package com.mims;

import android.util.Log;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

public class SampleLifecycleListener implements LifecycleObserver {

    public static String appstate = "Unknown";

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onMoveToForeground() {
        Log.d("SampleLifecycle", "Returning to foreground…");
        appstate="Foreground";
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    public void onMoveToBackground() {
        Log.d("SampleLifecycle", "Moving to background…");
        appstate="Background";
    }
}