package com.mims.rnarcgismapview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.res.ResourcesCompat;

import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.PointCollection;
import com.esri.arcgisruntime.geometry.Polygon;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.symbology.PictureMarkerSymbol;
import com.esri.arcgisruntime.symbology.SimpleFillSymbol;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.symbology.SimpleMarkerSymbol;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.ReadableMapKeySetIterator;
import com.google.gson.JsonObject;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class RNAGSGraphicsOverlay {
    private GraphicsOverlay graphicsOverlay;
    private HashMap<String, String> pointImageDictionary;
    private String referenceId;
    private Boolean shouldAnimateUpdate = false;
    private static Context contextOverlay;

    public RNAGSGraphicsOverlay(ReadableMap rawData, GraphicsOverlay graphicsOverlay, Context context) {
        contextOverlay=context;
        this.referenceId = rawData.getString("referenceId");
        this.graphicsOverlay = graphicsOverlay;
        if(rawData.hasKey("pointGraphics")) {
            ReadableArray pointImageDictionaryRaw = rawData.getArray("pointGraphics");
            pointImageDictionary = new HashMap<>();
            for (int i = 0; i < pointImageDictionaryRaw.size(); i++) {
                ReadableMap item = pointImageDictionaryRaw.getMap(i);
                if (item.hasKey("graphicId")) {
                    String graphicId = item.getString("graphicId");
                    String uri = item.getMap("graphic").getString("uri");
                    pointImageDictionary.put(graphicId, uri);
                }
            }
        }
        // Create graphics within overlay
        ReadableArray rawPoints = rawData.getArray("points");
        for (int i = 0; i < rawPoints.size(); i++) {
            addGraphicsLoop(rawPoints.getMap(i));

        }
    }

    // Getters
    public GraphicsOverlay getAGSGraphicsOverlay() {
        return graphicsOverlay;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setShouldAnimateUpdate(Boolean value) {
        shouldAnimateUpdate = value;
    }

    public void updateGraphics(ReadableArray args) {
        for (int i = 0; i < args.size(); i++) {
            updateGraphicLoop(args.getMap(i));
        }
    }

    private void updateGraphicLoop(ReadableMap args) {
        // Establish variables
        com.esri.arcgisruntime.geometry.Point agsPoint = null;
        // Get references
        String referenceId = args.getString("referenceId");
        Map<String, Object> attributes = null;
        Double rotation = 0.0;

        // Once we have all the required values, we change them
        Graphic graphic = ArrayHelper.graphicViaReferenceId(graphicsOverlay, referenceId);
        if (graphic == null) {
            return;
        }

        if (args.hasKey("attributes")) {
            attributes = RNAGSGraphicsOverlay.readableMapToMap(args.getMap("attributes"));
            graphic.getAttributes().putAll(attributes);

        }
        if (args.hasKey("graphicsId")) {
            String graphicsId = args.getString("graphicsId");
            String graphicUri = pointImageDictionary.get(graphicsId);
            if (graphicUri != null) {
                PictureMarkerSymbol symbol = new PictureMarkerSymbol(graphicUri);
                graphic.setSymbol(symbol);
            }
        }
        if (args.hasKey("latitude") && args.hasKey("longitude")) {
            Double latitude = args.getDouble("latitude");
            Double longitude = args.getDouble("longitude");
            agsPoint = new com.esri.arcgisruntime.geometry.Point(longitude, latitude, SpatialReferences.getWgs84());
        }
        if (args.hasKey("rotation")) {
            rotation = args.getDouble("rotation");
        }
        if (shouldAnimateUpdate) {
            Float initialRotation = (graphic.getSymbol() != null && graphic.getSymbol() instanceof PictureMarkerSymbol) ?
                    ((PictureMarkerSymbol) graphic.getSymbol()).getAngle() : 0;
            animateUpdate(graphic, ((com.esri.arcgisruntime.geometry.Point) graphic.getGeometry()), agsPoint, initialRotation, rotation.floatValue());

        } else {
            graphic.setGeometry(agsPoint);
            ((PictureMarkerSymbol) graphic.getSymbol()).setAngle(rotation.floatValue());
        }
        // End of updates

    }

    private int maxTimesFired = 10;
    private int timerDuration = 500;
    private void animateUpdate(Graphic graphic, com.esri.arcgisruntime.geometry.Point fromPoint, com.esri.arcgisruntime.geometry.Point toPoint,
                               Float fromRotation, Float toRotation){
        // Run animation
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Double dx = (toPoint.getX() - fromPoint.getX()) / maxTimesFired;
                Double dy = (toPoint.getY() - fromPoint.getY()) / maxTimesFired;
                Float dTheta = (toRotation - fromRotation) / maxTimesFired;
                PictureMarkerSymbol  symbol = null;
                if (graphic.getSymbol() instanceof PictureMarkerSymbol) {
                    symbol = ((PictureMarkerSymbol) graphic.getSymbol());
                }

                for(int timesFired = 0; timesFired < maxTimesFired; timesFired++) {
                    Double x = fromPoint.getX() + (dx * timesFired);
                    Double y = fromPoint.getY() + (dy * timesFired);
                    Float rotation = fromRotation + (dTheta * timesFired);
                    graphic.setGeometry(new com.esri.arcgisruntime.geometry.Point(x,y,SpatialReferences.getWgs84()));
                    if (symbol != null) {
                        symbol.setAngle(rotation);
                    }
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                graphic.setGeometry(toPoint);
                if (symbol != null) {
                    symbol.setAngle(toRotation);
                }
                timer.cancel();
            }
        },0,timerDuration);

    }

    public void addGraphics(ReadableArray args) {
        for (int i = 0; i < args.size(); i++) {
            addGraphicsLoop(args.getMap(i));
        }
    }

    private void addGraphicsLoop(ReadableMap map) {
        Point point = Point.fromRawData(map);
        Graphic graphic = RNAGSGraphicsOverlay.rnPointToAGSGraphic(point, pointImageDictionary);
        if(graphic!=null)
        graphicsOverlay.getGraphics().add(graphic);
    }

    public void removeGraphics(ReadableArray args) {
        for (int i = 0; i < args.size(); i++) {
            removeGraphicsLoop(args.getString(i));
        }
    }

    public void removeGraphics(String args) {

            removeGraphicsLoop(args);

    }
    private void removeGraphicsLoop(String referenceId) {
        // Identify the graphic and remove it
        Graphic graphic = ArrayHelper.graphicViaReferenceId(graphicsOverlay, referenceId);
        if (graphic != null) {
            graphicsOverlay.getGraphics().remove(graphic);
        }
    }

    // MARK: Static methods
    public static Graphic rnPointToAGSGraphic(Point point, Map<String, String> pointImageDictionary) {
        com.esri.arcgisruntime.geometry.Point agsPoint = new com.esri.arcgisruntime.geometry.Point(point.getLongitude(), point.getLatitude(), SpatialReferences.getWgs84());
        Graphic result=null;
        if (point.getGraphicId() != null && pointImageDictionary !=null && pointImageDictionary.get(point.getGraphicId()) != null) {
            String imageUri = pointImageDictionary.get(point.getGraphicId());
            assert imageUri != null;
            PictureMarkerSymbol symbol;
            String resourcename =  imageUri;
            if(imageUri.startsWith("http"))
            {



             symbol = new PictureMarkerSymbol(imageUri);
//                resourcename=  "app_images_personpoint";
//                if (imageUri.indexOf("normalpoint.png")>-1)
//                    resourcename =  "app_images_normalpoint";
            }
else {
                int resourceId = contextOverlay.getResources().getIdentifier(resourcename, "drawable", contextOverlay.getPackageName());
                Bitmap image = BitmapFactory.decodeResource(contextOverlay.getResources(), resourceId);
                BitmapDrawable markerDrawable = new BitmapDrawable(contextOverlay.getResources(), image);
                symbol = new PictureMarkerSymbol(markerDrawable);



            }
            if (point.getAttributes() != null) {
                result = new Graphic(agsPoint, point.getAttributes(), symbol);
            } else {
                result = new Graphic(agsPoint, symbol);
            }
            result.getAttributes().put("referenceId", point.getReferenceId());
        }
        else if (point.getGraphicId() != null&&point.getGraphicUnicode()!=0){

            String name = point.getGraphicType();
            Typeface typeface =null;
            switch (name){
                case "AdmIcon":
                    typeface=   Typeface.createFromAsset(contextOverlay.getAssets(),"fonts/adm-icon.ttf");
                    break;
                case "MaterialCommunityIcons":
                    typeface=   Typeface.createFromAsset(contextOverlay.getAssets(),"fonts/MaterialCommunityIcons.ttf");
                    break;

            }

         long fontLong=   point.getGraphicUnicode();
            char character =(char)fontLong;
               // abc= new String("", Charset.forName("UTF-8"));

            Bitmap image = Bitmap.createBitmap(60, 60, Bitmap.Config.ARGB_8888);
            Paint paint = new Paint();
            Canvas c = new Canvas(image);
            paint.setAntiAlias(true);
            paint.setSubpixelText(true);
            paint.setTypeface(typeface);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.BLUE);
            paint.setTextSize(60);
            c.drawText(Character.toString(character), 0, 50, paint);

            // c.drawColor(-1);
            BitmapDrawable markerDrawable = new BitmapDrawable(contextOverlay.getResources(), image);
            PictureMarkerSymbol symbol = new PictureMarkerSymbol(markerDrawable);
            if (point.getAttributes() != null) {
                result = new Graphic(agsPoint, point.getAttributes(), symbol);
            } else {
                result = new Graphic(agsPoint, symbol);
            }
            result.getAttributes().put("referenceId", point.getReferenceId());
        }

//        else {
//            SimpleMarkerSymbol symbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.CIRCLE, Color.GREEN, 10);
//            if (point.getAttributes() != null) {
//                result = new Graphic(agsPoint, point.getAttributes(), null);
//            } else {
//               // result = new Graphic(agsPoint, null);
//            }
//        }

        return result;

    }

    private static Map<String, Object> readableMapToMap(ReadableMap rawMap) {
        Map<String, Object> map = new HashMap<>();
        ReadableMapKeySetIterator iterator = rawMap.keySetIterator();
        while (iterator.hasNextKey()) {
            String key = iterator.nextKey();
            map.put(key, rawMap.getString(key));
        }
        return map;
    }

    // MARK: Inner class
    public static class Point {
        private Double latitude;
        private Double longitude;
        private Double rotation;
        private String referenceId;
        private Map<String, Object> attributes;
        private String graphicId;
        private int graphicUnicode;
        private String graphicType;

        public String getGraphicType() {
            return graphicType;
        }

        public void setGraphicType(String graphicType) {
            this.graphicType = graphicType;
        }


        public int getGraphicUnicode() {
            return graphicUnicode;
        }

        public void setGraphicUnicode(int graphicUnicode) {
            this.graphicUnicode = graphicUnicode;
        }



        public static Point fromRawData(ReadableMap rawData) {
            // Convert map to attribute map
            Map<String, Object> map = null;
            if (rawData.hasKey("attributes")) {
                ReadableMap rawMap = rawData.getMap("attributes");
                map = RNAGSGraphicsOverlay.readableMapToMap(rawMap);
            }
            Double rotation = 0.0;
            if (rawData.hasKey("rotation")) {
                rotation = rawData.getDouble("rotation");
            }
            String graphicId = "";
            if (rawData.hasKey("graphicId")) {
                graphicId = rawData.getString("graphicId");
            }
            String graphicType = "";
            if (rawData.hasKey("graphicType")) {
                graphicType = rawData.getString("graphicType");
            }
            int  graphicUnicode = 0;
            if (rawData.hasKey("graphicUnicode")) {
                graphicUnicode = rawData.getInt("graphicUnicode");
            }
            return new Point(
                    rawData.getDouble("latitude"),
                    rawData.getDouble("longitude"),
                    rotation,
                    rawData.getString("referenceId"),
                    map,
                    graphicId,
                    graphicType,
                    graphicUnicode
            );
        }

        private Point(@NonNull Double latitude, @NonNull Double longitude, @NonNull Double rotation, @NonNull String referenceId,
                      @Nullable Map<String, Object> attributes, @Nullable String graphicId,@Nullable String graphicType, @Nullable int graphicUnicode) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.rotation = rotation;
            this.referenceId = referenceId;
            this.attributes = attributes;
            this.graphicId = graphicId;
            this.graphicType=graphicType;
            this.graphicUnicode=graphicUnicode;
        }

        // MARK: Get/Set
        public void setRotation(Double rotation) {
            this.rotation = rotation;
        }

        public void setReferenceId(String referenceId) {
            this.referenceId = referenceId;
        }

        public void setLongitude(Double longitude) {
            this.longitude = longitude;
        }

        public void setLatitude(Double latitude) {
            this.latitude = latitude;
        }

        public void setGraphicId(String graphicId) {
            this.graphicId = graphicId;
        }

        public void setAttributes(Map<String, Object> attributes) {
            this.attributes = attributes;
        }

        public String getReferenceId() {
            return referenceId;
        }

        public String getGraphicId() {
            return graphicId;
        }

        public Map<String, Object> getAttributes() {
            return attributes;
        }

        public Double getRotation() {
            return rotation;
        }

        public double getLongitude() {
            return longitude;
        }

        public double getLatitude() {
            return latitude;
        }
    }
}
