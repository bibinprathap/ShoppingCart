package com.mims.rnarcgismapview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esri.arcgisruntime.ArcGISRuntimeException;
import com.esri.arcgisruntime.concurrent.ListenableFuture;
import com.esri.arcgisruntime.data.Feature;
import com.esri.arcgisruntime.data.FeatureQueryResult;
import com.esri.arcgisruntime.data.FeatureTable;
import com.esri.arcgisruntime.data.Field;
import com.esri.arcgisruntime.data.QueryParameters;
import com.esri.arcgisruntime.data.ServiceFeatureTable;
import com.esri.arcgisruntime.geometry.Envelope;
import com.esri.arcgisruntime.geometry.Geometry;
import com.esri.arcgisruntime.geometry.GeometryEngine;
import com.esri.arcgisruntime.geometry.PointCollection;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.PointCollection;
import com.esri.arcgisruntime.geometry.Polygon;
import com.esri.arcgisruntime.geometry.Polyline;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.layers.FeatureLayer;
import com.esri.arcgisruntime.location.LocationDataSource;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.Basemap;
import com.esri.arcgisruntime.mapping.LayerList;
import com.esri.arcgisruntime.mapping.Viewpoint;
import com.esri.arcgisruntime.mapping.view.Callout;
import com.esri.arcgisruntime.mapping.view.DefaultMapViewOnTouchListener;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.mapping.view.IdentifyGraphicsOverlayResult;
import com.esri.arcgisruntime.mapping.view.MapView;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.symbology.TextSymbol;
import com.esri.arcgisruntime.symbology.UniqueValueRenderer;
import com.esri.arcgisruntime.tasks.networkanalysis.DirectionManeuver;
import com.esri.arcgisruntime.tasks.networkanalysis.Route;
import com.esri.arcgisruntime.tasks.networkanalysis.RouteParameters;
import com.esri.arcgisruntime.tasks.networkanalysis.RouteResult;
import com.esri.arcgisruntime.tasks.networkanalysis.Stop;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.esri.arcgisruntime.layers.ArcGISTiledLayer;
import com.esri.arcgisruntime.symbology.SimpleFillSymbol;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.tasks.networkanalysis.RouteTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import com.mims.R;

public class RNAGSMapView extends LinearLayout implements LifecycleEventListener {
    // MARK: Variables/Prop declarations
    View rootView;
    public MapView mapView;
    String basemapUrl = "";
    String routeUrl = "";
    Boolean recenterIfGraphicTapped = false;
    HashMap<String, RNAGSGraphicsOverlay> rnGraphicsOverlays = new HashMap<>();
    GraphicsOverlay routeGraphicsOverlay;
    RNAGSRouter router;
    private Callout callout;
    Double minZoom = 0.0;
    Double maxZoom = 0.0;
    Boolean rotationEnabled = true;

    // MARK: Initializers
    public RNAGSMapView(Context context) {
        super(context);
        rootView = inflate(context.getApplicationContext(), R.layout.rnags_mapview, this);
        mapView = rootView.findViewById(R.id.agsMapView);
        if (context instanceof ReactContext) {
            ((ReactContext) context).addLifecycleEventListener(this);
        }
        setUpMap();
       // setUpCallout();
    }

    private void setUpCallout() {
        // We want to create the callout right after the View has finished its layout
        mapView.post(() -> {
            callout = mapView.getCallout();
            callout.setContent(inflate(getContext().getApplicationContext(), R.layout.rnags_callout_content, null));
            Callout.ShowOptions showOptions = new Callout.ShowOptions();
            showOptions.setAnimateCallout(true);
            showOptions.setAnimateRecenter(true);
            showOptions.setRecenterMap(false);
            callout.getStyle().setMaxHeight(1000);
            callout.getStyle().setMaxWidth(1000);
            callout.getStyle().setMinHeight(100);
            callout.getStyle().setMinWidth(100);
            callout.setShowOptions(showOptions);
            callout.setPassTouchEventsToMapView(false);
        });

    }

    @SuppressLint("ClickableViewAccessibility")
    public void setUpMap() {


        ArcGISMap arcGISMap = new ArcGISMap();
        arcGISMap.setBasemap(Basemap.createStreetsVector());
        mapView.setMap(arcGISMap);// Basemap.Type.STREETS_VECTOR, 34.057, -117.196, 17
        mapView.setOnTouchListener(new OnSingleTouchListener(getContext(), mapView));
        routeGraphicsOverlay = new GraphicsOverlay();
        mapView.getGraphicsOverlays().add(routeGraphicsOverlay);
//         mapView.getMap().addDoneLoadingListener(() -> {
//         ArcGISRuntimeException e = mapView.getMap().getLoadError();
//         Boolean success = e != null;
//         String errorMessage = !success ? "" : e.getMessage();
//         WritableMap map = Arguments.createMap();
//         map.putBoolean("success",success);
//         map.putString("errorMessage",errorMessage);
//
//         emitEvent("onMapDidLoad",map);
//         });
    }

    // MARK: Prop set methods
    public void setBasemapUrl(String url) {
        basemapUrl = url;
        if (basemapUrl == null || basemapUrl.isEmpty()) {
            return;
        }
        // Set basemap of map
        if (mapView.getMap() == null) {
            setUpMap();
        }
        ArcGISTiledLayer tiledLayer = new ArcGISTiledLayer(url);
        // ArcGISMap map = new ArcGISMap();
        ArcGISMap map = mapView.getMap();
        map.getOperationalLayers().add(tiledLayer);
        mapView.setMap(map);

        // map.setBasemap(Basemap.createOpenStreetMap());
        // mapView.setMap(Basemap.createOpenStreetMap());

        // final Basemap basemap = new Basemap(basemapUrl);
        // basemap.addDoneLoadingListener(() -> {
        // if (basemap.getLoadError() != null) {
        // Log.w("AGSMap", "An error occurred: " + basemap.getLoadError().getMessage());
        // } else {
        // mapView.getMap().setBasemap(basemap);
        // }
        // });
        // basemap.loadAsync();
    }

    public void setLayers(ReadableArray array) {

        ArcGISMap map = mapView.getMap();
        // LayerList layerList=map.getOperationalLayers();
        map.getOperationalLayers().clear();
        for (int i = 0; i < array.size(); i++) {

            String url = array.getString(i);// "https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/0"
            ServiceFeatureTable serviceFeatureTable = new ServiceFeatureTable(url);
            FeatureLayer featureLayer = new FeatureLayer(serviceFeatureTable);
            //serviceFeatureTable.setFeatureRequestMode(ServiceFeatureTable.FeatureRequestMode.MANUAL_CACHE);
            featureLayer.setVisible(true);

            map.getOperationalLayers().add(featureLayer);
             //commented for check in
//            serviceFeatureTable.loadAsync();
//            // add a done loading listener to call populate from service when the table is loaded is done
//            serviceFeatureTable.addDoneLoadingListener(new Runnable() {
//                @Override
//                public void run() {
//                    List<Field> fields = serviceFeatureTable.getFields();
//
//                    Iterator<Field> iterator = fields.iterator();
//                    while (iterator.hasNext()) {
//                        Field field = iterator.next();
//                        Log.i("fields", "run: " + field.getName());
//
//
//                    }
//                    QueryParameters params = new QueryParameters();
//                    params.setWhereClause("COMMUNITYNAMEENG='E11'");
//                    List<String> outFields = new ArrayList<>();
//                    outFields.add("*");
//                    ListenableFuture<FeatureQueryResult> future = serviceFeatureTable
//                            .populateFromServiceAsync(params, true, outFields);
//                    Log.i("future", "run: " + future);
//
//
//                    future.addDoneListener(new Runnable() {
//                        @Override
//                        public void run() {
//                            try {
//                                //call get on the future to get the result
//                                FeatureQueryResult result = future.get();
//                                // create an Iterator
//                                Iterator<Feature> iterator = result.iterator();
//                                Feature feature;
//                                // cycle through selections
//                                int counter = 0;
//                                while (iterator.hasNext()) {
//                                    feature = iterator.next();
//                                    counter++;
//                                    featureLayer.setFeatureVisible(feature,true);
//                                    featureLayer.setSelectionColor(0xFF000000);
//                                    Log.d(getResources().getString(R.string.app_name),
//                                            "Selection #: " + counter + " Table name: " + feature.getFeatureTable().getTableName());
//                                }
////                                Toast.makeText(getApplicationContext(), counter + " features returned", Toast.LENGTH_SHORT).show();
//
//                            } catch (Exception e) {
//                                Log.e(getResources().getString(R.string.app_name), "Populate from service failed: " + e.getMessage());
//                            }
//                        }
//                    });
//                }
//            });
        }
        mapView.setMap(map);


    }

    public void setBaseMapType(String baseMapType) {

        if (baseMapType.equals("DARK_GRAY")) {
            ArcGISMap map = mapView.getMap();
            map.setBasemap(Basemap.createDarkGrayCanvasVector());
            mapView.setMap(map);

        } else if (baseMapType.equals("IMAGERY")) {
            ArcGISMap map = mapView.getMap();
            map.setBasemap(Basemap.createImageryWithLabelsVector());
            mapView.setMap(map);
        } else if (baseMapType.equals("LIGHT_GRAY")) {
            ArcGISMap map = mapView.getMap();
            map.setBasemap(Basemap.createLightGrayCanvasVector());
            mapView.setMap(map);
        } else if (baseMapType.equals("STREETS")) {
            ArcGISMap map = mapView.getMap();
            map.setBasemap(Basemap.createStreetsVector());
            mapView.setMap(map);

        }

    }

    public void setRouteUrl(String url) {
        routeUrl = url;
        router = new RNAGSRouter(getContext().getApplicationContext(), routeUrl);
    }

    public void setRecenterIfGraphicTapped(boolean value) {
        recenterIfGraphicTapped = value;
    }

    public void setInitialMapCenter(ReadableArray initialCenter) {
        ArrayList<Point> points = new ArrayList<>();
        for (int i = 0; i < initialCenter.size(); i++) {
            ReadableMap item = initialCenter.getMap(i);
            if (item == null) {
                continue;
            }
            Double latitude = item.getDouble("latitude");
            Double longitude = item.getDouble("longitude");
            if (latitude == 0 || longitude == 0) {
                continue;
            }
            Point point = new Point(longitude, latitude, SpatialReferences.getWgs84());
            points.add(point);
        }
        // If no points exist, add a sample point
        if (points.size() == 0) {
            points.add(new Point(54.37820468097925, 24.4876619707793, SpatialReferences.getWgs84()));

            //////////////////

        }
        if (points.size() == 1) {
            mapView.getMap().setInitialViewpoint(new Viewpoint(points.get(0), 10000));
            // GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
            // mapView.getGraphicsOverlays().add(graphicsOverlay);

        } else {
            Polygon polygon = new Polygon(new PointCollection(points));
            Viewpoint viewpoint = viewpointFromPolygon(polygon);
            mapView.getMap().setInitialViewpoint(viewpoint);
        }
    }

    public void setMinZoom(Double value) {
        minZoom = value;
        mapView.getMap().setMinScale(minZoom);
    }

    public void setMaxZoom(Double value) {
        maxZoom = value;
        mapView.getMap().setMaxScale(maxZoom);
    }

    public void setRotationEnabled(Boolean value) {
        rotationEnabled = value;
    }

    public void drawRender(String rendersJson){
        ArcGISMap map = mapView.getMap();
       rendersJson="{data:"+rendersJson+"}";
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(rendersJson);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject layerObject = jsonArray.getJSONObject(i);
                JSONArray featuresArray = layerObject.getJSONArray("features");
                ServiceFeatureTable serviceFeatureTable = new ServiceFeatureTable(layerObject.getString("url"));
                FeatureLayer featureLayer = new FeatureLayer(serviceFeatureTable);
                UniqueValueRenderer uniqueValueRenderer = new UniqueValueRenderer();
                int fieldCount = 0;
                for (int j = 0; j < featuresArray.length(); j++) {
                    JSONObject featuresObject = featuresArray.getJSONObject(j);
                    int color = featuresObject.getInt("color");
                    SimpleFillSymbol FillSymbol = new SimpleFillSymbol(SimpleFillSymbol.Style.SOLID, color, new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, color, 2));
                    JSONObject fieldsObject = featuresObject.getJSONObject("fields");
                    Iterator<String> iterator = fieldsObject.keys();
                    List<Object> valuesList = new ArrayList<>();
                    while (iterator.hasNext()) {
                        String key = iterator.next();
                        String value = fieldsObject.getString(key);
                        Log.i("JSON", "key = " + key + " value = " + value);

                        if (fieldCount == 0)
                            uniqueValueRenderer.getFieldNames().add(key);
                        valuesList.add(value);
                        if (!iterator.hasNext())
                            uniqueValueRenderer.getUniqueValues().add(new UniqueValueRenderer.UniqueValue("MIMS", "ADM", FillSymbol, valuesList));

                    }
                    fieldCount++;
                }

                featureLayer.setRenderer(uniqueValueRenderer);
                map.getOperationalLayers().add(featureLayer);
            }
            mapView.setMap(map);
        } catch (Exception ex) {
            ex.printStackTrace();

        }
    }

    public void drawPolygons(String polygonJson) {
        JSONObject polygons;
        GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
        PointCollection polygonPointsforInitialViewPoint = new PointCollection(SpatialReferences.getWgs84());

        try {
            polygons = new JSONObject(polygonJson);

            JSONArray polygonsJSONArray = polygons.getJSONArray("polygons");
            if(polygonsJSONArray.length()>0) {
                for (int i = 0; i < polygonsJSONArray.length(); i++) {
                    JSONObject polygon = polygonsJSONArray.getJSONObject(i);
                    String id = polygon.getString("PolygonID");
                    String data = polygon.getJSONObject("data").toString();
                    int polygonFillColor = polygon.getInt("polygonFillColor");
                    int boundaryLineColor = polygon.getInt("boundaryLineColor");
                    float lineWidth = BigDecimal.valueOf(polygon.getDouble("lineWidth")).floatValue();
                    JSONArray pointsJSONArray = polygon.getJSONArray("coords");
                    PointCollection polygonPoints = new PointCollection(SpatialReferences.getWgs84());
                    for (int j = 0; j < pointsJSONArray.length(); j++) {

                        JSONObject coords = pointsJSONArray.getJSONObject(j);
                        Double latitude = coords.getDouble("latitude");
                        Double longitude = coords.getDouble("longitude");
                        polygonPoints.add(new com.esri.arcgisruntime.geometry.Point(longitude, latitude));
                        polygonPointsforInitialViewPoint
                                .add(new com.esri.arcgisruntime.geometry.Point(longitude, latitude));

                    }
                    Polygon shape = new Polygon(polygonPoints);
                    SimpleFillSymbol polygonSymbol = new SimpleFillSymbol(SimpleFillSymbol.Style.SOLID, polygonFillColor,
                            new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, boundaryLineColor, lineWidth));
                    Graphic polygonGraphic = new Graphic(shape, polygonSymbol);
                    polygonGraphic.getAttributes().put("data", data);

                    graphicsOverlay.getGraphics().add(polygonGraphic);
                    Point labelPoint = new Point(shape.getExtent().getCenter().getX(), shape.getExtent().getCenter().getY(),
                            SpatialReferences.getWgs84());
                    TextSymbol bassRockSymbol = new TextSymbol(10, id, boundaryLineColor,
                            TextSymbol.HorizontalAlignment.CENTER, TextSymbol.VerticalAlignment.MIDDLE);
                    Graphic labelGraphic = new Graphic(labelPoint, bassRockSymbol);
                    labelGraphic.getAttributes().put("data", data);
                    graphicsOverlay.getGraphics().add(labelGraphic);

                    Log.i("id", "drawPloygons: " + id);

                }

                Polygon initalViewPointPolygon = new Polygon(polygonPointsforInitialViewPoint);
                Point viewPoint = new Point(initalViewPointPolygon.getExtent().getCenter().getX(),
                        initalViewPointPolygon.getExtent().getCenter().getY(), SpatialReferences.getWgs84());
                mapView.getGraphicsOverlays().add(graphicsOverlay);
                mapView.getMap().setInitialViewpoint(new Viewpoint(viewPoint, 10000));
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    public void setRoute(ReadableMap args){

        GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
        mapView.getGraphicsOverlays().add(graphicsOverlay);
        RNAGSGraphicsOverlay overlay = new RNAGSGraphicsOverlay(args, graphicsOverlay, getContext());
        rnGraphicsOverlays.put(overlay.getReferenceId(), overlay);
        RouteTask  mRouteTask = new RouteTask(getContext(), "https://utility.arcgis.com/usrsvcs/appservices/OvAuTbABo8HsRY0t/rest/services/World/Route/NAServer/Route_World");


        final ListenableFuture<RouteParameters> listenableFuture = mRouteTask.createDefaultParametersAsync();
        listenableFuture.addDoneListener(new Runnable() {
            @Override
            public void run() {
                try {
                    if (listenableFuture.isDone()) {
                        //int i=0;
                        RouteParameters   mRouteParams = listenableFuture.get();
                        GraphicsOverlay  mGraphicsOverlay = new GraphicsOverlay();

                        ReadableArray rawPoints = args.getArray("points");
                        List<Stop> routeStops = new ArrayList<>();
                        for (int i = 0; i < rawPoints.size(); i++) {
                            ReadableMap pointsMap= rawPoints.getMap(i);
                            Stop stop = new Stop(new Point(pointsMap.getDouble("longitude") ,pointsMap.getDouble("latitude") , SpatialReferences.getWgs84()));
                            routeStops.add(stop);

                        }

                        mRouteParams.setStops(routeStops);

                        // set return directions as true to return turn-by-turn directions in the result of
                        // getDirectionManeuvers().
                        mRouteParams.setReturnDirections(true);

                        // solve
                        RouteResult result = mRouteTask.solveRouteAsync(mRouteParams).get();
                        final List routes = result.getRoutes();
                       Route mRoute = (Route) routes.get(0);
                      SimpleLineSymbol  mRouteSymbol = new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, Color.BLUE, 3);
                        // create a mRouteSymbol graphic
                        Graphic routeGraphic = new Graphic(mRoute.getRouteGeometry(), mRouteSymbol);
                        // add mRouteSymbol graphic to the map

                        mGraphicsOverlay.getGraphics().add(routeGraphic);
                        mapView.getGraphicsOverlays().add(mGraphicsOverlay);
                        // get directions
                        // NOTE: to get turn-by-turn directions Route Parameters should set returnDirection flag as true
//                        final List<DirectionManeuver> directions = mRoute.getDirectionManeuvers();
//
//                        String[] directionsArray = new String[directions.size()];
//
//                        for (DirectionManeuver dm : directions) {
//                           // directionsArray[i++] = dm.getDirectionText();
//                        }
                    }
                } catch (Exception e) {
                }
            }
        });


    }
    // MARK: Exposed RN Methods
    public void showCallout(ReadableMap args) {
        ReadableMap rawPoint = args.getMap("point");
        if (!rawPoint.hasKey("latitude") || !rawPoint.hasKey("longitude")) {
            return;
        }
        Double latitude = rawPoint.getDouble("latitude");
        Double longitude = rawPoint.getDouble("longitude");
        if (latitude == 0 || longitude == 0) {
            return;
        }
        String title = "";
        String text = "";
        Boolean shouldRecenter = false;

        if (args.hasKey("title")) {
            title = args.getString("title");
        }
        if (args.hasKey("text")) {
            text = args.getString("text");
        }
        if (args.hasKey("shouldRecenter")) {
            shouldRecenter = args.getBoolean("shouldRecenter");
        }

        // Displaying the callout
        Point agsPoint = new Point(longitude, latitude, SpatialReferences.getWgs84());

        // Set callout content
        View calloutContent = callout.getContent();
        ((TextView) calloutContent.findViewById(R.id.title)).setText(title);
        ((TextView) calloutContent.findViewById(R.id.text)).setText(text);
        callout.setLocation(agsPoint);
        callout.show();
        Log.i("AGS", callout.isShowing() + " " + calloutContent.getWidth() + " " + calloutContent.getHeight());
        if (shouldRecenter) {
            mapView.setViewpointCenterAsync(agsPoint);
        }
    }

    public void centerMap(ReadableArray args) {
        final ArrayList<Point> points = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            ReadableMap item = args.getMap(i);
            if (item == null) {
                continue;
            }
            Double latitude = item.getDouble("latitude");
            Double longitude = item.getDouble("longitude");
            if (latitude == 0 || longitude == 0) {
                continue;
            }
            points.add(new Point(longitude, latitude, SpatialReferences.getWgs84()));
        }
        // Perform the recentering
        if (points.size() == 1) {
            mapView.setViewpointCenterAsync(points.get(0));
        } else if (points.size() > 1) {
            PointCollection pointCollection = new PointCollection(points);
            Polygon polygon = new Polygon(pointCollection);
            mapView.setViewpointGeometryAsync(polygon, 50);
        }

    }


    public void showInspectorLocation(ReadableArray args){

        for (int i = 0; i < args.size(); i++) {
            ReadableMap item = args.getMap(i);
            String overlayReferenceId123  = item.toString();
            String overlayReferenceId = item.getString("referenceId");
            Log.d("", "showInspectorLocation: "+overlayReferenceId);
            if (rnGraphicsOverlays.containsKey(overlayReferenceId)) {
                RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
                Log.d("overlay", "overlay: " + overlay.getReferenceId());

                if (overlay != null && item.hasKey("points")) {
                    // overlay.removeGraphics(args.getArray("referenceIds"));
                    ReadableArray pointsArray = item.getArray("points");
                    // ReadableArray pointrefIdArray= new A
                    for (int k = 0; k < pointsArray.size(); k++) {
                        ReadableMap point = pointsArray.getMap(k);
                        if (point == null) {
                            continue;
                        }
                        Double latitude = point.getDouble("latitude");
                        Double longitude = point.getDouble("longitude");
                        String referenceId = point.getString("referenceId");
                        overlay.removeGraphics(referenceId);

                    }

                    Log.d("overlay1", "overlay:1 " + overlay.getReferenceId());
                }
            }



            GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
            mapView.getGraphicsOverlays().add(graphicsOverlay);
            RNAGSGraphicsOverlay overlay = new RNAGSGraphicsOverlay(item, graphicsOverlay, getContext());
            rnGraphicsOverlays.put(overlay.getReferenceId(), overlay);
            if(item.hasKey("points")){
                ReadableArray pointsArray = item.getArray("points");
                for (int k = 0; k < pointsArray.size(); k++) {
                    ReadableMap point = pointsArray.getMap(k);
                    if (point == null) {
                        continue;
                    }
                    Double latitude = point.getDouble("latitude");
                    Double longitude = point.getDouble("longitude");
                    String referenceId = point.getString("referenceId");
                   Point center=new Point(longitude, latitude, SpatialReferences.getWgs84());
                   mapView.setViewpointCenterAsync(center);

                }

            }

        }

//
//
    }
    // Layer add/remove
    public void addGraphicsOverlay(ReadableMap args) {
        GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
        mapView.getGraphicsOverlays().add(graphicsOverlay);
        RNAGSGraphicsOverlay overlay = new RNAGSGraphicsOverlay(args, graphicsOverlay, getContext());
        rnGraphicsOverlays.put(overlay.getReferenceId(), overlay);

    }

    public void removeGraphicsOverlay(String removalId) {
        RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(removalId);
        if (overlay == null) {
            Log.w("Warning (AGS)", "No overlay with the associated ID was found.");
            return;
        }
        mapView.getGraphicsOverlays().remove(overlay.getAGSGraphicsOverlay());
        rnGraphicsOverlays.remove(removalId);
    }

    // Point updates
    public void updatePointsInGraphicsOverlay(ReadableMap args) {
        if (!args.hasKey("overlayReferenceId")) {
            Log.w("Warning (AGS)", "No overlay with the associated ID was found.");
            return;
        }
        Boolean shouldAnimateUpdate = false;
        if (args.hasKey("animated")) {
            shouldAnimateUpdate = args.getBoolean("animated");
        }
        String overlayReferenceId = args.getString("overlayReferenceId");
        RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
        if (overlay != null && args.hasKey("updates")) {
            overlay.setShouldAnimateUpdate(shouldAnimateUpdate);
            overlay.updateGraphics(args.getArray("updates"));
        }
    }

    public void placeMarkers(ReadableMap args) {
      //  String abc=args.toString();

        String overlayReferenceId = args.getString("referenceId");

        if (rnGraphicsOverlays.containsKey(overlayReferenceId)) {
            RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
            Log.d("overlay", "overlay: " + overlay.getReferenceId());

            if (overlay != null && args.hasKey("points")) {
                // overlay.removeGraphics(args.getArray("referenceIds"));
                ReadableArray pointsArray = args.getArray("points");
                // ReadableArray pointrefIdArray= new A
                for (int i = 0; i < pointsArray.size(); i++) {
                    ReadableMap point = pointsArray.getMap(i);
                    if (point == null) {
                        continue;
                    }
                    Double latitude = point.getDouble("latitude");
                    Double longitude = point.getDouble("longitude");
                    String referenceId = point.getString("referenceId");
                    overlay.removeGraphics(referenceId);

                }

                Log.d("overlay1", "overlay:1 " + overlay.getReferenceId());
            }
        }

        GraphicsOverlay graphicsOverlay = new GraphicsOverlay();
        mapView.getGraphicsOverlays().add(graphicsOverlay);
        RNAGSGraphicsOverlay overlay = new RNAGSGraphicsOverlay(args, graphicsOverlay, getContext());
        rnGraphicsOverlays.put(overlay.getReferenceId(), overlay);
    }

    public void addPointsToOverlay(ReadableMap args) {
        if (!args.hasKey("overlayReferenceId")) {
            Log.w("Warning (AGS)", "No overlay with the associated ID was found.");
            return;
        }
        String overlayReferenceId = args.getString("overlayReferenceId");
        RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
        if (overlay != null && args.hasKey("points")) {
            overlay.addGraphics(args.getArray("points"));
        }
    }

    public void removePointsFromOverlay(ReadableMap args) {
        if (!args.hasKey("overlayReferenceId")) {
            Log.w("Warning (AGS)", "No overlay with the associated ID was found.");
            return;
        }
        String overlayReferenceId = args.getString("overlayReferenceId");
        RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
        if (overlay != null && args.hasKey("referenceIds")) {
            overlay.removeGraphics(args.getArray("referenceIds"));
        }
    }

    // set/get
    public void setRouteIsVisible(Boolean isVisible) {
        routeGraphicsOverlay.setVisible(isVisible);
    }

    public Boolean getRouteIsVisible() {
        return routeGraphicsOverlay.isVisible();
    }

    // Routing
    public void routeGraphicsOverlay(ReadableMap args) {
        if (router == null) {
            Log.w("Warning (AGS)",
                    "Router has not been initialized. Perhaps no route URL was provided? Route URL:" + routeUrl);
            return;
        }
        if (!args.hasKey("overlayReferenceId")) {
            Log.w("Warning (AGS)", "No overlay with the associated ID was found.");
            return;
        }
        String overlayReferenceId = args.getString("overlayReferenceId");
        RNAGSGraphicsOverlay overlay = rnGraphicsOverlays.get(overlayReferenceId);
        ArrayList<String> removeGraphics = new ArrayList<>();
        if (args.hasKey("excludeGraphics")) {
            ReadableArray rawArray = args.getArray("excludeGraphics");
            for (Object item : rawArray.toArrayList()) {
                removeGraphics.add(((String) item));
            }
        }
        final String color;
        if (args.hasKey("routeColor")) {
            color = args.getString("routeColor");
        } else {
            color = "#FF0000";
        }
        assert overlay != null;
        ListenableFuture<RouteResult> future = router.createRoute(overlay.getAGSGraphicsOverlay(), removeGraphics);
        if (future == null) {
            Log.w("Warning (AGS)",
                    "There was an issue creating the route. Please try again later, or check your routing server.");
            return;
        }
        setIsRouting(true);
        future.addDoneListener(() -> {
            try {
                RouteResult result = future.get();
                if (result != null && !result.getRoutes().isEmpty()) {
                    Route route = result.getRoutes().get(0);
                    drawRoute(route, color);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                setIsRouting(false);
            }
        });
    }

    private void setIsRouting(Boolean value) {
        ((ReactContext) getContext()).getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit("isRoutingChanged", value);
    }

    private void drawRoute(Route route, String color) {
        if (route == null) {
            Log.w("Warning (AGS)", "No route result returned.");
            return;
        }
        routeGraphicsOverlay.getGraphics().clear();
        SimpleLineSymbol symbol = new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, Color.parseColor(color), 5);
        Polyline polyline = route.getRouteGeometry();
        Graphic routeGraphic = new Graphic(route.getRouteGeometry(), symbol);
        routeGraphicsOverlay.getGraphics().add(routeGraphic);
    }

    // MARK: Event emitting
    public void emitEvent(String eventName, WritableMap args) {
        ((ReactContext) getContext()).getJSModule(RCTEventEmitter.class).receiveEvent(getId(), eventName, args);
    }

    // MARK: OnTouchListener
    public class OnSingleTouchListener extends DefaultMapViewOnTouchListener {
        OnSingleTouchListener(Context context, MapView mMapView) {
            super(context, mMapView);
        }

        @Override
        public boolean onRotate(MotionEvent event, double rotationAngle) {
            if (rotationEnabled) {
                return super.onRotate(event, rotationAngle);
            } else {
                return true;
            }
        }

        // @Override
        // public boolean onDown(MotionEvent e) {
        //     WritableMap map = createPointMap(e);
        //     emitEvent("onMapMoved", map);
        //     return true;
        // }


        // @Override
        // public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
        // {
        //     // for on scroll event
        //     WritableMap map = createPointMap(e1);
        //     WritableMap map2 = createPointMap(e2);
        //    // WritableMap map3=map2.getMap("raja");
        //    // map.merge(map2);
        //    // map.putMap("screenPoint1",);
        //     android.graphics.Point screenPoint = new android.graphics.Point(((int) e1.getX()), ((int) e1.getY()));
        //     android.graphics.Point screenPoint2 = new android.graphics.Point(((int) e2.getX()), ((int) e2.getY()));
        //     Log.d("onScroll","distanceX"+map.toString()+"distanceY"+map2.toString());
        //     return  true ;
        // }

        private WritableMap createPointMap(MotionEvent e) {
            android.graphics.Point screenPoint = new android.graphics.Point(Math.round( e.getX()), Math.round(e.getY()));
            WritableMap screenPointMap = Arguments.createMap();
            screenPointMap.putInt("x", screenPoint.x);
            screenPointMap.putInt("y", screenPoint.y);
            Point mapPoint = mMapView.screenToLocation(screenPoint);
            WritableMap mapPointMap = Arguments.createMap();
            if (mapPoint != null) {
                Point latLongPoint = ((Point) GeometryEngine.project(mapPoint, SpatialReferences.getWgs84()));
                LocationDataSource.Location location=new LocationDataSource.Location(latLongPoint);
                mapPointMap.putDouble("latitude", latLongPoint.getY());
                mapPointMap.putDouble("longitude", latLongPoint.getX());
                mapPointMap.putDouble("accuracy", location.getHorizontalAccuracy());
            }
            WritableMap map = Arguments.createMap();
            map.putMap("screenPoint", screenPointMap);
            map.putMap("mapPoint", mapPointMap);
            return map;
        }

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            WritableMap map = createPointMap(e);
            android.graphics.Point screenPoint = new android.graphics.Point(Math.round(  e.getX()), Math.round( e.getY()));

      ListenableFuture<List<IdentifyGraphicsOverlayResult>> future = mMapView. identifyGraphicsOverlaysAsync(screenPoint, 15, false);
            future.addDoneListener(() -> {
                try {
                    if (!future.get().isEmpty()) {
                        // We only care about the topmost result
                        IdentifyGraphicsOverlayResult futureResult = future.get().get(0);
                        List<Graphic> graphicResult = futureResult.getGraphics();
                        // More null checking >.>
                        if (!graphicResult.isEmpty()) {
                            Graphic result = graphicResult.get(0);
                            //Map<String,Object> map1=result.getAttributes();
                           // result.
                            //result.getGraphicsOverlay().getLabelDefinitions().
                            if(result.getAttributes().get("data")!=null)
                             map.putString("data",Objects.requireNonNull(result.getAttributes().get("data").toString()));
                             else {
                           Map<String,Object> hashMap= result.getAttributes();

                                for (Map.Entry<String,Object> entry : hashMap.entrySet())   {

                                    map.putString(entry.getKey(), entry.getValue().toString());
                                }

                             }
                           //  Objects.requireNonNull(result.getAttributes().get("data")));
//                            if (recenterIfGraphicTapped) {
//                                mapView.setViewpointCenterAsync(((Point) result.getGeometry().getExtent().getCenter()));
//                            }
                        }
                    }
                } catch (InterruptedException | ExecutionException exception) {
                    exception.printStackTrace();
                } finally {
                    emitEvent("onSingleTap", map);
                }
            });

            return true;
        }
    }

    // MARK: Lifecycle Event Listeners
    @Override
    public void onHostResume() {
        mapView.resume();
    }

    @Override
    public void onHostPause() {
        mapView.pause();
    }

    @Override
    public void onHostDestroy() {
        mapView.dispose();
        if (getContext() instanceof ReactContext) {
            ((ReactContext) getContext()).removeLifecycleEventListener(this);
        }
    }

    // MARK: Misc.
    public Viewpoint viewpointFromPolygon(Polygon polygon) {
        Envelope envelope = polygon.getExtent();
        Double paddingWidth = envelope.getWidth() * 0.5;
        Double paddingHeight = envelope.getHeight() * 0.5;
        return new Viewpoint(new Envelope(envelope.getXMin() - paddingWidth, envelope.getYMax() + paddingHeight,
                envelope.getXMax() + paddingWidth, envelope.getYMin() - paddingHeight, SpatialReferences.getWgs84()),
                0);
    }
}
