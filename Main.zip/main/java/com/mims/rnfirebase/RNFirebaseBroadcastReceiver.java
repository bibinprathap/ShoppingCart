package com.mims.rnfirebase;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
//import android.widget.Toast;
import android.util.Log;
import com.mims.rnfirebase.RNFirebaseModule;

public class RNFirebaseBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG = "RNFirebase";

    @Override
    public void onReceive(Context context, Intent intent) {

        try {
            RNFirebaseModule.sendNotification(intent.getExtras(), context);
            RNFirebaseBadgeHelper badgeHelper = new RNFirebaseBadgeHelper(context);
            int badgeCount = badgeHelper.getBadgeCount() + 1;
            badgeHelper.setBadgeCount(badgeCount);
            Log.d(TAG, "BroadcastReceiver for scheduled notifications...");
        } catch (Exception e) {
            Log.d(TAG, "Scheduler error  " + e.getMessage());
        }

    }
}