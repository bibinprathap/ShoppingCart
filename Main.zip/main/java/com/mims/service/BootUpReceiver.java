package com.mims.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

import static com.mims.MainActivity.mReceiver;

public class BootUpReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
       

        Intent i = new Intent(context, com.mims.service.HeartbeartService.class);
        i.putExtra("uniqueId", "");
        i.putExtra("receiverTag", mReceiver);
        context.startForegroundService(i);
    }
}
