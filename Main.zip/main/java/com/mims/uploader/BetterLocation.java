package com.mims.uploader;

import android.Manifest;
import android.app.Activity;
import android.location.Location;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.util.Log;

import com.esri.arcgisruntime.geometry.Geometry;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.PointCollection;
import com.esri.arcgisruntime.geometry.Polygon;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.Viewpoint;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.symbology.SimpleFillSymbol;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.symbology.TextSymbol;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.BufferedInputStream;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import java.util.Map;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.ACCESS_WIFI_STATE;
//import static com.mims.MainActivity.mFusedLocationClient;
import static com.mims.MainActivity.reactContextMain;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.text.format.Formatter;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiInfo;
import com.esri.arcgisruntime.geometry.GeometryEngine;
//import static com.mims.uploader.UploaderModule.geoCheckData;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class BetterLocation  {
    private static String TAG = "Location: ";
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    public static String DeviceIpAddress;
    public static String DeviceEventTime;

    public static Map<String, Object> places = new HashMap<>();
    WifiInfo wifiInfo;
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE
    };

    public void findCurrentPlace(Context context ) {

        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
            findCurrentPlaceWithPermissions(context);
        }
        else {
          //  ActivityCompat.requestPermissions(activity, PERMISSIONS, PERMISSION_ALL);
        }
    }

    public void updateCurrentPlace(Context context ) {

        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
            updateCurrentPlaceWithPermissions(context);
        }
        else {
            //  ActivityCompat.requestPermissions(activity, PERMISSIONS, PERMISSION_ALL);
        }
    }

    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE})
    public void updateCurrentPlaceWithPermissions(Context context) {
        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
            locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(10 * 1000);

            locationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    if (locationResult == null) {
                        return;
                    }
                    for (Location location : locationResult.getLocations()) {
                        if (location != null) {
                            Log.d("Periodic Location:", "updateCurrentPlace: "
                                    +location.getLatitude() + "\n"
                                    + location.getLongitude() + "\n" );

                            WritableMap params = Arguments.createMap();
                            params.putString("PeriodicLocationUpdates", "PeriodicLocationUpdates");
                            params.putString("latitude", Double.toString(location.getLatitude()));
                            params.putString("longitude", Double.toString(location.getLongitude()));
                            params.putString("altitude", Double.toString(location.getAltitude()));
                            params.putString("accuracy", Double.toString(location.getAccuracy()));
                            params.putString("heading", Double.toString(location.getBearing()));
                            params.putString("speed", Double.toString(location.getSpeed()));
                            params.putDouble("timestamp",  location.getTime() );
                            com.mims.uploader.UploaderModule.sendEvent3("progress", params);

                        }
                    }
                }
            };
            //mFusedLocationClient.removeLocationUpdates(locationCallback);
           // mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        }
    }


    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE})
    public void findCurrentPlaceWithPermissions(Context context) {
        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
//            Task<Location> currentPlaceTask =
//                    mFusedLocationClient.getLastLocation();
//            currentPlaceTask.addOnCompleteListener( task -> {
//                if (task.isSuccessful()) {
//                    places.clear();
//                    Location response = task.getResult();
//                    assert response != null;
//
//                    Log.d(TAG, "findCurrentPlace: "
//                            +response.getLatitude() + "\n"
//                            + response.getLongitude() + "\n" );
//                    WritableMap params = Arguments.createMap();
//                    params.putString("currentLocation", "Locationevery15minit");
//                    params.putString("latitude", Double.toString(response.getLatitude()));
//                    params.putString("longitude", Double.toString(response.getLongitude()));
//                    params.putString("altitude", Double.toString(response.getAltitude()));
//                    params.putString("accuracy", Double.toString(response.getAccuracy()));
//                    params.putString("heading", Double.toString(response.getBearing()));
//                    params.putString("speed", Double.toString(response.getSpeed()));
//                    params.putDouble("timestamp",  response.getTime() );
//                   params.putBoolean("geoCheck",  this.geoFencingCheck(geoCheckData,response.getLatitude(),response.getLongitude()));
//                    Log.d("geoCheck1", "findCurrentPlaceWithPermissions: "+geoCheckData);
//                    params.putString("deviceId", Build.BOARD);
//                    if (reactContextMain != null)
//                    params.putString("uniqueId",  Settings.Secure.getString(reactContextMain.getContentResolver(), Settings.Secure.ANDROID_ID));
//                    params.putString("serialNumber",  Build.SERIAL);
//
//                    if (reactContextMain != null &&
//                            (reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED ||
//                                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) ||
//                                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED))) {
//                        TelephonyManager telMgr = (TelephonyManager) reactContextMain.getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
//                        params.putString("phoneNumber", telMgr.getLine1Number());
//                    } else {
//                        params.putString("phoneNumber", null);
//                    }
//                    params.putString("systemName",  "Android");
//                    params.putString("systemVersion",Build.VERSION.RELEASE);
//                    params.putString("carrier",  this.getCarrier());
//                    params.putString("batteryLevel",   Double.toString(this.getBatteryLevel()));
//                    params.putString("GeofencingCheck",   Double.toString(this.getBatteryLevel()));
//                    params.putString("ipAddress",   this.getIpAddress() );
//                    com.mims.uploader.UploaderModule.sendEvent3("progress", params);
//                } else {
//                    Exception exception = task.getException();
//                    if (exception instanceof ApiException) {
//                        ApiException apiException = (ApiException) exception;
//                        Log.e(TAG, "findCurrentPlaceWithPermissions: " + apiException.getStatusCode() + apiException.getLocalizedMessage());
//                    }
//                }
//            });
      }
    }

    public String getCarrier() {
        if (reactContextMain != null) {
            TelephonyManager telMgr = (TelephonyManager) reactContextMain.getSystemService(Context.TELEPHONY_SERVICE);
            return telMgr.getNetworkOperatorName();
        }
        return "";
    }

    public float getBatteryLevel( ) {
        if (reactContextMain != null) {
            Intent batteryIntent = reactContextMain.getApplicationContext().registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            float batteryLevel = level / (float) scale;
            return batteryLevel;
        }
        else
            return 0;
    }


    public boolean geoFencingCheck(String polygonJson, Double latitude, Double longitude){
        JSONObject polygons;
        Log.d("geoFencingCheck", "geoFencingCheck: "+polygonJson);
        boolean contains=false;
        try {
            if(1==2) {
                Geometry currentLocationGeometry = new Point(longitude, latitude, SpatialReferences.getWgs84());

                polygons = new JSONObject(polygonJson);

                JSONArray polygonsJSONArray = polygons.getJSONArray("polygons");
                for (int i = 0; i < polygonsJSONArray.length(); i++) {
                    JSONObject polygon = polygonsJSONArray.getJSONObject(i);

                    JSONArray pointsJSONArray = polygon.getJSONArray("coords");
                    PointCollection polygonPoints = new PointCollection(SpatialReferences.getWgs84());
                    for (int j = 0; j < pointsJSONArray.length(); j++) {

                        JSONObject coords = pointsJSONArray.getJSONObject(j);
                        Double latitude1 = coords.getDouble("latitude");
                        Double longitude1 = coords.getDouble("longitude");
                        polygonPoints.add(new com.esri.arcgisruntime.geometry.Point(longitude1, latitude1));


                    }
                    Polygon shape = new Polygon(polygonPoints);

                    contains = (GeometryEngine.contains(shape, currentLocationGeometry) || GeometryEngine.touches(shape, currentLocationGeometry));
            //                boolean crosses =GeometryEngine.crosses(shape,currentLocationGeometry);
            //                boolean intersects=	GeometryEngine.intersects(shape,currentLocationGeometry);
            //                boolean overlap=	GeometryEngine.overlaps(shape,currentLocationGeometry);
            //                boolean touches=GeometryEngine.touches(shape,currentLocationGeometry);


                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return  contains ;
    }

    public String getIpAddress() {
        WifiInfo winfo = getWifiInfo();
        if(winfo != null) {
            String ipAddress = Formatter.formatIpAddress(getWifiInfo().getIpAddress());
           // DeviceIpAddress;
            //DeviceEventTime;
            return ipAddress;
        }
        return  "";
    }


    private WifiInfo getWifiInfo() {
        if (this.wifiInfo == null) {
            if (reactContextMain != null) {
                WifiManager manager = (WifiManager) reactContextMain.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                this.wifiInfo = manager.getConnectionInfo();
            }
        }
        return this.wifiInfo;
    }
}


