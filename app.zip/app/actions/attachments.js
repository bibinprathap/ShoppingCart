export const ATTACHMENT_ADD_IMAGE = 'ATTACHMENT_ADD_IMAGE';
export const ATTACHMENT_ADD_AUDIO = 'ATTACHMENT_ADD_AUDIO';
export const ATTACHMENT_ADD_VIDEO = 'ATTACHMENT_ADD_VIDEO';
export const ATTACHMENT_ADD_PDF = 'ATTACHMENT_ADD_PDF';
export const ATTACHMENTS_UNLOAD_ALL = 'ATTACHMENTS_UNLOAD_ALL';
export const ATTACHMENT_REMOVE_IMAGE = 'ATTACHMENT_REMOVE_IMAGE';
export const ATTACHMENT_STARTED_UPLOADING = 'ATTACHMENT_STARTED_UPLOADING';
export const ATTACHMENT_STARTED_UPLOADED = 'ATTACHMENT_STARTED_UPLOADED';
export const ATTACHMENT_UPLOAD_ERROR = 'ATTACHMENT_UPLOAD_ERROR';

export const unloadAllAttachments = () => ({
    type: ATTACHMENTS_UNLOAD_ALL,
});

export const addImageAttachment = contents => async dispatch =>
    dispatch({
        type: ATTACHMENT_ADD_IMAGE,
        payload: contents,
    });

export const uploadingImageAttachment = contents => async dispatch =>
    dispatch({
        type: ATTACHMENT_STARTED_UPLOADING,
        payload: contents,
    });
export const uploadedImageAttachment = contents => async dispatch =>
    dispatch({
        type: ATTACHMENT_STARTED_UPLOADED,
        payload: contents,
    });

export const uploadErrorImageAttachment = contents => async dispatch =>
    dispatch({
        type: ATTACHMENT_UPLOAD_ERROR,
        payload: contents,
    });

export const removeImageAttachment = contents => ({
    type: ATTACHMENT_REMOVE_IMAGE,
    payload: contents,
});

export const addAudioAttachment = contents => ({
    type: ATTACHMENT_ADD_AUDIO,
    payload: contents,
});

export const addVideoAttachment = contents => ({
    type: ATTACHMENT_ADD_VIDEO,
    payload: contents,
});

export const addPDFAttachment = contents => ({
    type: ATTACHMENT_ADD_PDF,
    payload: contents,
});
