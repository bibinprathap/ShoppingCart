import alertsHelper from 'app/api/helperServices/alerts';
import createError from 'app/api/helperServices/errors';
import AppApi from 'app/api/real';
import { clearFCMInstance, fcmInitialize } from 'app/actions/notifications';

export const AUTH_BEGIN = 'AUTH_BEGIN';
export const AUTH_FAILURE = 'AUTH_FAILURE';
export const AUTH_SUCESS = 'AUTH_SUCESS';
export const AUTH_LOGOUT = 'AUTH_LOGOUT';

const api = new AppApi();

export const authBegin = (loginType, remember, username, password) => {
    return async dispatch => {
        api.dispatch = dispatch;
        dispatch({
            type: AUTH_BEGIN,
            loginType,
            remember,
        });
        if (loginType == 'smartPass') {
            try {
                let { tokenData, userData } = await api.smartPassSso();
                if (!tokenData) throw 'Error in smartpass login. TokenData not found';
                if (!userData) throw 'Error in smartpass login. UserData not found';
                if (tokenData.error) throw tokenData;
                if (userData.error) throw userData;
                const authCode = await api.smartHubSso(tokenData, userData);
                if (!authCode) throw 'Error in smartpass login. AuthCode not found.';
                const profiles = await api.getPofiles(authCode);
                if (!profiles || (profiles && profiles.length == 0)) throw 'No active Mims Profile';
                dispatch(authSuccess({ tokenData, userData, authCode, profiles }));
            } catch (error) {
                dispatch(authFailure(error));
            }
        } else if (loginType == 'basic') {
            try {
                let authCode = await api.basicLogin(username, password);
                if (!authCode) throw 'Error in basic login. AuthCode not found.';
                let profiles = await api.getPofiles(authCode);
                if (!profiles || (profiles && profiles.length == 0)) throw 'No active Mims Profile';
                dispatch(authSuccess({ authCode, profiles }));
            } catch (error) {
                dispatch(authFailure(error));
            }
        } else if (loginType == 'admin') {
            try {
                let { tokenData, userData, authCode, profiles } = await api.adminLogin(username, password);
                dispatch(authSuccess({ tokenData, userData, authCode, profiles }));
            } catch (x) {
                dispatch(authFailure(error));
            }
        }
    };
};

export const authSuccess = data => {
    return async dispatch => {
        dispatch({ type: AUTH_SUCESS, data });
        dispatch(fcmInitialize());
    };
};

export const authFailure = error => {
    if (!error.handled) alertsHelper.show('error', error.message, error.detail);
    return {
        type: AUTH_FAILURE,
        error,
    };
};

export const authLogout = () => async (dispatch, getState) => {
    const state = getState();
    //  console.log('logout method');
    //console.log('state logOut' + JSON.stringify(state.auth.tokenData));

    try {
        await api.smartPassLogout(state.auth.tokenData.id_token, state.auth.tokenData.access_token);

        // Delete firebase instance and clear notification tray
        dispatch(clearFCMInstance());
    } catch (error) {
        console.log('authLogout ' + error);
        throw error;
    }

    dispatch({
        type: AUTH_LOGOUT,
    });
};
