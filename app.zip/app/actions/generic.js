import AppApi from 'app/api/real';

export const CHART_SUCCESS = 'CHART_SUCCESS';
export const CHART_FAILURE = 'CHART_FAILURE';

export const SET_FORM_FIELD_LOADER = 'SET_FORM_FIELD_LOADER';

const api = new AppApi();

export const chartSearch = (chartId, PrevchartData) => {
    return async dispatch => {
        try {
            /*
            const lastUpdatedDate = getfromstore
            if lastUpdatedDate <= 2 hours
                
                dispatch(chartSuccess(chartResult));
            else
            */

            const chartResult = await api.getDashboardCharts(chartId, PrevchartData);
            dispatch(chartSuccess(chartResult, chartId));
            /*
            end if
            */

            //    this.setState({ loading: false, dashboardChartsData: result, count: result.length });
        } catch (err) {
            //this.setState({ loading: false, error: err });
            dispatch(chartFailure);
        }
    };
};

export const chartSuccess = (results, chartId) => ({
    type: CHART_SUCCESS,
    chartId: chartId,
    results,
});

export const chartFailure = () => ({
    type: CHART_FAILURE,
});

export const setFormFieldLoader = (formName, fieldName, isLoading) => ({
    type: SET_FORM_FIELD_LOADER,
    formName,
    fieldName,
    isLoading,
});
