import AppApi from 'app/api/real';
import { lookup } from 'app/api/helperServices';

export const GET_CHART_SUCCESS = 'GET_CHART_SUCCESS';
export const GET_CHART_FAILURE = 'GET_CHART_FAILURE';
export const GET_LIST = 'GET_LIST';
export const GET_LIST_SUCCESS = 'GET_LIST_SUCCESS';
export const GET_LIST_FAILURE = 'GET_LIST_FAILURE';
export const RESET_LISTS = 'RESET_LISTS';

const api = new AppApi();

export const getchartData = (lastRefresh, chartId, PrevchartData) => {
    return async dispatch => {
        try {
            const chartResult = await api.getDashboardCharts(chartId, PrevchartData);
            dispatch(chartSuccess(lastRefresh, chartResult, chartId));
        } catch (err) {
            //this.setState({ loading: false, error: err });
            dispatch(chartFailure);
        }
    };
};

export const chartSuccess = (lastRefresh, results, chartId) => ({
    type: GET_CHART_SUCCESS,
    chartId: GET_CHART_FAILURE,
    lastRefresh: lastRefresh,
    results,
});

export const chartFailure = () => ({
    type: CHART_FAILURE,
});

export const resetLists = params => ({
    type: RESET_LISTS,
    params,
});

export const getList = params => async dispatch => {
    try {
        const data = lookup.getList(params.fieldName, params.parentId);
        dispatch({
            type: GET_LIST,
            params,
        });

        dispatch(getListSuccess({ ...params, data: data || [] }));
    } catch (e) {
        dispatch(getListFailure({ ...params, data: [] }));
    }
};

export const getListSuccess = params => ({
    type: GET_LIST_SUCCESS,
    params,
});

export const getListFailure = params => ({
    type: GET_LIST_FAILURE,
    params,
});
