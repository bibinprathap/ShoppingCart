import AppApi from 'app/api/real';

export const CHART_SUCCESS = 'CHART_SUCCESS';
export const CHART_FAILURE = 'CHART_FAILURE';

const api = new AppApi();

export const chartSearch = () => {
    debugger;
    return async dispatch => {
        try {
            const chartResult = await api.getDashboardCharts();
            dispatch(chartSuccess(chartResult));
            //    this.setState({ loading: false, dashboardChartsData: result, count: result.length });
        } catch (err) {
            //this.setState({ loading: false, error: err });
            dispatch(chartFailure);
        }
    };
};

export const chartSuccess = results => ({
    type: CHART_SUCCESS,
    results,
});

export const chartFailure = () => ({
    type: CHART_FAILURE,
});
