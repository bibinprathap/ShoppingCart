import AppApi from 'app/api/real';

export const INSPECTIONDIALOG_SHOW = 'INSPECTIONDIALOG_SHOW';
export const INSPECTIONDIALOG_HIDE = 'INSPECTIONDIALOG_HIDE';
export const INSPECTIONDIALOG_PENDINGTABRELOAD = 'INSPECTIONDIALOG_PENDINGTABRELOAD';
export const INSPECTIONDIALOG_NOPENDINGTABRELOAD = 'INSPECTIONDIALOG_NOPENDINGTABRELOAD';

const api = new AppApi();

export const showInspectionDialog = ({ refNumber, inspection, title }) => {
    return async dispatch => {
        dispatch({
            type: INSPECTIONDIALOG_SHOW,
            payload: {
                refNumber,
                inspection,
                title,
            },
        });
    };
};

export const hideInspectionDialog = payload => {
    return async dispatch => {
        dispatch({ type: INSPECTIONDIALOG_HIDE });
    };
};
export const inspectionDialogPendingTabReload = payload => {
    return async dispatch => {
        dispatch({ type: INSPECTIONDIALOG_PENDINGTABRELOAD });
    };
};
export const inspectionDialogNoPendingTabReload = payload => {
    return async dispatch => {
        dispatch({ type: INSPECTIONDIALOG_NOPENDINGTABRELOAD });
    };
};
