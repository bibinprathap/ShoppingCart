import AppApi from 'app/api/real';
import { inspectionsHelper } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { strings } from 'app/config/i18n/i18n';
import firebase from 'app/api/helperServices/rnFirebaseNative';
import { store } from 'app/config/store';
import { getLocation } from 'app/api/helperServices/geolocation';
import { getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { setLoading, setLoaded } from 'app/actions/loader';

//export const INSPECTION_CREATENEW = 'INSPECTION_CREATENEW';
export const INSPECTION_SAVENEW = 'INSPECTION_SAVENEW';
export const INSPECTION_UPDATE = 'INSPECTION_UPDATE';
export const INSPECTION_SAVE_SUCESS = 'INSPECTION_SAVE_SUCESS';
export const INSPECTION_CANCEL_SUCESS = 'INSPECTION_CANCEL_SUCESS';
export const INSPECTION_LOCAL_SAVE_SUCCESS = 'INSPECTION_LOCAL_SAVE_SUCCESS';
// export const INSPECTION_FOLLOWUP_SUCESS = 'INSPECTION_FOLLOWUP_SUCESS';
export const INSPECTION_FOLLOWUP_LOCAL_SUCCESS = 'INSPECTION_FOLLOWUP_LOCAL_SUCCESS';
export const INSPECTION_SAVE_FAILURE = 'INSPECTION_SAVE_FAILURE';
export const INSPECTION_CANCEL_FAILURE = 'INSPECTION_CANCEL_FAILURE';
export const INSPECTION_FOLLOWUP_FAILURE = 'INSPECTION_FOLLOWUP_FAILURE';
export const INSPECTION_SELECT = 'INSPECTION_SELECT';
//export const INSPECTION_SELECT_SUCCESS = 'INSPECTION_SELECT_SUCCESS';
export const INSPECTION_COORDSCHANGED = 'INSPECTION_COORDSCHANGED';
export const INSPECTION_ADDRESSCHANGED = 'INSPECTION_ADDRESSCHANGED';
export const INSPECTION_SELECTSERVICE = 'INSPECTION_SELECTSERVICE';
export const INSPECTION_VALUECHANGED = 'INSPECTION_VALUECHANGED';
export const INSPECTION_ADDEDNEWVIOLATOR = 'INSPECTION_ADDEDNEWVIOLATOR';
export const INSPECTION_ADDNEWLOG = 'INSPECTION_ADDNEWLOG';
export const INSPECTION_ADD_VIOLATOR = 'INSPECTION_ADD_VIOLATOR';
export const INSPECTION_ADD_BUSINESSENTITYTOCHECKITEM = 'INSPECTION_ADD_BUSINESSENTITYTOCHECKITEM';
export const INSPECTION_REMOVE_BUSINESSENTITYFROMCHECKITEM = 'INSPECTION_REMOVE_BUSINESSENTITYFROMCHECKITEM';
export const INSPECTION_UPDATEVIOLATIONS = 'INSPECTION_UPDATEVIOLATIONS';
export const INSPECTION_REMOVEVIOLATOR = 'INSPECTION_REMOVEVIOLATOR';
export const INSPECTION_INFOCHANGED = 'INSPECTION_INFOCHANGED';
export const INSPECTION_INFOVIOLATORCHANGED = 'INSPECTION_INFOVIOLATORCHANGED';
export const INSPECTION_INFOVIOLATORVIOLATIONSCHANGED = 'INSPECTION_INFOVIOLATORVIOLATIONSCHANGED';
export const INSPECTION_CLEARHISTORY = 'INSPECTION_CLEARHISTORY';
export const INSPECTION_DUPCHK_START = 'INSPECTION_DUPCHK_START';
export const INSPECTION_DUPCHK_SUCCESS = 'INSPECTION_DUPCHK_SUCCESS';
export const INSPECTION_DUPCHK_FAILURE = 'INSPECTION_DUPCHK_FAILURE';
export const INSPECTION_DUPLICATE_DETAILS_SUCCESS = 'INSPECTION_DUPLICATE_DETAILS_SUCCESS';
export const INSPECTION_DUPLICATE_DETAILS_FAILURE = 'INSPECTION_DUPLICATE_DETAILS_FAILURE';
export const INSPECTION_RECORDCREATE_START = 'INSPECTION_RECORDCREATE_START';
export const INSPECTION_RECORDCREATE_SUCCESS = 'INSPECTION_RECORDCREATE_SUCCESS';
export const INSPECTION_RECORDCREATE_FAILURE = 'INSPECTION_RECORDCREATE_FAILURE';
export const INSPECTION_SET_DUPLICATE = 'INSPECTION_SET_DUPLICATE';
export const INSPECTION_ADD_VIOLATIOR_SIGNATURE = 'INSPECTION_ADD_VIOLATIOR_SIGNATURE';
export const INSPECTION_REMOVE_VIOLATIOR_SIGNATURE = 'INSPECTION_REMOVE_VIOLATIOR_SIGNATURE';
export const INSPECTION_CHECKLIST_SET_DUPLICATE = 'INSPECTION_CHECKLIST_SET_DUPLICATE';
export const TASK_STARTED = 'TASK_STARTED';
export const INSPECTION_ADD_NEXT_VISIT = 'INSPECTION_ADD_NEXT_VISIT';
export const ADD_VISIT_LOCATION = 'ADD_VISIT_LOCATION';
export const GET_VIOLATION_ACTION_TYPES = 'GET_VIOLATION_ACTION_TYPES';
export const GET_VIOLATION_ACTION_TYPES_STARTED = 'GET_VIOLATION_ACTION_TYPES_STARTED';
export const GET_VIOLATION_ACTION_TYPES_SUCCESS = 'GET_VIOLATION_ACTION_TYPES_SUCCESS';
export const GET_VIOLATION_ACTION_TYPES_FAILED = 'GET_VIOLATION_ACTION_TYPES_FAILED';

export const GET_ACTION_TYPES = 'GET_ACTION_TYPES';
export const GET_ACTION_TYPES_SUCCESS = 'GET_ACTION_TYPES_SUCCESS';
export const GET_ACTION_TYPES_FAILED = 'GET_ACTION_TYPES_FAILED';

export const UPDATE_VIOLATION = 'UPDATE_VIOLATION';

const api = new AppApi();

// export const createNewInspection = selectedEntity => {
//     return async dispatch => {
//         const inspectionTypeDetail = { entityConst: selectedEntity };
//         const newInspection = inspectionsHelper.createNew(inspectionTypeDetail);
//         dispatch({
//             type: INSPECTION_CREATENEW,
//             payload: newInspection,
//         });
//         dispatch({
//             type: INSPECTION_SELECT,
//             payload: newInspection.refNumber,
//         });
//     };
// };

// export const createNewInspectionFromTask = payload => async dispatch =>
//     dispatch({
//         type: INSPECTION_CREATENEW,
//         payload: payload,
//     });

export const getInspectionDetails = ({
    workflowConst,
    workflowInstanceId,
    applicationNumber,
    isShallow,
    inspectionTypeId,
    isChecklist,
    currentVisitIndex,
    inspTypeCheckItemId,
    workflowApplicationNumber,
    taskId,
}) => {
    return async dispatch => {
        api.dispatch = dispatch;
        try {
            const data = await api.getInspectionDetails({
                workflowConst,
                workflowInstanceId,
                applicationNumber,
                isShallow,
                inspectionTypeId,
                taskId,
                workflowApplicationNumber,
            });
            dispatch({
                type: INSPECTION_DUPLICATE_DETAILS_SUCCESS,
                payload: {
                    refNumber: data.inspectionId,
                    data: data,
                    isChecklist,
                    currentVisitIndex,
                    inspTypeCheckItemId,
                },
            });
        } catch (error) {
            dispatch({
                type: INSPECTION_DUPLICATE_DETAILS_FAILURE,
                payload: { refNumber: applicationNumber, isChecklist, error },
            });
            dispatch(setLoaded());
            alertsHelper.show('error', strings('failedToLoadInspectionDetails'), getErrorMessageWithDetail(error));
            throw error;
        }
    };
};

export const checkDuplicate = (state, payload, actionName) => {
    return async dispatch => {
        const { canCheckDuplicate, reason, refNumber } = inspectionsHelper.canCheckDuplicate(state, payload, actionName);

        if (canCheckDuplicate) {
            // const refNumber = state.currentInspectionRef;
            api.dispatch = dispatch;
            //animation making the review screen very slow
            // dispatch({
            //     type: INSPECTION_DUPCHK_START,
            //     payload: { refNumber },
            // });
            try {
                const duplicateCheckRequestModel = inspectionsHelper.getDuplicateCheckRequestModel(state, payload, refNumber);
                const data = await api.checkDuplicate(duplicateCheckRequestModel);

                const duplicates = data || [];
                if (duplicates.length > 0) {
                    // alertsHelper.show(
                    //     'warn',
                    //     'Possible Duplicates',
                    //     `There are ${duplicates.length} possible duplicates of the current/ new inspection being created.`
                    // );
                }
                dispatch({
                    type: INSPECTION_DUPCHK_SUCCESS,
                    payload: { refNumber, data: { duplicateCandidates: data } },
                });
            } catch (error) {
                dispatch({
                    type: INSPECTION_DUPCHK_FAILURE,
                    payload: { refNumber, error },
                });
                // if (!error.isCancel) {
                //     alertsHelper.show('error', 'Duplicate check failed', error.detail);
                // }
            }
        } else {
            if (reason) {
            }
        }
    };
};

export const createInspectionRecordSuccess = (createdInspection, payload) => {
    return async dispatch => {
        const { refNumber } = createdInspection;
        let applicationNumber = inspectionsHelper.getApplicationNumber(createdInspection);
        return new Promise.resolve(
            dispatch({
                type: INSPECTION_RECORDCREATE_SUCCESS,
                payload: { applicationNumber, createdInspection, refNumber },
            })
        ).then(() => dispatch(addVisitLocation({ visitIndex: payload.visitIndex, applicationNumber })));
    };
};

export const createInspectionRecordFailure = payload => {
    return async dispatch => {
        dispatch({
            type: INSPECTION_RECORDCREATE_FAILURE,
            payload: { refNumber: payload.refNumber, error: payload.error },
        });
    };
};

export const saveNewInspection = (params, showAlert, navigation, setnewInspection) => {
    return async dispatch => {
        api.dispatch = dispatch;
        try {
            /*
                Todo: get rid of inspectionUpdate action, instead dispatch INSPECTION_SAVE_START, INSPECTION_SAVE_SUCESS and INSPECTION_SAVE_FAILURE
                and only include the inspection reference in the payload. the reducer should take care of what properties to set
                it is not the job of action creator to tell reducer what properties to set, rather it should only signal, what happend
            */
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: true }));
            let data = await api.createInspection(inspectionsHelper.getStartAndConfirmInspectionRequestModel(params));
            data = inspectionsHelper.getMimsInspectionModelFromResponse(data);

            const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(data);
            data.visits[currentVisitIndex].locallySaved = true;

            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));

            //Todo :use alertprovider
            if (showAlert) alertsHelper.show('success', 'Saved', 'Inspection Submitted Successfully', true);
            if (navigation) navigation.navigate('dashboard');
            //response.data.result
            dispatch(saveinspectionSuccess(data));
            if (setnewInspection) setnewInspection(data);
        } catch (error) {
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));

            dispatch(saveinspectionFailure(error));
            throw error;
        }
    };
};
export const cancelInspection = (params, navigation, setnewInspection) => {
    return async dispatch => {
        api.dispatch = dispatch;
        try {
            /*
                Todo: get rid of inspectionUpdate action, instead dispatch INSPECTION_SAVE_START, INSPECTION_SAVE_SUCESS and INSPECTION_SAVE_FAILURE
                and only include the inspection reference in the payload. the reducer should take care of what properties to set
                it is not the job of action creator to tell reducer what properties to set, rather it should only signal, what happend
            */
            dispatch(inspectionUpdate({ prop: 'cancelingFlag', value: true }));
            let data = await api.cancelInspection(params);
            const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(data);
            data.visits[currentVisitIndex].locallySaved = true;

            dispatch(inspectionUpdate({ prop: 'cancelingFlag', value: false }));

            //Todo :use alertprovider
            alertsHelper.show('success', 'Cancelled', 'Inspection cancelled Successfully', true);
            if (navigation) navigation.navigate('dashboard');
            //response.data.result
            dispatch(cancelinspectionSuccess(data));
            if (setnewInspection) setnewInspection(data);
        } catch (error) {
            dispatch(inspectionUpdate({ prop: 'cancelingFlag', value: false }));
            dispatch(cancelinspectionFailure(error));
            throw error;
        }
    };
};

export const setDuplicate = duplicateOption => ({
    type: INSPECTION_SET_DUPLICATE,
    payload: duplicateOption,
});
export const setCheckListDuplicate = duplicateOption => ({
    type: INSPECTION_CHECKLIST_SET_DUPLICATE,
    payload: duplicateOption,
});

export const saveinspectionSuccess = data => ({
    type: INSPECTION_SAVE_SUCESS,
    data,
});
export const cancelinspectionSuccess = data => ({
    type: INSPECTION_CANCEL_SUCESS,
    data,
});
export const saveinspectionLocalSuccess = data => ({
    type: INSPECTION_LOCAL_SAVE_SUCCESS,
    data,
});

// export const savefollowupSuccess = data => ({
//     type: INSPECTION_FOLLOWUP_SUCESS,
//     data,
// });
export const savefollowupLocalSuccess = data => ({
    type: INSPECTION_FOLLOWUP_LOCAL_SUCCESS,
    data,
});

export const addNextVisit = data => ({
    type: INSPECTION_ADD_NEXT_VISIT,
    data,
});

export const saveinspectionFailure = error => ({
    type: INSPECTION_SAVE_FAILURE,
    error,
});
export const cancelinspectionFailure = error => ({
    type: INSPECTION_CANCEL_FAILURE,
    error,
});
export const savefollowupFailure = error => ({
    type: INSPECTION_FOLLOWUP_FAILURE,
    error,
});

export const inspectionUpdate = ({ prop, value }) => ({
    type: INSPECTION_UPDATE,
    payload: { prop, value },
});
export const coordsChanged = coords => async (dispatch, getState) => {
    dispatch({
        type: INSPECTION_COORDSCHANGED,
        payload: coords,
    });
    try {
        const address = await api.getAddress(coords);
        dispatch({
            type: INSPECTION_ADDRESSCHANGED,
            payload: address,
        });
        const state = getState().inspections;
        dispatch(checkDuplicate(state, address, 'addressChanged'));
        return { coords, address };
    } catch (error) {}
};

// export const selectInspection = refNumber => ({
//     type: INSPECTION_SELECT,
//     payload: refNumber,
// });

export const selectInspection = inspectionContainer => async dispatch => {
    return dispatch({
        type: INSPECTION_SELECT,
        payload: inspectionContainer,
    });
};

export const selectService = payload => async (dispatch, getState) => {
    return dispatch({
        type: INSPECTION_SELECTSERVICE,
        payload,
    });
};

export const valueChanged = payload => async dispatch =>
    dispatch({
        type: INSPECTION_VALUECHANGED,
        payload,
    });

export const inspectionViolatorAdded = payload => async dispatch =>
    dispatch({
        type: INSPECTION_ADDEDNEWVIOLATOR,
        payload,
    });
export const inspectionAddLogs = log => async dispatch =>
    dispatch({
        type: INSPECTION_ADDNEWLOG,
        payload: { log },
    });
export const inspectionViolationsupdated = (violations, violatorindex) => async dispatch =>
    dispatch({
        type: INSPECTION_UPDATEVIOLATIONS,
        payload: { violations, violatorindex },
    });

export const addViolatorToViolation = payload => async dispatch =>
    dispatch({
        type: INSPECTION_ADD_VIOLATOR,
        payload,
    });
export const addBusinessEntityTocheckItems = payload => async dispatch =>
    dispatch({
        type: INSPECTION_ADD_BUSINESSENTITYTOCHECKITEM,
        payload,
    });
export const removeBusinessEntityFromcheckItems = payload => async dispatch =>
    dispatch({
        type: INSPECTION_REMOVE_BUSINESSENTITYFROMCHECKITEM,
        payload,
    });

export const inspectionRemoveViolator = payload => async dispatch =>
    dispatch({
        type: INSPECTION_REMOVEVIOLATOR,
        payload,
    });

export const infoChanged = (key, value, visit) => async dispatch =>
    dispatch({
        type: INSPECTION_INFOCHANGED,
        payload: { key, value, visit },
    });

export const infoViolatorChanged = payload => async dispatch =>
    dispatch({
        type: INSPECTION_INFOVIOLATORCHANGED,
        payload,
    });

export const clearHistory = () => ({
    type: INSPECTION_CLEARHISTORY,
});

export const addViolatorSignature = payload => ({
    type: INSPECTION_ADD_VIOLATIOR_SIGNATURE,
    payload,
});

export const removeViolatorSignature = payload => ({
    type: INSPECTION_REMOVE_VIOLATIOR_SIGNATURE,
    payload,
});

export const addVisitLocation = payload => async (dispatch, getState) => {
    const state = getState();
    let location = payload.visitLocation;
    if (location === undefined) {
        let coords = state.tracking && state.tracking.lastEvent && state.tracking.lastEvent.location;
        let address = undefined;
        if (coords === undefined) {
            try {
                coords = await getLocation();
            } catch (error) {
                throw `Error in addVisitLocation. Failed to get coords from device. ${getErrorMessageWithDetail(error)}`;
            }
        }
        try {
            address = await api.getAddress(coords);
        } catch (error) {
            throw `Error in addVisitLocation. Failed to get address. ${getErrorMessageWithDetail(error)}`;
        }
        location = { coords, address };
    }
    return dispatch({
        type: ADD_VISIT_LOCATION,
        payload: { ...payload, visitLocation: location },
    });
};

export const getViolationActionTypes = payload => {
    return async dispatch => {
        api.dispatch = dispatch;
        dispatch({
            type: GET_VIOLATION_ACTION_TYPES_STARTED,
            payload,
        });
        try {
            const data = await api.getViolationActionTypes({
                workflowConst: payload.workflowConst,
                inspTypeCheckItemId: payload.inspTypeCheckItemId,
                inspViolationTypeId: payload.inspViolationTypeId,
                inspInstanceId: payload.inspInstanceId,
                violatorId: payload.violator.violatorId,
                violatorType: payload.violator.violatorType,
                location: payload.location,
            });
            dispatch({
                type: GET_VIOLATION_ACTION_TYPES_SUCCESS,
                payload,
                data,
            });
        } catch (error) {
            dispatch({
                type: GET_VIOLATION_ACTION_TYPES_FAILED,
                payload,
            });
        }
    };
};

export const getActionTypes = payload => {
    return async dispatch => {
        api.dispatch = dispatch;
        dispatch({
            type: GET_ACTION_TYPES,
            payload,
        });

        try {
            const data = await api.getActionTypes({
                workflowConst: payload.workflowConst,
                inspInstanceId: payload.inspInstanceId,
                violatorId: payload.violatorId,
                violatorType: payload.violatorType,
                permitNumber: payload.permitNumber,
                followsTermsOfContract: payload.followsTermsOfContract,
                location: payload.location,
            });
            dispatch({
                type: GET_ACTION_TYPES_SUCCESS,
                payload,
                data,
            });
        } catch (error) {
            dispatch({
                type: GET_ACTION_TYPES_FAILED,
                payload,
            });
        }
    };
};

export const updateViolation = (params, visitIndex, inspTypeCheckItemId, reset) => async dispatch =>
    dispatch({
        type: UPDATE_VIOLATION,
        payload: { params, visitIndex, inspTypeCheckItemId, reset },
    });
