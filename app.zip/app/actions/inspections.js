import AppApi from 'app/api/real';
import { inspectionsHelper } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import firebase from 'app/api/helperServices/rnFirebaseNative';

export const INSPECTION_CREATENEW = 'INSPECTION_CREATENEW';
export const INSPECTION_SAVENEW = 'INSPECTION_SAVENEW';
export const INSPECTION_UPDATE = 'INSPECTION_UPDATE';
export const INSPECTION_SAVE_SUCESS = 'INSPECTION_SAVE_SUCESS';
export const INSPECTION_FOLLOWUP_SUCESS = 'INSPECTION_FOLLOWUP_SUCESS';
export const INSPECTION_SAVE_FAILURE = 'INSPECTION_SAVE_FAILURE';
export const INSPECTION_FOLLOWUP_FAILURE = 'INSPECTION_FOLLOWUP_FAILURE';
export const INSPECTION_SELECT = 'INSPECTION_SELECT';
export const INSPECTION_SELECT_SUCCESS = 'INSPECTION_SELECT_SUCCESS';
export const INSPECTION_COORDSCHANGED = 'INSPECTION_COORDSCHANGED';
export const INSPECTION_ADDRESSCHANGED = 'INSPECTION_ADDRESSCHANGED';
export const INSPECTION_SELECTSERVICE = 'INSPECTION_SELECTSERVICE';
export const INSPECTION_VALUECHANGED = 'INSPECTION_VALUECHANGED';
export const INSPECTION_ADDEDNEWVIOLATOR = 'INSPECTION_ADDEDNEWVIOLATOR';
export const INSPECTION_ADDNEWLOG = 'INSPECTION_ADDNEWLOG';
export const INSPECTION_UPDATEVIOLATIONS = 'INSPECTION_UPDATEVIOLATIONS';
export const INSPECTION_REMOVEVIOLATOR = 'INSPECTION_REMOVEVIOLATOR';
export const INSPECTION_INFOCHANGED = 'INSPECTION_INFOCHANGED';
export const INSPECTION_INFOVIOLATORCHANGED = 'INSPECTION_INFOVIOLATORCHANGED';
export const INSPECTION_INFOVIOLATORVIOLATIONSCHANGED = 'INSPECTION_INFOVIOLATORVIOLATIONSCHANGED';
export const INSPECTION_CLEARHISTORY = 'INSPECTION_CLEARHISTORY';
export const INSPECTION_DUPCHK_START = 'INSPECTION_DUPCHK_START';
export const INSPECTION_DUPCHK_SUCCESS = 'INSPECTION_DUPCHK_SUCCESS';
export const INSPECTION_DUPCHK_FAILURE = 'INSPECTION_DUPCHK_FAILURE';
export const INSPECTION_RECORDCREATE_START = 'INSPECTION_RECORDCREATE_START';
export const INSPECTION_RECORDCREATE_SUCCESS = 'INSPECTION_RECORDCREATE_SUCCESS';
export const INSPECTION_RECORDCREATE_FAILURE = 'INSPECTION_RECORDCREATE_FAILURE';
export const INSPECTION_SET_DUPLICATE = 'INSPECTION_SET_DUPLICATE';
export const INSPECTION_ADD_VIOLATIOR_SIGNATURE = 'INSPECTION_ADD_VIOLATIOR_SIGNATURE';
export const INSPECTION_REMOVE_VIOLATIOR_SIGNATURE = 'INSPECTION_REMOVE_VIOLATIOR_SIGNATURE';
export const INSPECTION_CHECKLIST_SET_DUPLICATE = 'INSPECTION_CHECKLIST_SET_DUPLICATE';
export const TASK_STARTED = 'TASK_STARTED';
export const INSPECTION_ADD_NEXT_VISIT = 'INSPECTION_ADD_NEXT_VISIT';

const api = new AppApi();

export const createNewInspection = () => {
    return async dispatch => {
        const newInspection = inspectionsHelper.createNew();
        dispatch({
            type: INSPECTION_CREATENEW,
            payload: newInspection,
        });
        dispatch({
            type: INSPECTION_SELECT,
            payload: newInspection.refNumber,
        });
    };
};

export const createNewInspectionFromTask = (taskId, selectedService, location) => async dispatch =>
    dispatch({
        type: INSPECTION_CREATENEW,
        payload: inspectionsHelper.createNewFromTask(taskId, selectedService, location),
    });

export const selectServiceFromTask = payload => async dispatch =>
    dispatch({
        type: INSPECTION_SELECTSERVICE,
        payload,
    });

export const checkDuplicate = (state, payload, actionName) => {
    return async dispatch => {
        const { canCheckDuplicate, reason, refNumber } = inspectionsHelper.canCheckDuplicate(state, payload, actionName);
        console.log('inspection.action.checkDuplicate... canCheckDuplicate: ', canCheckDuplicate, 'reason: ', reason);
        if (canCheckDuplicate) {
            // const refNumber = state.currentInspectionRef;
            api.dispatch = dispatch;
            //animation making the review screen very slow
            // dispatch({
            //     type: INSPECTION_DUPCHK_START,
            //     payload: { refNumber },
            // });
            try {
                const duplicateCheckRequestModel = inspectionsHelper.getDuplicateCheckRequestModel(state, payload, refNumber);
                const data = await api.checkDuplicate(duplicateCheckRequestModel);
                //console.log('actions.inspection.checkDuplicate. data = ', data);
                const duplicates = data.duplicates || [];
                if (duplicates.length > 0) {
                    // alertsHelper.show(
                    //     'warn',
                    //     'Possible Duplicates',
                    //     `There are ${duplicates.length} possible duplicates of the current/ new inspection being created.`
                    // );
                }
                dispatch({
                    type: INSPECTION_DUPCHK_SUCCESS,
                    payload: { refNumber, data: { duplicateCantidates: data.duplicates } },
                });
            } catch (error) {
                dispatch({
                    type: INSPECTION_DUPCHK_FAILURE,
                    payload: { refNumber, error },
                });
                // if (!error.isCancel) {
                //     alertsHelper.show('error', 'Duplicate check failed', error.detail);
                // }
            }
        } else {
            if (reason) {
                console.log(reason);
            }
        }
    };
};

export const createInspectionRecord = (inspection, payload) => {
    return async (dispatch, getState) => {
        api.dispatch = dispatch;
        dispatch({
            type: INSPECTION_RECORDCREATE_START,
            payload: { refNumber: inspection.refNumber },
        });
        try {
            debugger;
            const createInspectionRequestModel = inspectionsHelper.getInspectionRequestModel(inspection, payload);

            const data = await api.createInspectionRecord(createInspectionRequestModel);
            const inspectionId = data.inspectionId || '';
            //  if (inspectionId.length > 0) {
            // alertsHelper.show('warn', 'Inspection Record Created', `Record No: ${data.inspectionId}`);
            //}
            dispatch({
                type: INSPECTION_RECORDCREATE_SUCCESS,
                payload: { refNumber: payload.refNumber, inspectionId },
            });
        } catch (error) {
            console.log('createInspectionRecord() error: ', error);
            dispatch({
                type: INSPECTION_RECORDCREATE_FAILURE,
                payload: { refNumber: payload.refNumber, error },
            });
            // if (!error.isCancel) {
            //  alertsHelper.show('error', 'Inspection Record Create failed', error.detail);
            // }
        }
    };
};

export const createInspectionRecordFromTask = (taskId, refNumber) => {
    return async (dispatch, getState) => {
        const state = getState().inspections;
        // const refNumber = state.currentInspectionRef;
        api.dispatch = dispatch;
        dispatch({
            type: INSPECTION_RECORDCREATE_START,
            payload: { refNumber },
        });
        dispatch({
            type: TASK_STARTED,
            payload: { taskId, refNumber, status: 'InProgress' },
        });

        try {
            const createInspectionRequestModel = inspectionsHelper.getInspectionRequestModel(refNumber, taskId);
            const data = await api.createInspectionRecord(createInspectionRequestModel);
            //console.log('actions.inspection.checkDuplicate. data = ', data);
            const inspectionId = data.inspectionId || '';
            //  if (inspectionId.length > 0) {
            // alertsHelper.show('warn', 'Inspection Record Created', `Record No: ${data.inspectionId}`);
            //}
            dispatch({
                type: INSPECTION_RECORDCREATE_SUCCESS,
                payload: { refNumber, inspectionId },
            });
        } catch (error) {
            dispatch({
                type: INSPECTION_RECORDCREATE_FAILURE,
                payload: { refNumber, error },
            });
            // if (!error.isCancel) {
            //  alertsHelper.show('error', 'Inspection Record Create failed', error.detail);
            // }
        }
    };
};

export const saveFollowup = params => {
    return async dispatch => {
        api.dispatch = dispatch;
        try {
            /*
                Todo: get rid of inspectionUpdate action, instead dispatch INSPECTION_SAVE_START, INSPECTION_SAVE_SUCESS and INSPECTION_SAVE_FAILURE
                and only include the inspection reference in the payload. the reducer should take care of what properties to set
                it is not the job of action creator to tell reducer what properties to set, rather it should only signal, what happend
            */
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: true }));
            const data = await api.createFollowup(params);
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));
            // console.log('Submit Inspection success result: ' + JSON.stringify(data));
            //Todo :use alertprovider
            alertsHelper.show('success', 'Saved', 'FollowUp Submitted Successfully');
            //response.data.result
            dispatch(savefollowupSuccess(data));
            //[mock] [in real it will be done by the backend].
            // dispatch(addNextVisit(data));
        } catch (error) {
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));
            console.log('Submit FollowUp error result: ' + JSON.stringify(error));
            dispatch(savefollowupFailure(error));
        }
    };
};

export const saveNewInspection = params => {
    return async dispatch => {
        api.dispatch = dispatch;
        try {
            /*
                Todo: get rid of inspectionUpdate action, instead dispatch INSPECTION_SAVE_START, INSPECTION_SAVE_SUCESS and INSPECTION_SAVE_FAILURE
                and only include the inspection reference in the payload. the reducer should take care of what properties to set
                it is not the job of action creator to tell reducer what properties to set, rather it should only signal, what happend
            */
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: true }));
            const data = await api.createInspection(params);
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));
            // console.log('Submit Inspection success result: ' + JSON.stringify(data));
            //Todo :use alertprovider
            alertsHelper.show('success', 'Saved', 'Inspection Submitted Successfully');
            //response.data.result
            dispatch(saveinspectionSuccess(data));
            //[mock] [in real it will be done by the backend].
            // dispatch(addNextVisit(data));
            //  if (params.info && params.info) {
            const url = `adm://mims/task`;
            let addDays = function(days) {
                var date = new Date();
                date.setDate(date.getDate() + days);
                return date;
            };
            firebase.localNotification({
                title: 'Inspection task scheduled',
                body: `More information required for inpection ` + params.inspectionId,
                url,
                seconds: 5,
                task: JSON.stringify({
                    titleE: 'Followup Task for Inspection ' + params.inspectionId,
                    titleA: 'متابعة المهمة للتفتيش' + params.inspectionId,
                    taskId: 123323414,
                    assignedDate: addDays(0),
                    deadlineFromDate: addDays(2),
                    deadlineToDate: addDays(4),
                    location: params.location,
                    selectedService: params.service,
                    status: 'new',
                    parentRefNo: params.inspectionId,
                    refNumber: params.inspectionId,
                    icon: { type: 'custom', name: 'review' },
                    stepAction: 'followup',
                    assignedToInspectorId: params.createdByDomainCustomerId,
                    priority: 1,
                }),
            });
            // }
        } catch (error) {
            dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));
            console.log('Submit Inspection error result: ' + JSON.stringify(error));
            dispatch(saveinspectionFailure(error));
        }
    };
};

export const setDuplicate = duplicateOption => ({
    type: INSPECTION_SET_DUPLICATE,
    payload: duplicateOption,
});
export const setCheckListDuplicate = duplicateOption => ({
    type: INSPECTION_CHECKLIST_SET_DUPLICATE,
    payload: duplicateOption,
});

export const saveinspectionSuccess = data => ({
    type: INSPECTION_SAVE_SUCESS,
    data,
});

export const savefollowupSuccess = data => ({
    type: INSPECTION_FOLLOWUP_SUCESS,
    data,
});

export const addNextVisit = data => ({
    type: INSPECTION_ADD_NEXT_VISIT,
    data,
});

export const saveinspectionFailure = error => ({
    type: INSPECTION_SAVE_FAILURE,
    error,
});
export const savefollowupFailure = error => ({
    type: INSPECTION_FOLLOWUP_FAILURE,
    error,
});

export const inspectionUpdate = ({ prop, value }) => ({
    type: INSPECTION_UPDATE,
    payload: { prop, value },
});
export const coordsChanged = coords => async (dispatch, getState) => {
    const state = getState().inspections;
    dispatch(checkDuplicate(state, coords, 'coordsChanged'));
    return dispatch({
        type: INSPECTION_COORDSCHANGED,
        payload: coords,
    });
};

export const addressChanged = address => async dispatch =>
    dispatch({
        type: INSPECTION_ADDRESSCHANGED,
        payload: address,
    });

export const selectInspection = refNumber => ({
    type: INSPECTION_SELECT,
    payload: refNumber,
});

export const selectInspectionSuccess = inspection => ({
    type: INSPECTION_SELECT_SUCCESS,
    payload: inspection,
});

export const selectService = payload => async (dispatch, getState) => {
    return dispatch({
        type: INSPECTION_SELECTSERVICE,
        payload,
    });
};

export const valueChanged = payload => async dispatch =>
    dispatch({
        type: INSPECTION_VALUECHANGED,
        payload,
    });

export const inspectionViolatorAdded = (value, violations) => async dispatch =>
    dispatch({
        type: INSPECTION_ADDEDNEWVIOLATOR,
        payload: { value, violations },
    });
export const inspectionAddLogs = log => async dispatch =>
    dispatch({
        type: INSPECTION_ADDNEWLOG,
        payload: { log },
    });
export const inspectionViolationsupdated = (violations, violatorindex) => async dispatch =>
    dispatch({
        type: INSPECTION_UPDATEVIOLATIONS,
        payload: { violations, violatorindex },
    });
export const inspectionRemoveViolator = identifier => async dispatch =>
    dispatch({
        type: INSPECTION_REMOVEVIOLATOR,
        payload: { identifier },
    });

export const infoChanged = (key, value, visit) => async dispatch =>
    dispatch({
        type: INSPECTION_INFOCHANGED,
        payload: { key, value, visit },
    });
export const infoViolatorChanged = (key, value, identifier) => async dispatch =>
    dispatch({
        type: INSPECTION_INFOVIOLATORCHANGED,
        payload: { key, value, identifier },
    });
export const clearHistory = () => ({
    type: INSPECTION_CLEARHISTORY,
});

export const addViolatorSignature = payload => ({
    type: INSPECTION_ADD_VIOLATIOR_SIGNATURE,
    payload,
});

export const removeViolatorSignature = payload => ({
    type: INSPECTION_REMOVE_VIOLATIOR_SIGNATURE,
    payload,
});
