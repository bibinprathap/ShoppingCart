export const LOADING_DATA = 'LOADING_DATA';
export const DATA_LOADED = 'DATA_LOADED';
export const MODAL_SHOWING = 'MODAL_SHOWING';
export const MODAL_CLOSED = 'MODAL_CLOSED';
export const RERENDER_MODAL = 'MODAL_CLOSED';

export const setLoading = () => {
    return {
        type: LOADING_DATA,
    };
};

export const setLoaded = () => {
    return {
        type: DATA_LOADED,
    };
};

export const modalShowing = () => {
    return {
        type: MODAL_SHOWING,
    };
};

export const modalClosed = () => {
    return {
        type: MODAL_CLOSED,
    };
};

export const reRenderModal = () => {
    return {
        type: RERENDER_MODAL,
    };
};
