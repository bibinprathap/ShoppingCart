import { strings } from 'app/config/i18n/i18n';

export const LOADER_LOADING = 'LOADER_LOADING';
export const LOADER_LOADED = 'LOADER_LOADED';
export const setLoading = payload => {
    const defaultOptions = {
        maxTries: 1,
        autoClose: true,
        autoRetry: false,
        retryCount: 1,
        message: strings('pleaseWait'),
    };
    const mergedPayload = { options: defaultOptions, result: undefined, isRunning: true, ...payload };
    return async dispatch => {
        dispatch({ type: LOADER_LOADING, payload: mergedPayload });
    };
};

export const setLoaded = payload => {
    return async dispatch => {
        dispatch({ type: LOADER_LOADED, payload });
    };
};
