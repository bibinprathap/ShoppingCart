import AppApi from 'app/api/real';
const api = new AppApi();

export const MASTERDATA_LOADLATEST_STARTED = 'MASTERDATA_LOADLATEST_STARTED';
export const MASTERDATA_LOADLATEST_FAILURE = 'MASTERDATA_LOADLATEST_FAILURE';
export const MASTERDATA_LOADLATEST_SUCCESS = 'MASTERDATA_LOADLATEST_SUCCESS';
export const MASTERDATA_CLEAR = 'MASTERDATA_CLEAR';

const loadLatestInternal = lastUpdated => ({
    type: MASTERDATA_LOADLATEST_STARTED,
    lastUpdated,
});

export const masterdataLoaded = data => ({
    type: MASTERDATA_LOADLATEST_SUCCESS,
    data,
});

export const masterdataLoadFailed = error => ({
    type: MASTERDATA_LOADLATEST_FAILURE,
    error,
});

export const clearMasterdata = () => ({
    type: MASTERDATA_CLEAR,
});

export const loadLatestMasterdata = lastUpdated => {
    return async dispatch => {
        api.dispatch = dispatch;
        dispatch(loadLatestInternal(lastUpdated));
        try {
            const data = await api.loadMasterdata(lastUpdated);
            console.log('actions.loadLatestMasterdata succcess: ', data);
            dispatch(masterdataLoaded(data));
        } catch (error) {
            dispatch(masterdataLoadFailed(error));
        }
    };
};
