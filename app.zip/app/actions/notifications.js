import firebase from 'app/api/helperServices/rnFirebaseNative';

export const ADD_NOTIFICATION = 'ADD_NOTIFICATION';
export const NOTIFICATION_REFRESH_UNREAD_COUNT = 'NOTIFICATION_REFRESH_UNREAD_COUNT';
export const NOTIFICATION_READ = 'NOTIFICATION_READ';
export const NOTIFICATION_TOKEN = 'NOTIFICATION_TOKEN';
export const CLEAR_FCM_INSANCE = 'CLEAR_FCM_INSANCE';
export const FCM_INITIALIZE = 'FCM_INITIALIZE';
export const RESET_NOTIFICATIONS = 'RESET_NOTIFICATIONS';

export const fcmInitialize = () => async dispatch => {
    firebase.getRegistrationToken((error, token) => {
        dispatch(updateFCMToken(token));
    });

    dispatch({
        type: FCM_INITIALIZE,
    });
};

export const addNotification = notification => async dispatch =>
    dispatch({
        type: ADD_NOTIFICATION,
        notification,
    });

export const markNotificationAsRead = notificationId => async dispatch =>
    dispatch({
        type: NOTIFICATION_READ,
        notificationId,
    });

export const refreshNotificationUnreadCount = () => async dispatch =>
    dispatch({
        type: NOTIFICATION_REFRESH_UNREAD_COUNT,
    });

export const updateFCMToken = fcmToken => async dispatch =>
    dispatch({
        type: NOTIFICATION_TOKEN,
        fcmToken,
    });

export const clearFCMInstance = () => async dispatch => {
    firebase.clearAllNotifications();
    firebase.deleteInstance();

    dispatch({
        type: CLEAR_FCM_INSANCE,
        fcmToken: null,
    });
};

export const resetNotifications = () => async dispatch => {
    dispatch({
        type: RESET_NOTIFICATIONS,
    });
};
