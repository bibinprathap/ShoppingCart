import AppApi from 'app/api/real';

export const SET_SEARCH_KEY = 'SET_SEARCH_KEY';
export const SET_FILTER = 'SET_FILTER';
export const SEARCH = 'SEARCH';
export const SEARCH_SUCCESS = 'SEARCH_SUCCESS';
export const SEARCH_FAILURE = 'SEARCH_FAILURE';
export const RESET_SEARCH = 'RESET_SEARCH';

const api = new AppApi();

export const setSearchKey = searchKey => ({
    type: SET_SEARCH_KEY,
    searchKey,
});

export const setFilter = filter => ({
    type: SET_FILTER,
    filter,
});

export const search = (searchKey, filter) => {
    return async dispatch => {
        dispatch({
            type: SEARCH,
            searchKey,
            filter,
        });

        try {
            const searchResult = await api.search(searchKey, filter);
            dispatch(searchSuccess(searchResult));
        } catch (e) {
            dispatch(searchFailure());
        }
    };
};

export const searchSuccess = results => ({
    type: SEARCH_SUCCESS,
    results,
});

export const searchFailure = () => ({
    type: SEARCH_FAILURE,
});

export const resetSearch = () => ({
    type: RESET_SEARCH,
});
