export const SETTINGS_INIT_LANGUANGE = 'SETTINGS_INIT_LANGUANGE';
export const SETTINGS_SELECTEDPRINTER = 'SETTINGS_SELECTEDPRINTER';
export const SETTINGS_CAMERA_FLASH = 'SETTINGS_CAMERA_FLASH';
export const SETTINGS_CHANGE_ENVIRONMENT = 'SETTINGS_CHANGE_ENVIRONMENT';

export const SET_DEEPLINK = 'SET_DEEPLINK';
export const CLEAR_DEEPLINK = 'CLEAR_DEEPLINK';

export const initLanguage = locale => ({
    type: SETTINGS_INIT_LANGUANGE,
    locale,
});

export const setSelectedPrinter = printer => ({
    type: SETTINGS_SELECTEDPRINTER,
    printer,
});

export const setCameraFlash = flash => ({
    type: SETTINGS_CAMERA_FLASH,
    flash,
});

export const changeEnvironment = env => async dispatch =>
    dispatch({
        type: SETTINGS_CHANGE_ENVIRONMENT,
        env,
    });

export const setDeeplink = params => {
    return async dispatch => {
        const { deeplink } = params;
        dispatch({
            type: SET_DEEPLINK,
            deeplink,
        });
    };
};

export const clearDeeplink = () => ({
    type: CLEAR_DEEPLINK,
});
