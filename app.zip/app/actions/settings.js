import { NavigationActions } from 'react-navigation';
import alertsHelper from 'app/api/helperServices/alerts';

export const SETTINGS_INIT_LANGUANGE = 'SETTINGS_INIT_LANGUANGE';
export const SETTINGS_SELECTEDPRINTER = 'SETTINGS_SELECTEDPRINTER';
export const SETTINGS_CAMERA_FLASH = 'SETTINGS_CAMERA_FLASH';
export const SETTINGS_CHANGE_ENVIRONMENT = 'SETTINGS_CHANGE_ENVIRONMENT';

export const SET_DEEPLINK = 'SET_DEEPLINK';
export const CLEAR_DEEPLINK = 'CLEAR_DEEPLINK';

export const initLanguage = locale => ({
    type: SETTINGS_INIT_LANGUANGE,
    locale,
});

export const setSelectedPrinter = printer => ({
    type: SETTINGS_SELECTEDPRINTER,
    printer,
});

export const setCameraFlash = flash => ({
    type: SETTINGS_CAMERA_FLASH,
    flash,
});

export const changeEnvironment = env => async dispatch =>
    dispatch({
        type: SETTINGS_CHANGE_ENVIRONMENT,
        env,
    });

export const handleDeeplink = params => {
    return async dispatch => {
        const { deeplink, loggedIn } = params;
        dispatch({
            type: SET_DEEPLINK,
            deeplink,
            dispatch: params.dispatch,
        });
        try {
            if (deeplink && params.dispatch) {
                const route = deeplink.replace(/.*?:\/\/mims\//g, '').split('/');
                let routeName = '';
                let routeParams = {};
                switch (route[0]) {
                    // Add more deeplinks here
                    case 'search':
                        routeName = route[0];
                        routeParams = {};
                        break;
                }

                if (loggedIn) {
                    if (routeName) {
                        params.dispatch(
                            NavigationActions.navigate({
                                routeName,
                                params: routeParams,
                            })
                        );
                    }
                    dispatch(clearDeeplink());
                } else {
                    alertsHelper.show('warn', 'Please login', `Please login to continue`);
                    //do nothing for now
                }
            }
        } catch (error) {
            console.log('error', error);
        }
    };
};

export const clearDeeplink = () => ({
    type: CLEAR_DEEPLINK,
});
