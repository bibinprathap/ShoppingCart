import { tasksHelper } from 'app/api/helperServices';

export const TASK_CLEARHISTORY = 'TASK_CLEARHISTORY';
export const TASK_CREATENEW = 'TASK_CREATENEW';
export const TASK_INITIALCREATE = 'TASK_INITIALCREATE';

export const clearTask = () => ({
    type: TASK_CLEARHISTORY,
});

export const createNewTask = () => ({
    type: TASK_CREATENEW,
    payload: tasksHelper.createNew(),
});

export const createInitialTasks = tasks => ({
    type: TASK_INITIALCREATE,
    payload: tasks,
});
