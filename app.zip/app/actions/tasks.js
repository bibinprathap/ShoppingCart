import { tasksHelper } from 'app/api/helperServices';
import AppApi from 'app/api/real';

export const TASK_CLEARHISTORY = 'TASK_CLEARHISTORY';
export const TASK_CREATENEW = 'TASK_CREATENEW';
export const TASK_INITIALCREATE = 'TASK_INITIALCREATE';
export const TASK_DETAILS = 'TASK_DETAILS';
export const TASK_DETAILS_FETCH_STARTED = 'TASK_DETAILS_FETCH_STARTED';
export const TASK_DETAILS_FETCH_ERROR = 'TASK_DETAILS_FETCH_ERROR';
const api = new AppApi();

export const clearTask = () => ({
    type: TASK_CLEARHISTORY,
});

export const createNewTask = task => ({
    type: TASK_CREATENEW,
    payload: tasksHelper.createNew(task),
});

export const createInitialTasks = tasks => ({
    type: TASK_INITIALCREATE,
    payload: tasks,
});
export const getTaskDetails = taskId => async dispatch => {
    dispatch({
        type: TASK_DETAILS_FETCH_STARTED,
        payload: { taskId },
    });
    try {
        const data = await api.getTaskDetails(taskId);
        const remarks = data.remarks || '';
        const typeOfTasks = data.typeOfTasks || '';
        const assignedBy = data.assignedBy || '';
        dispatch({
            type: TASK_DETAILS,
            payload: { taskId, remarks, typeOfTasks, assignedBy },
        });
    } catch (error) {
        dispatch({
            type: TASK_DETAILS_FETCH_ERROR,
            payload: { taskId, error },
        });
        // if (!error.isCancel) {
        //  alertsHelper.show('error', 'Inspection Record Create failed', error.detail);
        // }
    }
    return taskId;
};
