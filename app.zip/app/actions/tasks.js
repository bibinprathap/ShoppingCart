import { setLoading, setLoaded } from 'app/actions/loader';
import alertsHelper from 'app/api/helperServices/alerts';
import AppApi from 'app/api/real';
import { strings } from 'app/config/i18n/i18n';
import { getErrorMessageWithDetail } from 'app/api/helperServices/utils';

export const TASK_DETAILS_FETCH_STARTED = 'TASK_DETAILS_FETCH_STARTED';
export const TASK_DETAILS_FETCH_ERROR = 'TASK_DETAILS_FETCH_ERROR';
export const TASK_DETAILS_DIALOG_SHOW = 'TASK_DETAILS_DIALOG_SHOW';
export const TASK_DETAILS_DIALOG_HIDE = 'TASK_DETAILS_DIALOG_HIDE';

const api = new AppApi();

const inscidentTask = {
    titleE: 'ABUDHABI WASTE MANGMENT CENTER',
    titleA: 'ABUDHABI WASTE MANGMENT CENTER',
    taskId: 3801,
    assignedDate: '2020-01-28T12:06:30',
    actualStartDate: '2020-01-28T12:18:10',
    expectedStartDate: '2020-01-29T12:06:30',
    expectedEndDate: '2020-01-30T12:06:30',
    location: {
        locationAddressId: null,
        coords: {
            gpsTime: null,
            accuracy: 17.1310005187988,
            longitude: 54.3783161,
            latitude: 24.4874398,
            speed: null,
            heading: null,
            altitude: null,
        },
        address: {
            zoneId: 435,
            zoneNameA: 'جزيرة أبوظبي',
            zoneNameE: 'ABU DHABI ISLAND',
            sectorId: 4312,
            sectorNameA: 'شرق 11',
            sectorNameE: 'E11',
            plotGisId: 0,
            plotNumber: 'P1',
        },
    },
    inspectionTypeId: 1000,
    taskStatusConst: 'New',
    taskStatusNameE: 'New',
    taskStatusNameA: 'جديد',
    parentInspectionInstanceId: 7387,
    icon: {
        type: 'AdmIcon',
        name: 'wf-1154',
    },
    priority: 3,
    taskType: 'Incident',
    taskTypeNameE: 'Incident',
    taskTypeNameA: 'Incident',
    description: 'Dead animals',
    assignedToUserId: 1274,
    applicationNumber: '1038',
    workflowApplicationNumber: '202000001377',
    refNumber: '20200128120519658',
    createdApplicationNumber: '1039',
    isMyTask: true,
    attachments: [],
    inspectionTypeDetail: {
        inspectionTypeId: 1000,
        titleE: 'Distortions',
        titleA: 'المشوهات',
        icon: {
            type: 'AdmIcon',
            name: 'wf-1154',
        },
        inspectionTypeCheckItems: [],
        workflowConst: 'MimsDistortion',
        entityConst: 'ADM',
        serviceDescE: 'Distortions Service',
        serviceDescA: 'المشوهات',
    },
    locationAddress: {
        communityId: 1343,
        confidence: '17.1310005187988',
        districtId: 1094,
        gpsDateTime: null,
        latitude: '24.4874398',
        locationAddressId: 110195,
        locationCoordinate: '54.3783161,24.4874398',
        longitude: '54.3783161',
        municipalityId: 1000,
        plotGisId: 4251901,
        plotId: null,
        plotNumber: 'P1',
        roadGisId: null,
        roadId: null,
        roadNameA: '',
        roadNameE: '',
        sectorGisId: 4312,
        sectorNameA: 'شرق 11',
        sectorNameE: 'E11',
        zoneGisId: 435,
        zoneNameA: 'جزيرة أبوظبي',
        zoneNameE: 'ABU DHABI ISLAND',
        urlArgs: null,
    },
    inspectorLocationAddress: {
        communityId: 1343,
        confidence: '17.1310005187988',
        districtId: 1094,
        gpsDateTime: null,
        latitude: '24.4874398',
        locationAddressId: 110198,
        locationCoordinate: '54.3783161,24.4874398',
        longitude: '54.3783161',
        municipalityId: 1000,
        plotGisId: 4251901,
        plotId: null,
        plotNumber: 'P1',
        roadGisId: null,
        roadId: null,
        roadNameA: '',
        roadNameE: '',
        sectorGisId: 4312,
        sectorNameA: 'شرق 11',
        sectorNameE: 'E11',
        zoneGisId: 435,
        zoneNameA: 'جزيرة أبوظبي',
        zoneNameE: 'ABU DHABI ISLAND',
        urlArgs: null,
    },
};

export const getTaskDetails = taskId => async dispatch => {
    dispatch({
        type: TASK_DETAILS_FETCH_STARTED,
        payload: { taskId },
    });
    let data = null;
    try {
        //########### Remove this block //Uncomment for testing
        // if (taskId == 3801) data = inscidentTask;
        // else data = await api.getTaskDetails(taskId);
        //########### REmove this block and uncomment below

        data = await api.getTaskDetails(taskId);
    } catch (error) {
        dispatch({
            type: TASK_DETAILS_FETCH_ERROR,
            payload: { taskId, error },
        });

        dispatch(setLoaded());
        alertsHelper.show('error', strings('failedToLoadTaskDetails'), getErrorMessageWithDetail(error));
    }
    if (!data) {
        dispatch(setLoaded());
        alertsHelper.show('error', strings('failedToLoadTaskDetails'), 'Task details not available');
        return;
    }
    return { taskId, data: { ...data, remarks: data.description || '' } };
};

export const showTaskDetailsDialog = (taskid, title, taskDetails) => {
    return async dispatch => {
        dispatch({
            type: TASK_DETAILS_DIALOG_SHOW,
            payload: {
                taskid,
                title,
                taskDetails,
            },
        });
    };
};

export const hideTaskDetailsDialog = payload => {
    return async dispatch => {
        dispatch({ type: TASK_DETAILS_DIALOG_HIDE });
    };
};
