[
    {
        name: 'followupForm',
        titleE: 'Details of the followup',
        titleA: 'تفاصيل المتابعة',
        showFormTitle: true,
        collapsible: true,
        showLabels: true,
        formType: 'followup',
        workflowConst: 'MimsBuildingPenaltiesandGeneralAppearance',
        scope: 'visit',
        fields: [
            {
                name: 'fieldGroup1',
                type: 'fieldGroup',
                fields: [
                    {
                        name: 'location',
                        type: 'currentLocation',
                        labelE: 'Current Location',
                        labelA: 'الموقع الحالي',
                    },
                ],
            },
            {
                name: 'fieldGroup2',
                type: 'fieldGroup',
                fields: [
                    {
                        name: 'attachmentList',
                        type: 'attachmentList',
                        labelE: 'Attachments',
                        labelA: 'مرفقات',
                        validationRule: ['array', 'required', 'nullable'],
                    },
                ],
            },
            {
                name: 'fieldGroup3',
                type: 'fieldGroup',
                fields: [
                    {
                        type: 'picker',
                        name: 'followupAction',
                        defaultlyNotSelected: true,
                        labelE: 'Action',
                        labelA: 'عمل',
                        validationRule: ['string', 'required'],
                    },
                    {
                        type: 'periodPicker',
                        name: 'duration',
                        labelE: 'Duration',
                        defaultValue: { selectedPeriod: 0, selectedPeriodType: 'day' },
                        labelA: 'المدة الزمنية',
                        showIf: ['followupAction=2'],
                    },
                    {
                        name: 'amount',
                        type: 'amount',
                        labelE: 'Violation Amount',
                        icon: 'remove-circle-outline',
                        iconColor: '#FF0000',
                        iconType: 'default',
                        labelA: 'مبلغ الانتهاك',
                        showIf: ['followupAction=3'],
                    },
                ],
            },
            {
                name: 'fieldGroup4',
                type: 'fieldGroup',
                fields: [
                    {
                        name: 'remarks',
                        type: 'text',
                        labelE: 'Remarks',
                        labelA: 'ملاحظات',
                        placeholderE: 'Remarks',
                        placeholderA: 'ملاحظات',
                        maxLength: 200,
                        multiline: true,
                        mode: 'flat',
                        debounce: 0,
                        validationRule: ['string', 'required'],
                    },
                ],
            },
        ],
    },
];
