export const TRACKING_LOCATION_UPDATE = 'TRACKING_LOCATION_UPDATE';
export const TRACKING_APPSTATE_CHANGE = 'TRACKING_APPSTATE_CHANGE';
import AppApi from 'app/api/real';
const api = new AppApi();

export const infoChanged = (key, value, visit) => async dispatch =>
    dispatch({
        type: INSPECTION_INFOCHANGED,
        payload: { key, value, visit },
    });

export const locationEvent = event => async dispatch => {
    //console.log('creating action bgGeolocationEvent', event);
    api.dispatch = dispatch;
    dispatch({
        type: TRACKING_LOCATION_UPDATE,
        event,
    });
    try {
        //const result = await api.trackingLocationUpdate(event);
        //console.log('trackingLocationUpdate success: ', result);
    } catch (error) {
        //console.log('trackingLocationUpdate error: ', error);
    }
};

export const appStateChange = appState => async dispatch => {
    dispatch({
        type: TRACKING_APPSTATE_CHANGE,
        appState,
    });
};
