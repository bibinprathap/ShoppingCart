AsyncTask.execute(new Runnable() {
    @Override
    public void run()  {
        
try {
URL Endpoint = new URL("https://api.github.com/");

// Create connection
HttpsURLConnection myConnection = (HttpsURLConnection) Endpoint.openConnection();
//setting request properties and method type
myConnection.setRequestProperty("User-Agent", "my-rest-app-v0.1");
myConnection.setRequestProperty("Accept",    "application/vnd.github.v3+json");
myConnection.setRequestProperty("InspectionId",    "hathibelagal@example.com");
 
myConnection.setRequestMethod("POST");
if (myConnection.getResponseCode() == 200) {
// Success
// Further processing here
InputStream responseBody = myConnection.getInputStream();
InputStreamReader responseBodyReader =new InputStreamReader(responseBody, "UTF-8");
JsonReader jsonReader = new JsonReader(responseBodyReader);
jsonReader.beginObject(); // Start processing the JSON object
while (jsonReader.hasNext()) { 
    String key = jsonReader.nextName(); 
    if (key.equals("organization_url")) { 
        
        String value = jsonReader.nextString();
        

        // Do something with the value
        // ...

        break; // Break out of the loop
    } else {
        jsonReader.skipValue(); // Skip values of other keys
    }
}
jsonReader.close();

} else {
// Error handling code goes here
}
myConnection.disconnect();
}
catch (Exception e){

}
    }
});