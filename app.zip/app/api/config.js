const defaultMapServer = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer';
const defaultFeatureServer = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer';
/*
        for emulator
        ============
        baseURL: 'http://172.18.196.122:30000/api',
        timeout: 60000,
            if you are running in dev, using IISExpress do the following:
                1) adjust baseURL for your machine IP
                2) npm install -g iisexpress-proxy
                3) if you are not using run.bat, cleanrun.bat or clearrun.bat,
                   then start iisxpress-proxy as shown below
                    iisexpress-proxy [iisexpress-port] to [new-port-to-listen-on]
                    * example: iisexpress-proxy 56035 to 30000
        for device - connected via USB
        ==============================
            - make sure iisexpress-proxy is not running
            - enable port forwarding in chrome dev tools.
                1) on host machine, open this url in chrome:   chrome://inspect/#devices
                2) click on "Port forwarding"
                   enter this-> 
                        port: 56035
                        IP address and port: localhost:56035
                    select check box "Enable port forwarding" and press Done
            

*/

const config = {
    production: {
        title: 'Production',
        baseURL: 'https://eformstest.adm.gov.ae/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    test: {
        title: 'Test',
        baseURL: 'https://eformstest.adm.gov.ae/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    uat: {
        title: 'UAT3',
        baseURL: 'https://eformsuat3.adm.gov.ae/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    /*
    development: {
        title: 'Development',
        baseURL: 'http://localhost:65125/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    */
    raheel: {
        title: 'Raheel',
        baseURL: 'http://172.18.128.94/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    bibin: {
        title: 'Bibin',
        baseURL: 'http://172.18.128.146/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    vyshakh: {
        title: 'Vyshakh',
        baseURL: 'http://172.18.128.102/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    aizaz: {
        title: 'Aizaz',
        baseURL: 'http://172.18.128.21/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    awais: {
        title: 'Awais',
        baseURL: 'http://172.18.128.110/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    ejaz: {
        title: 'Ejaz',
        baseURL: 'http://172.18.128.128/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    naqi: {
        title: 'Naqi',
        baseURL: 'http://172.18.128.39/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    deepak: {
        title: 'Deepak',
        baseURL: 'http://172.18.59.25/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
    saleem: {
        title: 'Saleem',
        baseURL: 'http://172.18.128.60/api',
        mapServer: defaultMapServer,
        featureServer: defaultFeatureServer,
        timeout: 60000,
    },
};
//export default config[process.env.NODE_ENV];
//export default config['development'];
export default config;
