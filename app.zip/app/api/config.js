const config = {
    production: {
        baseURL: 'https://eformstest.adm.gov.ae/api',
        timeout: 60000,
    },
    test: {
        baseURL: 'https://eformstest.adm.gov.ae/api',
        timeout: 60000,
    },
    development: {
        /*
        for emulator
        ============
        baseURL: 'http://172.18.196.122:30000/api',
        timeout: 60000,
            if you are running in dev, using IISExpress do the following:
                1) adjust baseURL for your machine IP
                2) npm install -g iisexpress-proxy
                3) if you are not using run.bat, cleanrun.bat or clearrun.bat,
                   then start iisxpress-proxy as shown below
                    iisexpress-proxy [iisexpress-port] to [new-port-to-listen-on]
                    * example: iisexpress-proxy 56035 to 30000
        */

        /*
        for device - connected via USB
        ==============================
            - make sure iisexpress-proxy is not running
            - enable port forwarding in chrome dev tools.
                1) on host machine, open this url in chrome:   chrome://inspect/#devices
                2) click on "Port forwarding"
                   enter this-> 
                        port: 56035
                        IP address and port: localhost:56035
                    select check box "Enable port forwarding" and press Done
            



        */
        baseURL: 'http://localhost:56035/api',
        timeout: 60000,
    },
};
//export default config[process.env.NODE_ENV];
//export default config['development'];
export default config;
