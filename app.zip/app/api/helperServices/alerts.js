import { setAlert } from 'app/actions/settings';
import { store } from 'app/config/store';
export default class alertsHelper {
    static alertDefault;
    static onClose;

    static setAlertProvider(provider) {
        this.alertDefault = provider;
    }

    static show(type, title, message, delay = false) {
        if (!this.alertDefault) return;
        if (delay) {
            setTimeout(() => {
                store.dispatch(setAlert({ type, title, message, delay }));
                this.alertDefault.alertWithType(type, title, message);
            }, 200);
        } else {
            store.dispatch(setAlert({ type, title, message, delay }));
            this.alertDefault.alertWithType(type, title, message);
        }
    }

    static invokeOnClose() {
        store.dispatch(setAlert(null));
        if (typeof this.onClose === 'function') {
            this.onClose();
        }
    }

    static invokeOnCancel(data) {
        if (typeof this.onCancel === 'function') {
            this.onCancel(data);
        }
    }
}
