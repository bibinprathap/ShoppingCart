export default class alertsHelper {
    static alertProvider;
    static onClose;

    static setAlertProvider(provider) {
        this.alertProvider = provider;
    }

    static show(type, title, message) {
        if (this.alertProvider) {
            //Todo: call provider specific method to show the alert
            // this.alertProvider.alertWithType(type, title, message);
        }
    }

    static setOnClose(onClose) {
        this.onClose = onClose;
    }

    static invokeOnClose() {
        if (typeof this.onClose === 'function') {
            this.onClose();
        }
    }
    static setOnCancel(onCancel) {
        this.onCancel = onCancel;
    }

    static invokeOnCancel(data) {
        if (typeof this.onCancel === 'function') {
            this.onCancel(data);
        }
    }
}
