import React from 'react';
import moment from 'moment';
import { _ } from 'lodash';
import { store } from 'app/config/store';

let helper = undefined;
export const MEDIA_TYPES = { Image: 'image', Audio: 'audio', Video: 'video', PDF: 'pdf', Unknwon: 'unknown' };
export const EXTENSIONS = { Image: { JPG: 'jpg', JPEG: 'jpeg', PNG: 'PNG' }, Audio: '3ga', Video: '3gp', PDF: 'pdf', Unknwon: 'unknown' };
class AttachmentsHelper {
    static instance = null;
    static _createInstance() {
        return new AttachmentsHelper();
    }

    static getInstance() {
        if (!AttachmentsHelper.instance) {
            AttachmentsHelper.instance = AttachmentsHelper._createInstance();
            helper = AttachmentsHelper.instance;
        }
        return AttachmentsHelper.instance;
    }

    generateUniqueIntegerKey = () => {
        //instead of random number, generating timestamp to ensure keys are in assending order, to avoid sorting for the image listview
        return moment().format('YYYYMMDDHHmmssSSS'); //time stamp upto 999th millisecond
    };

    getDoc = id => {
        const attachments = store.getState().attachments;
        if (attachments && attachments.docs) return _.find(attachments.docs, docItem => docItem.id == id);
    };

    getEmptyAudio = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Audio,
        extension: EXTENSIONS.Audio,
    });

    getEmptyVideo = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Video,
        extension: EXTENSIONS.Video,
    });

    getEmptyPdf = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.PDF,
        extension: EXTENSIONS.PDF,
    });

    getEmptyImage = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Image,
        extension: EXTENSIONS.Image.JPEG,
        fileName: undefined,
        path: undefined, //[will be full path in device filesystem, if file as been downloaded]
        data: undefined, // [base64 encoded data. when it is a new image, not uploaded yet]
        height: 0,
        width: 0,
        size: 0,
        exif: undefined, //exif data received from the cam
        uploading: false,
        thumbnail: undefined, //[base64 encoded- download the file when user opens enlarged view]
        inspectionID: undefined,
        uploaded: false, //to signal anyone waiting for file to uploaded
        downloaded: false, //to signal anyone waiting for file to download
        uploadedDate: undefined, //[needed? - idea is to track offline use, and how long it took to upload]
        createdDate: undefined, //
        createdBy: undefined, //[tbd: store id and username or what? if we want to show who attached the doc]
        location: {
            latitude: 0, //todo: get this from the location service helper
            longitude: 0, //todo: get this from the location service helper
            accuracy: 0, //todo: get this from the location service helper
        },
    });

    prepareNewImageForAttachment = (contents, quality, id) => {
        const doc = helper.getEmptyImage(id);
        doc.path = contents.path;
        doc.data = contents.data;
        doc.height = contents.height;
        doc.width = contents.width;
        doc.size = contents.size;
        doc.exif = contents.exif;
        doc.quality = quality;
        return doc;
    };
}

export default AttachmentsHelper.getInstance();
