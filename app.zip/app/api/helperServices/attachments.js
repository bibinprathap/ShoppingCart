import React from 'react';
import moment from 'moment';
import { _ } from 'lodash';
import { store, _state } from 'app/config/store';
import { RNFileUploader } from 'app/api/helperServices';
import envConfig from 'app/api/config';
import { uploadingImageAttachment, uploadedImageAttachment, uploadErrorImageAttachment } from 'app/actions/attachments';
import { inspectionAddLogs } from 'app/actions/inspections';
const env = envConfig;

let helper = undefined;
export const MEDIA_TYPES = { Image: 'image', Audio: 'audio', Video: 'video', PDF: 'pdf', Unknwon: 'unknown' };
export const EXTENSIONS = { Image: { JPG: 'jpg', JPEG: 'jpeg', PNG: 'PNG' }, Audio: '3ga', Video: '3gp', PDF: 'pdf', Unknwon: 'unknown' };
class AttachmentsHelper {
    static instance = null;
    static _createInstance() {
        return new AttachmentsHelper();
    }

    static getInstance() {
        if (!AttachmentsHelper.instance) {
            AttachmentsHelper.instance = AttachmentsHelper._createInstance();
            helper = AttachmentsHelper.instance;
        }
        return AttachmentsHelper.instance;
    }

    generateUniqueIntegerKey = () => {
        //instead of random number, generating timestamp to ensure keys are in assending order, to avoid sorting for the image listview
        return moment().format('YYYYMMDDHHmmssSSS'); //time stamp upto 999th millisecond
    };

    getDoc = id => {
        const attachments = store.getState().attachments;
        if (attachments && attachments.docs) return _.find(attachments.docs, docItem => docItem.id == id);
    };

    getDocByUploadId = fileName => {
        const attachments = store.getState().attachments;
        if (attachments && attachments.docs) return _.find(attachments.docs, docItem => docItem.fileName == fileName);
    };

    getPendingUploadAttachement = baseURL => {
        const state = _state;

        return _state.attachments.docs.filter(a => a.path.indexOf(baseURL) == -1);
    };

    getUploadingAttachement = () => {
        const state = _state;
        return _state.attachments.docs.filter(a => a.uploading == true);
    };

    getEmptyAudio = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Audio,
        extension: EXTENSIONS.Audio,
    });

    getEmptyVideo = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Video,
        extension: EXTENSIONS.Video,
    });

    getEmptyPdf = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.PDF,
        extension: EXTENSIONS.PDF,
    });

    getEmptyImage = id => ({
        id: id || helper.generateUniqueIntegerKey(),
        mediaType: MEDIA_TYPES.Image,
        extension: EXTENSIONS.Image.JPEG,
        fileName: undefined,
        path: undefined, //[will be full path in device filesystem, if file as been downloaded]
        data: undefined, // [base64 encoded data. when it is a new image, not uploaded yet]
        height: 0,
        width: 0,
        size: 0,
        exif: undefined, //exif data received from the cam
        uploading: false,
        thumbnail: undefined, //[base64 encoded- download the file when user opens enlarged view]
        inspectionID: undefined,
        uploaded: false, //to signal anyone waiting for file to uploaded
        downloaded: false, //to signal anyone waiting for file to download
        uploadedDate: undefined, //[needed? - idea is to track offline use, and how long it took to upload]
        createdDate: undefined, //
        createdBy: undefined, //[tbd: store id and username or what? if we want to show who attached the doc]
        location: {
            latitude: 0, //todo: get this from the location service helper
            longitude: 0, //todo: get this from the location service helper
            accuracy: 0, //todo: get this from the location service helper
        },
    });

    prepareNewImageForAttachment = (contents, quality, id) => {
        const doc = helper.getEmptyImage(id);
        doc.path = contents.path;
        doc.data = contents.data;
        doc.height = contents.height;
        doc.width = contents.width;
        doc.size = contents.size;
        doc.exif = contents.exif;
        doc.quality = quality;
        return doc;
    };

    uploaderListener;
    startUpload = (newAttachment, environment, authCode, useruuid) => {
        let attachement = { ...newAttachment, path: newAttachment.path.replace('file://', '') };
        const envConfig = env[environment];
        RNFileUploader.getFileInfo(attachement.path).then(metadata => {
            const options = Object.assign(
                {
                    url: envConfig.baseURL + '/DummyMims/upload_multipart',
                    field: 'uploaded_media',
                    type: 'multipart',
                    method: 'POST',
                    headers: {
                        'content-type': metadata.mimeType, // server requires a content-type header
                        '.ASPXAUTH': authCode,
                    },
                    timeout: envConfig.timeout || 0, //doesn't always work. need to fix this
                    withCredentials: true,
                },
                attachement
            );
            RNFileUploader.startUpload(options)
                .then(
                    (uploadId => {
                        console.log(`RNFileUploader started with options: ${JSON.stringify(options)}`);
                        store.dispatch(
                            uploadingImageAttachment({
                                id: attachement && attachement.id,
                                uploadId,
                                uploading: true,
                                createdBy: useruuid,
                                id: attachement.id,
                                inspectionID: attachement && attachement.inspectionID,
                            })
                        );
                        if (this.uploaderListener) this.uploaderListener.remove();
                        this.uploaderListener = RNFileUploader.addListener('progress', uploadId, data => {
                            __DEV__ && console.log(`Progress: ${JSON.stringify(data)}%`);
                            if (data.responseCode && data.responseCode == 200) {
                                store
                                    .dispatch(
                                        uploadedImageAttachment({
                                            id: attachement && attachement.id,
                                            uploading: false,
                                            uploaded: true,
                                            createdDate: new Date(),
                                            createdBy: useruuid,
                                            uploadedDate: new Date(),
                                            fileName: data.id,
                                            path: JSON.parse(data.responseBody).result.path.replace('http://', 'https://'),
                                        })
                                    )
                                    .then(() => {
                                        const pendingUploads = this.getUploadingAttachement();
                                        if (pendingUploads.length == 0) this.uploaderListener.remove();
                                    });
                            } else if (data.error || (data.responseCode && data.responseCode != 200)) {
                                store
                                    .dispatch(
                                        uploadErrorImageAttachment({
                                            id: attachement && attachement.id,
                                            uploading: false,
                                            uploaded: false,
                                            error: data.error,
                                            uploadedDate: new Date(),
                                            fileName: data.id,
                                        })
                                    )
                                    .then(() => {
                                        const pendingUploads = this.getUploadingAttachement();
                                        if (pendingUploads.length == 0) this.uploaderListener.remove();
                                    });
                            } else if (data.cancelled) {
                                __DEV__ && console.log(`[INFO] RNFileUploader cancelled!`);
                                const pendingUploads = this.getUploadingAttachement();
                                if (pendingUploads.length == 0) this.uploaderListener.remove();
                            }
                        });
                    }).bind(this)
                )
                .catch(function(err) {
                    //this.setState({ uploadId: null, progress: null });
                    console.log('RNFileUploader error!', err);
                });
        });
    };
    IsJsonString = str => {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    };
    checkUploadIdInSharedPreferences = async () => {
        return new Promise(resolve => {
            RNFileUploader.getString('CompletedUploadIds').then(completeduploadids => {
                __DEV__ && console.log('CompletedUploadIds' + completeduploadids);
                if (completeduploadids.length > 0) {
                    const uplodedIds = completeduploadids.split(' ');
                    uplodedIds.map(filename => {
                        const attachement = this.getDocByUploadId(filename);
                        __DEV__ && console.log('Completedfilename ' + filename);
                        if (attachement) {
                            RNFileUploader.getString(filename).then(data => {
                                __DEV__ && console.log('CompletedResponce');
                                __DEV__ && console.log(data);
                                if (data && data.length > 0 && this.IsJsonString(data) && JSON.parse(data).result) {
                                    store.dispatch(
                                        uploadedImageAttachment({
                                            id: attachement.id,
                                            uploading: false,
                                            uploaded: true,
                                            createdDate: new Date(),
                                            uploadedDate: new Date(),
                                            fileName: attachement.fileName,
                                            path: JSON.parse(data.responseBody).result.path.replace('http://', 'https://'),
                                        })
                                    );
                                    store.dispatch(
                                        inspectionAddLogs({
                                            documentid: attachement.fileName,
                                            inspectionID: attachement.inspectionID,
                                            date: new Date(),
                                            message: 'Uploaded Successfully',
                                            success: true,
                                        })
                                    );
                                }
                            });
                        }
                    });
                    // RNFileUploader.setString('CompletedUploadIds', '');
                }

                setTimeout(() => {
                    if (RNFileUploader.clearAll) RNFileUploader.clearAll();
                }, 5000);
            });

            RNFileUploader.getString('FailedUploadIds').then(failedUploadIds => {
                __DEV__ && console.log('FailedUploadIds' + failedUploadIds);
                if (failedUploadIds.length > 0) {
                    const uplodedIds = failedUploadIds.split(' ');
                    uplodedIds.map(filename => {
                        const attachement = this.getDocByUploadId(filename);
                        if (attachement) {
                            store.dispatch(
                                uploadErrorImageAttachment({
                                    id: attachement.id,
                                    uploading: false,
                                    uploaded: false,
                                    error: 'failed To Upload',
                                    uploadedDate: new Date(),
                                    fileName: attachement.fileName,
                                })
                            );
                            store.dispatch(
                                inspectionAddLogs({
                                    documentid: attachement.fileName,
                                    inspectionID: attachement.inspectionID,
                                    date: new Date(),
                                    message: 'Error While Uploading',
                                    success: false,
                                })
                            );
                        }
                    });

                    setTimeout(() => {
                        if (RNFileUploader.clearAll) RNFileUploader.clearAll();
                    }, 5000);
                    // RNFileUploader.setString('FailedUploadIds', '');
                }
            });

            resolve();
        });
    };
}

export default AttachmentsHelper.getInstance();
