import { NavigationActions } from 'react-navigation';
import { inspectionsHelper, alertsHelper } from 'app/api/helperServices';
import { clearDeeplink } from 'app/actions/settings';

class DeeplinkHelper {
    static instance = null;
    static _createInstance() {
        return new DeeplinkHelper();
    }

    static getInstance() {
        if (!DeeplinkHelper.instance) {
            DeeplinkHelper.instance = DeeplinkHelper._createInstance();
            helper = DeeplinkHelper.instance;
        }
        return DeeplinkHelper.instance;
    }

    handleLink = ({ deeplink, loggedIn, dispatch, navigation }) => {
        try {
            if (deeplink && dispatch) {
                const route = deeplink.replace(/.*?:\/\/mims\//g, '').split('/');
                let routeName = '';
                let routeParams = {};
                let navigate = loggedIn;
                switch (route[0]) {
                    // Add more deeplinks here
                    case 'search':
                    case 'scheduledWork':
                        routeName = route[0];
                        routeParams = {};
                        break;
                    case 'inspection':
                        const inspectionRef = typeof route[1] !== 'undefined' ? route[1] : null;
                        routeName = route[0];
                        if (inspectionRef) {
                            // navigation is handled in inspectionsHelper
                            navigate = false;
                            inspectionsHelper.selectInspection(inspectionRef, navigation);
                        }
                        break;
                    default:
                        break;
                }

                if (loggedIn) {
                    dispatch(clearDeeplink());
                    if (routeName && navigate) {
                        return navigation.dispatch(
                            NavigationActions.navigate({
                                routeName,
                                params: routeParams,
                            })
                        );
                    }
                } else {
                    alertsHelper.show('warn', 'Please login', `Please login to continue`);
                    //do nothing for now
                }
            }
        } catch (error) {
            console.log('error', error);
        }
    };
}

export default DeeplinkHelper.getInstance();
