import { PermissionsAndroid, Platform, ToastAndroid } from 'react-native';
import Geolocation from 'react-native-geolocation-service';

import moment from 'moment';
import DeviceInfo from 'react-native-device-info';
import { store, _state } from 'app/config/store';
import { locationEvent } from 'app/actions/tracking';
import AppApi from 'app/api/real';
const api = new AppApi();

const jobKey = 'locationTrackingJob';
const interval = 60000; //seconds
const timeout = 60000;
const minDistance = 1;
const enableHighAccuracy = true;
let _lastEvent = undefined;

showMessage = (msg, obj) => {
    const t = (obj && obj.time) || (obj && obj.location && obj.location.time);
    const msgTime = t ? moment(t).format('YYYY-MM-DD HH-mm-ss') : moment().format('YYYY-MM-DD HH-mm-ss'); //gps event or current time
     console.log(`[${msgTime}] - ${msg}`, obj || '');
};

dispatchEvent = async event => {
    _lastEvent = event;
    store && store.dispatch(locationEvent(event));

    // try {
    //     const result = await api.trackingLocationUpdate(event);
    //     //console.log('geolocation.dispatchEvent() trackingLocationUpdate success: ', result);
    // } catch (error) {
    //     console.log('geolocation.dispatchEvent() trackingLocationUpdate error: ', error);
    // }
};

export const startBackgroundLocationTracking = () => {
    // const backgroundJob = {
    //     jobKey: jobKey,
    //     job: performBackgroundJob,
    // };
    // BackgroundJob.register(backgroundJob);
    // applySchedule();
};

export const stopBackgroundLocationTracking = () => {
    BackgroundJob.cancel({ jobKey: jobKey })
        .then(() => console.log(`${jobKey} has been cancelled.`))
        .catch(err => console.log(`error while cancelling ${jobKey}: `, err));
};

export const cancelAllBackgroundJobs = () => {
    BackgroundJob.cancelAll()
        .then(() => console.log('All background jobs cancelled'))
        .catch(err => console.err(err));
};

performBackgroundJob = async () => {
    try {
        // const currentLocation = await getLocation();
        // const lastReportedTime = moment().format('YYYY-MM-DD HH-mm-ss');
        // const deviceId = DeviceInfo.getDeviceId();
        // const deviceUniqueId = DeviceInfo.getUniqueID();
        // const serialNumber = DeviceInfo.getSerialNumber();
        // const phoneNumber = DeviceInfo.getPhoneNumber();
        // const osName = DeviceInfo.getSystemName();
        // const osVersion = DeviceInfo.getSystemVersion();
        // const carrier = DeviceInfo.getCarrier();
        // const batteryLevel = DeviceInfo.getBatteryLevel();
        // const ipAddress = DeviceInfo.getIPAddress();
        // const appState = (_state && _state.tracking && _state.tracking.appState) || 'terminated';
        // let data;
        // Promise.all([batteryLevel.catch(error => error), ipAddress.catch(error => error)]).then(values => {
        //     data = {
        //         AppState: appState,
        //         DomainCustomerId: _state && _state.auth && _state.auth.activeProfileDomainCustomerId,
        //         location: { ...currentLocation },
        //         deviceInfo: {
        //             deviceId,
        //             deviceUniqueId,
        //             serialNumber,
        //             phoneNumber,
        //             osName,
        //             osVersion,
        //             carrier,
        //             batteryLevel: values[0],
        //             ipAddress: values[1],
        //         },
        //     };
        //     showMessage(`Location tracking job:`, data);
        //     //applySchedule(true, lastReportedTime);
        //     dispatchEvent(data);
        // });
    } catch (err) {
        //dispatchEvent(err);
    }
};

hasLocationPermission = async () => {
    if (Platform.OS === 'ios' || (Platform.OS === 'android' && Platform.Version < 23)) {
        return true;
    }

    const hasPermission = await PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);

    if (hasPermission) return true;

    const status = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);

    if (status === PermissionsAndroid.RESULTS.GRANTED) return true;

    if (status === PermissionsAndroid.RESULTS.DENIED) {
        ToastAndroid.show('Location permission denied by user.', ToastAndroid.LONG);
    } else if (status === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
        ToastAndroid.show('Location permission revoked by user.', ToastAndroid.LONG);
    }

    return false;
};

export const getLocation = async () => {
    const hasLocationPermission = await this.hasLocationPermission();

    if (!hasLocationPermission) return;
    else {
        //console.log('calling getCurrentPosition()');
        return new Promise((resolve, reject) => {
            Geolocation.getCurrentPosition(
                position => {
                    //console.log('Position: ', position);
                    resolve({ time: position.timestamp, ...position.coords });
                },
                error => {
                    //console.log('Error in getCurrentPosition: ', error);
                    reject(error);
                },
                {
                    enableHighAccuracy: enableHighAccuracy,
                    timeout: timeout,
                    maximumAge: interval * 2,
                    distanceFilter: minDistance,
                    forceRequestLocation: true,
                }
            );
        });
    }
};
