import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { _ } from 'lodash';
import * as yup from 'yup';
import { createSelector } from 'reselect';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { _state } from 'app/config/store';
import { ValidationHelper } from 'app/api/helperServices';
import { valueChanged, inspectionViolatorAdded, inspectionViolationsupdated, inspectionRemoveViolator } from 'app/actions/inspections';
import { isGenericTypeAnnotation } from '@babel/types';
import AbandonedVehicleConfig from 'app/components/Form/CommonForms/AbandonedVehicle/config';
import GeneralAppearanceVehicleConfig from 'app/components/Form/CommonForms/GeneralAppearanceVehicle/config';
import ResUnitOccupancyConfig from 'app/components/Form/CommonForms/ResUnitOccupancy/config';
import generalInfoConfig from 'app/components/Form/CommonForms/GeneralInfo/config';

let _allMainRoutes = undefined;
let _allInspectionRoutes = undefined;

export const initAllRoutesDefinitions = (mainRoutes, inspectionRouts) => {
    if (!_allMainRoutes) _allMainRoutes = mainRoutes;
    if (!_allInspectionRoutes) _allInspectionRoutes = inspectionRouts;
};

let helper = undefined;
const QUESTION_TYPES = { YesNo: 'YesNo', Checkbox: 'Checkbox' };
const CATEGORIES = { DISTORTION: 'DISTORTION', INFOREQUEST: 'INFOREQUEST', INSPECTION: 'INSPECTION' };

class InspectionsHelper {
    static instance = null;
    static _createInstance() {
        return new InspectionsHelper();
    }

    static getInstance() {
        if (!InspectionsHelper.instance) {
            InspectionsHelper.instance = InspectionsHelper._createInstance();
            helper = InspectionsHelper.instance;
        }
        return InspectionsHelper.instance;
    }
    createNew = userData => {
        const createdDate = moment();
        const domainCustomerId = _state.auth.activeProfileDomainCustomerId;
        return {
            createdDate: createdDate,
            refNumber: createdDate.format('YYYYMMDDHHmmssSSS'), //Todo: change his logic to create unique reference numbers that should work with smarthub
            visits: [
                // {
                //     visitDate: createdDate.subtract(15, 'days'),
                //     values: {}
                //     //todo: set visiting inspector
                // },
                {
                    visitDate: createdDate,
                    values: {},
                    visitedByDomainCustomerId: domainCustomerId,
                    //todo: set visiting inspector
                },
            ],
            createdByDomainCustomerId: domainCustomerId,
        };
    };
    getServiceCategory = createSelector(
        [state => state],
        selectedService => {
            const serviceMaster = _state.masterdata.services;
            let parentservicewithCategory = [];
            let findCategoryService = (serviceMaster, selectedService, parentservicewithCategory) => {
                // if (parentservicewithCategory.length > 0)
                //     return;
                if (selectedService.category) {
                    parentservicewithCategory.push(selectedService);

                    return true;
                }
                return serviceMaster.filter(o => {
                    if (o.serviceId === selectedService.parentServiceId) {
                        return findCategoryService(serviceMaster, o, parentservicewithCategory) > 0;
                    }
                    return false;
                });
            };
            findCategoryService(serviceMaster, selectedService, parentservicewithCategory);
            if (parentservicewithCategory.length > 0) {
                return parentservicewithCategory[0].category;
            }
            return null;
        }
    );
    getSelectedService = createSelector(
        [state => state],
        selectedService => {
            console.log('getSelectedService... getting service definition for id ', selectedService);
            const parentservice = _state.masterdata.services.filter(s => s.serviceId == selectedService);
            console.log('getSelectedService... parentservice', parentservice);
            if (parentservice.length > 0) {
                return parentservice[0];
            }
            return null;
        }
    );
    getPrimaryViolatorstype = (checklist, def, service) => {
        let ViolatorsType = this.getDistinctViolatorstype({ checklist, def, parentViolatorType: service.violatorType });
        if (ViolatorsType.length > 0) return ViolatorsType[0];
        else return undefined;
    };
    findDeselectedViolations = createSelector(
        [state => state.currentViolations, state => state.previousViolations],
        (currentViolations, previousViolations) => {
            var currentViolationsSize = currentViolations.length;
            var previousViolationsSize = previousViolations.length;
            // loop through previous Violations
            for (var j = 0; j < previousViolationsSize; j++) {
                // look for same thing in new Violations
                if (currentViolations.indexOf(previousViolations[j]) == -1) return previousViolations[j];
            }
            return null;
        }
    );
    getPreviouschecklistValues = (previousState, selectedVisitIndex) => {
        const state = previousState.inspections;
        return state.history[state.currentInspectionRef].inspection.visits[selectedVisitIndex].values;
    };
    getAllViolationsFromViolators = violators => {
        const allViolations = violators.reduce((allviolations, violator) => {
            if (violator.violations && violator.violations.length > 0) {
                violator.violations.map(vio => {
                    allviolations.push(vio);
                });
            }
            return allviolations;
        }, []);
        return allViolations;
    };
    getIsEditable = createSelector(
        [state => state],
        currentInspection => {
            if (currentInspection.inspection.locallySaved == true) return false;
            else return true;
        }
    );
    getIsServiceEditable = createSelector(
        [state => state],
        currentInspection => {
            if (currentInspection.inspection.inspectionID) return false;
            else return true;
        }
    );

    getChecklistActions = createSelector(
        [
            state => state.newValues,
            state => state.selectedVisitIndex,
            state => state.selectedService,
            state => state.currentInspectionContainer,
            state => state.previousState,
        ],
        (newValues, selectedVisitIndex, selectedService, currentInspectionContainer, previousState) => {
            let checkListActions = [
                valueChanged({
                    visitIndex: selectedVisitIndex,
                    newValues: newValues,
                }),
            ];
            const { inspection } = currentInspectionContainer;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            if (inspectionDefinition.type == 'checklist') {
                //setPrimaryViolatorstype
                let primaryViolatorstype;
                let ViolatorsType = this.getDistinctViolatorstype({
                    checklist: newValues,
                    def: inspectionDefinition.def,
                    parentViolatorType: selectedService[0].violatorType,
                });
                if (ViolatorsType.length > 0) primaryViolatorstype = ViolatorsType[0];

                const isCheckListWithCheckBox =
                    Object.getOwnPropertyNames(newValues).filter(code => newValues[code].selectedOption == true).length > 0;

                //setPrimaryViolatorstype
                if (primaryViolatorstype && (!inspection.info || !inspection.info.violators || inspection.info.violators.length == 0)) {
                    violations = this.getDistinctViolationsLawClause({
                        def: inspectionDefinition.def,
                        checklist: newValues,
                        violatorType: primaryViolatorstype,
                        parentViolatorType: selectedService[0].violatorType,
                    });
                    checkListActions.push(inspectionViolatorAdded(primaryViolatorstype, violations));
                }
                //update violations to existing violator
                else if (inspection.info && inspection.info.violators && inspection.info.violators.length === 1) {
                    let primaryViolatorstype = inspection.info.violators[0].violatorType;
                    newViolations = this.getDistinctViolationsLawClause({
                        def: inspectionDefinition.def,
                        checklist: newValues,
                        violatorType: primaryViolatorstype,
                        parentViolatorType: selectedService[0].violatorType,
                    });
                    //Remove violator
                    if (newViolations.length === 0) {
                        checkListActions.push(inspectionRemoveViolator(inspection.info.violators[0].UIIdentifier));
                    } else {
                        //Update Violations
                        checkListActions.push(inspectionViolationsupdated(newViolations, 0));
                    }
                } //remove violator if there is no violations
                else if (inspection.info && inspection.info.violators && inspection.info.violators.length > 1) {
                    // const previousViolations = inspection.info.violators.reduce((allviolations,violator) =>{
                    //     if(violator.violations&& violator.violations.length>0)
                    //     {
                    //         violator.violations.map((vio)=>{
                    //             allviolations.push(vio);
                    //         });
                    //     }
                    //     return allviolations;
                    // },[]);
                    const oldValue = this.getPreviouschecklistValues(previousState, selectedVisitIndex);
                    const previousViolations = Object.getOwnPropertyNames(oldValue).filter(code => {
                        if (oldValue[code].selectedOption == 'no' || oldValue[code].selectedOption == true) return true;
                        else return false;
                    });

                    const currentViolations = Object.getOwnPropertyNames(newValues).filter(code => {
                        if (newValues[code].selectedOption == 'no' || newValues[code].selectedOption == true) return true;
                        else return false;
                    });
                    const deselectedViolation = this.findDeselectedViolations({ previousViolations, currentViolations });
                    //Violations Removed
                    if (deselectedViolation && deselectedViolation.length > 0.0) {
                        inspection.info.violators.map((violator, violatorindex) => {
                            if (violator.violations) {
                                const i = this.getServiceByCode({ def: inspectionDefinition.def, code: deselectedViolation });
                                if (i) {
                                    const lawOptions = this.getLawClauseOptions(i.clauses);
                                    lawOptions.forEach(o => {
                                        const violationsIndex = violator.violations.find(v => v == o.id);
                                        if (violationsIndex != undefined) {
                                            //only one violation is remaining
                                            if (violator.violations.length == 1) {
                                                checkListActions.push(inspectionRemoveViolator(violator.UIIdentifier));
                                            } else {
                                                const newviolations = { ...violator }.violations.splice(violationsIndex, 1);
                                                checkListActions.push(inspectionViolationsupdated(newviolations, violatorindex));
                                            }
                                        }
                                    });
                                }

                                //
                            } else {
                                checkListActions.push(inspectionRemoveViolator(violator.UIIdentifier));
                            }
                            return violator;
                        });
                    }
                    //Violations Added
                    else if (previousViolations.length != currentViolations.length) {
                    }
                }
            }
            return checkListActions;
        }
    );
    validateDistrotionDetails = async ({ attachments, generalRemarks, address, inspection, distortionType }, validateDuplicates) => {
        const distrotionSchema = yup.object().shape({
            attachments: yup.array().required(),
            generalRemarks: yup.string().required(),
            address: yup.string().required(),
            distortionType: yup.string().required(),
        });
        let validationLogs = {};
        try {
            await ValidationHelper.validate(
                { attachments, generalRemarks, address, inspection, distortionType },
                distrotionSchema,
                validateDuplicates
            );
        } catch (errors) {
            validationLogs = errors;
        }
        return validationLogs;
    };

    validateInspectionDetails = async ({ generalRemarks, address, inspection, unAssignedItems }, validateDuplicates) => {
        const inspectionSchema = yup.object().shape({
            generalRemarks: yup.string().required(),
            address: yup.string().required(),
        });
        let validationLogs = {};
        try {
            await ValidationHelper.validate({ generalRemarks, address, inspection, unAssignedItems }, inspectionSchema, validateDuplicates);
        } catch (errors) {
            validationLogs = errors;
        }
        return validationLogs;
    };

    //Todo: remove if not used
    getParentService = selectedService => {
        const serviceMaster = _state.masterdata.services;
        let parentservice = [];
        let findparentService = (serviceMaster, selectedService, parentservice) => {
            if (!selectedService.parentServiceId) {
                parentservice.push(selectedService);
                return true;
            }
            return serviceMaster.filter(o => {
                if (o.serviceId === selectedService.parentServiceId) {
                    return findparentService(serviceMaster, o, parentservice) > 0;
                }
                return false;
            });
        };
        findparentService(serviceMaster, selectedService, parentservice);
        return parentservice[0];
    };

    getLongTitle = (inspectionContainer, showRefNumber, allServices) => {
        // console.log('getLongTitle, inspectionContainer -->');
        // console.log(inspectionContainer);
        const { service } = inspectionContainer.inspection;
        let serviceDef = service;
        if (service && allServices && allServices.length > 0) {
            serviceDef = _.find(allServices, { serviceId: service });
            if (!serviceDef) serviceDef = service;
        }

        let titleChain = '';
        if (serviceDef) {
            if (typeof serviceDef === 'object' && serviceDef !== null) {
                titleChain = helper._getTitleChain(serviceDef, allServices);
            } else {
                titleChain = `Service Id: ${serviceDef}`;
            }
        }

        const refNumber = showRefNumber
            ? `${!!service ? ' - ' : ''}${strings('referenceNumberShort')} ${inspectionContainer.inspection.refNumber}`
            : '';
        const title = `${titleChain}${refNumber}`;
        return title;
    };

    _getTitleChain = (selectedService, allServices, currentTitle) => {
        if (!selectedService) return currentTitle;
        else {
            const newTitle = `${localeProperty(selectedService, 'title')}${currentTitle ? ' - ' + currentTitle : ''}`;
            if (selectedService.parentServiceId !== undefined && allServices) {
                const parentService = _.find(allServices, {
                    serviceId: selectedService.parentServiceId,
                });
                return helper._getTitleChain(parentService, allServices, newTitle);
            } else return newTitle;
        }
    };

    getRoutes = () => {
        const state = _state;
        //console.log('getRoutes().getState().currentInspectionRef: ', _state.inspections.currentInspectionRef, 'state: ', _state);
        const currentInspectionContainer = _state.inspections.history[_state.inspections.currentInspectionRef];
        const currentInspection = currentInspectionContainer && currentInspectionContainer.inspection;
        if (!currentInspection) return [..._allInspectionRoutes.routes];
        return this.getRoutesSelector(currentInspection);
    };

    getRoutesSelector = createSelector(
        [state => state],
        currentInspection => {
            //console.log('getRoutes().currentInspection: ', currentInspection);
            let selectedService = _state.masterdata.services.find(s => s.serviceId == currentInspection.service);
            let adjustedRoutes = [..._allInspectionRoutes.routes];
            let selectedCategory = null;
            //first remove violatorDetails screen if violatorType is unknown
            if (selectedService && selectedService.violatorType == undefined) {
                adjustedRoutes = _.filter(adjustedRoutes, route => route.key != 'violatorDetails');
            }
            if (selectedService) selectedCategory = this.getServiceCategory(selectedService);
            const isCheckList =
                currentInspection.visits &&
                currentInspection.visits.length > 0 &&
                currentInspection.visits[0].def &&
                currentInspection.visits[0].def.type == 'checklist';
            //now check if we need duplicateCheck screen?
            if (
                !(
                    !isCheckList &&
                    selectedCategory != 'INSPECTION' &&
                    currentInspection.duplicateCheck &&
                    currentInspection.duplicateCheck.duplicateCantidates &&
                    currentInspection.duplicateCheck.duplicateCantidates.length > 0
                )
            ) {
                adjustedRoutes = _.filter(adjustedRoutes, route => route.key != 'duplicateCheck');
            }

            return adjustedRoutes;
        }
    );

    adjustRoutesForService = (allRoutes, selectedService) => {
        //Todo: if selected inspection def has no violator type, remove violatorDetails screen
        const adjustedRoutes =
            selectedService && selectedService.inspectionDef && selectedService.violatorType == undefined
                ? _.filter(allRoutes, route => route.key != 'violatorDetails')
                : [...allRoutes];
        return adjustedRoutes;
    };

    findItemDef = createSelector(
        [state => state.key, state => state.inspectionDef],
        (key, inspectionDef) => {
            if (!inspectionDef || !inspectionDef.checklistGroups) return;
            for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
                const grp = inspectionDef.checklistGroups[groupIndex];
                if (!grp.checklist) continue;
                const itemDef = _.find(grp.checklist, { code: key });
                if (itemDef) return { questionType: grp.questionType, itemDef };
            }
            return undefined;
        }
    );

    findQuestionType = createSelector(
        [state => state],
        inspectionDef => {
            let questionType;
            if (!inspectionDef || !inspectionDef.checklistGroups) return;
            for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
                const grp = inspectionDef.checklistGroups[groupIndex];
                if (!grp.checklist) continue;
                questionType = grp.questionType;
                if (questionType) return questionType;
            }
            return questionType;
        }
    );

    findItemDefFromLawClauses = createSelector(
        [state => state.lawClauseKey, state => state.inspectionDef],
        (lawClauseKey, inspectionDef) => {
            if (!inspectionDef || !inspectionDef.checklistGroups) return;
            for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
                const grp = inspectionDef.checklistGroups[groupIndex];
                if (!grp.checklist) continue;
                const connectedChecklist = grp.checklist.filter(c => {
                    if (c.clauses) return c.clauses.filter(l => l == lawClauseKey).length > 0;
                    else return false;
                });
                const itemDef = connectedChecklist[0];
                if (itemDef) return { questionType: grp.questionType, itemDef };
            }
            return undefined;
        }
    );
    getGeneralPreviewFormTitle = createSelector(
        [state => state],
        inspectionDef => {
            let formTitle = '';
            if (inspectionDef) {
                switch (inspectionDef.name) {
                    case 'abandonedVehicleInfo':
                        formTitle = localeProperty(AbandonedVehicleConfig, 'title');
                        break;
                    case 'generalAppearanceVehicleInfo':
                        formTitle = localeProperty(GeneralAppearanceVehicleConfig, 'title');
                        break;
                    case 'ResUnitOccupancyInfo':
                        formTitle = localeProperty(ResUnitOccupancyConfig, 'title');
                        break;
                    // case 'generalInfo':
                    //     formTitle = localeProperty(generalInfoConfig, 'title');
                    //     break;
                    default:
                        formTitle = 'unsupported form  ' + inspectionDef.name;
                        break;
                }
            }
            return formTitle;
            //localeProperty(inspectionDef, 'title');
        }
    );
    classifyAwarenessViolationWarningItems = createSelector(
        [state => state.inspection, state => state.inspectionDef, state => state.violators, state => state.duplicateCantidates],
        (inspection, inspectionDef, violators, duplicateCantidates) => {
            if (!inspection || !inspectionDef) return;
            if (inspectionDef.type != 'form') return;
            const violatorItems = [];
            if (inspectionDef.def && inspectionDef.def.length > 0) {
                if (inspection.info[inspectionDef.def[0].name] && inspection.info[inspectionDef.def[0].name].issueType) {
                    const actionType = inspection.info[inspectionDef.def[0].name].issueType;
                    const selectedPeriod = inspection.info[inspectionDef.def[0].name].duration.selectedPeriod;
                    const selectedPeriodType = inspection.info[inspectionDef.def[0].name].duration.selectedPeriodType;
                    violators.forEach(v => {
                        const awarenessItems = [],
                            warningItems = [],
                            violationItems = [];
                        if (v.violations)
                            v.violations.map(key => {
                                const duplicate = duplicateCantidates.filter(d => d.lawClausesID == key);
                                const violationAmount = this.getViolationAmount({ lawClauseIDs: [key], occurance: 1, discount: 0 });
                                const resultObj = {
                                    item: {
                                        violationAmount,
                                        selectedPeriod: selectedPeriod,
                                        selectedPeriodType: selectedPeriodType,
                                        selectedActionType: actionType,
                                    },
                                    duplicate: duplicate,
                                    lawClause: this.getLawClauseByClauseId(key),
                                };
                                switch (actionType) {
                                    case '1':
                                        awarenessItems.push(resultObj);
                                        break;
                                    case '2':
                                        warningItems.push(resultObj);
                                        break;
                                    case '3':
                                        violationItems.push(resultObj);
                                        break;
                                    case '4':
                                        warningItems.push(resultObj);
                                        break;
                                    case '5':
                                        violationItems.push(resultObj);
                                        break;
                                    default:
                                    //unknown type, ignore for now
                                }
                                return key;
                            });
                        violatorItems.push({ violatordetails: v, awarenessItems, warningItems, violationItems });
                        return v;
                    });
                    return { violatorItems };
                }
            }
            return { violatorItems: [] };
        }
    );

    classifyChecklistItems = createSelector(
        [state => state.items, state => state.inspectionDef, state => state.violators, state => state.duplicateCantidates],
        (items, inspectionDef, violators, duplicateCantidates) => {
            if (!items || !inspectionDef) return;
            if (inspectionDef.type != 'checklist') return;
            const complianceItems = [],
                unAssignedItems = [],
                violatorItems = [];
            let totalNumberOfAwareness = 0,
                totalViolationAmount = 0,
                totalNumberOfWarning = 0;
            Object.keys(items).forEach(key => {
                const item = items[key];
                const { questionType, itemDef } = helper.findItemDef({ key, inspectionDef: inspectionDef.def });
                if (itemDef) {
                    const result = helper.classifyChecklistItem({ questionType, item, itemDef, violators, key });
                    const resultObj = {
                        questionType: questionType,
                        item: item,
                        itemDef: itemDef,
                    };
                    // calculate total
                    const totalresult = helper.classifyViolationsItem({ questionType, item, itemDef, violators, key });
                    let increasecount = 1;
                    if (item.selectedLawClause && item.selectedLawClause.length > 0) {
                        increasecount = item.selectedLawClause.length;
                    }
                    switch (totalresult) {
                        case 'awareness':
                            totalNumberOfAwareness = totalNumberOfAwareness + increasecount;
                            break;
                        case 'warning':
                            totalNumberOfWarning = totalNumberOfWarning + increasecount;
                            break;
                        case 'violation':
                            totalViolationAmount = totalViolationAmount + item.violationAmount;
                            break;
                        default:
                        //unknown type, ignore for now
                    }
                    // calculate total
                    //console.log(`classifyChecklistItems... ${result} resultObj:`, resultObj);
                    switch (result) {
                        case 'compliance':
                            complianceItems.push(resultObj);
                            break;
                        case 'unassigned':
                            if (resultObj.item.selectedLawClause.length > 0) {
                                resultObj.item.selectedLawClause.forEach(key => {
                                    let finalresultObj = { ...resultObj };
                                    finalresultObj.lawClause = this.getLawClauseByClauseId(key);
                                    unAssignedItems.push(finalresultObj);
                                });
                            } else {
                                unAssignedItems.push(resultObj);
                            }
                            break;
                        default:
                        //unknown type, ignore for now
                    }
                }
            });
            violators.forEach(v => {
                const awarenessItems = [],
                    warningItems = [],
                    violationItems = [];
                if (v.violations)
                    v.violations.map(key => {
                        const { questionType, itemDef } = helper.findItemDefFromLawClauses({ lawClauseKey: key, inspectionDef: inspectionDef.def });
                        const item = items[itemDef.code];
                        if (itemDef) {
                            const result = helper.classifyViolationsItem({ questionType, item, itemDef, violators, key });
                            const duplicate = duplicateCantidates.filter(d => d.lawClausesID == key);
                            const resultObj = {
                                questionType: questionType,
                                item: item,
                                duplicate: duplicate,
                                lawClause: this.getLawClauseByClauseId(key),
                                itemDef: itemDef,
                            };
                            switch (result) {
                                case 'awareness':
                                    awarenessItems.push(resultObj);
                                    break;
                                case 'warning':
                                    warningItems.push(resultObj);
                                    break;
                                case 'violation':
                                    violationItems.push(resultObj);
                                    break;
                                default:
                                //unknown type, ignore for now
                            }
                        }
                        return key;
                    });
                violatorItems.push({ violatordetails: v, awarenessItems, warningItems, violationItems });
                return v;
            });

            return { complianceItems, unAssignedItems, violatorItems, totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning };
        }
    );

    classifyChecklistItem = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef, state => state.violators, state => state.key],
        (questionType, item, itemDef, violators, key) => {
            if (helper.checklistItemIsCompliance({ questionType, item, itemDef })) return 'compliance';
            if (helper.checklistItemIsUnAssigned({ questionType, item, violators, key })) return 'unassigned';
        }
    );
    classifyViolationsItem = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef, state => state.violators, state => state.key],
        (questionType, item, itemDef, violators, key) => {
            if (helper.checklistItemIsAwareness({ questionType, item, itemDef })) return 'awareness';
            if (helper.checklistItemIsWarning({ questionType, item, itemDef })) return 'warning';
            if (helper.checklistItemIsViolation({ questionType, item, itemDef })) return 'violation';
        }
    );
    checklistItemIsUnAssigned = createSelector(
        [state => state.questionType, state => state.item, state => state.violators, state => state.key],
        (questionType, item, violators, key) => {
            const assignedViolator = violators.filter(v => {
                return (
                    v.violations &&
                    v.violations.filter(a => {
                        if (item.selectedLawClause) return item.selectedLawClause.filter(sl => sl == a).length > 0;
                        else return false;
                    }).length > 0
                );
            });
            //dummy evaluation
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return item.selectedOption == 'no' && assignedViolator.length == 0;
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && assignedViolator.length == 0;
            }
            return false;
        }
    );

    checklistItemIsCompliance = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef],
        (questionType, item, itemDef) => {
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return item.selectedOption == 'yes';
                // case QUESTION_TYPES.Checkbox:
                //     return item.selectedOption == false;
            }
            return false;
        }
    );

    checklistItemIsAwareness = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef],
        (questionType, item, itemDef) => {
            //dummy evaluation
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return item.selectedActionType == 'awareness';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && item.selectedActionType == 'awareness';
            }
            return false;
        }
    );
    checklistItemIsWarning = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef],
        (questionType, item, itemDef) => {
            //dummy evaluation
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return item.selectedActionType == 'warning';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && item.selectedActionType == 'warning';
            }
            return false;
        }
    );
    checklistItemIsViolation = createSelector(
        [state => state.questionType, state => state.item, state => state.itemDef],
        (questionType, item, itemDef) => {
            //dummy evaluation
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return item.selectedActionType == 'violations';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && item.selectedActionType == 'violations';
            }
            return false;
        }
    );

    getViolatorHeading = createSelector(
        [state => state.text, state => state.violatorType, state => state.violatordetails],
        (text, violatorType, violatordetails) => {
            let violatorHeading = strings('new') + ' ' + text;
            if (violatorType == 'company') {
                const companyInfo = violatordetails['company'];
                if (violatordetails['company'] && localeProperty(companyInfo, 'companyName'))
                    violatorHeading = localeProperty(companyInfo, 'companyName');
            } else if (violatorType == 'building') {
                const buildingInfo = violatordetails['building'];
                if (violatordetails['building'] && buildingInfo.buildingName) violatorHeading = buildingInfo.buildingName;
            } else if (violatorType == 'individual') {
                const individualInfo = violatordetails['violator'];
                if (violatordetails['violator'] && (individualInfo.nameE || individualInfo.nameA))
                    violatorHeading = localeProperty(individualInfo, 'name');
            }
            return violatorHeading;
        }
    );
    getDistinctViolatorstype = createSelector(
        [state => state.checklist, state => state.def, state => state.parentViolatorType],
        (checklist, def, parentViolatorType) => {
            let ViolatorsType = [];
            Object.getOwnPropertyNames(checklist).map(code => {
                if (checklist[code].selectedOption == true) {
                    ViolatorsType = parentViolatorType.split(',');
                } else if (checklist[code].selectedOption == 'no') {
                    let selectedServiceviolatorType = this.getServiceviolatorType({ def, parentViolatorType, code });
                    if (selectedServiceviolatorType && ViolatorsType.find(v => v == selectedServiceviolatorType) == undefined) {
                        ViolatorsType.push(selectedServiceviolatorType);
                    }
                }
            });
            return ViolatorsType;
        }
    );

    getViolationsOptionsByViolatorsType = createSelector(
        [
            state => state.selectedService,
            state => state.checklist,
            state => state.def,
            state => state.violatorType,
            state => state.parentViolatorType,
        ],
        (selectedService, checklist, def, violatorType, parentViolatorType) => {
            let ViolatorLawClausesOptions = [];
            if (selectedService.inspectionDef.type == 'checklist') {
                Object.getOwnPropertyNames(checklist).map(code => {
                    if (checklist[code].selectedOption == true) {
                        const lawOptions = this.getLawClauseOptions(checklist[code].selectedLawClause, code);
                        lawOptions.forEach(o => {
                            if (!ViolatorLawClausesOptions.find(l => l.id == o.id)) {
                                ViolatorLawClausesOptions.push(o);
                            }
                        });
                    } else if (checklist[code].selectedOption == 'no') {
                        let selectedServiceviolatorType = this.getServiceviolatorType({ def, parentViolatorType, code });
                        if (selectedServiceviolatorType && selectedServiceviolatorType == violatorType) {
                            // const i = this.getServiceByCode(def, code);
                            // if (i) {
                            if (checklist[code].selectedLawClause && checklist[code].selectedLawClause.length > 0) {
                                const lawOptions = this.getLawClauseOptions(checklist[code].selectedLawClause, code);
                                lawOptions.forEach(o => {
                                    if (!ViolatorLawClausesOptions.find(l => l.id == o.id)) {
                                        ViolatorLawClausesOptions.push(o);
                                    }
                                });
                            }
                            // if (i) {
                            //     const selection = i.code;
                            //     const question = localeProperty(i, 'question') || 'Unknown question';
                            //     ViolatorLawClausesOptions.push({ title: question, id: selection });
                            // }
                        }
                    }
                });
            } else {
                return this.getLawClauseOptions(selectedService.clauses);
            }
            return ViolatorLawClausesOptions;
        }
    );

    getRemainingViolationsForSelectOptions = (violationsOptions, violators, selectedItems) => {
        let filteredViolatorsOptions = [];
        const allAllocatedViolations = this.getAllViolationsFromViolators(violators);
        violationsOptions.map(v => {
            if (allAllocatedViolations.indexOf(v.id) == -1) filteredViolatorsOptions.push(v);
            if (selectedItems && selectedItems.indexOf(v.id) > -1) filteredViolatorsOptions.push(v);
            return true;
        });
        return filteredViolatorsOptions;
    };

    getDistortionTypeOptions(pickerOptions) {
        const distortionTypesMaster = _state.masterdata.distortionTypes;
        distortionTypesMaster.map(distortionType => {
            pickerOptions.push({
                labelE: distortionType.titleE,
                labelA: distortionType.titleA,
                value: distortionType.serviceId,
            });
        });
        return pickerOptions;
    }

    getDistortionTypeDefaultValue() {
        const distortionTypesMaster = _state.masterdata.distortionTypes;
        if (distortionTypesMaster.length > 0) {
            return distortionTypesMaster[0].serviceId;
        }
        return '';
    }
    getDistortionTypeTitle(distortionTypeId) {
        const distortionTypesMaster = _state.masterdata.distortionTypes;
        const distortionType = distortionTypesMaster.filter(d => d.value == distortionTypeId);
        if (distortionType.length > 0) {
            return localeProperty(distortionType[0], 'label') || 'Unknown Distortion Type';
        }
        return '';
    }

    getPickerOptions(pickerName) {
        let pickerOptions = [];
        if (pickerName == 'distortionType') {
            this.getDistortionTypeOptions(pickerOptions);
        }
        return pickerOptions;
    }

    getLawClauseOptions = createSelector(
        [state => state],
        lawClauses => {
            let lawClausesOptions = [];
            const lawClausesMaster = _state.masterdata.lawClauses;
            lawClauses.map(code => {
                const masterLawClause = lawClausesMaster.find(law => law.clauseId == code);
                if (masterLawClause) {
                    const lawdescription = localeProperty(masterLawClause, 'description') || 'Unknown law';
                    lawClausesOptions.push({
                        title: lawdescription,
                        id: code,
                        mandatoryAwarenes: masterLawClause.mandatoryAwarenes,
                        mandatoryWarning: masterLawClause.mandatoryWarning,
                        minimumNoOfAwareness: masterLawClause.minimumNoOfAwareness,
                        minimumNoOfWarning: masterLawClause.minimumNoOfWarning,
                    });
                }
            });
            return lawClausesOptions;
        }
    );

    getLawClauseByClauseId = createSelector(
        [state => state],
        lawClauseId => {
            const lawClausesMaster = _state.masterdata.lawClauses;
            return lawClausesMaster.find(law => law.clauseId == lawClauseId);
        }
    );

    getNewViolationAmount = createSelector(
        [state => state.fineType, state => state.occuranceFine, state => state.masteroccurance],
        (fineType, occuranceFine, masteroccurance) => {
            let newAmount = 0;
            if (fineType == 'fixed') {
                newAmount = occuranceFine.amount;
            } else if (fineType == 'multiple') {
                newAmount = masteroccurance.amount * occuranceFine.multiplier;
            }
            return newAmount;
        }
    );
    getViolationAmount = createSelector(
        [state => state.lawClauseIDs, state => state.occurance, state => state.discount],
        (lawClauseIDs, occurance, discount) => {
            let violationamount = 0;
            const lawClausesMaster = _state.masterdata.lawClauses;
            lawClauseIDs.map(code => {
                const masterLawClause = lawClausesMaster.find(law => law.clauseId == code);
                if (masterLawClause) {
                    const occuranceFine = masterLawClause.fines.find(f => f.occurance == occurance);
                    const masteroccurance = masterLawClause.fines.find(f => f.occurance == -1);
                    let newAmount = 0;
                    if (!occuranceFine) {
                        const defaultoccurance = masterLawClause.fines.find(f => f.occurance == 0);
                        if (defaultoccurance)
                            newAmount = this.getNewViolationAmount({
                                fineType: defaultoccurance.fineType,
                                occuranceFine: defaultoccurance,
                                masteroccurance: masteroccurance,
                            });
                        else
                            newAmount = this.getNewViolationAmount({
                                fineType: masteroccurance.fineType,
                                occuranceFine: masteroccurance,
                                masteroccurance: masteroccurance,
                            });
                    } else {
                        newAmount = this.getNewViolationAmount({
                            fineType: occuranceFine.fineType,
                            occuranceFine: occuranceFine,
                            masteroccurance: masteroccurance,
                        });
                    }
                    violationamount = violationamount + newAmount;
                }
            });
            if (discount > 0) {
                const discoutedAmount = violationamount * (discount / 100);
                violationamount = violationamount - discoutedAmount;
            }
            return violationamount;
        }
    );
    getServiceviolatorType = createSelector(
        [state => state.def, state => state.parentViolatorType, state => state.code],
        (def, parentViolatorType, wantedCode) => {
            //used only for services having inspectionDef.type == checklist
            for (var groupIndex = 0; groupIndex < def.checklistGroups.length; groupIndex++) {
                const groupDef = def.checklistGroups[groupIndex];
                const checklistItem = _.find(groupDef.checklist, { code: wantedCode });
                if (checklistItem) return checklistItem.violatorType || groupDef.violatorType || parentViolatorType;
            }
            return undefined;
        }
    );
    getServiceByCode = createSelector(
        [state => state.def, state => state.code],
        (def, wantedCode) => {
            for (var groupIndex = 0; groupIndex < def.checklistGroups.length; groupIndex++) {
                const groupDef = def.checklistGroups[groupIndex];
                const checklistItem = _.find(groupDef.checklist, { code: wantedCode });
                if (checklistItem) return checklistItem;
            }
            return undefined;
        }
    );
    arrayUnique = array => {
        var a = array.concat();
        for (var i = 0; i < a.length; ++i) {
            for (var j = i + 1; j < a.length; ++j) {
                if (a[i] === a[j]) a.splice(j--, 1);
            }
        }
        return a;
    };

    getDistinctViolationsLawClause = createSelector(
        [state => state.def, state => state.checklist, state => state.violatorType, state => state.parentViolatorType],
        (def, checklist, violatorType, parentViolatorType) => {
            let violationsLawClause = [];
            Object.getOwnPropertyNames(checklist).map(code => {
                if (checklist[code].selectedOption == 'no') {
                    let selectedServiceviolatorType = this.getServiceviolatorType({ def, parentViolatorType, code });
                    if (selectedServiceviolatorType == violatorType) {
                        // const i = this.getServiceByCode(def, code);
                        if (checklist[code].selectedLawClause) {
                            violationsLawClause = this.arrayUnique(violationsLawClause.concat(checklist[code].selectedLawClause));
                        }
                    }
                } else if (checklist[code].selectedOption == true) {
                    violationsLawClause = this.arrayUnique(violationsLawClause.concat(checklist[code].selectedLawClause));
                }
            });
            return violationsLawClause;
        }
    );

    getAllDistinctViolationsLawClause = createSelector(
        [state => state],
        checklist => {
            let violationsLawClause = [];
            Object.getOwnPropertyNames(checklist).map(code => {
                if (checklist[code].selectedOption == 'no' || checklist[code].selectedOption == true) {
                    if (checklist[code].selectedLawClause) {
                        violationsLawClause = this.arrayUnique(violationsLawClause.concat(checklist[code].selectedLawClause));
                    }
                }
            });
            return violationsLawClause;
        }
    );

    getAllDistinctViolatorsViolationsLawClause = createSelector(
        [state => state],
        inspection => {
            let violationsLawClause = [];
            inspection.info.violators.map(violator => {
                if (violator.violations) {
                    violationsLawClause = this.arrayUnique(violationsLawClause.concat(violator.violations));
                }
            });
            return violationsLawClause;
        }
    );

    getAllViolatorsWithValidDetails = createSelector(
        [state => state],
        inspection => {
            let violatorsWithValidDetails = [];
            inspection.info.violators.map(violator => {
                switch (violator.violatorType) {
                    case 'company':
                        if (
                            violator.company &&
                            violator.company.tradeLicenseNumber &&
                            (violator.company.companyNameA || violator.company.companyNameE) &&
                            violator.company.phoneNumber
                        ) {
                            violatorsWithValidDetails.push(violator);
                        }
                        break;
                    case 'building':
                        if (violator.building && violator.building.buildingNumber && violator.building.buildingName) {
                            violatorsWithValidDetails.push(violator);
                        }
                        break;
                    case 'individual':
                        if (
                            violator.violator &&
                            violator.violator.uaeId &&
                            violator.violator.expiryDate &&
                            violator.violator.firstName &&
                            violator.violator.nationality &&
                            violator.violator.birthDate
                        ) {
                            violatorsWithValidDetails.push(violator);
                        }
                        break;
                    default:
                        break;
                }
            });
            return violatorsWithValidDetails;
        }
    );

    canCreateInspectionRecord = (state, payload) => {
        const checkingState = state ? state : _state.inspections;
        const checkingPayload = payload ? payload : {};
        const inspectionContainer = checkingState.history[checkingState.currentInspectionRef];
        return this.canStartInspectionRecord({ inspectionContainer, currentInspectionRef: checkingState.currentInspectionRef });
    };

    canStartInspectionRecord = createSelector(
        [state => state.inspectionContainer, state => state.currentInspectionRef],
        (inspectionContainer, currentInspectionRef) => {
            if (!(inspectionContainer && inspectionContainer.inspection))
                return { canCreateInspection: false, reason: 'Inspection Not Available', refNumber: currentInspectionRef };
            if (!(inspectionContainer.inspection.location && inspectionContainer.inspection.location.coords)) {
                return { canCreateInspection: false, reason: 'location Not Available', refNumber: currentInspectionRef };
            }
            if (inspectionContainer.inspection.inspectionID) {
                return { canCreateInspection: false, reason: 'Inspection Already created', refNumber: currentInspectionRef };
            }
            return { canCreateInspection: true, reason: 'All Values are aviable for Create Inspection', refNumber: currentInspectionRef };
        }
    );

    canCheckCheckListDuplicate = createSelector(
        [state => state.inspectionContainer, state => state.currentInspectionRef],
        (inspectionContainer, currentInspectionRef) => {
            const { inspection } = inspectionContainer;
            const selectedVisitIndex = inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            let violations;
            if (inspectionDefinition.type == 'checklist' || inspectionDefinition.type == 'form') {
                if (!inspection.info || !inspection.info.violators || inspection.info.violators.length == 0) {
                    return {
                        canCheckDuplicate: false,
                        reason: 'No violators Available For Duplicate Checking',
                        refNumber: currentInspectionRef,
                    };
                }
                if (inspectionDefinition.type == 'checklist') {
                    const selectedServiceFirst = _.find(_state.masterdata.services, { serviceId: inspectionContainer.inspection.service });
                    let ViolatorsType = this.getDistinctViolatorstype({
                        checklist: selectedVisitValues,
                        def: inspectionDefinition.def,
                        parentViolatorType: selectedServiceFirst.violatorType,
                    });
                    if (ViolatorsType.length == 0) {
                        return {
                            canCheckDuplicate: false,
                            reason: 'No Violations For Duplicate Checking',
                            refNumber: currentInspectionRef,
                        };
                    }
                    violations = this.getAllDistinctViolationsLawClause(selectedVisitValues);
                    if (violations.length == 0) {
                        return {
                            canCheckDuplicate: false,
                            reason: 'No Violations LawClause Available For Duplicate Checking',
                            refNumber: currentInspectionRef,
                        };
                    }
                }
                const violatorsWithValidDetails = this.getAllViolatorsWithValidDetails(inspection);
                if (violatorsWithValidDetails.length != inspection.info.violators.length)
                    return {
                        canCheckDuplicate: false,
                        reason: 'Some Violators Do Not Have Valid Details',
                        refNumber: currentInspectionRef,
                    };

                const violatorsViolations = this.getAllDistinctViolatorsViolationsLawClause(inspection);
                if (violatorsViolations.length == 0) {
                    return {
                        canCheckDuplicate: false,
                        reason: 'No violators Violations LawClause Available For Duplicate Checking',
                        refNumber: currentInspectionRef,
                    };
                }
                if (inspectionDefinition.type == 'checklist' && violatorsViolations.length == violations.length && inspection.inspectionID) {
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
                }
                if (inspectionDefinition.type == 'form' && violatorsViolations.length > 0 && inspection.inspectionID) {
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
                }
            }
            return {
                canCheckDuplicate: false,
                reason: 'All Values Not Available for checking Duplicate',
                refNumber: currentInspectionRef,
            };
        }
    );
    canCheckDuplicate = (state, payload, actionName) => {
        const checkingState = state ? state : _state.inspections;
        const checkingPayload = payload ? payload : {};
        const inspectionContainer = checkingState.history[checkingState.currentInspectionRef];

        if (!(inspectionContainer && inspectionContainer.inspection))
            return { canCheckDuplicate: false, reason: 'Inspection Not Available', refNumber: checkingState.currentInspectionRef };
        if (actionName == 'selectService') {
            const selectedCategory = this.getServiceCategory(checkingPayload);
            if (selectedCategory == 'DISTORTION' && inspectionContainer.inspection.location && inspectionContainer.inspection.location.coords) {
                return { canCheckDuplicate: true, reason: undefined, refNumber: checkingState.currentInspectionRef };
            } else if (selectedCategory == 'INSPECTION') {
            } else return { canCheckDuplicate: false, reason: 'location Not Available', refNumber: checkingState.currentInspectionRef };
        } else if (actionName == 'coordsChanged') {
            if (_state.masterdata.services && inspectionContainer && inspectionContainer.inspection && inspectionContainer.inspection.service) {
                const selectedService = _.find(_state.masterdata.services, { serviceId: inspectionContainer.inspection.service });
                const selectedCategory = this.getServiceCategory(selectedService);
                if (selectedCategory == 'DISTORTION' && inspectionContainer.inspection.inspectionID)
                    return { canCheckDuplicate: true, reason: undefined, refNumber: checkingState.currentInspectionRef };
                else if (selectedCategory == 'INSPECTION' && inspectionContainer.inspection.inspectionID) {
                    return this.canCheckCheckListDuplicate({ inspectionContainer, currentInspectionRef: checkingState.currentInspectionRef });
                }
            }
        } else if (actionName == undefined) {
            const canStartApiCall = this.canStartDuplicateCheck({ inspectionContainer, currentInspectionRef: checkingState.currentInspectionRef });
            if (canStartApiCall) return canStartApiCall;
        }
        return { canCheckDuplicate: false, reason: 'All Values Not Available for checking Duplicate', refNumber: checkingState.currentInspectionRef };
    };

    canStartDuplicateCheck = createSelector(
        [state => state.inspectionContainer, state => state.currentInspectionRef],
        (inspectionContainer, currentInspectionRef) => {
            const selectedService = _state.masterdata.services.find(s => s.serviceId == inspectionContainer.inspection.service);
            if (!selectedService) return { canCheckDuplicate: false, reason: 'Service Not Available', refNumber: currentInspectionRef };
            const selectedCategory = this.getServiceCategory(selectedService);
            if (selectedCategory == 'DISTORTION') {
                if (!(inspectionContainer.inspection.location && inspectionContainer.inspection.location.coords)) {
                    return { canCheckDuplicate: false, reason: 'location Not Available', refNumber: currentInspectionRef };
                }
                if (
                    _state.masterdata.services &&
                    inspectionContainer &&
                    inspectionContainer.inspection &&
                    inspectionContainer.inspection.service &&
                    inspectionContainer.inspection.inspectionID
                )
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
            } else if (selectedCategory == 'INSPECTION') {
                return this.canCheckCheckListDuplicate({ inspectionContainer, currentInspectionRef: currentInspectionRef });
            }
            return null;
        }
    );
    getViolators = createSelector(
        [state => state],
        inspectionContainer => {
            if (
                inspectionContainer &&
                inspectionContainer.inspection &&
                inspectionContainer.inspection.info &&
                inspectionContainer.inspection.info.violators
            ) {
                return inspectionContainer.inspection.info.violators;
            }
        }
    );

    getDuplicateCheckRequestModel = (state, payload, refNumber) => {
        const checkingState = state ? state : _state.inspections;
        const checkingPayload = payload ? payload : {};
        const inspectionContainer = checkingState.history[checkingState.currentInspectionRef];
        return this.getDuplicateCheckRequestModelSelector({ inspectionContainer, refNumber });
    }; //Todo: create the model to be sent to api

    getDuplicateCheckRequestModelSelector = createSelector(
        [state => state.inspectionContainer, state => state.refNumber],
        (inspectionContainer, refNumber) => {
            const selectedService = _state.masterdata.services.find(s => s.serviceId == inspectionContainer.inspection.service);
            const selectedCategory = this.getServiceCategory(selectedService);
            let inspectionDefType;
            if (selectedService && selectedService.inspectionDef && selectedService.inspectionDef.type) {
                inspectionDefType = selectedService.inspectionDef.type;
            }
            const questionType = this.findQuestionType(selectedService.inspectionDef.def);
            //  const selectedService = _.find(_state.masterdata.services, { serviceId: inspectionContainer.inspection.service });
            return {
                refNumber,
                selectedCategory,
                serviceId: inspectionContainer.inspection.service,
                inspectionDefType: inspectionDefType,
                questionType,
            };
        }
    );

    getInspectionHistoryForLoggedInUser = createSelector(
        [state => state.domainCustomerId, state => state.allHistory],
        (domainCustomerId, allHistory) => {
            const currentUserHistory = {};
            //console.log('getInspectionHistoryForLoggedInUser... domainCustomerId: ', domainCustomerId, 'allHistory: ', allHistory);
            Object.keys(allHistory).map(key => {
                const theInspectionContainer = allHistory[key];
                if (theInspectionContainer && theInspectionContainer.inspection.createdByDomainCustomerId === domainCustomerId) {
                    currentUserHistory[key] = theInspectionContainer;
                }
                //return theInspectionContainer;
            });
            //console.log('currentUserHistory: ', currentUserHistory);
            return currentUserHistory;
        }
    );

    getInspectionRequestModel = refNumber => {
        return refNumber;
    }; //Todo: create the model to be sent to api
}
export default InspectionsHelper.getInstance();
