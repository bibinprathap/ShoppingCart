import { Liquid } from 'liquidjs';
import { _ } from 'lodash';

let liquidEngine = new Liquid();

liquidEngine.registerFilter('isProbablyArabic', str => {
    for (i = 0; i < str.length; i++) {
        c = str.codePointAt(i);
        if (c >= 0x0600 && c <= 0x06e0) {
            return true;
        }
    }
    return false;
});

liquidEngine.registerFilter(
    'getHeight',
    (str, languageLineHeight, maxCharactersPerLine) => languageLineHeight * Math.ceil((str && str.length) / maxCharactersPerLine)
);

liquidEngine.registerFilter('getLines', (str, languageLineHeight) => Math.ceil((str && str.length) / languageLineHeight));

liquidEngine.registerFilter('getProbableNoOfLinesForViolations', (violations, fBuffer, maxCharactersPerLine) => {
    let probableNoOfLinesForViolations = 1;
    _.forEach(violations, function(violation) {
        if (violation.length > 0) {
            probableNoOfLinesForViolations += fBuffer * Math.ceil(violation.length / maxCharactersPerLine);
        }
    });
    return probableNoOfLinesForViolations;
});

liquidEngine.registerFilter('getProbableNoOfLinesForViolatorDetails', (violatorDetailsStringList, maxCharactersPerLine) => {
    let probableNoOfLinesForViolatorDetails = 1;
    _.forEach(violatorDetailsStringList, function(violationDetail) {
        let violatorDetailsSplit = violationDetail.split(' : ');
        if (violatorDetailsSplit.length > 1) {
            probableNoOfLinesForViolatorDetails += 1 + Math.ceil(violatorDetailsSplit[0].length / maxCharactersPerLine);
        }
    });
    return probableNoOfLinesForViolatorDetails;
});

liquidEngine.registerFilter('getProbableNoOfLinesForNote', (note, lineHeight, fBuffer) => {
    let probableNoOfLinesForNote = 1;
    if (note) {
        const noteSplit = note.split('\n');
        _.forEach(noteSplit, function(line) {
            probableNoOfLinesForNote += 2 + Math.ceil(noteSplit.length / lineHeight) * fBuffer;
        });
    }
    return probableNoOfLinesForNote;
});

liquidEngine.registerFilter('getNoteArray', note => {
    if (note) {
        const notesArray = [];
        const noteSplit = note.split('\n');
        _.forEach(noteSplit, function(line) {
            notesArray.push(_.trim(line));
        });
        return notesArray;
    }
});

liquidEngine.registerFilter('englishToArabicNumberConversion', note => {
    if (typeof englishNumber === 'undefined') {
        return;
    }
    if (englishNumber && typeof englishNumber !== 'string') {
        englishNumber = englishNumber.toString();
    }
    const arabicChars = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    let arString = '';
    for (i = 0; i < englishNumber.length; i++) {
        let num = parseInt(englishNumber.charAt(i));
        if (Number.isInteger(num)) {
            arString += arabicChars[num];
        } else {
            arString += englishNumber.charAt(i);
        }
    }
    return arString;
});

export default liquidEngine;
