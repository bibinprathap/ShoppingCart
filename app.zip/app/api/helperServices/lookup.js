import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import { store } from 'app/config/store';

class lookupHelper {
    static instance = null;
    static _createInstance() {
        return new lookupHelper();
    }

    static getInstance() {
        if (!this.instance) {
            lookupHelper.instance = lookupHelper._createInstance();
        }
        return lookupHelper.instance;
    }

    getAllLookup = () => {
        return (store.getState() && store.getState().masterdata && store.getState().masterdata.dataLookups) || {};
    };

    getList = (fieldName, parentId, parentType) => {
        if (parentType && parentId !== 0 && typeof parentId !== 'undefined') {
            return this.getAllLookup()[parentType].find(k => k.id == parentId)[fieldName];
        } else {
            return this.getAllLookup()[fieldName];
        }
    };

    getLabel = (fieldName, id, parentPicker, parentValue) => {
        let foundItem = {};
        if (parentPicker) {
            if (parentValue) {
                const parentfountItem = this.getAllLookup()[parentPicker].find(data => data.id == parentValue);
                if (parentfountItem && parentfountItem[fieldName]) {
                    foundItem = parentfountItem[fieldName].find(data => data.id == id);
                }
            }
        } else {
            foundItem = this.getAllLookup()[fieldName].find(data => data.id == id);
        }
        //_.find(this.getAllLookup(), data => data.type === fieldName && data.id == id);
        return foundItem && Object.getOwnPropertyNames(foundItem).length ? localeProperty(foundItem, 'label') : '';
    };

    getOption = (fieldName, id, parentPicker, parentValue) => {
        const foundItem = this.getAllLookup()
            [parentPicker].find(data => data.id == parentValue)
            [fieldName].find(data => data.id == id);
        //_.find(this.getAllLookup(), data => data.type === fieldName && data.id == id);
        return foundItem;
    };
    getRootType = (m, orginalData) => {
        let element = orginalData.find(d => d.id == m.parentId && (!m.parentType || m.parentType == d.type));
        let pathArray = [{ type: element.type, id: element.id }];
        while (element.parentId) {
            element = orginalData.find(d => d.id == element.parentId && (!element.parentType || element.parentType == d.type));
            pathArray.push({ type: element.type, id: element.id });
        }
        return { pathArray, parentType: element.type };
    };
    getNewMasterData = (data, newMasterData, remainingItems, orginalData) => {
        data.map(m => {
            if (!m.parentId) {
                if (!newMasterData[m.type]) newMasterData[m.type] = [m];
                else {
                    newMasterData[m.type].push(m);
                }
            } else {
                const parentsDetails = this.getRootType(m, orginalData);
                const parentMasterType = parentsDetails.parentType;
                let parentItemDetails = newMasterData[parentMasterType];
                if (!parentItemDetails) {
                    remainingItems.push(m);
                } else {
                    let parentMasterData = parentItemDetails.find(d => d.id == m.parentId);
                    if (parentsDetails.pathArray.length > 1) {
                        parentsDetails.pathArray.reverse().map((p, i) => {
                            if (parentItemDetails) {
                                const newvalue = parentItemDetails.find(d => d.id == p.id && d.type == p.type);
                                if (newvalue && parentsDetails.pathArray[i + 1]) {
                                    parentItemDetails = newvalue[parentsDetails.pathArray[i + 1].type];
                                }
                            }
                        });
                        parentMasterData = parentItemDetails.find(d => d.id == m.parentId);
                    }
                    if (!parentMasterData[m.type]) parentMasterData[m.type] = [m];
                    else {
                        parentMasterData[m.type].push(m);
                    }
                }
            }
        });
    };

    getMasterDataFromResponse = ({ dataLookupdataJson, ...params }) => {
        const oldMasterData = JSON.parse(dataLookupdataJson);
        var rootDatalokups = Array.from(new Set(oldMasterData.map(a => a.type)));
        const newMasterData = rootDatalokups.reduce((t, a) => {
            t[a] = oldMasterData.filter(o => o.type == a);
            return t;
        }, {});

        return { dataLookups: newMasterData, ...params };

        //     const newMasterData = {};
        //     const compareAsc = (a, b) => {
        //         if (a.parentId) {
        //             return 0;
        //         }

        //         return -1;
        //     };
        //     let remainingItems = [];
        //     // k.type != 'category' &&
        //     // k.type != 'emirate' &&
        //     // k.type != 'emirate' &&
        //     // k.type != 'agency' &&
        //     // k.type != 'distortionType' &&
        //     // k.type != 'isCritical' &&
        //     // k.type != 'issueType' &&
        //     // k.type != 'period' &&
        //     // k.type != 'buildingType' &&
        //     // k.type != 'followupAction' &&
        //     // k.type != 'selectedActionType'
        //     // && k.type != 'VehicleColor' && k.type != 'PlateKind' && k.type != 'PlateColor'
        //     const newdataLookups = dataLookups;
        //     //dataLookups.filter(k => k.type != 'VehicleMake' && k.type != 'VehicleModel');
        //this.getNewMasterData(newdataLookups.sort(compareAsc), newMasterData, remainingItems, newdataLookups);
        //     let i = 0;
        //     while (remainingItems.length > 0) {
        //         const newRemainingItems = [];
        //         this.getNewMasterData(remainingItems, newMasterData, newRemainingItems, newdataLookups);
        //         remainingItems = newRemainingItems;
        //         i++;
        //         if (i > 15) remainingItems = [];
        //     }
    };
}

// const entities = [
//     {
//         const: 'AWQAF',
//         nameE: 'General Authority of Islamic Affairs & Endowments - Awqaf',
//         nameA: 'الهيئة العامة للشؤون الاسلامية والأوقاف',
//     },
//     {
//         const: 'ADAFSA',
//         nameE: 'Abu Dhabi Agriculture & Food Safety Authority',
//         nameA: 'هيئة أبوظبي للزراعة والسلامة الغذائية',
//     },
//     {
//         const: 'ADSSC',
//         nameE: 'Abu Dhabi Sewerage Services Company',
//         nameA: 'شركة أبوظبي لخدمات الصرف الصحي',
//     },
//     {
//         const: 'EA',
//         nameE: 'Environment Agency - Abu Dhabi',
//         nameA: 'هيئة البيئة - أبوظبي',
//     },
//     {
//         const: 'ITC',
//         nameE: 'Integrated Transport Center',
//         nameA: 'مركز النقل المتكامل',
//     },
//     {
//         const: 'ADDC',
//         nameE: 'Abu Dhabi Distribution Co.',
//         nameA: 'شركة أبوظبي للتوزيع',
//     },
//     {
//         const: 'ADM',
//         nameE: 'Abu Dhabi City Municipality',
//         nameA: 'بلدية مدينة أبوظبي',
//     },
//     {
//         const: 'TADWEER',
//         nameE: 'Tadweer',
//         nameA: 'تدوير',
//     },
// ];
export default lookupHelper.getInstance();
