import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import { store } from 'app/config/store';

class lookupHelper {
    static instance = null;
    static _createInstance() {
        return new lookupHelper();
    }

    static getInstance() {
        if (!this.instance) {
            lookupHelper.instance = lookupHelper._createInstance();
        }
        return lookupHelper.instance;
    }

    getAllLookup = () => {
        return (store.getState() && store.getState().masterdata && store.getState().masterdata.dataLookups) || [];
    };

    getList = (fieldName, parentId) => {
        if (parentId !== 0 && typeof parentId !== 'undefined') {
            return _.filter(this.getAllLookup(), data => data.type === fieldName && data.parentId === parentId);
        } else {
            return _.filter(this.getAllLookup(), data => data.type === fieldName);
        }
    };

    getLabel = (fieldName, id) => {
        const foundItem = _.find(this.getAllLookup(), data => data.type === fieldName && data.id == id);
        return foundItem ? localeProperty(foundItem, 'label') : '';
    };
}

export default lookupHelper.getInstance();
