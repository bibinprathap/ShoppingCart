import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';

import { dataLookups } from 'app/api/mockData';

class lookupHelper {
    static instance = null;
    static _createInstance() {
        return new lookupHelper();
    }

    static getInstance() {
        if (!this.instance) {
            lookupHelper.instance = lookupHelper._createInstance();
        }
        return lookupHelper.instance;
    }

    getList = (fieldName, parentId) => {
        if (parentId !== null) {
            return _.filter(dataLookups, data => data.type === fieldName && data.parentId == parentId);
        } else {
            return _.filter(dataLookups, data => data.type === fieldName);
        }
    };

    getLabel = (fieldName, id) => {
        const foundItem = _.find(dataLookups, { type: fieldName, value: id });
        return localeProperty(foundItem, 'label');
    };
}

export default lookupHelper.getInstance();
