import { liquidEngine, zebra } from 'app/api/helperServices';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import moment from 'moment';
import { printHeader, printContent, printFooter } from 'app/api/mockData';
import { inspectionsHelper, lookup } from 'app/api/helperServices';
const companyViolatorFields = ['companyName', 'tradeLicenseNumber'];
const individualViolatorFields = ['firstName', 'lastName', 'uaeId'];
const abandonedVehicleInfoFields = ['emirate', 'numberPlate'];

const getTranslation = key => {
    const secondLastChar = key.substr(-2, 1);
    const lastChar = key.substr(-1);
    if ((lastChar === 'E' || lastChar === 'A') && secondLastChar === secondLastChar.toLowerCase()) {
        const locale = lastChar === 'A' ? 'ar' : 'en';
        return strings(key.slice(0, -1), { locale });
    } else {
        return strings(key);
    }
};

const getViolationTitle = (item, currentTitle) => {
    let selectedActionType = currentTitle;
    if (!selectedActionType) {
        selectedActionType = item.selectedActionType;
    } else if (item.selectedActionType === 'violations') {
        selectedActionType = item.selectedActionType;
    } else if (item.selectedActionType === 'warning' && selectedActionType !== 'violations') {
        selectedActionType = item.selectedActionType;
    } else if (item.selectedActionType === 'awareness' && selectedActionType !== 'violations' && selectedActionType !== 'warning') {
        selectedActionType = item.selectedActionType;
    }
    return selectedActionType;
};

const getInspectionChecklistParams = params => {
    const { violationItems, violatordetails, generalInfo, inspection } = params;
    const address = (inspection.location && inspection.location.address) || {};
    let violationAmount = 0;
    const printParams = {
        isWarning: 1,
        id: inspection.inspectionId,
        inspectorCode: '8888',
        referenceNumber: inspection.refNumber,
        muncipalCenterName_ar: 'مركز البلد',
        muncipalCenterName_en: 'Muncipal CenterName en',
        zoneSecPlot: 'المنطقة' + address.zone + '،القطاع' + address.sector + '،القطعة' + address.plot,
        violations: [],
        violationAmount: '0',
        note: `${generalInfo.remarks}`,
        idReceived: 'YES',
    };

    const questionType = inspectionsHelper.findQuestionType(params.def && params.def.def);

    let selectedActionType = '';

    violationItems.forEach(violation => {
        const { item } = violation;

        selectedActionType = getViolationTitle(item, selectedActionType);

        if (item.selectedLawClause && item.selectedLawClause.length) {
            item.selectedLawClause.forEach(lawClauseId => {
                // violation.lawClause.violationTypeId is Interger and lawClauseId is string. Have to fix
                if (violation.lawClause && violation.lawClause.violationTypeId === `${lawClauseId}`) {
                    printParams.violations.push(violation.lawClause.descriptionA);
                    printParams.violations.push(violation.lawClause.descriptionE);
                }
            });
        }

        if ((questionType === 'Checkbox' && item.selectedOption === true) || (questionType !== 'Checkbox' && item.selectedOption === 'no')) {
            violationAmount += item.violationAmount;
            printParams.violations.push(`AED ${item.violationAmount}`);
        }
    });
    if (selectedActionType) {
        printParams.selectedActionTypeA = strings(selectedActionType, { locale: 'ar' });
        printParams.selectedActionTypeE = strings(selectedActionType, { locale: 'en' });
    }

    if (violatordetails) {
        printParams.violatorDetailsList = [];
        if (params.visitDate) {
            printParams.visitDate = moment(params.visitDate).format('M/D/YYYY h:m:s a');
        }
        const { violatorType, company, violator } = violatordetails;
        printParams.idReceived = violator.signature ? 'YES' : 'NO';
        switch (violatorType) {
            case 'company':
                Object.keys(company).map(function(key) {
                    if (companyViolatorFields.indexOf(key) !== -1) {
                        printParams.violatorDetailsList.push(getTranslation(key) + ':' + company[key]);
                    }
                });
                break;
            case 'individual':
                Object.keys(violator).map(function(key) {
                    if (individualViolatorFields.indexOf(key) !== -1) {
                        printParams.violatorDetailsList.push(getTranslation(key) + ':' + violator[key]);
                    }
                });
                break;
            default:
                break;
        }
    }
    return printParams;
};

const getInspectionParams = params => {
    const { inspection } = params;
    const visit = inspection && inspection.visits && inspection.visits[0];
    if (!visit) {
        return {};
    }

    const { violators, abandonedVehicleInfo } = inspection.info;
    const { generalInfo } = visit;
    const visitDate = moment(visit.values.visitDate).format('M/D/YYYY h:m:s a');
    const address = (inspection.location && inspection.location.address) || {};
    let violationAmount = 0;
    const printParams = {
        isWarning: 1,
        id: inspection.inspectionId,
        inspectorCode: '8888',
        referenceNumber: inspection.refNumber,
        visitDate: visitDate,
        muncipalCenterName_ar: 'مركز البلد',
        muncipalCenterName_en: 'Muncipal CenterName en',
        zoneSecPlot: 'المنطقة' + address.zone + '،القطاع' + address.sector + '،القطعة' + address.plot,
        violations: [],
        violatorDetailsList: [],
        violationAmount: '0',
        note: `${generalInfo.remarks}`,
        idReceived: 'YES',
    };

    const violatordetails = violators[0];
    if (violatordetails) {
        const { violatorType, company, violator, violations } = violatordetails;

        violations.forEach(violationId => {
            const lawClause = inspectionsHelper.getLawClauseByClauseId(violationId);
            if (lawClause) {
                printParams.violations.push(lawClause.descriptionA);
                printParams.violations.push(lawClause.descriptionE);

                if (lawClause.fines[0].value) {
                    printParams.violations.push(`AED ${lawClause.fines[0].value}`);
                    violationAmount += lawClause.fines[0].value;
                }
            }
        });

        printParams.idReceived = violatordetails.signature ? 'YES' : 'NO';
        printParams.violationAmount = violationAmount;

        switch (violatorType) {
            case 'company':
                Object.keys(company).map(function(key) {
                    if (companyViolatorFields.indexOf(key) !== -1) {
                        printParams.violatorDetailsList.push(getTranslation(key) + ':' + company[key]);
                    }
                });
                break;
            case 'individual':
                Object.keys(violator).map(function(key) {
                    if (individualViolatorFields.indexOf(key) !== -1) {
                        printParams.violatorDetailsList.push(getTranslation(key) + ':' + violator[key]);
                    }
                });
                break;
            default:
                break;
        }

        if (abandonedVehicleInfo) {
            Object.keys(abandonedVehicleInfo).map(function(key) {
                if (abandonedVehicleInfoFields.indexOf(key) !== -1) {
                    let value = abandonedVehicleInfo[key];
                    if (key === 'emirate') {
                        value = lookup.getLabel(key, value);
                    }
                    printParams.violatorDetailsList.push(getTranslation(key) + ':' + value);
                }
            });
        }
    }
    return printParams;
};

const getParsedTemplate = async (receiptTemplate, serviceCategoryType, params) => {
    try {
        let printParams = null;
        switch (serviceCategoryType) {
            case 'INSPECTION_CHECKLIST':
                printParams = getInspectionChecklistParams(params);
                break;
            case 'MimsBuildingPenaltiesandGeneralAppearance':
            case 'MimsGeneralAppearanceForCars':
            case 'MimsOccupancyLaw':
            case 'MimsInspectionPlanImplementation':
            case 'MimsAbandonedVehicles':
            case 'MimsInformationRequestOnDemand':
            case 'MimsInspectionPlanApproval':
                printParams = getInspectionParams(params);
                break;
        }
        console.log('printParams', printParams);
        if (printParams) {
            return liquidEngine.parseAndRender(receiptTemplate, printParams);
        }
    } catch (error) {
        throw error;
    }
};

export { getParsedTemplate };
