import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { RNFirebase } = NativeModules;
const RNFirebaseEmitter = Platform.OS === 'android' ? new NativeEventEmitter(RNFirebase) : {};

export default {
    ...RNFirebase,
    addListener(callback) {
        return Platform.OS === 'android' ? RNFirebaseEmitter.addListener(RNFirebase.EVENTS, callback) : {};
    },
};
