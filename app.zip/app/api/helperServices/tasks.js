import { createSelector } from 'reselect';

class TasksHelper {
    static instance = null;
    static _createInstance() {
        return new TasksHelper();
    }

    static getInstance() {
        if (!TasksHelper.instance) {
            TasksHelper.instance = TasksHelper._createInstance();
            helper = TasksHelper.instance;
        }
        return TasksHelper.instance;
    }

    createNew = (userData, task) => {
        const createdDate = moment();
        const domainCustomerId = _state.auth.activeProfileDomainCustomerId;
        return {
            ...task,
            createdDate: createdDate,
            refNumber: createdDate.format('YYYYMMDDHHmmssSSS'), //Todo: change his logic to create unique reference numbers that should work with smarthub
        };
    };

    getInitialTasks = async () => {
        return new Promise(resolve => {
            resolve();
        });
    };
    getTaskHistory = createSelector(
        [state => state.domainCustomerId, state => state.allHistory],
        (domainCustomerId, allHistory) => {
            return allHistory;
        }
    );
    getOverDueTaskHistory = createSelector(
        [state => state.history],
        history => {
            return Object.keys(history).reduce((overdue, refNumber) => {
                const t = history[refNumber];
                if (t.status != 'completed' && new Date(t.deadlineToDate) < new Date()) overdue[refNumber] = t;
                return overdue;
            }, {});
        }
    );
}

export default TasksHelper.getInstance();
