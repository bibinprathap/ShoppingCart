import { createSelector } from 'reselect';
import moment from 'moment';

class TasksHelper {
    static instance = null;
    static _createInstance() {
        return new TasksHelper();
    }

    static getInstance() {
        if (!TasksHelper.instance) {
            TasksHelper.instance = TasksHelper._createInstance();
            helper = TasksHelper.instance;
        }
        return TasksHelper.instance;
    }

    createNew = task => {
        const createdDate = moment();
        //  const domainCustomerId = _state.auth.activeProfileDomainCustomerId;
        return {
            ...task,
            createdDate: createdDate.format('YYYY-MM-DD HH:mm:ss'),
            refNumber: createdDate.format('YYYYMMDDHHmmssSSS'), //Todo: change his logic to create unique reference numbers that should work with smarthub
        };
    };

    getInitialTasks = async () => {
        return new Promise(resolve => {
            resolve();
        });
    };
    getTaskHistory = createSelector(
        [state => state.domainCustomerId, state => state.allHistory],
        (domainCustomerId, allHistory) => {
            const currentTaskHistory = {};
            Object.keys(allHistory).map(key => {
                const history = allHistory[key];
                if (history && history.assignedToInspectorId === domainCustomerId) {
                    currentTaskHistory[key] = history;
                }
            });
            return currentTaskHistory;
        }
    );
    getOverDueTaskHistory = createSelector(
        [state => state.history],
        history => {
            return Object.keys(history).reduce((overdue, refNumber) => {
                const t = history[refNumber];
                if (t.status != 'completed' && new Date(t.deadlineToDate) < new Date()) overdue[refNumber] = t;
                return overdue;
            }, {});
        }
    );
}

export default TasksHelper.getInstance();
