import { createSelector } from 'reselect';
import moment from 'moment';
import { _state, store } from 'app/config/store';
import { setLoading, setLoaded } from 'app/actions/loader';
import { getTaskDetails } from 'app/actions/tasks';
import { showTaskDetailsDialog } from 'app/actions/tasks';
import { strings, localeProperty } from 'app/config/i18n/i18n';

class TasksHelper {
    static instance = null;
    static _createInstance() {
        return new TasksHelper();
    }

    static getInstance() {
        if (!TasksHelper.instance) {
            TasksHelper.instance = TasksHelper._createInstance();
            helper = TasksHelper.instance;
        }
        return TasksHelper.instance;
    }

    getTaskTitleWithNumber = item => {
        const { inspectionTypeDetail = {} } = item;
        let numberWithPrefix;
        if (item.workflowApplicationNumber) {
            numberWithPrefix = `Issue# ${item.workflowApplicationNumber}`;
        } else {
            if (item.applicationNumber) {
                numberWithPrefix = `App# ${item.applicationNumber}`;
            } else {
                numberWithPrefix = `Task# ${item.taskId}`;
            }
        }

        const title = `${localeProperty(inspectionTypeDetail, 'title')} - ${numberWithPrefix}`;
        return title;
    };

    showTaskDetails = ({ taskId, data }) => {
        store.dispatch(setLoaded(taskId)).then(() => {
            store.dispatch(showTaskDetailsDialog(taskId, strings('taskDetails'), data));
        });
    };

    selectTask = async (item, navigation) => {
        store.dispatch(setLoading({ options: { message: 'Loading task details...' } }));
        store.dispatch(getTaskDetails(item.taskId)).then(this.showTaskDetails);
    };
}

export default TasksHelper.getInstance();
