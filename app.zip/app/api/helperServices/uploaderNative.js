import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { RNFileUploader } = NativeModules;
const UploaderEmitter = Platform.OS === 'android' ? new NativeEventEmitter(RNFileUploader) : {};

export default {
    ...RNFileUploader,
    addListener(constname, uploadId, callback) {
        return Platform.OS === 'android' ? UploaderEmitter.addListener(RNFileUploader.UPLOAD_NOTIFICATION, callback) : {};
    },
    removeListener() {
        return Platform.OS === 'android' ? UploaderEmitter.addListener(RNFileUploader.UPLOAD_NOTIFICATION, callback) : {};
    },
};
//
