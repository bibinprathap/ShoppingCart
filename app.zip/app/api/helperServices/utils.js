import { I18nManager } from 'react-native';
import { strings } from 'app/config/i18n/i18n';

const defaultSeparator = I18nManager.isRTL ? '،' : ',';
const defaultOptions = { includeHeadings: true, separator: defaultSeparator, headingSeparator: ':', addSpacesAfterSeparators: true };

export function formatAddress(address, options) {
    /*
        This does the following:
            - replaces multiple consecutive white spacesd with just one. example: 'a  b' -> 'a b'
            - gets rid of leading or trailing shite spaces. example ' ab ' -> 'ab'
            - includes the Zone/Sector/Plot headings if needed
            - adds the desired separator between values when more than one parts of the address are available. example: zone, sector, plot
            - returns 'emptyAddress' message when none of the address parts are available
            - uses arabic/english headings depending upon current language
    */
    if (!address) return strings('emptyAddress');
    const appliedOptions = { ...defaultOptions, ...options };
    const { includeHeadings, separator, headingSeparator, addSpacesAfterSeparators } = appliedOptions;
    let _separator = addSpacesAfterSeparators ? `${separator} ` : separator;
    const _headingSeparator = addSpacesAfterSeparators ? `${headingSeparator} ` : headingSeparator;
    let zoneHeading = '',
        sectorHeading = '',
        plotHeading = '',
        streetHeading = '';
    if (includeHeadings) {
        zoneHeading = `${strings('zone')}${_headingSeparator}`;
        sectorHeading = `${strings('sector')}${_headingSeparator}`;
        streetHeading = `${strings('street')}${_headingSeparator}`;
        plotHeading = `${strings('plot')}${_headingSeparator}`;
    }
    const trimmedZone = !!address.zone
        ? String(address.zone)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';
    const trimmedSector = !!address.sector
        ? String(address.sector)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';
    const trimmedStreet = !!address.street
        ? String(address.street)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';
    const trimmedPlot = !!address.plot
        ? String(address.plot)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';

    const formattedZone = !!trimmedZone ? `${zoneHeading}${trimmedZone}${_separator}` : '';
    const formattedSector = !!trimmedSector ? `${sectorHeading}${trimmedSector}${_separator}` : '';
    const formattedStreet = !!trimmedStreet ? `${streetHeading}${trimmedStreet}${_separator}` : '';
    const formattedPlot = !!trimmedPlot ? `${plotHeading}${trimmedPlot}${_separator}` : '';
    const formattedAddress = `${formattedZone}${formattedSector}${formattedStreet}${formattedPlot}`;
    const endsWithRegex = new RegExp(`${_separator}$`);
    return !!formattedAddress ? String(formattedAddress).replace(endsWithRegex, '') : strings('emptyAddress');
}
