import React from 'react';
import PropTypes from 'prop-types';
import * as yup from 'yup';
class ValidationHelper {
    static instance = null;
    static _createInstance() {
        return new ValidationHelper();
    }

    static getInstance() {
        if (!ValidationHelper.instance) {
            ValidationHelper.instance = ValidationHelper._createInstance();
            helper = ValidationHelper.instance;
        }
        return ValidationHelper.instance;
    }
    validate = async (values, validationSchema, customValidation) => {
        let rErrors = {};
        try {
            if (validationSchema) await validationSchema.validate(values, { abortEarly: false });
        } catch (errors) {
            //Yup errors > redux-form errors
            errors.inner.forEach(error => {
                rErrors[error.path] = error.message;
            });
        } finally {
            if (customValidation) {
                // customValidation(values, rErrors);
                try {
                    await customValidation(values, rErrors);
                } catch (errors) {
                    throw rErrors;
                }
            }
            if (Object.getOwnPropertyNames(rErrors).length > 0) {
                throw rErrors;
            }
        }
    };
    getValidationRule = (rules, requiredMessage) => {
        let validationRuleForYup = yup;
        rules.map(rule => {
            switch (rule) {
                case 'string':
                    validationRuleForYup = validationRuleForYup.string();
                    break;
                case 'required':
                    if (requiredMessage) validationRuleForYup = validationRuleForYup.required(requiredMessage);
                    else validationRuleForYup = validationRuleForYup.required();
                    break;
                case 'array':
                    validationRuleForYup = validationRuleForYup.array();
                    break;
                case 'nullable':
                    validationRuleForYup = validationRuleForYup.nullable();
                    break;
                default:
                //unknown type, ignore for now
            }
        });
        return validationRuleForYup;
    };
    getIsMandatory = rules => {
        let isMandatory = false;
        rules.map(rule => {
            switch (rule) {
                case 'required':
                    isMandatory = true;
                    break;
                default:
                //unknown type, ignore for now
            }
        });
        return isMandatory;
    };
}

export default ValidationHelper.getInstance();

export function shallowEqual(thisProps, nextProps, thisState, nextState) {
    if (nextProps.isFocused || nextProps.isFocused == undefined)
        return !shallowEqualState(thisState, nextState) || !shallowEqualWithoutReactElements(thisProps, nextProps);
    else return false;
}

export function shallowEqualState(thisState, nextState) {
    return thisState === nextState;
}

export function shallowEqualWithoutReactElements(thisProps, nextProps) {
    let equals = false;
    if (thisProps === nextProps) {
        equals = true;
    } else if (typeof thisProps === 'object' && typeof nextProps === 'object') {
        equals = true;
        const propNames = new Set(Object.keys(thisProps), Object.keys(nextProps));
        for (const propName of propNames) {
            // if (propName == 'navigation' || propName == 'currentInspectionContainer') {
            // } else

            if (thisProps[propName] !== nextProps[propName] && !isReactElement(thisProps[propName])) {
                // No need to check nextProps[propName] as well, as we know they are not equal
                equals = false;
                break;
            }
        }
    }
    return equals;
}

function isReactElement(suspectedElement) {
    let isElem = false;
    if (React.isValidElement(suspectedElement)) {
        isElem = true;
    } else if (Array.isArray(suspectedElement)) {
        for (let i = 0, l = suspectedElement.length; i < l; i++) {
            if (React.isValidElement(suspectedElement[i])) {
                isElem = true;
                break;
            }
        }
    }
    return isElem;
}
