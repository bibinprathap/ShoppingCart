import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { Zebra } = NativeModules;
const ZebraEmitter = Platform.OS === 'android' ? new NativeEventEmitter(Zebra) : {};

export default {
    ...Zebra,
    addListener(callback) {
        return Platform.OS === 'android' ? ZebraEmitter.addListener(Zebra.PRINTER_NOTIFICATION, callback) : {};
    },
};
