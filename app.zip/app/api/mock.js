import moment from 'moment';
import {
    services,
    lawClauses,
    distortionTypes,
    printTemplateHeader,
    printTemplateContent,
    printTemplateFooter,
    dashboardCharts,
    tasks,
    inspectorPlanStatus,
    inspection,
    //plotsInspectionsData,
} from 'app/api/mockData';
import { _ } from 'lodash';

function sleep(milliseconds) {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if (new Date().getTime() - start > milliseconds) {
            break;
        }
    }
}

export const duplicateMock = {
    duplicates: [
        {
            createdDate: '2019-05-21T08:05:15.227Z',
            refNumber: '20190521120515227',
            visits: [
                {
                    visitDate: '2019-05-21T08:05:15.227Z',
                    values: {},
                    def: {
                        type: 'form',
                        def: [
                            {
                                name: 'generalInfo',
                                formType: 'fixed',
                            },
                            {
                                name: 'distortionForm',
                                titleE: 'Details of the distortion',
                                titleA: 'تفاصيل التشويه',
                                showFormTitle: true,
                                collapsible: true,
                                showLabels: true,
                                formType: 'dynamic',
                                fields: [
                                    {
                                        name: 'fieldGroup1',
                                        type: 'fieldGroup',
                                        fields: [
                                            {
                                                name: 'attachmentList',
                                                type: 'attachmentList',
                                                labelE: 'Attachments',
                                                labelA: 'مرفقات',
                                                validationRule: ['array', 'required', 'nullable'],
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                },
            ],
            service: '1',
            info: {
                generalInfo: {
                    remarks: 'First duplicate distortion ',
                },
                distortionForm: {
                    attachmentList: ['20190521120552756'],
                },
            },
            location: {
                coords: {
                    longitude: 54.37839780002833,
                    latitude: 24.488568886282202,
                },
                address: {
                    zone: 25,
                    sector: 26,
                    plot: 19,
                },
            },
        },
        {
            createdDate: '2019-05-21T08:05:15.227Z',
            refNumber: '20190521120515228',
            visits: [
                {
                    visitDate: '2019-05-21T08:05:15.227Z',
                    values: {},
                    def: {
                        type: 'form',
                        def: [
                            {
                                name: 'generalInfo',
                                formType: 'fixed',
                            },
                            {
                                name: 'distortionForm',
                                titleE: 'Details of the distortion',
                                titleA: 'تفاصيل التشويه',
                                showFormTitle: true,
                                collapsible: true,
                                showLabels: true,
                                formType: 'dynamic',
                                fields: [
                                    {
                                        name: 'fieldGroup1',
                                        type: 'fieldGroup',
                                        fields: [
                                            {
                                                name: 'attachmentList',
                                                type: 'attachmentList',
                                                labelE: 'Attachments',
                                                labelA: 'مرفقات',
                                                validationRule: ['array', 'required', 'nullable'],
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                },
            ],
            service: '1',
            info: {
                generalInfo: {
                    remarks:
                        'second duplicate distortion React Native JS code runs as a web worker inside this tab.  Press Ctrl⇧J to open Developer Tools. Enable Pause On Caught Exceptions for a better debugging experience.You may also install the standalone version of React Developer Tools to inspect the React component hierarchy, their props, and state.Status: Debugger session #0 active.',
                },
                distortionForm: {
                    attachmentList: ['20190521120552756'],
                },
            },
            location: {
                coords: {
                    longitude: 54.37839780002833,
                    latitude: 24.488568886282202,
                },
                address: {
                    zone: 25,
                    sector: 26,
                    plot: 19,
                },
            },
        },
        {
            createdDate: '2019-05-21T08:05:15.227Z',
            refNumber: '20190521120515527',
            visits: [
                {
                    visitDate: '2019-05-21T08:05:15.227Z',
                    values: {},
                    def: {
                        type: 'form',
                        def: [
                            {
                                name: 'generalInfo',
                                formType: 'fixed',
                            },
                            {
                                name: 'distortionForm',
                                titleE: 'Details of the distortion',
                                titleA: 'تفاصيل التشويه',
                                showFormTitle: true,
                                collapsible: true,
                                showLabels: true,
                                formType: 'dynamic',
                                fields: [
                                    {
                                        name: 'fieldGroup1',
                                        type: 'fieldGroup',
                                        fields: [
                                            {
                                                name: 'attachmentList',
                                                type: 'attachmentList',
                                                labelE: 'Attachments',
                                                labelA: 'مرفقات',
                                                validationRule: ['array', 'required', 'nullable'],
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                },
            ],
            service: '1',
            info: {
                generalInfo: {
                    remarks:
                        'Third duplicate distortion React Native JS code runs as a web worker inside this tab.  Press Ctrl⇧J to open Developer Tools. Enable Pause On Caught Exceptions for a better debugging experience.You may also install the standalone version of React Developer Tools to inspect the React component hierarchy, their props, and state.Status: Debugger session #0 active.duplicate distortion React Native JS code runs as a web worker inside this tab.  Press Ctrl⇧J to open Developer Tools. Enable Pause On Caught Exceptions for a better debugging experience.You may also install the standalone version of React Developer Tools to inspect the React component hierarchy, their props, and state.Status: Debugger session #0 active.duplicate distortion React Native JS code runs as a web worker inside this tab.  Press Ctrl⇧J to open Developer Tools. Enable Pause On Caught Exceptions for a better debugging experience.You may also install the standalone version of React Developer Tools to inspect the React component hierarchy, their props, and state.Status: Debugger session #0 active.duplicate distortion React Native JS code runs as a web worker inside this tab.  Press Ctrl⇧J to open Developer Tools. Enable Pause On Caught Exceptions for a better debugging experience.You may also install the standalone version of React Developer Tools to inspect the React component hierarchy, their props, and state.Status: Debugger session #0 active.',
                },
                distortionForm: {
                    attachmentList: ['20190521120552756'],
                },
            },
            location: {
                coords: {
                    longitude: 54.37839780002833,
                    latitude: 24.488568886282202,
                },
                address: {
                    zone: 25,
                    sector: 26,
                    plot: 19,
                },
            },
        },
    ],
};

export const checkListDuplicateMock = {
    duplicates: [
        {
            lawClausesID: 1,
            createdDate: '2019-06-26T11:42:07.205Z',
            refNumber: '20190626154207205',
            visits: [
                {
                    visitDate: '2019-06-26T11:42:07.205Z',
                    values: {
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            location: {
                coords: {
                    longitude: 54.37861908227206,
                    latitude: 24.48618255122643,
                },
                address: {
                    zone: 8,
                    sector: 14,
                    plot: 45,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 14640661,
                        Order: 1,
                        violatorType: 'company',
                        violations: [1],
                        company: {
                            tradeLicenseNumber: '555654',
                            companyNameE: 'Fttttftyyygftrrddfggggg',
                            companyNameA: 'Fttttftyyygftrrddfggggg',
                        },
                    },
                ],
            },
            service: '2.1.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 1,
            createdDate: '2019-06-26T11:31:30.303Z',
            refNumber: '20190626153130303',
            visits: [
                {
                    visitDate: '2019-06-26T11:31:30.303Z',
                    values: {
                        '2.1.1-1.2': {
                            selectedOption: 'no',
                            selectedLawClause: [2],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                        '2.1.1-1.3': {
                            selectedOption: 'no',
                            selectedLawClause: [3],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1500,
                        },
                        '2.1.1-1.4': {
                            selectedOption: 'no',
                            selectedLawClause: [4, 5],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 15600,
                        },
                        '2.1.1-1.5': {
                            selectedOption: 'no',
                            selectedLawClause: [6],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 300,
                        },
                        '2.1.1-2.1': {
                            selectedOption: 'no',
                            selectedLawClause: [999999999],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            service: '2.1.1',
            location: {
                coords: {
                    longitude: 54.37817148864269,
                    latitude: 24.48878185708648,
                },
                address: {
                    zone: 96,
                    sector: 22,
                    plot: 31,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 40491906,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [2],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 1,
            createdDate: '2019-06-25T07:49:09.747Z',
            refNumber: '20190625114909747',
            visits: [
                {
                    visitDate: '2019-06-25T07:49:09.747Z',
                    values: {
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            attachments: ['20190625124337383', '20190625124344850', '20190625124352453'],
                            remarks: {
                                '20190625120915437': {
                                    addedOn: '2019-06-25 12:09:15',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Rfff',
                                },
                                '20190625120916265': {
                                    addedOn: '2019-06-25 12:09:16',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Rffffffff',
                                },
                                '20190625120917082': {
                                    addedOn: '2019-06-25 12:09:17',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Rffffffffffff',
                                },
                                '20190625120917418': {
                                    addedOn: '2019-06-25 12:09:17',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Rfffffffffffff',
                                },
                                '20190625120917852': {
                                    addedOn: '2019-06-25 12:09:17',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'F',
                                },
                                '20190625120918224': {
                                    addedOn: '2019-06-25 12:09:18',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Ff',
                                },
                                '20190625120918467': {
                                    addedOn: '2019-06-25 12:09:18',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Fff',
                                },
                                '20190625120918619': {
                                    addedOn: '2019-06-25 12:09:18',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Ffff',
                                },
                                '20190625120918862': {
                                    addedOn: '2019-06-25 12:09:18',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Fffff',
                                },
                                '20190625120919254': {
                                    addedOn: '2019-06-25 12:09:19',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'f',
                                },
                                '20190625120919463': {
                                    addedOn: '2019-06-25 12:09:19',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'ff',
                                },
                                '20190625120919657': {
                                    addedOn: '2019-06-25 12:09:19',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'fff',
                                },
                            },
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                        '2.1.1-1.2': {
                            selectedOption: 'no',
                            attachments: ['20190625114943419'],
                            selectedLawClause: [2],
                            selectedActionType: 'warning',
                            selectedPeriodType: 'day',
                            selectedPeriod: 3,
                            violationAmount: 0,
                        },
                        '2.1.1-1.3': {
                            selectedOption: 'no',
                            selectedLawClause: [3],
                            selectedActionType: 'awareness',
                            selectedPeriodType: 'hour',
                            selectedPeriod: 3,
                            violationAmount: 0,
                        },
                        '2.1.1-1.4': {
                            selectedOption: 'no',
                            attachments: ['20190625155906430'],
                            remarks: {
                                '20190625155913083': {
                                    addedOn: '2019-06-25 15:59:13',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Ghjjj',
                                },
                            },
                            selectedLawClause: [5, 4],
                            selectedActionType: 'awareness',
                            selectedPeriodType: 'day',
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-1.5': {
                            selectedOption: 'no',
                            selectedLawClause: [6],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 300,
                        },
                        '2.1.1-2.1': {
                            selectedOption: 'no',
                            selectedLawClause: [999999999],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                        '2.1.1-2.2': {
                            selectedOption: 'no',
                            selectedLawClause: [7, 8],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3600,
                        },
                        '2.1.1-2.3': {
                            selectedOption: 'yes',
                            attachments: ['20190626081748642', '20190626081755351'],
                            remarks: {
                                '20190626081801806': {
                                    addedOn: '2019-06-26 08:18:01',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Yjkuuu',
                                },
                            },
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-3.1': {
                            selectedOption: 'yes',
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-3.2': {
                            selectedOption: 'yes',
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-3.3': {
                            selectedOption: 'yes',
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-3.4': {
                            selectedOption: 'yes',
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                        '2.1.1-3.5': {
                            selectedOption: 'yes',
                            selectedLawClause: [],
                            selectedActionType: '',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 0,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            location: {
                coords: {
                    longitude: 54.37955114990473,
                    latitude: 24.48747961736141,
                },
                address: {
                    zone: 96,
                    sector: 22,
                    plot: 58,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 97759561,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [2],
                        violator: {
                            uaeId: '784-1968-6',
                            expiryDate: '05-03-2022',
                            firstName: 'Aherreee55e',
                            middleName: 'Mohammed',
                            lastName: 'Abdullahereerttty',
                            familyName: '',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                        ticketRecipient: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                        signature: '20190625150151231',
                    },
                    {
                        UIIdentifier: 48146434,
                        Order: 1,
                        violatorType: 'company',
                        violations: [1, 3, 999999999, 7],
                        company: {
                            companyNameE: 'Huawerr',
                            companyNameA: 'Huawerr',
                            tradeLicenseNumber: '847',
                        },
                        ticketRecipient: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmaddffffff',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '2.1.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 4,
            createdDate: '2019-06-26T11:42:07.205Z',
            refNumber: '20190626154207205',
            visits: [
                {
                    visitDate: '2019-06-26T11:42:07.205Z',
                    values: {
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            location: {
                coords: {
                    longitude: 54.37861908227206,
                    latitude: 24.48618255122643,
                },
                address: {
                    zone: 8,
                    sector: 14,
                    plot: 45,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 14640661,
                        Order: 1,
                        violatorType: 'company',
                        violations: [1],
                        company: {
                            tradeLicenseNumber: '555654',
                            companyNameE: 'Fttttftyyygftrrddfggggg',
                            companyNameA: 'Fttttftyyygftrrddfggggg',
                        },
                    },
                ],
            },
            service: '2.1.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 5,
            createdDate: '2019-06-26T11:42:07.205Z',
            refNumber: '20190626154207205',
            visits: [
                {
                    visitDate: '2019-06-26T11:42:07.205Z',
                    values: {
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            location: {
                coords: {
                    longitude: 54.37861908227206,
                    latitude: 24.48618255122643,
                },
                address: {
                    zone: 8,
                    sector: 14,
                    plot: 45,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 14640661,
                        Order: 1,
                        violatorType: 'company',
                        violations: [1],
                        company: {
                            tradeLicenseNumber: '555654',
                            companyNameE: 'Fttttftyyygftrrddfggggg',
                            companyNameA: 'Fttttftyyygftrrddfggggg',
                        },
                    },
                ],
            },
            service: '2.1.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 5,
            createdDate: '2019-06-26T11:31:30.303Z',
            refNumber: '20190626153130303',
            visits: [
                {
                    visitDate: '2019-06-26T11:31:30.303Z',
                    values: {
                        '2.1.1-1.2': {
                            selectedOption: 'no',
                            selectedLawClause: [2],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                        '2.1.1-1.3': {
                            selectedOption: 'no',
                            selectedLawClause: [3],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1500,
                        },
                        '2.1.1-1.4': {
                            selectedOption: 'no',
                            selectedLawClause: [4, 5],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 15600,
                        },
                        '2.1.1-1.5': {
                            selectedOption: 'no',
                            selectedLawClause: [6],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 300,
                        },
                        '2.1.1-2.1': {
                            selectedOption: 'no',
                            selectedLawClause: [999999999],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            service: '2.1.1',
            location: {
                coords: {
                    longitude: 54.37817148864269,
                    latitude: 24.48878185708648,
                },
                address: {
                    zone: 96,
                    sector: 22,
                    plot: 31,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 40491906,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [2],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            saving: false,
            inspectionID: '56445666',
        },

        {
            lawClausesID: 2,
            createdDate: '2019-06-26T11:31:30.303Z',
            refNumber: '20190626153130303',
            visits: [
                {
                    visitDate: '2019-06-26T11:31:30.303Z',
                    values: {
                        '2.1.1-1.2': {
                            selectedOption: 'no',
                            selectedLawClause: [2],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                        '2.1.1-1.1': {
                            selectedOption: 'no',
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                        '2.1.1-1.3': {
                            selectedOption: 'no',
                            selectedLawClause: [3],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1500,
                        },
                        '2.1.1-1.4': {
                            selectedOption: 'no',
                            selectedLawClause: [4, 5],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 15600,
                        },
                        '2.1.1-1.5': {
                            selectedOption: 'no',
                            selectedLawClause: [6],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 300,
                        },
                        '2.1.1-2.1': {
                            selectedOption: 'no',
                            selectedLawClause: [999999999],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '2.1.1-1',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 1',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الأولى',
                                    checklist: [
                                        {
                                            code: '2.1.1-1.1',
                                            questionE: 'Car sheds are licensed and in good condition',
                                            questionA: 'مظلات للسيارات مرخصة وفي حالة جيدة',
                                            clauses: [1],
                                        },
                                        {
                                            code: '2.1.1-1.2',
                                            questionE: 'No worn-out flags or photos',
                                            questionA: 'لا تهالك الأعلام أو الصور',
                                            clauses: [2],
                                            violatorType: 'individual',
                                        },
                                        {
                                            code: '2.1.1-1.3',
                                            questionE: 'Outdoor cultivation is maintained properly',
                                            questionA: 'يتم الحفاظ على زراعة في الهواء الطلق بشكل صحيح',
                                            clauses: [3],
                                        },
                                        {
                                            code: '2.1.1-1.4',
                                            questionE: 'Systematic building',
                                            questionA: 'بناء  نظامي',
                                            clauses: [4, 5],
                                            violatorType: 'building',
                                        },
                                        {
                                            code: '2.1.1-1.5',
                                            questionE: 'Does not have more than four dish antenna',
                                            questionA: 'ليس لديه أكثر من أربعة طبق هوائي',
                                            clauses: [6],
                                            violatorType: 'building',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-2',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 2',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثانية',
                                    checklist: [
                                        {
                                            code: '2.1.1-2.1',
                                            questionE: 'Building is free of billboards',
                                            questionA: 'المبنى خالي من اللوحات الإعلانية',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.2',
                                            questionE: 'New or well maintained building',
                                            questionA: 'مبنى جديد أو بحالة جيدة',
                                            clauses: [7, 8],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-2.3',
                                            questionE: 'Not a deserted dwelling',
                                            questionA: 'ليس مسكنا مهجورا',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-3',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 3',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الثالثة',
                                    checklist: [
                                        {
                                            code: '2.1.1-3.1',
                                            questionE: 'Dwelling is not overcrowded',
                                            questionA: 'لا يوجد تكدس في المسكن',
                                            clauses: [9],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.2',
                                            questionE: 'There are no circuit breakers',
                                            questionA: 'لا توجد قواطع',
                                            clauses: [10],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.3',
                                            questionE: 'There is no graffiti',
                                            questionA: 'لا يوجد كتابات على الجدران',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.4',
                                            questionE: 'Plot has only one villa',
                                            questionA: 'قطعة أرض لديها فيلا واحدة فقط',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.5',
                                            questionE: 'There is no apartment',
                                            questionA: 'لا يوجد نظام شقة',
                                            clauses: [11],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-3.6',
                                            questionE: 'There is no tent',
                                            questionA: 'لا توجد خيمة',
                                            clauses: [12],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                                {
                                    code: '2.1.1-4',
                                    questionType: 'YesNo',
                                    titleE: 'Checklist for villas under construction - Group 4',
                                    titleA: 'قائمة مرجعية للفيلات قيد الإنشاء - المجموعة الرابعة',
                                    checklist: [
                                        {
                                            code: '2.1.1-4.1',
                                            questionE: 'There is a panel showing the consultant, contractor and owner data',
                                            questionA: 'يوجد لوحة توضح بيانات الاستشاري والمقاول والمالك',
                                            clauses: [999999999],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.2',
                                            questionE: 'There is a temporary fence that meets the requirements',
                                            questionA: 'يوجد سور مؤقت مطابق للاشتراطات',
                                            clauses: [13],
                                            violatorType: 'company',
                                        },
                                        {
                                            code: '2.1.1-4.3',
                                            questionE: 'There are more than 4 workers in the site',
                                            questionA: 'يوجد سكن عمال في الموقع اكثر من 4',
                                            clauses: [14],
                                            violatorType: 'company',
                                        },
                                    ],
                                },
                            ],
                        },
                    },
                },
            ],
            service: '2.1.1',
            location: {
                coords: {
                    longitude: 54.37817148864269,
                    latitude: 24.48878185708648,
                },
                address: {
                    zone: 96,
                    sector: 22,
                    plot: 31,
                },
            },
            info: {
                violators: [
                    {
                        UIIdentifier: 40491906,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [2],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            saving: false,
            inspectionID: '56445666',
        },
    ],
};

export const checkListCheckBoxDuplicateMock = {
    duplicates: [
        {
            lawClausesID: 1,
            createdDate: '2019-07-10T04:10:34.019Z',
            refNumber: '20190710081034019',
            visits: [
                {
                    visitDate: '2019-07-10T04:10:34.019Z',
                    values: {
                        '3.1.1-1-1.1': {
                            selectedOption: true,
                            attachments: ['20190710081247901'],
                            remarks: {
                                '20190710081305823': {
                                    addedOn: '2019-07-10 08:13:05',
                                    addedByUUID: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                                    addedByFullnameA: 'راجاشيكار,ريدى,,,اتي',
                                    addedByFullnameE: 'Rajashekar,Reddy,,,Ette',
                                    value: 'Ffhfuhfutu',
                                },
                            },
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                        '3.1.1-1-1.2': {
                            selectedOption: true,
                            selectedLawClause: [2],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                        '3.1.1-1-1.3': {
                            selectedOption: true,
                            selectedLawClause: [3],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1500,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '3.1.1-1',
                                    questionType: 'Checkbox',
                                    titleE: 'Checklist for General Appearance',
                                    titleA: 'قائمة مرجعية للمظهر العام',
                                    checklist: [
                                        {
                                            code: '3.1.1-1-1.1',
                                            clauses: [1],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.2',
                                            clauses: [2],
                                            isMandatory: true,
                                            isAttachementMandatory: false,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.3',
                                            clauses: [3],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: false,
                                        },
                                        { code: '3.1.1-1-1.4', clauses: [4] },
                                        { code: '3.1.1-1-1.5', clauses: [5] },
                                        { code: '3.1.1-1-1.6', clauses: [6] },
                                    ],
                                },
                            ],
                        },
                    },
                    generalInfo: { remarks: 'Remarks ' },
                },
            ],
            location: { coords: { latitude: 24.484145271974256, longitude: 54.377363839063904 }, address: { zone: 98, sector: 8, plot: 64 } },
            info: {
                violators: [
                    {
                        UIIdentifier: 8965601,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [1, 3, 2],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '3.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 1,
            createdDate: '2019-07-10T04:50:56.999Z',
            refNumber: '20190710085056999',
            visits: [
                {
                    visitDate: '2019-07-10T04:50:56.999Z',
                    values: {
                        '3.1.1-1-1.2': {
                            selectedOption: true,
                            selectedLawClause: [2],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 1800,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '3.1.1-1',
                                    questionType: 'Checkbox',
                                    titleE: 'Checklist for General Appearance',
                                    titleA: 'قائمة مرجعية للمظهر العام',
                                    checklist: [
                                        {
                                            code: '3.1.1-1-1.1',
                                            clauses: [1],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.2',
                                            clauses: [2],
                                            isMandatory: true,
                                            isAttachementMandatory: false,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.3',
                                            clauses: [3],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: false,
                                        },
                                        { code: '3.1.1-1-1.4', clauses: [4] },
                                        { code: '3.1.1-1-1.5', clauses: [5] },
                                        { code: '3.1.1-1-1.6', clauses: [6] },
                                    ],
                                },
                            ],
                        },
                    },
                    generalInfo: { remarks: 'Remarkssd' },
                },
            ],
            location: { coords: { latitude: 24.487434066832066, longitude: 54.378766939044 } },
            info: {
                violators: [
                    {
                        UIIdentifier: 28625848,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [2],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '3.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 2,
            createdDate: '2019-07-10T05:02:24.726Z',
            refNumber: '20190710090224726',
            visits: [
                {
                    visitDate: '2019-07-10T05:02:24.726Z',
                    values: {
                        '3.1.1-1-1.1': {
                            selectedOption: true,
                            selectedLawClause: [1],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 3000,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '3.1.1-1',
                                    questionType: 'Checkbox',
                                    titleE: 'Checklist for General Appearance',
                                    titleA: 'قائمة مرجعية للمظهر العام',
                                    checklist: [
                                        {
                                            code: '3.1.1-1-1.1',
                                            clauses: [1],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.2',
                                            clauses: [2],
                                            isMandatory: true,
                                            isAttachementMandatory: false,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.3',
                                            clauses: [3],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: false,
                                        },
                                        { code: '3.1.1-1-1.4', clauses: [4] },
                                        { code: '3.1.1-1-1.5', clauses: [5] },
                                        { code: '3.1.1-1-1.6', clauses: [6] },
                                    ],
                                },
                            ],
                        },
                    },
                    generalInfo: { remarks: 'Reevv' },
                },
            ],
            location: { coords: { latitude: 24.485914786598837, longitude: 54.381582075946746 }, address: { zone: 61, sector: 44, plot: 12 } },
            info: {
                violators: [
                    {
                        UIIdentifier: 50289191,
                        Order: 1,
                        violatorType: 'company',
                        violations: [1],
                        company: { tradeLicenseNumber: '1111' },
                        ticketRecipient: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '3.1',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 3,
            createdDate: '2019-07-10T05:06:46.120Z',
            refNumber: '20190710090646120',
            visits: [
                {
                    visitDate: '2019-07-10T05:06:46.120Z',
                    values: {
                        '3.1.1-1-1.4': {
                            selectedOption: true,
                            selectedLawClause: [4],
                            selectedActionType: 'violations',
                            selectedPeriodType: {},
                            selectedPeriod: 1,
                            violationAmount: 15000,
                        },
                    },
                    def: {
                        type: 'checklist',
                        def: {
                            checklistGroups: [
                                {
                                    code: '3.1.1-1',
                                    questionType: 'Checkbox',
                                    titleE: 'Checklist for General Appearance',
                                    titleA: 'قائمة مرجعية للمظهر العام',
                                    checklist: [
                                        {
                                            code: '3.1.1-1-1.1',
                                            clauses: [1],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.2',
                                            clauses: [2],
                                            isMandatory: true,
                                            isAttachementMandatory: false,
                                            isRemarkMandatory: true,
                                        },
                                        {
                                            code: '3.1.1-1-1.3',
                                            clauses: [3],
                                            isMandatory: true,
                                            isAttachementMandatory: true,
                                            isRemarkMandatory: false,
                                        },
                                        { code: '3.1.1-1-1.4', clauses: [4] },
                                        { code: '3.1.1-1-1.5', clauses: [5] },
                                        { code: '3.1.1-1-1.6', clauses: [6] },
                                    ],
                                },
                            ],
                        },
                    },
                    generalInfo: { remarks: 'Rdğggt' },
                },
            ],
            location: { coords: { latitude: 24.485610930552195, longitude: 54.380867120542874 }, address: { zone: 68, sector: 88, plot: 17 } },
            info: {
                violators: [
                    {
                        UIIdentifier: 73455543,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [4],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '3.1',
            saving: false,
            inspectionID: '56445666',
        },
    ],
};

export const generalDuplicateMock = {
    duplicates: [
        {
            lawClausesID: 15,
            createdDate: '2019-07-04T12:13:43.674Z',
            refNumber: '20190704161343674',
            visits: [
                {
                    visitDate: '2019-07-04T12:13:43.674Z',
                    values: {},
                    def: { type: 'form', def: [{ name: 'abandonedVehicleInfo', formType: 'fixed' }] },
                    generalInfo: { remarks: 'Ghy' },
                },
            ],
            location: { coords: { longitude: 54.38028909265996, latitude: 24.487755749450876 }, address: { zone: 16, sector: 89, plot: 33 } },
            info: {
                abandonedVehicleInfo: {
                    regApplicable: true,
                    isCritical: true,
                    duration: { selectedPeriod: 2, selectedPeriodType: 'hour' },
                    issueType: '4',
                    emirate: '1',
                    registrationType: '35',
                    category: '70',
                    numberPlate: 'Yyuu',
                    make: '1180',
                    model: '2558',
                    color: '2',
                    attachmentList: ['20190707092147106'],
                },
                violators: [
                    {
                        UIIdentifier: 38111317,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [15],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '4',
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 15,
            createdDate: '2019-07-07T05:33:24.163Z',
            refNumber: '20190707093324163',
            visits: [
                {
                    visitDate: '2019-07-07T05:33:24.163Z',
                    values: {},
                    def: { type: 'form', def: [{ name: 'abandonedVehicleInfo', formType: 'fixed' }] },
                    generalInfo: { remarks: 'Rehhhhgg' },
                },
            ],
            service: '4',
            location: { coords: { longitude: 54.37903951853514, latitude: 24.48898353827502 }, address: { zone: 83, sector: 47, plot: 9 } },
            info: {
                abandonedVehicleInfo: {
                    regApplicable: true,
                    isCritical: false,
                    duration: { selectedPeriod: 0, selectedPeriodType: 'day' },
                    emirate: '1',
                    registrationType: '35',
                    category: '70',
                    numberPlate: 'Hjjiioo9',
                    make: '1180',
                    model: '1182',
                    color: '6',
                    issueType: '3',
                },
                violators: [
                    {
                        UIIdentifier: 28800739,
                        Order: 1,
                        violatorType: 'individual',
                        violations: [15],
                        violator: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            saving: false,
            inspectionID: '56445666',
        },
        {
            lawClausesID: 15,
            createdDate: '2019-07-07T05:36:56.995Z',
            refNumber: '20190707093656995',
            visits: [
                {
                    visitDate: '2019-07-07T05:36:56.995Z',
                    values: {},
                    def: { type: 'form', def: [{ name: 'abandonedVehicleInfo', formType: 'fixed' }] },
                    generalInfo: { remarks: 'Rsbgbnh' },
                },
            ],
            location: { coords: { longitude: 54.38032530248165, latitude: 24.487541556435318 }, address: { zone: 17, sector: 80, plot: 63 } },
            info: {
                abandonedVehicleInfo: {
                    regApplicable: true,
                    isCritical: false,
                    duration: { selectedPeriod: 0, selectedPeriodType: 'day' },
                    emirate: '1',
                    registrationType: '35',
                    category: '70',
                    numberPlate: 'Huuu',
                    make: '1180',
                    model: '1182',
                    color: '6',
                    issueType: '3',
                },
                violators: [
                    {
                        UIIdentifier: 48921216,
                        Order: 1,
                        violatorType: 'company',
                        violations: [15],
                        company: {
                            tradeLicenseNumber: '1111',
                            phoneNumber: '055555',
                            companyNameA: 'بنك أبو ظبي الأول',
                            companyNameE: 'First Abu Dhabi Bank',
                        },
                        ticketRecipient: {
                            uaeId: '784-1968-6570305-0',
                            expiryDate: '05-03-2022',
                            firstName: 'Ahmad',
                            middleName: 'Mohammed',
                            lastName: 'Abdullah',
                            familyName: 'Salim',
                            birthDate: '27-07-1999',
                            nationality: 'United Arab Emirates',
                        },
                    },
                ],
            },
            service: '4',
            saving: false,
            inspectionID: '56445666',
        },
    ],
};
class MockApi {
    latency = 1000;

    adminLogin = (username, password, success = true) => {
        //console.log(`AdminLogin username: ${username}, password: ${password} `);
        return new Promise((resolve, reject) => {
            if (success) {
                setTimeout(() => {
                    resolve({
                        message: 'Mock AdminLogin success.',
                        authCode:
                            '3F916A22E63376725925AB22166FEEFD0A6DA361A79B9ED302F2D97EFF6158C258A18902212285714223FD6B0A0F80264F17625F1E91C6D6764720139DAF7EB88010A28898FB1BA8E5BE50689A3648F45240E8A71A1AF84BA6BDBB37E1D1941B2F0DDF2E860640BCE0024778694974E1B8E1AFC98F511353E18FDB4617238D5F4D02B21C6CEE83633F2ED144BA951EDB2785864B',
                        profiles: [
                            {
                                customerId: 1039,
                                applicationUserId: 1103,
                                applicationInboxId: 1000,
                                domainCustomerId: 1000,
                                userType: 'B',
                                displayNameA: 'عبد الله المهندس',
                                displayNameE: 'Abullah Al-Mohandes',
                                domainCustomerNameA: 'بلدية مدينة أبوظبي - فرع وهمية',
                                domainCustomerNameE: 'Abu Dhabi City Municipality - Fake Branch',
                                isDomainAdmin: false,
                                isPersonalAccount: false,
                                email: 'Admin@this.me',
                                urlArgs: 'QabssTh76cQgE7ueFNppCzLyN9O1C6MytVxACdG0gKDvYGo%2BcP3y2g%3D%3D',
                            },
                        ],
                        tokenData: {
                            access_token: 'dummyToken',
                            refresh_token: 'dummyRefreshToken',
                            scope:
                                'motherFullNameEN homeAddressFlatNo motherFullNameAR uuid homeAddressEmirateDescriptionEN titleEN passportIssueDate passportNumber fullnameAR homeAddressStreetAR homeAddressCityDescriptionEN openid homeAddressCityCode lastnameEN fullnameEN homeAddressStreetEN idCardIssueDate homeAddressBuildingNameEN lastnameAR adsicUserName idn nationalityEN dob passportCountryCode idCardNumber residencyExpiryDate homeAddressAreaCode userType nationalityAR maritalStatus gender cardSerialNumber homeAddressBuildingNameAR sponsorName residencyNumber emailNotVerified passportExpiryDate mobileNotVerified firstnameEN firstnameAR email idCardExpiryDate sponsorType mobile photo homeAddressEmirateDescriptionAR homeAddressMobilePhoneNumber placeOfBirthEN sponsorNumber occupationCode passportCountryDescriptionEN idnNotVerified placeOfBirthAR workAddressLandPhoneNumber homeAddressPOBox homeAddressEmirateCode passportCountryDescriptionAR residencyType',
                            id_token: 'dummyIdToken',
                            token_type: 'Bearer',
                            expires_in: 2000,
                        },
                        userData: {
                            username: username,
                            uuid: 'c7e779e1-8774-4c8c-8cc8-a8400759fe34',
                            homeAddressEmirateDescriptionEN: 'Abu Dhabi',
                            passportIssueDate: '28/04/2015',
                            passportNumber: 'M 8484668',
                            fullnameAR: 'راجاشيكار,ريدى,,,اتي',
                            homeAddressCityDescriptionEN: 'Abu Dhabi',
                            homeAddressCityCode: '02',
                            lastnameEN: 'Ette',
                            fullnameEN: 'Rajashekar,Reddy,,,Ette',
                            idCardIssueDate: '16/08/2016',
                            lastnameAR: 'اتي',
                            idn: '784198483979807',
                            nationalityEN: 'IND',
                            dob: '18/11/1984',
                            passportCountryCode: 'IND',
                            idCardNumber: '079637547',
                            residencyExpiryDate: '07/08/2018',
                            homeAddressAreaCode: '22',
                            userType: 'SOP3',
                            nationalityAR: 'الهند',
                            maritalStatus: 'Married',
                            gender: 'Male',
                            cardSerialNumber: '784198483979807/079637547',
                            sponsorName: 'مؤسسه ابوظبى والخليج للحاسبات الالكترونيه',
                            residencyNumber: '10120122158678',
                            passportExpiryDate: '27/04/2025',
                            firstnameEN: 'Rajashekar',
                            firstnameAR: 'راجاشيكار',
                            email: 'rajashekar.ette@gmail.com',
                            idCardExpiryDate: '07/08/2018',
                            sponsorType: '06',
                            mobile: '971508475995',
                            photo:
                                '/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMNBhUREBEVDQ8NDxMVDQ0SDw8QEAoQGBIYFhYVGRUaHDQgGBolGxMTITEhJS8rMTIuGCszODMtNzQtLisBCgoKDQ0NDg0NDisdFRkrKysrKysrKysrNysrKysrKzc3KysrKysrKysrKysrKysrKysrNysrKysrKysrKysrN//AABEIAOAA4AMBIgACEQEDEQH/xAAbAAEBAAIDAQAAAAAAAAAAAAAAAQQGAwUHAv/EAD8QAAIBAQQECggEBQUAAAAAAAABAgMEBRExEiFBYQYTMlFScoGRobEiM0Jxc7LB0SMkNZI0YqPh8BQlU2OC/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAH/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD3EAAAAAAAAAAACSkoxxbSSzbeCQFB1lpvulDUm6j/AJVq739Drq3CCb5MYwW/GTA2QGqxv2stsX74/ZnDbLylVWtaL2uM6mH7ccANvbwz1Hxx8ceVHHm0kaK+8+QPQAafYL3qUGljxkOg3ktz2G0WK2Qr0dKD60XnB8zQGQAAAAAAAAAAAAAAAAAAAAAAGPbrZGhQ0pf+Y7ZsC2yroUcdKMFtnLF4e5bWapbrRxlXlyqJbZJRXZFZHzbLZKtV0pvqx2QW4xwBAQAAQAQEAHNYrXKhaFOOzNbJrmZwEA3qnbqboxlpxiprFaUkmc1KtGa9GSl7mn5HnxYTcZ4xbi1k02mu0D0MHS8HbzlWjKFR6U4JOMtso5a/dq7zugAAAAAAAAAAAAAAAAI3gsXqSzfMafeVsde1OXsrVBc0f7m2Wl/lpdSXkaQAICAACACAgAgIAICACAgGfctZ07fGaWMYvCo+jCWrF7sWjeDz6yWqVGupx2ZxeU47Yvcb5ZqyqWeM45Timt24DlAAAAAAAAAAAAAAABj3i8LvqfDn8rNKN1vBfkKnwp/KzSQABABAQAQEAEBABAQAAQoG8XD+kU+q/NmjG9XGsLop9T6kGeAAAAAAAAAAAAAAADitUcbNJc8JLwNFN+axRoMlg8OZgCAgAgIAICACAgAAhQICADf7ojhddL4UPGKZ5+8j0Wxx0bHBdGnFd0UQcwAAAAAAAAAAAAAAAOC12uFGGM5aOOSzcvcjSrTJStEnHkynJx58G9RmX9Wc7zlzQwjFc2C1+OJ1wAgIAICACAgAAhQICACAgFWevLb7j0C77xp2iP4csXHOLWEo9h56Zd0Wh0rzpyWr00pb4yeD8wPQgAQAAAAAAAAAAAAAGkXp+o1PiS8zEOwv+joXpLmnhJb8Vr8UzrgBAQAQEAAEKBAQAQEAEBAB92d/mI9ePmjjMu56Dq3pTiumm+rH0n4ID0QAEAAAAAAAAAAAAAB1d/Xfx9mxj6yni4rprajT3qfM1muY9EMO1XXSrVNKcE5bWm4t+/DMDRiGdfVmVG8ZRSwi8HBbmvviYAAAhQICACAgAgIAIDJu2z8deEIZqU1pdVa5eCYGKzceC11OjSdWawnUWEYvOnDfveruM+zXLQpVtONNaSeKbcpaL3JvUdgQAAAAAAAAAAAAAAAAAABr/Cyy40Y1V7D0Z9V5Pv8AM1g9Dr0VUouEtcZpp9poNtszo2mUJZxefSWxgcJAQoEBABAQAQEAGycDbHjWlWa1RWjDrPXLww7zXqFJ1KyhFYym8IreeiXfZFQscacfZWt9KWbfeBkgAgAAAAAAAAAAAAAAAAAAAdTf91/6ihpR9bBej/2Lo/Y7YAeatYPDJrNcxDktX8TPry+ZnEUCAgAgIAIynzLII3PgxdHE0+NqL8Sa9CP/ABRf1f8Am078+KPqV1V5H2RQAAAAAAAAAAAAAAAAAAADEtN50aXLqRTXsp6Uu5awMsHQWnhTTj6uEqj53hBffwOrtPCWtPk6NJfyxxfewOrtX8TPry+ZnCWUsZYvW28W+dnyUCAgAAgQPmWRSMD1Cj6ldVeR9mh2XhLXppJuNVLZKOvD3rA7azcL4P1lOUN8Wpr6PzIrZgYFlvmhV5NWOL9mT0G+x5meAAAAAAAAAAMO87wjZqGlLW3qhBZzf23gZhwWi206XLnGO5yWL7MzTLbe1WtL0pOMehH0Yr79pgAbfaOEtKPIUqj3LRj3vX4HV2nhNVlyIxpr98l2vV4HSEKMi02+rV5dSUt2OEe5ajGBABAQAQEAAECBAQAQEAEBADOezW6pRf4dSUNyk8O7IxyAd/ZeFleHLUaq3rRk+1avA7ey8L6MvWRlSfPqnFdq1+BpAA9Pst50a3q6sJPo6SUv2vWZZ5GzOsF8VrPL8Oo9FexJ6UH2PLswIr04HVXDfUbZRy0KkOXTx8Vzo7UAaPflr468ZPH0YPRh7lt7XibnaamhZpS6EJPuWJ52BSAhQICACAgAgIAAIECAgAgIAICACAgAgAAgIAICAZd0252a8IVFlF+mulB8pd3kepJ4rnxy3nkLPULgrcZctKW3i4p72lovyIr7vmWF1VPhy8VgaEb1fr/2ip1fqjRABAQoEBABAQAAQIEBABAQAQEAEBABAABAQAQEAEBAB6NwOljwep7nUX9SR5weicCv0CPXn8zA/9k=',
                            homeAddressEmirateDescriptionAR: 'أبوظبي',
                            homeAddressMobilePhoneNumber: '0562122134',
                            placeOfBirthEN: 'TELANGANA',
                            sponsorNumber: '00',
                            occupationCode: '2131',
                            passportCountryDescriptionEN: 'India',
                            placeOfBirthAR: 'غير محدد',
                            homeAddressPOBox: '26610-1',
                            homeAddressEmirateCode: '01',
                            passportCountryDescriptionAR: 'الهند',
                            residencyType: '02',
                            sub: 'UAE-784198483979807',
                            updated_at: '1549187279',
                        },
                    });
                }, this.latency);
            } else {
                setTimeout(() => {
                    reject(`Mock AdminLogin failure. add login failure details here.`);
                }, this.latency);
            }
        });
    };

    checkDuplicate = (duplicateCheckRequestModel, success = true) => {
        // console.log(`checkDuplicate: ${JSON.stringify(duplicateCheckRequestModel)} `);
        return new Promise((resolve, reject) => {
            if (success) {
                setTimeout(() => {
                    if (duplicateCheckRequestModel.selectedCategory == 'DISTORTION') resolve({ ...duplicateMock });
                    else if (duplicateCheckRequestModel.selectedCategory == 'INSPECTION') {
                        if (duplicateCheckRequestModel.inspectionDefType == 'checklist') {
                            if (duplicateCheckRequestModel.questionType == 'Checkbox') resolve({ ...checkListCheckBoxDuplicateMock });
                            else resolve({ ...checkListDuplicateMock });
                        } else resolve({ ...generalDuplicateMock });
                    } else resolve({ ...duplicateMock });
                }, this.latency);
            } else {
                setTimeout(() => {
                    reject(`Mock checkDuplicate failure. add checkDuplicate failure details here.`);
                }, this.latency);
            }
        });
    };

    createInspectionRecord = (createInspectionModel, success = true) => {
        //console.log(`createInspectionRecord: ${JSON.stringify(createInspectionModel)} `);
        return new Promise((resolve, reject) => {
            if (success) {
                setTimeout(() => {
                    resolve({ inspectionID: '56445666', taskId: createInspectionModel.taskId });
                }, this.latency);
            } else {
                setTimeout(() => {
                    reject(`Mock createInspectionRecord failure. add createInspectionRecord failure details here.`);
                }, this.latency);
            }
        });
    };
    getJsonFromResponse = response => {
        if (response && response.bodyString) return JSON.parse(response.bodyString);
        else return response;
    };

    loadMasterdata = lastUpdated => {
        return this.delayedResult(true, {
            lastUpdated: moment().format('YYYY-MM-DD HH:mm:ss'), //lastUpdated should come from server
            services: services,
            lawClauses: lawClauses,
            distortionTypes: distortionTypes,
            printTemplate: `${printTemplateHeader}\n${printTemplateContent}\n${printTemplateFooter}`,
        });
    };

    getCompanyProfile = licenseNo => {
        if (licenseNo && licenseNo.length > 0) {
            return this.delayedResult(true, { companyName: `NameOf${licenseNo}` });
        } else {
            return this.delayedResult(true, { companyName: '' });
        }
    };

    createInspection = params => {
        return this.delayedResult(true, {
            lastUpdated: moment().format('YYYY-MM-DD HH:mm:ss'),
            services: params,
        });
    };

    getDashboardCharts = () => {
        return this.delayedResult(true, dashboardCharts);
    };

    getInitialTasks = userData => {
        return this.delayedResult(true, tasks);
    };

    getBuildingDetails = buildingNo => {
        if (buildingNo && buildingNo.length > 0 && buildingNo == 1234) {
            return this.delayedResult(
                true,
                { buildingType: '1', buildingNameAR: `buildingNameAR`, buildingNameEN: `buildingNameEN`, ownerName: 'Owner NAme' },
                10000
            );
        } else {
            return reject(data);
        }
    };

    getInspectorPlanStatus = async inspectorDomainCustomerId => {
        //console.log('filteredPlanStatus', inspectorPlanStatus);

        //console.log('inspectorDomainCustomerId   ', inspectorDomainCustomerId + ' inspectorPlanStatus ', JSON.stringify(inspectorPlanStatus));

        const filteredPlanStatus = _.find(inspectorPlanStatus, {
            inspectorId: 123,
        });
        //console.log('filteredPlanStatus: ', filteredPlanStatus);
        //use _ to filter the data for the required inspector
        return this.delayedResult(true, filteredPlanStatus);
    };

    getInspection = ref => {
        return {
            inspection,
        };
    };

    getPlotGeometry = (basePoint, index, plotDelta) => {
        console.log('getPlotGeometry.index:', index);
        const pointDeltaLatitude = 0.0002;
        const pointDeltaLongitude = 0.0003;
        // const refPoint = { latitude: basePoint.latitude + index * plotDelta, longitude: basePoint.longitude + index * plotDelta };
        const refPoint = { latitude: basePoint.latitude + index * pointDeltaLatitude, longitude: basePoint.longitude };
        let geometry;
        if (true) {
            geometry = [
                {
                    latitude: refPoint.latitude,
                    longitude: refPoint.longitude,
                },
                {
                    latitude: refPoint.latitude,
                    longitude: refPoint.longitude + pointDeltaLongitude,
                },
                {
                    latitude: refPoint.latitude + pointDeltaLatitude - index * 0.00002,
                    longitude: refPoint.longitude + pointDeltaLongitude,
                },
                {
                    latitude: refPoint.latitude + pointDeltaLatitude - index * 0.00002,
                    longitude: refPoint.longitude,
                },
            ];
        }
        const fixedGeometry = geometry.map(point => {
            return { latitude: point.latitude.toFixed(6), longitude: point.longitude.toFixed(6) };
        });

        return fixedGeometry;
    };
    getInspectionsPlotsData = async plotIDS => {
        //console.log('plotIDS ' + plotIDS);
        // console.log('plotsInspectionsData', plotsInspectionsData);
        let plotCounter = 0;
        const plotDelta = 0.0002;
        const basePoint = { latitude: 24.487254, longitude: 54.379653 };
        const plotsInAColumn = Math.ceil(plotIDS.length / 4);
        const plotsGeometryData = plotIDS.map((plot, index) => {
            if (plotCounter == plotsInAColumn) {
                console.log('resetting.... plotCounter:', plotCounter, ' plotsInAColumn:', plotsInAColumn);
                plotCounter = 0;
                basePoint.longitude = basePoint.longitude + plotDelta * 1.8;
            }
            plotCounter++;
            const geometry = this.getPlotGeometry(basePoint, plotCounter, plotDelta);
            console.log('genering data for plotId: ', plot, 'at index ', index, 'rowPlotCounter: ', plotCounter, ' plotsInAColumn:', plotsInAColumn);
            return { plotId: plot, geometry };
        });
        console.log('plotsGeometryData: ', plotsGeometryData);
        //return plotsGeometryData;
        return this.delayedResult(true, plotsGeometryData);
    };

    getAddress = async coords => {
        const address = {
            zone: this.getRandom(),
            sector: this.getRandom(),
            plot: this.getRandom(),
        };
        return this.delayedResult(true, address);
    };

    getRandom = () => Math.floor(Math.random() * 100 + 1);

    delayedResult = (success, data, latency) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (success) resolve(data);
                else reject(data);
            }, latency || this.latency);
        });
    };
}

export default MockApi;
