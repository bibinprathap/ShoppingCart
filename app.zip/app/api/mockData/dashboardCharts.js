export default [
    {
        type: 'bar',
        name: 'ADM Bar Chart',
        title: 'asasd',
        showValues: true,
        showYScale: true,
        showXScale: true,
        chartHeight: 500,
        vType: [{ vlabel: 'abc', svg: { fill: '#cc00ff' } }, { vlabel: 'xyz', svg: { fill: '#009900' } }],
        data1: [
            { key: 1, amount: 75, label: 'Jan', svg: { fill: '#cc00ff' } },
            { key: 2, amount: 22, label: 'Feb', svg: { fill: '#0066ff' } },
            { key: 3, amount: 70, label: 'Mar', svg: { fill: '#ff0000' } },
            { key: 4, amount: 95, label: 'Apr', svg: { fill: '#009900' } },
            { key: 5, amount: 53, label: 'May', svg: { fill: '#0000ff' } },
            { key: 6, amount: 50, label: 'Jun', svg: { fill: '#0000ff' } },
            { key: 7, amount: 10, label: 'Jul', svg: { fill: '#0066ff' } },
        ],
        data2: [
            { key: 1, amount: 35, label: 'Jan', svg: { fill: '#cc00ff' } },
            { key: 2, amount: 52, label: 'Feb', svg: { fill: '#0066ff' } },
            { key: 3, amount: 10, label: 'Mar', svg: { fill: '#ff0000' } },
            { key: 4, amount: 9, label: 'Apr', svg: { fill: '#009900' } },
            { key: 5, amount: 43, label: 'May', svg: { fill: '#0000ff' } },
            { key: 6, amount: 70, label: 'Jun', svg: { fill: '#0000ff' } },
            { key: 7, amount: 70, label: 'Jul', svg: { fill: '#0066ff' } },
        ]

    },
    {
        type: 'pie',
        name: 'ADM Pie Chart',
        title: 'asasd',
        showValues: true,
        showYScale: true,
        showXScale: true,
        chartHeight: 450,
        data: [
            { key: 1, amount: 75, label: 'Jan', svg: { fill: '#cc00ff' } },
            { key: 2, amount: 22, label: 'Feb', svg: { fill: '#0066ff' } },
            { key: 3, amount: 70, label: 'Mar', svg: { fill: '#ff0000' } },
            { key: 4, amount: 95, label: 'Apr', svg: { fill: '#009900' } },
            { key: 5, amount: 53, label: 'May', svg: { fill: '#0000ff' } },
            { key: 6, amount: 50, label: 'Jun', svg: { fill: '#0000ff' } },
            { key: 7, amount: 10, label: 'Jul', svg: { fill: '#0066ff' } },




        ]
    },
    {
        type: 'line',
        name: 'ADM Line Chart',
        title: 'asasd',
        showValues: true,
        showYScale: true,
        showXScale: true,
        chartHeight: 500,
        vType: [{ vlabel: 'abc', svg: { fill: '#cc00ff' } }],
        data: [
            { key: 1, amount: 75, label: 'abc', svg: { fill: '#cc00ff' } },
            { key: 2, amount: 22, label: 'abc', svg: { fill: '#cc00ff' } },
            { key: 3, amount: 70, label: 'abc', svg: { fill: '#cc00ff' } },
            { key: 4, amount: 95, label: 'abc', svg: { fill: '#cc00ff' } },
            { key: 5, amount: 53, label: 'abc', svg: { fill: '#cc00ff' } },
            { key: 6, amount: 50, label: 'abc', svg: { fill: '#cc00ff' } },
        ]
    },
];
