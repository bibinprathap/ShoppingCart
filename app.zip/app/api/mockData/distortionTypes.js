export default [
    {
        serviceId: '1.1',
        titleE: 'Etisalat',
        titleA: 'اتصالات',
    },
    {
        serviceId: '1.2',
        titleE: 'Tadweer',
        titleA: 'تدوير',
    },
    {
        serviceId: '1.3',
        titleE: 'Abu Dhabi Distribution Company',
        titleA: 'شركة ابوظبي للتوزيع',
    },
    {
        serviceId: '1.4',
        titleE: 'Du Telecom',
        titleA: 'دو شركة اتصالات',
    },
    {
        serviceId: '1.5',
        titleE: 'Department of Transport',
        titleA: 'دائرة النقل',
    },
    {
        serviceId: '1.6',
        titleE: 'Abu Dhabi Police',
        titleA: 'شرطة أبوظبي',
    },
];
