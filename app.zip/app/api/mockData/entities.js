export default entities = [
    {
        entityConst: 'AWQAF',
        titleE: 'General Authority of Islamic Affairs & Endowments - Awqaf',
        titleA: 'الهيئة العامة للشؤون الاسلامية والأوقاف',
    },
    {
        entityConst: 'ADAFSA',
        titleE: 'Abu Dhabi Agriculture & Food Safety Authority',
        titleA: 'هيئة أبوظبي للزراعة والسلامة الغذائية',
    },
    {
        entityConst: 'ADSSC',
        titleE: 'Abu Dhabi Sewerage Services Company',
        titleA: 'شركة أبوظبي لخدمات الصرف الصحي',
    },
    {
        entityConst: 'EA',
        titleE: 'Environment Agency - Abu Dhabi',
        titleA: 'هيئة البيئة - أبوظبي',
    },
    {
        entityConst: 'ITC',
        titleE: 'Integrated Transport Center',
        titleA: 'مركز النقل المتكامل',
    },
    {
        entityConst: 'ADDC',
        titleE: 'Abu Dhabi Distribution Co.',
        titleA: 'شركة أبوظبي للتوزيع',
    },
    {
        entityConst: 'ADM',
        titleE: 'Abu Dhabi City Municipality',
        titleA: 'بلدية مدينة أبوظبي',
    },
    {
        entityConst: 'TADWEER',
        titleE: 'Tadweer',
        titleA: 'تدوير',
    },
];
