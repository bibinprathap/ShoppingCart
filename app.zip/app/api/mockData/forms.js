export const generalFormConfig = {
    name: 'generalInformation',
    lable: 'General Information',
    showLabels: false,
    fields: [
        {
            name: 'someSetting',
            type: 'switch',
            labelE: 'Some Setting',
            labelA: 'بعض الإعداد',
            icon: 'settings',
            iconType: 'default',
        },
        {
            name: 'reconcile',
            type: 'custom',
            labelE: 'Reconcile',
            labelA: 'تصالح',
            icon: 'mode-edit',
            iconType: 'default',
        },
        {
            name: 'remarks',
            type: 'text',
            labelE: 'Remarks',
            labelA: 'ملاحظات',
            placeholderE: 'Remarks',
            placeholderA: 'ملاحظات',
            maxLength: 100,
            multiline: true,
            mode: 'flat',
        },
    ],
};

export const testFormConfig = {
    name: 'testForm',
    titleE: 'Test Custom Form',
    titleA: 'Test Custom Form',
    showLabels: true,
    fields: [
        {
            name: 'firstName',
            type: 'text',
            labelE: 'First Name',
            labelA: 'الاسم الاول',
            placeholderE: 'Enter first name here...',
            placeholderA: 'أدخل الاسم الأول هنا',
        },
        {
            name: 'middleName',
            type: 'text',
            labelE: 'Middle Name',
            labelA: 'الاسم الوسطى',
            placeholderE: 'Enter middle name here...',
            placeholderA: 'أدخل الاسم الأوسط هنا',
        },
        {
            name: 'lastName',
            type: 'text',
            labelE: 'Last Name',
            labelA: 'الكنية',
            placeholderE: 'Enter last name here...',
            placeholderA: 'أدخل الكنية هنا',
        },
    ],
};
