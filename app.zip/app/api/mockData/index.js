import services from './services';
import lawClauses from './lawClauses';
import inspectionInstance from './inspectionInstance';
import { testFormConfig, generalFormConfig } from './forms';
import receiptTemplate from './receiptTemplate';
import dataLookups from './datalookups';
import dashboardCharts from './dashboardCharts';
import tasks from './tasks';
import inspectorPlanStatus from './inspectorPlanStatus';
import plotsInspectionsData from './plotsInspectionsData';
import inspection from './inspection';
import searchResults from './searchResults';
import { printTemplateHeader, printTemplateContent, printTemplateFooter, testTemplate } from './printTemplates';
const distortionTypes = dataLookups.filter(data => data.type === 'distortionType');
export {
    services,
    inspectionInstance,
    testFormConfig,
    generalFormConfig,
    receiptTemplate,
    lawClauses,
    distortionTypes,
    dataLookups,
    printTemplateHeader,
    printTemplateContent,
    printTemplateFooter,
    dashboardCharts,
    testTemplate,
    inspectorPlanStatus,
    plotsInspectionsData,
    tasks,
    inspection,
    searchResults,
};
