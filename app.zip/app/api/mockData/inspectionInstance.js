export default {
    inspections: [
        {
            visitDate: '2019-01-01',
            inspectorId: 1,
            values: { '1.1': 'yes', '1.2': 'no', '1.3': 'na' },
        },
        {
            visitDate: '2019-01-02',
            inspectorId: 1,
            values: { '1.1': 'yes', '1.2': 'yes', '1.3': 'yes' },
        },
    ],
};
