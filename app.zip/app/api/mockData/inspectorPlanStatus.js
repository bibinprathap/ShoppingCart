export default (inspectorPlanStatus = [
    {
        inspectorId: 123,
        plots: [
            { plotId: 1, plotTitle: 'A1', status: 'completed' },
            { plotId: 2, plotTitle: 'A2', status: 'pending' },
            { plotId: 3, plotTitle: 'A3', status: 'inprogress' },
        ],
    },
    {
        inspectorId: 456,
        plots: [
            { plotId: 4, plotTitle: 'B2', status: 'completed' },
            { plotId: 5, plotTitle: 'B2', status: 'pending' },
            { plotId: 6, plotTitle: 'B3', status: 'inprogress' },
        ],
    },
]);
