export default (inspectorPlanStatus = [
    {
        inspectorId: 123,
        plots: [
            { plotId: 1, plotTitle: 'A1', status: 'completed' },
            { plotId: 2, plotTitle: 'A2', status: 'pending' },
            { plotId: 3, plotTitle: 'A3', status: 'inprogress' },
            { plotId: 4, plotTitle: 'A4', status: 'completed' },
            { plotId: 5, plotTitle: 'A5', status: 'pending' },
            { plotId: 6, plotTitle: 'A6', status: 'inprogress' },
            { plotId: 7, plotTitle: 'A7', status: 'completed' },
            { plotId: 8, plotTitle: 'A8', status: 'pending' },
            { plotId: 9, plotTitle: 'A9', status: 'inprogress' },
            { plotId: 10, plotTitle: 'A10', status: 'completed' },
            { plotId: 11, plotTitle: 'A11', status: 'pending' },
            // { plotId: 12, plotTitle: 'A12', status: 'inprogress' },
        ],
    },
    {
        inspectorId: 456,
        plots: [
            { plotId: 4, plotTitle: 'B2', status: 'completed' },
            { plotId: 5, plotTitle: 'B2', status: 'pending' },
            { plotId: 6, plotTitle: 'B3', status: 'inprogress' },
        ],
    },
]);
