export default (plotsInspectionsData = [
    { id: 1, geometry: [{ latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }] },
    { id: 2, geometry: [{ latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }] },
    { id: 3, geometry: [{ latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }, { latitude: 123, longitude: 567 }] },
]);
