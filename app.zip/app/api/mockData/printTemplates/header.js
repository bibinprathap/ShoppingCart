export default `^FX ************* Starts here *************
{% assign titleMuncipalityofAbuDhabiCity_ar = "دائرة التخطيط العمراني والبلديات" -%}
{% assign titleMuncipalityofAbuDhabiCity_en = "DEPARTMENT OF URBAN PLANNING" -%}
{% assign titleMuncipalityofAbuDhabiCity_line2_en = "AND MUNICIPALITIES" -%}
{% assign titleMuncipalCenter_ar = "مركز البلدية" -%}
{% assign titleMuncipalCenter_en = "Municipal Center" -%}
{% assign titleDateTime_ar = "التاريخ/ الوقت" -%}
{% assign titleDateTime_en = "Date/Time" -%}
{% assign titleZoneSectorPlot_ar = "المنطقة/الحوض/رقم القطعة" -%}
{% assign titleZoneSectorPlot_en = "Zone/Sector/Plot" -%}
{% assign titleViolationType_ar = "نوع المخالفة" -%}
{% assign titleViolationType_en = "Violation Type" -%}
{% assign titleViolationAmount_ar = "قيمة المخالفة" -%}
{% assign titleViolationAmount_en = "Total Violation Amount" -%}
{% assign titleViolatorDetails_ar = "مجموع الانتهاك المبلغ" -%}
{% assign titleViolatorDetails_en = "Violator Details" -%}
{% assign titleNote_ar = "الملاحظات" -%}
{% assign titleNote_en = "Note" -%}
{% assign titleIDRecieved_ar = "قبول التصالح" -%}
{% assign titleIDRecieved_en = "Accept Reconciliation Law" -%}
{% assign titleInspectorCode_ar = "قبول التصالح" -%}
{% assign titleInspectorCode_en = "Inspector Code" -%}
{% assign labelLength = 450 -%}
{% assign labelheight = 50 -%}
{% assign maxCharactersPerLine = 47 -%}
{% assign headerHeight = 320 -%}
{% assign fBufferHeight = 1.10 -%}
{% assign lineCharHeight_en = 40 -%}
{% assign lineCharHeight_ar = 50 -%}
{% assign probableNoOfLinesForViolations = violations | getProbableNoOfLinesForViolations: fBufferHeight, maxCharactersPerLine -%}
{% assign probableNoOfLinesForAddress = zoneSecPlot | getLines: maxCharactersPerLine -%}
{% assign probableNoOfLinesForNote = note | getProbableNoOfLinesForNote: maxCharactersPerLine, fBufferHeight -%}
{% assign probableNoOfLinesForViolatorDetails = violatorDetailsList | getProbableNoOfLinesForViolatorDetails: maxCharactersPerLine -%}
{% assign notesArray = note | getNoteArray -%}
{% assign labelLengthCalulated = probableNoOfLinesForViolations | plus: probableNoOfLinesForNote, probableNoOfLinesForAddress, probableNoOfLinesForViolatorDetails | times: lineCharHeight_ar | times: fBufferHeight -%}
{% assign labelLength = labelLength | plus: labelLengthCalulated -%}
{% if labelLength < 1600 -%}
  {% assign labelLength = 1600 -%}
{% endif -%}
^XA^POI^MNV^LL{{labelLength | ceil}}^XZ^XA^JUS^XZ
^FX ************* Header *************
^XA^PA0,1,1,1
^FO25,0^TBN,500,50^A@N,46,46,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_ar}}
^FS
^FO80,60^FB500,1,0,J,2^A@N,28,28,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_en}}
^FS
^FO65,95^FB500,1,0,R,2^A@N,28,28,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_line2_en}}
^FS
^FX ************* Violation Title *************
^FO220,120^TBN,500,50^A@N,40,40,TT0003M_^CI17^F8^FD
{{selectedActionTypeA}}
^FS
^FO25,160^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^FD
{{selectedActionTypeE}}
^FS
^FX ************* Reference Number *************
^BY2,2,50
^FO75,200^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^BC^FD
{{referenceNumber}}
^FS
^FX ************* Line  *************
^FO25,290^GB500,1,3^FS
^FX ************* Second section with all info details *************
^FO25,{{headerHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleMuncipalCenter_en}}
^FS
^FO525,{{headerHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleMuncipalCenter_ar}}
^FS
{% assign currentHeight = headerHeight | plus: labelheight -%}
^FX ************* English MuncipalCenterName *************
^FO25,{{ currentHeight }}^A@N,20,20,TT0003M_^CI17^F8^FD
{{muncipalCenterName_en}}
^FS
^FX ************* Arabic MuncipalCenterName *************
^FO525,{{ currentHeight }},2^A@N,30,30,TT0003M_^CI17^F8^FD
{{muncipalCenterName_ar}}
^FS
^FX ************* Date and Time Title *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleDateTime_en}}
^FS
^FO525,{{currentHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleDateTime_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* English Date Time *************
^FO165,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{visitDate}}
^FS
^FX ************* Zone, Sector, Plot *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Plot details in Arabic *************
^FO525,{{currentHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleZoneSectorPlot_ar}}
^FS
^FX ************* Plot details in English *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleZoneSectorPlot_en}}
^FS
^FX ************* Address section *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
{% assign isPlotDetailsInArabic = zoneSecPlot | isProbablyArabic %}
^FX ************* Plot section starts here *************
{% if zoneSecPlot.size > 0 and isPlotDetailsInArabic == true %}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine}}^FD
{{zoneSecPlot}}
^FS
{% endif -%}
{% if zoneSecPlot.size > 0 and isPlotDetailsInArabic == false - %}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine}}^FD
{{zoneSecPlot}}
^FS
{% endif -%}
^FX ************* Plot section ends here *************
{% assign currentHeight = zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine | plus: currentHeight -%}
^FX ************* Header ends here *************`;
