import printTemplateHeader from './header';
import printTemplateContent from './content';
import printTemplateFooter from './footer';
import testTemplate from './testTemplate';

export { printTemplateHeader, printTemplateContent, printTemplateFooter, testTemplate };
