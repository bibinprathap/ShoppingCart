// export default `^FX ************* Starts here *************
// ^XA^POI^MNV^LL200^XZ^XA^JUS^XZ
// ^FX ************* Header *************
// ^XA^PA0,1,1,1
// ^BY3,2,50
// ^FO25,50^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^BC^FD
// 12345678
// ^FS
// ^XZ`;

export default `^FX ************* Starts here *************
^XA^POI^MNV^LL500^XZ^XA^JUS^XZ
^FX ************* Header *************
^XA^PA0,1,1,1
^FO25,0^TBN,500,50^A@N,46,46,TT0003M_^CI17^F8^FD
دائرة التخطيط العمراني والبلديات
^FS
^FO80,60^FB500,1,0,J,2^A@N,28,28,TT0003M_^CI17^F8^FD
DEPARTMENT OF URBAN PLANNING
^FS
^FO65,95^FB500,1,0,R,2^A@N,28,28,TT0003M_^CI17^F8^FD
AND MUNICIPALITIES
^FS
^FX ************* Violation Title *************
^FO220,120^TBN,500,50^A@N,40,40,TT0003M_^CI17^F8^FD
عنيف
^FS
^FO25,160^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^FD
Violations
^FS
^FX ************* Reference Number *************
^BY2,2,50
^FO75,200^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^BC^FD
20190716120923293
^FS
^FX ************* Line  *************
^FO25,290^GB500,1,3^FS
^FX ************* Second section with all info details *************
^FO25,320^A@N,25,25,TT0003M_^CI17^F8^FD
Municipal Center
^FS
^XZ`;

// export default `^XA^POI^MNV^LL200^XZ^XA^JUS^XZ
// ^XA^PA0,1,1,1
// ^FO25,0^TBN,500,50^A@N,46,46,TT0003M_^CI17^F8^FD
// اختبارات
// ^FS
// ^FO80,60^FB500,1,0,J,2^A@N,28,28,TT0003M_^CI17^F8^FD
// TESTING
// ^FS
// ^XZ`;
