export const simpleCustomerCompanyModels = [
    {
        customerId: 9001,
        customerType: 'C',
        customerNameA: 'الشركة الأولى',
        customerNameE: 'First Company',
        nationalityId: 1,
        identityNumber: '9001',
        identityExpiryDate: '',
        phoneNumber: '+971501234567',
        email: 'firstcompany@domain.com',
    },
    {
        customerId: 9002,
        customerType: 'C',
        customerNameA: 'الشركة الثانية',
        customerNameE: 'Second Company',
        nationalityId: 1,
        identityNumber: '9002',
        identityExpiryDate: '',
        phoneNumber: '+971503453424',
        email: 'firstcompany@domain.com',
    },
];

export const simpleCustomerPersonModels = [
    {
        customerId: 9003,
        customerType: 'P',
        customerNameA: 'شخص أولا',
        customerNameE: 'First Person',
        nationalityId: 1,
        identityNumber: '9003',
        identityExpiryDate: '',
        phoneNumber: '+97150564524',
        email: 'firstperson@domain.com',
    },
    {
        customerId: 9004,
        customerType: 'P',
        customerNameA: 'شخص ثاني',
        customerNameE: 'Second Person',
        nationalityId: 1,
        identityNumber: '9004',
        identityExpiryDate: '',
        phoneNumber: '+971504289353',
        email: 'secondperson@domain.com',
    },
];

export const simpleCustomerMixModels = [...simpleCustomerCompanyModels, ...simpleCustomerPersonModels];
