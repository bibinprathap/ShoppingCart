addDays = function(days) {
    var date = new Date();
    date.setDate(date.getDate() + days);
    return date;
};

export default {
    2323232323: {
        title: 'Distrotions at Salam Street',
        assignedDate: addDays(-2),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(2),
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '1',
        status: 'new',
        parentRefNo: '21541525415454',
        icon: { type: 'custom', name: 'home' },
        priority: 3,
        assignedToInspectorId: 1134,
    },
    23232323232: {
        title: 'Building Penalities at musaffah',
        assignedDate: addDays(-1),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(2),
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '2.1.1',
        status: 'new',
        parentRefNo: '21541525415454',
        icon: { type: 'custom', name: 'review' },
        assignedToInspectorId: 1134,
        priority: 3,
    },
    232323232334: {
        title: 'General Appearance at Al Ain',
        assignedDate: addDays(-6),
        deadlineFromDate: addDays(-2),
        deadlineToDate: addDays(-2),
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '3.1',
        status: 'new',
        parentRefNo: '21541525415454',
        icon: { type: 'custom', name: 'review' },
        assignedToInspectorId: 1134,
        priority: 2,
    },
    232323232345: {
        title: 'Abandoned Vehicles at shahama',
        assignedDate: addDays(-8),
        deadlineFromDate: addDays(+24),
        deadlineToDate: addDays(+26),
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '4',
        status: 'completed',
        parentRefNo: '21541525415454',
        icon: { type: 'custom', name: 'review' },
        assignedToInspectorId: 1134,
        priority: 1,
    },
};
