addDays = function(days) {
    var date = new Date();
    date.setDate(date.getDate() + days);
    return date;
};

export default {
    2323232323: {
        title: 'Distrotions at Salam Street',
        assignedBy: 'Sayed Ahammed Abdul',
        assignedDate: addDays(-2),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(2),
        typeOfTasks: 'Inspection Plan',
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '5',
        remarks: 'Need to Check Distrotions Near this Area',
        status: 'new',
        parentRefNo: '21541525415454',
    },
    23232323232: {
        title: 'Building Penalities at musaffah',
        assignedBy: 'Sayed Ahammed Abdul',
        assignedDate: addDays(-1),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(2),
        typeOfTasks: 'Inspection Plan',
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '5',
        remarks: 'Need to Check Building Penalities around this Area',
        status: 'new',
        parentRefNo: '21541525415454',
    },
    232323232334: {
        title: 'General Appearance at Al Ain',
        assignedBy: 'Sayed Ahammed Abdul',
        assignedDate: addDays(-3),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(2),
        typeOfTasks: 'Inspection Plan',
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '5',
        remarks: 'Need to Check General Appearance  around this Area',
        status: 'new',
        parentRefNo: '21541525415454',
    },
    232323232345: {
        title: 'Abandoned Vehicles at shahama',
        assignedBy: 'Sayed Ahammed Abdul',
        assignedDate: addDays(-4),
        deadlineFromDate: addDays(1),
        deadlineToDate: addDays(1),
        typeOfTasks: 'Inspection Plan',
        location: { coords: { latitude: 24.4874002, longitude: 54.3782985 }, address: { zone: 72, sector: 28, plot: 79 } },
        selectedService: '5',
        remarks: 'Need to Check Abandoned Vehicles around this Area',
        status: 'new',
        parentRefNo: '21541525415454',
    },
};
