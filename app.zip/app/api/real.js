import moment from 'moment';
import { services, lawClauses } from 'app/api/mockData';
//import { authorize } from 'ThirdPartyModules/react-native-app-auth';
import { authorize } from 'ThirdPartyModules/react-native-app-auth';
import { config as smartPassConfig, apiUrl as smartPassUrl } from 'app/config/smartPass';
import pinch from 'react-native-pinch';
import DeviceInfo from 'react-native-device-info';
import MockApi, { duplicateMock, checkListDuplicateMock } from './mock';
import RestApi from './restApi';

import createError from 'app/api/helperServices/errors';

const isEmulator = DeviceInfo.isEmulator();

const mockApi = new MockApi();

export default class AppApi {
    addSSL = config => {
        let newConfig = { ...config };
        if (!isEmulator) {
            //do not add sslPinning for Emulator
            //console.log('bypassing SSLPinning');
        } else {
            //console.log('added SSLPinning');
            newConfig.sslPinning = {
                cert: 'DMAROOTCA',
            };
        }
        return newConfig;
    };

    getJsonFromResponse = response => {
        if (response && response.bodyString) return JSON.parse(response.bodyString);
        else return response;
    };

    parseGender = gender => {
        if (!gender) return;
        switch (gender.toLowerCase()) {
            case 'male':
                return 1;
            case 'female':
                return 2;
            default:
                return;
        }
    };

    smartPassSso = async () => {
        let tokenUrl, tokenRequestConfg;
        try {
            const response = await authorize(smartPassConfig);
            tokenUrl = `${smartPassUrl}/secure/oauth2/access_token?realm=/TRA&code=${
                response.code
            }&redirect_uri=ae.abudhabi.dma.dev.singlewindow://msServices_ADM&grant_type=authorization_code`;
            //Todo: extract this logic into a helper
            tokenRequestConfg = this.addSSL({
                method: 'post',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'Basic YWRtOkMtQi1QcyRVM3c3XjhOTQ==',
                },
            });
        } catch (error) {
            console.log('error checkpoint 1: ', { error });
            throw error;
        }
        const tokenResponse = await pinch.fetch(tokenUrl, tokenRequestConfg);
        const tokenData = this.getJsonFromResponse(tokenResponse);
        const access_token = tokenData.access_token;
        const userInfoUrl = `${smartPassUrl}/secure/oauth2/userinfo?realm=/TRA`;

        //Todo: extract this logic into a helper
        const userInfoRequestConfig = this.addSSL({
            method: 'get',
            headers: {
                accept: 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${access_token}`,
            },
        });

        const userInfoResponse = await pinch.fetch(userInfoUrl, userInfoRequestConfig);
        const userData = this.getJsonFromResponse(userInfoResponse);
        return { tokenData, userData };
    };

    smartHubSso = async (tokenData, userData) => {
        /*
        Todo: from ssoUserProfileModel remove the following for golive,
              these values are temporarily for working with unverified SmartPass accounts during development
            * idnNotVerified
            * `${userData.firstnameEN} ${userData.lastnameEN}`
        */
        const ssoUserProfileModel = {
            userType: userData.userType,
            uuid: userData.uuid,
            //Todo: remove the idnNotVerified in next line, it is
            nationalNumber: userData.idn || userData.idnNotVerified,
            idCardExpiryDate: userData.idCardExpiryDate,
            customerNameA: userData.fullnameAR || `${userData.firstnameEN} ${userData.lastnameEN}`,
            customerNameE: userData.fullnameEN || `${userData.firstnameEN} ${userData.lastnameEN}`,
            gender: this.parseGender(userData.gender),
            email: userData.email,
            mobile: userData.mobile,
            deviceId: DeviceInfo.getDeviceId(),
            osversion: DeviceInfo.getSystemVersion(),
        };
        /* SmartHub Login*/
        const restApi = new RestApi({ controller: 'User', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'SsoLogin',
                body: ssoUserProfileModel,
            });
            if (smartHubResponse.data.success) return smartHubResponse.data.result;
            else throw smartHubResponse.data.error;
        } catch (error) {
            //if SmartHub login fails, we must logout from SmartPass as well,
            //otherwise when user hits SmartPass login button next time, it doesn't ask for credentials
            this.smartPassLogout(tokenData.id_token, tokenData.access_token);
            throw error;
        }
    };

    basicLogin = async (username, password) => {
        const restApi = new RestApi({ controller: 'Account', dispatch: this.dispatch, seure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'Login',
                body: { username, password },
            });
            let authCode;
            if (smartHubResponse.data.success) {
                //RJ: When there are more than one 'set-cookie' headers, this will not work due to a bug in fetch.
                //Todo: Try this solution to workaround the set-cookie issu: https://github.com/facebook/react-native/issues/18837#issuecomment-398779994
                const cookies = smartHubResponse.headers['set-cookie'];
                // console.log('basicLogin.cookies: ', cookies);
                for (let cookie of cookies) {
                    if (cookie) {
                        //console.log('basicLogin.cookie: ', cookie);
                        /*
                        sample success cookie
                        .ASPXAUTH=3F916A22E63376725925AB22166FEEFD0A6DA361A79B9ED302F2D97EFF6158C258A18902212285714223FD6B0A0F80264F17625F1E91C6D6764720139DAF7EB88010A28898FB1BA8E5BE50689A3648F45240E8A71A1AF84BA6BDBB37E1D1941B2F0DDF2E860640BCE0024778694974E1B8E1AFC98F511353E18FDB4617238D5F4D02B21C6CEE83633F2ED144BA951EDB2785864B; expires=Sun, 05-May-2019 19:59:59 GMT; path=/
                        */
                        var matches = cookie.match(/(.ASPXAUTH=)(\w+);/i);
                        if (matches && matches.length >= 3 && matches[2] && matches[2].length > 0) {
                            authCode = matches[2];
                        }
                    }
                }
                if (authCode) {
                    return authCode;
                } else {
                    throw Error('SmartHub did not return authcode');
                }
            } else throw smartHubResponse.data.error;
        } catch (error) {
            throw createError(error);
        }
    };

    getPofiles = async authCode => {
        const restApi = new RestApi({ controller: 'Profiles', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'GetMimsProfiles',
                body: { authCode },
            });
            if (smartHubResponse.data.success) {
                const profiles = smartHubResponse.data.result;
                return profiles;
            }
        } catch (error) {
            throw error;
        }
    };

    getCompanyProfile = async licenseNo => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'GetCompanyProfile',
                body: { tradeLicenseNumber: licenseNo },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getPersonProfile = async emiratesId => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'GetPersonProfile',
                body: { NationalNumber: emiratesId },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getInspection = async inspectionRef => {
        return mockApi.getInspection(inspectionRef);

        // const restApi = new RestApi({ controller: 'Inspection' });
        // try {
        //     let response = await restApi.post({
        //         url: 'getInspection',
        //         body: { ref: inspectionRef },
        //         cancelable: true,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };

    deleteUploadedDocument = async filename => {
        const restApi = new RestApi({ controller: 'DummyMims' });
        try {
            let response = await restApi.post({
                url: 'Delete_multipart',
                body: { filename },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    // Get printer template
    getPrintTemplate = async licenseNo => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'getPrintTemplate',
                body: {},
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    smartPassLogout = async (id_token, access_token) => {
        let endSessionUrl, endSessionConfig, revokeTokensUrl, revokeTokensConfig;
        try {
            endSessionUrl = `${smartPassUrl}/secure/oauth2/connect/endSession?id_token_hint=${id_token}`;
            //Todo: extract this logic into a helper
            endSessionConfig = this.addSSL({
                method: 'get',
                headers: {
                    Authorization: `Bearer ${access_token}`,
                },
            });
        } catch (error) {
            console.log('error endSession ', { error });
            throw error;
        }
        const endSessionResponse = await pinch.fetch(endSessionUrl, endSessionConfig);
        // console.log('endSession Response  ' + JSON.stringify(endSessionResponse));

        try {
            // console.log('1');
            revokeTokensUrl = `${smartPassUrl}/secure/frrest/oauth2/token/${access_token}?_action=revokeTokens`;
            //Todo: extract this logic into a helper
            console.log('2' + revokeTokensUrl);
            revokeTokensConfig = this.addSSL({
                method: 'post',
                body: '{ "client_id": "adm" }',
                headers: {
                    'Accept-API-Version': 'protocol=1.0,resource=1.0',
                    'Content-Type': 'application/json',
                },
            });
            // console.log('3 ' + JSON.stringify(revokeTokensConfig));
        } catch (error) {
            console.log('error revokeTokens ', { error });
            throw error;
        }
        //console.log('4 ' + JSON.stringify(revokeTokensConfig));
        const revokeTokensResponse = await pinch.fetch(revokeTokensUrl, revokeTokensConfig);
        //console.log('revokeTokensResponse  ' + JSON.stringify(revokeTokensResponse));
    };

    checkDuplicate = async duplicateCheckRequestModel => {
        const restApi = new RestApi({ controller: 'DummyMims' });
        try {
            const response = await restApi.post({
                url: 'CheckDuplicate',
                body: { value: duplicateCheckRequestModel },
                cancelable: true,
                showAlerts: false,
            });
            if (duplicateCheckRequestModel.selectedCategory == 'DISTORTION') return duplicateMock;
            else if (duplicateCheckRequestModel.selectedCategory == 'INSPECTION') return checkListDuplicateMock;
            else return duplicateMock;

            //    return response.data.result;
        } catch (error) {
            throw error;
        }
    };
    // createInspectionRecord = async createInspectionModel => {
    //     const restApi = new RestApi({ controller: 'DummyMims' });
    //     try {
    //         const response = await restApi.post({
    //             url: 'CreateInspectionRecord',
    //             body: { value: createInspectionModel },
    //             cancelable: false,
    //             showAlerts: false,
    //         });
    //         return response.data.result;
    //     } catch (error) {
    //         throw error;
    //     }
    // };
    createInspectionRecord = createInspectionModel => mockApi.createInspectionRecord(createInspectionModel);
    trackingLocationUpdate = async data => {
        return { TrackingLocationUpdate: 'dummy success', ...data };
        // const restApi = new RestApi({ controller: 'DummyMims' });
        // try {
        //     let response = await restApi.post({
        //         url: 'TrackingLocationUpdate',
        //         body: data,
        //         cancelable: false,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };
    /* mock api calls */
    getInitialTasks = userData => mockApi.getInitialTasks(userData);
    adminLogin = (username, password, success = true) => mockApi.adminLogin(username, password, success);
    //checkDuplicate = (duplicateCheckRequestModel, success = true) => mockApi.checkDuplicate(duplicateCheckRequestModel, success);
    loadMasterdata = lastUpdated => mockApi.loadMasterdata(lastUpdated);
    createInspection = params => mockApi.createInspection(params);
    getDashboardCharts = () => mockApi.getDashboardCharts();
    getBuildingDetails = params => mockApi.getBuildingDetails(params);
    getInspectorPlanStatus = async inspectorDomainCustomerId => {
        console.log('aaaaaaa');
        return mockApi.getInspectorPlanStatus(inspectorDomainCustomerId);
    };

    getInspectionsPlotsData = async plotIDS => {
        return mockApi.getInspectionsPlotsData(plotIDS);
    };
    getBuildingDetails = params => mockApi.getBuildingDetails(params);
    getAddress = coords => mockApi.getAddress(coords);
}
