import moment from 'moment';
import { violationTypes } from 'app/api/mockData';
//import { authorize } from 'ThirdPartyModules/react-native-app-auth';
import { authorize } from 'ThirdPartyModules/react-native-app-auth';
import { config as smartPassConfig, apiUrl as smartPassUrl } from 'app/config/smartPass';
import pinch from 'react-native-pinch';
import DeviceInfo from 'react-native-device-info';
import axios from 'axios';
import MockApi, { duplicateMock, checkListDuplicateMock } from './mock';
import { objectToGisFilter, objectToQueryString } from 'app/api/helperServices/utils';
import RestApi from './restApi';
import gisMapping from 'app/api/gisMapping';
import { _ } from 'lodash';
import createError from 'app/api/helperServices/errors';
import { store } from 'app/config/store';

const isEmulator = DeviceInfo.isEmulator();

const mockApi = new MockApi();

const layersEnum = { municipality: 3, zone: 2, sector: 1, plot: 0, address: 5 };
const defaultGISOptions = {
    outFields: '*',
    returnGeometry: false,
};

const mapGISFields = (layer, direction, params) => {
    var mappedObj = {};
    const mapping = gisMapping[layer];
    for (var i = 0; i < mapping.length; i++) {
        const fromKey = direction === 'in' ? mapping[i][0] : mapping[i][1];
        const toKey = direction === 'in' ? mapping[i][1] : mapping[i][0];
        //const mappingElement = mapping[i];
        if (typeof params[fromKey] !== 'undefined') {
            mappedObj[toKey] = params[fromKey];
        }
    }

    return mappedObj;
};

export const replaceFieldNames = (layer, direction, fields) => {
    const fieldsSplit = (fields && fields.split(',')) || [];
    const mapping = gisMapping[layer];
    const mappedFields = fieldsSplit.map(f => {
        if (direction === 'in') {
            const mappingElement = _.find(mapping, pair => {
                return pair[0] == f;
            });
            if (mappingElement) return mappingElement[1];
        } else {
            const mappingElement = _.find(mapping, pair => {
                return pair[1] == f;
            });
            if (mappingElement) return mappingElement[0];
        }
    });
    return mappedFields.filter(f => f !== undefined).join(',');
};

const getGisQuery = (dynamicFilter, layer, options) => {
    let mergedOptions = { ...defaultGISOptions, ...options };
    const fixedFilter = { ...mergedOptions.filter };
    delete mergedOptions.filter;
    const mergedFilter = { ...dynamicFilter, ...fixedFilter };
    const gisFilter = objectToGisFilter(mergedFilter);

    gisFilter;

    mergedOptions = {
        ...mergedOptions,
        outFields: replaceFieldNames(layer, 'out', mergedOptions.outFields) || '*',
        orderByFields: replaceFieldNames(layer, 'out', mergedOptions.orderByFields),
    };
    const queryObj = {
        f: 'json',
        where: gisFilter || '1=1',
        ...mergedOptions,
    };

    const query = objectToQueryString(queryObj);
    const url = `${layer}/query?${query}`;
    return url;
};

const mapGisResult = (layer, result) => {
    if (result && result.data && result.data.features) {
        return result.data.features.map(f => {
            const mappedData = { ...mapGISFields(layer, 'in', f.attributes) };
            if (f.geometry && f.geometry.rings && f.geometry.rings.length > 0) {
                mappedData['geometry'] = f.geometry.rings[0].map(p => {
                    return {
                        latitude: p[1],
                        longitude: p[0],
                    };
                });
            }
            return mappedData;
        });
    }
    return null;
};

export default class AppApi {
    getZones = async ({ zoneId, municipalityCode, options } = {}) => {
        const dynamicFilter = { districtId: zoneId, municipalityName: municipalityCode };
        const url = getGisQuery(dynamicFilter, layersEnum.zone, options);
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            return mapGisResult(layersEnum.zone, result);
        } catch (err) {
            throw createError(err);
        }
    };

    getSectors = async ({ zoneId, sectorId, municipalityCode, options } = {}) => {
        const dynamicFilter = { districtId: zoneId, communityId: sectorId, municipality: municipalityCode };
        const url = getGisQuery(dynamicFilter, layersEnum.sector, options);
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            return mapGisResult(layersEnum.sector, result);
        } catch (err) {
            throw createError(err);
        }
    };

    getPlots = async ({ zoneId, sectorId, plotId, plotNumber, options } = {}) => {
        const dynamicFilter = { districtId: zoneId, communityId: sectorId, plotId, plotNumber };
        const url = getGisQuery(dynamicFilter, layersEnum.plot, options);
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            return mapGisResult(layersEnum.plot, result);
        } catch (err) {
            throw createError(err);
        }
    };

    getPlotsCustom = async (zoneId, sectorId, plotNumbers) => {
        const plotClause = plotNumbers.map(p => 'plotNumber=' + `'${p}'`).join(' or ');
        const url = `/0/query?where=1=1 and communityId=${sectorId} and districtId=${zoneId} and (${plotClause})&outFields=*&returnGeometry=true&f=json&orderByFields=plotnumber`;
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            return mapGisResult(layersEnum.plot, result);
        } catch (err) {
            throw createError(err);
        }
    };
    getAddress = async coords => {
        // debugger;
        const query = `query?where=&geometry=%7B%22x%22%3A${coords.longitude}%2C%22y%22%3A+${
            coords.latitude
        }%7D&geometryType=esriGeometryPoint&outFields=*&f=json`;
        let url = `/${layersEnum.address}/` + query;
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            const addressWithGeometry = mapGisResult(layersEnum.address, result);
            if (addressWithGeometry.length > 0) {
                let { geometry: _, ...address } = addressWithGeometry[0];
                // delete addressWithGeometry.geometry;
                return address;

                //console.log('getAddress(), got address with plot:', address);
                //return delayedResult(true, address, 5000);
            } else {
                url = `/${layersEnum.sector}/` + query;
                const sectorResult = await restApi.get({ url });
                const sectorAddress = mapGisResult(6, sectorResult);
                if (sectorAddress.length > 0) {
                    let { geometry: _, ...sectoraddress } = sectorAddress[0];
                    // delete addressWithGeometry.geometry;
                    // console.warn(JSON.stringify(sectoraddress));
                    return sectoraddress;

                    //console.log('getAddress(), got address without plot:', sectoraddress);
                    //return delayedResult(true, sectoraddress, 5000);
                }
                return null;
            }
        } catch (err) {
            throw createError(err);
        }
    };
    getPlotsDataGIS = async plotIDS => {
        //, =%2C
        //' =%27
        const query = `query?where=PLOTID+in+%28${plotIDS
            .map(p => '%27' + p + '%27')
            .join('%2C')}%29&geometryType=esriGeometryPoint&outFields=*&f=json`;
        let url = `/${layersEnum.address}/` + query;
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            const addressWithGeometry = mapGisResult(layersEnum.address, result);
            //  debugger;

            return addressWithGeometry;
        } catch (err) {
            throw createError(err);
        }
    };
    addSSL = config => {
        let newConfig = { ...config };
        if (!isEmulator) {
            //do not add sslPinning for Emulator
            //console.log('bypassing SSLPinning');
        } else {
            //console.log('added SSLPinning');
            newConfig.sslPinning = {
                cert: 'DMAROOTCA',
            };
        }
        return newConfig;
    };

    getJsonFromResponse = response => {
        if (response && response.bodyString) return JSON.parse(response.bodyString);
        else return response;
    };

    parseGender = gender => {
        if (!gender) return;
        switch (gender.toLowerCase()) {
            case 'male':
                return 1;
            case 'female':
                return 2;
            default:
                return;
        }
    };

    smartPassSso = async () => {
        let tokenUrl, tokenRequestConfg;
        try {
            const response = await authorize(smartPassConfig);
            tokenUrl = `${smartPassUrl}/secure/oauth2/access_token?realm=/TRA&code=${
                response.code
            }&redirect_uri=ae.abudhabi.dma.dev.singlewindow://msServices_ADM&grant_type=authorization_code`;
            //Todo: extract this logic into a helper
            tokenRequestConfg = this.addSSL({
                method: 'post',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'Basic YWRtOkMtQi1QcyRVM3c3XjhOTQ==',
                },
            });
        } catch (error) {
            console.log('error checkpoint 1: ', { error });
            throw error;
        }
        const tokenResponse = await pinch.fetch(tokenUrl, tokenRequestConfg);
        const tokenData = this.getJsonFromResponse(tokenResponse);
        const access_token = tokenData.access_token;
        const userInfoUrl = `${smartPassUrl}/secure/oauth2/userinfo?realm=/TRA`;

        //Todo: extract this logic into a helper
        const userInfoRequestConfig = this.addSSL({
            method: 'get',
            headers: {
                accept: 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${access_token}`,
            },
        });

        const userInfoResponse = await pinch.fetch(userInfoUrl, userInfoRequestConfig);
        const userData = this.getJsonFromResponse(userInfoResponse);
        return { tokenData, userData };
    };

    smartHubSso = async (tokenData, userData) => {
        /*
        Todo: from ssoUserProfileModel remove the following for golive,
              these values are temporarily for working with unverified SmartPass accounts during development
            * idnNotVerified
            * `${userData.firstnameEN} ${userData.lastnameEN}`
        */
        const ssoUserProfileModel = {
            userType: userData.userType,
            uuid: userData.uuid,
            //Todo: remove the idnNotVerified in next line, it is
            nationalNumber: userData.idn || userData.idnNotVerified,
            idCardExpiryDate: userData.idCardExpiryDate,
            customerNameA: userData.fullnameAR || `${userData.firstnameEN} ${userData.lastnameEN}`,
            customerNameE: userData.fullnameEN || `${userData.firstnameEN} ${userData.lastnameEN}`,
            gender: this.parseGender(userData.gender),
            email: userData.email,
            mobile: userData.mobile,
            deviceId: DeviceInfo.getDeviceId(),
            osversion: DeviceInfo.getSystemVersion(),
        };
        /* SmartHub Login*/
        const restApi = new RestApi({ controller: 'User', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'SsoLogin',
                body: ssoUserProfileModel,
            });
            if (smartHubResponse.data.success) return smartHubResponse.data.result;
            else throw smartHubResponse.data.error;
        } catch (error) {
            //if SmartHub login fails, we must logout from SmartPass as well,
            //otherwise when user hits SmartPass login button next time, it doesn't ask for credentials
            if (tokenData) {
                this.smartPassLogout(tokenData.id_token, tokenData.access_token);
            }
            throw error;
        }
    };

    basicLogin = async (username, password) => {
        const restApi = new RestApi({ controller: 'Account', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'Login',
                body: { username, password },
            });
            let authCode;
            if (smartHubResponse.data.success) {
                //RJ: When there are more than one 'set-cookie' headers, this will not work due to a bug in fetch.
                //Todo: Try this solution to workaround the set-cookie issu: https://github.com/facebook/react-native/issues/18837#issuecomment-398779994
                const cookies = smartHubResponse.headers['set-cookie'];
                // console.log('basicLogin.cookies: ', cookies);
                for (let cookie of cookies) {
                    if (cookie) {
                        //console.log('basicLogin.cookie: ', cookie);
                        /*
                        sample success cookie
                        .ASPXAUTH=3F916A22E63376725925AB22166FEEFD0A6DA361A79B9ED302F2D97EFF6158C258A18902212285714223FD6B0A0F80264F17625F1E91C6D6764720139DAF7EB88010A28898FB1BA8E5BE50689A3648F45240E8A71A1AF84BA6BDBB37E1D1941B2F0DDF2E860640BCE0024778694974E1B8E1AFC98F511353E18FDB4617238D5F4D02B21C6CEE83633F2ED144BA951EDB2785864B; expires=Sun, 05-May-2019 19:59:59 GMT; path=/
                        */
                        var matches = cookie.match(/(.ASPXAUTH=)(\w+);/i);
                        if (matches && matches.length >= 3 && matches[2] && matches[2].length > 0) {
                            authCode = matches[2];
                        }
                    }
                }
                if (authCode) {
                    return authCode;
                } else {
                    throw Error('SmartHub did not return authcode');
                }
            } else throw smartHubResponse.data.error;
        } catch (error) {
            throw createError(error);
        }
    };

    getPofiles = async authCode => {
        const restApi = new RestApi({ controller: 'Profiles', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'GetMimsProfiles',
                body: { authCode },
            });
            if (smartHubResponse.data.success) {
                const profiles = smartHubResponse.data.result;
                return profiles;
            }
        } catch (error) {
            throw error;
        }
    };

    getCompanyProfile = async licenseNo => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'GetCompanyProfile',
                body: { tradeLicenseNumber: licenseNo },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getPersonProfile = async emiratesId => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'GetPersonProfile',
                body: { NationalNumber: emiratesId },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getInspection = async inspectionRef => {
        return mockApi.getInspection(inspectionRef);

        // const restApi = new RestApi({ controller: 'Inspection' });
        // try {
        //     let response = await restApi.post({
        //         url: 'getInspection',
        //         body: { ref: inspectionRef },
        //         cancelable: true,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };

    search = async (searchKey, filter) => {
        return mockApi.search(searchKey, filter);

        // const restApi = new RestApi({ controller: 'Search' });
        // try {
        //     let response = await restApi.post({
        //         url: 'search',
        //         body: { searchKey, filter },
        //         cancelable: true,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };

    getLocation = async filter => {
        //https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query?where=MUNICIPALITYNAME='ADM'&outFields=NAMEENGLISH&returnGeometry=false&f=json
        //https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query?where=NAMEENGLISH='AL BATEEN'&outFields=*&returnGeometry=false&f=json
        //?where=NAMEENGLISH='AL BATEEN'&outFields=*&returnGeometry=false&f=json

        const url = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query';
        let params = {
            outFields: '*',
            returnGeometry: false,
            f: 'json',
        };

        if (filter) {
            params = { ...params, ...filter };
        }

        try {
            const response = await axios.get(url, { params });
            return response.data;
        } catch (error) {
            console.log('getLocation API error', error);
            throw error;
        }
    };

    deleteUploadedDocument = async token => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: `Delete?token=${token}`,
                cancelable: false,
                showAlerts: false,
            });
            return response.data;
        } catch (error) {
            throw error;
        }
    };

    // Get printer template
    getPrintTemplate = async licenseNo => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'getPrintTemplate',
                body: {},
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    smartPassLogout = async (id_token, access_token) => {
        let endSessionUrl, endSessionConfig, revokeTokensUrl, revokeTokensConfig;
        try {
            endSessionUrl = `${smartPassUrl}/secure/oauth2/connect/endSession?id_token_hint=${id_token}`;
            //Todo: extract this logic into a helper
            endSessionConfig = this.addSSL({
                method: 'get',
                headers: {
                    Authorization: `Bearer ${access_token}`,
                },
            });
        } catch (error) {
            console.log('error endSession ', { error });
            throw error;
        }
        const endSessionResponse = await pinch.fetch(endSessionUrl, endSessionConfig);
        // console.log('endSession Response  ' + JSON.stringify(endSessionResponse));

        try {
            // console.log('1');
            revokeTokensUrl = `${smartPassUrl}/secure/frrest/oauth2/token/${access_token}?_action=revokeTokens`;
            //Todo: extract this logic into a helper
            console.log('2' + revokeTokensUrl);
            revokeTokensConfig = this.addSSL({
                method: 'post',
                body: '{ "client_id": "adm" }',
                headers: {
                    'Accept-API-Version': 'protocol=1.0,resource=1.0',
                    'Content-Type': 'application/json',
                },
            });
            // console.log('3 ' + JSON.stringify(revokeTokensConfig));
        } catch (error) {
            console.log('error revokeTokens ', { error });
            throw error;
        }
        //console.log('4 ' + JSON.stringify(revokeTokensConfig));
        const revokeTokensResponse = await pinch.fetch(revokeTokensUrl, revokeTokensConfig);
        //console.log('revokeTokensResponse  ' + JSON.stringify(revokeTokensResponse));
    };

    checkDuplicate = async duplicateCheckRequestModel => {
        const restApi = new RestApi({ controller: 'DummyMims' });
        try {
            const response = await restApi.post({
                url: 'CheckDuplicate',
                body: { value: duplicateCheckRequestModel },
                cancelable: true,
                showAlerts: false,
            });
            if (duplicateCheckRequestModel.selectedWorkflowConst == 'MimsDistortion') return duplicateMock;
            else if (duplicateCheckRequestModel.selectedWorkflowConst != 'MimsDistortion') return checkListDuplicateMock;
            else return duplicateMock;

            //    return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    loadMasterdata = async lastUpdated => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'LoadMasterData',
                body: { lastUpdated: lastUpdated },
                cancelable: false,
                showAlerts: true,
            });
            //Todo: remove violationTypes below when LoadMasterdata API returns correct structure and data of violationTypes
            const mergedMasterdata = { ...response.data.result, violationTypes: violationTypes };
            return mergedMasterdata;
        } catch (error) {
            throw error;
        }
    };

    // createInspectionRecord = async createInspectionModel => {
    //     //console.log('createInspectionRecord() createInspectionModel: ', createInspectionModel);
    //     const restApi = new RestApi({ controller: 'Inspection' });
    //     try {
    //         const response = await restApi.post({
    //             url: 'CreateInspectionRecord',
    //             body: createInspectionModel,
    //             cancelable: false,
    //             showAlerts: false,
    //         });
    //         return response.data.result;
    //     } catch (error) {
    //         throw error;
    //     }
    // };

    createInspection = async params => {
        let currentVisitIndex = params && params.visits && params.visits.length - 1;
        // if (this.props.visitindex != undefined) currentVisitIndex = this.props.visitindex;
        const currentVisitData = currentVisitIndex != undefined ? params.visits[currentVisitIndex] : undefined;
        const distortionForm = currentVisitData && currentVisitData.distortionForm;

        if (distortionForm) {
            // const inspectionParams = {
            //     inspectionId: params.inspectionId,
            //     info: params.info,
            //     visits: [params.visits[0]],
            // };

            const restApi = new RestApi({ controller: 'Inspection' });
            try {
                const response = await restApi.post({
                    url: 'StartAndConfirmInspection',
                    body: params,
                    cancelable: false,
                    showAlerts: false,
                });
                return response.data.result;
            } catch (error) {
                throw error;
            }
        }
        return mockApi.createInspection(params);
    };

    getTaskDetails = taskid => mockApi.getTaskDetails(taskid);
    trackingLocationUpdate = async data => {
        return { TrackingLocationUpdate: 'dummy success', ...data };
        // const restApi = new RestApi({ controller: 'DummyMims' });
        // try {
        //     let response = await restApi.post({
        //         url: 'TrackingLocationUpdate',
        //         body: data,
        //         cancelable: false,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };
    /* mock api calls */
    getInitialTasks = userData => mockApi.getInitialTasks(userData);
    adminLogin = (username, password, success = true) => mockApi.adminLogin(username, password, success);
    //  checkDuplicate = (duplicateCheckRequestModel, success = true) => mockApi.checkDuplicate(duplicateCheckRequestModel, success);
    //   loadMasterdata = lastUpdated => mockApi.loadMasterdata(lastUpdated);
    createInspectionRecord = createInspectionModel => mockApi.createInspectionRecord(createInspectionModel);
    createInspection = params => mockApi.createInspection(params);
    getDashboardCharts = (chartId, PrevchartData) => mockApi.getDashboardCharts(chartId, PrevchartData);
    createFollowup = params => mockApi.createFollowup(params);
    getBuildingDetails = params => mockApi.getBuildingDetails(params);
    getInspectorPlanStatus = async inspectorDomainCustomerId => {
        console.log('aaainspectorDomainCustomerId  ' + inspectorDomainCustomerId);
        return mockApi.getInspectorPlanStatus(inspectorDomainCustomerId);
    };

    getInspectionsPlotsData = async plotIDS => {
        return mockApi.getInspectionsPlotsData(plotIDS);
    };
    getBuildingDetails = params => mockApi.getBuildingDetails(params);
    //   getAddress = coords => mockApi.getAddress(coords);
}

delayedResult = (success, data, latency) => {
    console.log(`delaying results for ${latency} milliseconds`);
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (success) resolve(data);
            else reject(data);
        }, latency || this.latency);
    });
};
