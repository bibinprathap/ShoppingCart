import axios from 'axios';
import envConfig from './config';
import alertsHelper from 'app/api/helperServices/alerts';
import createError from 'app/api/helperServices/errors';
import { _state } from 'app/config/store';

export default class RestApi {
    static cancelTokens = {};
    constructor({ controller, dispatch = null, secure = true, endpoint = 'smarthub' }) {
        //if (!dispatch || dispatch == null) throw Error(`Dispatch cannot be null. controller: ${controller}`);

        //const env = 'test';
        //const env = 'development';
        const env = _state.settings.environment || 'development';

        this.header = {
            'Content-Type': 'application/json',
            Accept: '*/*',
        };
        this.controller = controller || '';
        this.dispatch = dispatch;
        this.secure = secure;
        this.envConfig = envConfig[env];
        this.endpoint = endpoint;
        //console.log('restApi.constructor._state: ', _state);
    }

    get = ({ url, parameters, body, headers, isFormData, showAlerts, cancelable }) => {
        return this.restApi('GET', url, parameters, body, headers, isFormData, showAlerts, cancelable);
    };

    post = ({ url, parameters, body, headers, isFormData, showAlerts, cancelable }) => {
        return this.restApi('POST', url, parameters, body, headers, isFormData, showAlerts, cancelable);
    };

    restApi = (method = 'GET', url = '', parameters = {}, body = {}, headers = {}, isFormData = false, showAlerts = true, cancelable = false) => {
        if (!url) url = '';
        if (!parameters) parameters = {};
        if (!headers) headers = {};
        //let requestUrl = this.gis === true ? url : this.parseUrl(url, parameters);
        let requestUrl = this.parseUrl(url, parameters);

        // if (isFormData) {
        //     //set correct Content-Type in the headers
        // }

        //console.log(`Sending ${method} request to ${requestUrl}`);

        const defaultHeaders = {
            'Content-Type': 'application/json',
            //'Access-Control-Allow-Origin': '*',
        };
        const requestConfig = {
            url: requestUrl,
            method: method,
            headers: { ...defaultHeaders, ...headers },
            data: typeof body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
            //body: JSON.stringify(body),
            timeout: this.envConfig.timeout || 0, //doesn't always work. need to fix this
            withCredentials: true,
            //todo: add token if it is secure call
        };

        if (cancelable) {
            const previousToken = RestApi.cancelTokens[requestUrl]; //one request per url
            if (previousToken) {
                previousToken.cancel(`Request canceled [${requestUrl}]. One request allowed per url.`);
            }
            const newTokenSource = axios.CancelToken.source();
            RestApi.cancelTokens[requestUrl] = newTokenSource;
            requestConfig.cancelToken = newTokenSource.token;
        }
        return this.sendRequest(requestConfig, showAlerts);
        //return this.fetchRequest(requestConfig, showAlerts);
    };

    fetchRequest = (requestConfig, showAlerts) => {
        //Todo:  dispatch --> this.dispatch(ajax-call-counter-increment-action)
        //console.log('restApi fetch request: ', requestConfig);
        return (
            fetch(requestConfig.url, requestConfig)
                //.request(requestConfig)
                .then(response => this.parseFetchResponse(response, requestConfig))
                .catch(error => {
                    //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)

                    console.log('restApi fetch error: ', { error });
                    //delete cancelTokens[requestConfig.url];

                    let errorToThrow = createError(error);
                    errorToThrow.isCancel = axios.isCancel(error);

                    if (showAlerts && errorToThrow) {
                        alertsHelper.show('error', errorToThrow.message, errorToThrow.detail);
                        errorToThrow.handled = true;
                    }
                    throw errorToThrow;
                })
        );
    };

    parseFetchResponse = (response, requestConfig) =>
        response.text().then(text => {
            let data;
            try {
                data = JSON.parse(text);
            } catch (err) {
                data = text;
            }

            // console.log('restApi fetch success: ', response, 'data: ', data);
            delete RestApi.cancelTokens[requestConfig.url];
            //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
            //return response;

            return {
                statusText: response.statusText,
                status: response.status,
                ok: response.ok,
                body: data,
            };
        });

    sendRequest = (requestConfig, showAlerts) => {
        //Todo:  dispatch --> this.dispatch(ajax-call-counter-increment-action)
        console.log('restApi axios request: ', requestConfig);
        axios.defaults.withCredentials = true;
        return axios
            .request(requestConfig)
            .then(response => {
                console.log('restApi axios success: ', response);
                delete RestApi.cancelTokens[requestConfig.url];
                //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
                return response;
            })
            .catch(error => {
                //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)

                console.log('restApi axios error: ', { error });
                //delete cancelTokens[requestConfig.url];

                let errorToThrow = createError(error);
                errorToThrow.isCancel = axios.isCancel(error);

                if (showAlerts && errorToThrow) {
                    alertsHelper.show('error', errorToThrow.message, errorToThrow.detail);
                    errorToThrow.handled = true;
                }
                console.log('sendRequest throwing error: ', errorToThrow);
                throw errorToThrow;
            });
    };

    parseUrl = (url = '', parameters) => {
        const regex = /:(\w+)\/?/g;

        let m;

        while ((m = regex.exec(url)) !== null) {
            // This is necessary to avoid infinite loops with zero-width matches
            if (m.index === regex.lastIndex) {
                regex.lastIndex++;
            }

            // The result can be accessed through the `m`-variable.
            m.forEach(match => {
                if (parameters[match]) {
                    url = url.replace(`:${match}`, parameters[match]);
                    delete parameters[match];
                }
            });
        }

        let prefix = url.lastIndexOf('?') > 0 ? '&' : '?';

        for (let propName in parameters) {
            url = url.concat(`${prefix}${propName}=${parameters[propName]}`);
            if (prefix === '?') {
                prefix = '&';
            }
        }
        let parsedUrl = '';
        if (this.endpoint == 'smarthub') {
            if (url.startsWith('//')) {
                parsedUrl = `${this.envConfig.baseURL}/${url.slice(2)}`;
            } else {
                if (url.startsWith('/')) {
                    url = url.slice(1);
                }
                if (url.startsWith('?')) {
                    parsedUrl = `${this.envConfig.baseURL}/${this.controller}${url}`;
                } else {
                    parsedUrl = `${this.envConfig.baseURL}/${this.controller}/${url}`;
                }
            }
        } else if (this.endpoint == 'mapServer') {
            parsedUrl = `${this.envConfig.mapServer}/${url}`;
        }
        //console.log('parsedUrl: ', parsedUrl);
        return parsedUrl;
    };
}
export { envConfig };
