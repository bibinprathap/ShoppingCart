import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import styles from './styles';
//const abc = require('app/images/personpoint.png');

import ArcGISMapView from 'rnarcgis';

class ADMGISMapView extends Component {
    constructor(props) {
        super(props);
        // this.mapRendered = false;
        // this.state = {
        //     lastX: 0.0,
        //     lastY: 0.0,
        //     isOverlayVisible: true,
        //     updatesActive: false,
        //     graphicId: 'none',
        // };
    }
    //mapRendered;

    static propTypes = {
        onCoordinateschanged: PropTypes.func,
        onAddressChanged: PropTypes.func,
        location: PropTypes.object,
    };

    state = {
        focusedLocation: {
            latitude: 24.486775,
            longitude: 54.378501,
        },

        container: {
            flex: 1,
            paddingTop: 1,
        },
    };

    render() {
        const { location } = this.props;
        const polygonData = {
            polygons: [
                {
                    PolygonID: 'ADM',
                    polygonFillColor: 0x00ffffff,
                    boundaryLineColor: 0xff000000,
                    lineWidth: 2.0,
                    coords: [
                        { latitude: 24.488979, longitude: 54.378012 },
                        { latitude: 24.488248, longitude: 54.377282 },
                        { latitude: 24.487717, longitude: 54.377161 },
                        { latitude: 24.487219, longitude: 54.378623 },
                        { latitude: 24.488391, longitude: 54.378241 },
                    ],
                },

                {
                    PolygonID: 'Salam',
                    polygonFillColor: 0x00ffffff,
                    boundaryLineColor: 0xff000000,
                    lineWidth: 2.0,
                    coords: [
                        { latitude: 24.488983, longitude: 54.380678 },
                        { latitude: 24.488734, longitude: 54.380908 },
                        { latitude: 24.488703, longitude: 54.38129 },
                        { latitude: 24.489212, longitude: 54.38132 },
                    ],
                },
            ],
        };

        const stringifedJSON = JSON.stringify(polygonData);

        // console.log('this.props', this.props);
        const coords = location && location.latitude && location.longitude && { latitude: location.latitude, longitude: location.longitude };
        console.log('cords from GISMAPView', coords);

        if (!coords) return null;
        return (
            <View style={styles.container}>
                <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ width: '100%', height: '100%' }}
                    initialMapCenter={[coords]}
                    currentMarkerCoords={coords}
                    recenterIfGraphicTapped={true}
                    pointGraphics={this.pointGraphics}
                    basemapUrl="https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer"
                    drawPolygons={stringifedJSON}
                    onSingleTap={this.onSingleTap}
                />
            </View>
        );
    }

    getRandom = () => Math.floor(Math.random() * 100 + 1);
    getZoneSectorPlot = coords => {
        //Todo: call the webservice here without blocking UI
        //dummy response from the arcGis service, with simulated 2 seconds delay,
        setTimeout(() => {
            if (!!this.props.onAddressChanged) {
                this.props.onAddressChanged({
                    zone: this.getRandom(),
                    sector: this.getRandom(),
                    plot: this.getRandom(),
                });
            }
        }, 2000);
    };

    pointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    ];

    onSingleTap = event => {
        if (!!!this.props.editable) return;
        points = event.nativeEvent;
        //  console.log('onSingleTap' + JSON.stringify(points));

        overlayData = {
            pointGraphics: this.pointGraphics,
            referenceId: 'graphicsOverlay',
            points: [
                {
                    latitude: points.mapPoint.latitude,
                    longitude: points.mapPoint.longitude,
                    rotation: 0,
                    referenceId: 'Abu Dhabi',
                    graphicId: 'normalPoint',
                },
            ],
        };

        if (!points.mapPoint) {
            return;
        }

        if (this.mapView) {
            // console.log('step 0 ');
            this.mapView.removeGraphicsOverlay('graphicsOverlay');
            this.mapView.addGraphicsOverlay(overlayData);
        }

        //  console.log('step 1 ');
        if (points.mapPoint.latitude && points.mapPoint.longitude) {
            // this.setState({ lastX: points.mapPoint.latitude.toFixed(4), lastY: points.mapPoint.longitude.toFixed(4) });
            const coords = { latitude: points.mapPoint.latitude, longitude: points.mapPoint.longitude };
            this.getZoneSectorPlot(coords);
            //console.log('step 2 ');
            this.setState(
                {
                    focusedLocation: {
                        latitude: points.mapPoint.latitude,
                        longitude: points.mapPoint.longitude,
                    },
                },
                () => {
                    // console.log('step 3 ');
                    if (!!this.props.onCoordinateschanged) {
                        //  console.log('step 4 ');
                        this.props.onCoordinateschanged(coords);
                    }
                }
            );
        }
    };
}

export default ADMGISMapView;
