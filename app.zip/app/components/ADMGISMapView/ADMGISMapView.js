import React, { memo, Component, useState } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import styles from './styles';
import Menu from './Menu';
import Caption from './Caption';
import CallOut from './CallOut';
import InspectorCurrentLocation from './InspectorCurrentLocation';
import InspectionLocation from './InspectionLocation';
import { getFeatureServerUrl, getFeatureLayersIndex } from 'app/api/helperServices/utils';
import { getLocation } from 'app/api/helperServices/geolocation';
import ArcGISMapView from '../../../ThirdPartyModuleJS/AGSMapView';
import { setPreference } from 'app/actions/generic';

const defaultBaseMap = 'STREETS';

class ADMGISMapView extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showCallOut: false,
            basemap: props.basemap || defaultBaseMap,
            layers: this.createLayersUrls(props.layers),
            callOutData: '',
            layout: { width: 0, height: 0 },
        };
    }
    componentDidMount() {
        if (!this.props.preference.mapInitialized) {
            setTimeout(() => {
                if (!this.props.preference.mapInitialized) this.props.dispatch(setPreference({ mapInitialized: true }));
            }, 8000);
        }
    }

    setshowCallOut = val => {
        this.setState({ showCallOut: val });
    };

    setcallOutData = data => {
        this.setState({ callOutData: data });
    };

    setlayout = layout => {
        this.setState({ layout: layout });
    };

    setBasemap = basemap => {
        this.setState({ basemap: basemap });
    };

    setLayers = layers => {
        this.setState({ layers: layers });
    };

    defaultPointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
        { graphicId: 'inspectorPoint', graphic: Image.resolveAssetSource(require('app/images/inspPin.png')) },
    ];

    getInspectorCurrentLocation = async () => {
        const currentLocation = await getLocation();

        currentLocation.graphicId = 'inspectorPoint';
        currentLocation.referenceId = 'referenceId';

        const inspectorCurrentLocationData = currentLocation && {
            pointGraphics: this.defaultPointGraphics,
            referenceId: 'InspectorCurrentLocation',
            points: [currentLocation],
        };

        if (this.mapView) {
            this.mapView.setInspectorLocation(inspectorCurrentLocationData);
        }
    };
    getInspectionLocation = () => {
        const props = this.props;
        if (this.mapView) {
            this.mapView.recenterMap([props.coords]);
        }
    };

    onSingleTap = event => {
        const props = this.props;
        const wasVisible = this.menu && this.menu.hideMenu();
        if (wasVisible) return;

        points = event.nativeEvent;
        if (!points.mapPoint) {
            return;
        }

        if (typeof points.data !== 'undefined' && points.data != null) {
            this.setshowCallOut(true);
            this.setcallOutData(points);
        } else if (typeof points.appNumber !== 'undefined' && points.appNumber != null) {
            this.setshowCallOut(true);
            this.setcallOutData(points);
        } else {
            this.setshowCallOut(false);
        }

        props.onSingleTap && props.onSingleTap(points);
    };

    createLayersUrls = layers => {
        if (!layers) return;
        const featureServerUrl = getFeatureServerUrl();
        const layersIndex = getFeatureLayersIndex();
        return layers.map(l => `${featureServerUrl}/${layersIndex[l]}`);
    };

    handleSelectlayers = layers => {
        const layersWithUrl = this.createLayersUrls(layers);

        this.setLayers(layersWithUrl);
    };

    handleBaseMap = basemap => {
        this.setBasemap(basemap);
    };
    handleLayout = event => {
        var { x, y, width, height } = event.nativeEvent.layout;

        this.setlayout({ width: width, height: height });
    };
    render() {
        const props = this.props;
        const {
            polygonsData,
            renderData,
            coords,
            placeMarks,
            markersReferenceId,
            showMenu,
            caption,
            // showInspectorCurrentLocation,
            showInspectionLocation,
            routeData,
        } = props;
        const pointGraphics = props.pointGraphics || this.defaultPointGraphics;
        const markersData = placeMarks && {
            pointGraphics: pointGraphics,
            referenceId: markersReferenceId || 'defaultId',
            points: [...placeMarks],
        };

        const { layers, basemap, layout, showCallOut, callOutData } = this.state;

        return (
            <View
                style={[styles.container, props.preference.mapInitialized ? { marginBottom: 0 } : { marginBottom: 1 }]}
                onLayout={event => {
                    this.handleLayout(event);
                }}
            >
                <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ width: '100%', height: '100%' }}
                    initialMapCenter={[coords]}
                    recenterIfGraphicTapped={true}
                    pointGraphics={props.pointGraphics}
                    layersData={layers}
                    baseMapType={basemap}
                    markersData={markersData}
                    polygonsData={polygonsData}
                    renderData={renderData}
                    routeData={routeData}
                    onSingleTap={this.onSingleTap}
                />
                {/* {showInspectorCurrentLocation ? <InspectorCurrentLocation onGetCurrentLocation={this.getInspectorCurrentLocation} /> : null} */}
                <InspectorCurrentLocation onGetCurrentLocation={this.getInspectorCurrentLocation} />
                {showInspectionLocation ? <InspectionLocation onGetInspectionLocation={this.getInspectionLocation} /> : null}
                {showMenu && (
                    <Menu
                        selectedLayers={this.props.layers}
                        selectedBasemap={basemap}
                        onLayersChange={this.handleSelectlayers}
                        onBaseMapChange={this.handleBaseMap}
                        ref={menu => {
                            this.menu = menu;
                        }}
                    />
                )}
                {caption && <Caption menu={showMenu} label={caption} />}
                {showCallOut ? <CallOut data={callOutData} layoutData={layout} /> : null}
            </View>
        );
    }
}

const mapStateToProps = state => {
    return {
        preference: state.generic.preference,
    };
};

export default connect(mapStateToProps)(ADMGISMapView);
