import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import styles from './styles';
//const abc = require('app/images/personpoint.png');

import ArcGISMapView from 'rnarcgis';

class ADMGISMapView extends Component {
    defaultPointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    ];

    render() {
        const { coords, placeMarks, markersReferenceId } = this.props;
        const pointGraphics = this.props.pointGraphics || this.defaultPointGraphics;
        const markersData = placeMarks && {
            pointGraphics: pointGraphics,
            referenceId: markersReferenceId || 'defaultId',
            points: [...placeMarks],
        };
        console.log('markers Data Latest', markersData);

        console.log('cords from GISMAPView', coords);

        return (
            <View style={styles.container}>
                <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ width: '100%', height: '100%' }}
                    initialMapCenter={coords && [coords]}
                    // currentMarkerCoords={coords && coords}
                    recenterIfGraphicTapped={true}
                    pointGraphics={this.props.pointGraphics}
                    basemapUrl="https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer"
                    markersData={markersData && markersData}
                    onSingleTap={this.onSingleTap}
                />
            </View>
        );
    }

    onSingleTap = event => {
        console.log('ADMGISMapView.onSingleTap() event: ', event);
        points = event.nativeEvent;

        if (!points.mapPoint) {
            return;
        }

        this.props.onSingleTap && this.props.onSingleTap(points);
    };
}

export default ADMGISMapView;
