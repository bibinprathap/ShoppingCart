import React, { Component, useState } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import styles from './styles';
import Menu from './Menu';
import { getFeatureServerUrl } from 'app/api/helperServices/utils';
//const abc = require('app/images/personpoint.png');

import ArcGISMapView from '../../../ThirdPartyModuleJS/AGSMapView';
const layersIndex = {
    zones: 2,
    sectors: 1,
    plots: 0,
};

const defaultBaseMap = 'STREETS';

export default function(props) {
    const featureServerUrl = getFeatureServerUrl();
    defaultPointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    ];

    onSingleTap = event => {
        const wasVisible = this.menu && this.menu.hideMenu();
        if (wasVisible) return;

        points = event.nativeEvent;
        if (!points.mapPoint) {
            return;
        }
        // this.setState({ lastPoint: JSON.stringify(points.mapPoint) });
        console.log('mappoints ', points.mapPoint);

        props.onSingleTap && props.onSingleTap(points);
    };

    createLayersUrls = layers => {
        if (!layers) return;
        return (layersWithUrl = layers.map(l => {
            console.log('creating layer url for ', l);
            return (formattedUrl = `${featureServerUrl}/${layersIndex[l]}`);
        }));
    };

    handleSelectlayers = layers => {
        const layersWithUrl = createLayersUrls(layers);
        setLayers(layersWithUrl);
    };

    handleBaseMap = basemap => {
        //console.log('baseMap', baseMapType);
        setBasemap(basemap);
        //this.setState({ baseMapType: baseMapType });
    };

    const { coords, placeMarks, markersReferenceId, layers, basemap, showMenu } = props;
    const pointGraphics = props.pointGraphics || this.defaultPointGraphics;
    const markersData = placeMarks && {
        pointGraphics: pointGraphics,
        referenceId: markersReferenceId || 'defaultId',
        points: [...placeMarks],
    };
    const [_basemap, setBasemap] = useState(basemap || defaultBaseMap);
    const [_layers, setLayers] = useState(createLayersUrls(layers));

    console.log('markers Data Latest', markersData);
    // const coords1 = coords && coords.latitude && coords.longitude && { latitude: location.latitude, longitude: location.longitude };
    console.log('cords from GISMAPView', coords);
    console.log('_basemap', _basemap);

    return (
        <View style={styles.container}>
            <ArcGISMapView
                ref={mapView => (this.mapView = mapView)}
                style={{ width: '100%', height: '100%' }}
                initialMapCenter={[coords]}
                recenterIfGraphicTapped={true}
                pointGraphics={props.pointGraphics}
                //basemapUrl="https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer"
                //basemapUrl=""
                layersData={_layers}
                baseMapType={_basemap}
                markersData={markersData}
                onSingleTap={this.onSingleTap}
            />
            {showMenu && (
                <Menu
                    selectedLayers={layers}
                    selectedBasemap={_basemap}
                    onLayersChange={this.handleSelectlayers}
                    onBaseMapChange={this.handleBaseMap}
                    ref={menu => {
                        this.menu = menu;
                    }}
                />
            )}
        </View>
    );
}
