import React, { Component } from 'react';
import { View, PixelRatio } from 'react-native';
import styles from './styles';
import { Text } from 'react-native-paper';
import { StatusChip } from 'app/components';
export default class CallOut extends Component {
    state = { width: 0, height: 0 };
    handleLayout = event => {
        var { width, height } = event.nativeEvent.layout;

        this.setState({ width: width, height: height });
    };

    render() {
        const { layoutData, data } = this.props;

        const callOutWidth = this.state.width;
        const callOutHeight = this.state.height;
        const pixelRatio = PixelRatio.get();
        let left = data.screenPoint.x / pixelRatio;
        let top = data.screenPoint.y / pixelRatio;


        left = layoutData.width - left > callOutWidth ? left : layoutData.width - callOutWidth - 10;
        top = layoutData.height - top > callOutHeight ? top : layoutData.height - callOutHeight - 30;
        // const left = PixelRatio.roundToNearestPixel(data.screenPoint.x) / pixelRatio;
        //const top = PixelRatio.roundToNearestPixel(data.screenPoint.y) / pixelRatio;

        //Object.
        let Heading = data.appNumber ? data.title + ' -' + data.appNumber : null;
        let Details = data.serviceDesc ? data.serviceDesc : null;
        let polyData = data.data ? data.data : null;
        let Status = data.inspectionStatus ? data.inspectionStatus : null;
        let TaskId = data.taskId ? 'Task ID - ' + data.taskId : null;

        return (
            <View
                style={[styles.callOutContainer, { left, top }]}
                onLayout={event => {
                    this.handleLayout(event);
                }}
            >
                {Heading && <Text style={styles.itemMediumText}>{Heading}</Text>}
                {TaskId && <Text style={styles.itemSmallText}>{TaskId}</Text>}
                {Details && <Text style={styles.itemSmallText}>{Details}</Text>}
                {Status && <StatusChip statusCode={Status} translatedStatus={Status} />}
                {polyData && <Text style={styles.itemSmallText}>{polyData}</Text>}
            </View>
        );
    }
}
