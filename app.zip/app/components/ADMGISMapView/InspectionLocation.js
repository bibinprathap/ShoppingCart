import React, { Component } from 'react';
import { View, TouchableOpacity, Image } from 'react-native';
import styles from './styles';
import { Icon } from 'app/components';
export default class InspectionLocation extends Component {
    handleInspectionLocationPress = () => {
        const { onGetInspectionLocation } = this.props;
        onGetInspectionLocation && onGetInspectionLocation();
    };

    render() {
        return (
            <View style={styles.inspectionLocationContainer}>
                <TouchableOpacity onPress={this.handleInspectionLocationPress}>
                    <Icon type="MaterialCommunityIcons" name="map-marker-radius" style={styles.layerIcon} size={28} />
                </TouchableOpacity>
            </View>
        );
    }
}
