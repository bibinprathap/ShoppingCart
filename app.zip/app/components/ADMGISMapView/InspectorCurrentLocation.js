import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import styles from './styles';
import { Icon } from 'app/components';
export default class InspectorCurrentLocation extends Component {
    handleCurrentLocationPress = () => {
        const { onGetCurrentLocation } = this.props;
        onGetCurrentLocation && onGetCurrentLocation();
    };

    render() {
        return (
            <View style={styles.currentLocationContainer}>
                <TouchableOpacity onPress={this.handleCurrentLocationPress}>
                    <Icon type="MaterialCommunityIcons" name="map-marker-circle" style={styles.layerIcon} size={28} />
                </TouchableOpacity>
            </View>
        );
    }
}
