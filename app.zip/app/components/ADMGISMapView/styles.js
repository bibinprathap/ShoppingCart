import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    map: {
        flex: 1,
        height: 500,
    },
    menuIconContainer: {
        position: 'absolute',
        top: 0,
        right: 0,
        margin: 20,
        //padding: 10,
        width: 40,
        height: 40,
        elevation: 12,
        backgroundColor: '$primaryDividerLightColor',
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
    },
    containerTop: {
        position: 'absolute',
        top: 7,
        right: 5,
        elevation: 12,
        backgroundColor: '$primaryDividerLightColor',
        borderRadius: 8,
        justifyContent: 'flex-start',
        alignItems: 'flex-end',
        opacity: 0.8,
    },
    layerIcon: {
        color: '$primarySelectedTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
        textAlign: 'left',
        //fontWeight: 'bold',
        margin: 5,
    },
    imageStyle: { width: 60, height: 60, margin: 5, borderRadius: 10, borderWidth: 1, borderColor: '$primaryWhite' },
    imageStyleSelected: { borderColor: '$primaryHeaderColor' },
    imageText: { fontSize: '$primaryTextXSM', textAlign: 'center', fontWeight: 'bold', color: '$primaryDarkTextColor' },
    imageTextSelected: { color: '$primaryHeaderColor' },
    layerView: { flexDirection: 'row', justifyContent: 'space-around', margin: 10 },
    layerTouch: { borderWidth: 1, borderRadius: 10, borderColor: '$primaryWhite' },
    layerTouchSelected: { borderColor: '$primaryHeaderColor' },
    layerText: { fontSize: 14, textAlign: 'center', margin: 5 },
});
