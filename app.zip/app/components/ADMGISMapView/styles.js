import { Dimensions } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

const height = Dimensions.get('window').height - 200;

export default EStyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    map: {
        flex: 1,
        height: 500,
    },
});
