import React, { Component } from 'react';
import { View, Picker } from 'react-native';
import { Button, IconButton } from 'react-native-paper';
import styles from './styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Selector, Icon } from 'app/components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { _ } from 'lodash';
import { search, setAddress } from 'app/actions/search';

import AppApi from 'app/api/real';
const api = new AppApi();

import { I18nManager } from 'react-native';

class AddressPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectorType: null,
            selectedZone: null,
            selectedSector: null,
            selectedPlot: null,
            dataSource: [],
            dataSourceTemp: [],
            isLoading: false,
            searchFieldName: null,
            municipalityId: '1000',
        };
    }

    selectAddressBtnPress = selectorType => {
        this.setState({ selectorType, isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleLocationSearch = async searchKey => {
        try {
            let result = null;
            let orderBy = null;
            const { selectedZone, selectedSector, selectorType, municipalityId } = this.state;
            const isRTL = I18nManager.isRTL;
            switch (selectorType) {
                case 'zone':
                    orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';

                    result = await api.getZones({
                        municipalityId,
                        options: { orderByFields: orderBy, outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'zoneNameA' : 'zoneNameE',
                    });

                case 'sector':
                    if (!selectedZone) return null;
                    orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';

                    result = await api.getSectors({
                        municipalityId,
                        zoneIds: [selectedZone.zoneId],
                    });
                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'sectorNameA' : 'sectorNameE',
                    });
                case 'plot':
                    if (!selectedZone || !selectedSector) return null;

                    result = await api.getPlots({
                        municipalityId,
                        sectorIds: [selectedSector.sectorId],
                        zoneIds: [selectedZone.zoneId],
                        orderByFields: 'plotNumber',
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: 'plotNumber',
                    });

                default:
                    break;
            }
            this.setState({ isLoading: false });
        } catch (e) {
            this.setState({ isLoading: false });
        }
    };

    onLocationSelect = item => {
        switch (this.state.selectorType) {
            case 'zone':
                this.setState({
                    selectedZone: item || null,
                    selectorType: null,
                    selectedSector: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'sector':
                this.setState({
                    selectedSector: item || null,
                    selectorType: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'plot':
                this.setState(
                    {
                        selectedPlot: item || null,
                        selectorType: null,
                        searchFieldName: null,
                        dataSource: [],
                        dataSourceTemp: [],
                        isLoading: false,
                    },
                    () => {
                        if (item && this.state.selectedZone && this.state.selectedSector) {
                            this.handleSearch();
                        }
                    }
                );

                break;
            default:
                this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false });
                break;
        }
    };

    handleSearch = () => {
        this.props.actions.search(null, {
            ...this.props.search.filter,
            zone: this.state.selectedZone,
            sector: this.state.selectedSector,
            plot: this.state.plot,
        });
        this.props.actions.setAddress({
            zone: this.state.selectedZone,
            sector: this.state.selectedSector,
            plot: this.state.plot,
        });
    };

    mapItem = item => {
        switch (this.state.selectorType) {
            case 'zone':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'zoneName') };
            case 'sector':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'sectorName') };
            case 'plot':
                return { ...item, id: item['objectId'], label: item['plotNumber'] };
            default:
                return null;
        }
    };

    searchKeyUpdate = searchKey => {
        if (this.state.dataSourceTemp && this.state.dataSourceTemp.length > 0) {
            const filterdDataSource = _.filter(this.state.dataSourceTemp, item => {
                let value = item[this.state.searchFieldName].toLowerCase();
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ dataSource: filterdDataSource });
        }
    };

    render() {
        return (
            <View style={styles.container}>
                {this.state.selectorType && (
                    <Selector
                        placeholder={strings('searchByName')}
                        isLoading={this.state.isLoading}
                        onSelect={this.onLocationSelect}
                        source={this.state.dataSource}
                        mapItem={this.mapItem}
                        searchKeyUpdate={this.searchKeyUpdate}
                        handleSearch={searchKey => this.handleLocationSearch(searchKey)}
                        onRequestClose={() => this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false })}
                        headerTitle={strings('select')}
                    />
                )}
                <View style={styles.buttonWrapper}>
                    <Picker
                        selectedValue={this.state.municipalityId}
                        style={{ height: 50, width: 96 }}
                        onValueChange={(municipalityId, itemIndex) => this.setState({ municipalityId })}
                    >
                        <Picker.Item label="ADM" value="1000" style={styles.pickerItem} />
                        <Picker.Item label="AAM" value="1001" style={styles.pickerItem} />
                        <Picker.Item label="WRM" value="1002" style={styles.pickerItem} />
                    </Picker>

                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('zone')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedZone, 'zoneName')) || strings('zone')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('sector')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedSector, 'sectorName')) || strings('sector')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('plot')}>
                        {(this.state.selectedPlot && this.state.selectedPlot.plotNumber) || strings('plot')}
                    </Button>
                    {/* <Button style={[styles.optionBtn, styles.locationButton]} onPress={null}>
                        <Icon type="MaterialCommunityIcons" name="map-marker" size={22} />
                    </Button> */}
                    <IconButton
                        icon="search"
                        size={20}
                        onPress={this.props.handleSearch.bind(this, {
                            ...this.props.search.filter,
                            zone: this.state.selectedZone,
                            sector: this.state.selectedSector,
                            plot: this.state.selectedPlot,
                        })}
                    />
                </View>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators(
            {
                search,
                setAddress,
            },
            dispatch
        ),
        dispatch,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddressPicker);
