import React, { Component } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity } from 'react-native';
import { IconButton, Button } from 'react-native-paper';
//import styles from './styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Selector } from 'app/components/Selector';
import IconEntypo from 'react-native-vector-icons/Entypo';
import { _ } from 'lodash';

import AppApi from 'app/api/real';
const api = new AppApi();

import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager, Dimensions } from 'react-native';
const screenWidth = Dimensions.get('window').width;
const searchIconMargin = screenWidth - 50;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
    },
    buttonWrapper: {
        flexDirection: 'row',
    },
    optionBtn: {
        backgroundColor: '$primaryMediumBackground',
        fontFamily: '$primaryFontNormal',
        marginRight: 5,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 3,
        minWidth: 80,
        maxWidth: 100,
    },
    itemWrapper: {
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginBottom: 2,
    },
    itemDetails: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
    },
    locationButton: {
        minWidth: 'auto',
        maxWidth: 'auto',
    },
    locationButtonIcon: {},
});

class AddressPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectorType: null,
            selectedZone: null,
            selectedSector: null,
            selectedPlot: null,
            dataSource: [],
            dataSourceTemp: [],
            isLoading: false,
            searchFieldName: null,
        };
    }

    selectAddressBtnPress = selectorType => {
        this.setState({ selectorType, isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleLocationSearch = async searchKey => {
        try {
            let result = null;
            let orderBy = null;
            const { selectedZone, selectedSector, selectorType } = this.state;
            const isRTL = I18nManager.isRTL;
            switch (selectorType) {
                case 'zone':
                    orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';

                    result = await api.getZones({
                        municipalityCode: 'ADM',
                        options: { orderByFields: orderBy, outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'zoneNameA' : 'zoneNameE',
                    });

                case 'sector':
                    if (!selectedZone) return null;
                    orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';

                    result = await api.getSectors({
                        municipalityCode: 'ADM',
                        zoneId: selectedZone.zoneId,
                        options: {
                            orderByFields: orderBy,
                            outFields: 'objectId,sectorId,sectorNameA,sectorNameE',
                        },
                    });
                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'sectorNameA' : 'sectorNameE',
                    });
                case 'plot':
                    if (!selectedZone || !selectedSector) return null;

                    result = await api.getPlots({
                        sectorId: selectedSector.sectorId,
                        orderByFields: 'plotNumber',
                        options: {
                            outFields: 'objectId,gisId,plotId,plotNumber',
                        },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: 'plotNumber',
                    });

                default:
                    break;
            }
            this.setState({ isLoading: false });
        } catch (e) {
            console.log('error', e);
            this.setState({ isLoading: false });
        }
    };

    onLocationSelect = item => {
        switch (this.state.selectorType) {
            case 'zone':
                this.setState({
                    selectedZone: item || null,
                    selectorType: null,
                    selectedSector: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'sector':
                this.setState({
                    selectedSector: item || null,
                    selectorType: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'plot':
                this.setState({
                    selectedPlot: item || null,
                    selectorType: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            default:
                this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false });
                break;
        }
    };

    renderItem = ({ item }) => {
        let filedName = null;
        switch (this.state.selectorType) {
            case 'zone':
                return (
                    <TouchableOpacity onPress={() => this.onLocationSelect(item)} KEY={item['objectId']} style={styles.itemWrapper}>
                        <Text style={styles.itemDetails}>{localeProperty(item, 'zoneName')}</Text>
                    </TouchableOpacity>
                );
            case 'sector':
                return (
                    <TouchableOpacity onPress={() => this.onLocationSelect(item)} KEY={item['objectId']} style={styles.itemWrapper}>
                        <Text style={styles.itemDetails}>{localeProperty(item, 'sectorName')}</Text>
                    </TouchableOpacity>
                );
            case 'plot':
                return (
                    <TouchableOpacity onPress={() => this.onLocationSelect(item)} KEY={item['objectId']} style={styles.itemWrapper}>
                        <Text style={styles.itemDetails}>{item['plotNumber']}</Text>
                    </TouchableOpacity>
                );

            default:
                return null;
        }
    };

    searchKeyUpdate = searchKey => {
        if (this.state.dataSourceTemp && this.state.dataSourceTemp.length > 0) {
            const filterdDataSource = _.filter(this.state.dataSourceTemp, item => {
                let value = item[this.state.searchFieldName].toLowerCase();
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ dataSource: filterdDataSource });
        }
    };

    render() {
        return (
            <View style={styles.container}>
                {this.state.selectorType && (
                    <Selector
                        placeholder={strings('searchByName')}
                        isLoading={this.state.isLoading}
                        renderItem={this.renderItem}
                        source={this.state.dataSource}
                        searchKeyUpdate={this.searchKeyUpdate}
                        handleLocationSearch={searchKey => this.handleLocationSearch(searchKey)}
                        onRequestClose={() => this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false })}
                        headerTitle={strings('select')}
                    />
                )}
                <View style={styles.buttonWrapper}>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('zone')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedZone, 'zoneName')) || strings('zone')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('sector')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedSector, 'sectorName')) || strings('sector')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('plot')}>
                        {(this.state.selectedPlot && this.state.selectedPlot.plotNumber) || strings('plot')}
                    </Button>
                    <Button style={[styles.optionBtn, styles.locationButton]} onPress={console.log}>
                        <IconEntypo name="location-pin" size={22} />
                    </Button>
                </View>
            </View>
        );
    }
}

export default AddressPicker;
