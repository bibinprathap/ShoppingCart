import React, { Component } from 'react';
import { View } from 'react-native';
import { Button, IconButton } from 'react-native-paper';
import styles from './styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Selector } from 'app/components/Selector';
import IconEntypo from 'react-native-vector-icons/Entypo';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { _ } from 'lodash';
import { search } from 'app/actions/search';

import AppApi from 'app/api/real';
const api = new AppApi();

import { I18nManager } from 'react-native';

class AddressPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectorType: null,
            selectedZone: null,
            selectedSector: null,
            selectedPlot: null,
            dataSource: [],
            dataSourceTemp: [],
            isLoading: false,
            searchFieldName: null,
        };
    }

    selectAddressBtnPress = selectorType => {
        this.setState({ selectorType, isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleLocationSearch = async searchKey => {
        try {
            let result = null;
            let orderBy = null;
            const { selectedZone, selectedSector, selectorType } = this.state;
            const isRTL = I18nManager.isRTL;
            switch (selectorType) {
                case 'zone':
                    orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';

                    result = await api.getZones({
                        municipalityCode: 'ADM',
                        options: { orderByFields: orderBy, outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'zoneNameA' : 'zoneNameE',
                    });

                case 'sector':
                    if (!selectedZone) return null;
                    orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';

                    result = await api.getSectors({
                        municipalityCode: 'ADM',
                        zoneId: selectedZone.zoneId,
                        options: {
                            orderByFields: orderBy,
                            outFields: 'objectId,sectorId,sectorNameA,sectorNameE',
                        },
                    });
                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'sectorNameA' : 'sectorNameE',
                    });
                case 'plot':
                    if (!selectedZone || !selectedSector) return null;

                    result = await api.getPlots({
                        sectorId: selectedSector.sectorId,
                        orderByFields: 'plotNumber',
                        options: {
                            outFields: 'objectId,gisId,plotId,plotNumber',
                        },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: 'plotNumber',
                    });

                default:
                    break;
            }
            this.setState({ isLoading: false });
        } catch (e) {
            console.log('error', e);
            this.setState({ isLoading: false });
        }
    };

    onLocationSelect = item => {
        switch (this.state.selectorType) {
            case 'zone':
                this.setState({
                    selectedZone: item || null,
                    selectorType: null,
                    selectedSector: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'sector':
                this.setState({
                    selectedSector: item || null,
                    selectorType: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'plot':
                this.setState(
                    {
                        selectedPlot: item || null,
                        selectorType: null,
                        searchFieldName: null,
                        dataSource: [],
                        dataSourceTemp: [],
                        isLoading: false,
                    },
                    () => {
                        if (item && this.state.selectedZone && this.state.selectedSector) {
                            this.handleSearch();
                        }
                    }
                );

                break;
            default:
                this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false });
                break;
        }
    };

    handleSearch = () => {
        this.props.actions.search(null, {
            ...this.props.search.filter,
            zone: this.state.selectedZone,
            sector: this.state.selectedSector,
            plot: this.state.plot,
        });
    };

    mapItem = item => {
        switch (this.state.selectorType) {
            case 'zone':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'zoneName') };
            case 'sector':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'sectorName') };
            case 'plot':
                return { ...item, id: item['objectId'], label: item['plotNumber'] };
            default:
                return null;
        }
    };

    searchKeyUpdate = searchKey => {
        if (this.state.dataSourceTemp && this.state.dataSourceTemp.length > 0) {
            const filterdDataSource = _.filter(this.state.dataSourceTemp, item => {
                let value = item[this.state.searchFieldName].toLowerCase();
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ dataSource: filterdDataSource });
        }
    };

    render() {
        return (
            <View style={styles.container}>
                {this.state.selectorType && (
                    <Selector
                        placeholder={strings('searchByName')}
                        isLoading={this.state.isLoading}
                        onSelect={this.onLocationSelect}
                        source={this.state.dataSource}
                        mapItem={this.mapItem}
                        searchKeyUpdate={this.searchKeyUpdate}
                        handleSearch={searchKey => this.handleLocationSearch(searchKey)}
                        onRequestClose={() => this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false })}
                        headerTitle={strings('select')}
                    />
                )}
                <View style={styles.buttonWrapper}>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('zone')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedZone, 'zoneName')) || strings('zone')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('sector')}>
                        {(this.state.selectedZone && localeProperty(this.state.selectedSector, 'sectorName')) || strings('sector')}
                    </Button>
                    <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('plot')}>
                        {(this.state.selectedPlot && this.state.selectedPlot.plotNumber) || strings('plot')}
                    </Button>
                    <Button style={[styles.optionBtn, styles.locationButton]} onPress={console.log}>
                        <IconEntypo name="location-pin" size={22} />
                    </Button>
                    <IconButton icon="search" size={20} onPress={this.handleSearch} />
                </View>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators(
            {
                search,
            },
            dispatch
        ),
        dispatch,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AddressPicker);
