import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
    },
    buttonWrapper: {
        flexDirection: 'row',
    },
    optionBtn: {
        backgroundColor: '$primaryMediumBackground',
        fontFamily: '$primaryFontNormal',
        marginRight: 5,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 3,
        minWidth: 80,
        maxWidth: 100,
    },
    itemWrapper: {
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginBottom: 2,
    },
    itemDetails: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
    },
    locationButton: {
        minWidth: 'auto',
        maxWidth: 'auto',
    },
    locationButtonIcon: {},
});
