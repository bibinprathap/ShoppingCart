import React from 'react';
import { Text, View, ScrollView } from 'react-native';
import { Thumbnail } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { withNavigation } from 'react-navigation';
import * as Animatable from 'react-native-animatable';
import { store } from 'app/config/store';

//Todo: move to styles.js it is here for hotreloading
const styles = EStyleSheet.create({
    container: {
        flex: 1,
        paddingStart: 10,
    },
    containerInner: {
        justifyContent: 'flex-start',
    },
});

export default withNavigation(function({
    attachments,
    onPress,
    onRemove,
    editable,
    navigation,
    hideDelete,
    thumbnailType,
    thumbnailSize,
    enableGalleryView,
    selectedAttachment,
    vertical,
}) {
    handleOnPress = (doc, index) => {
        if (enableGalleryView) {
            navigation.navigate('attachments', {
                attachments: attachments,
                editable: false,
                selectedAttachment: doc,
            });
        } else if (onPress) onPress(doc);
    };

    handleOnRemovePress = doc => {
        if (onRemove) {
            onRemove(doc);
        }
    };

    const state = store.getState();
    const authCode = state.auth.authCode;

    const thumbnails =
        attachments &&
        attachments.map((attachment, index) => {
            return (
                <Animatable.View
                    key={attachment.mobileReferenceNumber}
                    animation="fadeInUp"
                    duration={400}
                    useNativeDriver={true}
                    easing="ease-out"
                    delay={index ? index * 100 : 0}
                >
                    <Thumbnail
                        selected={attachment.mobileReferenceNumber === (selectedAttachment && selectedAttachment.mobileReferenceNumber)}
                        attachment={attachment}
                        editable={editable}
                        hideDelete={hideDelete}
                        thumbnailType={thumbnailType}
                        thumbnailSize={thumbnailSize}
                        index={index}
                        onRemove={handleOnRemovePress}
                        onPress={handleOnPress}
                        authCode={authCode}
                    />
                </Animatable.View>
            );
        });

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.containerInner} horizontal={!vertical}>
            {thumbnails}
        </ScrollView>
    );
});
