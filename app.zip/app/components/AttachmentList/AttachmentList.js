import React from 'react';
import { Text, View, ScrollView } from 'react-native';
import { Thumbnail } from 'app/components/Thumbnail';
import EStyleSheet from 'react-native-extended-stylesheet';
import { withNavigation } from 'react-navigation';
import * as Animatable from 'react-native-animatable';

//Todo: move to styles.js it is here for hotreloading
const styles = EStyleSheet.create({
    container: {
        flex: 1,
    },
    containerInner: {
        flex: 1,
        justifyContent: 'flex-start',
    },
});

export default withNavigation(function({
    attachments,
    onPress,
    onRemove,
    editable,
    navigation,
    hideDelete,
    thumbnailType,
    thumbnailSize,
    enableGalleryView,
    selectedAttachmentId,
    authCode,
}) {
    //console.log('AttachmentList.render attachments=', attachments);

    onLayout = event => {
        const { width, height } = event.nativeEvent.layout;
        /*
            thumbnail with height and width same as (height - offset) of the parent view
        */
        const offset = styles.attachmentListContainer.padding * 2;
        if (!this.state.layoutDone) this.setState({ layoutDone: true, thumbnailHeight: height - offset, thumbnailWidth: height - offset });
    };

    handleOnPress = (id, index) => {
        if (enableGalleryView) {
            navigation.navigate('attachments', {
                attachments: attachments,
                editable: false,
                selectedAttachmentId: id,
            });
        } else if (onPress) onPress(id);
    };

    handleOnRemovePress = id => {
        //console.log('AttachmentList.handleOnRemovePress', onRemove);
        if (onRemove) {
            onRemove(id);
        }
    };

    const thumbnails =
        attachments &&
        attachments.map((id, index) => {
            return (
                <Animatable.View
                    key={id}
                    animation="fadeInUp"
                    duration={400}
                    useNativeDriver={true}
                    easing="ease-out"
                    delay={index ? index * 100 : 0}
                >
                    <Thumbnail
                        id={id}
                        selected={id === selectedAttachmentId}
                        editable={editable}
                        hideDelete={hideDelete}
                        thumbnailType={thumbnailType}
                        thumbnailSize={thumbnailSize}
                        index={index}
                        onRemove={handleOnRemovePress}
                        onPress={handleOnPress}
                        authCode={authCode}
                    />
                </Animatable.View>
            );
        });

    //console.log('selectedAttachmentId:', selectedAttachmentId);
    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.containerInner} horizontal>
            {thumbnails}
        </ScrollView>
    );
});
