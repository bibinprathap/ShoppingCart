import React, { Component } from 'react';
import { AttachmentListWithDialog } from 'app/screens';

export default class AttachmentListTester extends Component {
    state = { editable: true, attachments: [] };

    onAdd = attachment => {

        this.setState({ attachments: [...this.state.attachments, attachment] });
    };

    onRemove = attachment => {
        const modifiedAttachments = [...this.state.attachments];
        let index;
        modifiedAttachments.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedAttachments.splice(index, 1);

        this.setState({ attachments: modifiedAttachments });
    };
    render() {
        const testerProps = { ...this.state };
        return <AttachmentListWithDialog {...testerProps} onAdd={this.onAdd} onRemove={this.onRemove} />;
    }
}
