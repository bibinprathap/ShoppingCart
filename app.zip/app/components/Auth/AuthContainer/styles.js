import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { widthPercentageToDP, heightPercentageToDP, listenOrientationChange, removeOrientationListener } from 'react-native-responsive-screen';
const logoWidth = 415;
logoHeight = 290;

export default EStyleSheet.create({
    $largeLogoWidth: logoWidth,
    $largeLogoHeight: logoHeight,
    $smallLogoWidth: logoWidth / 2,
    $smallLogoHeight: logoHeight / 2,
    statusBar: {
        backgroundColor: '$primaryDarkBackground',
    },
    logoContainer: {
        //position: 'absolute',
        //top: 0, left: 0, right: 0,
        //height: '$largeLogoHeight', //default   //290,
        height: 'auto',
        alignItems: 'center',
        justifyContent: 'center',
        //borderWidth: 1
    },
    logo: {
        height: '$largeLogoHeight',
        width: '$largeLogoWidth',
    },
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
        backgroundColor: '$primaryDarkBackground',
    },
    surface: {
        //marginTop: 100,
        padding: 8,
        //height: heightPercentageToDP('35%'),
        height: 'auto',
        width: widthPercentageToDP('70%'),
        backgroundColor: '$primaryDarkBackground',
        justifyContent: 'center',
        elevation: 8,
        //borderWidth: 1, borderColor: 'red'
    },
    languageContainer: {
        flexDirection: I18nManager.isRTL ? 'row-reverse' : 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginHorizontal: 10,
        paddingVertical: 20,
    },
    button: {
        marginHorizontal: 10,
        marginTop: 50,
        backgroundColor: '$primaryDarkButtonBackground',
    },
    languangeButton: {
        width: 190,
        backgroundColor: '$primaryDarkButtonBackground',
        paddingVertical: 4,
        margin: 1,
    },
    checkboxLabel: {
        color: '$primaryLightTextColor',
    },
    checkbox: {
        color: '$primaryDarkButtonBackground',
    },
});
