import Basic from './Basic';
import styles from './styles';

export { Basic, styles };
