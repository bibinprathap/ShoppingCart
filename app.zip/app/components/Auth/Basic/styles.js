import EStyleSheet from 'react-native-extended-stylesheet';
export default EStyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
    },
    heading: {
        marginHorizontal: 10,
        marginVertical: 20,
        color: '$primaryLightTextColor',
        alignSelf: 'flex-start',
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    input: {
        color: '$primaryLightTextColor',
        backgroundColor: '$primaryDarkInputBackground',
        borderRadius: 8,
        margin: 10,
    },
});
