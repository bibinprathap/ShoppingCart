import React, { Component } from 'react';
import { connect } from 'react-redux';
import EStyleSheet from 'react-native-extended-stylesheet';
import { StyleSheet, View, Text } from 'react-native';
import { Button } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import envConfig from 'app/api/config';
import AppApi from 'app/api/real';
const api = new AppApi();
import { authCancel } from 'app/actions/auth';

class CancelLogin extends Component {
    cancelPressed = () => {
        this.props.dispatch(authCancel()).then(() => {
            console.log('authCancel success');
        });
    };
    render() {
        console.log('CancelLogin.render() props: ', this.props);
        const { environment } = this.props;
        const currentEnvConfig = envConfig[environment];
        return (
            <View style={{ marginTop: 30 }}>
                <Text style={styles.centerText}>
                    Target environment: {environment} ({currentEnvConfig.baseURL})
                </Text>
                <Button style={styles.button} mode="contained" dark={true} onPress={this.cancelPressed}>
                    {strings('cancel')}
                </Button>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        environment: state.settings.environment,
    };
};

export default connect(mapStateToProps)(CancelLogin);

const styles = EStyleSheet.create({
    centerText: {
        color: '$primaryLightTextColor',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
    },
    button: {
        margin: 10,
        backgroundColor: '$primaryDarkButtonBackground',
    },
});
