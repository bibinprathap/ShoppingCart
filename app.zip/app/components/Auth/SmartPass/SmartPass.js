import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Button } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import { AuthContainer } from 'app/components';
import styles from './styles';

//Todo: change this to a helper service, this doesn't need to be a component
class SmartPass extends Component {
    static propTypes = {
        loggingIn: PropTypes.bool,
        onBeginLogin: PropTypes.any,
    };
    render() {
        const { loggingIn } = this.props;
        return (
            <AuthContainer isSmartPass={true} {...this.props}>
                <Button
                    style={styles.button}
                    mode="contained"
                    dark={true}
                    onPress={() => {
                        this.props.onBeginLogin();
                    }}
                    disabled={loggingIn}
                    loading={loggingIn}
                >
                    {strings('smartPassLogin')}
                </Button>
            </AuthContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        loggingIn: state.auth.loggingIn,
    };
};

export default connect(mapStateToProps)(SmartPass);
