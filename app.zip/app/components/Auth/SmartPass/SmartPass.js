import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Button } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import { authorize, refresh, revoke } from 'ThirdPartyModules/react-native-app-auth';
import pinch from 'react-native-pinch';
import axios from 'axios';
import { AuthContainer } from 'app/components/Auth/AuthContainer';
import { startSmartPassAuthentication, authSuccess } from 'app/actions/auth';
import { config as smartPassConfig, apiUrl as smartPassUrl } from 'app/config/smartPass';
import styles from './styles';
import images from 'app/images';
import DeviceInfo from 'react-native-device-info';
const isEmulator = DeviceInfo.isEmulator(); // false

//Todo: change this to a helper service, this doesn't need to be a component
class SmartPass extends Component {
    static propTypes = {
        loggingIn: PropTypes.bool,
        onBeginLogin: PropTypes.any,
    };
    render() {
        const { loggingIn } = this.props;
        return (
            <AuthContainer isSmartPass={true} {...this.props}>
                <Button
                    style={styles.button}
                    mode="contained"
                    dark={true}
                    onPress={() => {
                        this.props.onBeginLogin();
                    }}
                    disabled={loggingIn}
                    loading={loggingIn}
                >
                    {strings('smartPassLogin')}
                </Button>
            </AuthContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        loggingIn: state.auth.loggingIn,
    };
};

export default connect(mapStateToProps)(SmartPass);
