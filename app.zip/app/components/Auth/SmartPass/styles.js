import EStyleSheet from 'react-native-extended-stylesheet';
import { widthPercentageToDP, heightPercentageToDP, listenOrientationChange, removeOrientationListener } from 'react-native-responsive-screen';

export default EStyleSheet.create({
    button: {
        backgroundColor: '$primaryDarkButtonBackground',
        marginHorizontal: 10,
        marginVertical: 20,
        paddingVertical: 6,
    },
});
