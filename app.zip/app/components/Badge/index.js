import Badge from './Badge';

export { Badge };
