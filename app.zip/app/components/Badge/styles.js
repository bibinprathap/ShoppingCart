import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    defaultContainer: {
        position: 'absolute',
        zIndex: 100,
        borderWidth: 1,
        overflow: 'hidden',
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    defaultText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryWhite',
        fontWeight: 'bold',
    },
});
