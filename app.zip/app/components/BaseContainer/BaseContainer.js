import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, StatusBar, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard } from 'react-native';
import styles from './styles';

export default function(props) {
    const backgroundColor = props.backgroundColor;
    const children = props.children;
    const containerStyles = [styles.container];

    if (backgroundColor) {
        containerStyles.push({ backgroundColor: backgroundColor });
    }

    return (
        /*
        <ScrollView contentContainerStyle={{
            flex: 1
            //take up all space remaining after status bar and navigation header }
        }}>
        </ScrollView>
        */
        <View style={{ flex: 1 /* take up all space remaining after status bar and navigation header */ }}>
            <StatusBar translucent={false} hidden={false} barStyle="default" backgroundColor={styles.statusBar.backgroundColor} />
            {/* <TouchableWithoutFeedback style={{ flex: 1 }} onPress={() => { Keyboard.dismiss() }}> */}
            <View style={containerStyles}>{children}</View>
            {/* </TouchableWithoutFeedback> */}
        </View>
    );
}

// BaseContainer.propTypes = {
//     children: PropTypes.any,
//     backgroundColor: PropTypes.string,
// };
