import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { mainStackDefinition } from 'app/config/routs/defs';
import { authLogout } from 'app/actions/auth';
import _ from 'lodash';

class BaseContainerWithSideNav extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    constructor(props) {
        super(props);
        this.sidenavRoutes = mainStackDefinition.routes;
        this.currentRouteName = this.props.navigation.state.routeName;
        this.breadCrumbs = [{ key: 'dashboard', title: strings('dashboard') }];
        currentRouteDefIndex = _.findIndex(mainStackDefinition.routes, item => item.key === this.currentRouteName);
        if (currentRouteDefIndex > -1) {
            this.breadCrumbs.push({
                key: this.currentRouteName,
                title: mainStackDefinition.routes[currentRouteDefIndex].title,
                selected: true,
            });
        }
    }

    handleSideNavOnPress = item => {
        //console.log(`BaseContainerWithSideNav.handleSideNavOnPress(${item.key})`);
        if (item.key === 'logout') {
            this.props.dispatch(authLogout());
            this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
        } else this.props.navigation.navigate(item.key);
    };

    render() {
        const { children } = this.props;
        return (
            <BaseContainer {...this.props}>
                <SearchBar breadCrumbs={this.breadCrumbs} />
                <View style={styles.containerWithSideNav}>
                    <View style={styles.sideNavContainer}>
                        <SideNav routes={this.sidenavRoutes} onPress={this.handleSideNavOnPress} currentRouteName={this.currentRouteName} />
                    </View>
                    <View style={styles.contentsContainer}>{children}</View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
    };
};

export default connect(mapStateToProps)(BaseContainerWithSideNav);
