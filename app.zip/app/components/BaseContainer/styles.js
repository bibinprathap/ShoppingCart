import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    statusBar: {
        backgroundColor: '$primaryHeaderColor',
    },

    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '$primaryWhite',
    },
    containerWithSideNav: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
        width: '$sideNavWidth',
        minWidth: '$sideNavWidth',
        maxWidth: '$sideNavWidth',
    },
    contentsContainer: {
        flex: 9,
        backgroundColor: '$primaryWhite',
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 30,
        borderRadius: 10,
    },
});
