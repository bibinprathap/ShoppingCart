import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Checkbox, Text } from 'react-native-paper';
import { TapGestureHandler } from 'react-native-gesture-handler';

class CheckBoxWithLabel extends Component {
    static propTypes = {
        lable: PropTypes.string,
        value: PropTypes.bool,
        onValueChange: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            checked: props.value || false,
        };
    }

    handleOnPress = () => {
        this.setState({ checked: !this.state.checked }, obj => {
            if (typeof this.props.onValueChange === 'function') {
                this.props.onValueChange(this.state.checked);
            }
        });
    };

    render() {
        ({ label, value, onValuechange, checkBoxStyle, labelStyle, color, uncheckedColor } = this.props);
        const checked = this.state.checked;
        var checkBoxElementStyles = [{ color: 'red' }];
        if (checkBoxStyle) checkBoxElementStyles.push(checkBoxStyle);
        var textElementStyles = [{ alignSelf: 'center', textAlign: 'center' }];
        if (labelStyle) textElementStyles.push(labelStyle);
        return (
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                <Checkbox status={checked ? 'checked' : 'unchecked'} onPress={this.handleOnPress} {...this.props} style={checkBoxElementStyles} />
                <Text style={textElementStyles}>{label}</Text>
            </View>
        );
    }
}

export default CheckBoxWithLabel;
