import React, { Component } from 'react';
import PropTypes from 'prop-types';
import EStyleSheet from 'react-native-extended-stylesheet';
import { View, TouchableNativeFeedback, Modal } from 'react-native';
import { withNavigation } from 'react-navigation';
import { _ } from 'lodash';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Badge } from 'app/components/Badge';
import { I18nManager } from 'react-native';
import styles from './styles';
import Remark from './Remark';
import { Attachments } from 'app/screens/attachments';

class AttachmentAndRemarks extends React.PureComponent {
    static propTypes = {
        attachments: PropTypes.array,
        remarks: PropTypes.string,
        onAttachmentChanged: PropTypes.func,
        onRemarksChanged: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = { attachmentModalVisible: false, selectedAttachmentId: null, remarksDialogVisible: false };
        this.handleRemarksDialogDismiss = this.handleRemarksDialogDismiss.bind(this);
        this.handleRemarksPressed = this.handleRemarksPressed.bind(this);
        this.handleRemarksAdded = this.handleRemarksAdded.bind(this);
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
    }
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };

    handleAttachmentClosed = () => {
        this.setState({
            attachmentModalVisible: false,
        });
        //if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(attachments);
    };

    handleAttachmentAdded = newAttachment => {
        const { attachments } = this.props;
        const newAttachmentsArray = attachments ? [...attachments, newAttachment] : [newAttachment];
        //console.log('AttachmentAndRemarks.handleAttachmentAdded newAttachments = ', newAttachmentsArray);
        if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(newAttachmentsArray);
    };

    handleAttachmentRemoved = docId => {
        const { attachments } = this.props;
        const newAttachmentsArray = _.without(attachments, docId);
        if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(newAttachmentsArray);
    };

    handleAttachmentPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleRemarksPressed = props => {
        this.setState({ remarksDialogVisible: !this.state.remarksDialogVisible });
    };

    handleRemarksDialogDismiss = props => {
        this.setState({ remarksDialogVisible: false });
    };

    handleRemarksAdded = newRemarks => {
        if (this.props.onRemarksChanged) this.props.onRemarksChanged(newRemarks);
        this.setState({ remarksDialogVisible: false });
    };

    render() {
        const { attachments, remarks, editable } = this.props;
        const { remarksDialogVisible } = this.state;
        const attachmentsCount = !!attachments ? attachments.length : 0;
        const remarksCount = !!remarks ? 1 : 0;

        return (
            <View style={styles.container}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.attachmentModalVisible}
                    onRequestClose={this.toggleAttachmentDialog}
                >
                    <Attachments
                        attachments={this.props.attachments}
                        onAdd={this.handleAttachmentAdded}
                        onRemove={this.handleAttachmentRemoved}
                        onClose={this.handleAttachmentClosed}
                        selectedAttachmentId={this.state.selectedAttachmentId}
                        editable={editable}
                        attachmentModalVisible={this.state.attachmentModalVisible}
                    />
                </Modal>

                <View style={styles.buttonContainer}>
                    <TouchableNativeFeedback disabled={attachmentsCount == 0 && !editable} onPress={this.handleAttachmentPressed}>
                        <View style={{ flex: 1 }}>
                            {attachmentsCount > 0 && <Badge size={18}>{attachmentsCount}</Badge>}
                            <Icon name="photo-camera" size={44} style={styles.icon} />
                        </View>
                    </TouchableNativeFeedback>
                </View>
                <View style={styles.buttonContainer}>
                    <TouchableNativeFeedback disabled={remarksCount == 0 && !editable} onPress={this.handleRemarksPressed}>
                        <View style={{ flex: 1 }}>
                            {remarksCount > 0 && (
                                <View style={styles.remarkTickMark}>
                                    <Icon name="check" color="#ffffff" size={14} style={[styles.remarkTickMarkIcon]} />
                                </View>
                            )}
                            <Icon name="comment" size={44} style={styles.icon} />
                        </View>
                    </TouchableNativeFeedback>
                </View>
                <Remark
                    remarksDialogVisible={remarksDialogVisible}
                    editable={editable}
                    handleRemarksDialogDismiss={this.handleRemarksDialogDismiss}
                    onRemarksAdded={this.handleRemarksAdded}
                    remarks={remarks}
                />
            </View>
        );
    }
}
export default withNavigation(AttachmentAndRemarks);
