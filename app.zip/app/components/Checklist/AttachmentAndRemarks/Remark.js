import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import moment from 'moment';
import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager, View, TextInput, ScrollView } from 'react-native';
import { Button, Dialog, Portal } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { dialogTheme } from 'app/styles';

class Remark extends Component {
    static propTypes = {
        remarks: PropTypes.string,
        onRemarksAdded: PropTypes.func,
    };
    constructor(props) {
        super(props);
        this.state = {
            newRemarks: props.remarks,
        };
        this.onRemarkChange = this.onRemarkChange.bind(this);
    }
    handleNewRemarksButtonOnPress = () => {
        const { newRemarks } = this.state;
        //   if (!newRemarks) return;
        if (this.props.onRemarksAdded) {
            this.props.onRemarksAdded(newRemarks);
        }
    };
    onRemarkChange = newVal => this.setState({ newRemarks: newVal });
    render() {
        const { remarks, editable, remarksDialogVisible, handleRemarksDialogDismiss } = this.props;
        const { newRemarks } = this.state;
        const titleTheme = {
            ...dialogTheme,
            colors: {
                primary: EStyleSheet.value('$primaryDarkTextColor'),
                surface: EStyleSheet.value('$primaryDarkTextColor'),
                background: EStyleSheet.value('$primaryDarkTextColor'),
                text: EStyleSheet.value('$primaryDarkTextColor'),
            },
        };

        return (
            <Portal>
                <Dialog visible={remarksDialogVisible} onDismiss={handleRemarksDialogDismiss} theme={dialogTheme}>
                    <Dialog.Title theme={titleTheme} style={{ alignSelf: 'flex-start' }}>
                        {strings('remarks')}
                    </Dialog.Title>
                    <Dialog.Content>
                        <View
                            style={{
                                borderTopWidth: EStyleSheet.value('$primaryBorderThin'),
                                borderBottomWidth: 0,
                                borderColor: EStyleSheet.value('$primaryBorderColor'),
                                height: 300,
                                paddingHorizontal: 15,
                                marginHorizontal: 15,
                            }}
                        >
                            <Dialog.ScrollArea style={{ paddingHorizontal: 0 }}>
                                <TextInput
                                    style={styles.remarksListNewRemarksInput}
                                    placeholder={strings('newRemarks')}
                                    value={newRemarks}
                                    editable={editable}
                                    onChangeText={this.onRemarkChange}
                                    autoCorrect={false}
                                    direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                    autoCapitalize="sentences"
                                    //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                    autoFocus={true}
                                    multiline={true}
                                    textAlignVertical={'top'}
                                />

                                {/* <RemarksList editable={editable} remarks={remarks} onRemarksAdded={this.handleRemarksAdded} /> */}
                            </Dialog.ScrollArea>
                        </View>
                    </Dialog.Content>
                    <Dialog.Actions>
                        <Button style={styles.dialogDoneButton} onPress={this.handleNewRemarksButtonOnPress}>
                            {strings('done')}
                        </Button>
                    </Dialog.Actions>
                </Dialog>
            </Portal>
        );
    }
}
mapStateToProps = state => {
    return {
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(Remark);
