import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import moment from 'moment';
import { View, TextInput, ScrollView } from 'react-native';
import { Icon } from 'app/components';
import { Text, TouchableRipple } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';

class RemarksList extends Component {
    static propTypes = {
        remarks: PropTypes.object,
        onRemarksAdded: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            newRemarks: undefined,
        };
        //this.scrollToEnd = true;
        //this.firstRender = true;
    }

    handleScrollViewLayout = () => {
        this.scrollView.scrollToEnd({ animated: true });
    };
    // scrllToEndIfNeeded = () => {
    //     //if (this.scrollToEnd) {

    //     this.scrollView.scrollToEnd({ animated: true });
    //     //this.scrollToEnd = false;
    //     //}
    // };

    handleNewRemarksButtonOnPress = () => {
        /*
            RJ: RemarksList is a controled component, the host should take care of what to do when new remarks are added.

                example: dispatch appropriate redux action, that will add the new remarks to the store, which will eventually
                get passed down to this component via remarks prop and get rendered.
        */
        const { newRemarks } = this.state;
        if (!newRemarks) return;
        const { userData } = this.props;
        this.scrollToEnd = true;
        setTimeout(() => {
            this.setState({ newRemarks: undefined });
            if (this.props.onRemarksAdded) {
                const remarksObj = {
                    addedOn: moment().format('YYYY-MM-DD HH:mm:ss'),
                    addedByUUID: userData.uuid,
                    addedByFullnameA: userData.fullnameAR,
                    addedByFullnameE: userData.fullnameEN,
                    value: newRemarks,
                };
                this.props.onRemarksAdded(remarksObj);
            }
        }, 0);
    };

    componentDidUpdate(prevProps, prevState) {
        if (this.scrollToEnd) {
            setTimeout(() => {
                if (this.scrollView) this.scrollView.scrollToEnd({ animated: true });
                this.scrollToEnd = false;
            });
        }
    }

    render() {
        const { remarks, editable } = this.props;
        const { newRemarks } = this.state;
        const newRemarksButtonStyles = [styles.remarksListNewRemarksButton, newRemarks ? styles.remarksListNewRemarksButtonEnabled : null];
        const renderedRemarks = !remarks
            ? undefined
            : Object.keys(remarks).map(remarksKey => {
                  const item = remarks[remarksKey];
                  return (
                      <View key={remarksKey} style={styles.remarksListItemContainer}>
                          <View style={styles.remarksListItemHeader}>
                              <Text style={styles.remarksListItemAddedBy}>{localeProperty(item, 'addedByFullname')}</Text>
                              <Text style={styles.remarksListItemAddedOn}>{moment(item.addedOn).fromNow()}</Text>
                          </View>
                          <Text style={styles.remarksListItemBodyText}>{item.value}</Text>
                      </View>
                  );
              });
        return (
            <View style={styles.remarksListMainContainer}>
                {!remarks && (
                    <View style={styles.remarksListEmptyContainer}>
                        <Text>{strings('emptyRemarksList')}</Text>
                    </View>
                )}
                {remarks && (
                    <ScrollView
                        ref={ref => (this.scrollView = ref)}
                        contentContainerStyle={{ paddingHorizontal: 0 }}
                        onLayout={this.handleScrollViewLayout}
                    >
                        <View style={styles.remarksListContaner}>{renderedRemarks}</View>
                    </ScrollView>
                )}
                <View style={styles.remarksListNewRemarksContainer}>
                    <TextInput
                        style={styles.remarksListNewRemarksInput}
                        placeholder={strings('newRemarks')}
                        value={newRemarks}
                        editable={editable}
                        onChangeText={newVal => this.setState({ newRemarks: newVal })}
                        autoCorrect={false}
                        autoCapitalize="sentences"
                        //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                        autoFocus={true}
                        multiline={true}
                    />
                    <View style={styles.remarksListNewRemarksButtonContainer}>
                        <TouchableRipple disabled={!editable} onPress={this.handleNewRemarksButtonOnPress}>
                            <Icon type="MaterialCommunityIcons" name="send" size={50} style={newRemarksButtonStyles} />
                        </TouchableRipple>
                    </View>
                </View>
            </View>
        );
    }
}
mapStateToProps = state => {
    return {
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(RemarksList);
