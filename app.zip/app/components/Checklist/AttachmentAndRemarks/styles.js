import { I18nManager, Dimensions } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

const remarksListContentMaxHeight = Dimensions.get('screen').height * 0.4;

export default EStyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 3,
        borderRadius: 5,
    },
    button: {
        color: '$primaryWhite',
        alignSelf: 'center',
    },
    icon: {
        color: '$primaryDarkIconbuttonBackground',
        alignSelf: 'center',
    },
    dialogTitle: {
        backgroundColor: '$primaryDarkTextColor',
        color: '$primaryWhite',
    },
    dialogDoneButton: {
        backgroundColor: '$primaryLightButtonBackground',
        color: '$primaryWhite',
        minWidth: 50,
    },
    remarksListMainContainer: {
        maxHeight: remarksListContentMaxHeight,
        flexDirection: 'column',
    },
    remarksListEmptyContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primaryLightInputBackground',
        marginHorizontal: 10,
        marginTop: 10,
        padding: 20,
        borderRadius: 10,
    },
    remarksListContaner: {
        backgroundColor: '$primaryLightInputBackground',
        marginHorizontal: 10,
        marginTop: 10,
        paddingHorizontal: 10,
        paddingTop: 10,
        borderRadius: 10,
    },
    remarksListNewRemarksContainer: {
        flexDirection: 'row',
        margin: 10,
    },
    remarksListNewRemarksInput: {
        flex: 1,
        minHeight: 300,
        marginTop: 10,
        marginBottom: 10,
        paddingTop: 20,
        paddingBottom: 20,
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryLightInputBackground',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        direction: I18nManager.isRTL ? 'rtl' : 'ltr',
        fontSize: '$primaryTextSM',
    },
    remarksListNewRemarksButtonContainer: {
        flexDirection: 'column',
        justifyContent: 'flex-end',
    },
    remarksListNewRemarksButton: {
        color: '$primaryDarkIconbuttonBackground',
        alignSelf: 'center',
        transform: [{ scaleX: I18nManager.isRTL ? -1 : 1 }],
    },
    remarksListNewRemarksButtonEnabled: {
        color: '$primaryLightButtonBackground',
    },
    remarksListItemContainer: {
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryWhite',
        borderRadius: 10,
        padding: 10,
        marginBottom: 10,
    },
    remarksListItemHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderColor: '$primaryWhite',
    },
    remarksListItemAddedBy: {
        fontSize: '$primaryTextSM',
    },
    remarksListItemAddedOn: {
        color: '$primaryHeaderColor',
        fontSize: '$primaryTextXS',
    },
    remarksListItemBodyText: { fontSize: '$primaryTextSM', alignSelf: 'flex-start' },
    remarkTickMark: {
        position: 'absolute',
        top: -5,
        right: -3,
        height: 18,
        borderRadius: 9,
        zIndex: 100,
        borderWidth: 1,
        overflow: 'hidden',
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    remarkTickMarkIcon: {
        color: '$primaryWhite',
        alignSelf: 'center',
    },
});
