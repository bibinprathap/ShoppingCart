import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        //marginVertical: 10
        //borderWidth: 1
    },
    questionContainer: {
        flex: 1,
        //flexGrow: 3,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingStart: 10,
        marginBottom: 10,
    },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    optionsAndOtherControlsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },

    actiontypeContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    typePicker: {
        // flex: 1,
    },
    violationAmount: {
        zIndex: 100,
        textAlign: 'right',
        textAlignVertical: 'center',
        color: '$primaryDarkTextColor',
        maxWidth: 90,
        minWidth: 80,
    },
    optionsContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginEnd: 5,
    },
    optionButtonContainer: {
        flex: 1,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '$primaryDarkIconbuttonBackground',
        marginEnd: 5,
    },
    touchWrapper: {
        flex: 1,
    },
    optionButtonSelected: {
        color: '$primaryWhite',
        borderWidth: 0,
        borderRadius: 5,
    },
    optionButtonSelectedYes: {
        backgroundColor: '$primaryYesButtonBackground',
    },

    optionButtonSelectedNo: {
        backgroundColor: '$primaryNoButtonBackground',
    },

    optionButtonSelectedNa: {
        backgroundColor: '$primaryNotApplicableButtonBackground',
    },
    optionButton: {
        flex: 1,
        //alignSelf: 'center',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    attachmentsAndRemarksContainer: {
        flex: 1,
    },
    numberPicker: { height: 70, width: 70 },
    actionPicker: { height: 50, width: '100%', flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start' },
    periodTypePicker: { height: 50, width: '100%', flex: 1, marginLeft: 20, justifyContent: 'flex-start', alignSelf: 'flex-start' },
    pickerContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        borderWidth: 0.751173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
    },
    labelContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    violationsActionSelectionContainer: {
        flex: 1,
        // marginHorizontal: 5,
        // marginVertical: 5,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionTypeContainer: {
        flex: 1,
        alignSelf: 'center',
        alignItems: 'center',
        borderWidth: 0.251173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
    },
    actionPeriod: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'center',
        borderWidth: 0.251173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
    },
    checkboxLabel: {
        color: '$primaryLightTextColor',
    },
    checkbox: {
        color: '$primaryDarkButtonBackground',
    },
});
