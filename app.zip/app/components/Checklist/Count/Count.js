import React, { Component } from 'react';
import { View } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { _ } from 'lodash';
import { AttachmentAndRemarks, Icon } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { NumericInput } from 'app/components';
import { inspectionsHelper } from 'app/api/helperServices';

const initValues = {
    selectedCount: null,
    attachments: undefined,
    remarks: undefined,
};

class Count extends Component {
    constructor(props) {
        super(props);
        const selectedCount = props.val ? props.val.selectedCount : undefined;
        const attachments = props.val ? props.val.attachments : undefined;
        const remarks = props.val ? props.val.remarks : undefined;
        this.state = {
            ...initValues,
            selectedCount,
            attachments,
            remarks,
        };
        this.countChanged = this.countChanged.bind(this);
    }
    getCurrentValObject = () => {
        //Todo: decide where to get the attachments and remarks from? props or state
        const { selectedCount, attachments, remarks } = this.state;
        const { val } = this.props;
        return {
            val: {
                ...val,
                checkItemId: this.props.checkItemId,
                inspTypeCheckItemId: this.props.inspTypeCheckItemId,
                selectedCount,
                attachments,
                remarks,
            },
        };
    };
    shouldComponentUpdate(nextProps, nextState) {
        return !(this.state.selectedCount != nextState.selectedCount) && !(this.state === nextState);
        // shallowEqual(this.props, nextProps, this.state, nextState);
    }
    countChanged = count => {
        const previousSelectedCount = this.state.selectedCount;
        let newState = { selectedCount: count };
        this.setState(newState, () => {
            if (this.props.onValuechanged && previousSelectedCount !== this.state.selectedCount) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };
    handleOnAttachmentChanged = attachments => {
        this.setState({ attachments: attachments }, () => {
            if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(this.getCurrentValObject());
        });
    };
    handleOnRemarksChanged = newRemarks => {
        this.setState({ remarks: newRemarks }, () => {
            if (this.props.onRemarksChanged) this.props.onRemarksChanged(this.getCurrentValObject());
        });
    };
    render() {
        const question = this.props.question || 'Unknown question';
        const { selectedCount, attachments, remarks } = this.state;
        const { editable, inspTypeCheckItemId, checkItemId } = this.props;
        return (
            <View style={styles.container}>
                <View style={styles.questionContainer}>
                    <Text style={styles.questionText}>{question}</Text>
                </View>
                <View style={styles.countAndOtherControlsContainer}>
                    <View style={styles.countContainer}>
                        {this.props.isMandatory ? (
                            <Icon type="MaterialCommunityIcons" name="flag-triangle" style={{ color: '#FF0000' }} size={24} />
                        ) : null}
                        <View style={styles.countButtonContainer}>
                            <NumericInput
                                value={selectedCount || 0}
                                initValue={selectedCount || 0}
                                totalWidth={120}
                                minValue={0}
                                totalHeight={40}
                                onChange={this.countChanged}
                            />
                        </View>
                    </View>
                    <AttachmentAndRemarks
                        editable={editable}
                        attachments={attachments}
                        remarks={remarks}
                        inspTypeCheckItemId={inspTypeCheckItemId}
                        style={styles.attachmentsAndRemarksContainer}
                        onAttachmentChanged={this.handleOnAttachmentChanged}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                </View>
            </View>
        );
    }
}

export default Count;
