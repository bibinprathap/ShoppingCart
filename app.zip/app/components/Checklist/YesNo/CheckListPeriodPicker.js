import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Picker, View, Text } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { PeriodPicker } from 'app/components/PeriodPicker';
import styles from './styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload

class CheckListPeriodPicker extends Component {
    static propTypes = {
        items: PropTypes.any,
    };

    render() {
        const {
            periodTypeOptions,
            selectedPeriodType,
            editable,
            selectedPeriod,
            handlePeriodNumberPickerChange,
            handleChangePeriodType,
        } = this.props;
        if (editable) {
            return (
                <PeriodPicker
                    periodTypeOptions={periodTypeOptions}
                    selectedPeriodType={selectedPeriodType}
                    selectedPeriod={selectedPeriod}
                    editable={true}
                    handlePeriodNumberPickerChange={handlePeriodNumberPickerChange}
                    handleChangePeriodType={handleChangePeriodType}
                />
            );
        } else {
            return (
                <View style={styles.violationAmountContainer}>
                    <Icon name="access-time" size={25} style={styles.icon} />
                    {selectedPeriodType == 'day' || selectedPeriodType == 'hour' ? (
                        <Text style={styles.pickerViolationAmount}>{selectedPeriod + ' ' + strings(selectedPeriodType)}</Text>
                    ) : null}
                </View>
            );
        }
    }
}

export default CheckListPeriodPicker;
