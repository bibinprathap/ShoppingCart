import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Picker, View } from 'react-native';
import moment from 'moment';
import { Text, TouchableRipple } from 'react-native-paper';
import { AttachmentAndRemarks } from 'app/components/Checklist/AttachmentAndRemarks';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import styles from './styles';
import Icon from 'react-native-vector-icons/MaterialIcons';
import IconCommunity from 'react-native-vector-icons/MaterialCommunityIcons';
import { LawclauseList } from 'app/components/LawclauseList';
import { inspectionsHelper } from 'app/api/helperServices';

import CheckListActionTypePicker from './CheckListActionTypePicker';
import CheckListPeriodPicker from './CheckListPeriodPicker';
import { shallowEqual } from 'app/api/helperServices';

class YesNoOld extends Component {
    static propTypes = {
        question: PropTypes.string,
        val: PropTypes.shape({
            selectedOption: PropTypes.string,
            attachments: PropTypes.Array,
            remarks: PropTypes.string,
        }),
        onValuechanged: PropTypes.func,
        onAttachmentChanged: PropTypes.func,
        onRemarksChanged: PropTypes.func,
    };

    constructor(props) {
        super(props);

        const selectedOption = props.val ? props.val.selectedOption : undefined;
        const attachments = props.val ? props.val.attachments : undefined;
        const remarks = props.val ? props.val.remarks : undefined;
        const violationTypeIds = props.val ? [props.val.violationTypeIds[0]] : [];
        const selectedActionType = props.val ? props.val.selectedActionType : '';
        const selectedPeriodType = props.val ? props.val.selectedPeriodType : {};
        const selectedPeriod = props.val ? props.val.selectedPeriod : 1;
        let actionTypeoptions = [];
        // selectedActionType ? [selectedActionType] : [];
        const violationAmount = props.val && props.val.violationAmount ? props.val.violationAmount : 0;
        const posibleViolatorTypes = props.val && props.val.posibleViolatorTypes ? props.val.posibleViolatorTypes : null;
        const violatorType = props.val && props.val.violatorType ? props.val.violatorType : null;

        let showViolationActions = false;
        let showPeriodSelection = false;
        let showActionType = false;
        if (selectedOption == 'no') {
            showViolationActions = true;
            showActionType = violationTypeIds.length > 0;
            showPeriodSelection = showActionType && selectedActionType != 'violations';
            const items = inspectionsHelper.getViolationTypeOptions(violationTypeIds, props.checkItemId);
            actionTypeoptions = ['violations'];
            items.map(v => {
                const selectedItem = v;
                if (selectedItem.mandatoryAwarenes && actionTypeoptions.filter(a => a == 'awareness').length == 0) {
                    actionTypeoptions.push('awareness');
                }
                if (selectedItem.mandatoryWarning && actionTypeoptions.filter(a => a == 'warning').length == 0) {
                    actionTypeoptions.push('warning');
                }
            });
        }
        this.state = {
            showViolationActions,
            showPeriodSelection,
            showActionType,
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            selectedActionType,
            selectedPeriodType,
            selectedPeriod,
            actionTypeoptions,
            violationAmount,
            posibleViolatorTypes,
            violatorType,
        };
        this.handlePeriodNumberPickerChange = this.handlePeriodNumberPickerChange.bind(this);
        this.handleChangePeriodType = this.handleChangePeriodType.bind(this);
    }

    getCurrentValObject = () => {
        //Todo: decide where to get the attachments and remarks from? props or state
        const {
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            selectedActionType,
            selectedPeriodType,
            selectedPeriod,
            violationAmount,
            posibleViolatorTypes,
            violatorType,
        } = this.state;
        return {
            val: {
                checkItemId: this.props.checkItemId,
                inspTypeCheckItemId: this.props.inspTypeCheckItemId,
                selectedOption,
                attachments,
                remarks,
                violationTypeIds,
                selectedActionType,
                selectedPeriodType,
                selectedPeriod,
                violationAmount,
                posibleViolatorTypes,
                violatorType,
            },
        };
    };

    shouldComponentUpdate(nextProps, nextState) {
        return !(this.state.selectedPeriod != nextState.selectedPeriod) && !(this.state === nextState);
        // shallowEqual(this.props, nextProps, this.state, nextState);
    }

    optionSelected = option => {
        const previousSelectedOption = this.state.selectedOption;
        const newState = { selectedOption: option, showViolationActions: option === 'no' };
        if (option === 'yes') {
            newState.showPeriodSelection = false;
            newState.showActionType = false;
            newState.violationTypeIds = [];
            newState.selectedActionType = '';
            newState.selectedPeriodType = {};
            newState.selectedPeriod = 1;

            newState.actionTypeoptions = [];
            newState.violationAmount = 0;
            newState.posibleViolatorTypes = null;
            newState.violatorType = null;
        } else if (option === 'no') {
            const { violationTypeIds, checkItemId } = this.props;
            let actionTypeoptions = [];
            let selectedActionType = '';
            let values = [];
            let violationAmount = 0;
            let posibleViolatorTypes = null;
            let violatorType = null;
            const items = inspectionsHelper.getViolationTypeOptions(violationTypeIds, checkItemId);
            actionTypeoptions = ['violations'];
            items.map(v => {
                const selectedItem = v;
                if (selectedItem.mandatoryAwarenes && actionTypeoptions.filter(a => a == 'awareness').length == 0) {
                    actionTypeoptions.push('awareness');
                }
                if (selectedItem.mandatoryWarning && actionTypeoptions.filter(a => a == 'warning').length == 0) {
                    actionTypeoptions.push('warning');
                }
            });
            // values = items.map(I => I.id);
            values = [items.map(I => I.id)[0]];
            violationAmount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
            posibleViolatorTypes = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
            violatorType = posibleViolatorTypes[0];
            selectedActionType = actionTypeoptions[0];
            newState.violationTypeIds = values;
            newState.selectedActionType = selectedActionType;
            newState.selectedPeriodType = {};
            newState.selectedPeriod = 1;
            newState.showActionType = items.length > 0;
            newState.showPeriodSelection = false;
            newState.actionTypeoptions = actionTypeoptions;
            newState.violationAmount = violationAmount;
            newState.posibleViolatorTypes = posibleViolatorTypes;
            newState.violatorType = violatorType;
        }
        this.setState(newState, () => {
            if (this.props.onValuechanged && previousSelectedOption !== this.state.selectedOption) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };

    handleLawClausePickerChange = (values, items) => {
        const previousSelectedLawClause = this.state.violationTypeIds;
        const actionTypeoptions = ['violations'];
        values.map(v => {
            const selectedItem = items.filter(a => a.id == v)[0];
            if (selectedItem.mandatoryAwarenes && actionTypeoptions.filter(a => a == 'awareness').length == 0) {
                actionTypeoptions.push('awareness');
            }
            if (selectedItem.mandatoryWarning && actionTypeoptions.filter(a => a == 'warning').length == 0) {
                actionTypeoptions.push('warning');
            }
        });
        const selectedActionType = actionTypeoptions[0];
        const violationAmount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
        const posibleViolatorTypes = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
        const violatorType = posibleViolatorTypes[0];
        this.setState(
            {
                violationTypeIds: values,
                selectedActionType,
                actionTypeoptions,
                violationAmount,
                showActionType: items.length > 0,
                showPeriodSelection: false,
                selectedPeriodType: {},
                selectedPeriod: 1,
                posibleViolatorTypes: posibleViolatorTypes,
                violatorType,
            },
            () => {
                if (this.props.onValuechanged && previousSelectedLawClause !== this.state.violationTypeIds) {
                    this.props.onValuechanged(this.getCurrentValObject());
                }
            }
        );
    };
    handlePeriodNumberPickerChange = values => {
        const previousSelectedNumber = this.state.selectedPeriod;
        this.setState({ selectedPeriod: values }, () => {
            if (this.props.onValuechanged && previousSelectedNumber !== this.state.selectedPeriod) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };
    handleChangeActions = (values, violationTypeIds) => {
        const previousselectedActionType = this.state.selectedActionType;
        const newState = { selectedActionType: values, showPeriodSelection: values != 'violations' };
        if (values === 'violations') {
            newState.showPeriodSelection = false;
            newState.selectedPeriodType = {};
            newState.selectedPeriod = 1;
            newState.violationAmount = inspectionsHelper.getViolationAmount({ lawClauseIDs: violationTypeIds, occurance: 1, discount: 0 });
        } else {
            newState.violationAmount = 0;
            newState.selectedPeriodType = 'day';
            newState.selectedPeriod = 1;
        }
        this.setState(newState, () => {
            if (this.props.onValuechanged && previousselectedActionType !== this.state.selectedActionType) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };

    handleChangePeriodType = values => {
        const previousselectedPeriodType = this.state.selectedPeriodType;
        this.setState({ selectedPeriodType: values }, () => {
            if (this.props.onValuechanged && previousselectedPeriodType !== this.state.selectedPeriodType) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };

    handleOnAttachmentChanged = attachments => {
        this.setState({ attachments: attachments }, () => {
            if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(this.getCurrentValObject());
        });
    };

    handleOnRemarksChanged = newRemarks => {
        this.setState({ remarks: newRemarks }, () => {
            if (this.props.onRemarksChanged) this.props.onRemarksChanged(this.getCurrentValObject());
        });
    };

    render() {
        const question = this.props.question || 'Unknown question';
        // console.warn('YesNoOld rerender' + Math.random());
        //const selectedOption = this.props.val ? props.val.selectedOption : undefined;
        const {
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            selectedActionType,
            selectedPeriodType,
            selectedPeriod,
            showViolationActions,
            showPeriodSelection,
            showActionType,
            actionTypeoptions,
            violationAmount,
            posibleViolatorTypes,
        } = this.state;
        const { editable, inspTypeCheckItemId, checkItemId } = this.props;
        const periodTypeOptions = ['day', 'hour'];
        //  debugger;
        const lawClausesOptions = inspectionsHelper.getViolationTypeOptions(this.props.violationTypeIds, checkItemId);

        return (
            <View style={styles.container}>
                <View style={styles.questionContainer}>
                    <Text style={styles.questionText}>{question}</Text>
                    {posibleViolatorTypes && posibleViolatorTypes.length > 0
                        ? posibleViolatorTypes.map(violatorType => (
                              <Icon
                                  key={violatorType}
                                  name={
                                      violatorType == 'plot'
                                          ? 'landscape'
                                          : violatorType == 'company'
                                          ? 'group'
                                          : violatorType == 'building'
                                          ? 'business'
                                          : 'face'
                                  }
                                  size={24}
                              />
                          ))
                        : null}
                </View>
                <View style={styles.optionsAndOtherControlsContainer}>
                    <View style={styles.optionsContainer}>
                        {this.props.isMandatory ? <IconCommunity name="flag-triangle" style={{ color: '#FF0000' }} size={24} /> : null}
                        <View style={styles.optionButtonContainer}>
                            <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('yes')} style={styles.touchWrapper}>
                                <Text
                                    style={[
                                        styles.optionButton,
                                        selectedOption === 'yes' ? [styles.optionButtonSelected, styles.optionButtonSelectedYes] : null,
                                    ]}
                                    numberOfLines={1}
                                >
                                    {strings('yes')}
                                </Text>
                            </TouchableRipple>
                        </View>
                        <View style={styles.optionButtonContainer}>
                            <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('no')} style={styles.touchWrapper}>
                                <Text
                                    style={[
                                        styles.optionButton,
                                        selectedOption === 'no' ? [styles.optionButtonSelected, styles.optionButtonSelectedNo] : null,
                                    ]}
                                    numberOfLines={1}
                                >
                                    {strings('no')}
                                </Text>
                            </TouchableRipple>
                        </View>
                        <View style={styles.optionButtonContainer}>
                            <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('na')} style={styles.touchWrapper}>
                                <Text
                                    style={[
                                        styles.optionButton,
                                        selectedOption === 'na' ? [styles.optionButtonSelected, styles.optionButtonSelectedNa] : null,
                                    ]}
                                    numberOfLines={1}
                                >
                                    {strings('notApplicable')}
                                </Text>
                            </TouchableRipple>
                        </View>
                    </View>
                    <AttachmentAndRemarks
                        editable={editable}
                        attachments={attachments}
                        remarks={remarks}
                        inspTypeCheckItemId={inspTypeCheckItemId}
                        style={styles.attachmentsAndRemarksContainer}
                        onAttachmentChanged={this.handleOnAttachmentChanged}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                </View>
                {showViolationActions ? (
                    <View style={styles.violationsActionSelectionContainer}>
                        <View style={styles.questionContainer}>
                            <LawclauseList
                                multiSelect={false}
                                editable={(lawClausesOptions || []).length == 1 ? false : editable}
                                violationTypeIds={lawClausesOptions || []}
                                selectedItems={violationTypeIds || []}
                                onValueChange={itemValue => this.handleLawClausePickerChange(itemValue, lawClausesOptions)}
                            />
                        </View>
                        <View style={styles.questionContainer}>
                            <View style={{ flex: 1, alignItems: 'flex-end', justifyContent: 'center', marginHorizontal: 10 }}>
                                {showActionType ? (
                                    <CheckListActionTypePicker
                                        actionTypeoptions={actionTypeoptions}
                                        selectedActionType={selectedActionType}
                                        violationTypeIds={violationTypeIds}
                                        editable={editable}
                                        handleChangeActions={itemValue => this.handleChangeActions(itemValue, violationTypeIds)}
                                    />
                                ) : null}
                            </View>
                            <View style={{ flex: 1, alignItems: 'flex-end', justifyContent: 'center', marginHorizontal: 10 }}>
                                {showActionType && selectedActionType == 'violations' ? (
                                    <View style={styles.typePicker}>
                                        <Text style={styles.violationAmount}>
                                            {/* {(violationAmount || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' ' + 'AED'} */}
                                            {formatCurrency(violationAmount)}
                                        </Text>
                                    </View>
                                ) : null}
                                {showPeriodSelection ? (
                                    <CheckListPeriodPicker
                                        periodTypeOptions={periodTypeOptions}
                                        selectedPeriodType={selectedPeriodType}
                                        selectedPeriod={selectedPeriod}
                                        handlePeriodNumberPickerChange={this.handlePeriodNumberPickerChange}
                                        editable={editable}
                                        handleChangePeriodType={this.handleChangePeriodType}
                                    />
                                ) : null}
                            </View>
                        </View>
                    </View>
                ) : null}
            </View>
        );
    }
}

export default YesNoOld;
