/* 
    taken from https://callstack.github.io/react-native-paper/list-accordion.html, 
    added support for custom render, that has more than just text title in the accordion header
*/
import React from 'react';
import color from 'color';
import { View, UIManager, LayoutAnimation } from 'react-native';
import { TouchableRipple, Text, withTheme } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

class CustomAccordion extends React.PureComponent {
    static displayName = 'CustomAccordion';

    constructor(props) {
        super(props);
        // UIManager.setLayoutAnimationEnabledExperimental &&
        //     UIManager.setLayoutAnimationEnabledExperimental(true);
    }

    state = {
        expanded: this.props.expanded || this.props.expandedAtStart === undefined ? false : this.props.expandedAtStart,
    };

    _handlePress = () => {
        this.props.onPress && this.props.onPress();

        if (this.props.expanded === undefined) {
            // Only update state of the `expanded` prop was not passed
            // If it was passed, the component will act as a controlled component
            /*
            LayoutAnimation.configureNext({
                duration: 300,
                create: {
                    property: LayoutAnimation.Properties.opacity,
                    type: LayoutAnimation.Types.spring,
                    springDamping: 1
                },
                update: {
                    property: LayoutAnimation.Properties.opacity,
                    type: LayoutAnimation.Types.spring,
                    springDamping: 1
                },
                delete: {
                    property: LayoutAnimation.Properties.opacity,
                    type: LayoutAnimation.Types.spring,
                    springDamping: 1
                }
            });
            */
            this.setState(state => ({
                expanded: !state.expanded,
            }));
        }
    };

    render() {
        // console.log(`CustomAccordion.render(${this.props.title}) -->`);
        // console.log(this.props);
        const { renderHeader, ...restParams } = this.props;
        const { left, title, description, children, theme, style } = restParams; //this.props;
        const titleColor = color(theme.colors.text)
            .alpha(0.87)
            .rgb()
            .string();
        const descriptionColor = color(theme.colors.text)
            .alpha(0.54)
            .rgb()
            .string();

        const expanded = this.props.expanded !== undefined ? this.props.expanded : this.state.expanded;
        return (
            <View>
                <TouchableRipple
                    style={[styles.container, style]}
                    onPress={this._handlePress}
                    accessibilityTraits="button"
                    accessibilityComponentType="button"
                    accessibilityRole="button"
                >
                    <View style={styles.row} pointerEvents="none">
                        {left
                            ? left({
                                  color: expanded ? theme.colors.primary : descriptionColor,
                              })
                            : null}

                        {//if renderHeader function is provided, pass it all the params (except itself) and let it render the header
                        renderHeader && <View style={{ flex: 1 }}>{renderHeader({ expanded, ...restParams })}</View>}
                        {//if there is no renderHeader, show the title and description by default
                        !renderHeader && (
                            <View style={[styles.item, styles.content]}>
                                <Text
                                    numberOfLines={1}
                                    style={[
                                        styles.title,
                                        {
                                            color: expanded ? theme.colors.primary : titleColor,
                                        },
                                    ]}
                                >
                                    {title}
                                </Text>
                                {description && (
                                    <Text
                                        numberOfLines={2}
                                        style={[
                                            styles.description,
                                            {
                                                color: descriptionColor,
                                            },
                                        ]}
                                    >
                                        {description}
                                    </Text>
                                )}
                            </View>
                        )}
                        <View style={[styles.item, description && styles.multiline]}>
                            <Icon name={expanded ? 'keyboard-arrow-up' : 'keyboard-arrow-down'} size={24} color={titleColor} />
                        </View>
                    </View>
                </TouchableRipple>
                <View style={{ display: expanded ? 'flex' : 'flex', opacity: expanded ? 1 : 0 }}>{this.props.children}</View>
                {/*expanded
                    ? React.Children.map(children, child => {
                          if (
                              left &&
                              React.isValidElement(child) &&
                              !child.props.left &&
                              !child.props.right
                          ) {
                              return React.cloneElement(child, {
                                  style: [styles.child, child.props.style]
                              });
                          }

                          return child;
                      })
                    : null
                    */}
            </View>
        );
    }
}

export default withTheme(CustomAccordion);
