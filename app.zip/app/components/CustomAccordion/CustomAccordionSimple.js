import React from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

class CustomAccordion extends React.PureComponent {
    static displayName = 'CustomAccordion';

    constructor(props) {
        super(props);
    }

    state = {
        expanded: this.props.expanded || this.props.expandedAtStart === undefined ? false : this.props.expandedAtStart,
    };

    _handlePress = () => {
        this.props.onPress && this.props.onPress();

        if (this.props.expanded === undefined) {
            // Only update state of the `expanded` prop was not passed
            // If it was passed, the component will act as a controlled component
            this.setState(state => ({
                expanded: !state.expanded,
            }));
        }
    };

    render() {
        const { renderHeaderTitle, ...restParams } = this.props;
        const { titleStyles, title, description, children, style } = restParams;
        const expanded = this.props.expanded !== undefined ? this.props.expanded : this.state.expanded;
        const TheTitleComponent = renderHeaderTitle;
        return (
            <View>
                <TouchableOpacity style={[styles.container, style]} onPress={this._handlePress}>
                    <View style={styles.row} pointerEvents="auto">
                        {!!renderHeaderTitle && renderHeaderTitle({ expanded, ...restParams })}
                        {!renderHeaderTitle && (
                            <View style={[styles.item, styles.content]}>
                                <Text numberOfLines={1} style={[styles.title, titleStyles ? titleStyles : null]}>
                                    {title}
                                </Text>
                            </View>
                        )}
                        <View style={[styles.item, description && styles.multiline]}>
                            <Icon name={expanded ? 'keyboard-arrow-up' : 'keyboard-arrow-down'} size={24} />
                        </View>
                    </View>
                </TouchableOpacity>
                <View style={{ display: expanded ? 'flex' : 'none', opacity: expanded ? 1 : 0 }}>{children}</View>
            </View>
        );
    }
}

export default CustomAccordion;
