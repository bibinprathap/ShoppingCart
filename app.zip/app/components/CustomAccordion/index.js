import styles from './styles';
//import CustomAccordion from './CustomAccordion';
import CustomAccordion from './CustomAccordionSimple';

export { styles, CustomAccordion };
