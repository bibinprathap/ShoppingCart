import React, { Component } from 'react';
import { ExpandableCalendar, CalendarProvider } from 'react-native-calendars';
import EStyleSheet from 'react-native-extended-stylesheet';
import moment from 'moment';
import { SearchResultListView } from 'app/components';
import { store } from 'app/config/store';
import { inspectionsTaskCalLoad, inspectionsCalLoad } from 'app/actions/generic';

class CalendarView extends Component {
    constructor(props) {
        super(props);
        this.state = { currentDay: moment().format('YYYY-MM-DD') };
    }
    componentDidMount() {
        const { currentDay } = this.state;
        this.onLoadItems(currentDay, (reset = true), (countOnly = true));
        this.onLoadDateItems(currentDay);
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.sourceType != prevProps.sourceType && this.props.calendarViewData.dateSelected === undefined) {
            const { currentDay } = this.state;
            this.onLoadItems(currentDay, (reset = true), (countOnly = true));
            this.onLoadDateItems(currentDay);
        }
    }

    onDateChanged = async day => {
        const { calendarViewData } = this.props;
        const today = moment().format('YYYY-MM-DD');
        const changedDate = moment(day).format('YYYY-MM-DD');
        const changeDateMonth = moment(changedDate).format('YYYY-MM');
        const PrevDate = moment(calendarViewData.dateSelected).format('YYYY-MM-DD');
        const PrevDateMonth = moment(calendarViewData.dateSelected).format('YYYY-MM');
        let currentDay = this.state.currentDay;
        if (changedDate !== PrevDate) {
            if (changeDateMonth === PrevDateMonth) {
                this.onLoadDateItems(day);
            } else {
                if (changedDate === today) {
                    currentDay = today;
                } else {
                    if (PrevDate < changedDate) {
                        currentDay = moment(changedDate).startOf('month');
                    } else {
                        currentDay = moment(changedDate).endOf('month');
                    }
                }
                this.onLoadItems(changedDate, (reset = true), (countOnly = true));
                this.onLoadDateItems(currentDay);
            }
        }
    };

    onLoadItems = async (currentDay, reset, countOnly) => {
        const { sourceType } = this.props;

        const monthStartDate = moment(currentDay).startOf('month');
        const monthEndDate = moment(currentDay).endOf('month');

        startDate = moment(monthStartDate)
            .startOf('day')
            .format('YYYY-MM-DD HH:mm:ss');
        endDate = moment(monthEndDate)
            .endOf('day')
            .format('YYYY-MM-DD HH:mm:ss');

        try {
            const payload = {
                startDate: startDate,
                endDate: endDate,
                countOnly: countOnly,
                groupType: countOnly ? 1 : undefined,
                reset: reset,
            };

            if (sourceType === 'history') {
                store.dispatch(inspectionsCalLoad(payload));
            } else if (sourceType === 'tasks') {
                store.dispatch(inspectionsTaskCalLoad(payload));
            }
        } catch (error) {}
    };

    onLoadDateItems = async currentDay => {
        const { sourceType } = this.props;
        currentDay = currentDay.dateString === undefined ? currentDay : currentDay.dateString;
        startDate = moment(currentDay)
            .startOf('day')
            .format('YYYY-MM-DD HH:mm:ss');
        endDate = moment(currentDay)
            .endOf('day')
            .format('YYYY-MM-DD HH:mm:ss');

        try {
            const payload = {
                startDate: startDate,
                endDate: endDate,
                countOnly: false,
                reset: false,
            };

            if (sourceType === 'history') {
                store.dispatch(inspectionsCalLoad(payload));
            } else if (sourceType === 'tasks') {
                store.dispatch(inspectionsTaskCalLoad(payload));
            }
        } catch (error) {}
    };

    onLoadNextPage = () => {
        const { calendarViewData, loading } = this.props;
        if (calendarViewData && !loading) {
            const { pageSize, pageNumber, totalCount } = calendarViewData;
            const maxNumOfPages = parseInt(totalCount / pageSize);
            if (pageNumber < maxNumOfPages) {
                this.onLoadDateItems(calendarViewData.dateSelected, { pageNumber: pageNumber + 1 });
            }
        }
    };

    onRefresh = () => {
        const { calendarViewData } = this.props;
        this.onLoadDateItems(calendarViewData.dateSelected);
    };

    render() {
        const { calendarViewData, sourceType, onItemPress } = this.props;
        const currentDate = moment(calendarViewData.dateSelected).format('YYYY-MM-DD');
        const nextDays = [];
        const marked = {};

        const hasMarkedItems = calendarViewData && calendarViewData.items && calendarViewData.items.length > 0;

        if (hasMarkedItems) {
            calendarViewData.items.forEach(key => {
                nextDays.push(moment(key.type).format('YYYY-MM-DD'));
            });

            nextDays.forEach(date => {
                marked[date] = { marked: true };
            });
        }
        return (
            <CalendarProvider
                style={styles.calendar}
                date={currentDate}
                onDateChanged={this.onDateChanged}
                theme={{ todayButtonTextColor: '#349EFB' }}
                showTodayButton
                disabledOpacity={0.6}
            >
                <ExpandableCalendar
                    markedDates={marked}
                    calendarWidth={540}
                    hideExtraDays
                    pastScrollRange={12}
                    futureScrollRange={12}
                    calendarHeight={380}
                    theme={{
                        textDayFontSize: 14,
                        textMonthFontSize: 16,
                        textDayHeaderFontSize: 14,
                        dotColor: '#665EFF',
                        selectedDotColor: '#FFFFFF',
                        disabledDotColor: '#f6eeee',
                        dotStyle: { marginTop: 2, width: 7, height: 4 },
                        'stylesheet.expandable.main': {
                            knob: {
                                width: 60,
                                height: 4,
                                borderRadius: 3,
                                backgroundColor: '#349EFB',
                            },
                        },
                    }}
                />
                <SearchResultListView
                    sourceType={sourceType}
                    items={calendarViewData.selectedDateData}
                    loading={calendarViewData.loading}
                    onItemPress={onItemPress}
                    onLoadNextPage={this.onLoadNextPage}
                    onRefresh={this.onRefresh}
                    refreshing={calendarViewData.loading}
                />
            </CalendarProvider>
        );
    }
}

export default CalendarView;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
    },

    itemsOuterContainer: {
        flex: 2,
        backgroundColor: '$primaryWhite',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    itemSmallText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },

    noItemsContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },
    errorContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },
    errorText: {
        color: '$primaryErrorTextColor',
        textAlign: 'center',
    },
    calendar: {
        borderTopWidth: 2,
        paddingTop: 1,
        borderBottomWidth: 2,
        borderColor: '#eee',
    },
});
