import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings } from 'app/config/i18n/i18n';
import { withNavigation } from 'react-navigation';
import { connect } from 'react-redux';
import { CalendarView, TabbedListView, TasksMapView, Icon } from 'app/components';
import moment from 'moment';
import {
    inspectionsTabLoad,
    inspectionsCalLoad,
    inspectionsTaskCalLoad,
    inspectionsTabChanged,
    tasksTabLoad,
    tasksTabChanged,
    tasksSetPendingRefresh,
} from 'app/actions/generic';

import { inspectionsHelper, tasksHelper } from 'app/api/helperServices';
import { TaskDetailsDialog } from 'app/screens';

class DashboardView extends Component {
    state = {
        viewMode: 'list', // Todo: take it from general reducer
        showDialog: false,
    };

    componentDidUpdate = () => {
        const { tabbedListViewData, selectedTab } = this.props;
        const selectedTabData = tabbedListViewData[selectedTab];
        const currentDateTime = moment();
        const lastRefreshed = selectedTabData.lastRefreshed !== undefined ? moment(selectedTabData.lastRefreshed) : currentDateTime;
        const timeDiff = currentDateTime.diff(lastRefreshed, 'minutes');
        if (timeDiff > 5 && selectedTabData.loading !== true) {
            this.loadTabData({ reset: true });
        }
    };

    handleViewModePress = () => {
        const newViewMode = this.state.viewMode === 'calendar' ? 'list' : 'calendar';
        this.setState({ viewMode: newViewMode });
    };

    handleRefreshPress = () => {
        const { viewMode } = this.state;
        const { calendarViewData } = this.props;
        if (viewMode === 'list') {
            this.loadTabData({ reset: true });
        } else {
            this.resetCalendarData({
                startDate: calendarViewData.startDate,
                endDate: calendarViewData.endDate,
                reset: true,
                pageNumber: 0,
                groupType: 1,
                countOnly: true,
            });
            const startDate = moment(calendarViewData.dateSelected)
                .startOf('day')
                .format('YYYY-MM-DD HH:mm:ss');
            const endDate = moment(calendarViewData.dateSelected)
                .endOf('day')
                .format('YYYY-MM-DD HH:mm:ss');
            this.resetCalendarData({ startDate: startDate, endDate: endDate, reset: false, pageNumber: 0 });
        }
    };

    handleSortPress = () => {
        const { viewMode, sortOrder } = this.state;
        if (viewMode === 'list') {
            const newSortOrder = sortOrder === 'asc' ? 'dsc' : 'asc';
            this.setState({ sortOrder: newSortOrder }, () => {
                this.loadTabData(true);
            });
        } else {
            //Do nothing, sorting isn't available in calendar
        }
    };

    getCurrentSortOrder = () => {};

    handleOnSortOrderChanged = () => {
        this.loadTabData({ reset: true, switchSortOrder: true });
    };

    handleOnSelectedTabChanged = selectedTab => {
        const { dispatch, sourceType } = this.props;
        if (sourceType === 'history') {
            dispatch(inspectionsTabChanged({ tabKey: selectedTab }));
        } else if (sourceType === 'tasks') {
            dispatch(tasksTabChanged({ tabKey: selectedTab }));
        }
    };

    loadTabData = ({ reset = false, switchSortOrder = false, paginationParams = {} } = {}) => {
        const { dispatch, sourceType, tabbedListViewData, selectedTab } = this.props;
        const tabData = tabbedListViewData[selectedTab];
        const { startDate, endDate, fixedFilter } = tabData;
        const isOrderByDesc = switchSortOrder ? !tabData.isOrderByDesc : tabData.isOrderByDesc;
        if (!tabData) {
        } else {
            const payload = { tabKey: selectedTab, startDate, endDate, fixedFilter, reset, isOrderByDesc, ...paginationParams };
            if (sourceType === 'history') {
                dispatch(inspectionsTabLoad(payload));
            } else if (sourceType === 'tasks') {
                dispatch(tasksTabLoad(payload));
            }
        }
    };

    resetCalendarData = (params = {}) => {
        const { dispatch, sourceType } = this.props;
        const payload = {
            ...params,
        };

        if (sourceType === 'history') {
            dispatch(inspectionsCalLoad(payload));
        } else if (sourceType === 'tasks') {
            dispatch(inspectionsTaskCalLoad(payload));
        }
    };

    handleDialogOnRequestClose = () => {
        this.setState({ showDialog: !this.state.showDialog });
    };

    handleMapPress = () => {
        this.setState({ showDialog: !this.state.showDialog });
    };
    handleItemOnPress = item => {
        const { sourceType, navigation } = this.props;
        if (sourceType === 'history') {
            const { inspectionTypeDetail = {} } = item;
            const inspectionParams = {
                workflowInstanceId: item.workflowInstanceId,
                applicationNumber: item.applicationNumber,
                workflowApplicationNumber: item.workflowApplicationNumber,
                inspectionTypeId: item.inspectionTypeId,
                workflowConst: inspectionTypeDetail.workflowConst,
            };

            inspectionsHelper.showInspection({ navigation, inspectionParams });
        } else if (sourceType === 'tasks') {
            tasksHelper.selectTask(item, navigation);
        }
    };

    onLoadNextPage = () => {
        const { tabbedListViewData, selectedTab } = this.props;
        const dataObject = tabbedListViewData[selectedTab];
        if (dataObject && !dataObject.loading) {
            const { pageSize, pageNumber, totalCount } = dataObject;
            const maxNumOfPages = parseInt(totalCount / pageSize);
            if (pageNumber < maxNumOfPages) {
                this.loadTabData({ paginationParams: { pageNumber: pageNumber + 1 } });
            }
        }
    };

    onRefresh = () => {
        this.loadTabData({ reset: true });
    };

    render() {
        const forceRender = Math.random();
        const { sourceType, tabbedListViewData, selectedTab, calendarViewData } = this.props;
        const { viewMode } = this.state;
        const viewModeIcon = viewMode === 'list' ? 'calendar' : 'format-list-bulleted';
        const viewModeTitle = viewMode === 'list' ? 'calendarView' : 'listView';

        const taskMapData = tabbedListViewData[selectedTab].items;

        return (
            <View style={{ flex: 1 }}>
                <View style={styles.iconsRowContainer}>
                    <TouchableOpacity style={styles.iconContainer} onPress={this.handleViewModePress}>
                        <Text style={{ flex: 1 }}>{strings(viewModeTitle)}</Text>
                        <Icon type="MaterialCommunityIcons" name={viewModeIcon} size={24} style={styles.icon} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.iconContainer} onPress={this.handleRefreshPress}>
                        <Text>{strings('refresh')}</Text>
                        <Icon type="MaterialCommunityIcons" name={'refresh'} size={24} style={styles.icon} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.iconContainer} onPress={this.handleMapPress}>
                        <Text>{strings('map')}</Text>
                        <Icon type="MaterialCommunityIcons" name={'map'} size={24} style={styles.icon} />
                    </TouchableOpacity>
                </View>
                {this.state.showDialog ? (
                    <TasksMapView
                        isShowing={this.state.showDialog}
                        onRequestClose={this.handleDialogOnRequestClose}
                        tasksData={taskMapData}
                        sourceType={sourceType}
                    />
                ) : null}

                {viewMode === 'calendar' && (
                    <CalendarView sourceType={sourceType} calendarViewData={calendarViewData} onItemPress={this.handleItemOnPress} />
                )}
                <TaskDetailsDialog />
                {viewMode === 'list' && (
                    <TabbedListView
                        sourceType={sourceType}
                        tabbedListViewData={tabbedListViewData}
                        selectedTab={selectedTab}
                        loadTabData={this.loadTabData}
                        onItemPress={this.handleItemOnPress}
                        onSelectedTabChanged={this.handleOnSelectedTabChanged}
                        onSortOrderChanged={this.handleOnSortOrderChanged}
                        forceRender={forceRender}
                        onLoadNextPage={this.onLoadNextPage}
                        onRefresh={this.onRefresh}
                        refreshing={tabbedListViewData[selectedTab].loading}
                    />
                )}
            </View>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    const tabsObj = ownProps.sourceType === 'history' ? state.generic.inspectionsTabs : state.generic.tasksTabs;
    const calendarObj = ownProps.sourceType === 'history' ? state.generic.inspectionsCalendar : state.generic.tasksCalendar;

    return {
        tabbedListViewData: tabsObj.tabs,
        selectedTab: tabsObj.selectedTab,
        calendarViewData: calendarObj,
    };
};

export default withNavigation(connect(mapStateToProps)(DashboardView));

const styles = EStyleSheet.create({
    iconsRowContainer: {
        flexDirection: 'row',
        marginVertical: 10,
        justifyContent: 'space-around',
    },
    iconContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: '$primaryWhite',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
        margin: 5,
        paddingVertical: 10,
        paddingHorizontal: 5,
    },
    icon: {},
});
