import React, { Component } from 'react';
import { View, TouchableOpacity, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { Icon, SearchResultListView } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';

class TabbedListView extends Component {
    constructor(props) {
        super(props);
        let { selectedTab } = props;

        if (typeof selectedTab === 'undefined') {
            selectedTab = this.getFirstTabKey();
            this.handleOnSelectedTabChanged(selectedTab);
        }
    }

    getFirstTabKey = () => {
        let { tabbedListViewData } = this.props;
        const sortedkeys = this.getSortedTabKeys(tabbedListViewData);
        const firstKey = sortedkeys.length > 0 ? sortedkeys[0] : undefined;
        return firstKey;
    };

    getSortedTabKeys = tabbedListViewData => {
        if (tabbedListViewData) {
            const keys = [];
            Object.keys(tabbedListViewData).map(key => {
                if (tabbedListViewData.hasOwnProperty(key)) {
                    keys.push({ key, order: tabbedListViewData[key].order || 0 });
                }
            });

            const sortedKeys = _.sortBy(keys, function(item) {
                return item.order;
            });

            return sortedKeys.map(item => item.key);
        } else return [];
    };

    componentDidMount = () => {
        this.checkSelectedTabData(true);
    };

    componentDidUpdate = () => {
        this.checkSelectedTabData();
    };

    handleOnSelectedTabChanged = selectedTab => {
        const { onSelectedTabChanged } = this.props;
        if (typeof onSelectedTabChanged === 'function') onSelectedTabChanged(selectedTab);
    };
    checkSelectedTabData = (forceLoad = false) => {
        const { tabbedListViewData, loadTabData, setPendingRefresh } = this.props;
        if (forceLoad) {
            loadTabData({ reset: true });
            return;
        }
        let { selectedTab } = this.props;

        const selectedTabData = tabbedListViewData[selectedTab];

        if (typeof selectedTabData === 'undefined') {
            //previous selected tab may not be valid when source is changed, having different tabs
            selectedTab = this.getFirstTabKey();
            if (selectedTab) {
                this.handleOnSelectedTabChanged(selectedTab);
            }
        } else {
            if (
                selectedTabData.hasPendingRefresh == true ||
                (typeof selectedTabData.items === 'undefined' && selectedTabData.loading !== true && !selectedTabData.error)
            ) {
                if (typeof loadTabData === 'function') {
                    loadTabData({ reset: true });
                }
            } else {
                return; //nothing to do, there is no tab
            }
        }
    };

    renderHeaderItem = (key, item, index) => {
        const { tabbedListViewData = {}, selectedTab, onSortOrderChanged } = this.props;
        const selected = key === selectedTab;
        const selectedTabData = tabbedListViewData[key];
        const { totalCount = 0, items, isOrderByDesc } = selectedTabData || {};
        const headerItemContainerStyles = [styles.headerItemContainer, selected ? styles.headerItemContainerSelected : null];
        const headerItemTextStyles = [styles.headerItemText, selected ? styles.headerItemTextSelected : null];
        const headerItemCountTextStyles = [styles.headerItemTextSmall, selected ? styles.headerItemTextSelected : null];
        const sortOrderIcon = !isOrderByDesc ? 'sort-ascending' : 'sort-descending';
        const sortOrderIconColor = selected ? styles.headerItemTextSelected.color : styles.headerItemText.color;

        handleHeaderItemPress = () => {
            if (selectedTab === key) {
                if (typeof onSortOrderChanged === 'function') onSortOrderChanged();
            } else {
                this.handleOnSelectedTabChanged(key);
            }
        };
        const formattedCount = items ? `(${totalCount})` : '(?)';
        return (
            <View style={headerItemContainerStyles} key={`${key}_${index}`}>
                <TouchableOpacity onPress={handleHeaderItemPress} style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                    <View style={{ flex: 1, flexDirection: 'row', alignItems: 'flex-start' }}>
                        <Text style={headerItemTextStyles}>{strings(key)}</Text>
                        <Text style={headerItemCountTextStyles}>{formattedCount}</Text>
                    </View>
                    <Icon type="MaterialCommunityIcons" name={sortOrderIcon} size={18} color={sortOrderIconColor} />
                </TouchableOpacity>
            </View>
        );
    };

    render() {
        const { sourceType, tabbedListViewData = {}, selectedTab, onItemPress, forceRender, onLoadNextPage, onRefresh, refreshing } = this.props;
        if (typeof selectedTab === 'undefined') return;
        const selectedTabData = tabbedListViewData[selectedTab];
        const { items, loading } = selectedTabData;
        const headers = [];
        const sortedKeys = this.getSortedTabKeys(tabbedListViewData);
        if (sortedKeys.length > 0) {
            for (var i = 0; i < sortedKeys.length; i++) {
                const key = sortedKeys[i];
                headers.push(this.renderHeaderItem(key, tabbedListViewData[key], i));
            }
        }
        let hasError = !!selectedTabData.error;

        return (
            <View style={styles.container}>
                <View style={styles.headersContainer}>{headers}</View>
                {hasError && (
                    <View style={styles.errorContainer}>
                        <Text style={[styles.itemSmallText, styles.errorText]}>{selectedTabData.error}</Text>
                    </View>
                )}
                {!hasError && (
                    <SearchResultListView
                        sourceType={sourceType}
                        items={items}
                        loading={loading}
                        onItemPress={onItemPress}
                        onLoadNextPage={onLoadNextPage}
                        onRefresh={onRefresh}
                        refreshing={refreshing}
                    />
                )}
            </View>
        );
    }
}

export default TabbedListView;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
    },
    headersContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 40,
        minHeight: 40,
        paddingBottom: 1,
    },
    errorContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },
    itemSmallText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    errorText: {
        color: '$primaryErrorTextColor',
        textAlign: 'center',
    },
    headerItemContainer: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        paddingHorizontal: 5,
    },
    headerItemContainerSelected: {
        borderBottomColor: '$primaryIndicatorColor',
        borderBottomWidth: '$primaryBorderThick',
    },
    headerItemText: {
        flex: 1,
        color: '$primaryMediumTextColor',
        fontSize: I18nManager.isRTL ? '$primaryTextXS' : '$primaryTextSM',
        textAlignVertical: 'center',
    },
    headerItemTextSmall: {
        color: '$primaryMediumTextColor',
        fontSize: '$primaryTextXXS',
        textAlignVertical: 'center',
        marginTop: 5,
    },

    headerItemTextSelected: {
        color: '$primarySelectedTextColor',
    },
});
