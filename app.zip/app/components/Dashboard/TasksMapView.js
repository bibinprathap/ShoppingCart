import React, { Component } from 'react';
import { View } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { ADMGISMapView, HeaderGeneric, Modal } from 'app/components';
import { getIconUnicode } from 'app/api/helperServices/utils';
import AppApi from 'app/api/real';
import { shallowEqual } from 'app/api/helperServices';
const api = new AppApi();
export default class TasksMapView extends Component {
    handleOnRequestClose = () => {

        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    render() {
        const { isShowing, tasksData, sourceType } = this.props;


        if (!isShowing) return null;
        else {
            let coordsData = [];

            if (typeof tasksData !== 'undefined') {
                tasksData.map(item => {
                    const icon = sourceType == 'tasks' ? item.icon : item.inspectionTypeDetail.icon;
                    if (typeof item.location !== 'undefined' && typeof icon !== 'undefined') {
                        const code = getIconUnicode(
                            sourceType == 'tasks' ? item.icon.type : item.inspectionTypeDetail.icon.type,
                            sourceType == 'tasks' ? item.icon.name : item.inspectionTypeDetail.icon.name
                        );
                        const newTaskData = {
                            referenceId: sourceType == 'tasks' ? item.taskId.toString() : item.applicationNumber.toString(),
                            latitude: item.location.coords.latitude,
                            longitude: item.location.coords.longitude,
                            graphicId: sourceType == 'tasks' ? item.icon.name : item.inspectionTypeDetail.icon.name,
                            graphicType: sourceType == 'tasks' ? item.icon.type : item.inspectionTypeDetail.icon.type,
                            graphicUnicode: code,
                            rotation: 0,
                            attributes: {
                                inspectionStatus: sourceType == 'tasks' ? item.status : item.inspectionStatusE,
                                title: item.inspectionTypeDetail.titleE,
                                serviceDesc: item.inspectionTypeDetail.serviceDescE,
                            },
                        };
                        if (item.applicationNumber) newTaskData.attributes.appNumber = item.applicationNumber;
                        if (item.taskId) newTaskData.attributes.taskId = item.taskId.toString();
                        coordsData.push(newTaskData);
                    }
                });
            }
            const taskMapData = {
                referenceId: 'MapRoutes',
                points: coordsData,
            };
            return (
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric backAction={this.handleOnRequestClose} title={strings('tasksMapView')} />
                    <View style={{ height: '100%', width: '100%' }}>
                        <ADMGISMapView
                            //coords={coords}
                            // polygonsData={JSON.stringify(this.state.inspectorDesignatedSectors)}
                            //placeMarks={placeMarkData}
                            routeData={taskMapData}
                            showMenu={true}
                        />
                    </View>
                </Modal>
            );
        }
    }
}
