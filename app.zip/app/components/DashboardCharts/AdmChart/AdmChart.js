import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Dialog, Portal } from 'react-native-paper';
import AppApi from 'app/api/real';
import PieGraph from 'app/components/DashboardCharts/PieGraph/PieGraph';
import BarGraph from 'app/components/DashboardCharts/BarGraph/BarGraph';
import LineGraph from 'app/components/DashboardCharts/LineGraph/LineGraph';

const api = new AppApi();

export default class AdmChart extends Component {
    state = {};
    componentDidMount = async () => {
        this.loadChartsData();
    };
    loadChartsData = async () => {
        this.setState({ loading: true });
        try {
            const result = await api.getDashboardCharts();
            this.setState({ loading: false, dashboardChartsData: result, count: result.length });
        } catch (err) {
            this.setState({ loading: false, error: err });
        }
    };

    _showDialog = item => this.setState({ visible: true, chartType: item });
    _hideDialog = () => this.setState({ visible: false });

    render = () => {
        const { dashboardChartsData, loading, count } = this.state;
        //  console.log('AdmChat... dashboardChartsData: ', dashboardChartsData);
        return (
            <View style={styles.chartContainer}>
                {dashboardChartsData ? (
                    //added dummy hardcoded keys just to suppress warnings for now
                    <View style={styles.chartBox} key={1}>
                        <TouchableOpacity onPress={() => this._showDialog('pie')}>
                            <PieGraph chartData={dashboardChartsData.filter(d => d.type == 'pie')} chartVal={false} />
                        </TouchableOpacity>
                    </View>
                ) : null}

                {dashboardChartsData ? (
                    <View style={styles.chartBox} key={2}>
                        <TouchableOpacity onPress={() => this._showDialog('line')}>
                            <LineGraph chartData={dashboardChartsData.filter(d => d.type == 'line')} chartVal={false} />
                        </TouchableOpacity>
                    </View>
                ) : null}
                {dashboardChartsData ? (
                    <View style={styles.chartBox} key={3}>
                        <TouchableOpacity onPress={() => this._showDialog('bar')}>
                            <BarGraph chartData={dashboardChartsData.filter(d => d.type == 'bar')} chartVal={false} />
                        </TouchableOpacity>
                    </View>
                ) : null}

                <Portal>
                    <Dialog visible={this.state.visible} onDismiss={this._hideDialog}>
                        <Dialog.Content style={styles.Dialog} boxShadow="none">
                            {dashboardChartsData ? (
                                <View style={styles.chartBox}>
                                    {this.state.chartType == 'pie' ? (
                                        <PieGraph chartData={dashboardChartsData.filter(d => d.type == this.state.chartType)} chartVal={true} />
                                    ) : this.state.chartType == 'bar' ? (
                                        <BarGraph chartData={dashboardChartsData.filter(d => d.type == this.state.chartType)} chartVal={true} />
                                    ) : this.state.chartType == 'line' ? (
                                        <LineGraph chartData={dashboardChartsData.filter(d => d.type == this.state.chartType)} chartVal={true} />
                                    ) : null}
                                </View>
                            ) : null}
                        </Dialog.Content>
                    </Dialog>
                </Portal>
            </View>

            /*
                        check if there is an error, show message
                        */
        );
    };
}

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        //flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',

        width: '$sideNavWidth',
        minWidth: '$sideNavWidth',
        maxWidth: '$sideNavWidth',

        //minWidth: 120, width: '15%', height: '100%',
    },
    dashboardNavContainer: {
        //flex: 2,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',

        width: '$dashboardNavWidth',
        minWidth: '$dashboardNavWidth',
        maxWidth: '$dashboardNavWidth',

        //minWidth: 250, width: '30%', height: '100%',
    },
    contentsScrollContainer: {
        flex: 1,
        // width: '$mainContentWidth',
        // minWidth: '$mainContentWidth',
        // maxWidth: '$mainContentWidth',

        marginVertical: 5,
        marginHorizontal: 5,
        //padding: 5,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
    },
    contentsRightContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        borderColor: '$primaryBorderColor',
    },
    contentsRightContainer1: {
        flex: 1,
        margin: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    contentsRightContainer2: {
        flex: 3,
        margin: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
        padding: 5,
    },

    chartBox: {
        flex: 2,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
    Dialog: {
        backgroundColor: '$primaryWhite',
        borderColor: '$primaryBorderColor',
        marginTop: 20,
        height: 700,
        justifyContent: 'center',
    },
});
