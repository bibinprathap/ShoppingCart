import React, { Component } from 'react';
import { View, TouchableOpacity, AsyncStorage, Text, ActivityIndicator } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Dialog, Portal } from 'react-native-paper';
import AppApi from 'app/api/real';
import PieGraph from 'app/components/DashboardCharts/PieGraph/PieGraph';
import BarGraph from 'app/components/DashboardCharts/BarGraph/BarGraph';
import LineGraph from 'app/components/DashboardCharts/LineGraph/LineGraph';

const api = new AppApi();

export default class AdmChart extends Component {
    _isMounted = false;

    state = {};
    componentDidMount = async () => {
        this._isMounted = true;
        this.setState({ loading: true });
        try {
            const result = await api.getDashboardCharts();
            if (this._isMounted) {
                this.setState({ loading: false, dashboardChartsData: result, count: result.length });
                await AsyncStorage.setItem('@MySuperStore:key', JSON.stringify(result));
            }
        } catch (err) {
            this.setState({ loading: false, error: err });
        }
    };

    componentWillUnmount() {
        this._isMounted = false;
    }

    _showDialog = (item, data) => this.setState({ visible: true, chartType: item, chartData: data });
    _hideDialog = () => this.setState({ visible: false });

    renderChartContent = () => {
        var myloop = [];
        var { dashboardChartsData } = this.state;
        for (let i = 0; i < this.state.count; i++) {
            var getChartName = this.state.dashboardChartsData[i].type;
            myloop.push(
                <View style={styles.chartBox} key={i}>
                    {
                        <View>
                            {getChartName == 'pie' ? (
                                <TouchableOpacity onPress={() => this._showDialog('pie', dashboardChartsData[i])}>
                                    <PieGraph chartData={dashboardChartsData[i]} chartVal={false} />
                                </TouchableOpacity>
                            ) : getChartName == 'bar' ? (
                                <TouchableOpacity onPress={() => this._showDialog('bar', dashboardChartsData[i])}>
                                    <BarGraph chartData={dashboardChartsData[i]} chartVal={false} />
                                </TouchableOpacity>
                            ) : (
                                <TouchableOpacity onPress={() => this._showDialog('line', dashboardChartsData[i])}>
                                    <LineGraph chartData={dashboardChartsData[i]} chartVal={false} />
                                </TouchableOpacity>
                            )}
                        </View>
                    }
                </View>
            );
        }
        return myloop;
    };
    render = () => {
        if (this.state.loading) {
            const themeStlye = 'dark' ? styles.containerDark : styles.containerLight;
            const spinnerStyles = [styles.container, themeStlye];
            return (
                //first stage spinner
                <View style={spinnerStyles}>
                    <Text>Loading Charts...</Text>
                    <ActivityIndicator />
                </View>
            );
        }
        return (
            <View style={styles.chartContainer}>
                {this.renderChartContent()}
                <Portal>
                    <Dialog visible={this.state.visible} onDismiss={this._hideDialog}>
                        <Dialog.Content style={styles.Dialog} boxShadow="none">
                            {this.state.chartType == 'pie' ? (
                                <PieGraph chartData={this.state.chartData} chartVal={true} />
                            ) : this.state.chartType == 'bar' ? (
                                <BarGraph chartData={this.state.chartData} chartVal={true} />
                            ) : (
                                <LineGraph chartData={this.state.chartData} chartVal={true} />
                            )}
                        </Dialog.Content>
                    </Dialog>
                </Portal>
            </View>
        );
    };
}

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
    Dialog: {
        backgroundColor: '$primaryWhite',
        borderColor: '$primaryBorderColor',
        marginTop: 20,
        height: 700,
        justifyContent: 'center',
    },
});
