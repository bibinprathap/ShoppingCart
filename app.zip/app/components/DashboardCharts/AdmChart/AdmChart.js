import React, { Component } from 'react';
import { View, TouchableOpacity, AsyncStorage, Text, ActivityIndicator, Button, Image, ImageButton } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Dialog, Portal, IconButton, Colors } from 'react-native-paper';
import AppApi from 'app/api/real';
import PieGraph from 'app/components/DashboardCharts/PieGraph/PieGraph';
import BarGraph from 'app/components/DashboardCharts/BarGraph/BarGraph';
import LineGraph from 'app/components/DashboardCharts/LineGraph/LineGraph';
import { chartSearch } from 'app/actions/generic';
import { _state, store } from 'app/config/store';
import { connect } from 'react-redux';
import images from 'app/images';

const api = new AppApi();

class AdmChart extends React.PureComponent {
    state = {
        lastRefresh: new Date().toLocaleString(),

        loading: true,
    };

    componentDidMount() {
        setInterval(() => {
            this.setState({
                loading: false,
            });
        }, 1000);
    }

    refreshChart = ChartData => {
        console.log('ChartData', this.props.dashboardChartsData[ChartData]);

        this.setState({ chartData: this.props.dashboardChartsData[ChartData], loading: true, lastRefresh: new Date().toLocaleString() });
    };

    _showDialog = (item, data) => this.setState({ visible: true, chartType: item, chartData: data });
    _hideDialog = () => this.setState({ visible: false });

    render = () => {
        const { chartData, chartSeq } = this.props;
        getChartName = chartData.type;

        if (this.state.loading) {
            const themeStlye = 'dark' ? styles.containerDark : styles.containerLight;
            const spinnerStyles = [styles.container, themeStlye];
            return (
                //first stage spinner
                <View style={spinnerStyles}>
                    <Text>Loading Charts...</Text>
                    <ActivityIndicator />
                </View>
            );
        }

        return (
            <View>
                {getChartName == 'pie' ? (
                    <View style={styles.chartBox1}>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <IconButton icon="refresh" color={Colors.blue500} size={20} onPress={() => this.refreshChart(chartSeq)} />

                            <Text style={{ flexGrow: 1, fontSize: 8, width: 200, alignContent: 'center' }}>
                                Last Refresh: {this.state.lastRefresh}
                            </Text>
                            {/* <Button onPress={() => this.refreshChart(chartSeq)} title="Refresh Chart" /> */}
                        </View>
                        <TouchableOpacity onPress={() => this._showDialog('pie', chartData[chartSeq])}>
                            <PieGraph chartData={chartData} chartVal={false} lastRefresh={this.state.lastRefresh} />
                        </TouchableOpacity>
                    </View>
                ) : getChartName == 'bar' ? (
                    <View style={styles.chartBox1}>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <IconButton icon="refresh" color={Colors.blue500} size={20} onPress={() => this.refreshChart(chartSeq)} />

                            <Text style={{ flexGrow: 1, fontSize: 8, width: 200, alignContent: 'center' }}>
                                Last Refresh: {this.state.lastRefresh}
                            </Text>
                        </View>
                        <TouchableOpacity onPress={() => this._showDialog('bar', chartData[chartSeq])}>
                            <BarGraph chartData={chartData} chartVal={false} lastRefresh={this.state.lastRefresh} />
                        </TouchableOpacity>
                    </View>
                ) : (
                    <View style={styles.chartBox1}>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}>
                            <IconButton icon="refresh" color={Colors.blue500} size={20} onPress={() => this.refreshChart(chartSeq)} />

                            <Text style={{ flexGrow: 1, fontSize: 8, width: 200, alignContent: 'center' }}>
                                Last Refresh: {this.state.lastRefresh}
                            </Text>
                        </View>
                        <TouchableOpacity onPress={() => this._showDialog('line', chartData[chartSeq])}>
                            <LineGraph chartData={chartData} chartVal={false} lastRefresh={this.state.lastRefresh} />
                        </TouchableOpacity>
                    </View>
                )}

                <Portal>
                    <Dialog visible={this.state.visible} onDismiss={this._hideDialog}>
                        <Dialog.Content style={styles.Dialog} boxShadow="none">
                            {this.state.chartType == 'pie' ? (
                                <PieGraph chartData={chartData} chartVal={true} lastRefresh={this.state.lastRefresh} />
                            ) : this.state.chartType == 'bar' ? (
                                <BarGraph chartData={chartData} chartVal={true} lastRefresh={this.state.lastRefresh} />
                            ) : (
                                <LineGraph chartData={chartData} chartVal={true} lastRefresh={this.state.lastRefresh} />
                            )}
                        </Dialog.Content>
                    </Dialog>
                </Portal>
            </View>
        );
    };
}

mapStateToProps = state => {
    return {
        dashboardChartsData: state.generic.results,
        loading: state.generic.isLoading,
    };
};

export default connect(mapStateToProps)(AdmChart);

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
    Dialog: {
        backgroundColor: '$primaryWhite',
        borderColor: '$primaryBorderColor',
        marginTop: 20,
        height: 700,
        justifyContent: 'center',
    },
});
