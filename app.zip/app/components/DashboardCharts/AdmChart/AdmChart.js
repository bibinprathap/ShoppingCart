import React from 'react';
import { View, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Dialog, Portal, IconButton, Colors } from 'react-native-paper';
import { PieChart, BarChart, LineChart } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { getColor } from 'app/api/helperServices/utils';

const getLegends = (chartData, isPie) => {
    const renderedlegends = [];
    const datasets = chartData.datasets || [];

    if (chartData.type.toLowerCase() === 'pie') {
        //for pie chart, using xAxisLabels as legents, instead of datasetName. pie chart will render only first database
        const { xAxisLabels = [] } = chartData;
        for (var labelIndex in xAxisLabels) {
            const label = xAxisLabels[labelIndex] || {};
            const { color, labelConst } = label;
            renderedlegends.push(
                <Text
                    key={`legend_${labelIndex}`}
                    style={[{ backgroundColor: color ? color : getColor(labelConst || labelIndex) }, styles.legendText]}
                >
                    {localeProperty(label, 'label')}
                </Text>
            );
        }
    } else {
        for (var datasetIndex in datasets) {
            const dataset = datasets[datasetIndex];
            const { color, datasetConst } = dataset;
            renderedlegends.push(
                <Text
                    key={`legend_${datasetIndex}`}
                    style={[{ backgroundColor: color ? color : getColor(datasetConst || datasetIndex) }, styles.legendText]}
                >
                    {localeProperty(dataset, 'dataSetName')}
                </Text>
            );
        }
    }
    return renderedlegends;
};

const chartHasData = chartData => {
    const datasets = chartData.datasets || [];
    for (var datasetIndex in datasets) {
        const dataset = datasets[datasetIndex] || {};
        const { data = [] } = dataset;
        const sum = data.reduce((total, item) => total + item, 0);
        if (sum) return true;
    }
    return false;
};

class AdmChart extends React.PureComponent {
    state = { dialogVisible: false };
    refreshChart = () => {
        const { onRefreshPressed, chartData } = this.props;
        if (typeof onRefreshPressed === 'function') onRefreshPressed(chartData.constant);
    };

    _showDialog = () => {
        const { chartData } = this.props;
        if (!chartData) return;
        chartData.xAxisLabels.length > 0 ? this.setState({ dialogVisible: true }) : null;
    };
    _hideDialog = () => this.setState({ dialogVisible: false });

    render = () => {
        const { dialogVisible } = this.state;
        const { chartData } = this.props;
        if (!chartData || !chartData.constant) {
            return null;
        }
        const { loading } = chartData;

        if (this.state.loading) {
            const themeStlye = 'dark' ? styles.containerDark : styles.containerLight;
            const spinnerStyles = [styles.container, themeStlye];
            return (
                //first stage spinner
                <View style={spinnerStyles}>
                    <Text>{strings('loadingCharts')}</Text>
                    <ActivityIndicator />
                </View>
            );
        }
        let chartComponentSmall = null;
        let chartComponentLarge = null;
        let width = 'auto';
        let hasData = chartHasData(chartData);
        const chartType = (chartData.type || '').toLowerCase();

        if (hasData) {
            switch (chartType) {
                case 'pie':
                    chartComponentSmall = <PieChart chartData={chartData} height={190} width={250} />;
                    chartComponentLarge = <PieChart chartData={chartData} height={500} width={'auto'} />;
                    break;
                case 'bar':
                    chartComponentSmall = (
                        <BarChart chartData={chartData} height={190} width={250 + 10 * chartData.xAxisLabels.length * chartData.datasets.length} />
                    );
                    chartComponentLarge = <BarChart chartData={chartData} height={500} width={'auto'} />;
                    break;
                case 'line':
                    chartComponentSmall = <LineChart chartData={chartData} height={190} width={250 + 10 * chartData.xAxisLabels.length} />;
                    chartComponentLarge = <LineChart chartData={chartData} height={500} width={'auto'} />;
                    break;
                default:
                    console.log('AdmChart render() unknwon chart type ', chartData);
                    chartComponentSmall = <Text>Unknown chart type {chartType}</Text>;
                    break;
            }
        } else {
            chartComponentSmall = (
                <View style={styles.emptyChartContainer}>
                    <Text style={styles.emptyChartName}>{localeProperty(chartData, 'name')}</Text>
                    <Text style={styles.emptyChartMessage}>{strings('noData')}</Text>
                </View>
            );
        }
        const renderedlegends = getLegends(chartData);

        return (
            <>
                <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', height: 20 }}>
                    {!loading && (
                        <>
                            <IconButton icon="refresh" color={Colors.blue500} size={20} onPress={this.refreshChart} />
                            <Text style={{ flex: 1, fontSize: 9, alignContent: 'center' }}>Last Refresh: {chartData.lastRefreshed}</Text>
                        </>
                    )}
                    {loading && (
                        <>
                            <ActivityIndicator style={{ marginStart: 5 }} />
                            <Text style={{ flex: 1, fontSize: 9, alignContent: 'center' }}>Refreshing</Text>
                        </>
                    )}
                </View>
                {!hasData && chartComponentSmall}
                {hasData && <TouchableOpacity onPress={this._showDialog}>{chartComponentSmall}</TouchableOpacity>}
                {dialogVisible && (
                    <Portal>
                        <Dialog visible={dialogVisible} onDismiss={this._hideDialog}>
                            <Dialog.Content style={styles.dialog} boxShadow="none">
                                <Text style={styles.chartHeading}>{localeProperty(chartData, 'name')}</Text>
                                {chartComponentLarge}
                                <View>
                                    <Text style={styles.lastRefresh}>Last Refresh: {chartData.lastRefreshed}</Text>
                                </View>
                                <View style={styles.legendContainer}>{renderedlegends}</View>
                            </Dialog.Content>
                        </Dialog>
                    </Portal>
                )}
            </>
        );
    };
}

export default AdmChart;

const styles = EStyleSheet.create({
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
    },

    chartBox: {
        flex: 2,
        //  width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
    dialog: {
        backgroundColor: '$primaryWhite',
        borderColor: '$primaryBorderColor',
        height: 700,
        justifyContent: 'center',
    },
    chartHeading: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    lastRefresh: {
        textAlignVertical: 'bottom',
        textAlign: 'center',
        fontSize: 10,
        fontWeight: 'bold',
        marginVertical: 10,
    },
    legendContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    legendText: {
        textAlignVertical: 'center',
        textAlign: 'center',
        color: 'white',
        maxHeight: 25,
        fontSize: 12,
        marginTop: 5,
        marginHorizontal: 5,
        paddingHorizontal: 10,
        borderRadius: 10,
    },
    emptyChartContainer: {
        flex: 1,
        paddingHorizontal: 30,
        flexDirection: 'column',
        justifyContent: 'space-evenly',
        alignContent: 'center',
    },
    emptyChartName: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: '$primaryTextXS',
    },
    emptyChartMessage: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: '$primaryTextXXXS',
    },
});
