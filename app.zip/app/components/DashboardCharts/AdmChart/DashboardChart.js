import React from 'react';
import { View, Text, ScrollView, ActivityIndicator } from 'react-native';
import { connect } from 'react-redux';
import { AdmChart } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { getchartData } from 'app/actions/generic';
import { strings } from 'app/config/i18n/i18n';

class DashboardChart extends React.PureComponent {
    componentDidMount() {
        this.interval = setInterval(() => this.props.dispatch(getchartData()), 300000);
    }

    componentWillUnmount() {
        clearInterval(this.interval);
    }

    handleOnRefreshPressed = chartConst => {
        this.props.dispatch(getchartData(chartConst));
    };

    renderChartContent = () => {
        const myloop = [];
        const { dashboardChartsData = [] } = this.props;
        if (dashboardChartsData.length == 0) return <Text style={styles.textMsg}>No charts to display.</Text>;

        for (let i = 0; i < dashboardChartsData.length; i++) {
            const data = dashboardChartsData[i];
            myloop.push(
                <View key={i} style={styles.chartBox}>
                    <AdmChart
                        style={styles.chartContainer}
                        chartData={data}
                        lastRefreshed={data.lastRefreshed}
                        onRefreshPressed={this.handleOnRefreshPressed}
                    />
                </View>
            );
        }

        return myloop;
    };

    render = () => {
        if (this.props.loading) {
            return (
                <View style={styles.loadingContainer}>
                    <Text>{strings('loadingCharts')}</Text>
                    <ActivityIndicator />
                </View>
            );
        }

        return (
            <View>
                <ScrollView horizontal={true}>{this.renderChartContent()}</ScrollView>
            </View>
        );
    };
}
mapStateToProps = state => {
    const { dashboardChart = {} } = state.generic;
    return {
        loading: dashboardChart.loading || false,
        dashboardChartsData: dashboardChart.data || [],
        lastRefreshed: dashboardChart.lastRefreshed,
        chartRefreshing: dashboardChart.chartRefreshing,
    };
};

export default connect(mapStateToProps)(DashboardChart);

const styles = EStyleSheet.create({
    loadingContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 10,
    },
    chartContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
    },

    chartBox: {
        flex: 1,
        //width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
        height: 220,
    },

    textMsg: {
        flex: 1,
        alignSelf: 'center',
        justifyContent: 'center',
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
        left: 200,
        width: 500,
    },
});
