import React from 'react';
import { View } from 'react-native';
import { connect } from 'react-redux';
import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';
import EStyleSheet from 'react-native-extended-stylesheet';
import { getchartData } from 'app/actions/generic';

class DashboardChart extends React.PureComponent {
    state = {
        lastRefresh: new Date().toLocaleString(),
    };

    componentDidMount = async () => {
        this.props.dispatch(getchartData(new Date().toLocaleString()));
    };

    renderChartContent = () => {
        const myloop = [];

        for (let i = 0; i < this.props.dashboardChartsData.length; i++) {
            myloop.push(
                <View key={i}>
                    <View style={styles.chartBox}>
                        {
                            <View>
                                <AdmChart
                                    chartData={this.props.dashboardChartsData[i]}
                                    allchartData={this.props.dashboardChartsData}
                                    chartId={i}
                                    dispatch={this.props.dispatch}
                                />
                            </View>
                        }
                    </View>
                </View>
            );
        }

        return myloop;
    };

    render = () => {
        return <View style={styles.chartContainer}>{this.renderChartContent()}</View>;
    };
}
mapStateToProps = state => {
    return {
        dashboardChartsData: state.generic.dashboardChart.results,
        lastRefresh: state.generic.dashboardChart.lastRefresh,
    };
};

export default connect(mapStateToProps)(DashboardChart);

const styles = EStyleSheet.create({
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
        height: 250,
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
});
