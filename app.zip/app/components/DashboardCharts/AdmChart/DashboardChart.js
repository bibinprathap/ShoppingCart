import React, { Component } from 'react';
import { View, Modal, ScrollView, TouchableOpacity, LayoutAnimation, Image } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Portal, Button, Provider, Dialog, TouchableHighlight } from 'react-native-paper';
import { chartSearch } from 'app/actions/generic';
import { _state, store } from 'app/config/store';
import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';
import EStyleSheet from 'react-native-extended-stylesheet';

class DashboardChart extends React.PureComponent {
    componentDidMount = async () => {
        this.props.dispatch(chartSearch());
    };

    renderChartContent = () => {
        const myloop = [];

        for (let i = 0; i < this.props.dashboardChartsData.length; i++) {
            myloop.push(
                <View key={i}>
                    <View style={styles.chartBox}>
                        {
                            <View>
                                <AdmChart
                                    chartData={this.props.dashboardChartsData[i]}
                                    loading={this.props.loading}
                                    chartSeq={i}
                                    reload={this._loadChartsData}
                                />
                            </View>
                        }
                    </View>
                </View>
            );
        }

        return myloop;
    };

    _loadChartsData = chartId => {
        this.props.dispatch(chartSearch(chartId, this.props.dashboardChartsData));
    };

    render = () => {
        return <View style={styles.chartContainer}>{this.renderChartContent()}</View>;
    };
}
mapStateToProps = state => {
    return {
        dashboardChartsData: state.generic.dashboardChart.results,
        currentversion: new Date(),
        loading: state.generic.dashboardChart.isLoading,
    };
};

export default connect(mapStateToProps)(DashboardChart);

const styles = EStyleSheet.create({
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
        height: 250,
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
});
