import React from 'react';
import { BarChart, YAxis, XAxis, Grid } from 'react-native-svg-charts';
import { View, Text } from 'react-native';
import { getBarChartData } from 'app/api/helperServices/utils';

class ADMBarChart extends React.PureComponent {
    render() {
        const { chartData, height, width } = this.props;
        const { data, xAxisData, yAxisData } = getBarChartData(chartData);
        const XLabel = index => xAxisData[index] || index;

        const axesSvg = { fontSize: 10, fill: 'grey', margin: 10 };
        const verticalContentInset = { top: 10, bottom: 20 };

        return (
            <View style={{ height, padding: 2, flexDirection: 'row', width: width }}>
                <YAxis data={yAxisData} style={{ marginBottom: 10 }} contentInset={verticalContentInset} svg={axesSvg} />

                <View style={{ flex: 1, marginLeft: 10 }}>
                    <BarChart style={{ flex: 1 }} data={data} contentInset={verticalContentInset} spacingInner={0.1}>
                        <Grid />
                        {/* <Decorator /> */}
                    </BarChart>
                    <XAxis data={xAxisData} formatLabel={XLabel} contentInset={{ left: 15, right: 15 }} svg={axesSvg} />
                </View>
            </View>
        );
    }
}

export default ADMBarChart;
