import React from 'react';
import { BarChart, XAxis, Grid, YAxis } from 'react-native-svg-charts';
import { View, Text as RText } from 'react-native';
import { Text } from 'react-native-svg';
import * as scale from 'd3-scale';

import EStyleSheet from 'react-native-extended-stylesheet';

class BarGraph extends React.PureComponent {
    render() {
        const { chartData, lastRefresh } = this.props;
        const barData = chartData.chartValues;
        const xLabels = chartData.xLabels;

        const legendData = Object.keys(barData).map(key => {
            return (
                <RText key={key} style={[{ backgroundColor: barData[key].svg.fill }, styles.legendData]}>
                    {barData[key].vlabel}
                </RText>
            );
        });

        const YAxisval = barData.map(v => v.data.map(c => c.amount)).reduce((a, b) => a.concat(b));
        const Ymax = Math.max(...YAxisval);
        const Ymin = Math.min(...YAxisval);
        const axesSvg = { fontSize: 10, fill: 'grey' };
        const verticalContentInset = { top: 10, bottom: 0 };
        const xAxisHeight = 30;
        const yAxisHeight = 20;
        const chartHeight = this.props.chartVal == true ? chartData.chartHeightmax : chartData.chartHeightmin;

        return (
            <View style={{ padding: 2, flexDirection: 'column' }}>
                <View style={{ height: chartHeight, padding: 2, flexDirection: 'row' }}>
                    <YAxis data={[Ymin, Ymax]} style={{ marginBottom: xAxisHeight }} contentInset={{ top: 10, bottom: 10 }} svg={axesSvg} />

                    <View style={{ flex: 1, marginLeft: 10 }}>
                        <BarChart
                            style={{ flex: 1 }}
                            data={barData}
                            yAccessor={({ item }) => item.amount}
                            contentInset={{ top: 10, bottom: 10 }}
                            // {...this.props}
                        >
                            <Grid />
                        </BarChart>

                        <XAxis
                            style={{ marginHorizontal: -10, height: xAxisHeight }}
                            data={xLabels}
                            formatLabel={(_, index) => xLabels[index].name}
                            contentInset={{ left: xLabels.length * 10, right: xLabels.length * 10 }}
                            textAlignVertical="center"
                            //svg={axesSvg}
                        />
                    </View>
                </View>
                <View>
                    <View>
                        <RText style={styles.lastRefresh}>Last Refresh: {lastRefresh}</RText>
                    </View>
                    <View>
                        <RText style={styles.legendText}>{chartData.name}</RText>
                    </View>
                    <View style={styles.legendAlign}>{legendData}</View>
                </View>
            </View>
        );
    }
}

export default BarGraph;

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    legendData: {
        width: 80,
        fontWeight: 'bold',
        color: 'white',
        height: 25,
        borderWidth: 3,
        borderRadius: 10,
        fontSize: 15,
        textAlign: 'center',
        margin: 5,
    },
    legendText: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    legendAlign: {
        height: 20,
        padding: 20,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    lastRefresh: {
        textAlignVertical: 'bottom',
        textAlign: 'center',
        fontSize: 10,
        fontWeight: 'bold',
        //alignItems: 'flex-end',
    },
});
