import React from 'react';
import { BarChart, XAxis, Grid, YAxis } from 'react-native-svg-charts';
import { View, Text as RText } from 'react-native';
import { Text } from 'react-native-svg';
import * as scale from 'd3-scale';

import EStyleSheet from 'react-native-extended-stylesheet';

class BarGraph extends React.PureComponent {
    render() {
        ///const data12 = [50, 10, 40, 95, 85, 50, 10, 40, 95, 85, 55, 77];

        const { chartData } = this.props;
        const dataA = chartData[0].data1;
        const data1 = Object.keys(dataA)
            .map(key => {
                return dataA[key].amount;
            })
            .map(value => ({ value }));

        const dataB = chartData[0].data2;
        const data2 = Object.keys(dataB)
            .map(key => {
                return dataB[key].amount;
            })
            .map(value => ({ value }));

        const vdata = chartData[0].vType;
        const legendData = Object.keys(vdata).map(key => {
            return (
                <RText key={key} style={[{ backgroundColor: vdata[key].svg.fill }, styles.legendData]}>
                    {vdata[key].vlabel}
                </RText>
            );
        });

        const barData = [
            {
                data: data1,
                svg: vdata[0].svg,
            },
            {
                data: data2,
                svg: vdata[1].svg,
            },
        ];
        const barData1 = [12, 12, 12, 12, 12, 12];
        const xAxisHeight = 30;
        const chartHeight = this.props.chartVal == true ? chartData[0].chartHeight : 200;

        // console.log('legendData ', legendData);

        return (
            <View style={{ padding: 2 }}>
                <View style={{ height: chartHeight }}>
                    <BarChart
                        style={{ flex: 1 }}
                        data={barData}
                        yAccessor={({ item }) => item.value}
                        contentInset={{ top: 30, bottom: 30 }}
                        // {...this.props}
                    >
                        <Grid direction={Grid.Direction.HORIZONTAL} />
                    </BarChart>

                    <XAxis
                        style={{ marginHorizontal: -10, height: xAxisHeight }}
                        data={dataB}
                        //formatLabel={(value, index) => index}
                        formatLabel={(_, index) => dataB[index].label}
                        contentInset={{ left: 10, right: 10 }}
                        textAlignVertical="center"
                        //svg={axesSvg}
                    />
                </View>
                <View>
                    <View>
                        <RText style={styles.legendText}>{chartData[0].name}</RText>
                    </View>
                    <View style={styles.legendAlign}>{legendData}</View>
                </View>
            </View>
        );
    }
}

export default BarGraph;

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    legendData: {
        width: 80,
        fontWeight: 'bold',
        color: 'white',
        height: 25,
        borderWidth: 3,
        borderRadius: 10,
        fontSize: 15,
        textAlign: 'center',
        margin: 5,
    },
    legendText: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    legendAlign: {
        height: 20,
        padding: 20,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
});
