import React from 'react';
import { LineChart, YAxis, XAxis, Grid } from 'react-native-svg-charts';
import { Circle, Path } from 'react-native-svg';
import { View, Text } from 'react-native';
import { getLineChartData, getColor } from 'app/api/helperServices/utils';

const Decorator = props => {
    let allRenderedDecorators = [];
    const { x, y, data: allDatasets, hideCircle, chartData } = props;

    for (var datasetIndex in allDatasets) {
        const dataset = chartData.datasets[datasetIndex] || {};
        const { color, datasetConst } = dataset;
        const data = dataset ? dataset.data || [] : [];
        const decoratorColor = color ? color : getColor(datasetConst || datasetIndex);

        if (!hideCircle) {
            const renderedDecorator = data.map((value, index) => (
                <Circle key={`${datasetIndex}_${index}`} cx={x(index)} cy={y(value)} r={2} stroke={decoratorColor} fill={decoratorColor} />
            ));
            allRenderedDecorators = [...allRenderedDecorators, ...renderedDecorator];
        }
    }
    return allRenderedDecorators;
};

class ADMLineChart extends React.PureComponent {
    render() {
        const { chartData, height, width, lineChartProps, hideXaxis } = this.props;
        const { data, xAxisData, yAxisData } = getLineChartData(chartData);
        const XLabel = index => xAxisData[index];

        const axesSvg = { fontSize: 10, fill: 'grey' };
        const verticalContentInset = { top: 10, bottom: 10 };

        return (
            <View style={{ height, width, flexDirection: 'row' }}>
                <YAxis data={yAxisData} style={{ marginBottom: 10 }} contentInset={verticalContentInset} svg={axesSvg} />
                <View style={{ flex: 1, marginLeft: 0 }}>
                    <LineChart {...(lineChartProps || {})} style={{ flex: 1, height }} data={data} contentInset={verticalContentInset}>
                        <Grid />
                        <Decorator hideCircle={this.props.hideCircle} chartData={chartData} />
                        {this.props.children || null}
                    </LineChart>
                    {!hideXaxis && <XAxis data={xAxisData} formatLabel={XLabel} contentInset={{ left: 15, right: 15 }} svg={axesSvg} />}
                </View>
            </View>
        );
    }
}

export default ADMLineChart;
