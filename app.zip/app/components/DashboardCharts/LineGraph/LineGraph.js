import React from 'react';
import { LineChart, YAxis, XAxis, Grid } from 'react-native-svg-charts';
import { Circle, Path } from 'react-native-svg';
import { View, Text as RText } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

class LineGraph extends React.PureComponent {
    render() {
        const { chartData } = this.props;
        const data1 = chartData.data;

        const data = Object.keys(data1).map(key => {
            return data1[key].amount;
        });
        const Decorator = ({ x, y, data }) => {
            return data.map((value, index) => <Circle key={index} cx={x(index)} cy={y(value)} r={4} stroke={'rgb(134, 65, 244)'} fill={'white'} />);
        };

        // const Line = ({ line }) => <Path d={line} stroke={'rgba(134, 65, 244)'} fill={'none'} />;

        const axesSvg = { fontSize: 10, fill: 'grey' };
        const verticalContentInset = { top: 10, bottom: 10 };
        const xAxisHeight = 30;
        const chartHeight = this.props.chartVal == true ? chartData.chartHeightmax : chartData.chartHeightmin;

        const vdata = chartData.vType;
        const legendData = Object.keys(vdata).map(key => {
            return (
                <RText key={key} style={[{ backgroundColor: vdata[key].svg.fill }, styles.legendData]}>
                    {vdata[key].vlabel}
                </RText>
            );
        });

        return (
            <View style={{ padding: 2, flexDirection: 'column' }}>
                <View style={{ height: chartHeight, padding: 2, flexDirection: 'row' }}>
                    <YAxis data={data} style={{ marginBottom: xAxisHeight }} contentInset={verticalContentInset} svg={axesSvg} />

                    <View style={{ flex: 1, marginLeft: 10 }}>
                        <LineChart style={{ flex: 1 }} data={data} contentInset={verticalContentInset} svg={{ stroke: 'rgb(134, 65, 244)' }}>
                            <Grid />
                            <Decorator />
                        </LineChart>
                        <XAxis
                            style={{ marginHorizontal: -10, height: 40 }}
                            data={data}
                            formatLabel={(value, index) => index}
                            contentInset={{ left: 10, right: 10 }}
                            svg={axesSvg}
                        />
                    </View>
                </View>

                <View>
                    <View>
                        <RText style={styles.legendText}>{chartData.name}</RText>
                    </View>
                    <View style={styles.legendAlign}>{legendData}</View>
                </View>
            </View>
        );
    }
}

export default LineGraph;

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    legendData: {
        width: 80,
        fontWeight: 'bold',
        color: 'white',
        height: 25,
        borderWidth: 3,
        borderRadius: 10,
        fontSize: 15,
        textAlign: 'center',
        margin: 5,
    },
    legendText: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    legendAlign: {
        height: 20,
        padding: 20,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
});
