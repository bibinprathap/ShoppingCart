import React from 'react';
import { PieChart, YAxis, XAxis, Grid } from 'react-native-svg-charts';
import { Text as SVGText } from 'react-native-svg';
import { View, Text } from 'react-native';
import { _ } from 'lodash';
import { getPieChartData } from 'app/api/helperServices/utils';

const Labels = ({ slices, height, width }) => {
    return slices.map((slice, index) => {
        const { labelCentroid, pieCentroid, data } = slice;
        return (
            <SVGText
                key={index}
                x={pieCentroid[0]}
                y={pieCentroid[1]}
                fill={'white'}
                textAnchor={'middle'}
                alignmentBaseline={'middle'}
                fontSize={24}
                stroke={'black'}
                strokeWidth={0.2}
            >
                {data.value}
            </SVGText>
        );
    });
};

class ADMPieChart extends React.PureComponent {
    render() {
        const { chartData, height, width } = this.props;
        const data = getPieChartData(chartData);

        //console.log('PieChart.render() data: ', data);

        return (
            <View style={{ padding: 2, flexDirection: 'column', width: width }}>
                <PieChart style={{ height, padding: 10 }} data={data} spacing={0} outerRadius={'95%'}>
                    <Labels />
                </PieChart>
            </View>
        );
    }
}

export default ADMPieChart;
