import React from 'react';
import { PieChart } from 'react-native-svg-charts';
import { Text } from 'react-native-svg';
import { View, Text as RText } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
class PieGraph extends React.PureComponent {
    render() {
        // const { data } = this.props;
        const { chartData } = this.props;
        const data = chartData.data;
        const legendData = Object.keys(data).map(key => {
            return (
                <RText key={key} style={[{ backgroundColor: data[key].svg.fill }, styles.legendData]}>
                    {data[key].label}
                </RText>
            );
        });
        const chartHeight = this.props.chartVal == true ? chartData.chartHeightmax : chartData.chartHeightmin;
        const Labels = ({ slices, height, width }) => {
            return slices.map((slice, index) => {
                const { labelCentroid, pieCentroid, data } = slice;
                return (
                    <Text
                        key={index}
                        x={pieCentroid[0]}
                        y={pieCentroid[1]}
                        fill={'white'}
                        textAnchor={'middle'}
                        alignmentBaseline={'middle'}
                        fontSize={24}
                        stroke={'black'}
                        strokeWidth={0.2}
                    >
                        {data.amount}
                    </Text>
                );
            });
        };
        return (
            <View style={{ flexDirection: 'column', padding: 10 }}>
                <PieChart
                    style={{ height: chartHeight, padding: 10 }}
                    valueAccessor={({ item }) => item.amount}
                    data={data}
                    spacing={0}
                    outerRadius={'95%'}
                >
                    <Labels />
                </PieChart>

                <View>
                    <View>
                        <RText style={styles.legendText}>{chartData.name}</RText>
                    </View>
                    <View style={styles.legendAlign}>{legendData}</View>
                </View>
            </View>
        );
    }
}

export default PieGraph;

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    legendData: {
        width: 80,
        fontWeight: 'bold',
        color: 'white',
        height: 25,
        borderWidth: 3,
        borderRadius: 10,
        fontSize: 15,
        textAlign: 'center',
        margin: 5,
    },
    legendText: {
        textAlignVertical: 'center',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
    },
    legendAlign: {
        height: 20,
        padding: 20,
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
});
