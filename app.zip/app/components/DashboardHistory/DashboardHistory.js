import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ActivityIndicator } from 'react-native';
import { connect } from 'react-redux';
import { Title, Headline, Text } from 'react-native-paper';
import { Timeline } from 'app/components';
import { inspectionsHelper } from 'app/api/helperServices';
import DashboardHistoryItem from './DashboardHistoryItem';
class DashboardHistory extends Component {
    static propTypes = {
        local: PropTypes.string,
        history: PropTypes.array,
        onSelect: PropTypes.func,
    };

    constructor(props) {
        super(props);
        const renderedContent = null;
        this.state = { renderedContent };
    }

    handleOnPress = refNumber => {
        this.props.onSelect && this.props.onSelect(refNumber);
    };
    preRender = async props => {
        let content = null;
        const { history } = props;
        const historyContent = [];
        history.forEach(inspectionContainer => {
            const inspection = inspectionContainer.inspection;
            const refNumber = inspection.refNumber;
            const titleRefNumber = inspection.applicationNumber || inspection.refNumber;
            const servicesTitle = inspectionsHelper.getLongTitle(inspectionContainer, true);
            historyContent.push(
                <DashboardHistoryItem
                    key={refNumber}
                    servicesTitle={servicesTitle}
                    inspection={inspection}
                    refNumber={refNumber}
                    titleRefNumber={titleRefNumber}
                    handleOnPress={this.handleOnPress}
                />
            );
        });

        if (!historyContent || (!!historyContent && historyContent.length == 0)) {
            content = (
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <Headline>History</Headline>
                    <Title>Inspection hisory is empty</Title>
                    <Text>Todo: Put some other usefull content or message here</Text>
                </View>
            );
        } else {
            content = <Timeline data={historyContent} renderItem={({ item }) => item} />;
        }
        this.setState({ renderedContent: content });
        return null;
    };

    render() {
        const { renderedContent } = this.state;
        if (renderedContent) {
            return renderedContent;
        } else {
            setTimeout(() => {
                this.preRender(this.props, this.state);
            });
            return (
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <ActivityIndicator size={'large'} />
                </View>
            );
        }
    }
}

mapStateToProps = state => {
    const history = inspectionsHelper.getInspectionHistoryForLoggedInUser({
        userId: state.auth.activeProfileUserId,
        allHistory: state.inspections.history,
    });
    return {
        history: history || {},
    };
};

export default connect(mapStateToProps)(DashboardHistory);
