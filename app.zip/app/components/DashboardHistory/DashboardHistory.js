import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Title, Headline, Text, TouchableRipple } from 'react-native-paper';
import moment from 'moment';
import { strings } from 'app/config/i18n/i18n';
import { Timeline } from 'app/components/Timeline';
import { inspectionsHelper } from 'app/api/helperServices';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';
import DashboardHistoryItem from './DashboardHistoryItem';
class DashboardHistory extends Component {
    static propTypes = {
        local: PropTypes.string,
        history: PropTypes.array,
        onSelect: PropTypes.func,
        services: PropTypes.array,
    };

    handleOnPress = refNumber => {
        this.props.onSelect && this.props.onSelect(refNumber);
    };

    render() {
        const { history, services } = this.props;
        const historyContent = [];
        history.forEach(inspectionContainer => {
            const inspection = inspectionContainer.inspection;
            const refNumber = inspection.inspectionId || inspection.refNumber;
            const servicesTitle = inspectionsHelper.getLongTitle(inspectionContainer, false, services);
            historyContent.push(
                <DashboardHistoryItem
                    key={refNumber}
                    servicesTitle={servicesTitle}
                    inspection={inspection}
                    refNumber={refNumber}
                    handleOnPress={this.handleOnPress}
                />
            );
        });

        if (!historyContent || (!!historyContent && historyContent.length == 0)) {
            return (
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <Headline>History</Headline>
                    <Title>Inspection hisory is empty</Title>
                    <Text>Todo: Put some other usefull content or message here</Text>
                </View>
            );
        } else {
            return <Timeline data={historyContent} renderItem={({ item }) => item} />;
        }
    }
}

mapStateToProps = state => {
    const history = inspectionsHelper.getInspectionHistoryForLoggedInUser({
        domainCustomerId: state.auth.activeProfileDomainCustomerId,
        allHistory: state.inspections.history,
    });
    return {
        locale: state.settings.locale,
        history: history || {},
        services: state.masterdata.services,
    };
};

export default connect(mapStateToProps)(DashboardHistory);
