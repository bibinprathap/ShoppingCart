import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Modal } from 'react-native';
import { Text } from 'react-native-paper';
import moment from 'moment';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import InspectionLocation from './InspectionLocation';

class DashboardHistoryItem extends React.PureComponent {
    constructor(props) {
        super(props);
    }
    render() {
        const { refNumber, handleOnPress, inspection, servicesTitle, titleRefNumber } = this.props;

        return (
            <View key={refNumber} style={styles.historyItem}>
                <TouchableOpacity onPress={handleOnPress.bind(this, refNumber)} style={styles.touchWrapper}>
                    <View>
                        <Text style={styles.createdDate}>{moment(inspection.createdDate).fromNow()}</Text>
                        {!!servicesTitle && <Text style={styles.servicesTitle}>{servicesTitle}</Text>}
                        <Text style={styles.refNumber} numberOfLines={1}>
                            {strings('referenceNumberShort')} - {inspection.applicationNumber || titleRefNumber}
                        </Text>
                    </View>
                </TouchableOpacity>
                <InspectionLocation inspection={inspection} />
            </View>
        );
    }
}

export default DashboardHistoryItem;
