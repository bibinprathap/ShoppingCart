import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Modal, Linking, Platform, Image } from 'react-native';
import { Text } from 'react-native-paper';
import moment from 'moment';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import Icon from 'react-native-vector-icons/MaterialIcons';
import MaterialIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { formatAddress } from 'app/api/helperServices/utils';
import { ADMMapView } from 'app/components/ADMMapView';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import { ADMGISMapView } from 'app/components/ADMGISMapView';

import ArcGISMapView from 'ThirdPartyModuleJS/AGSMapView';

class InspectionLocation extends React.PureComponent {
    defaultPointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    ];
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
            showMap: false,
        };
        this.handleShowMap = this.handleShowMap.bind(this);
        this.handleHideMap = this.handleHideMap.bind(this);
        this.handleShowGoogleMap = this.handleShowGoogleMap.bind(this);
    }
    handleShowMap() {
        this.setState({ showMap: true });
    }
    handleHideMap() {
        this.setState({ showMap: false });
    }

    handleShowGoogleMap() {
        const { inspection } = this.props;
        const coords = inspection && inspection.location && inspection.location.coords;
        const address = (inspection && inspection.location && inspection.location.address) || {};

        const formattedAddress = formatAddress(address);

        const latLng = `${coords.latitude},${coords.longitude}`;
        const label = formattedAddress;

        console.warn(label);
        Linking.openURL(`geo:0,0?q=${latLng}(${label})`);

        // this.setState({ modalVisible: true });
    }
    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };
    render() {
        const { inspection } = this.props;
        const { showMap } = this.state;

        const coords = inspection && inspection.location && inspection.location.coords;
        const pointGraphics = this.defaultPointGraphics;
        const markersData = {
            pointGraphics: pointGraphics,
            referenceId: 'defaultId',
            points: [{ ...coords, rotation: 0, referenceId: 'selectedLocation', graphicId: 'personPoint' }],
        };
        console.log('coords ', JSON.stringify(coords));
        console.log('markersData ', JSON.stringify(markersData));

        if (showMap)
            return (
                <>
                    <View
                        style={[
                            {
                                position: 'absolute',

                                zIndex: 999,

                                top: 4,
                                right: this.props.keepRight ? 35 : 0,
                                padding: 5,
                                flex: 1,
                            },
                        ]}
                    >
                        <TouchableOpacity onPress={this.handleHideMap}>
                            <View style={styles.buttonView}>
                                <Icon name="location-off" style={styles.button} />
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={[styles.smallmapItem, { height: 200, width: '100%' }]}>
                        <View
                            style={[
                                {
                                    position: 'absolute',
                                    flexDirection: 'row',
                                    zIndex: 999,
                                    right: 0,
                                    top: 0,
                                    padding: 5,
                                },
                            ]}
                        >
                            <TouchableOpacity onPress={this.handleShowGoogleMap} style={{ marginHorizontal: 10 }}>
                                <View style={styles.buttonView}>
                                    <MaterialIcon name="google-maps" style={styles.button} />
                                </View>
                            </TouchableOpacity>
                        </View>
                        <ArcGISMapView
                            ref={mapView => (this.mapView = mapView)}
                            style={{ width: '100%', height: '100%' }}
                            initialMapCenter={[coords]}
                            recenterIfGraphicTapped={true}
                            markersData={markersData}
                            // layersData={['https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/0']}
                            // baseMapType={'LIGHT_GRAY'}
                        />

                        {/* <ADMGISMapView coords={coords} placeMarks={placeMarkData} /> */}
                    </View>
                </>
            );
        else
            return (
                <View
                    style={[
                        {
                            position: 'absolute',

                            zIndex: 999,

                            top: 4,
                            right: this.props.keepRight ? 35 : 0,
                            padding: 5,
                            flex: 1,
                        },
                    ]}
                >
                    <TouchableOpacity onPress={this.handleShowMap} style={styles.touchWrapper}>
                        <View style={styles.buttonView}>
                            <Icon name="location-on" style={styles.button} />
                        </View>
                    </TouchableOpacity>
                </View>
            );
    }
}

export default InspectionLocation;
