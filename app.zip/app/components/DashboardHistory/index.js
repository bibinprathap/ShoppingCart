import styles from './styles';
import DashboardHistory from './DashboardHistory';

export { styles, DashboardHistory };
