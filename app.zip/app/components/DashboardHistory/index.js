import styles from './styles';
import DashboardHistory from './DashboardHistory';
import InspectionLocation from './InspectionLocation';

export { styles, DashboardHistory, InspectionLocation };
