import styles from './styles';
import DashboardHistory from './DashboardHistory';
import InspectionLocation from './InspectionLocation';
import HistoryCalendar from './HistoryCalendar';
import DashboardMapView from './DashboardMapView';

export { styles, DashboardHistory, InspectionLocation, HistoryCalendar, DashboardMapView };
