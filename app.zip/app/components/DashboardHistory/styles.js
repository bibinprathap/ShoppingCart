import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {},
    historyItem: {
        flex: 1,
        margin: 10,
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    touchWrapper: { flex: 1 },
    createdDate: { fontSize: '$primaryTextXS' },
    servicesTitle: { fontSize: '$primaryTextSM', alignSelf: 'flex-start', textAlign: I18nManager.isRTL ? 'right' : 'left' },
    refNumber: { fontSize: '$primaryTextSM', alignSelf: 'flex-start', textAlign: I18nManager.isRTL ? 'right' : 'left' },
    smallmapItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    button: {
        fontSize: 25,
        justifyContent: 'center',
        alignItems: 'center',
        color: '$primaryWhite',
    },
    buttonView: {
        height: 27,
        width: 27,
        borderRadius: 5,
        backgroundColor: '$primaryHeaderColor',
        justifyContent: 'center',
        alignItems: 'center',
    },
});
