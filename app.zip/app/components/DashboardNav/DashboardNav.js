import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';

class DashboardNav extends Component {
    render() {
        return (
            <View style={styles.container}>
                <Text>DashboardNav Content</Text>
            </View>
        );
    }
}

export default DashboardNav;
