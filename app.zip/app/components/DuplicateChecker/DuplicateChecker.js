import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
import { strings } from 'app/config/i18n/i18n';

const AnimatableIcon = Animatable.createAnimatableComponent(Icon);
export default function({ checkingDuplicate, checkDuplicate }) {
    //return <AnimatableIcon name={'content-copy'} size={30} color="white" animation="pulse" easing="ease-out" iterationCount="infinite" />;
    //const [animating, setAnimationState] = useState(checkingDuplicate);

    handleIconRef = ref => (this.icon = ref);
    handleOnPress = () => {
        setTimeout(() => {
            if (checkDuplicate) checkDuplicate();
        });
    };

    return (
        <TouchableOpacity onPress={this.handleOnPress}>
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    borderWidth: 1,
                    borderColor: 'white',
                    borderRadius: 4,
                    padding: 2,
                }}
            >
                <Text numberOfLines={2} style={{ fontSize: 12, color: 'white', marginHorizontal: 2 }}>
                    {checkingDuplicate ? strings('checkingDuplicate') : strings('checkDuplicate')}
                </Text>
                <AnimatableIcon
                    ref={this.handleIconRef}
                    name={'content-copy'}
                    size={20}
                    color="white"
                    animation={
                        checkingDuplicate
                            ? {
                                  0: { rotateY: '0deg' },
                                  1: { rotateY: '360deg' },
                                  // 0: { rotateY: '0deg', scale: 1 },
                                  // 0.5: { rotateY: '180deg', scale: 1.5 },
                                  // 1: { rotateY: '360deg', scale: 1 },
                              }
                            : undefined
                    }
                    easing="linear"
                    iterationCount="infinite"
                    useNativeDriver
                />
            </View>
        </TouchableOpacity>
    );
}
