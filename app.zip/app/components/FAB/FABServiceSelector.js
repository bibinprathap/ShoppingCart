import * as React from 'react';
import { View, Animated, TouchableWithoutFeedback, StatusBar, SafeAreaView, TouchableOpacity, Image } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { Text, Card, ActivityIndicatorm, Surface, CrossFadeIcon, DefaultTheme, withTheme } from 'react-native-paper';
import { Icon, FABGroup } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { selectService } from 'app/actions/inspections';
import images from 'app/images';

class FABServiceSelector extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fabIsOpen: false,
            FABGroupActions: this.initFABGroupActions(),
        };
    }

    initFABGroupActions = () => {
        const { entities } = this.props;
        return entities.map((entity, index) => {
            const logoKey = `${entity.entityConst}Logo`;
            const entityImage = images.entities[logoKey] || {};
            const defaultHeight = 40;
            const defaultWidth = 40;
            const logoStyle = {
                width: entityImage.width || defaultWidth,
                height: entityImage.height || defaultHeight,
            };

            return {
                key: entity.entityConst,
                icon: <Image source={entityImage.content} style={logoStyle} />,
                data: entity,
                onPress: this.newInspectionEntityPressed,
            };
        });
    };

    selectEntityService = service => {
        const { navigation, dispatch, services } = this.props;
        const subServices = inspectionsHelper.findSubServices({
            services,
            entityConst: service.entityConst,
            inspectionTypeId: service.inspectionTypeId,
        });
        if (subServices) {
            this.setState({ FABGroupActions: this.getMappedFABActions(subServices) });
        } else {
            inspectionsHelper.beginInspection({ entityConst: service.entityConst }, navigation);
            dispatch(selectService(service));
        }
    };

    getMappedFABActions = services => {
        return services.map((service, index) => {
            return {
                key: `${service.inspectionTypeId}`,
                data: service,
                onPress: this.selectEntityService,
                entityConst: service.entityConst,
                titleE: service.titleE,
                titleA: service.titleA,
                icon: service.icon ? <Icon {...service.icon} size={26} /> : null,
            };
        });
    };

    newInspectionEntityPressed = entity => {
        const { navigation } = this.props;
        const services = inspectionsHelper.findSubServices({ services: this.props.services, entityConst: entity.entityConst });
        if (services) {
            this.setState({ FABGroupActions: this.getMappedFABActions(services) });
        } else {
            inspectionsHelper.beginInspection({ entityConst: entity.entityConst }, navigation);
            this.setState({ fabIsOpen: false });
        }
        //console.log('newInspectionEntityPressed(), entity: ', entity);
    };

    render() {
        const newInspectionIcon = <Image source={images.new.content} resizeMode="contain" style={styles.fabNewInspectionIcon} />;

        return (
            <FABGroup
                large
                open={this.state.fabIsOpen}
                icon={newInspectionIcon}
                style={styles.fabGroupStyle}
                backdropColor="#2A2E4388"
                fabStyle={styles.fabGroupMainIcon}
                color="red"
                actions={this.state.FABGroupActions}
                onStateChange={({ open }) => this.setState({ fabIsOpen: open, FABGroupActions: this.initFABGroupActions() })}
                onPress={data => {
                    if (this.state.fabIsOpen) {
                    }
                }}
            />
        );
    }
}

const styles = EStyleSheet.create({
    fabNewInspectionIcon: {
        width: 30,
        height: 30,
        tintColor: '$primaryWhite',
    },
    fabGroupStyle: {
        position: 'absolute',
        paddingEnd: 35,
        paddingBottom: 25,
        right: 0,
        bottom: 0,
    },
    fabGroupMainIcon: {
        position: 'absolute',
        backgroundColor: '$primaryDarkBackground',
        right: 0,
        bottom: 0,
    },
});

export default FABServiceSelector;
