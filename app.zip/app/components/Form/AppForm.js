import React from 'react';
import { View, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import { _ } from 'lodash';
import * as yup from 'yup';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { CustomAccordion } from 'app/components/CustomAccordion';
import { RFField } from 'app/components/Form';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { ValidationHelper, lookup } from 'app/api/helperServices';
import Icon from 'react-native-vector-icons/MaterialIcons';
import images from 'app/images';

import styles from './styles';

/*
    Todo: consider debouncing at the input component level, this will delay redux-form actions (such as onChange)
          and may affect validations or UI update when user presses a key in the text input
          ref: https://github.com/erikras/redux-form/issues/1835#issuecomment-249424667

          other debouncing options/ things to concider
          https://stackoverflow.com/questions/23123138/perform-debounce-in-react-js
*/

const createReadOnlyView = (config, values, validations) => {
    //console.log('creating read only view... config:', config, 'values:', values);
    const renderReadOnlyFieldGroup = (group, validations) => {
        const key = `${config.name}_${group.name}`;
        const fields = group.fields.map(item => renderReadOnlyField(item, validations));
        return (
            <View key={key} style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                {fields}
            </View>
        );
    };

    const readOnlyRtlStyles = I18nManager.isRTL
        ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
        : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };

    const renderReadOnlyField = (field, validations) => {
        //Todo: extract the field rendering logic into a separate component for each type
        const key = `${config.name}_${field.name}`;
        let formattedValue = undefined;
        switch (field.type) {
            case 'text':
            case 'maskedText':
            case 'numeric':
                formattedValue = <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{values && values[field.name]}</Text>;
                break;
            case 'picker':
                formattedValue = (
                    <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{values && lookup.getLabel(field.name, values[field.name])}</Text>
                );
                break;
            case 'switch':
                const isTrue = values && !!values[field.name];
                if (isTrue) {
                    if (field.onIcon) {
                        if (field.onIconType == 'default') {
                            formattedValue = <Icon name={field.onIcon} size={32} style={styles.icon} />;
                        } else {
                            formattedValue = <Image source={images[field.onIcon].content} resizeMode="contain" />;
                        }
                    } else {
                        formattedValue = <Icon name="check" size={32} style={styles.icon} />;
                    }
                } else {
                    if (field.offIcon) {
                        if (field.offIconType == 'default') {
                            formattedValue = <Icon name={field.offIcon} size={32} style={styles.icon} />;
                        } else {
                            formattedValue = <Image source={images[field.offIcon].content} resizeMode="contain" />;
                        }
                    } else {
                        formattedValue = <Icon name="close" size={32} style={styles.icon} />;
                    }
                }
                break;
            case 'periodPicker':
                const periodValue = (values && values[field.name]) || {};
                const selectedPeriod = parseInt(periodValue.selectedPeriod) || 0;
                const pluralizedPeriodType = `${periodValue.selectedPeriodType || 'day'}${selectedPeriod <= 1 ? '' : 's'}`;
                formattedValue = (
                    <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>
                        {selectedPeriod} {strings(pluralizedPeriodType)}
                    </Text>
                );
                break;
            case 'attachmentList':
                const attachmentsArray = values && values[field.name];
                formattedValue = attachmentsArray && (
                    <AttachmentList attachments={attachmentsArray} editable={false} hideDelete={true} enableGalleryView thumbnailType="rounded" />
                );

                break;
            case 'signature':
            case 'custom':
                formattedValue = (
                    <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>
                        {field.type}: {values && JSON.stringify(values[field.name])}
                    </Text>
                );
        }
        return (
            <View
                key={key}
                style={[
                    { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                    !!field.inlineValue ? { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' } : {},
                ]}
            >
                <Text style={[styles.lableReadOnly, readOnlyRtlStyles, !!field.inlineValue ? { alignSelf: 'center' } : {}]}>
                    {localeProperty(field, 'label')}
                </Text>
                {formattedValue}
                {validations && validations[field.name] ? (
                    <Text style={styles.ValidationMessageText}> {localeProperty(field, 'label') + ' ' + strings('isRequired')} </Text>
                ) : null}
            </View>
        );
    };
    const renderedForm = config.fields.map(item => {
        if (item.type === 'fieldGroup') {
            return renderReadOnlyFieldGroup(item, validations);
        } else {
            return renderReadOnlyField(item, validations);
        }
    });

    return <View style={config.hideBorder ? styles.containerWithoutBorder : styles.container}>{renderedForm}</View>;
};

const createForm = (config, fieldValues, onFormChange, onFieldchange, customValidation) => {
    const defaultValue = {};
    config.fields.map(item => {
        if (item.type === 'fieldGroup') {
            if (item.fields) {
                item.fields.map(fieldConfig => {
                    if (typeof fieldConfig.defaultValue !== 'undefined') {
                        defaultValue[fieldConfig.name] = fieldConfig.defaultValue;
                    }
                });
            }
        }
    });

    const values = { ...defaultValue, ...fieldValues };
    const readOnlyForm = props => {
        return createReadOnlyView(config, props.values, props.validations);
    };

    if (config.readOnly) return readOnlyForm;

    //if (config.readOnly) return createReadOnlyView(config, values);

    const handleOnFormChange = (values, dispatch, props, previousValues) => {
        if (_.isEqual(values, previousValues)) return;
        if (!!onFormChange) onFormChange(values, dispatch, props, previousValues);
    };
    const validationSchemaShape = {};
    const asyncValidate = values => {
        const validationSchema = yup.object().shape(validationSchemaShape);
        return ValidationHelper.validate(values, validationSchema, customValidation);
    };

    const handleFieldChange = (event, newValue, previousValue, name) => {
        if (!!onFieldchange) onFieldchange(event, newValue, previousValue, name);
    };

    const renderFieldGroup = (group, formProps) => {
        const { name } = group;
        const key = `${config.name}_${name}`;
        const fields = group.fields.map(item => renderField(item, formProps));
        return (
            <View key={key} style={{ flex: 1, flexDirection: 'row' }}>
                {fields}
            </View>
        );
    };

    const renderField = (item, formProps) => {
        const { name, validationRule, disableIf, integrated } = item;
        const fieldProps = formProps.formProps ? formProps.formProps[name] : {};
        const key = `${config.name}_${name}`;
        let isMandatory = false;
        if (validationRule) {
            validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
            isMandatory = ValidationHelper.getIsMandatory(validationRule);
        }
        //const debouncedFieldChangeHandler = item.debounce ? _.debounce(handleFieldChange, item.debounce) : handleFieldChange;
        const debouncedFieldChangeHandler = handleFieldChange;
        let pickerOptions = [];
        let parentId = null;
        if (item.type === 'picker') {
            if (item.cascadingParent) {
                let parentId = null;
                if (typeof formProps.currentFormValues[item.cascadingParent] !== 'undefined' && formProps.currentFormValues[item.cascadingParent]) {
                    parentId = formProps.currentFormValues[item.cascadingParent];
                }
                // If value is empty then get parentId using intial value
                if (
                    (typeof parentId === 'undefined' || parentId === null) &&
                    formProps.initialValues &&
                    typeof formProps.initialValues[item.cascadingParent] !== 'undefined'
                ) {
                    parentId = formProps.initialValues[item.cascadingParent];
                } else if ((typeof parentId === 'undefined' || parentId === null) && typeof item.cascadingParentDefaultValue !== 'undefined') {
                    parentId = item.cascadingParentDefaultValue;
                }
                if (typeof parentId != 'undefined' && parentId !== null) {
                    pickerOptions = lookup.getList(item.name, parentId);
                }
            } else {
                pickerOptions = lookup.getList(item.name, null);
            }
            pickerOptions = pickerOptions || [];
        }

        const rules = {};
        if (disableIf) {
            _.forEach(disableIf, function(rule) {
                const ruleArray = rule.split('=');
                const linkedFieldName = ruleArray[0];
                const linkedFieldValue = ruleArray[1];
                if (typeof formProps.currentFormValues[linkedFieldName] !== 'undefined') {
                    if (`${formProps.currentFormValues[linkedFieldName]}` === linkedFieldValue) {
                        rules.editable = false;
                    }
                }
            });
        }
        if (integrated) rules.editable = false;

        return (
            <RFField
                key={key}
                pickerOptions={item.type === 'picker' && pickerOptions}
                {...{ editable: formProps.editable, ...fieldProps }}
                showLabel={config.showLabels}
                isMandatory={isMandatory}
                {...item}
                {...rules}
                handleChangePeriodType={item.type === 'periodPicker' ? formProps.handleChangePeriodType : null}
                handlePeriodNumberPickerChange={item.type === 'periodPicker' ? formProps.handlePeriodNumberPickerChange : null}
                onFieldchange={debouncedFieldChangeHandler}
                integrationData={formProps.integrationData}
            />
        );
    };

    const generateFields = formProps => {
        return config.fields.map(item => {
            const { type, name } = item;
            if (type === 'fieldGroup') {
                return renderFieldGroup(item, formProps);
            } else {
                return renderField(item, formProps);
            }
        });
    };

    //default renderTitle
    const _renderTitle = props => {
        return config.showFormTitle ? (
            <View style={styles.titleContainer}>
                <Text style={styles.title}>{localeProperty(config, 'title')}</Text>
            </View>
        ) : null;
    };

    const newForm = props => {
        //console.log(`newForm constructor: ${config.name}`);
        const collapsible = config.collapsible === undefined ? false : config.collapsible;
        const boundRenderTitle = props.renderTitle ? props.renderTitle : config.renderTitle ? config.renderTitle : _renderTitle;
        if (config.onInit) config.onInit(props);
        const fields = generateFields(props);
        return !!collapsible ? (
            <View style={styles.container}>
                <CustomAccordion renderHeaderTitle={boundRenderTitle} expandedAtStart={true}>
                    {fields}
                </CustomAccordion>
            </View>
        ) : (
            <View style={config.hideBorder ? styles.containerWithoutBorder : styles.container}>
                {boundRenderTitle(props)}
                {fields}
            </View>
        );
    };

    //Todo: make formDebounce >= maxFieldsDebounce
    const formDebounce = config.debounce === undefined ? 500 : config.debounce;
    const debouncedFormChangeHandler = _.debounce(handleOnFormChange, formDebounce);
    const formCreator = reduxForm({ form: config.name, asyncValidate, onChange: debouncedFormChangeHandler, enableReinitialize: true });
    const connectedForm = formCreator(newForm);

    const mapStateToProps = state => {
        const currentFormValues = (state.form[config.name] && state.form[config.name].values) || {};
        return {
            initialValues: values,
            currentFormValues,
        };
    };

    const formWithInitialValues = connect(mapStateToProps)(connectedForm);

    return formWithInitialValues;
};
export default createForm;
export { createForm, createReadOnlyView };
