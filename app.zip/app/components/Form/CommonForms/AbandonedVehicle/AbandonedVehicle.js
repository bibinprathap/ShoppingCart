import React, { Component } from 'react';
import { View, TextInput, Picker, ScrollView, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { AttachmentListWithDialog, ViolationList } from 'app/screens';
import { inspectionsHelper, lookup } from 'app/api/helperServices';
import { infoChanged } from 'app/actions/inspections';

class AbandonedVehicle extends Component {
    constructor(props) {
        super(props);
        const vals = props.initialValue || props.values;
        const stateFromStore = { attachmentList: [], ...vals };
        const vehicleYardState = inspectionsHelper.getVehicleYardState({
            impoundVehicleYardId: stateFromStore.impoundVehicleYardId,
            inspection: props.inspection,
        });
        this.state = { ...stateFromStore, ...vehicleYardState };
    }

    componentDidMount() {
        const { needValidation, readOnly, inspection } = this.props;
        if (needValidation) {
            const { errorLogs, changed } = this.runValidation(this.state, true);
        }

        const { currentVisitIndex, currentVisit } = inspectionsHelper.getCurrentVisit(inspection);
        if (!readOnly && currentVisit.inspectionId) {
            const violationItems = this.getViolationItems(inspection);
            if (violationItems && violationItems.length > 0) return;
            const { inspectionTypeDetail } = inspection;
            const defaultVisitValues = [];
            if (inspectionTypeDetail.inspectionTypeCheckItems) {
                inspectionTypeDetail.inspectionTypeCheckItems.map(inspTypecheckItem => {
                    defaultVisitValues.push({
                        checkItemId: inspTypecheckItem.violationTypeIds[0],
                        inspTypeCheckItemId: inspTypecheckItem.inspTypeCheckItemId,
                        violationTypeIds: inspTypecheckItem.violationTypeIds,
                        possibleViolatorTypes: ['vehicle'],
                        selectedOption: 'fixedViolation',
                    });
                });
            }
            this.props.dispatch(infoChanged('values', defaultVisitValues, currentVisitIndex));
        }
    }

    async componentDidUpdate() {
        const { needValidation } = this.props;
        if (needValidation === true) {
            const { errorLogs, changed } = await this.runValidation(this.state);

            if (!!changed && errorLogs) {
                this.setState({ errorLogs });
            }
        }
    }

    updateState = newState => {
        const { dispatch, visitIndex, formName } = this.props;
        this.setState(newState, () => {
            const { attachmentList, remarks, impoundVehicleYardId, impoundVehicleYardIdRequired, selectedActionTypeConst } = this.state;
            const stateToStore = { attachmentList, remarks, impoundVehicleYardId, impoundVehicleYardIdRequired, selectedActionTypeConst };
            stateToStore.isResolved = false;
            delete stateToStore.errorLogs;

            dispatch(infoChanged(formName, stateToStore, visitIndex));
        });
    };

    //Todo: move it to the validation helper service
    valuesCompare = (obj1, obj2) => {
        if (!obj1 || !obj2) return false;
        let areEqual = true;
        const keys1 = Object.keys(obj1);
        const keys2 = Object.keys(obj2);

        const numberOfKeys1 = (keys1 && keys1.length) || 0;
        const numberOfKeys2 = (keys2 && keys2.length) || 0;
        if (numberOfKeys1 != numberOfKeys2) return false;

        if (numberOfKeys1 > 0 && numberOfKeys2 > 0) {
            for (var k = 0; k < keys1.length; k++) {
                if (obj1[keys1[k]] !== obj2[keys1[k]]) {
                    areEqual = false;
                    break;
                }
            }
        }
        return areEqual;
    };

    runValidation = async (validationState, setTheState) => {
        const { errorLogs: oldErrorLogs } = validationState;
        const { inspection } = this.props;
        const errorLogs = await inspectionsHelper.validateAbandonedVehicle(validationState, inspection);

        const errorLogsAreEqual = this.valuesCompare(oldErrorLogs, errorLogs);

        if (!errorLogsAreEqual && setTheState === true) {
            setImmediate(() => {
                this.setState({ errorLogs });
            });
        }
        return { errorLogs, changed: !errorLogsAreEqual };
    };

    handleFieldChange = async (name, value) => {
        const newState = { [name]: value };
        this.updateState(newState);
    };

    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateState(newState);
    };

    handleOnActionChange = callProps => {
        const { params = {}, inspTypeCheckItemId, reset } = callProps;
        const { impoundVehicleYardId } = this.setState;
        const vehicleYardState = inspectionsHelper.getVehicleYardState({
            selectedActionTypeConst: params.selectedActionTypeConst,
            impoundVehicleYardId,
        });
        this.updateState({ ...vehicleYardState, selectedActionTypeConst: params.selectedActionTypeConst });
    };

    getViolationItems = inspection => {
        const { currentVisitIndex, currentVisit } = inspectionsHelper.getCurrentVisit(inspection);
        const currentVisitCheckListValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].values : undefined;
        const violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);
        return violationItems;
    };

    render() {
        const { dispatch, inspection, editable, formName, impoundVehicleYardOptions, readOnly, currentInspectionVersion } = this.props;
        const displaySource = this.props.readOnly ? this.props.values : this.state;
        const { attachmentList, remarks, impoundVehicleYardId, impoundVehicleYardIdRequired } = displaySource || {};
        let errorLogs = this.props.errorLogs || {};
        const violationItems = this.getViolationItems(inspection);

        const readOnlyRtlStyles = I18nManager.isRTL
            ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
            : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };

        return (
            <View style={{ marginVertical: 20, flex: 1 }} key={{ formName }} key={this.props.key}>
                <ScrollView>
                    <View style={{ flex: 1 }} key={this.props.key}>
                        {!readOnly && (
                            <ViolationList
                                dispatch={dispatch}
                                inspection={inspection}
                                editable={editable}
                                violationItems={violationItems}
                                onActionChange={this.handleOnActionChange}
                            />
                        )}

                        <View style={styles.container}>
                            <View style={styles.fieldrow}>
                                <View style={styles.labelContainer}>
                                    <Text style={styles.label}> {strings('attachments')}</Text>
                                    <View style={styles.fieldContainer}>
                                        <AttachmentListWithDialog
                                            editable={editable}
                                            onAdd={this.handleOnAddAttachment}
                                            onRemove={this.handleOnRemoveAttachment}
                                            attachments={attachmentList}
                                        />
                                    </View>
                                </View>
                            </View>
                            {errorLogs.attachmentList && (
                                <Text style={[styles.ValidationMessageText, styles.error]}>
                                    {strings('attachments') + ' ' + strings('isRequired')}
                                </Text>
                            )}
                            <View style={styles.fieldrow}>
                                <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                                    <Text style={styles.label}> {strings('remarks')}</Text>
                                    {readOnly ? (
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{remarks}</Text>
                                        </View>
                                    ) : (
                                        <View style={[styles.fieldContainer]}>
                                            <TextInput
                                                style={styles.input}
                                                placeholder={strings('newRemarks')}
                                                value={remarks}
                                                editable={editable}
                                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                                autoCorrect={false}
                                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                                autoCapitalize="sentences"
                                                //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                                //autoFocus={true}
                                                multiline={true}
                                                textAlignVertical={'top'}
                                            />
                                        </View>
                                    )}
                                </View>
                            </View>
                            {errorLogs.remarks && (
                                <Text style={[styles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                            )}
                            {!!impoundVehicleYardIdRequired && (
                                <View style={styles.fieldrow}>
                                    <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                                        <Text style={styles.label}> {strings('yard')}</Text>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            {readOnly ? (
                                                <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>
                                                    {impoundVehicleYardId && lookup.getLabel('vehicleYard', impoundVehicleYardId, '', '-1')}
                                                </Text>
                                            ) : (
                                                <Picker
                                                    selectedValue={impoundVehicleYardId}
                                                    key={`yard${impoundVehicleYardOptions.length}`}
                                                    enabled={editable}
                                                    style={styles.picker}
                                                    onValueChange={this.handleFieldChange.bind(this, 'impoundVehicleYardId')}
                                                >
                                                    <Picker.Item key={-1} label={strings('pleaseselect') + ' ' + strings('yard')} value={undefined} />
                                                    {impoundVehicleYardOptions &&
                                                        impoundVehicleYardOptions.map((v, i) => {
                                                            return (
                                                                <Picker.Item
                                                                    key={i}
                                                                    label={localeProperty(v, 'label') || 'Unknown Type'}
                                                                    value={v.id}
                                                                />
                                                            );
                                                        })}
                                                </Picker>
                                            )}
                                        </View>
                                    </View>
                                </View>
                            )}
                            {!!impoundVehicleYardIdRequired && errorLogs.impoundVehicleYardId && (
                                <Text style={[styles.ValidationMessageText, styles.error]}>{strings('yard') + ' ' + strings('isRequired')}</Text>
                            )}
                        </View>
                    </View>
                </ScrollView>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        impoundVehicleYardOptions: state.masterdata.dataLookups.vehicleYard,
    };
};

export default connect(mapStateToProps)(AbandonedVehicle);

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingHorizontal: 8,
    },
    fieldrow: { flex: 1, flexDirection: 'row', marginVertical: 10 },
    labelContainer: {
        flex: 1,
        // flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    labelContainerColumnStart: {
        flex: 4,
        marginStart: 5,
    },
    labelContainerColumnEnd: {
        flex: 4,
        marginEnd: 5,
    },
    fieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        // marginHorizontal: 10,
        marginTop: 5,
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        // maxWidth: 100,
        // minWidth: 120,
        justifyContent: 'flex-start',
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,
        height: 50,
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    fieldContainerPicker: {
        height: 45,
        backgroundColor: '#ffffff',
        elevation: 1,
        borderRadius: 4,
    },
    picker: {
        height: 50,
        width: '100%',
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        color: '$primaryDarkTextColor',

        borderRadius: 4,
        elevation: 1,
    },
    valueReadOnlyText: {
        fontSize: 12,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        color: '$primaryDarkTextColor',
    },
    error: {
        paddingHorizontal: 10,
        marginBottom: 10,
        marginStart: 8,
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
});
