export default (config = {
    name: 'buildingInfoForm',
    titleE: 'Building Information',
    titleA: 'معلومات البناء',
    showFormTitle: true,
    collapsible: true,
    showLabels: true,
    fields: [
        {
            name: 'fieldGroup1',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'buildingNumber',
                    type: 'text',
                    labelE: 'Building No. (MEPS)',
                    labelA: '(MEPS) رقم المبنى',
                    placeholderE: 'Building No. (MEPS)',
                    placeholderA: '(MEPS) رقم المبنى',
                    validationRule: ['string', 'required'],
                },
                {
                    name: 'buildingName',
                    type: 'text',
                    labelE: 'Building Name',
                    labelA: 'اسم المبنى',
                    placeholderE: 'Building Name',
                    placeholderA: 'اسم المبنى',
                    validationRule: ['string', 'required'],
                },
            ],
        },
    ],
});
