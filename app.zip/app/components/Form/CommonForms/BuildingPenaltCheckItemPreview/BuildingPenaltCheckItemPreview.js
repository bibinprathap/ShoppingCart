import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager } from 'react-native';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';
import { Icon, ReconciliationPreview } from 'app/components';
import { ViolationActionReview } from 'app/components/Preview/ViolationItemReview';
// import ViolationList from 'app/screens/inspection/ViolationDetails/ViolationList';
import { AttachmentListWithDialog, ViolationList } from 'app/screens';

class BuildingPenaltCheckItemPreview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            reconciliationDialogVisible: false,
        };
        this.handleReconciliation = this.handleReconciliation.bind(this);
    }
    handleReconciliation = () => {
        this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible }, () => {
            if (!this.state.reconciliationDialogVisible) this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible });
        });
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    render = () => {
        const { visitIndex, actionTypeOptions, inspection } = this.props;
        let violationItems = [];
        const buildingPenaltiesForm = inspection.visits[visitIndex].buildingPenaltiesForm;
        const actionItem =
            actionTypeOptions.length > 0
                ? inspectionsHelper.findViolationAction({
                      violationActionTypes: actionTypeOptions,
                      selectedActionType: buildingPenaltiesForm.selectedActionType,
                  })
                : {};
        let currentVisitCheckListValues =
            visitIndex != undefined
                ? [
                      {
                          ...buildingPenaltiesForm,
                          selectedActionTypeConst: actionItem.constant,
                      },
                  ]
                : undefined;
        violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);

        const actionTypeConstant = actionItem.constant || buildingPenaltiesForm.selectedActionTypeConst || 'engineeringReview';
        return (
            <View style={styles.container}>
                <ViolationList
                    dispatch={() => {}}
                    inspection={inspection}
                    hideEditAndDelete={true}
                    editable={false}
                    violationItems={violationItems}
                />
                {this.state.reconciliationDialogVisible ? (
                    <ReconciliationPreview
                        readOnly={true}
                        currentInspectionVersion={1}
                        violatorId={inspection.violators[0].violatorId}
                        values={{ reconciled: !!inspection.violators[0].signature, signature: inspection.violators[0].signature }}
                        dispatch={() => {}}
                        navigation={this.props.navigation}
                    />
                ) : null}
                {inspection.violators[0].signature ? (
                    <TouchableNativeFeedback onPress={(e, props) => this.handleReconciliation(inspection.violators[0], 1)}>
                        <View style={styles.violatorInfoClickArea}>
                            <Icon type="AdmIcon" name="wf-1210" size={25} style={[styles.icon, styles.iconActive]} />
                        </View>
                    </TouchableNativeFeedback>
                ) : null}
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer}>
                            <AttachmentListWithDialog editable={false} attachments={buildingPenaltiesForm.attachments} />
                        </View>
                    </View>
                </View>

                <View style={styles.ViolationActionContainer}>
                    <ViolationActionReview
                        selectedActionTypeConst={actionTypeConstant}
                        amount={buildingPenaltiesForm.amount}
                        selectedPeriod={buildingPenaltiesForm.selectedPeriod}
                        selectedPeriodType={buildingPenaltiesForm.selectedPeriodType}
                    ></ViolationActionReview>
                </View>
            </View>
        );
    };
}

export default BuildingPenaltCheckItemPreview;
