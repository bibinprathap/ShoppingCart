import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';
export default EStyleSheet.create({
    contentContainer: {
        flex: 1,
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 5,
        borderRadius: 10,
    },
    formContainer: {
        backgroundColor: '$primaryLightBackground',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,

        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    inputDisabled: {
        color: '$primaryDarkTextColor',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,

        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    labelContainer: {
        flex: 1,
        // flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    labelContainerColumnStart: {
        flex: 4,
        marginStart: 5,
    },
    labelContainerColumnEnd: {
        flex: 4,
        marginEnd: 5,
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        // maxWidth: 100,
        // minWidth: 120,
        justifyContent: 'flex-start',
    },
    button: {
        height: 50,

        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonSearch: {
        height: 50,

        justifyContent: 'center',
        alignItems: 'center',
    },

    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    container: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingHorizontal: 8,
    },
    titleContainer: {
        flex: 1,
    },
    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
        alignSelf: 'flex-start',
    },
    fieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        // marginHorizontal: 10,
        marginTop: 5,
    },
    fieldrow: { flex: 1, flexDirection: 'row', marginVertical: 10 },
    fieldContainerAttachement: {
        backgroundColor: '$primaryLightBackground',
        flexDirection: 'row',
    },
    outerContainerNoAttachment: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 10,
    },
    outerContainerWithAttachment: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    customFieldRowContainer: {
        marginTop: 20,
        flex: 1,
        marginBottom: 5,
    },
    fieldContainerPicker: {
        height: 45,
        backgroundColor: '#ffffff',
        elevation: 1,
        borderRadius: 4,
    },
    picker: {
        height: 50,
        width: '100%',
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        color: '$primaryDarkTextColor',

        borderRadius: 4,
        elevation: 1,
    },
    price: {
        fontWeight: 'bold',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
    error: {
        paddingHorizontal: 10,
        marginStart: 8,
    },
    summaryContainer: {
        flex: 1,

        justifyContent: 'flex-end',
        marginBottom: 36,
        flexDirection: 'row',
        height: 60,
        width: '100%',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
        marginLeft: 5,
    },
    violationAmountContainer: { flex: 1, flexDirection: 'row' },
    violationAmount: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    valueReadOnlyText: {
        fontSize: 12,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        color: '$primaryDarkTextColor',
    },
    violationLeft: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
        padding: 10,
        flexDirection: 'row',
    },
    violationRight: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: 10,
        flexDirection: 'row',
    },
    fieldContainerShadowed: {
        backgroundColor: '$primaryWhite',
        elevation: 4,
        borderRadius: 8,
    },
    engineeringReviewMsgContainer: {
        borderWidth: '$primaryBorderThin',
        backgroundColor: '$primaryIndicatorMutedColor',
        borderColor: '$primaryBorderColor',
        padding: 5,
        borderRadius: 5,
    },
    ViolationActionContainer: {
        flex: 1,
        marginBottom: 5,
        padding: 10,
        elevation: 1,
        borderRadius: 8,
    },
});
