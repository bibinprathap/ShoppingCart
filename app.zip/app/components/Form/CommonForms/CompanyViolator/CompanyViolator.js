import React, { Component } from 'react';
import { View, ScrollView, TextInput } from 'react-native';
import AppApi from 'app/api/real';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import styles from './styles';
import { ViolatorSelector, IconButton, IntegrationFeedback } from 'app/components';
const api = new AppApi();

//Todo: Integrate with DED
class CompanyViolator extends Component {
    constructor(props) {
        super(props);
        this.searchCompanyProfile = this.searchCompanyProfile.bind(this);
        this.handleMEPSandELMSViolatorSelection = this.handleMEPSandELMSViolatorSelection.bind(this);
        const { violator } = props;
        if (props.mode === 'edit') {
            this.state = { ...violator };
        } else {
            this.state = { idNumber: '', titleE: '', registeredPhoneNumber: '', titleA: '', integrationData: null, detail: null };
        }
    }

    handleFieldChange = async (name, value) => {
        let newstate = { [name]: value };
        if (name == 'idNumber' && this.state.integrationData && this.state.integrationData.success) {
            newstate = { [name]: value, titleE: '', registeredPhoneNumber: '', titleA: '', integrationData: null };
            this.props.isValidViolator(false, newstate);
        }
        this.setState(newstate, () => {
            if (this.state.integrationData && this.state.integrationData.success) this.props.isValidViolator(true, this.state);
        });
    };

    searchCompanyProfile = async () => {
        const { integrationData } = this.state;
        const isSearching = integrationData && integrationData.running == true;
        if (isSearching) return;
        this.setState({
            registeredPhoneNumber: '',
            titleA: '',
            titleE: '',

            violatorType: 'company',
            integrationData: { running: true, message: strings('integrationProgressMessageDED') },
        });
        try {
            const param = {
                ...this.state,
                integrationData: null,
                tradeLicenseNumber: this.state.idNumber,
            };
            const result = await api.getCompanyProfile(param);
            const newState = {
                ...this.state,
                ...result,
                idNumber: this.state.idNumber,
                violatorType: 'company',
                integrationData: { running: false, success: true, message: strings('integrationSuccessMessageDED') },
            };
            this.setState(newState, () => {
                this.props.isValidViolator(true, this.state);
            });
        } catch (e) {
            if (!e.isCancel) {
                const newState = {
                    registeredPhoneNumber: '',
                    titleA: '',
                    titleE: '',

                    detail: null,
                    violatorType: 'company',
                    integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageDED') },
                };
                this.setState(newState, () => {
                    this.props.isValidViolator(false, this.state);
                });
                /*
        todo: if license number is invalid, set error on licenseNumber
              if it is network error, or exception on the server, then 
              enable the company name field so user can enter value directly.
        */
            }
        }
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleMEPSandELMSViolatorSelection = violator => {
        const newState = {
            ...violator,
            integrationData: { running: false, success: true, message: strings('integrationSuccessMessageDED') },
        };
        this.setState(newState, () => {
            this.props.isValidViolator(true, this.state);
        });
    };

    render = () => {
        const { mode, idNumber, titleE, registeredPhoneNumber, titleA, integrationData } = this.state;
        const validationStyles = styles.invalid;
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const editable = mode == undefined || mode === 'new';
        const isSearching = integrationData && integrationData.running == true;
        const fieldEditable = false;
        const searchButtonstyle = editable && !isSearching && idNumber.length > 0 ? styles.buttonPositive : styles.buttonPositiveDisabled;
        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, { flex: 4 }]}>
                        <Text style={styles.label}> {strings('tradeLicenseNumber')}</Text>
                        <View style={styles.fieldContainer}>
                            <TextInput
                                style={styles.input}
                                onChangeText={this.handleFieldChange.bind(this, 'idNumber')}
                                theme={textInputTheme}
                                value={idNumber}
                                editable={!isSearching && editable}
                                placeholder={'CN-#### or IN-####'}
                                placeholderStyle={{ color: '#000000' }}
                                textAlignVertical={'center'}
                                // keyboardType={'numeric'}
                            />
                            <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                            </View>

                            <View>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="magnify"
                                    disabled={!editable || isSearching || idNumber.length == 0}
                                    style={[styles.buttonSearch, searchButtonstyle]}
                                    onPress={this.searchCompanyProfile}
                                />
                            </View>
                        </View>
                    </View>
                    <View style={{ flex: 3, flexDirection: 'row', justifyContent: 'space-evenly', paddingTop: 20 }}>
                        <ViolatorSelector
                            showButton={!isSearching && editable}
                            source={'MEPS'}
                            onViolatorSelected={this.handleMEPSandELMSViolatorSelection}
                            location={this.props.location}
                        />
                        <ViolatorSelector
                            showButton={!isSearching && editable}
                            source={'ELMS'}
                            onViolatorSelected={this.handleMEPSandELMSViolatorSelection}
                            location={this.props.location}
                        />
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('companyName')}</Text>
                        <View style={styles.fieldContainer}>
                            <Text style={styles.inputDisabled}> {localeProperty(this.state, 'title')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('registeredPhoneNumber')}</Text>
                        <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                            <Text style={styles.inputDisabled}> {registeredPhoneNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.labelContainer}>
                        <Text style={[styles.label, { marginStart: 5 }]}> {strings('country')}</Text>
                        <View style={[styles.fieldContainer, { marginStart: 5 }]}>
                            <Text style={styles.inputDisabled}> {localeProperty(this.state, 'nationalityName')}</Text>
                        </View>
                    </View>
                </View>
            </View>
        );
    };
}
export default CompanyViolator;
