import React, { Component } from 'react';
import { createForm } from 'app/components/Form';
import formConfigTemplate from './config';
import AppApi from 'app/api/real';
import { shallowEqual } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import { checkDuplicate } from 'app/actions/inspections';
const api = new AppApi();

//Todo: Integrate with DED
class DistortionForm extends Component {
    state = { integrationData: { running: false } };
    constructor(props) {
        super(props);

        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            editable: props.editable,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            errorLogs: props.errorLogs,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }
    handleOnInit = formProps => {
        this.formProps = formProps;
    };
    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
        if (
            this.props.editable &&
            values.distortionType &&
            !(previousValues.distortionType && previousValues.distortionType == values.distortionType && previousValues.slaLevels != null)
        ) {
            // await inspectionsHelper.nextFrame();
            this.props.dispatch(checkDuplicate());
        }
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    render = () => {
        const TheForm = this.form;
        //console.warn('DistortionForm rerender' + Math.random());
        return (
            <TheForm
                formProps={this.props.formProps}
                values={this.props.values}
                editable={this.props.editable}
                integrationData={this.state.integrationData}
                errorLogs={this.props.errorLogs}
            />
        );
    };
}

export default DistortionForm;
