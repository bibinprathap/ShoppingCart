export default {
    name: 'distortionForm',
    formType: 'dynamic',
    scope: 'visit',
    titleE: 'Details of the distortion',
    titleA: 'تفاصيل التشويه',
    showFormTitle: true,
    collapsible: true,
    showLabels: true,
    fields: [
        {
            name: 'fieldGroup4',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'agency',
                    type: 'picker',
                    defaultlyNotSelected: true,
                    labelE: 'Agency',
                    labelA: 'وكالة',
                    icon: 'bug-report',
                    iconType: 'default',
                    validationRule: ['string', 'required', 'nullable'],
                    immediateChild: 'distortionType',
                    children: ['distortionType'],
                },
            ],
        },
        {
            name: 'fieldGroup3',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'distortionType',
                    type: 'picker',
                    defaultlyNotSelected: true,
                    labelE: 'Distortion Type',
                    labelA: 'نوع التشويه',
                    icon: 'bug-report',
                    iconType: 'default',
                    cascadingParent: 'agency',
                    childPicker: 'slaLevels',
                    validationRule: ['string', 'required', 'nullable'],
                },
            ],
        },
        {
            name: 'fieldGroup2',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'slaLevels',
                    type: 'childpicker',
                    defaultlyNotSelected: true,
                    labelE: 'Sla Levels',
                    labelA: 'نوع التشويه',
                    icon: 'bug-report',
                    iconType: 'default',
                    rootParentPicker: 'agency',
                    parentPicker: 'distortionType',
                    showChildPicker: 'slaLevels',
                },
            ],
        },
        {
            name: 'fieldGroup1',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'attachmentList',
                    type: 'attachmentList',
                    labelE: 'Attachments',
                    labelA: 'مرفقات',
                    validationRule: ['array', 'required', 'nullable'],
                },
            ],
        },
    ],
};
