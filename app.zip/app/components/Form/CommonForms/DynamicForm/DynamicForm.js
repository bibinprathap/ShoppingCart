import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm } from 'app/components/Form';

class DynamicForm extends React.PureComponent {
    static propTypes = {
        formDef: PropTypes.object,
        initialValues: PropTypes.object,
        formChangeHandler: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.form = createForm(props.formDef, props.initialValues, props.formChangeHandler);
        // console.log('DynamicForm constructor');
    }

    render = () => {
        const TheForm = this.form;
        return (
            <TheForm
                values={this.props.values}
                currentInspectionVersion={this.props.currentInspectionVersion}
                formProps={this.props.formProps}
                editable={this.props.formDef.editable}
            />
        );
    };
}

export default DynamicForm;
