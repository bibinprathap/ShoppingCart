import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm } from 'app/components/Form';
import { inspectionsHelper } from 'app/api/helperServices';
import { View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { Loader } from 'app/components/Loader';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { saveFollowup } from 'app/actions/inspections';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    divider: {
        width: '100%',
        marginVertical: 10,
    },

    summaryContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 80,
        width: '100%',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
});

class FollowupForm extends React.PureComponent {
    static propTypes = {
        formDef: PropTypes.object,
        initialValues: PropTypes.object,
        formChangeHandler: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.form = createForm({ ...props.formDef, onInit: this.handleOnInit }, props.initialValues, props.formChangeHandler, this.handleFieldChange);
        // console.log('DynamicForm constructor');
    }
    handleOnInit = formProps => {
        this.formProps = formProps;
    };
    handleSave = () => {
        const { inspection } = this.props.inspection;
        this.props.dispatch(saveFollowup(inspection));
    };
    printReceipt = params => { };

    handleCancel = () => { this.props.backAction(); };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'followupAction') {
            if (newValue == 3) {
                const inspection = this.props.inspection;
                debugger;
                const violators = inspection.info.violators;
                let violationAmount = 0;
                violators.forEach(v => {
                    if (v.violations)
                        v.violations.map(key => {
                            violationAmount =
                                violationAmount + inspectionsHelper.getViolationAmount({ lawClauseIDs: [key], occurance: 1, discount: 0 });
                        });
                });
                this.formProps.change('amount', violationAmount.toString());
            }

            // this.formProps.change('duration', {});
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {
        const TheForm = this.form;
        const { inspection } = this.props;
        return (
            <View style={styles.container}>
                <TheForm
                    values={this.props.values}
                    currentInspectionVersion={this.props.currentInspectionVersion}
                    formProps={this.props.formProps}
                    editable={this.props.formDef.editable}
                />
                <Divider style={styles.divider} />
                <View style={styles.summaryContainer}>
                    <View style={styles.summaryItem}>
                        <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                            <Icon.Button
                                name="save"
                                borderRadius={25}
                                disabled={!isAllowedToSave || !editable}
                                style={[styles.button, saveButtonstyle]}
                                onPress={this.handleSave}
                            >
                                <Text style={saveTextstyle}>{strings('save')}</Text>
                            </Icon.Button>
                        </Loader>
                    </View>
                    <View style={styles.summaryItem}>
                        <Icon.Button name="cancel" borderRadius={25} style={[styles.button, styles.buttonNegative]} onPress={this.handleCancel}>
                            <Text style={styles.buttonText}>{strings('cancel')}</Text>
                        </Icon.Button>
                    </View>
                    <View style={styles.summaryItem}>
                        <Icon.Button
                            name="print"
                            borderRadius={25}
                            style={[styles.button, styles.buttonPositive]}
                            onPress={() => this.printReceipt({})}
                        >
                            <Loader loading={this.state.isPrinting} sprinnerSize={14}>
                                <Text style={styles.buttonText}>{strings('print')}</Text>
                            </Loader>
                        </Icon.Button>
                    </View>
                </View>
            </View>
        );
    };
}

export default FollowupForm;
