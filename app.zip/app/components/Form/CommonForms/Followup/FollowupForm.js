import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm } from 'app/components/Form';
import { inspectionsHelper } from 'app/api/helperServices';
import { View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { Loader } from 'app/components/Loader';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { ValidationHelper } from 'app/api/helperServices';
import { saveFollowup } from 'app/actions/inspections';
import { TASK_STARTED } from 'app/actions/inspections';
// import { shallowEqual } from 'app/api/helperServices';
import * as yup from 'yup';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryWhite',
    },
    divider: {
        width: '100%',
        marginVertical: 10,
    },

    summaryContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 80,
        width: '100%',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },

    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
});

class FollowupForm extends React.PureComponent {
    static propTypes = {
        formDef: PropTypes.object,
        initialValues: PropTypes.object,
        formChangeHandler: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.form = createForm(
            { ...props.formDef, onInit: this.handleOnInit, validations: props.validations },
            props.initialValues,
            this.handleFormChange,
            this.handleFieldChange,
            this.validateFollowup
        );

        this.state = { isAllowedToSave: false, error: {}, showPrintButton: true };
        this.initialValidateFollowup = this.initialValidateFollowup.bind(this);
        this.initialValidateFollowup();
        // console.log('DynamicForm constructor');
    }

    shouldComponentUpdate(nextProps, nextState) {
        // return shallowEqual(this.props, nextProps, this.state, nextState);
        return !this.shallowEqualState(this.state, nextState) || !this.shallowEqualWithoutReactElements(this.props, nextProps);
    }

    shallowEqualState = (thisState, nextState) => {
        return thisState === nextState;
    };

    shallowEqualWithoutReactElements = (thisProps, nextProps) => {
        let equals = false;
        if (thisProps === nextProps) {
            equals = true;
        } else if (typeof thisProps === 'object' && typeof nextProps === 'object') {
            equals = true;
            const propNames = new Set(Object.keys(thisProps), Object.keys(nextProps));
            for (const propName of propNames) {
                // if (propName == 'navigation' || propName == 'currentInspectionContainer') {
                // } else

                if (propName != 'formDef' && thisProps[propName] !== nextProps[propName] && !this.isReactElement(thisProps[propName])) {
                    // No need to check nextProps[propName] as well, as we know they are not equal
                    equals = false;
                    break;
                }
            }
        }
        return equals;
    };
    isReactElement = suspectedElement => {
        let isElem = false;
        if (React.isValidElement(suspectedElement)) {
            isElem = true;
        } else if (Array.isArray(suspectedElement)) {
            for (let i = 0, l = suspectedElement.length; i < l; i++) {
                if (React.isValidElement(suspectedElement[i])) {
                    isElem = true;
                    break;
                }
            }
        }
        return isElem;
    };

    handleOnInit = formProps => {
        this.formProps = formProps;
    };
    initialValidateFollowup = async () => {
        const validationSchemaShape = {};
        let errorlogs = {};
        this.props.formDef.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            } else {
                const { name, validationRule } = item;
                if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
            }
        });

        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const values = this.props.inspection.visits[currentVisitIndex].followupForm;
        const validationSchema = yup.object().shape(validationSchemaShape);
        try {
            await ValidationHelper.validate(values, validationSchema, this.validateFollowup);
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map(er => {
                errorlogs[er] = errors[er];
            });
        }

        return errorlogs;
    };
    validateFollowup = async (values, rErrors) => {
        let showPrintButton = true;
        if (values.followupAction == '2' && values.duration && !values.duration.selectedPeriod) {
            rErrors.duration = strings('durationValidation');
            //'Number of days Or Hours Should not be zero';
        }
        if (values.followupAction != '2' && values.followupAction != '3') showPrintButton = false;
        if (Object.getOwnPropertyNames(rErrors).length == 0) {
            this.setState({ isAllowedToSave: true, error: rErrors, showPrintButton });
        } else {
            if (rErrors.remarks) rErrors.remarks = strings('emptyRemarksValidation');
            if (rErrors.attachmentList) rErrors.attachmentList = strings('emptyAttachmentValidation');
            if (rErrors.followupAction) rErrors.followupAction = strings('emptyFollowupAction');

            this.setState({ isAllowedToSave: false, error: rErrors, showPrintButton });
        }
        // console.log(values);
        // console.log(rErrors);
        return rErrors;
    };
    handleSave = () => {
        const { isAllowedToSave } = this.state;
        if (isAllowedToSave) {
            const { inspection } = this.props.inspection;
            this.props.dispatch(saveFollowup(inspection));

            let currentVisitIndex = this.props.inspection.visits.length - 1;
            const taskId = this.props.inspection.visits[currentVisitIndex].taskId;

            this.props.dispatch({
                type: TASK_STARTED,
                payload: { taskId, refNumber: this.props.inspection.refNumber, status: 'completed' },
            });
        }
    };
    printReceipt = params => {
        const editable = this.props.formDef.editable;
        if (editable) this.handleSave();
    };

    handleCancel = () => {
        this.props.backAction();
    };
    handlePeriodNumberPickerChange = value => {
        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const currentValues = this.props.inspection.visits[currentVisitIndex].followupForm;
        let currentDuration = typeof currentValues['duration'] !== 'undefined' ? currentValues['duration'] : null;
        const duraionObj = { selectedPeriod: value };
        if (currentDuration && currentDuration.selectedPeriodType) {
            duraionObj.selectedPeriodType = currentDuration.selectedPeriodType;
        }
        this.formProps.change('duration', duraionObj);
    };

    handleChangePeriodType = value => {
        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const currentValues = this.props.inspection.visits[currentVisitIndex].followupForm;
        let currentDuration = typeof currentValues['duration'] !== 'undefined' ? currentValues['duration'] : null;
        const duraionObj = { selectedPeriodType: value };
        if (currentDuration && currentDuration.selectedPeriod) {
            duraionObj.selectedPeriod = currentDuration.selectedPeriod;
        }
        this.formProps.change('duration', duraionObj);
    };
    handleFormChange = async (values, dispatch, props, previousValues) => {
        this.props.formChangeHandler(values, dispatch, props, previousValues);
        const editable = this.props.formDef.editable;
        if (editable) {
            let currentVisitIndex = this.props.inspection.visits.length - 1;
            const taskId = this.props.inspection.visits[currentVisitIndex].taskId;

            this.props.dispatch({
                type: TASK_STARTED,
                payload: { taskId, refNumber: this.props.inspection.refNumber, status: 'InProgress' },
            });
            if (values.duration != previousValues.duration) this.initialValidateFollowup();
        }
    };
    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'followupAction') {
            if (newValue == 3) {
                const inspection = this.props.inspection;

                const violators = inspection.info.violators;
                let violationAmount = 0;
                violators.forEach(v => {
                    if (v.violations)
                        v.violations.map(key => {
                            violationAmount =
                                violationAmount + inspectionsHelper.getViolationAmount({ lawClauseIDs: [key], occurance: 1, discount: 0 });
                        });
                });
                this.formProps.change('amount', violationAmount.toString());
            }

            // this.formProps.change('duration', {});
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {
        // console.warn('FollowupForm rerender' + Math.random());
        const TheForm = this.form;
        const { inspection } = this.props;
        const { isAllowedToSave, showPrintButton } = this.state;
        const editable = this.props.formDef.editable;
        const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const saveTextstyle = isAllowedToSave && editable == true ? styles.buttonText : styles.buttonTextPositiveDisabled;
        const printButtonstyle = isAllowedToSave && showPrintButton ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const printTextstyle = isAllowedToSave && showPrintButton ? styles.buttonText : styles.buttonTextPositiveDisabled;
        return (
            <View style={styles.container}>
                <TheForm
                    values={this.props.values}
                    currentInspectionVersion={this.props.currentInspectionVersion}
                    formProps={this.formProps}
                    editable={editable}
                    handlePeriodNumberPickerChange={this.handlePeriodNumberPickerChange}
                    handleChangePeriodType={this.handleChangePeriodType}
                    validations={this.state.error}
                />
                <Divider style={styles.divider} />
                <View style={styles.summaryContainer}>
                    <View style={styles.summaryItem}>
                        <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                            <Icon.Button
                                name="save"
                                borderRadius={25}
                                disabled={!(isAllowedToSave && editable)}
                                style={[styles.button, saveButtonstyle]}
                                onPress={this.handleSave}
                            >
                                <Text style={saveTextstyle}>{strings('save')}</Text>
                            </Icon.Button>
                        </Loader>
                    </View>
                    <View style={styles.summaryItem}>
                        <Icon.Button name="cancel" borderRadius={25} style={[styles.button, styles.buttonNegative]} onPress={this.handleCancel}>
                            <Text style={styles.buttonText}>{strings('cancel')}</Text>
                        </Icon.Button>
                    </View>
                    {this.props.formDef.workflowConst != 'MimsDistortion' ? (
                        <View style={styles.summaryItem}>
                            <Icon.Button
                                name="print"
                                disabled={!(isAllowedToSave && showPrintButton)}
                                borderRadius={25}
                                style={[styles.button, printButtonstyle]}
                                onPress={() => this.printReceipt({})}
                            >
                                <Loader loading={inspection.creatingFlag} sprinnerSize={14}>
                                    <Text style={printTextstyle}>{strings('print')}</Text>
                                </Loader>
                            </Icon.Button>
                        </View>
                    ) : null}
                </View>
            </View>
        );
    };
}

export default FollowupForm;
