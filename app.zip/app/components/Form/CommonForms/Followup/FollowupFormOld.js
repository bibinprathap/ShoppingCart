import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm, IconButton, Loader, commonStyles } from 'app/components';
import { inspectionsHelper } from 'app/api/helperServices';
import { View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { ValidationHelper } from 'app/api/helperServices';
import { saveNewInspection, savefollowupLocalSuccess } from 'app/actions/inspections';
import { TASK_STARTED } from 'app/actions/inspections';
import alertsHelper from 'app/api/helperServices/alerts';
import { store, _state } from 'app/config/store';
import { connect } from 'react-redux';
import { shallowEqual } from 'app/api/helperServices';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { tasksTabLoad } from 'app/actions/generic';
import { attachmentsHelper } from 'app/api/helperServices';
import * as yup from 'yup';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryWhite',
    },
    distortionTypeContainer: {
        width: '100%',
        paddingStart: 10,
    },
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    summaryContainer: {
        flex: 1,

        justifyContent: 'flex-end',
        marginBottom: 36,
        flexDirection: 'row',
        maxHeight: 80,
        width: '100%',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    button: {
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 10,
    },
    buttonActive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
        fontFamily: '$primaryFontNormal',
    },
    validationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
    },
});

class FollowupForm extends Component {
    static propTypes = {
        formDef: PropTypes.object,
        initialValues: PropTypes.object,
        formChangeHandler: PropTypes.func,
    };

    constructor(props) {
        super(props);

        this.form = createForm(
            { ...props.formDef, onInit: this.handleOnInit, errorLogs: props.errorLogs, readOnly: props.readOnly ? props.readOnly : false },
            props.values,
            this.handleFormChange,
            this.handleFieldChange,
            this.validateFollowup
        );

        this.state = { isAllowedToSave: false, error: {}, showPrintButton: true };
        this.initialValidateFollowup = this.initialValidateFollowup.bind(this);

        if (!props.readOnly) this.initialValidateFollowup();
    }

    // shouldComponentUpdate(nextProps, nextState) {
    //     // return shallowEqual(this.props, nextProps, this.state, nextState);
    //     const shouldUpdate = !this.shallowEqualState(this.state, nextState) || !this.shallowEqualWithoutReactElements(this.props, nextProps);
    //     // if (shouldUpdate && nextProps.attachments != this.props.attachments) {
    //     //     this.initialValidateFollowup();
    //     // }
    //     return shouldUpdate;
    // }

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    // shallowEqualState = (thisState, nextState) => {
    //     return thisState === nextState;
    // };

    // shallowEqualWithoutReactElements = (thisProps, nextProps) => {
    //     let equals = false;
    //     if (thisProps === nextProps) {
    //         equals = true;
    //     } else if (typeof thisProps === 'object' && typeof nextProps === 'object') {
    //         equals = true;
    //         const propNames = new Set(Object.keys(thisProps), Object.keys(nextProps));
    //         for (const propName of propNames) {
    //             // if (propName == 'navigation' || propName == 'currentInspectionContainer') {
    //             // } else

    //             if (propName != 'formDef' && thisProps[propName] !== nextProps[propName] && !this.isReactElement(thisProps[propName])) {
    //                 // No need to check nextProps[propName] as well, as we know they are not equal
    //                 equals = false;
    //                 break;
    //             }
    //         }
    //     }
    //     return equals;
    // };
    // isReactElement = suspectedElement => {
    //     let isElem = false;
    //     if (React.isValidElement(suspectedElement)) {
    //         isElem = true;
    //     } else if (Array.isArray(suspectedElement)) {
    //         for (let i = 0, l = suspectedElement.length; i < l; i++) {
    //             if (React.isValidElement(suspectedElement[i])) {
    //                 isElem = true;
    //                 break;
    //             }
    //         }
    //     }
    //     return isElem;
    // };

    handleOnInit = formProps => {
        this.formProps = formProps;
    };
    initialValidateFollowup = async () => {
        const validationSchemaShape = {};
        let errorlogs = {};
        this.props.formDef.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            } else {
                const { name, validationRule } = item;
                if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
            }
        });

        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const values = this.props.inspection.visits[currentVisitIndex].followupForm;
        const validationSchema = yup.object().shape(validationSchemaShape);
        try {
            await ValidationHelper.validate(values, validationSchema, this.validateFollowup);
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map(er => {
                errorlogs[er] = errors[er];
            });
        }

        return errorlogs;
    };
    validateFollowup = async (values, rErrors) => {
        let showPrintButton = true;
        if (values.followupAction == '2' && values.duration && !values.duration.selectedPeriod) {
            rErrors.duration = strings('durationValidation');
            //'Number of days Or Hours Should not be zero';
        }
        if (values.followupAction != '2' && values.followupAction != '3') showPrintButton = false;
        if (Object.getOwnPropertyNames(rErrors).length == 0) {
            //let allowsave = true;
            // if (values.attachmentList && values.attachmentList.length > 0) {
            //     for (var a = 0; a <= values.attachmentList.length - 1; a++) {

            //         const theAttachment = _state.attachments.docs.find(att => att.mobileReferenceNumber == values.attachmentList[a]);
            //         if (theAttachment && theAttachment.uploaded === false) {
            //             rErrors.pendingUploads = strings('waitingForDocument');
            //             allowsave = false;
            //             // 'Waiting documents upload';
            //             break;
            //         }
            //     }
            // }
            this.setState({ isAllowedToSave: true, error: rErrors, showPrintButton });
        } else {
            if (rErrors.remarks) rErrors.remarks = strings('emptyRemarksValidation');
            if (rErrors.attachmentList) rErrors.attachmentList = strings('emptyAttachmentValidation');
            if (rErrors.followupAction) rErrors.followupAction = strings('emptyFollowupAction');

            this.setState({ isAllowedToSave: false, error: rErrors, showPrintButton });
        }

        return rErrors;
    };

    handleSave = async () => {
        const { isAllowedToSave } = this.state;
        this.props.handleSave({ isAllowedToSave });
    };

    handleCancel = () => {
        this.props.backAction();
    };
    handlePeriodNumberPickerChange = value => {
        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const currentValues = this.props.inspection.visits[currentVisitIndex].followupForm;
        let currentDuration = typeof currentValues['duration'] !== 'undefined' ? currentValues['duration'] : null;
        const duraionObj = { selectedPeriod: value };
        if (currentDuration && currentDuration.selectedPeriodType) {
            duraionObj.selectedPeriodType = currentDuration.selectedPeriodType;
        }
        this.formProps.change('duration', duraionObj);
    };

    handleChangePeriodType = value => {
        let currentVisitIndex = this.props.inspection.visits.length - 1;
        const currentValues = this.props.inspection.visits[currentVisitIndex].followupForm;
        let currentDuration = typeof currentValues['duration'] !== 'undefined' ? currentValues['duration'] : null;
        const duraionObj = { selectedPeriodType: value };
        if (currentDuration && currentDuration.selectedPeriod) {
            duraionObj.selectedPeriod = currentDuration.selectedPeriod;
        }
        this.formProps.change('duration', duraionObj);
    };
    handleFormChange = async (values, dispatch, props, previousValues) => {
        this.props.formChangeHandler(values, dispatch, props, previousValues);
        const editable = this.props.formDef.editable;
        if (editable) {
            let currentVisitIndex = this.props.inspection.visits.length - 1;
            const taskId = this.props.inspection.visits[currentVisitIndex].taskId;

            this.props.dispatch({
                type: TASK_STARTED,
                payload: { taskId, refNumber: this.props.inspection.refNumber, status: 'InProgress' },
            });
            if (
                values.remarks != previousValues.remarks ||
                values.attachmentList != previousValues.attachmentList ||
                values.isResolved != previousValues.isResolved ||
                values.duration != previousValues.duration
            )
                this.initialValidateFollowup();
        }
    };
    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'followupAction') {
            if (newValue == 3) {
                const inspection = this.props.inspection;

                const violators = inspection.violators;
                let violationAmount = 0;
                violators.forEach(v => {
                    if (v.violations)
                        v.violations.map(key => {
                            violationAmount =
                                violationAmount + inspectionsHelper.getViolationAmount({ lawClauseIDs: [key], occurance: 1, discount: 0 });
                        });
                });
                this.formProps.change('amount', violationAmount.toString());
            }

            // this.formProps.change('duration', {});
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {
        const TheForm = this.form;
        const { inspection, refNumber, visitIndex, formName, selectedVisit, readOnly } = this.props;
        // const inspection = inspectionsHistory[refNumber].inspection;
        const { isAllowedToSave, showPrintButton } = this.state;
        const editable = this.props.formDef.editable;
        const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonActive : styles.buttonDisabled;
        const printButtonstyle = isAllowedToSave && showPrintButton ? styles.buttonActive : styles.buttonDisabled;
        const printTextstyle = isAllowedToSave && showPrintButton ? styles.buttonText : styles.buttonTextPositiveDisabled;
        let applicationNumber = selectedVisit.applicationNumber;
        let heightstyle = { flex: 1, minHeight: 740 };
        if (readOnly) heightstyle = { flex: 1 };

        return (
            <View style={styles.container}>
                <View style={heightstyle}>
                    {applicationNumber && applicationNumber != 'NA' ? (
                        <>
                            <View style={styles.distortionTypeContainer}>
                                <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('applicationNumber')}</Text>
                                <Text style={[commonStyles.generalText, !applicationNumber ? commonStyles.mutedText : null]}>
                                    {applicationNumber || ''}
                                </Text>
                            </View>
                            <Divider style={commonStyles.divider} />
                        </>
                    ) : null}
                    <TheForm
                        values={inspection.visits[visitIndex][formName]}
                        currentInspectionVersion={this.props.currentInspectionVersion}
                        formProps={this.props.formProps}
                        editable={editable}
                        readOnly={readOnly}
                        handlePeriodNumberPickerChange={this.handlePeriodNumberPickerChange}
                        handleChangePeriodType={this.handleChangePeriodType}
                        errorLogs={this.state.error}
                    />
                    <Divider style={styles.divider} />
                    {/* {this.state.error && this.state.error.pendingUploads && (
                    <Text style={styles.validationMessageText}>{this.state.error.pendingUploads} </Text>
                )} */}
                </View>
                <View style={[styles.summaryContainer]}>
                    {readOnly ? null : (
                        <View style={styles.summaryItem}>
                            <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="content-save"
                                    borderRadius={25}
                                    disabled={!(isAllowedToSave && editable)}
                                    style={[styles.button, saveButtonstyle]}
                                    onPress={this.handleSave}
                                >
                                    <Text style={styles.buttonText}>{strings('save')}</Text>
                                </IconButton>
                            </Loader>
                        </View>
                    )}

                    {/* {this.props.formDef.workflowConst != 'MimsDistortion' && (isAllowedToSave && showPrintButton) ? (
                        <View style={styles.summaryItem}>
                            <Icon.Button
                                name="print"
                                disabled={!(isAllowedToSave && showPrintButton)}
                                borderRadius={25}
                                style={[styles.button, printButtonstyle]}
                                onPress={() => this.printReceipt({})}
                            >
                                <Loader loading={inspection.creatingFlag} sprinnerSize={14}>
                                    <Text style={printTextstyle}>{strings('print')}</Text>
                                </Loader>
                            </Icon.Button>
                        </View>
                    ) : null} */}
                </View>
            </View>
        );
    };
}
export default FollowupForm;

// mapStateToProps = state => {
//     return {
//         inspectionsHistory: state.inspections.history,
//     };
// };

// export default connect(mapStateToProps)(FollowupForm);
