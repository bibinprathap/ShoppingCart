import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager, TouchableOpacity, Image } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Icon, AttachmentList, Switch, commonStyles, SimpleViolatorInfo, SimpleItemInfo, Modal } from 'app/components';

import { Attachments, ImageDialog, ViolationActionTypes as ViolationActionTypesComponent } from 'app/screens';
import { infoChanged, saveNewInspection } from 'app/actions/inspections';
import { ValidationHelper, lookup } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import { ViolationActionReview } from 'app/components/Preview/ViolationItemReview';
import { TASK_STARTED } from 'app/actions/inspections';
import * as yup from 'yup';
import { tasksTabLoad } from 'app/actions/generic';

const api = new AppApi();

const emptyFollowUpForm = {
    amount: '',
    selectedPeriod: '',
    selectedPeriodType: 'day',
    remarks: '',
    attachmentList: [],
    attachmentModalVisible: false,
    isResolved: false,
    selectedAttachment: null,
    errorLogs: {},
    violationActionTypes: [],
    followupAction: null,
};

const showContractDetailsFields = ['community', 'permitTypeName', 'permitNumber', 'stopNumber', 'rentContractStartDate', 'rentContractEndDate'];

class FoodTruckAndOutdoorFollowUp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            attachmentList: [],
            ...emptyFollowUpForm,
            ...props.initialValue,
            violationActionTypes: props.violationActionTypes,
            showImageDialog: false,
            currentImageSource: null,
        };

        this.isSubmitable = this.isSubmitable.bind(this);
        this.renderCustomActions = this.renderCustomActions.bind(this);
        this.handleActionChange = this.handleActionChange.bind(this);
    }
    updateFollowupState = async newState => {
        let formValue = { ...this.state, ...newState };
        const remarksRequiredMessage = strings('remarks') + ' ' + strings('isRequired');
        const followupValidationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup
                .string()
                .nullable()
                .required(remarksRequiredMessage),
        };
        let errorLogs = {};
        try {
            await ValidationHelper.validate(formValue, yup.object().shape(followupValidationSchema));
        } catch (errors) {
            //            return;
            Object.getOwnPropertyNames(errors).map(er => {
                errorLogs[er] = errors[er];
            });
        }
        newState.errorLogs = errorLogs;
        this.setState(newState, () => {
            const { visitIndex } = this.props;
            this.props.dispatch(infoChanged('followupForm', this.state, visitIndex));
            this.isSubmitable();
        });
    };
    componentDidMount() {
        if (this.isSubmitable) this.isSubmitable();
    }
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleOnAdd = newAttachment => {
        const { attachmentList } = this.state;
        const newAttachmentsArray = attachmentList ? attachmentList.slice() : [];
        newAttachmentsArray.push(newAttachment);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleAttachmentRemoved = doc => {
        const { attachmentList } = this.state;
        const currentAttachments = attachmentList;
        const newAttachmentsArray = _.without(currentAttachments, doc);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleCameraPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateFollowupState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );

    handleActionChange = callProps => {
        const { params, reset } = callProps;
        this.updateFollowupState({
            amount: params.violationAmount != undefined ? params.violationAmount : this.state.amount,
            followupAction: params.selectedActionType != undefined ? params.selectedActionType : this.state.followupAction,
            selectedPeriod: params.selectedPeriod != undefined ? params.selectedPeriod : this.state.selectedPeriod,
            selectedPeriodType: params.selectedPeriodType != undefined ? params.selectedPeriodType : this.state.selectedPeriodType,
            violationActionTypes: (this.props && this.props.violationActionTypes) || [],
        });
    };

    isSubmitable = () => {
        const { errorLogs, attachmentList, remarks } = this.state;
        const isAllowedToSave =
            Object.getOwnPropertyNames(errorLogs).length == 0 && attachmentList && attachmentList.length > 0 && remarks.length > 0;
        if (this.props.isSubmitable) this.props.isSubmitable({ isAllowedToSave });
    };

    showZoomableImage = currentImageSource => {
        this.setState({ showImageDialog: true, currentImageSource });
    };

    renderCustomActions = ({ item }) => {
        return (
            <View>
                {item.imageURL && (
                    <TouchableOpacity onPress={() => this.showZoomableImage({ uri: item.imageURL })}>
                        <Image source={{ uri: item.imageURL }} style={styles.contractImage} />
                    </TouchableOpacity>
                )}
            </View>
        );
    };
    handleImageDialogOnRequestClose = item => {
        this.setState({ showImageDialog: false });
    };

    showZoomableImage = currentImageSource => {
        this.setState({ showImageDialog: true, currentImageSource });
    };

    render = () => {
        const {
            attachmentList,
            remarks,
            errorLogs,
            isResolved,
            violationActionTypes,
            followupAction,
            showImageDialog,
            currentImageSource,
            amount,
            selectedPeriod,
            selectedPeriodType,
        } = this.state;

        const { editable, inspection, readOnly } = this.props;

        const customFieldContainerStyles = [styles.fieldContainerShadowed, styles.customFieldRowContainer, { padding: 10 }];
        let actionItem = inspectionsHelper.findViolationAction({
            violationActionTypes: violationActionTypes,
            selectedActionType: followupAction,
        });
        const readOnlyRtlStyles = I18nManager.isRTL
            ? { textAlign: 'right', alignSelf: 'flex-start' }
            : { textAlign: 'left', alignSelf: 'flex-start' };

        let actionItemDetails = {};
        if (readOnly) {
            actionItemDetails = {
                amount: this.props.amount,
                selectedPeriod: this.props.selectedPeriod,
                selectedPeriodType: this.props.selectedPeriodType,
            };
        }

        let { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);

        return (
            <View style={styles.container}>
                <ImageDialog
                    isVisible={showImageDialog}
                    source={currentImageSource}
                    onRequestClose={this.handleImageDialogOnRequestClose}
                    title={strings('back')}
                />

                <View style={styles.fieldrow}>
                    <View style={customFieldContainerStyles}>
                        <Switch
                            editable={editable}
                            onChange={this.handleFieldChange.bind(this, 'isResolved')}
                            value={isResolved}
                            label={strings('isItResolved')}
                            iconProps={{ name: 'shield-check', type: 'MaterialCommunityIcons', size: 24 }}
                        />
                    </View>
                </View>

                {!isResolved ? (
                    <>
                        {actionItem && readOnly ? (
                            <View style={styles.ViolationActionContainer}>
                                <ViolationActionReview
                                    selectedActionTypeConst={actionItem.constant}
                                    amount={amount}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                ></ViolationActionReview>
                            </View>
                        ) : null}
                    </>
                ) : null}

                {editable && !isResolved && violationActionTypes && violationActionTypes.length > 0 && (
                    <View style={styles.actionTypesWrapper}>
                        <ViolationActionTypesComponent
                            onActionChange={this.handleActionChange}
                            editable={editable}
                            violationActionTypesLoading={false}
                            violationActionTypesSuccess={true}
                            violationActionTypes={violationActionTypes}
                            currentVisitIndex={currentVisitIndex}
                            selectedActionType={followupAction}
                            selectedPeriod={parseInt(selectedPeriod || 0)}
                            selectedPeriodType={selectedPeriodType}
                        />
                    </View>
                )}

                {errorLogs.followupAction ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('actionType') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {errorLogs.selectedPeriod ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('selectedPeriod') + ' ' + strings('isRequired')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer} />
                    </View>
                </View>

                <View style={styles.fieldContainerAttachement}>
                    <Modal
                        animationType="slide"
                        transparent={false}
                        visible={this.state.attachmentModalVisible}
                        onRequestClose={this.toggleAttachmentDialog}
                    >
                        <Attachments
                            attachments={attachmentList}
                            onAdd={this.handleOnAdd}
                            onRemove={this.handleAttachmentRemoved}
                            onClose={this.handleOnClose}
                            selectedAttachment={this.state.selectedAttachment}
                            editable={editable}
                            attachmentModalVisible={this.state.attachmentModalVisible}
                        />
                    </Modal>
                    {!attachmentList || !attachmentList.length ? (
                        <View style={styles.outerContainerNoAttachment}>
                            {editable ? <View style={[styles.fieldContainerAttachement, { flex: 1 }]}>{this.renderAddPictureButton()}</View> : null}
                        </View>
                    ) : (
                        <View style={[styles.outerContainerNoAttachment]}>
                            <View style={styles.outerContainerWithAttachment}>
                                <AttachmentList attachments={attachmentList} editable={editable} onPress={this.handleThumbnailPressed} />
                                {editable ? <View style={styles.buttonWithAttachmentsContainer}>{this.renderAddPictureButton()}</View> : null}
                            </View>
                        </View>
                    )}
                </View>

                {errorLogs.attachmentList ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={styles.fieldrow}>
                            {readOnly ? (
                                <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                    <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{remarks}</Text>
                                </View>
                            ) : (
                                <View style={[styles.fieldContainer]}>
                                    <TextInput
                                        style={styles.input}
                                        placeholder={strings('newRemarks')}
                                        value={remarks}
                                        editable={editable}
                                        onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                        autoCorrect={false}
                                        direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                        autoCapitalize="sentences"
                                        autoFocus={false}
                                        multiline={true}
                                        textAlignVertical={'top'}
                                    />
                                </View>
                            )}
                        </View>
                    </View>
                </View>
                {errorLogs.remarks ? <Text style={[commonStyles.ValidationMessageText, styles.error]}>{errorLogs.remarks}</Text> : null}
            </View>
        );
    };
}
export default FoodTruckAndOutdoorFollowUp;
