import React, { Component } from 'react';
import { View, TextInput, ScrollView, I18nManager, FlatList, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { ViolationList, AttachmentListWithDialog } from 'app/screens';
import { commonStyles } from 'app/components';
import { inspectionsHelper } from 'app/api/helperServices';
import { valueChanged } from 'app/actions/inspections';
import { infoChanged } from 'app/actions/inspections';
import { RadioButton } from 'react-native-paper';

class GeneralAppearanceVehicle extends Component {
    constructor(props) {
        super(props);
        const vals = props.initialValue || props.values;
        const stateFromStore = { attachmentList: [], ...vals };
        this.state = { ...stateFromStore, selectedIds: [], showViolationTypes: true };
    }

    componentDidMount() {
        const { needValidation } = this.props;
        if (needValidation) {
            const { errorLogs, changed } = this.runValidation(this.state, true);
        }
    }

    async componentDidUpdate() {
        const { needValidation } = this.props;
        if (needValidation === true) {
            const { errorLogs, changed } = await this.runValidation(this.state);

            if (!!changed && errorLogs) {
                this.setState({ errorLogs });
            }
        }
    }

    updateState = newState => {
        const { dispatch, visitIndex, formName } = this.props;
        this.setState(newState, () => {
            const { attachmentList, remarks, selectedActionTypeConst } = this.state;
            const stateToStore = { attachmentList, remarks, selectedActionTypeConst };
            stateToStore.isResolved = false;
            delete stateToStore.errorLogs;

            dispatch(infoChanged(formName, stateToStore, visitIndex));
        });
    };

    //Todo: move it to the validation helper service
    valuesCompare = (obj1, obj2) => {
        if (!obj1 || !obj2) return false;
        let areEqual = true;
        const keys1 = Object.keys(obj1);
        const keys2 = Object.keys(obj2);

        const numberOfKeys1 = (keys1 && keys1.length) || 0;
        const numberOfKeys2 = (keys2 && keys2.length) || 0;
        if (numberOfKeys1 != numberOfKeys2) return false;

        if (numberOfKeys1 > 0 && numberOfKeys2 > 0) {
            for (var k = 0; k < keys1.length; k++) {
                if (obj1[keys1[k]] !== obj2[keys1[k]]) {
                    areEqual = false;
                    break;
                }
            }
        }
        return areEqual;
    };

    runValidation = async (validationState, setTheState) => {
        const { errorLogs: oldErrorLogs } = validationState;
        const { inspection } = this.props;
        const errorLogs = await inspectionsHelper.validateAbandonedVehicle(validationState, inspection);

        const errorLogsAreEqual = this.valuesCompare(oldErrorLogs, errorLogs);

        if (!errorLogsAreEqual && setTheState === true) {
            setImmediate(() => {
                this.setState({ errorLogs });
            });
        }
        return { errorLogs, changed: !errorLogsAreEqual };
    };

    handleFieldChange = async (name, value) => {
        const newState = { [name]: value };
        this.updateState(newState);
    };

    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateState(newState);
    };
    onViolatorRemoved = () => {
        // this.setState({ showViolationTypes: true });
    };
    onViolatorSelected = () => {
        this.setState({ showViolationTypes: false });
    };
    handleOnActionChange = callProps => {
        const { params = {}, reset } = callProps;

        this.updateState({ selectedActionTypeConst: params.selectedActionTypeConst });
    };

    getViolationItems = inspection => {
        const { currentVisitIndex, currentVisit } = inspectionsHelper.getCurrentVisit(inspection);
        const currentVisitCheckListValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].values : undefined;
        const violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);
        return violationItems;
    };
    getViolationTypes = (inspection, violationTypes) => {
        const newViolationTypes = [];
        inspection.inspectionTypeDetail.inspectionTypeCheckItems.map(c => {
            c.violationTypeIds.map(violationTypeId => {
                const violationst = violationTypes.find(v => v.violationTypeId == violationTypeId);
                newViolationTypes.push({ ...violationst, inspTypeCheckItemId: c.inspTypeCheckItemId });
                return violationTypeId;
            });
            return c;
        });
        return newViolationTypes;
    };

    onPressItem = item => {
        const value = {
            checkItemId: item.violationTypeId,
            inspTypeCheckItemId: item.inspTypeCheckItemId,
            violationTypeIds: [item.violationTypeId],
            possibleViolatorTypes: item.violatorTypes,
            selectedOption: 'fixedViolation',
        };
        this.props.dispatch(
            valueChanged({
                visitIndex: this.props.visitIndex || 0,
                newValues: [value],
            })
        );
        //this.props.onSelect(item);
        const selectedIds = [item.violationTypeId];
        this.setState({ selectedIds });
    };

    renderItem = ({ item }) => {
        const mappedItem = item;
        return (
            <TouchableOpacity onPress={this.onPressItem.bind(this, mappedItem)} key={mappedItem.violationTypeId} style={styles.itemWrapper}>
                <RadioButton
                    color="#454F63"
                    onPress={this.onPressItem.bind(this, mappedItem)}
                    status={this.state.selectedIds.indexOf(mappedItem.violationTypeId) !== -1 ? 'checked' : 'unchecked'}
                />
                <Text style={styles.itemDetails}>{localeProperty(mappedItem, 'description') || ''}</Text>
            </TouchableOpacity>
        );
    };

    render() {
        const { dispatch, inspection, editable, formName, readOnly, currentInspectionVersion, violationTypes } = this.props;
        const displaySource = this.props.readOnly ? this.props.values : this.state;
        const { attachmentList, remarks } = displaySource || {};
        let errorLogs = this.props.errorLogs || {};
        const violationItems = this.getViolationItems(inspection);

        const source = this.getViolationTypes(inspection, violationTypes);

        const readOnlyRtlStyles = I18nManager.isRTL
            ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
            : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };

        return (
            <View style={{ marginVertical: 20, flex: 1 }} key={{ formName }} key={this.props.key}>
                {!readOnly && this.state.showViolationTypes ? (
                    <ScrollView style={{ maxHeight: 300 }}>
                        <View style={styles.fieldrowViolationType}>
                            <View style={styles.labelContainer}>
                                <Text style={styles.label}> {strings('selectaviolation')}</Text>
                            </View>
                        </View>
                        <View style={{ flex: 1 }}>
                            <FlatList
                                initialNumToRender={25}
                                data={source}
                                extraData={this.state}
                                keyExtractor={(item, index) => index.toString()}
                                renderItem={this.renderItem}
                                ListFooterComponent={() => <View style={{ height: 60 }} />}
                            />
                        </View>
                    </ScrollView>
                ) : null}

                <View style={{ flex: 1 }} key={this.props.key}>
                    {!readOnly && (
                        <ViolationList
                            dispatch={dispatch}
                            inspection={inspection}
                            editable={editable}
                            violationItems={violationItems}
                            onViolatorSelected={this.onViolatorSelected}
                            onViolatorRemoved={this.onViolatorRemoved}
                            onActionChange={this.handleOnActionChange}
                        />
                    )}

                    <View style={styles.container}>
                        <View style={styles.fieldrow}>
                            <View style={styles.labelContainer}>
                                <Text style={styles.label}> {strings('attachments')}</Text>
                                <View style={styles.fieldContainer}>
                                    <AttachmentListWithDialog
                                        editable={editable}
                                        onAdd={this.handleOnAddAttachment}
                                        onRemove={this.handleOnRemoveAttachment}
                                        attachments={attachmentList}
                                    />
                                </View>
                            </View>
                        </View>
                        {errorLogs.attachmentList && (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                {strings('attachments') + ' ' + strings('isRequired')}
                            </Text>
                        )}
                        <View style={styles.fieldrow}>
                            <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                                <Text style={styles.label}> {strings('remarks')}</Text>
                                {readOnly ? (
                                    <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                        <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{remarks}</Text>
                                    </View>
                                ) : (
                                    <View style={[styles.fieldContainer]}>
                                        <TextInput
                                            style={styles.input}
                                            placeholder={strings('newRemarks')}
                                            value={remarks}
                                            editable={editable}
                                            onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                            autoCorrect={false}
                                            direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                            autoCapitalize="sentences"
                                            //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                            //autoFocus={true}
                                            multiline={true}
                                            textAlignVertical={'top'}
                                        />
                                    </View>
                                )}
                            </View>
                        </View>
                        {errorLogs.remarks && (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                        )}
                    </View>
                </View>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        violationTypes: state.masterdata.violationTypes,
    };
};

export default connect(mapStateToProps)(GeneralAppearanceVehicle);

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingHorizontal: 8,
    },
    fieldrow: { flex: 1, flexDirection: 'row', marginVertical: 10 },
    fieldrowViolationType: { flex: 1, flexDirection: 'row', marginVertical: 3 },
    labelContainer: {
        flex: 1,
        // flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    labelContainerColumnStart: {
        flex: 4,
        marginStart: 5,
    },
    labelContainerColumnEnd: {
        flex: 4,
        marginEnd: 5,
    },
    fieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        // marginHorizontal: 10,
        marginTop: 5,
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        // maxWidth: 100,
        // minWidth: 120,
        justifyContent: 'flex-start',
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,

        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    fieldContainerPicker: {
        minHeight: 45,
        backgroundColor: '#ffffff',
        elevation: 1,
        borderRadius: 4,
    },
    picker: {
        height: 50,
        width: '100%',
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        color: '$primaryDarkTextColor',

        borderRadius: 4,
        elevation: 1,
    },
    valueReadOnlyText: {
        fontSize: 12,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        color: '$primaryDarkTextColor',
    },
    error: {
        paddingHorizontal: 10,
        marginBottom: 10,
        marginStart: 8,
    },
    itemWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginBottom: 2,
    },
    itemDetails: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXXS',
    },
    wrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primaryWhite',
    },
});
