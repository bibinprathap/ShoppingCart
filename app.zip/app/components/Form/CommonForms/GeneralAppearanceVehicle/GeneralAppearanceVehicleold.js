import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { connect } from 'react-redux';
import { localeProperty } from 'app/config/i18n/i18n';
import { createForm } from 'app/components/Form';
import styles from './styles';
import formConfigTemplate from './config';
import AppApi from 'app/api/real';
const api = new AppApi();

class GeneralAppearanceVehicle extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
        editable: PropTypes.bool,
    };

    constructor(props) {
        super(props);
        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            errorLogs: props.errorLogs,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }

    handleOnInit = formProps => (this.formProps = formProps);

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;

        //pass on to the host control
        if (name == 'isCritical') {
            if (newValue) {
                this.formProps.change('duration', { selectedPeriodType: 'hour', selectedPeriod: 0 });
            } else {
                this.formProps.change('duration', { selectedPeriodType: 'day', selectedPeriod: 1 });
            }
        }
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    handlePeriodNumberPickerChange = value => {
        let currentDuration = typeof this.props.currentValues['duration'] !== 'undefined' ? this.props.currentValues['duration'] : null;
        const duraionObj = { selectedPeriod: value };
        if (currentDuration && currentDuration.selectedPeriodType) {
            duraionObj.selectedPeriodType = currentDuration.selectedPeriodType;
        }
        this.formProps.change('duration', duraionObj);
    };

    handleChangePeriodType = value => {
        let currentDuration = typeof this.props.currentValues['duration'] !== 'undefined' ? this.props.currentValues['duration'] : null;
        const duraionObj = { selectedPeriodType: value };
        if (currentDuration && currentDuration.selectedPeriod) {
            duraionObj.selectedPeriod = currentDuration.selectedPeriod;
        }
        this.formProps.change('duration', duraionObj);
    };

    render = () => {
        const TheForm = this.form;
        return (
            <TheForm
                values={this.props.values}
                editable={this.props.editable}
                handlePeriodNumberPickerChange={this.handlePeriodNumberPickerChange}
                handleChangePeriodType={this.handleChangePeriodType}
                errorLogs={this.props.errorLogs}
            />
        );
    };
}

const mapStateToProps = state => {
    const initialValues = (state.form['generalAppearanceVehicleInfo'] && state.form['generalAppearanceVehicleInfo'].initialValues) || {};
    const currentValues = (state.form['generalAppearanceVehicleInfo'] && state.form['generalAppearanceVehicleInfo'].values) || {};
    return {
        initialValues,
        currentValues,
    };
};

export default connect(mapStateToProps)(GeneralAppearanceVehicle);
