export default config = {
    name: 'abandonedVehicleInfo',
    titleE: 'Details of the General Appearance - vehicle',
    titleA: 'تفاصيل المظهر العام',
    showFormTitle: true,
    collapsible: false,
    showLabels: true,
    debounce: 500,
    fields: [
        {
            name: 'fieldGroup8',
            type: 'fieldGroup',
            showFormTitle: true,
            collapsible: false,
            showLabels: true,
            fields: [
                {
                    name: 'attachmentList',
                    type: 'attachmentList',
                    labelE: 'Attachments',
                    labelA: 'مرفقات',
                    validationRule: ['array', 'required', 'nullable'],
                },
            ],
        },
        {
            name: 'fieldGroup9',
            type: 'fieldGroup',
            showFormTitle: true,
            collapsible: false,
            showLabels: true,
            fields: [
                {
                    name: 'remarks',
                    type: 'text',
                    labelE: 'Remarks',
                    labelA: 'ملاحظات',
                    placeholderE: 'Remarks',
                    placeholderA: 'ملاحظات',
                    maxLength: 200,
                    multiline: true,
                    mode: 'flat',
                    debounce: 500,
                    validationRule: ['string', 'required'],
                },
            ],
        },
    ],
};
