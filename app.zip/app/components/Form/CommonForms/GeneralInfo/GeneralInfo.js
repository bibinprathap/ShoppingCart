import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm } from 'app/components';
import formConfigTemplate from './config';
import { shallowEqual } from 'app/api/helperServices';

class GeneralInfoForm extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
    };

    constructor(props) {
        super(props);
        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            readOnly: props.readOnly,
            editable: props.editable,
            errorLogs: props.errorLogs,
            hideBorder: true,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }
    //CustomValidation Example
    // checkRemarks = async (values, errorLogs) => {
    //     const res = await new Promise((resolve, reject) => {
    //         if (values.remarks.indexOf('dist') > -1) return resolve();
    //         else {
    //             errorLogs.remarks = (errorLogs.remarks || '') + '  Should include Distortion word in remarks';
    //             return reject();
    //         }
    //     });
    // };
    handleOnInit = formProps => (this.formProps = formProps);

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (this.props.onFieldChange) this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    render = () => {
        const TheForm = this.form;

        return (
            <TheForm
                currentInspectionVersion={this.props.currentInspectionVersion}
                values={this.props.values}
                formProps={this.props.formProps}
                errorLogs={this.props.errorLogs}
                editable={this.props.editable}
            />
        );
    };
}

export default GeneralInfoForm;
