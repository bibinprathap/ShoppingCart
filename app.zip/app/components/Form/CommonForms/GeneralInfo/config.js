export default {
    name: 'generalInfoForm',
    titleE: 'General Information',
    titleA: 'معلومات عامة',
    showFormTitle: true,
    collapsible: true,
    showLabels: true,
    fields: [
        {
            name: 'fieldGroup1',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'remarks',
                    type: 'text',
                    labelE: 'Remarks',
                    labelA: 'ملاحظات',
                    placeholderE: 'Remarks',
                    placeholderA: 'ملاحظات',
                    maxLength: 200,
                    multiline: true,
                    mode: 'flat',
                    debounce: 500,
                    validationRule: ['string', 'required'],
                },
            ],
        },
    ],
};
