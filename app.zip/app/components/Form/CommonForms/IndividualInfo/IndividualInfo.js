import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { strings } from 'app/config/i18n/i18n';
import { createForm } from 'app/components';
import formConfigTemplate from './config';
import IndividualInfoTitle from './IndividualInfoTitle';
import AppApi from 'app/api/real';
import { shallowEqual } from 'app/api/helperServices';
const api = new AppApi();
const initialIntegrationData = { running: false };

//Todo: Integrate with EID Reader, (REST API?), or read from the MRZ of the emirates ID photo.
class IndividualInfoForm extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
    };
    onAccept = data => {
        this.setState(
            {
                setByScan: true,
                integrationData: { ...this.state.integrationData, running: false, success: true, message: strings('integrationSuccessMessageMOI') },
            },
            obj => {
                Object.keys(data).forEach(key => {
                    this.formProps.change(key, data[key]);
                });
            }
        );
    };
    onError = e => {
        this.setState({ integrationData: { ...this.state.integrationData, running: false } });
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    state = { integrationData: initialIntegrationData, setByScan: false };
    constructor(props) {
        super(props);
        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,

            onInit: this.handleOnInit,
            editable: props.editable,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            errorLogs: props.errorLogs,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
        this.onAccept = this.onAccept.bind(this);
        this.onError = this.onError.bind(this);
    }

    handleOnInit = formProps => (this.formProps = formProps);

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    clearIntegratedValues = () => {
        //todo: run this dynamically based on config
        this.formProps.change('expiryDate', '');
        this.formProps.change('birthDate', '');
        this.formProps.change('nameE', '');
        this.formProps.change('nameA', '');
        this.formProps.change('nationality', '');
        this.formProps.change('birthDate', '');
    };
    handleFieldChange = async (event, newValue, previousValue, name) => {
        //sample dummy emirates id: Raj = 784198483979807, Raheel = 784197912345671

        if (newValue === previousValue) return;
        if (name == 'emiratesId') {
            if (this.state.setByScan) {
                this.setState({ setByScan: false });
            } else {
                if (newValue.length !== 12) {
                    this.clearIntegratedValues();
                    if (this.state.integrationData && this.state.integrationData.running == true) {

                        this.setState({ integrationData: initialIntegrationData });
                    }
                    return;
                } else {
                    this.setState({ integrationData: { running: true, message: strings('integrationProgressMessageMOI') } });
                    try {
                        //todo: show loading spinner in companyName field
                        this.clearIntegratedValues();
                        const result = await api.getPersonProfile(`784${newValue}`);
                        //todo: run this dynamically based on config
                        this.formProps.change('expiryDate', result.identificationExpiryDate || '');
                        this.formProps.change('birthDate', result.birthDate || '');
                        this.formProps.change('nameE', result.customerNameE || '');
                        this.formProps.change('nameA', result.customerNameA || '');
                        this.formProps.change('nationality', result.nationalityNameE || '');
                        this.formProps.change('birthDate', result.birthDate || '');
                        this.formProps.change('mobileNumber', result.mobile || '');
                        this.setState({ integrationData: { running: false, success: true, message: strings('integrationSuccessMessageMOI') } });
                        /*
                    todo: hide the spinner and disable the companyName field because 
                          API call was a success, whatever name has been returned by
                          the API is the correct name
                    */
                    } catch (e) {
                        if (!e.isCancel) {
                            this.clearIntegratedValues();
                            this.setState({
                                integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageMOI') },
                            });
                            /*
                    todo: if license number is invalid, set error on licenseNumber
                          if it is network error, or exception on the server, then 
                          enable the company name field so user can enter value directly.
                    */

                        }
                    }
                }
            }
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {

        const { currentInspectionVersion } = this.props;
        const TheForm = this.form;
        return (
            <TheForm
                formProps={this.props.formProps}
                values={this.props.values}
                //currentInspectionVersion={currentInspectionVersion}
                editable={this.props.editable}
                errorLogs={this.props.errorLogs}
                integrationData={this.state.integrationData}
                renderTitle={
                    this.props.readonly
                        ? () => null
                        : () => (
                              <IndividualInfoTitle
                                  editable={this.props.editable}
                                  formTitle={this.props.formTitle}
                                  flashOn={this.props.flashOn}
                                  onAccept={this.onAccept}
                                  onError={this.onError}
                                  dispatch={this.props.dispatch}
                              />
                          )
                }
            />
        );
    };
}

export default IndividualInfoForm;
