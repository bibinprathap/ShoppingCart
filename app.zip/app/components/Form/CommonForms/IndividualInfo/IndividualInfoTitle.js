import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Modal } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { withNavigation } from 'react-navigation';
import { strings } from 'app/config/i18n/i18n';
import { IdScan } from 'app/screens/idScan';
import { setCameraFlash } from 'app/actions/settings';
import IdScanHeader from 'app/components/Header/IdScanHeader';
import styles from './styles';

class IndividualInfoTitle extends React.PureComponent {
    state = { idScanModalVisible: false, flashOn: this.props.flashOn, isScaning: true, error: false };
    constructor(props) {
        super(props);
        this.toggleIdScanDialog = this.toggleIdScanDialog.bind(this);
        this.flashButtonClick = this.flashButtonClick.bind(this);
        this.setIsScaning = this.setIsScaning.bind(this);
    }
    toggleIdScanDialog = () => {
        this.setState({
            idScanModalVisible: !this.state.idScanModalVisible,
            flashOn: this.props.flashOn,
            isScaning: true,
            error: false,
        });
    };
    flashButtonClick = () => {
        if (this.props.dispatch) this.props.dispatch(setCameraFlash(!this.props.flashOn));
        //  this.setState({ flashOn: !this.props.flashOn });
        this._idScan.onSetFlashOn(this.props.flashOn);
    };
    reScanButtonClick = () => {
        this._idScan.onResetScan();
        this.setState({ isScaning: true, error: false });
    };
    setIsScaning = val => {
        this.setState({ isScaning: val });
    };
    onAccept = result => {
        //console.log('Accepted, result:', result);

        this.setState({ idScanModalVisible: false, isScaning: true, error: false });
        this.props.onAccept(result);
    };

    onError = e => {
        this.props.onError(e);
        this.setState({ error: e, idScanModalVisible: true, isScaning: false });
    };

    render() {
        return (
            <View style={styles.titleContainer}>
                <Text style={styles.title}>{this.props.formTitle}</Text>
                <View style={styles.scanButtonContainer}>
                    <TouchableOpacity onPress={this.toggleIdScanDialog} disabled={!this.props.editable} style={styles.scanButtonTouchWrapper}>
                        <Text style={styles.scanButton} numberOfLines={1}>
                            {strings('scanTheId')}
                        </Text>
                    </TouchableOpacity>
                </View>
                <Modal animationType="slide" transparent={false} visible={this.state.idScanModalVisible} onRequestClose={this.toggleIdScanDialog}>
                    <IdScanHeader
                        backAction={this.toggleIdScanDialog}
                        flashButtonClick={this.flashButtonClick}
                        ReScanButtonClick={this.reScanButtonClick}
                        flashOn={this.props.flashOn}
                        isScaning={this.state.isScaning}
                        title={strings('scanTheId')}
                    />
                    <IdScan
                        ref={ref => {
                            this._idScan = ref;
                        }}
                        {...this.props}
                        requestClose={this.toggleIdScanDialog}
                        onReject={this.toggleIdScanDialog}
                        onAccept={this.onAccept}
                        isScaning={this.state.isScaning}
                        onError={this.onError}
                        error={this.state.error}
                        setIsScaning={this.setIsScaning}
                        idScanModalVisible={this.state.idScanModalVisible}
                    />
                </Modal>
            </View>
        );
    }
}

export default withNavigation(IndividualInfoTitle);
