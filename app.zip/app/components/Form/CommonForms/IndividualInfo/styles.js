import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    titleContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
    },
    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
    },
    scanButtonContainer: {
        flex: 1,
        borderRadius: 5,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryDarkIconbuttonBackground',
        marginHorizontal: 10,
        maxWidth: 100,
    },
    scanButtonTouchWrapper: {
        flex: 1,
    },
    scanButton: {
        flex: 1,
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
});
