import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import AppApi from 'app/api/real';
import { strings } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { IconButton, IntegrationFeedback } from 'app/components';
import TextInputMask from 'react-native-text-input-mask';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { EmiratesIdScanDialog } from 'app/screens';
const api = new AppApi();

const emptyViolatorState = {
    idNumber: '',
    titleE: '',
    titleA: '',
    integrationData: null,
    nationalityNameA: '',
    nationalityNameE: '',
    registeredPhoneNumber: '',
    detail: null,
    violatorType: 'individual',
};

class IndividualViolator extends Component {
    constructor(props) {
        super(props);
        this.searchPersonProfile = this.searchPersonProfile.bind(this);
        this.handleEmiratesIdChangeText = this.handleEmiratesIdChangeText.bind(this);
        if (props.mode === 'edit') {
            this.state = this.getViolatorStateForEditMode(props.violator);
        } else {
            this.state = { ...emptyViolatorState };
        }
    }

    resetViolatorState = () => {
        this.updateViolatorState(emptyViolatorState);
    };

    getViolatorStateForEditMode = violator => {
        const newState = { ...violator };
        if (!newState.integrationData) newState.integrationData = { success: true };
        return newState;
    };

    updateViolatorState = newState => {
        this.setState(newState, () => {
            const isValid = (this.state.integrationData && this.state.integrationData.success) || false;
            this.props.isValidViolator(isValid, this.state);
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = name == 'idNumber' ? { ...emptyViolatorState } : {};
        newState[name] = value;
        this.updateViolatorState(newState);
    };
    onAccept = data => {
        const integrationData = { ...this.state.integrationData, running: false, success: true, message: strings('integrationSuccessMessageMOI') };
        const newState = { ...emptyViolatorState, ...data, integrationData, idNumber: data.emiratesId };
        this.updateViolatorState(newState);
    };

    onError = e => {
        const integrationData = { ...this.state.integrationData, running: false, success: false, message: strings('integrationProgressMessageMOI') };
        this.updateViolatorState({ integrationData });
    };

    searchPersonProfile = async () => {
        let integrationData = { running: true, message: strings('integrationProgressMessageDED') };
        let newState = { integrationData };
        this.updateViolatorState(newState);
        try {
            const result = await api.getPersonProfile(`784${this.state.idNumber}`);
            integrationData = { running: false, success: true, message: strings('integrationSuccessMessageDED') };
            newState = {
                ...result,
                idNumber: this.state.idNumber,
                integrationData,
            };
        } catch (e) {
            if (!e.isCancel) {
                integrationData = { running: false, success: false, error: e, message: strings('integrationProgressMessageMOI') };
                newState = {
                    ...emptyViolatorState,
                    integrationData,
                };
            }
        } finally {
            this.updateViolatorState(newState);
        }
    };
    handleEmiratesIdChangeText = (formatted, extracted) => {
        this.handleFieldChange('idNumber', extracted);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    handleEmiratesIdPress = () => {
        //Todo: remove this, its for debugging
        if (this.props.mode === 'new') this.handleFieldChange('idNumber', '198483979807');
    };

    handleEmiratesIdLongPress = () => {
        //Todo: remove this, its for debugging
        if (this.props.mode === 'new') this.handleFieldChange('idNumber', '198650361870');
    };

    render = () => {
        const { idNumber, titleE, titleA, nationalityNameE, nationalityNameA, registeredPhoneNumber, integrationData } = this.state;

        const validationStyles = styles.invalid;
        const fieldEditable = false;
        const editable = this.props.mode === 'new';
        const isSearching = integrationData && integrationData.running == true;
        const searchButtonstyle = !isSearching && idNumber.length > 0 ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <TouchableOpacity onPress={this.handleEmiratesIdPress} onLongPress={this.handleEmiratesIdLongPress}>
                            <Text style={styles.label}> {strings('emiratesId')}</Text>
                        </TouchableOpacity>
                        <View style={styles.fieldContainer}>
                            <TextInputMask
                                style={styles.input}
                                onChangeText={this.handleEmiratesIdChangeText}
                                theme={textInputTheme}
                                editable={!isSearching && editable}
                                value={idNumber}
                                placeholder={strings('emiratesId')}
                                placeholderStyle={{ color: '#000000' }}
                                textAlignVertical={'center'}
                                mask={'784-[9999]-[9999999]-[9]'}
                                keyboardType={'numeric'}
                            />
                            <View style={{ position: 'absolute', right: 105, top: 13, elevation: 1 }}>
                                {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                            </View>

                            <View>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="magnify"
                                    disabled={!editable || isSearching || idNumber.length == 0} //Todo, check valid length
                                    style={[styles.buttonSearch, searchButtonstyle]}
                                    onPress={this.searchPersonProfile}
                                />
                            </View>
                            <View>
                                <EmiratesIdScanDialog
                                    editable={!isSearching && editable}
                                    formTitle={this.props.formTitle}
                                    flashOn={false}
                                    onAccept={this.onAccept}
                                    onError={this.onError}
                                    dispatch={this.props.dispatch}
                                />
                            </View>
                        </View>
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('name')}</Text>
                        <View style={styles.fieldContainer}>
                            <Text style={styles.inputDisabled}> {localeProperty(this.state, 'title')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={[styles.label, { marginEnd: 5 }]}> {strings('nationality')}</Text>
                        <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                            <Text style={styles.inputDisabled}> {localeProperty(this.state, 'nationalityName')}</Text>
                        </View>
                    </View>
                    <View style={styles.labelContainer}>
                        <Text style={[styles.label, { marginStart: 5 }]}> {strings('registeredPhoneNumber')}</Text>
                        <View style={[styles.fieldContainer, { marginStart: 5 }]}>
                            <Text style={styles.inputDisabled}> {registeredPhoneNumber}</Text>
                        </View>
                    </View>
                </View>
            </View>
        );
    };
}
export default IndividualViolator;
