import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { localeProperty, strings } from 'app/config/i18n/i18n';
import { createForm } from 'app/components';
import formConfigTemplate from './config';
import AppApi from 'app/api/real';
import { shallowEqual } from 'app/api/helperServices';
const api = new AppApi();

//Todo: Integrate with DED
class PlotInfoForm extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
    };

    state = { integrationData: { running: false } };
    constructor(props) {
        super(props);

        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            editable: props.editable,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            errorLogs: props.errorLogs,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }

    handleOnInit = formProps => {
        this.formProps = formProps;
    };

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'elmsId') {
            this.setState({ integrationData: { running: true, message: strings('integrationProgressMessageELMSID') } });
            try {
                if (newValue.length > 4) {
                    this.formProps.change('address', '');
                    this.formProps.change('ownerName', '');
                    this.formProps.change('ownerPhone', '');
                    const result = await api.getPlotsDataByGISID([newValue]);
                    const plotOwner = await api.getPlotOwnerDetails(newValue);
                    //GISID test id 10004251570
                    if (result && result.length > 0) {
                        const address = `${localeProperty(result[0], 'sectorName')}, ${localeProperty(result[0], 'sectorName')}, ${strings(
                            'plot'
                        )}  ${result[0].plotNumber} `;

                        this.formProps.change('address', address);

                        if (plotOwner && plotOwner.name) {
                            this.formProps.change('ownerName', plotOwner.name);
                            this.formProps.change('ownerPhone', plotOwner.phone);
                        }
                    }
                    this.setState({ integrationData: { running: false, success: true, message: strings('integrationSuccessMessageELMSID') } });
                }
            } catch (e) {
                if (!e.isCancel) {
                    this.formProps.change('address', '');
                    this.setState({
                        integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageELMSID') },
                    });

                }
            }
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    render = () => {
        const TheForm = this.form;
        return (
            <TheForm
                formProps={this.props.formProps}
                values={this.props.values}
                editable={this.props.editable}
                integrationData={this.state.integrationData}
                errorLogs={this.props.errorLogs}
            />
        );
    };
}

export default PlotInfoForm;
