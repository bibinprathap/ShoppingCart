import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { createForm } from 'app/components/Form';
import formConfigTemplate from './config';

class ReconcileInfoForm extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
        editable: PropTypes.bool,
    };

    constructor(props) {
        super(props);
        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            hideBorder: true,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }

    handleOnInit = formProps => (this.formProps = formProps);

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (this.props.onFieldChange) this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
    };

    render = () => {
        const TheForm = this.form;
        return <TheForm values={this.props.values} editable={this.props.editable} />;
    };
}

export default ReconcileInfoForm;
