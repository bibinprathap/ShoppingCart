export default (config = {
    name: 'ReconcileInfoForm',
    titleE: 'Reconcile',
    titleA: 'التصالح',
    showFormTitle: false,
    collapsible: false,
    showLabels: true,
    debounce: 500,
    fields: [
        {
            name: 'signature',
            type: 'signature',
            labelSaveE: 'I agree',
            labelSaveA: 'أنا موافق',
            labelResetE: 'Reset',
            labelResetA: 'إعادة تعيين',
            fieldHeight: 100,
            mode: 'flat',
            debounce: 500,
        },
    ],
});
