import React, { memo, Component } from 'react';
import EStyleSheet from 'react-native-extended-stylesheet';
import { View, Picker, TouchableNativeFeedback, TouchableOpacity } from 'react-native';
import TextInputMask from 'react-native-text-input-mask';
import { Text, Divider } from 'react-native-paper';
import { I18nManager, TextInput } from 'react-native';
import { strings } from 'app/config/i18n/i18n';

import AppApi from 'app/api/real';
import { shallowEqual } from 'app/api/helperServices';
import { Icon, IntegrationFeedback } from 'app/components';
import { EmiratesIdScanDialog } from 'app/screens';

import { _ } from 'lodash';
const api = new AppApi();
const initialIntegrationData = { running: false };

const styles = EStyleSheet.create({
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: 'transparent',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    fieldHeight: {
        height: 45,
    },
    fieldOuterContainer: {
        flex: 1,
        flexDirection: 'column',
        marginVertical: 5,
    },
    mandatoryField: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMandatoryTextBackground',
    },
    labelContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: 14,
        color: '$primaryDarkTextColor',
    },
    lableReadOnly: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    lableId: {
        fontSize: 15,
    },
    fieldContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        marginHorizontal: 10,
        marginTop: 5,
    },
    fieldContainerFlat: {
        //backgroundColor: '$primaryWhite',
        backgroundColor: 'transparent',
        elevation: 0,
        // borderBottomWidth: '$primaryBorderThin',
        //borderRadius: 5,
        // borderColor: '$primaryDarkPlaceholderColor',
    },
    actionPicker: { height: 50, width: 142, justifyContent: 'flex-start', alignSelf: 'flex-start' },
    checkListCard: {
        flex: 1,
        flexDirection: 'row',
    },
    violatorContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    CommentsPhotoContainer: {
        // backgroundColor: '#000000',
        flex: 1,
        width: '97%',
        backgroundColor: '$primaryWhite',
        // elevation: 4,
        borderRadius: 8,
        margin: 5,
        padding: 5,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
    },
    imageAndComments: {
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'flex-start',
        marginLeft: 0,
        flex: 1,
        flexDirection: 'row',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    divider: {
        width: '100%',
        marginVertical: 2,
    },
    violatorsContainer: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
    },
    fieldContainerShadowed: {
        backgroundColor: '$primaryWhite',
        elevation: 4,
        borderRadius: 8,
    },
    validationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
});
const AddedViolator = memo(function(props) {
    // const [expanded, setExpanded] = useState(false);
    // handleDetailsClick = () => {
    //     setExpanded(prevState => !prevState);
    // };

    const handleDeleteClick = () => {
        props.handleDeleteClick(props.violator);
    };

    return (
        <React.Fragment>
            <View style={styles.checkListCard}>
                {props.violator.idTypeIcon == 'drivers-license' ? (
                    <Icon
                        type="MaterialCommunityIcons"
                        name={props.violator.idTypeIcon}
                        size={20}
                        style={[styles.icon, { color: '#008000', marginStart: 10, paddingTop: 20 }]}
                    />
                ) : (
                    <Icon
                        type="MaterialCommunityIcons"
                        name={props.violator.idTypeIcon}
                        size={20}
                        style={[styles.icon, { color: '#008000', marginStart: 10, paddingTop: 20 }]}
                    />
                )}

                <View style={[styles.CommentsPhotoContainer]}>
                    <View style={styles.violatorContainer}>
                        <View style={styles.imageAndComments}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.lableId}>{props.violator.idNumber}</Text>
                                <Text style={styles.lableReadOnly}>{props.violator.violatorName}</Text>
                            </View>

                            {props.editable ? (
                                <View style={styles.buttonContainer}>
                                    <TouchableNativeFeedback onPress={handleDeleteClick}>
                                        <View style={{ padding: 5 }}>
                                            <Icon type="MaterialCommunityIcons" name="delete" size={20} style={styles.icon} />
                                        </View>
                                    </TouchableNativeFeedback>
                                </View>
                            ) : null}
                        </View>
                    </View>
                </View>
            </View>
            {/* {expanded ? (
                <View style={[styles.checkListCard, { flexDirection: 'column' }]}>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('name')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.violator.name}</Text>
                        </View>

                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('emiratesId')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.violator.idNumber}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('idType')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.violator.idType}</Text>
                        </View>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('nationality')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.violator.nationality}</Text>
                        </View>
                    </View>
                </View>
            ) : null} */}
            <Divider style={styles.divider} />
        </React.Fragment>
    );
});

export const ViolatorsList = memo(function(props) {
    return (
        <React.Fragment>
            <View style={{ flex: 1 }}>
                {props.violators && props.violators.length > 0
                    ? props.violators.map((violator, i) => {
                          return <AddedViolator key={i} violator={violator} editable={props.editable} handleDeleteClick={props.handleDeleteClick} />;
                      })
                    : null}
            </View>
        </React.Fragment>
    );
});

//Todo: Integrate with EID Reader, (REST API?), or read from the MRZ of the emirates ID photo.
class Occupants extends Component {
    static propTypes = {};
    onAccept = data => {
        this.setState(
            {
                setByScan: true,
                integrationData: { ...this.state.integrationData, running: false, success: true, message: strings('integrationSuccessMessageMOI') },
            },
            obj => {
                this.setState({ idNumber: data.emiratesId, violatorName: data.nameA, nationality: data.nationality });
                // Object.keys(data).forEach(key => {
                //     this.formProps.change(key, data[key]);
                // });
            }
        );
    };
    onError = e => {
        this.setState({ integrationData: { ...this.state.integrationData, running: false } });
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    state = {
        integrationData: initialIntegrationData,
        setByScan: false,
        idNumber: '',
        violatorName: '',
        idType: 'emiratesId',
        nationality: 'Philippines',
        nameDisabled: true,
        idPlaceHolder: strings('emiratesId'),
        idTypeIcon: 'account-card-details',
        errorLogs: {},
    };
    constructor(props) {
        super(props);

        //  this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
        this.onAccept = this.onAccept.bind(this);
        this.onError = this.onError.bind(this);
        this.handleAddViolator = this.handleAddViolator.bind(this);
        this.handleDeleteClick = this.handleDeleteClick.bind(this);
        this.handleIdTypeChange = this.handleIdTypeChange.bind(this);
        this.handleIdChange = this.handleIdChange.bind(this);
    }

    clearIntegratedValues = () => {
        //todo: run this dynamically based on config
        // this.formProps.change('expiryDate', '');
        // this.formProps.change('birthDate', '');
        // this.formProps.change('nameE', '');
        // this.formProps.change('nameA', '');
        // this.formProps.change('nationality', '');
        // this.formProps.change('birthDate', '');
    };

    handleEmiratesIdChange = async (formatted, idNumber) => {
        //  this.setState({  });
        if (this.state.setByScan) {
            this.setState({ idNumber, setByScan: false });
        } else {
            if (idNumber.length !== 12) {
                this.clearIntegratedValues();
                if (this.state.integrationData && this.state.integrationData.running == true) {
                    this.setState({ idNumber, integrationData: initialIntegrationData });
                } else {
                    this.setState({ idNumber });
                }
                return;
            } else {
                this.setState({ idNumber, integrationData: { running: true, message: strings('integrationProgressMessageMOI') } });
                try {
                    //todo: show loading spinner in companyName field
                    this.clearIntegratedValues();
                    const result = await api.getPersonProfile(`784${idNumber}`);
                    //todo: run this dynamically based on config

                    this.setState({
                        idNumber: result.idNumber,
                        violatorName: result.titleE,
                        nationality: result.nationalityNameA,
                        integrationData: { running: false, success: true, message: strings('integrationSuccessMessageMOI') },
                    });
                    /*
                todo: hide the spinner and disable the companyName field because 
                      API call was a success, whatever name has been returned by
                      the API is the correct name
                */
                } catch (e) {
                    if (!e.isCancel) {
                        this.clearIntegratedValues();
                        this.setState({
                            integrationData: { idNumber, running: false, success: false, error: e, message: strings('integrationErrorMessageMOI') },
                        });
                        /*
                todo: if license number is invalid, set error on licenseNumber
                      if it is network error, or exception on the server, then 
                      enable the company name field so user can enter value directly.
                */
                    }
                }
            }
        }
    };

    handleIdChange = async idNumber => {
        this.setState({ idNumber });
    };
    handleIdTypeChange = idType => {
        let nameDisabled = false;
        let idTypeIcon = 'account-card-details';

        let idPlaceHolder = strings('emiratesId');
        if (idType == 'emiratesId') {
            nameDisabled = true;
        } else if (idType == 'passport') {
            idPlaceHolder = strings('passport');
            idTypeIcon = 'passport';
        } else if (idType == 'drivingLicence') {
            idPlaceHolder = strings('drivingLicence');
            idTypeIcon = 'book';
        }
        this.setState({
            integrationData: initialIntegrationData,
            setByScan: false,
            idType,
            nameDisabled,
            idPlaceHolder,
            idTypeIcon,
            idNumber: '',
            violatorName: '',
            errorLogs: {},
        });
        //  this.setState({ name: '' });
    };
    handleViolatorNameChange = violatorName => {
        this.setState({ violatorName, errorLogs: {} });
    };

    handleAddViolator = () => {
        const currentViolator = this.props.value;
        const { idNumber, violatorName, idType, nationality, idTypeIcon, errorLogs } = this.state;

        if (idNumber && violatorName) {
            const newViolatorArray = currentViolator ? currentViolator.slice() : [];
            newViolatorArray.push({ idNumber, violatorName, idType, nationality, idTypeIcon });
            this.props.onChange(newViolatorArray);
            this.setState({
                errorLogs: {},
                idNumber: '',
                violatorName: '',
                integrationData: null,
            });
        } else {
            this.setState({
                errorLogs: {
                    idNumber: !(idNumber && idNumber.length > 0),
                    violatorName: !(violatorName && violatorName.length > 0),
                },
            });
        }
    };
    handleDeleteClick = violator => {
        const currentViolators = this.props.value;
        const newViolatorsArray = _.without(currentViolators, violator);

        this.props.onChange(newViolatorsArray);
    };
    handleEmiratesIdPress = () => {
        //Todo: remove this, its for debugging
        this.handleEmiratesIdChange('idNumber', '198483979807');
    };
    render = () => {
        const { value, editable, validationerror, ...otherProps } = this.props;

        const { integrationData, idType, nameDisabled, idPlaceHolder, violatorName, idNumber, errorLogs } = this.state;
        const integrationSourceFieldIndicator = idType == 'emiratesId' && integrationData && (
            <IntegrationFeedback integrationData={integrationData} />
        );
        // const integrationFieldIndicator =
        //     idType == 'emiratesId' && integrationData && !integrationData.running && !!integrationData.success && integrationSourceFieldIndicator;
        const addButtonEnabled = violatorName && violatorName.length > 0 && idNumber.length > 0;
        if (editable) {
            return (
                <View style={styles.violatorsContainer}>
                    <View style={{ flex: 1 }}>
                        {value && value.length > 0
                            ? this.props.value.map((violator, i) => {
                                  return <AddedViolator key={i} violator={violator} handleDeleteClick={this.handleDeleteClick} editable={editable} />;
                              })
                            : null}
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 5 }} />
                        <View style={{ flex: 1 }}>
                            <View style={{ position: 'absolute', zIndex: 999, top: 40, right: I18nManager.isRTL ? 0 : -5, color: '#008000' }}>
                                <TouchableNativeFeedback onPress={this.handleAddViolator}>
                                    {/* disabled={!addButtonEnabled} */}
                                    <View style={{ height: 50, width: 50, justifyContent: 'center', alignItems: 'center' }}>
                                        <Icon
                                            type="MaterialCommunityIcons"
                                            name="plus-circle"
                                            color={addButtonEnabled ? '#008000' : '#cccccc'}
                                            size={30}
                                            style={[styles.icon]}
                                        />
                                    </View>
                                </TouchableNativeFeedback>
                            </View>
                        </View>
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 1, marginEnd: 30 }}>
                            <View style={[{ flex: 1 }, styles.fieldOuterContainer]}>
                                <View style={{ flexDirection: 'row', flex: 1 }}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Picker
                                            selectedValue={idType}
                                            style={{ width: 180, transform: [{ scaleX: 0.9 }, { scaleY: 0.9 }] }}
                                            editable={editable}
                                            onValueChange={this.handleIdTypeChange}
                                        >
                                            <Picker.Item key="emiratesId" value="emiratesId" label={strings('emiratesId')} />
                                            {/* <Picker.Item key="passport" value="passport" label={strings('passport')} />
                                            <Picker.Item key="drivingLicence" value="drivingLicence" label={strings('drivingLicence')} /> */}
                                        </Picker>
                                        <Text style={[styles.mandatoryField, { position: 'absolute', left: 152, top: 10 }]}>*</Text>
                                    </View>
                                    <View>
                                        <View style={{ width: 330, flexDirection: 'row' }}>
                                            <View style={[styles.fieldContainer, styles.fieldContainerShadowed, { flexDirection: 'row' }]}>
                                                {idType == 'emiratesId' ? (
                                                    <>
                                                        <EmiratesIdScanDialog
                                                            editable={editable}
                                                            formTitle={this.props.formTitle}
                                                            flashOn={false}
                                                            onAccept={this.onAccept}
                                                            onError={this.onError}
                                                            dispatch={this.props.dispatch}
                                                        />
                                                        <TextInputMask
                                                            name="emiratesId"
                                                            editable={editable}
                                                            style={[styles.input, styles.maskedInput, { height: 45, width: '100%' }]}
                                                            onChangeText={this.handleEmiratesIdChange}
                                                            value={this.state.idNumber}
                                                            autoCapitalize="none"
                                                            mask={'784-[9999]-[9999999]-[9]'}
                                                            placeholder={idPlaceHolder}
                                                        />
                                                    </>
                                                ) : (
                                                    <TextInput
                                                        name="otherid"
                                                        style={[styles.input, styles.maskedInput, { height: 45, width: '100%' }]}
                                                        value={this.state.idNumber}
                                                        autoCapitalize="none"
                                                        onChangeText={this.handleIdChange}
                                                        placeholder={idPlaceHolder}
                                                        editable={editable}
                                                    />
                                                )}
                                            </View>
                                            {integrationSourceFieldIndicator}
                                        </View>

                                        {errorLogs && errorLogs.idNumber ? (
                                            <View style={{ padding: 5, marginLeft: 10 }}>
                                                <Text style={styles.validationMessageText}>{idPlaceHolder + ' ' + strings('isRequired')}</Text>
                                            </View>
                                        ) : null}
                                    </View>
                                </View>
                            </View>
                            <View style={[{ flex: 1 }, styles.fieldOuterContainer]}>
                                <View style={[styles.labelContainer]}>
                                    <View style={{ flexDirection: 'row', flex: 1 }}>
                                        <View style={{ flexDirection: 'row', width: 170, paddingLeft: 5 }}>
                                            <TouchableOpacity
                                                style={{ flexDirection: 'row', width: 170 }}
                                                onPress={this.handleEmiratesIdPress}
                                                onLongPress={this.handleEmiratesIdPress}
                                            >
                                                <Text style={styles.label}>{strings('name')}</Text>
                                                <Text style={styles.mandatoryField}>*</Text>
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ flex: 1 }}>
                                            <View style={[styles.fieldContainer, styles.fieldContainerShadowed]}>
                                                <TextInput
                                                    style={[styles.input, styles.maskedInput, { height: 45 }]}
                                                    onChangeText={this.handleViolatorNameChange}
                                                    value={violatorName}
                                                    editable={!nameDisabled}
                                                    autoCapitalize="none"
                                                    placeholder={strings('name')}
                                                />
                                            </View>
                                            {errorLogs && errorLogs.violatorName ? (
                                                <View style={{ padding: 5, marginLeft: 10 }}>
                                                    <Text style={styles.validationMessageText}>{strings('name') + ' ' + strings('isRequired')}</Text>
                                                </View>
                                            ) : null}
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            );
        } else {
            return <ViolatorsList violators={value} editable={editable} handleDeleteClick={this.handleDeleteClick} />;
        }
    };
}

export default Occupants;
