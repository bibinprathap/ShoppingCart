import React, { Component } from 'react';
import { View, TextInput, TouchableOpacity, Picker, I18nManager } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { NumericInput, commonStyles, Icon, IntegrationFeedback } from 'app/components';
import { infoChanged } from 'app/actions/inspections';
import { AttachmentListWithDialog } from 'app/screens';
import { lookup } from 'app/api/helperServices';
import { ViolatorSelectorDialog } from 'app/screens';

const api = new AppApi();

const emptyResUnitOccupancy = {
    buildingNumber: '',
    buildingType: '',
    buildingNameE: '',
    buildingNameA: '',
    ownerName: '',
    noOfUnits: '',
    attachmentList: [],
    attachmentModalVisible: false,
    violatorsID: null,
    errorLogs: {},
    violationActionTypes: [],
    integrationData: {},
    showDialog: false,
    availableViolators: [],
    remarks: '',
};

class ResUnitOccupancy extends Component {
    constructor(props) {
        super(props);
        this.state = { ...emptyResUnitOccupancy, ...props.initialValue, violationActionTypes: props.actionTypeOptions, attachmentList: [] };
        //this.searchBuildingDetails = this.searchBuildingDetails.bind(this);
    }

    resetViolatorState = () => {
        this.updateResUnitOccupancyState(emptyResUnitOccupancy);
    };

    updateResUnitOccupancyState = async newState => {
        this.setState(newState, () => {
            const { visitIndex } = this.props;
            this.props.dispatch(infoChanged('resUnitOccupancySuspicion', this.state, visitIndex));
        });
    };

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateResUnitOccupancyState(newState);
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateResUnitOccupancyState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateResUnitOccupancyState(newState);
    };

    // searchBuildingDetails = async () => {
    //     let integrationData = { running: true, message: strings('verifying') };
    //     let newState = { integrationData };
    //     this.updateResUnitOccupancyState(newState);
    //     try {
    //         const result = await api.getBuildingInfo({ buildingNumber: this.state.buildingNumber, location: this.props.location });
    //         integrationData = { running: false, success: true, message: strings('integrationSuccessMessageBuilding') };
    //         if (result.length === 1) {
    //             newState = {
    //                 ...result[0],
    //                 buildingType: result[0].buildingType && result[0].buildingType.id,
    //                 buildingNumber: result[0].buildingNumber,
    //                 integrationData,
    //             };
    //         } else if (result.length > 1) {
    //             newState = {
    //                 integrationData,
    //                 showDialog: true,
    //                 availableViolators: result.map(res => {
    //                     return {
    //                         data: res,
    //                         violatorType: 'building',
    //                         titleA: res.buildingType.labelA,
    //                         titleE: res.buildingType.labelE,
    //                         idNumber: res.buildingNumber,
    //                         registeredPhoneNumber: '',
    //                         violatorPhoneNumber: '',
    //                         nationalityNameA: res.buildingNameA,
    //                         nationalityNameE: res.buildingNameE,
    //                     };
    //                 }),
    //             };
    //         }
    //     } catch (e) {
    //         if (!e.isCancel) {
    //             integrationData = { running: false, success: false, error: e, message: strings('integrationErrorMessageBuilding') };
    //             newState = {
    //                 ...emptyResUnitOccupancy,
    //                 integrationData,
    //             };
    //         }
    //     } finally {
    //         this.updateResUnitOccupancyState(newState);
    //     }
    // };

    handleDialogOnRequestClose = selectedViolator => {
        this.setState({ showDialog: false });
        if (!selectedViolator) return;
        this.updateResUnitOccupancyState({
            ...selectedViolator.data,
            buildingType: selectedViolator.data.buildingType.id,
            buildingNumber: selectedViolator.data.buildingNumber,
        });
    };

    render() {
        const {
            dispatch,
            inspection,
            editable,
            formName,
            readOnly,
            currentInspectionVersion,
            violationTypes,
            buildingTypeOptions,
            values,
        } = this.props;
        const { integrationData, showDialog, availableViolators } = this.state;
        const remarks = editable ? this.state.remarks : values && values.remarks;
        const displaySource = this.props.readOnly ? this.props.values : this.state;
        const { attachmentList, buildingNumber, buildingType, buildingNameE, buildingNameA, ownerName, noOfUnits, violatorsID } = displaySource || {};
        let errorLogs = this.props.errorLogs || {};

        const isSearching = integrationData.running == true;
        const isSearchDisabled = isSearching || !buildingNumber || !buildingNumber.length || !editable;
        const searchButtonstyle = isSearchDisabled ? styles.buttonDisabled : styles.buttonActive;
        const readOnlyRtlStyles = I18nManager.isRTL
            ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
            : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };

        const manualEntry = integrationData.success === false;

        const editableFieldStyle = manualEntry ? styles.input : styles.inputDisabled;

        return (
            <View style={{ flex: 1 }} key={{ formName }} key={this.props.key}>
                {/* <ViolatorSelectorDialog
                    isShowing={showDialog}
                    availableViolators={availableViolators}
                    onRequestClose={this.handleDialogOnRequestClose}
                    title={strings('selectBuilding')}
                /> */}
                <View style={{ flex: 1 }} key={this.props.key}>
                    <View style={styles.container}>
                        <View style={styles.titleContainer}>
                            <Text style={[commonStyles.generalHeading]}>{strings('ResUnitOccupancy')}</Text>
                        </View>
                        {/* <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('buildingNumber')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{buildingNumber}</Text>
                                        </View>
                                        {errorLogs.buildingNumber && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('buildingNumber') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={[styles.fieldContainer]}>
                                        <TextInput
                                            style={styles.input}
                                            placeholder={strings('buildingNumber')}
                                            value={buildingNumber}
                                            editable={editable}
                                            onChangeText={this.handleFieldChange.bind(this, 'buildingNumber')}
                                            autoCorrect={false}
                                            direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                            autoCapitalize="sentences"
                                            multiline={true}
                                            textAlignVertical={'top'}
                                        />
                                        <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                            {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                                        </View>
                                        <TouchableOpacity onPress={this.searchBuildingDetails} style={[styles.buttonSearch, searchButtonstyle]}>
                                            <Icon type="MaterialCommunityIcons" name="magnify" size={25} />
                                        </TouchableOpacity>
                                    </View>
                                )}
                            </View>
                        </View>
                        <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('buildingType')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>
                                                {buildingType && lookup.getLabel('buildingType', buildingType, '', '-1')}
                                            </Text>
                                        </View>

                                        {errorLogs.buildingType && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('buildingType') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                        <Picker
                                            selectedValue={buildingType}
                                            key={`building${buildingTypeOptions.length}`}
                                            enabled={editable && manualEntry}
                                            style={manualEntry ? styles.picker : [styles.picker, styles.pickerDisabled]}
                                            onValueChange={this.handleFieldChange.bind(this, 'buildingType')}
                                        >
                                            <Picker.Item key={4422} label={strings('pleaseselect') + ' ' + strings('buildingType')} value={''} />
                                            {buildingTypeOptions &&
                                                buildingTypeOptions.map((v, i) => {
                                                    return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                                })}
                                        </Picker>
                                    </View>
                                )}
                            </View>
                        </View>
                        <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('buildingNameE')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{buildingNameE}</Text>
                                        </View>
                                        {errorLogs.buildingNameE && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('buildingNameE') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={[styles.fieldContainer]}>
                                        <TextInput
                                            style={editableFieldStyle}
                                            placeholder={strings('buildingNameE')}
                                            value={buildingNameE}
                                            editable={editable && manualEntry}
                                            onChangeText={this.handleFieldChange.bind(this, 'buildingNameE')}
                                            autoCorrect={false}
                                            direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                            autoCapitalize="sentences"
                                            multiline={true}
                                            textAlignVertical={'top'}
                                        />
                                    </View>
                                )}
                            </View>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('buildingNameA')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{buildingNameA}</Text>
                                        </View>
                                        {errorLogs.buildingNameA && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('buildingNameA') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={styles.fieldContainer}>
                                        <TextInput
                                            style={editableFieldStyle}
                                            placeholder={strings('buildingNameA')}
                                            value={buildingNameA}
                                            editable={editable && manualEntry}
                                            onChangeText={this.handleFieldChange.bind(this, 'buildingNameA')}
                                            autoCorrect={false}
                                            direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                            autoCapitalize="sentences"
                                            multiline={true}
                                            textAlignVertical={'top'}
                                        />
                                    </View>
                                )}
                            </View>
                        </View> */}
                        {/* <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('ownerName')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{ownerName}</Text>
                                        </View>
                                        {errorLogs.ownerName && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('ownerName') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={[styles.fieldContainer]}>
                                        <TextInput
                                            style={styles.input}
                                            placeholder={strings('ownerName')}
                                            value={ownerName}
                                            editable={editable}
                                            onChangeText={this.handleFieldChange.bind(this, 'ownerName')}
                                            autoCorrect={false}
                                            direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                            autoCapitalize="sentences"
                                            //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                            multiline={true}
                                            textAlignVertical={'top'}
                                        />
                                    </View>
                                )}
                            </View>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('noOfUnits')}</Text>
                                {readOnly ? (
                                    <>
                                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{noOfUnits}</Text>
                                        </View>
                                        {errorLogs.noOfUnits && (
                                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                                {strings('noOfUnits') + ' ' + strings('isRequired')}
                                            </Text>
                                        )}
                                    </>
                                ) : (
                                    <View style={[styles.fieldContainer]}>
                                        <NumericInput
                                            value={noOfUnits || 0}
                                            initValue={noOfUnits || 0}
                                            totalWidth={120}
                                            minValue={0}
                                            totalHeight={40}
                                            onChange={this.handleFieldChange.bind(this, 'noOfUnits')}
                                        />
                                    </View>
                                )}
                            </View>
                        </View> */}

                        <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('attachments')}</Text>
                                <View style={styles.attachmentFieldContainer}>
                                    <AttachmentListWithDialog
                                        editable={editable}
                                        onAdd={this.handleOnAddAttachment}
                                        onRemove={this.handleOnRemoveAttachment}
                                        attachments={attachmentList}
                                    />
                                </View>
                            </View>
                        </View>

                        {errorLogs.attachmentList && (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                {strings('attachments') + ' ' + strings('isRequired')}
                            </Text>
                        )}
                        {/* <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('occupants')}</Text>
                                <View style={[styles.fieldContainer]}>
                                    <Occupants value={violatorsID} editable={editable} onChange={this.handleFieldChange.bind(this, 'violatorsID')} />
                                </View>
                            </View>
                        </View> */}
                        {errorLogs.violatorsID && (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                {strings('occupants') + ' ' + strings('isRequired')}
                            </Text>
                        )}

                        <View style={styles.fieldrow}>
                            <View style={styles.rowContainer}>
                                <Text style={styles.label}> {strings('remarks')}</Text>
                                <View style={styles.fieldContainer}>
                                    <TextInput
                                        style={styles.input}
                                        placeholder={strings('remarks')}
                                        value={remarks}
                                        editable={!!editable}
                                        onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                        autoCorrect={false}
                                        direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                        autoCapitalize="sentences"
                                        autoFocus={false}
                                        multiline={true}
                                        textAlignVertical={'top'}
                                    />
                                </View>
                            </View>
                        </View>

                        {errorLogs.remarks ? (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                        ) : null}
                    </View>
                </View>
            </View>
        );
    }
}
export default ResUnitOccupancy;
