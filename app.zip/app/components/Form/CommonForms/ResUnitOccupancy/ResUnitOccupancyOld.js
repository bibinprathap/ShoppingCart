import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { strings } from 'app/config/i18n/i18n';
import { createForm } from 'app/components';
import formConfigTemplate from './config';
import AppApi from 'app/api/real';
const api = new AppApi();

//Todo: Integrate with DED
class ResUnitOccupancy extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
    };

    state = { integrationData: { running: false } };
    constructor(props) {
        super(props);

        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            editable: props.editable,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            errorLogs: props.errorLogs,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }

    handleOnInit = formProps => {
        this.formProps = formProps;
    };

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'buildingNumber') {
            this.setState({ integrationData: { running: true, message: strings('integrationProgressMessageBuilding') } });
            try {
                //todo: show loading spinner in companyName field
                if (newValue.length > 3) {
                    this.formProps.change('buildingType', '');
                    this.formProps.change('buildingNameEN', '');
                    this.formProps.change('buildingNameAR', '');
                    this.formProps.change('ownerName', '');
                    const result = await api.getBuildingDetails(newValue);
                    this.formProps.change('buildingType', result.buildingType || '');
                    this.formProps.change('buildingNameEN', result.buildingNameEN || '');
                    this.formProps.change('buildingNameAR', result.buildingNameAR || '');
                    this.formProps.change('ownerName', result.ownerName || '');
                    this.setState({ integrationData: { running: false, success: true, message: strings('integrationSuccessMessageBuilding') } });
                }
            } catch (e) {
                if (!e.isCancel) {
                    this.formProps.change('buildingType', '');
                    this.formProps.change('buildingNameEN', '');
                    this.formProps.change('buildingNameAR', '');
                    this.formProps.change('ownerName', '');
                    this.setState({
                        integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageBuilding') },
                    });


                }
            }
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {
        const TheForm = this.form;

        return (
            <TheForm
                formProps={this.props.formProps}
                values={this.props.values}
                editable={this.props.editable}
                integrationData={this.state.integrationData}
                errorLogs={this.props.errorLogs}
            />
        );
    };
}

export default ResUnitOccupancy;
