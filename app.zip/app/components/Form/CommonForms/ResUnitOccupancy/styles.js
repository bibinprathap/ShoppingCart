import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';
export default EStyleSheet.create({
    contentContainer: {
        flex: 1,
        marginVertical: 20,
        borderRadius: 10,
    },
    formContainer: {
        backgroundColor: '$primaryLightBackground',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    input: {
        flex: 1,
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',
        alignItems: 'flex-start',
        borderRadius: 4,
        elevation: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        padding: 10,
        marginRight: 2,
    },
    inputDisabled: {
        flex: 1,
        color: '$primaryDarkTextColor',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    pickerDisabled: {
        backgroundColor: '$primaryLightBackground',
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    rowContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        marginHorizontal: 5,
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
    },
    button: {
        height: 50,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonActive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonSearch: {
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 10,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 5,
    },

    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
    container: {
        flex: 1,
    },

    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
        alignSelf: 'flex-start',
    },

    titleContainer: {
        flex: 1,
    },

    scanButtonContainer: {
        flex: 1,
        borderRadius: 5,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryDarkIconbuttonBackground',
        marginHorizontal: 10,
        maxWidth: 100,
    },
    scanButtonTouchWrapper: {
        flex: 1,
    },
    scanButton: {
        flex: 1,
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    customFieldRowContainer: {
        marginTop: 20,
        marginBottom: 5,
    },
    fieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        marginTop: 5,
    },
    attachmentFieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryWhite',
        margin: 5,
        elevation: 1,
        borderRadius: 5,
    },
    fieldrow: { flex: 1, flexDirection: 'row', marginVertical: 10 },
    picker: {
        height: 50,
        width: '100%',
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        color: '$primaryDarkTextColor',

        borderRadius: 4,
        elevation: 1,
    },
    titleContainer: {
        width: '100%',
        marginLeft: 8,
        marginBottom: 10,
    },
    fieldContainerPicker: {
        backgroundColor: '#ffffff',
        elevation: 1,
        borderRadius: 4,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    valueReadOnlyText: {
        fontSize: 12,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        color: '$primaryDarkTextColor',
    },
});
