import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager, TouchableOpacity } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { NumericInput, Icon, IconButton, AttachmentList, Switch, commonStyles, Loader, Modal, Occupants, AddViolator } from 'app/components';
import { Attachments } from 'app/screens';
import { infoChanged, infoViolatorChanged, addViolatorSignature } from 'app/actions/inspections';
import { ValidationHelper, lookup } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import * as yup from 'yup';
const api = new AppApi();

const emptyFollowUpForm = {
    remarks: null,
    attachmentList: [],
    attachmentModalVisible: false,
    occupants: null,
    selectedAttachment: null,
    actualNoOfUnits: null,
    actualNoOfOccupants: null,
    violatorId: null,
    reconciled: false,
    occupancyLawViolationExists: false,
    errorLogs: {},
};

class ResUnitOccupancyWarrantApprovedForm extends Component {
    constructor(props) {
        super(props);
        this.state = { ...emptyFollowUpForm, ...props.initialValue };
        this.isSubmitable = this.isSubmitable.bind(this);
        this.updateFollowupState = this.updateFollowupState.bind(this);
        this.onViolatorSelected = this.onViolatorSelected.bind(this);
        this.handleOnViolatorEdited = this.handleOnViolatorEdited.bind(this);
        this.handleOnViolatorRemoved = this.handleOnViolatorRemoved.bind(this);
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
        this.handleonReconciled = this.handleonReconciled.bind(this);
        this.handleThumbnailPressed = this.handleThumbnailPressed.bind(this);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    updateFollowupState = async newState => {
        let formValue = { ...this.state, ...newState };
        let followupValidationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };

        if (this.state.occupancyLawViolationExists === true && !this.state.violatorId) {
            followupValidationSchema.violatorId = yup.string().required();
        }

        let errorLogs = {};
        try {
            await ValidationHelper.validate(formValue, yup.object().shape(followupValidationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map(er => {
                errorLogs[er] = errors[er];
            });
        }
        newState.errorLogs = errorLogs;
        this.setState(newState, () => {
            const { visitIndex } = this.props;
            this.props.dispatch(infoChanged('followupForm', this.state, visitIndex));
            this.isSubmitable();
        });
    };
    componentDidMount() {
        if (this.isSubmitable) this.isSubmitable();
    }
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleOnAdd = newAttachment => {
        const { attachmentList } = this.state;
        const newAttachmentsArray = attachmentList ? attachmentList.slice() : [];
        newAttachmentsArray.push(newAttachment);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleAttachmentRemoved = doc => {
        const { attachmentList } = this.state;
        const currentAttachments = attachmentList;
        const newAttachmentsArray = _.without(currentAttachments, doc);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleCameraPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateFollowupState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );

    isSubmitable = async () => {
        const { errorLogs, attachmentList, remarks } = this.state;
        const isAllowedToSave =
            (!errorLogs || (errorLogs && Object.getOwnPropertyNames(errorLogs).length == 0)) &&
            attachmentList &&
            attachmentList.length > 0 &&
            remarks &&
            remarks.length > 0;
        if (this.props.isSubmitable) this.props.isSubmitable({ isAllowedToSave });
    };

    onViolatorSelected = async callProps => {
        const { selectedViolator, changed } = callProps;
        const { dispatch } = this.props;
        await this.updateFollowupState({ violatorId: selectedViolator.violatorId });
        if (changed) {
            await dispatch(infoViolatorChanged({ baseInfo: { ...selectedViolator } }));
        }
    };

    handleOnViolatorEdited = async callProps => {
        const { editedViolator, changed } = callProps;
        const { dispatch } = this.props;
        if (changed) {
            await this.updateFollowupState({ reconciled: editedViolator.isPresent && this.state.reconciled });
            await dispatch(
                infoViolatorChanged({
                    baseInfo: {
                        ...editedViolator,
                        isPresent: editedViolator.isPresent,
                    },
                })
            );
        }
    };

    handleOnViolatorRemoved = async () => {
        await this.updateFollowupState({ violatorId: null, reconciled: false });
    };

    handleonReconciled = async ({ reconciled, attachment, violatorId }) => {
        const { dispatch } = this.props;
        await this.updateFollowupState({ reconciled });

        if (reconciled && attachment) {
            await dispatch(addViolatorSignature({ violatorId, attachment }));
        }
    };

    render = () => {
        const {
            remarks,
            attachmentList,
            errorLogs,
            occupants,
            actualNoOfUnits,
            actualNoOfOccupants,
            violatorId,
            reconciled,
            occupancyLawViolationExists,
            selectedAttachment,
        } = this.state;
        const { editable, inspection, readOnly, dispatch } = this.props;

        const currentViolator = violatorId && inspection.violators && _.find(inspection.violators, { violatorId: violatorId });
        const { currentVisit, currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        const existingViolators = inspectionsHelper.getAllViolators({ violators: inspection.violators || [], visit: currentVisit });
        const showReconciliation = currentViolator && (currentViolator.isPresent || currentViolator.signature) ? true : false;

        const showOccupants = editable || (occupants && occupants.length > 0);
        return (
            <View style={styles.container}>
                {currentVisit.warrantDocs && (
                    <View style={{ flex: 1 }}>
                        <View style={styles.fieldrow}>
                            <View style={styles.labelContainer}>
                                <Text style={styles.label}>{strings('warrant')}</Text>
                                <View style={styles.fieldContainer} />
                            </View>
                        </View>
                        <View style={{ borderRadius: 4, paddingVertical: 10 }}>
                            <AttachmentList attachments={currentVisit.warrantDocs} editable={false} onPress={this.handleThumbnailPressed} />
                        </View>
                    </View>
                )}
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}>{strings('attachments')}</Text>
                        <View style={styles.fieldContainer} />
                    </View>
                </View>
                <View style={styles.fieldContainerAttachement}>
                    <Modal
                        animationType="slide"
                        transparent={false}
                        visible={this.state.attachmentModalVisible}
                        onRequestClose={this.toggleAttachmentDialog}
                    >
                        <Attachments
                            attachments={
                                currentVisit.warrantDocs && selectedAttachment && selectedAttachment.type == 'InspectionWarrant'
                                    ? currentVisit.warrantDocs
                                    : attachmentList
                            }
                            onAdd={this.handleOnAdd}
                            onRemove={this.handleAttachmentRemoved}
                            onClose={this.handleOnClose}
                            selectedAttachment={this.state.selectedAttachment}
                            editable={selectedAttachment && selectedAttachment.type == 'InspectionWarrant' ? false : editable}
                            attachmentModalVisible={this.state.attachmentModalVisible}
                        />
                    </Modal>
                    {!attachmentList || !attachmentList.length ? (
                        <View style={styles.outerContainerNoAttachment}>
                            {editable ? <View style={[styles.fieldContainerAttachement, { flex: 1 }]}>{this.renderAddPictureButton()}</View> : null}
                        </View>
                    ) : (
                        <View style={styles.outerContainerWithAttachment}>
                            <AttachmentList attachments={attachmentList} editable={editable} onPress={this.handleThumbnailPressed} />
                            {editable ? <View style={styles.buttonWithAttachmentsContainer}>{this.renderAddPictureButton()}</View> : null}
                        </View>
                    )}
                </View>

                {errorLogs.attachmentList ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={[styles.fieldContainer]}>
                            <TextInput
                                style={styles.input}
                                placeholder={strings('newRemarks')}
                                value={remarks}
                                editable={editable}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                autoCorrect={false}
                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                autoCapitalize="sentences"
                                //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                autoFocus={false}
                                multiline={true}
                                textAlignVertical={'top'}
                            />
                        </View>
                        {errorLogs.remarks ? (
                            <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                        ) : null}
                    </View>
                </View>

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd, { alignItems: 'center' }]}>
                        <Text style={styles.label}> {strings('actualNoOfUnits')}</Text>
                        {readOnly ? (
                            <>
                                <Text style={styles.valueReadOnlyText}>{actualNoOfUnits}</Text>
                                {errorLogs.actualNoOfUnits && (
                                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                        {strings('actualNoOfUnits') + ' ' + strings('isRequired')}
                                    </Text>
                                )}
                            </>
                        ) : (
                            <View style={[styles.fieldContainer]}>
                                <NumericInput
                                    value={actualNoOfUnits || 0}
                                    initValue={actualNoOfUnits || 0}
                                    totalWidth={120}
                                    minValue={0}
                                    totalHeight={40}
                                    onChange={this.handleFieldChange.bind(this, 'actualNoOfUnits')}
                                />
                            </View>
                        )}
                    </View>

                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd, { alignItems: 'center' }]}>
                        <Text style={styles.label}> {strings('actualNoOfOccupants')}</Text>
                        {readOnly ? (
                            <>
                                <Text style={styles.valueReadOnlyText}>{actualNoOfOccupants}</Text>
                                {errorLogs.actualNoOfOccupants && (
                                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                                        {strings('actualNoOfOccupants') + ' ' + strings('isRequired')}
                                    </Text>
                                )}
                            </>
                        ) : (
                            <View style={styles.fieldContainer}>
                                <NumericInput
                                    value={actualNoOfOccupants || 0}
                                    initValue={actualNoOfOccupants || 0}
                                    totalWidth={120}
                                    minValue={0}
                                    totalHeight={40}
                                    onChange={this.handleFieldChange.bind(this, 'actualNoOfOccupants')}
                                />
                            </View>
                        )}
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={{ flex: 1 }}>
                        <View style={styles.fieldWrapper}>
                            <Switch
                                editable={editable}
                                showHint={false}
                                onChange={this.handleFieldChange.bind(this, 'occupancyLawViolationExists')}
                                value={occupancyLawViolationExists}
                                label={strings('occupancyLawViolationExists')}
                            />
                        </View>
                    </View>
                </View>

                {occupancyLawViolationExists && (
                    <View>
                        <View style={styles.fieldrow}>
                            <View style={{ flex: 1 }}>
                                <AddViolator
                                    dispatch={dispatch}
                                    inspection={inspection}
                                    violator={currentViolator}
                                    editable={editable}
                                    existingViolators={existingViolators}
                                    onViolatorSelected={this.onViolatorSelected}
                                    onViolatorEdited={this.handleOnViolatorEdited}
                                    onViolatorRemoved={this.handleOnViolatorRemoved}
                                    possibleViolatorTypes={['individual', 'company']}
                                    onReconciled={this.handleonReconciled}
                                    showReconciliation={showReconciliation}
                                    reconciled={reconciled}
                                />
                            </View>
                        </View>
                        {showOccupants && (
                            <View style={styles.fieldrow}>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.label}> {strings('occupants')}</Text>
                                    <View style={[styles.fieldContainer, styles.fieldContainerBorder]}>
                                        <Occupants value={occupants} editable={editable} onChange={this.handleFieldChange.bind(this, 'occupants')} />
                                    </View>
                                </View>
                            </View>
                        )}
                    </View>
                )}
            </View>
        );
    };
}
export default ResUnitOccupancyWarrantApprovedForm;
