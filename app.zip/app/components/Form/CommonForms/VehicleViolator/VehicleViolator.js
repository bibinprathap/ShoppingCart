import React, { Component } from 'react';
import { View, TextInput, Picker } from 'react-native';
import { connect } from 'react-redux';
import AppApi from 'app/api/real';
import { strings } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { IconButton, IntegrationFeedback, Switch } from 'app/components';
import styles from './styles';
import { localeProperty } from 'app/config/i18n/i18n';
import { ValidationHelper } from 'app/api/helperServices';
import * as yup from 'yup';
const api = new AppApi();

class VehicleViolator extends Component {
    constructor(props) {
        super(props);
        const { mode, violator } = props;
        if (mode === 'new') {
            this.state = { ...this.getEmptyState() };
        } else {
            this.state = { ...this.getStateFromExistingViolator(violator) };
        }

        this.searchVehicleProfile = this.searchVehicleProfile.bind(this);
        this.checkStateisValid = this.checkStateisValid.bind(this);
    }

    getEmptyState = (preserveSearchParams, searchOn) => {
        const newState = {
            violatorType: 'vehicle',
            isManualEntry: false,
            isPlateNoObtainable: true,
            country: '1000', //UAE
            emirate: '1', //Abu Dhabi
            plateNumber: '',
            titleE: '',
            registeredPhoneNumber: '',
            titleA: '',
            integrationData: undefined,
            detail: undefined,
            make: '',
            model: '',
            color: '',
            plateDescription: '',
            chassisNumber: '',
            plateKind: '',
            plateColor: '',
            vehicleDesc: '',
            mandatoryFields: ['plateNumber', 'plateKind', 'plateColor', 'make', 'model', 'color'],
        };
        if (preserveSearchParams && this.state && this.state.isPlateNoObtainable && searchOn === 'searchByPlateNo') {
            newState.country = this.state.country;
            newState.emirate = this.state.emirate;
            newState.plateKind = this.state.plateKind;
            newState.plateColor = this.state.plateColor;
            //newState.chassisNumber = this.state.chassisNumber;
            newState.plateNumber = this.state.plateNumber;
        }
        if (preserveSearchParams && this.state && this.state.isPlateNoObtainable && searchOn !== 'searchByPlateNo') {
            newState.country = this.state.country;
            newState.emirate = this.state.emirate;
            newState.plateKind = this.state.plateKind;
            newState.plateColor = this.state.plateColor;
            newState.chassisNumber = this.state.chassisNumber;
            newState.plateNumber = this.state.plateNumber;
        }
        if (preserveSearchParams && this.state && !this.state.isPlateNoObtainable) {
            newState.country = this.state.country;
            newState.emirate = this.state.emirate;
            newState.chassisNumber = this.state.chassisNumber;
        }
        return newState;
    };

    getStateFromExistingViolator = violator => {
        //Todo: shouldn't need to check for null, if the API stops serializing null values
        const newState = { ...this.getEmptyState(), ...violator };
        const detail = newState.detail || {};
        newState.detail = detail;
        newState.country =
            typeof detail.nationalityId !== 'undefined' && detail.nationalityId != null ? detail.nationalityId.toString() : newState.country;
        newState.emirate = typeof detail.emirateId !== 'undefined' && detail.emirateId != null ? detail.emirateId.toString() : newState.emirate;
        newState.plateNumber = typeof detail.plateNumber !== 'undefined' && detail.plateNumber != null ? detail.plateNumber : newState.plateNumber;
        newState.make =
            typeof detail.vehicleMakeLkdId !== 'undefined' && detail.vehicleMakeLkdId != null ? detail.vehicleMakeLkdId.toString() : newState.make;
        newState.model =
            typeof detail.vehicleModelLkdId !== 'undefined' && detail.vehicleModelLkdId != null
                ? detail.vehicleModelLkdId.toString()
                : newState.model;
        newState.color =
            typeof detail.vehicleColorLkdId !== 'undefined' && detail.vehicleColorLkdId != null
                ? detail.vehicleColorLkdId.toString()
                : newState.color;
        newState.plateDescription =
            typeof detail.plateDescription !== 'undefined' && detail.plateDescription != null ? detail.plateDescription : newState.plateDescription;
        newState.chassisNumber =
            typeof detail.chassisNumber !== 'undefined' && detail.chassisNumber != null ? detail.chassisNumber : newState.chassisNumber;
        newState.plateKind =
            typeof detail.plateKindLkdId !== 'undefined' && detail.plateKindLkdId != null ? detail.plateKindLkdId.toString() : newState.plateKind;
        newState.plateColor =
            typeof detail.plateColorLkdId !== 'undefined' && detail.plateColorLkdId != null ? detail.plateColorLkdId.toString() : newState.plateColor;
        newState.vehicleDesc = typeof detail.vehicleDesc !== 'undefined' && detail.vehicleDesc != null ? detail.vehicleDesc : newState.vehicleDesc;
        newState.isPlateNoObtainable = typeof detail.isPlateNoObtainable !== 'undefined' ? detail.isPlateNoObtainable : newState.isPlateNoObtainable;
        newState.isManualEntry = typeof detail.isManualEntry !== 'undefined' ? detail.isManualEntry : newState.isManualEntry;
        newState.violatorType = 'vehicle';
        return newState;
    };

    checkStateisValid = async newState => {
        newState.mandatoryFields = [];
        if (newState.isPlateNoObtainable) {
            newState.mandatoryFields.push('plateNumber');
            if (newState.country == 1000 && !newState.isManualEntry) {
                newState.mandatoryFields.push('plateKind', 'plateColor', 'make', 'model', 'color');
            } else if (newState.country == 1000 && newState.isManualEntry) {
                newState.mandatoryFields.push('plateKind', 'plateColor', 'vehicleDesc');
            } else {
                newState.mandatoryFields.push('vehicleDesc');
            }
        } else {
            newState.mandatoryFields.push('vehicleDesc');
        }

        const vehicleValidationSchema = {};
        newState.mandatoryFields.map(f => {
            vehicleValidationSchema[f] = yup.string().required();
            return f;
        });

        try {
            await ValidationHelper.validate(newState, yup.object().shape(vehicleValidationSchema));
            this.props.isValidViolator(true, this.state);
            return;
        } catch (errors) {
            this.props.isValidViolator(false, this.state);
            return;
        }
    };
    handleFieldChange = async (name, value) => {
        let newState = { ...this.state, [name]: value };

        if (name == 'isPlateNoObtainable') {
            newState = { ...this.getEmptyState(), [name]: value };
        }

        if (name == 'country') {
            if (value == 1000) {
                newState.emirate = 1;
            } else newState.emirate = undefined;

            newState.plateKind = '';
            newState.plateColor = '';
            newState.chassisNumber = '';
            newState.plateNumber = '';
            newState.vehicleDesc = '';
            newState.make = '';
            newState.color = '';
        }

        if (name == 'emirate') {
            newState.plateKind = '';
            newState.plateColor = '';
        }

        if (name == 'plateKind') {
            newState.plateColor = '';
        }

        if (name == 'make') {
            newState.model = '';
            newState.color = '';
        }

        newState = this.removeIntegrationSuccess(newState, name, value); //data is no more verified as user has changed something

        console.log('handleFieldChange() name:', name, 'value: ', value, ' newState: ', newState);
        this.updateState(newState);
    };

    removeIntegrationSuccess = (newState, name, value) => {
        if (newState.integrationData && newState.integrationData.success) {
            if (
                name == 'country' ||
                name == 'emirate' ||
                name == 'plateKind' ||
                name == 'plateColor' ||
                name == 'chassisNumber' ||
                name == 'plateNumber'
            ) {
                newState = { ...this.getEmptyState(true), ['isPlateNoObtainable']: this.state.isPlateNoObtainable };
            } else {
                newState = { ...newState, integrationData: undefined };
            }

            newState[name] = value;
            return newState;
        } else return newState;
    };

    updateState = newState => {
        newState.isManualEntry = this.getManualEntryFlag(newState);
        this.setState(newState, () => {
            this.checkStateisValid(this.state);
        });
    };

    getManualEntryFlag = values => {
        let integrationFailure = false;

        if (values.integrationData && !values.integrationData.running && !values.integrationData.success) {
            integrationFailure = true;
        }

        return integrationFailure || values.country != 1000;
    };

    searchVehicleProfile = async (searchOn, isPlateNoObtainable) => {
        const { integrationData } = this.state;

        const isSearching = integrationData && integrationData.running == true;
        let newState = {};
        if (isSearching) return;

        newState = {
            ...this.getEmptyState(true, searchOn),
            ['isPlateNoObtainable']: isPlateNoObtainable,
            integrationData: { running: true, message: strings('integrationProgressMessageDED') },
        };
        this.updateState(newState);

        try {
            const result = await api.getVehicleProfile(newState);
            if (result.detail.nationalityId == 0) result.detail.nationalityId = this.state.country;
            newState = {
                ...this.getStateFromExistingViolator(result),
                ['isPlateNoObtainable']: isPlateNoObtainable,
                integrationData: { running: false, success: true, message: strings('integrationSuccessMessageDED') },
            };
            this.updateState(newState);
        } catch (e) {
            newState = {
                ...this.getEmptyState(true),
                ['isPlateNoObtainable']: isPlateNoObtainable,
                integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageDED') },
            };
            this.updateState(newState);
        }
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    render = () => {
        const {
            isPlateNoObtainable,
            plateNumber,
            titleE,
            registeredPhoneNumber,
            titleA,
            integrationData,
            country,
            emirate,
            make,
            model,
            color,
            chassisNumber,
            plateDescription,
            isManualEntry,
            plateKind,
            plateColor,
            vehicleDesc,
            mandatoryFields,
        } = this.state;
        const { mode, countryOptions, makeOptions, colorOptions, plateColorOptions, plateKindOptions } = this.props;
        const validationStyles = styles.invalid;
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const isSearching = (integrationData && integrationData.running == true) || false;
        const editable = mode === 'new' && !isSearching;
        //const hasIntegrationSuccess = (integrationData && integrationData.success == true) || false;

        const casnsearch = plateNumber.length > 0 && plateKind.length > 0 && plateColor.length > 0;
        const chassissearch = chassisNumber.length > 0;
        const searchButtonstyle = mode === 'new' && !isSearching && casnsearch ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const searchChassisButtonstyle = mode === 'new' && !isSearching && chassissearch ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const emiratesOptions = (countryOptions.find(c => c.id == country) || {}).emirate || [];

        const modelOptions = (makeOptions.find(c => c.id == make) || {}).VehicleModel || [];

        return (
            <View style={styles.containerWithOutBorder}>
                <View style={styles.fieldrow}>
                    <View
                        style={[
                            styles.labelContainer,
                            styles.labelContainerColumnEnd,
                            { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
                        ]}
                    >
                        <View style={[styles.fieldContainer]}>
                            <Switch
                                editable={editable}
                                onChange={this.handleFieldChange.bind(this, 'isPlateNoObtainable')}
                                value={isPlateNoObtainable}
                                label={strings('isPlateNoObtainable')}
                                iconProps={{ name: 'alpha-r-circle-outline', type: 'MaterialCommunityIcons', size: 24 }}
                            />
                        </View>
                    </View>
                </View>

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('country')}</Text>
                            {mandatoryFields.includes('country') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>
                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                            <Picker
                                selectedValue={country}
                                key={`country_${countryOptions.length}`}
                                enabled={editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'country')}
                            >
                                {countryOptions &&
                                    countryOptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        {emiratesOptions.length > 0 ? (
                            <>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.label}> {strings('emirate')}</Text>
                                    {mandatoryFields.includes('emirate') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                </View>

                                <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                    <Picker
                                        selectedValue={emirate}
                                        key={`emirate${emiratesOptions.length}`}
                                        enabled={editable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'emirate')}
                                    >
                                        {emiratesOptions &&
                                            emiratesOptions.map((v, i) => {
                                                return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                            })}
                                    </Picker>
                                </View>
                            </>
                        ) : null}
                    </View>
                </View>

                {country == 1000 && (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateKind')}</Text>
                                {mandatoryFields.includes('plateKind') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={isPlateNoObtainable ? [styles.fieldContainer, styles.fieldContainerPicker] : [styles.fieldContainer]}>
                                <Picker
                                    selectedValue={plateKind}
                                    key={`plateKind${plateKindOptions.length}`}
                                    enabled={isPlateNoObtainable}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'plateKind')}
                                >
                                    <Picker.Item key={4422} label={strings('pleaseselect') + ' ' + strings('plateKind')} value={''} />
                                    {plateKindOptions &&
                                        plateKindOptions.map((v, i) => {
                                            return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                        })}
                                </Picker>
                            </View>
                        </View>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateColor')}</Text>
                                {mandatoryFields.includes('plateColor') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={isPlateNoObtainable ? [styles.fieldContainer, styles.fieldContainerPicker] : [styles.fieldContainer]}>
                                <Picker
                                    selectedValue={plateColor}
                                    key={`plateColor${plateColorOptions.length}`}
                                    enabled={isPlateNoObtainable}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'plateColor')}
                                >
                                    <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('plateColor')} value={''} />
                                    {plateColorOptions &&
                                        plateColorOptions.map((v, i) => {
                                            return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                        })}
                                </Picker>
                            </View>
                        </View>
                    </View>
                )}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('chassisNumber')}</Text>
                            {mandatoryFields.includes('chassisNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>
                        <View style={styles.fieldContainer}>
                            <TextInput
                                style={[styles.input, editable ? null : styles.inputDisabled]}
                                onChangeText={this.handleFieldChange.bind(this, 'chassisNumber')}
                                theme={textInputTheme}
                                value={chassisNumber}
                                editable={editable}
                                placeholder={strings('chassisNumber')}
                                placeholderStyle={{ color: '#000000' }}
                                textAlignVertical={'center'}
                            />
                            <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                            </View>

                            {country == 1000 ? (
                                <View>
                                    <IconButton
                                        type="MaterialCommunityIcons"
                                        name="magnify"
                                        disabled={isSearching || !chassissearch || mode !== 'new'}
                                        style={[styles.buttonSearch, searchChassisButtonstyle]}
                                        onPress={this.searchVehicleProfile.bind(this, 'searchByChassis', isPlateNoObtainable)}
                                    />
                                </View>
                            ) : null}
                        </View>
                    </View>
                    {/* )} */}

                    {isPlateNoObtainable ? (
                        <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('numberPlate')}</Text>
                                {mandatoryFields.includes('plateNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={styles.fieldContainer}>
                                <TextInput
                                    style={styles.input}
                                    onChangeText={this.handleFieldChange.bind(this, 'plateNumber')}
                                    theme={textInputTheme}
                                    value={plateNumber}
                                    editable={editable}
                                    placeholder={strings('numberPlate')}
                                    placeholderStyle={{ color: '#000000' }}
                                    textAlignVertical={'center'}
                                    keyboardType={'numeric'}
                                />
                                <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                    {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                                </View>

                                {country == 1000 ? (
                                    <View>
                                        <IconButton
                                            type="MaterialCommunityIcons"
                                            name="magnify"
                                            disabled={isSearching || !casnsearch || mode !== 'new'}
                                            style={[styles.buttonSearch, searchButtonstyle]}
                                            onPress={this.searchVehicleProfile.bind(this, 'searchByPlateNo', isPlateNoObtainable)}
                                        />
                                    </View>
                                ) : null}
                            </View>
                        </View>
                    ) : (
                        <View style={(styles.labelContainer, styles.labelContainerColumnEnd)}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateNumber')}</Text>
                                {mandatoryFields.includes('plateNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                                <Text style={styles.inputDisabled}> {plateNumber}</Text>
                            </View>
                        </View>
                    )}
                </View>

                {(isManualEntry || !isPlateNoObtainable) && (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('vehicleDesc')}</Text>
                                {mandatoryFields.includes('vehicleDesc') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={[styles.fieldContainer]}>
                                <TextInput
                                    style={styles.input}
                                    onChangeText={this.handleFieldChange.bind(this, 'vehicleDesc')}
                                    theme={textInputTheme}
                                    value={vehicleDesc}
                                    editable={editable}
                                    placeholder={strings('vehicleDesc')}
                                    placeholderStyle={{ color: '#000000' }}
                                    textAlignVertical={'center'}
                                />
                            </View>
                        </View>
                    </View>
                )}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('make')}</Text>
                            {mandatoryFields.includes('make') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>
                        <View style={[styles.fieldContainer, isManualEntry ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled]}>
                            <Picker
                                selectedValue={make}
                                key={`make_${makeOptions.length}`}
                                enabled={isManualEntry && editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'make')}
                            >
                                <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('make')} value={''} />
                                {makeOptions &&
                                    makeOptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('model')}</Text>
                            {mandatoryFields.includes('model') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>

                        <View style={[styles.fieldContainer, isManualEntry ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled]}>
                            <Picker
                                selectedValue={model}
                                key={`model${modelOptions.length}`}
                                enabled={isManualEntry && editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'model')}
                            >
                                <Picker.Item key={2222} label={strings('pleaseselect') + ' ' + strings('model')} value={''} />
                                {modelOptions &&
                                    modelOptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('color')}</Text>
                            {mandatoryFields.includes('color') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>

                        <View style={[styles.fieldContainer, isManualEntry ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled]}>
                            <Picker
                                selectedValue={color}
                                key={`color${colorOptions.length}`}
                                enabled={isManualEntry && editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'color')}
                            >
                                <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('color')} value={''} />
                                {colorOptions &&
                                    colorOptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                    {country == 1000 && !isManualEntry && (
                        <View style={(styles.labelContainer, styles.labelContainerColumnEnd)}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('registeredPhoneNumberFull')}</Text>
                                {mandatoryFields.includes('registeredPhoneNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                                <Text style={styles.inputDisabled}> {registeredPhoneNumber}</Text>
                            </View>
                        </View>
                    )}
                </View>
            </View>
        );
    };
}
const mapStateToProps = (state, ownProps) => {
    const { dataLookups } = state.masterdata;
    return {
        countryOptions: ownProps.countryOptions || dataLookups.country,
        makeOptions: ownProps.makeOptions || dataLookups.VehicleMake,
        colorOptions: ownProps.colorOptions || dataLookups.VehicleColor,
        plateColorOptions: ownProps.plateColorOptions || dataLookups.PlateColor,
        plateKindOptions: ownProps.plateKindOptions || dataLookups.PlateKind,
    };
};

export default connect(mapStateToProps)(VehicleViolator);
