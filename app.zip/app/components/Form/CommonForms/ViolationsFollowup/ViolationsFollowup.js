import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Icon, IconButton, AttachmentList, Switch, commonStyles, Loader, Modal } from 'app/components';
import { Attachments, ViolationActionTypes } from 'app/screens';
import { infoChanged, saveNewInspection } from 'app/actions/inspections';
import { ValidationHelper, lookup } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import { ViolationActionReview } from 'app/components/Preview/ViolationItemReview';
import * as yup from 'yup';

const api = new AppApi();

const emptyFollowUpForm = {
    amount: '',
    selectedPeriod: '',
    selectedPeriodType: 'day',
    isResolved: false,
    remarks: '',
    impoundVehicleYardId: '',
    remarks: '',
    followupAction: '',
    violationActionTypes: '',
    attachmentList: [],
    attachmentModalVisible: false,
    selectedAttachment: null,
    errorLogs: {},
    violationActionTypes: [],
};

class ViolationsFollowup extends Component {
    constructor(props) {
        super(props);
        this.state = { ...emptyFollowUpForm, ...props.initialValue, violationActionTypes: props.actionTypeOptions };
        this.isSubmitable = this.isSubmitable.bind(this);
    }

    resetViolatorState = () => {
        this.updateFollowupState(emptyFollowUpForm);
    };

    updateFollowupState = async newState => {
        let formValue = { ...this.state, ...newState };
        if (formValue.followupAction == 0) {
            formValue = { ...formValue, followupAction: '' };
        }
        const { yardOptions, visitIndex, actionTypeOptions, violator, violation, hideYard } = this.props;
        const followupValidationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        if (formValue.isResolved == null || formValue.isResolved == false) {
            // followupValidationSchema.selectedPeriodType = yup.string().required();
            followupValidationSchema.followupAction = yup.string().required();
            const actionItem = inspectionsHelper.findViolationAction({
                violationActionTypes: actionTypeOptions,
                selectedActionType: formValue.followupAction,
            });
            if (actionItem && actionItem.constant == 'warning') {
                followupValidationSchema.selectedPeriodType = yup.string().required();
                followupValidationSchema.selectedPeriod = yup.number().required();
            } else if (!hideYard && actionItem && actionItem.constant == 'violation') {
                //  followupValidationSchema.amount = yup.string().required();
                followupValidationSchema.impoundVehicleYardId = yup.string().required();
            }
        }

        let errorLogs = {};

        try {
            await ValidationHelper.validate(formValue, yup.object().shape(followupValidationSchema));
        } catch (errors) {
            //            return;
            Object.getOwnPropertyNames(errors).map(er => {
                errorLogs[er] = errors[er];
            });
        }

        newState.errorLogs = errorLogs;

        this.setState(newState, () => {
            const { visitIndex } = this.props;
            this.props.dispatch(infoChanged('followupForm', this.state, visitIndex));
            this.isSubmitable();
        });
    };
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    componentDidMount() {
        if (this.isSubmitable) this.isSubmitable();
    }
    handleOnAdd = newAttachment => {
        const { attachmentList } = this.state;
        const newAttachmentsArray = attachmentList ? attachmentList.slice() : [];
        newAttachmentsArray.push(newAttachment);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleAttachmentRemoved = doc => {
        const { attachmentList } = this.state;
        const currentAttachments = attachmentList;
        const newAttachmentsArray = _.without(currentAttachments, doc);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleCameraPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateFollowupState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );
    // handleSave = () => {
    //     const { errorLogs, attachmentList, remarks } = this.state;
    //     const isAllowedToSave = Object.getOwnPropertyNames(errorLogs).length == 0 && attachmentList.length > 0 && remarks.length > 0;
    //     if (isAllowedToSave) {
    //         const { inspection } = this.props;
    //         if (!inspectionsHelper.getPendingAttachementList(inspection)) {
    //             this.props.dispatch(saveNewInspection(inspection, true));
    //         } else {
    //             this.props.dispatch(savefollowupLocalSuccess(inspection));
    //             alertsHelper.show('success', 'Saved', 'FollowUp Submitted Successfully');
    //         }

    //         let currentVisitIndex = this.props.inspection.visits.length - 1;
    //         const taskId = this.props.inspection.visits[currentVisitIndex].taskId;

    //         this.props.dispatch({
    //             type: TASK_STARTED,
    //             payload: { taskId, refNumber: this.props.inspection.refNumber, status: 'completed' },
    //         });
    //     }
    // };
    isSubmitable = async () => {
        const { errorLogs, attachmentList, remarks } = this.state;
        const isAllowedToSave =
            (!errorLogs || (errorLogs && Object.getOwnPropertyNames(errorLogs).length == 0)) &&
            attachmentList &&
            attachmentList.length > 0 &&
            remarks &&
            remarks.length > 0;
        if (this.props.isSubmitable) this.props.isSubmitable({ isAllowedToSave });
    };

    handleActionChange = callProps => {
        const { params, inspTypeCheckItemId, reset } = callProps;
        this.updateFollowupState({
            amount: params.violationAmount != undefined ? params.violationAmount : this.state.amount,
            followupAction: params.selectedActionType != undefined ? params.selectedActionType : this.state.followupAction,
            selectedPeriod: params.selectedPeriod != undefined ? params.selectedPeriod : this.state.selectedPeriod,
            selectedPeriodType: params.selectedPeriodType != undefined ? params.selectedPeriodType : this.state.selectedPeriodType,
        });
    };

    render = () => {
        const {
            amount,
            selectedPeriod,
            selectedPeriodType,
            isResolved,
            remarks,
            impoundVehicleYardId,
            followupAction,
            violationActionTypes,
            attachmentList,
            errorLogs,
        } = this.state;

        const validationStyles = styles.invalid;
        const fieldEditable = false;
        const readOnlyRtlStyles = I18nManager.isRTL
            ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
            : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const customFieldContainerStyles = [styles.fieldContainerShadowed, styles.customFieldRowContainer, { padding: 10 }];
        const { yardOptions, visitIndex, actionTypeOptions, violator, violation, editable, inspection, readOnly, hideYard } = this.props;
        const impoundVehicleYardOptions = yardOptions || [];
        const actionItem = inspectionsHelper.findViolationAction({
            violationActionTypes: actionTypeOptions,
            selectedActionType: followupAction,
        });

        //  const isAllowedToSave = Object.getOwnPropertyNames(errorLogs).length == 0 && (attachmentList || '').length > 0 && (remarks || '').length > 0;
        // const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonPositive : styles.buttonPositiveDisabled;
        // const saveTextstyle = isAllowedToSave && editable == true ? styles.buttonText : styles.buttonTextPositiveDisabled;

        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer} />
                    </View>
                </View>

                <View style={styles.fieldContainerAttachement}>
                    <Modal
                        animationType="slide"
                        transparent={false}
                        visible={this.state.attachmentModalVisible}
                        onRequestClose={this.toggleAttachmentDialog}
                    >
                        <Attachments
                            attachments={attachmentList}
                            onAdd={this.handleOnAdd}
                            onRemove={this.handleAttachmentRemoved}
                            onClose={this.handleOnClose}
                            selectedAttachment={this.state.selectedAttachment}
                            editable={editable}
                            attachmentModalVisible={this.state.attachmentModalVisible}
                        />
                    </Modal>
                    {!attachmentList || !attachmentList.length ? (
                        <View
                            style={[
                                styles.outerContainerNoAttachment,
                                { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, marginHorizontal: 12 },
                            ]}
                        >
                            {editable ? <View style={[styles.fieldContainerAttachement, { flex: 1 }]}>{this.renderAddPictureButton()}</View> : null}
                        </View>
                    ) : (
                        <View style={[styles.outerContainerNoAttachment]}>
                            <View
                                style={[
                                    styles.outerContainerWithAttachment,

                                    { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, marginHorizontal: 12 },
                                ]}
                            >
                                <AttachmentList attachments={attachmentList} editable={editable} onPress={this.handleThumbnailPressed} />
                                {editable ? <View style={styles.buttonWithAttachmentsContainer}>{this.renderAddPictureButton()}</View> : null}
                            </View>
                        </View>
                    )}
                </View>

                {errorLogs.attachmentList ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    {/* <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}> */}
                    {/* <View style={[styles.fieldContainer, { marginStart: 5 }]}> */}
                    <View style={customFieldContainerStyles}>
                        <Switch
                            editable={editable}
                            onChange={this.handleFieldChange.bind(this, 'isResolved')}
                            value={isResolved}
                            label={strings('isItResolved')}
                            iconProps={{ name: 'shield-check', type: 'MaterialCommunityIcons', size: 24 }}
                        />
                    </View>
                    {/* </View> */}
                    {/* </View> */}
                </View>

                {!isResolved ? (
                    <View
                        style={{
                            flex: 1,
                            margin: 0,
                            padding: 0,
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            backgroundColor: '#ffffff',
                            elevation: 1,
                            borderRadius: 4,
                        }}
                    >
                        {actionItem && readOnly ? (
                            <View style={styles.ViolationActionContainer}>
                                <ViolationActionReview
                                    selectedActionTypeConst={actionItem.constant}
                                    amount={amount}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                ></ViolationActionReview>
                            </View>
                        ) : (
                            <>
                                <ViolationActionTypes
                                    onActionChange={this.handleActionChange}
                                    editable={editable}
                                    violator={violator}
                                    violation={violation}
                                    violationActionTypesLoading={false}
                                    violationActionTypesSuccess={true}
                                    isEngineerReviewRequired={false}
                                    violationActionTypes={actionTypeOptions}
                                    currentVisitIndex={visitIndex}
                                    selectedActionType={followupAction}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                />

                                {amount > 0 && (
                                    <View style={{ alignItems: 'flex-end', justifyContent: 'center', paddingRight: 15 }}>
                                        <Text style={styles.price}>AED {amount}</Text>
                                    </View>
                                )}
                            </>
                        )}
                    </View>
                ) : null}
                {errorLogs.followupAction ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('actionType') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {errorLogs.selectedPeriod ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('selectedPeriod') + ' ' + strings('isRequired')}</Text>
                ) : null}

                {!hideYard && !isResolved && actionItem && actionItem.constant === 'violation' ? (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                            <Text style={styles.label}> {strings('yard')}</Text>
                            <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                {readOnly ? (
                                    <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>
                                        {impoundVehicleYardId && lookup.getLabel('vehicleYard', impoundVehicleYardId, '', '')}
                                    </Text>
                                ) : (
                                    <Picker
                                        selectedValue={impoundVehicleYardId}
                                        key={`yard${impoundVehicleYardOptions.length}`}
                                        enabled={editable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'impoundVehicleYardId')}
                                    >
                                        <Picker.Item key={4422} label={strings('pleaseselect') + ' ' + strings('yard')} value={''} />
                                        {impoundVehicleYardOptions &&
                                            impoundVehicleYardOptions.map((v, i) => {
                                                return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                            })}
                                    </Picker>
                                )}
                            </View>
                        </View>
                    </View>
                ) : null}
                {errorLogs.impoundVehicleYardId ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('yard') + ' ' + strings('isRequired')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={[styles.fieldContainer]}>
                            <TextInput
                                style={styles.input}
                                placeholder={strings('newRemarks')}
                                value={remarks}
                                editable={editable}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                autoCorrect={false}
                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                autoCapitalize="sentences"
                                //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                autoFocus={false}
                                multiline={true}
                                textAlignVertical={'top'}
                            />
                        </View>
                    </View>
                </View>
                {errorLogs.remarks ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {/* {!readOnly ? (
                    <View style={[styles.summaryContainer]}>
                        <View style={styles.summaryItem}>
                            <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="content-save"
                                    borderRadius={25}
                                    disabled={!(isAllowedToSave && editable)}
                                    style={[styles.button, saveButtonstyle]}
                                    onPress={this.handleSave}
                                >
                                    <Text style={saveTextstyle}>{strings('save')}</Text>
                                </IconButton>
                            </Loader>
                        </View>
                    </View>
                ) : null} */}
            </View>
        );
    };
}
export default ViolationsFollowup;
