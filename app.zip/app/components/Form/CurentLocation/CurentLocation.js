import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Text, TouchableRipple } from 'react-native-paper';
import { Icon, HeaderGeneric, ADMGISMapView, commonStyles, Modal } from 'app/components';
import { formatAddress } from 'app/api/helperServices/utils';
import { getLocation } from 'app/api/helperServices/geolocation';
import styles from './styles';
import AppApi from 'app/api/real';
const api = new AppApi();

class CurentLocation extends Component {
    static propTypes = {
        generalRemarks: PropTypes.string,
        address: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
        };
    }
    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };
    async componentDidMount() {
        if (!(this.props.currentLocation && this.props.currentLocation.coords && this.props.currentLocation.address)) {
            try {
                const currentLocation = await getLocation();

                await this.handleCoordsChanged(currentLocation);
            } catch (error) {}
        }
    }
    handleCoordsChanged = async coords => {
        try {
            const address = await api.getAddress(coords);
            this.props.onChange({ coords, address });
        } catch (error) {}
    };
    render() {
        const { currentLocation } = this.props;
        let coords = {};
        let address = {};
        if (currentLocation) {
            coords = currentLocation.coords;
            address = currentLocation.address;
        }
        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];
        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={this.toggleLocationDialog} title={strings('address')} />
                    <View style={{ height: '100%', width: '100%' }}>
                        <ADMGISMapView coords={coords} placeMarks={placeMarkData} />
                    </View>
                </Modal>
                <View style={styles.addressContainer}>
                    <View style={{ flex: 1 }}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('address')}</Text>
                        <Text style={commonStyles.generalText}>{formatAddress(address)}</Text>
                        <Text style={styles.coordsText}>
                            {coords
                                ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                                : strings('latitudeAndLongitude')}
                        </Text>
                    </View>
                    <View style={styles.addressIconContainer}>
                        <TouchableRipple onPress={this.toggleLocationDialog}>
                            <Icon type="MaterialCommunityIcons" name="map-marker" style={styles.addressIcon} size={20} color={'white'} />
                        </TouchableRipple>
                    </View>
                </View>
            </ScrollView>
        );
    }
}
export default CurentLocation;
