import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Text, TouchableRipple } from 'react-native-paper';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import ADMGISMapView from 'app/components/ADMGISMapView/ADMGISMapView';
import commonStyles from 'app/components/Preview/styles';
import { formatAddress } from 'app/api/helperServices/utils';
import { getLocation } from 'app/api/helperServices/geolocation';
import { coordsChanged, addressChanged } from 'app/actions/inspections';
import styles from './styles';
import AppApi from 'app/api/real';
const api = new AppApi();

class CurentLocation extends Component {
    static propTypes = {
        generalRemarks: PropTypes.string,
        address: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
        };
    }
    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };
    async componentDidMount() {
        // const { location } = this.props.currentLocation;
        // // console.log('location123', location);
        if (!(this.props.currentLocation && this.props.currentLocation.coords && this.props.currentLocation.address)) {
            try {
                const currentLocation = await getLocation();
                debugger;
                await this.handleCoordsChanged(currentLocation);
            } catch (error) {
                console.log('getLocation error: ', error);
            }
        }
    }
    handleCoordsChanged = async coords => {
        debugger;
        try {
            const address = await api.getAddress(coords);
            this.props.onChange({ coords, address });
            debugger;
        } catch (error) {
            console.log('error in api.getAddress. ', error);
        }
    };
    render() {
        const { currentLocation } = this.props;
        let coords = {};
        let address = {};
        //this.props.tracking && this.props.tracking.lastEvent && this.props.tracking.lastEvent.location;
        if (currentLocation) {
            coords = currentLocation.coords;
            address = currentLocation.address;
        }
        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];
        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={this.toggleLocationDialog} title={strings('address')} />
                    <View style={{ height: '100%', width: '100%' }}>
                        <ADMGISMapView coords={coords} placeMarks={placeMarkData} />
                    </View>
                </Modal>
                <View style={styles.addressContainer}>
                    <View style={{ flex: 1 }}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('address')}</Text>
                        <Text style={commonStyles.generalText}>{formatAddress(address)}</Text>
                        <Text style={styles.coordsText}>
                            {coords
                                ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                                : strings('latitudeAndLongitude')}
                        </Text>
                    </View>
                    <View style={styles.addressIconContainer}>
                        <TouchableRipple onPress={this.toggleLocationDialog}>
                            <LineIcons style={styles.addressIcon} name={'location-pin'} size={20} color={'white'} />
                        </TouchableRipple>
                    </View>
                </View>
            </ScrollView>
        );
    }
}
export default CurentLocation;
