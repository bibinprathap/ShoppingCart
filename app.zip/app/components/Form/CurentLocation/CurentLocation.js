import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';

import { Text, Divider, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import ADMGISMapView from 'app/components/ADMGISMapView/ADMGISMapView';
import commonStyles from 'app/components/Preview/styles';
import { formatAddress } from 'app/api/helperServices/utils';
import styles from './styles';

class CurentLocation extends Component {
    static propTypes = {
        generalRemarks: PropTypes.string,
        address: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
        };
    }

    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };

    render() {
        const { currentLocation } = this.props;
        let { coords, address } = this.props.tracking && this.props.tracking.lastEvent && this.props.tracking.lastEvent.location;
        if (currentLocation) {
            coords = currentLocation.coords;
            address = currentLocation.address;
        }
        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];

        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={this.toggleLocationDialog} title={strings('address')} />
                    <View style={{ height: '100%', width: '100%' }}>
                        <ADMGISMapView coords={coords} placeMarks={placeMarkData} />
                    </View>
                </Modal>
                <View style={styles.addressContainer}>
                    <View style={{ flex: 1 }}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('address')}</Text>
                        <Text style={commonStyles.generalText}>{formatAddress(address)}</Text>
                        <Text style={styles.coordsText}>
                            {coords
                                ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                                : strings('latitudeAndLongitude')}
                        </Text>
                    </View>
                    <View style={styles.addressIconContainer}>
                        <TouchableRipple onPress={this.toggleLocationDialog}>
                            <LineIcons style={styles.addressIcon} name={'location-pin'} size={20} color={'white'} />
                        </TouchableRipple>
                    </View>
                </View>
            </ScrollView>
        );
    }
}

const mapStateToProps = state => {
    return {
        tracking: state.tracking,
    };
};

const connectedCurentLocation = connect(mapStateToProps)(CurentLocation);
export default connectedCurentLocation;
