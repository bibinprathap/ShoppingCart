import React from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { formatCurrency } from 'app/config/i18n/i18n';
import { styles } from 'app/components/Form';
import { IconAndLabel } from 'app/components/InputControls';

export default function(props) {
    const { input, meta, ...otherProps } = props;
    return (
        <View style={styles.customFieldContainer}>
            <IconAndLabel
                label={formatCurrency(input.value)}
                iconStyle={{ color: otherProps.iconColor }}
                icon={otherProps.icon}
                iconType={otherProps.iconType}
            />
        </View>
    );
}
