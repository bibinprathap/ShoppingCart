import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { AttachmentListWithDialog } from 'app/screens';
import { commonStyles } from 'app/components';

class RFAttachmentList extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    handleOnAdd = newAttachment => {
        const currentAttachments = this.props.input.value;
        const newAttachmentsArray = currentAttachments || [];
        newAttachmentsArray.push(newAttachment);
        this.props.input.onChange(newAttachmentsArray);
    };

    handleAttachmentRemoved = docId => {
        const currentAttachments = this.props.input.value;
        const newAttachmentsArray = _.without(currentAttachments, docId);

        this.props.input.onChange(newAttachmentsArray);
    };

    render() {
        const { input, meta, validationerror, ...otherProps } = this.props;
        const { value } = input || {};

        return (
            <>
                <AttachmentListWithDialog {...otherProps} attachments={value} onAdd={this.handleOnAdd} onRemove={this.handleAttachmentRemoved} />
                <View style={{ flex: 1 }}>
                    {this.state && this.state.Focused && this.state.errors && <Text>{this.state.errors[input.name]}</Text>}
                    {!(this.state && this.state.Focused && this.state.errors) && validationerror && validationerror.length > 0 && (
                        <Text style={commonStyles.ValidationMessageText}>{validationerror}</Text>
                    )}
                </View>
            </>
        );
    }
}

export default RFAttachmentList;
