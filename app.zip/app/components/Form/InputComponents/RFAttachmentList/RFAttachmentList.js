import React from 'react';
import PropTypes from 'prop-types';
import { View, TouchableNativeFeedback, ScrollView, Modal } from 'react-native';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import Icon from 'react-native-vector-icons/MaterialIcons';
//import { AttachmentList } from 'app/components/AttachmentList';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { Attachments } from 'app/screens/attachments';

import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import * as yup from 'yup';
import commonStyles from 'app/components/Preview/styles';
import { ValidationHelper } from 'app/api/helperServices';

class RFAttachmentList extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };
    constructor(props) {
        super(props);
        this.state = { attachmentModalVisible: false, selectedAttachmentId: null };
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
        this.validateAttachment = this.validateAttachment.bind(this);
    }

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    validateattAchements = async ({ input, validationRule, newAttachmentsArray }) => {
        const validationSchema = yup.object().shape({
            [input.name]: ValidationHelper.getValidationRule(validationRule, 'Minimum one attachement is required'),
        });
        let validationLogs = {};
        try {
            await ValidationHelper.validate({ [input.name]: newAttachmentsArray }, validationSchema);
        } catch (errors) {
            validationLogs = errors;
        }
        return validationLogs;
    };
    handleCameraPressed = () => {
        const { input } = this.props;
        //Todo: do any validation on the input for error handling and hints for debugging
        //this.handleOnClose();
        this.setState({
            attachmentModalVisible: true,
        });
    };
    validateAttachment = () => {
        const { input, validationRule } = this.props;
        if (validationRule) {
            this.validateattAchements({ input, validationRule, newAttachmentsArray: input.value }).then(errors => {
                this.setState({ Focused: true, errors: errors });
            });
        }
    };
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    handleOnAdd = newAttachment => {
        const currentAttachments = this.props.input.value;
        const newAttachmentsArray = currentAttachments ? currentAttachments.slice() : [];
        newAttachmentsArray.push(newAttachment);
        this.props.input.onChange(newAttachmentsArray);
    };

    handleAttachmentRemoved = docId => {
        const currentAttachments = this.props.input.value;
        const newAttachmentsArray = _.without(currentAttachments, docId);
        //  console.log('currentAttachments', currentAttachments, 'newAttachmentsArray', newAttachmentsArray);
        this.props.input.onChange(newAttachmentsArray);
    };

    handleThumbnailPressed = docId => {
        this.setState({ attachmentModalVisible: true, selectedAttachmentId: docId });
    };

    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon name="add-a-photo" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );

    render() {
        const { input, meta, validationerror, ...otherProps } = this.props;
        const { value } = input || {};

        return (
            <>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.attachmentModalVisible}
                    onRequestClose={this.toggleAttachmentDialog}
                >
                    <Attachments
                        attachments={input.value}
                        onAdd={this.handleOnAdd}
                        onRemove={this.handleAttachmentRemoved}
                        onClose={this.handleOnClose}
                        selectedAttachmentId={this.state.selectedAttachmentId}
                        editable={this.props.editable}
                        attachmentModalVisible={this.state.attachmentModalVisible}
                    />
                </Modal>
                {!value || !value.length ? (
                    <View style={styles.outerContainerNoAttachment}>
                        {this.props.editable ? <View style={{ flex: 1 }}>{this.renderAddPictureButton()}</View> : null}
                        {/* <Text style={styles.emptyAttachmentListMessage}>Todo: show proper message about empty list ---- {strings('addPicture')}</Text> */}
                        <View style={{ flex: 1 }}>
                            {this.state && this.state.Focused && this.state.errors && <Text>{this.state.errors[input.name]}</Text>}
                            {!(this.state && this.state.Focused && this.state.errors) && validationerror && (
                                <Text style={commonStyles.ValidationMessageText}>{validationerror}</Text>
                            )}
                        </View>
                    </View>
                ) : (
                    <View style={styles.outerContainerNoAttachment}>
                        <View style={styles.outerContainerWithAttachment}>
                            <AttachmentList
                                attachments={value}
                                editable={this.props.editable}
                                hideDelete={!this.props.hideDelete}
                                onPress={this.handleThumbnailPressed}
                            />

                            {this.props.editable ? (
                                <View style={styles.buttonWithAttachmentsContainer}>
                                    <Text />
                                    {this.state && this.state.Focused && this.state.errors && (
                                        <View style={{ flex: 1 }}>
                                            <Text>{this.state.errors[input.name]}</Text>
                                        </View>
                                    )}

                                    {this.renderAddPictureButton()}
                                </View>
                            ) : null}
                        </View>
                    </View>
                )}
            </>
        );
    }
}

export default RFAttachmentList;
