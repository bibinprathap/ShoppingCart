import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    outerContainerNoAttachment: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 10,
    },
    outerContainerWithAttachment: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonWithAttachmentsContainer: {
        flex: 1,
        maxWidth: 70,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    buttonContainer: {
        borderColor: '$primaryBorderColor',
        borderWidth: '$primaryBorderThin',
        padding: 5,
        borderRadius: 10,
    },
    emptyAttachmentListMessage: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
});
