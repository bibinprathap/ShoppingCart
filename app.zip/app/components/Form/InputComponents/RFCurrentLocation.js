import React, { memo } from 'react';
import { CurentLocation } from 'app/components';

export default memo(function(props) {
    const { input, editable, meta, ...otherProps } = props;
    const value = input.value;

    return <CurentLocation onChange={input.onChange} label={otherProps.label} currentLocation={value} />;
});
