import React from 'react';
import PropTypes from 'prop-types';
import CurentLocation from 'app/components/Form/CurentLocation/CurentLocation';

class RFCurrentLocation extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const { input, editable, meta, ...otherProps } = this.props;
        const value = input.value;

        return <CurentLocation onChange={input.onChange} label={otherProps.label} currentLocation={value} />;
    }
}

export default RFCurrentLocation;
