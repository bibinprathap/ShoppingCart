import React from 'react';
import PropTypes from 'prop-types';
import CurentLocation from 'app/components/Form/CurentLocation/CurentLocation';

export default function(props) {
    const { input, editable, meta, ...otherProps } = props;
    const value = input.value;

    return <CurentLocation onChange={input.onChange} label={otherProps.label} currentLocation={value} />;
}
