import React from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { styles } from 'app/components/Form';
import { IconAndLabel } from 'app/components/InputControls';

class RFCustom extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const { input, meta, ...otherProps } = this.props;
        return (
            <View style={styles.customFieldContainer}>
                <IconAndLabel label={otherProps.label} iconProps={{ icon: otherProps.icon, iconType: otherProps.iconType }} />
                <Icon name={'launch'} size={24} />
            </View>
        );
    }
}

export default RFCustom;
