import React, { memo } from 'react';
import { View } from 'react-native';
import { IconAndLabel, Icon, formStyles as styles } from 'app/components';

export default memo(function(props) {
    const { input, meta, ...otherProps } = props;
    return (
        <View style={styles.customFieldContainer}>
            <IconAndLabel label={otherProps.label} iconProps={{ icon: otherProps.icon, iconType: otherProps.iconType }} />
            <Icon type="MaterialCommunityIcons" name={'launch'} size={24} />
        </View>
    );
});
