import React from 'react';
import { View, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import { Field } from 'redux-form';
import { localeProperty } from 'app/config/i18n/i18n';
import Icon from 'react-native-vector-icons/MaterialIcons';
import IntegrationFeedback from 'app/components/Form/IntegrationFeedback/IntegrationFeedback';
import {
    styles,
    RFTextInput,
    RFMaskedTextInput,
    RFSwitch,
    RFCustom,
    RFAttachmentList,
    RFSignature,
    RFPicker,
    RFNumeric,
    RFperiodPicker,
    RFDateTimePicker,
    CurentLocation,
} from 'app/components/Form';
import * as Animatable from 'react-native-animatable';

class RFField extends React.Component {
    constructor(props) {
        super(props);
        const { type } = props;
        // this.normalizer = this.normalizeNeutral;
        // this.parser = this.parseNeutral;
        // this.formatter = this.formatNeutral;
        switch (type) {
            case 'text':
                this.fieldComponent = RFTextInput;
                break;
            case 'date':
                this.fieldComponent = RFDateTimePicker;
                break;
            case 'picker':
                this.fieldComponent = RFPicker;
                break;
            case 'maskedText':
                this.fieldComponent = RFMaskedTextInput;
                break;
            case 'switch':
                this.fieldComponent = RFSwitch;
                //this.normalizer = this.normalizeBoolean;
                this.parser = this.parseBoolean;
                //this.formatter = this.formatBoolean;
                break;
            case 'numeric':
                this.fieldComponent = RFNumeric;
                break;
            case 'periodPicker':
                this.fieldComponent = RFperiodPicker;
                break;
            case 'signature':
                this.fieldComponent = RFSignature;
                break;
            case 'attachmentList':
                this.fieldComponent = RFAttachmentList;
                break;
            case 'custom':
                this.fieldComponent = RFCustom;
            case 'currentLocation':
                formattedValue = CurentLocation;

                break;
            default:
                console.log(`RFField: unsupported type -->${type}`);
        }
    }

    handleFieldChange = (event, newValue, previousValue, name) => {
        //console.log(event, newValue, previousValue, name);
        if (!!this.props.onFieldchange) this.props.onFieldchange(event, newValue, previousValue, name);
    };

    normalizeNeutral = value => {
        //  console.log(`${this.props.name} - normalizeNeutral, value: ${value}, typeof value : ${typeof value}`);
        return value;
    };
    parseNeutral = value => {
        //  console.log(`${this.props.name} - parseNeutral, value: ${value}, typeof value : ${typeof value}`);
        return value;
    };

    formatNeutral = value => {
        // console.log(`${this.props.name} - formatNeutral, value: ${value}, typeof value : ${typeof value}`);
        return value;
    };

    render() {
        const { showLabel = true, mode, type, editable, integrated, integrationSource, integrationData, isMandatory, index } = this.props;
        const localeLabel = localeProperty(this.props, 'label');
        const localePlaceholder = localeProperty(this.props, 'placeholder');
        const fieldStyles = [styles.fieldContainer, mode === 'flat' ? styles.fieldContainerFlat : styles.fieldContainerShadowed];
        if (type === 'numeric') {
            fieldStyles.push(styles.justify);
        }

        const labelStyle = editable ? styles.label : styles.labelNotActive;
        if (!editable && mode !== 'flat') {
            fieldStyles.push(styles.noShadow);
        }

        const integrationSourceFieldIndicator = integrationData && <IntegrationFeedback integrationData={integrationData} />;
        const integrationFieldIndicator = integrationData && !integrationData.running && !!integrationData.success && integrationSourceFieldIndicator;
        return (
            <Animatable.View
                style={styles.fieldOuterContainer}
                animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                duration={400}
                useNativeDriver={true}
                easing="ease-out"
                delay={index ? index * 100 : 0}
            >
                {!!showLabel && (
                    <>
                        <View style={[styles.labelContainer]}>
                            <View style={{ flexDirection: 'row', flex: 1 }}>
                                <Text style={[labelStyle]}>{localeLabel}</Text>
                                {isMandatory ? <Text style={[styles.ValidationMessageTextForm]}>*</Text> : null}
                            </View>
                            <View>
                                {integrated && integrationFieldIndicator}
                                {integrationSource && integrationSourceFieldIndicator}
                            </View>
                        </View>
                    </>
                )}
                <View style={fieldStyles}>
                    {!!this.fieldComponent && (
                        <Field
                            component={this.fieldComponent}
                            {...this.props}
                            label={localeLabel}
                            placeholder={localePlaceholder}
                            //normalize={this.normalizer}
                            //parse={this.parser}
                            //format={this.formatter}
                            onChange={this.handleFieldChange}
                        />
                    )}
                    {/* label={localeLabel}  this should be at the end, to overwrite the label prop in this.props, if any*/}
                </View>
            </Animatable.View>
        );
    }
}

export default RFField;
