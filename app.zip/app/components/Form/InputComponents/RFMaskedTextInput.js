import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import TextInputMask from 'react-native-text-input-mask';
import { styles } from 'app/components/Form';

export default function(props) {
    handleChangeText = (formatted, extracted) => {
        //console.log(`RFMaskedTextInput, formatted = [${formatted}], extracted = [${extracted}]`);
        props.input.onChange(extracted);
    };

    // const textInputTheme = {
    //     roundness: styles.input.borderRadius,
    //     colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
    // };
    const textInputTheme = {
        //roundness: styles.input.borderRadius,
        colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
    };
    const { input, meta, ...otherProps } = props;
    const { placeholder, maxLength } = otherProps;
    delete otherProps.label;
    delete otherProps.placeholder;
    /* note: react native paper uses label property for the animated placeholder */
    const conitionalLabel = !!input.value ? null : placeholder;
    //console.log('RFMaskedTextInput.props:', props);
    const inputLength = input.value ? input.value.length : 0;
    return (
        <View style={[{ flex: 1 }, styles.fieldHeight]}>
            {!!maxLength && (
                <Text style={styles.inputLength}>
                    {inputLength}/ {maxLength}
                </Text>
            )}
            <TextInputMask
                style={[styles.input, styles.maskedInput]}
                onChangeText={this.handleChangeText}
                value={input.value}
                //mask={'DED-[000999999]'}
                //theme={textInputTheme}
                {...otherProps}
                placeholder={conitionalLabel}
            />
        </View>
    );
}
