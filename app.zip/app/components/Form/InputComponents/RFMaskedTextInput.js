import React, { memo } from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import TextInputMask from 'react-native-text-input-mask';
import { formStyles as styles } from 'app/components';

export default memo(function(props) {
    handleChangeText = (formatted, extracted) => {

        props.input.onChange(extracted);
    };

    // const textInputTheme = {
    //     roundness: styles.input.borderRadius,
    //     colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
    // };
    const textInputTheme = {
        //roundness: styles.input.borderRadius,
        colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
    };
    const { input, meta, ...otherProps } = props;
    const { placeholder, maxLength } = otherProps;
    delete otherProps.label;
    delete otherProps.placeholder;
    /* note: react native paper uses label property for the animated placeholder */
    const conitionalLabel = !!input.value ? null : placeholder;

    const inputLength = input.value ? input.value.length : 0;
    return (
        <View style={[{ flex: 1 }, styles.fieldHeight]}>
            {!!maxLength && (
                <Text style={styles.inputLength}>
                    {inputLength}/ {maxLength}
                </Text>
            )}
            <TextInputMask
                style={[styles.input, styles.maskedInput]}
                onChangeText={this.handleChangeText}
                value={input.value}
                //mask={'DED-[000999999]'}
                //theme={textInputTheme}
                {...otherProps}
                placeholder={conitionalLabel}
            />
        </View>
    );
});
