import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import TextInputMask from 'react-native-text-input-mask';
import { styles } from 'app/components/Form';

class RFMaskedTextInput extends React.PureComponent {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.string,
        }).isRequired,
    };

    handleChangeText = (formatted, extracted) => {
        //console.log(`RFMaskedTextInput, formatted = [${formatted}], extracted = [${extracted}]`);
        this.props.input.onChange(extracted);
    };

    render() {
        // const textInputTheme = {
        //     roundness: styles.input.borderRadius,
        //     colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        // };
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const { input, meta, ...otherProps } = this.props;
        const { placeholder, maxLength } = otherProps;
        delete otherProps.label;
        delete otherProps.placeholder;
        /* note: react native paper uses label property for the animated placeholder */
        const conitionalLabel = !!input.value ? null : placeholder;
        //console.log('RFMaskedTextInput.props:', this.props);
        const inputLength = input.value ? input.value.length : 0;
        return (
            <View style={[{ flex: 1 },styles.fieldHeight]}>
                {!!maxLength && (
                    <Text style={styles.inputLength}>
                        {inputLength}/ {maxLength}
                    </Text>
                )}
                <TextInputMask
                    style={[styles.input, styles.maskedInput]}
                    onChangeText={this.handleChangeText}
                    value={input.value}
                    //mask={'DED-[000999999]'}
                    //theme={textInputTheme}
                    {...otherProps}
                    placeholder={conitionalLabel}
                />
            </View>
        );
    }
}

export default RFMaskedTextInput;
