import React from 'react';
import PropTypes from 'prop-types';
import NumericInput from 'react-native-numeric-input';

export default function(props) {
    const { input, meta, ...otherProps } = props;
    return (
        <NumericInput
            value={input.value || 0}
            initValue={input.value || 0}
            totalWidth={120}
            minValue={0}
            totalHeight={40}
            onChange={input.onChange}
        />
    );
}
