import React from 'react';
import PropTypes from 'prop-types';
import NumericInput from 'react-native-numeric-input';

class RFNumericInput extends React.PureComponent {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const { input, meta, ...otherProps } = this.props;
        return (
            <NumericInput
                value={input.value || 0}
                initValue={input.value || 0}
                totalWidth={120}
                minValue={0}
                totalHeight={40}
                onChange={input.onChange}
            />
        );
    }
}

export default RFNumericInput;
