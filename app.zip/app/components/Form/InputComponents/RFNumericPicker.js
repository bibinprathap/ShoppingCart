import React from 'react';
import PropTypes from 'prop-types';
import { PeriodPicker } from 'app/components/PeriodPicker';

export default function(props) {
    const {
        input,
        meta,
        editable,
        periodTypeOptions,
        selectedPeriodType,
        selectedPeriod,
        handlePeriodNumberPickerChange,
        handleChangePeriodType,
        ...otherProps
    } = props;
    return (
        <PeriodPicker
            editable={editable}
            periodTypeOptions={['units']}
            selectedPeriodType={input.value.selectedPeriodType || 1}
            selectedPeriod={input.value.selectedPeriod || 0}
            handlePeriodNumberPickerChange={handlePeriodNumberPickerChange}
            handleChangePeriodType={handleChangePeriodType}
        />
    );
}
// import React from 'react';
// import PropTypes from 'prop-types';
// import NumericInput from 'react-native-numeric-input';

// class RFNumericPicker extends React.Component {
//     static propTypes = {
//         input: PropTypes.shape({
//             onChange: PropTypes.func.isRequired,
//             value: PropTypes.any,
//         }).isRequired,
//     };

//     render() {
//         const { input, meta, ...otherProps } = props;
//         return <NumericInput value={input.value} initValue={input.value} totalWidth={200} minValue={0} totalHeight={40} onChange={input.onChange} />;
//     }
// }

// export default RFNumericPicker;
