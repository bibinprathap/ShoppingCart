import React, { memo } from 'react';
import { PeriodPicker } from 'app/components';

export default memo(function(props) {
    const {
        input,
        meta,
        editable,
        periodTypeOptions,
        selectedPeriodType,
        selectedPeriod,
        handlePeriodNumberPickerChange,
        handleChangePeriodType,
        ...otherProps
    } = props;
    return (
        <PeriodPicker
            editable={editable}
            periodTypeOptions={['day', 'hour']}
            selectedPeriodType={input.value.selectedPeriodType || 1}
            selectedPeriod={input.value.selectedPeriod || 0}
            handlePeriodNumberPickerChange={handlePeriodNumberPickerChange}
            handleChangePeriodType={handleChangePeriodType}
        />
    );
});
