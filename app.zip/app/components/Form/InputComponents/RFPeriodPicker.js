import React from 'react';
import PropTypes from 'prop-types';
import { PeriodPicker } from 'app/components/PeriodPicker';

class RFPeriodPicker extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const {
            input,
            meta,
            editable,
            periodTypeOptions,
            selectedPeriodType,
            selectedPeriod,
            handlePeriodNumberPickerChange,
            handleChangePeriodType,
            ...otherProps
        } = this.props;
        return (
            <PeriodPicker
                editable={editable}
                periodTypeOptions={['day', 'hour']}
                selectedPeriodType={input.value.selectedPeriodType || 1}
                selectedPeriod={input.value.selectedPeriod || 0}
                handlePeriodNumberPickerChange={handlePeriodNumberPickerChange}
                handleChangePeriodType={handleChangePeriodType}
            />
        );
    }
}

export default RFPeriodPicker;
