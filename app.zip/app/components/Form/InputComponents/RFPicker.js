import React from 'react';
import PropTypes from 'prop-types';
import { View, Picker } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { styles } from 'app/components/Form';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import RFTextInput from './RFTextInput';
import { Loader } from 'app/components/Loader';
import { connect } from 'react-redux';
import commonStyles from 'app/components/Preview/styles';

class RFPicker extends React.Component {
    constructor() {
        super();
        this.state = { pickerActive: true };
    }
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.string,
        }).isRequired,
    };

    handleValueChange = (val, idx) => {
        if (this.state.pickerActive && this.props.allowInputIfValueEqual === val) {
            this.props.input.onChange('', 0);
            this.setState({ pickerActive: false });
        } else {
            this.props.input.onChange(val, idx);
        }
    };

    render() {
        const {
            input,
            meta,
            pickerOptions,
            editable,
            allowInputIfValueEqual,
            formFieldLoader,
            cascadingParent,
            cascadingChildren,
             validationerror,
            ...otherProps
        } = this.props;
        const { fieldHeight, defaultlyNotSelected, formName } = otherProps;
        const validationStyles = meta.touched && !meta.active ? (meta.valid ? {} : styles.invalid) : null;
        const options = pickerOptions || [];

        let isLoading =
            (formFieldLoader[formName] && formFieldLoader[formName][input.name] === true) ||
            (cascadingParent && formFieldLoader[formName] && formFieldLoader[formName][cascadingParent] === true);

        if (cascadingChildren && cascadingChildren.length > 0) {
            cascadingChildren.forEach(childFieldName => {
                isLoading = (formFieldLoader[formName] && formFieldLoader[formName][childFieldName] === true) || isLoading || false;
            });
        }

        if (this.state.pickerActive) {
            const errorStyle = meta.touched && meta.error ? styles.invalid : {};
            return (
                <View style={[{ flex: 1 }, validationStyles, { height: fieldHeight || 45 }, errorStyle]}>
                    {isLoading && <Loader loading={true} sprinnerSize={14} />}
                    {!isLoading && (
                        <Picker
                            selectedValue={input.value}
                            key={`${otherProps.labelE}_${options.length}`}
                            enabled={editable}
                            style={styles.picker}
                            onValueChange={this.handleValueChange}
                        >
                            {defaultlyNotSelected ? (
                                <Picker.Item key="notselected" label={strings('pleaseselect') + ' ' + localeProperty(otherProps, 'label')} value="" />
                            ) : null}
                            {options &&
                                options.map((v, i) => {
                                    return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.value} />;
                                })}
                        </Picker>
                    )}
                    {validationerror && <Text style={[commonStyles.ValidationMessageText, { marginStart: 10 }]}>{validationerror}</Text>}
                </View>
            );
        } else {
            return (
                <View style={[{ flex: 1, flexDirection: 'row' }, validationStyles, { height: fieldHeight || 45 }]}>
                    <View style={{ flex: 1 }}>
                        <RFTextInput {...this.props} />
                    </View>
                    <Button icon="close" style={{ alignSelf: 'center' }} onPress={() => this.setState({ pickerActive: true })} />
                </View>
            );
        }
    }
}

const mapStateToProps = state => {
    return {
        formFieldLoader: state.generic.formFieldLoader || {},
    };
};

export default connect(mapStateToProps)(RFPicker);
