import React from 'react';
import PropTypes from 'prop-types';
import { Signature } from 'app/components/InputControls';

class RFSignature extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const { input, meta, ...otherProps } = this.props;
        const config = {
            labelSaveE: otherProps.labelSaveE,
            labelSaveA: otherProps.labelSaveA,
            labelResetE: otherProps.labelResetE,
            labelResetA: otherProps.labelResetA,
        };
        return <Signature {...otherProps} onChange={input.onChange} value={input.value} config={config} />;
    }
}

export default RFSignature;
