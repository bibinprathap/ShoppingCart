import React, { memo } from 'react';
import { Signature } from 'app/components';

export default memo(function(props) {
    const { input, meta, ...otherProps } = props;
    const config = {
        labelSaveE: otherProps.labelSaveE,
        labelSaveA: otherProps.labelSaveA,
        labelResetE: otherProps.labelResetE,
        labelResetA: otherProps.labelResetA,
    };
    return <Signature {...otherProps} onChange={input.onChange} value={input.value} config={config} />;
});
