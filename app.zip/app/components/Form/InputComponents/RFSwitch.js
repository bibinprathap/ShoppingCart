import React from 'react';
import PropTypes from 'prop-types';
import { Switch } from 'app/components/InputControls';

class RFSwitch extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.any,
        }).isRequired,
    };

    render() {
        const { input, editable, meta, ...otherProps } = this.props;
        const value =
            typeof input.value === 'string' && input.value === '' && typeof this.props.defaultValue != 'undefined'
                ? this.props.defaultValue
                : input.value;

        return (
            <Switch
                onChange={input.onChange}
                value={value}
                editable={editable}
                label={otherProps.label}
                iconProps={{ icon: otherProps.icon, iconType: otherProps.iconType }}
            />
        );
    }
}

export default RFSwitch;
