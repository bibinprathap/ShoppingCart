import React, { memo } from 'react';
import { Switch } from 'app/components';

export default memo(function(props) {
    const { input, editable, meta, ...otherProps } = props;
    const value =
        typeof input.value === 'string' && input.value === '' && typeof props.defaultValue != 'undefined' ? props.defaultValue : input.value;

    return (
        <Switch
            onChange={input.onChange}
            value={value}
            editable={editable}
            label={otherProps.label}
            iconProps={{ name: otherProps.icon, type: otherProps.iconType }}
        />
    );
});
