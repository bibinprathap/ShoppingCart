import React from 'react';
import PropTypes from 'prop-types';
import { View, TextInput } from 'react-native';
import { Text } from 'react-native-paper';
import { styles } from 'app/components/Form';

class RFTextInput extends React.PureComponent {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.string,
        }).isRequired,
    };

    render() {
        // const textInputTheme = {
        //     roundness: styles.input.borderRadius,
        //     colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        // };
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const { input, meta, ...otherProps } = this.props;
        const { placeholder, maxLength, fieldHeight } = otherProps;
        delete otherProps.label;
        delete otherProps.placeholder;

        /* note: react native paper uses label property for the animated placeholder */
        const conditionalLabel = !!input.value ? null : placeholder;
        //console.log(`Value of otherProps: ${JSON.stringify(otherProps)}`);
        const inputLength = input.value ? input.value.length : 0;
        // do not display warning if the field has not been touched or if it's currently being edited
        const validationStyles = meta.touched && !meta.active ? (meta.valid ? {} : styles.invalid) : null;
        return (
            <View style={[{ flex: 1 }, validationStyles, { height: fieldHeight || 45 }]}>
                {!!maxLength && (
                    <Text style={styles.inputLength}>
                        {inputLength}/ {maxLength}
                    </Text>
                )}
                {meta.touched && meta.error && <Text>{meta.error}</Text>}
                <TextInput
                    style={[styles.input, validationStyles]}
                    onChangeText={input.onChange}
                    value={input.value}
                    theme={textInputTheme}
                    {...otherProps}
                    onBlur={() => input.onBlur(input.value)}
                    label={conditionalLabel}
                    placeholderStyle={{}}
                    textAlignVertical={'center'}
                />
            </View>
        );
    }
}

export default RFTextInput;
