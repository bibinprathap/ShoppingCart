import React, { Component, useState } from 'react';
import PropTypes from 'prop-types';
import EStyleSheet from 'react-native-extended-stylesheet';
import { View, TouchableOpacity, Picker, TouchableNativeFeedback } from 'react-native';
import TextInputMask from 'react-native-text-input-mask';
import { Text, Divider } from 'react-native-paper';
import { I18nManager, TextInput } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import Icon from 'react-native-vector-icons/MaterialIcons';

import AppApi from 'app/api/real';
// import { setLoading, setLoaded } from 'app/actions/loader';
import { shallowEqual } from 'app/api/helperServices';
import IconCommunity from 'react-native-vector-icons/MaterialCommunityIcons';
import IconFontAwesome from 'react-native-vector-icons/FontAwesome';
import IntegrationFeedback from 'app/components/Form/IntegrationFeedback/IntegrationFeedback';

import IndividualInfoTitle from 'app/components/Form/CommonForms/IndividualInfo/IndividualInfoTitle';
import * as Animatable from 'react-native-animatable';
import { _ } from 'lodash';
const api = new AppApi();
const initialIntegrationData = { running: false };

const styles = EStyleSheet.create({
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: 'transparent',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    fieldHeight: {
        height: 45,
    },
    fieldOuterContainer: {
        flex: 1,
        flexDirection: 'column',
        marginVertical: 5,
    },
    ValidationMessageTextForm: {
        fontSize: '$primaryTextXS',
        color: '$primaryMandatoryTextBackground',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        marginStart: 10,
        paddingTop: 2,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    labelContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
    fieldContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        marginHorizontal: 10,
        marginTop: 5,
    },
    fieldContainerFlat: {
        //backgroundColor: '$primaryWhite',
        backgroundColor: 'transparent',
        elevation: 0,
        // borderBottomWidth: '$primaryBorderThin',
        //borderRadius: 5,
        // borderColor: '$primaryDarkPlaceholderColor',
    },
    actionPicker: { height: 50, width: 142, justifyContent: 'flex-start', alignSelf: 'flex-start' },
    checkListCard: {
        flex: 1,
        flexDirection: 'row',
    },
    violatorContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    CommentsPhotoContainer: {
        // backgroundColor: '#000000',
        flex: 1,
        width: '97%',
        backgroundColor: '$primaryWhite',
        // elevation: 4,
        borderRadius: 8,
        margin: 5,
        padding: 5,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
    },
    imageAndComments: {
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'flex-start',
        marginLeft: 0,
        flex: 1,
        flexDirection: 'row',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    divider: {
        width: '100%',
        marginVertical: 2,
    },
    violatorsContainer: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
    },
    fieldContainerShadowed: {
        backgroundColor: '$primaryWhite',
        elevation: 4,
        borderRadius: 8,
    },
});
const AddedViolator = function(props) {
    // const [expanded, setExpanded] = useState(false);
    // handleDetailsClick = () => {
    //     setExpanded(prevState => !prevState);
    // };

    handleDeleteClick = () => {
        props.handleDeleteClick(props.vilator);
    };
    // const readOnlyRtlStyles = I18nManager.isRTL
    //     ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
    //     : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };
    return (
        <React.Fragment>
            <View style={styles.checkListCard}>
                {props.vilator.idTypeIcon == 'drivers-license' ? (
                    <IconFontAwesome
                        name={props.vilator.idTypeIcon}
                        size={20}
                        style={[styles.icon, { color: '#008000', marginStart: 10, paddingTop: 20 }]}
                    />
                ) : (
                    <IconCommunity
                        name={props.vilator.idTypeIcon}
                        size={20}
                        style={[styles.icon, { color: '#008000', marginStart: 10, paddingTop: 20 }]}
                    />
                )}

                <View style={[styles.CommentsPhotoContainer]}>
                    <View style={styles.violatorContainer}>
                        <View style={styles.imageAndComments}>
                            <View style={{ flex: 3 }}>
                                <Text>{props.vilator.violatorName}</Text>
                                <Text>{props.vilator.idNumber}</Text>
                            </View>

                            <View style={[styles.buttonContainer, { flex: 1 }]}>
                                <TouchableNativeFeedback onPress={this.handleDeleteClick}>
                                    <View style={{ flex: 1 }}>
                                        <Icon name="delete" size={20} style={styles.icon} />
                                    </View>
                                </TouchableNativeFeedback>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
            {/* {expanded ? (
                <View style={[styles.checkListCard, { flexDirection: 'column' }]}>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('name')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.vilator.name}</Text>
                        </View>

                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('emiratesId')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.vilator.idNumber}</Text>
                        </View>
                    </View>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('idType')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.vilator.selectedIdType}</Text>
                        </View>
                        <View
                            style={[
                                { flex: 1, paddingHorizontal: 10, justifyContent: 'flex-start' },
                                { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
                            ]}
                        >
                            <Text style={[styles.lableReadOnly, readOnlyRtlStyles]}>{strings('nationality')}</Text>
                            <Text style={[styles.valueReadOnlyText, readOnlyRtlStyles]}>{props.vilator.nationality}</Text>
                        </View>
                    </View>
                </View>
            ) : null} */}
            <Divider style={styles.divider} />
        </React.Fragment>
    );
};

//Todo: Integrate with EID Reader, (REST API?), or read from the MRZ of the emirates ID photo.
class RFViolatorId extends Component {
    static propTypes = {};
    onAccept = data => {
        this.setState(
            {
                setByScan: true,
                integrationData: { ...this.state.integrationData, running: false, success: true, message: strings('integrationSuccessMessageMOI') },
            },
            obj => {
                this.setState({ idNumber: data.emiratesId, violatorName: data.nameA, nationality: data.nationality });
                // Object.keys(data).forEach(key => {
                //     this.formProps.change(key, data[key]);
                // });
            }
        );
    };
    onError = e => {
        this.setState({ integrationData: { ...this.state.integrationData, running: false } });
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    state = {
        integrationData: initialIntegrationData,
        setByScan: false,
        idNumber: '',
        violatorName: '',
        selectedIdType: '1',
        nationality: 'Philippines',
        nameDisabled: true,
        idPlaceHolder: strings('emiratesId'),
        idTypeIcon: 'account-card-details',
    };
    constructor(props) {
        super(props);

        //  this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
        this.onAccept = this.onAccept.bind(this);
        this.onError = this.onError.bind(this);
        this.handleAddViolator = this.handleAddViolator.bind(this);
        this.handleDeleteClick = this.handleDeleteClick.bind(this);
        this.handleIdTypeChange = this.handleIdTypeChange.bind(this);
        this.handleIdChange = this.handleIdChange.bind(this);
    }

    clearIntegratedValues = () => {
        //todo: run this dynamically based on config
        // this.formProps.change('expiryDate', '');
        // this.formProps.change('birthDate', '');
        // this.formProps.change('nameE', '');
        // this.formProps.change('nameA', '');
        // this.formProps.change('nationality', '');
        // this.formProps.change('birthDate', '');
    };

    handleEmiratesIdChange = async idNumber => {
        this.setState({ idNumber });
        if (this.state.setByScan) {
            this.setState({ setByScan: false });
        } else {
            if (idNumber.length !== 12) {
                this.clearIntegratedValues();
                if (this.state.integrationData && this.state.integrationData.running == true) {
                    //  console.warn('emiratesidtyping');
                    this.setState({ integrationData: initialIntegrationData });
                }
                //this.props.dispatch(setLoaded());
                return;
            } else {
                //this.props.dispatch(setLoading());
                this.setState({ integrationData: { running: true, message: strings('integrationProgressMessageMOI') } });
                try {
                    //todo: show loading spinner in companyName field
                    this.clearIntegratedValues();
                    const result = await api.getPersonProfile(`784${newValue}`);
                    //this.props.dispatch(setLoaded());
                    //todo: run this dynamically based on config

                    this.setState({ integrationData: { running: false, success: true, message: strings('integrationSuccessMessageMOI') } });
                    /*
                todo: hide the spinner and disable the companyName field because 
                      API call was a success, whatever name has been returned by
                      the API is the correct name
                */
                } catch (e) {
                    //this.props.dispatch(setLoaded());
                    if (!e.isCancel) {
                        this.clearIntegratedValues();
                        this.setState({
                            integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageMOI') },
                        });
                        /*
                todo: if license number is invalid, set error on licenseNumber
                      if it is network error, or exception on the server, then 
                      enable the company name field so user can enter value directly.
                */
                        console.log('Error in getPersonProfile', { e });
                    }
                }
            }
        }
    };

    handleIdChange = async idNumber => {
        this.setState({ idNumber });
    };
    handleIdTypeChange = selectedIdType => {
        debugger;
        let nameDisabled = false;
        let idTypeIcon = 'account-card-details';

        let idPlaceHolder = strings('emiratesId');
        if (selectedIdType == '1') {
            nameDisabled = true;
        } else if (selectedIdType == '2') {
            idPlaceHolder = strings('passport');
            idTypeIcon = 'passport';
        } else if (selectedIdType == '3') {
            idPlaceHolder = strings('drivingLicence');
            idTypeIcon = 'drivers-license';
        }
        this.setState({
            integrationData: initialIntegrationData,
            setByScan: false,
            selectedIdType,
            nameDisabled,
            idPlaceHolder,
            idTypeIcon,
            idNumber: '',
            violatorName: '',
        });
        //  this.setState({ violatorName: '' });
    };
    handleViolatorNameChange = violatorName => {
        this.setState({ violatorName });
    };

    handleAddViolator = () => {
        debugger;
        const currentViolator = this.props.input.value;
        const { idNumber, violatorName, selectedIdType, nationality, idTypeIcon } = this.state;
        const newViolatorArray = currentViolator ? currentViolator.slice() : [];
        newViolatorArray.push({ idNumber, violatorName, selectedIdType, nationality, idTypeIcon });
        this.props.input.onChange(newViolatorArray);
    };
    handleDeleteClick = vilator => {
        const currentViolators = this.props.input.value;
        const newViolatorsArray = _.without(currentViolators, vilator);
        //  console.log('currentViolators', currentViolators, 'newViolatorsArray', newViolatorsArray);
        this.props.input.onChange(newViolatorsArray);
    };
    render = () => {
        const { input, meta, validationerror, ...otherProps } = this.props;
        const { integrationData, selectedIdType, nameDisabled, idPlaceHolder, violatorName, idNumber } = this.state;
        const integrationSourceFieldIndicator = selectedIdType == '1' && integrationData && <IntegrationFeedback integrationData={integrationData} />;
        const integrationFieldIndicator =
            selectedIdType == '1' && integrationData && !integrationData.running && !!integrationData.success && integrationSourceFieldIndicator;
        const addButtonEnabled = violatorName.length > 0 && idNumber.length > 0;
        return (
            <View style={styles.violatorsContainer}>
                <View style={{ flex: 1 }}>
                    {input.value && input.value.length > 0
                        ? this.props.input.value.map((vilator, i) => {
                              return <AddedViolator key={i} vilator={vilator} handleDeleteClick={this.handleDeleteClick} />;
                          })
                        : null}
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <View style={{ flex: 5 }} />
                    <View style={{ flex: 1 }}>
                        <View style={{ position: 'absolute', zIndex: 999, top: 10, right: I18nManager.isRTL ? 0 : -26, color: '#008000' }}>
                            <TouchableNativeFeedback onPress={this.handleAddViolator} disabled={!addButtonEnabled}>
                                <View style={{ height: 100, width: 100, justifyContent: 'center', alignItems: 'center' }}>
                                    <Icon name="add-circle" color="#008000" size={30} style={[styles.icon]} />
                                </View>
                            </TouchableNativeFeedback>
                        </View>
                    </View>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <View style={{ flex: 1, marginEnd: 20 }}>
                        <View style={[{ flex: 1 }, styles.fieldOuterContainer]}>
                            <View style={[styles.labelContainer]}>
                                <View style={{ flexDirection: 'row', flex: 1 }}>
                                    <View style={{ flex: 3, flexDirection: 'row' }}>
                                        <Picker selectedValue={selectedIdType} style={styles.actionPicker} onValueChange={this.handleIdTypeChange}>
                                            <Picker.Item key="1" value="1" label={strings('emiratesId')} />
                                            <Picker.Item key="2" value="2" label={strings('passport')} />
                                            <Picker.Item key="3" value="3" label={strings('drivingLicence')} />
                                        </Picker>
                                        <Text style={[styles.ValidationMessageTextForm, { marginStart: -40 }]}>*</Text>
                                    </View>
                                    <View style={{ flex: 8, flexDirection: 'row' }}>
                                        <View style={[styles.fieldContainer, styles.fieldContainerShadowed, { flexDirection: 'row' }]}>
                                            {selectedIdType == '1' ? (
                                                <>
                                                    <IndividualInfoTitle
                                                        editable={true}
                                                        formTitle={this.props.formTitle}
                                                        flashOn={false}
                                                        onAccept={this.onAccept}
                                                        onError={this.onError}
                                                        dispatch={this.props.dispatch}
                                                    />
                                                    <TextInputMask
                                                        name="emiratesid"
                                                        style={[styles.input, styles.maskedInput, { height: 45 }]}
                                                        onChangeText={this.handleEmiratesIdChange}
                                                        value={this.state.idNumber}
                                                        autoCapitalize="none"
                                                        mask={'784-[9999]-[9999999]-[9]'}
                                                        placeholder={idPlaceHolder}
                                                    />
                                                </>
                                            ) : (
                                                <TextInput
                                                    name="otherid"
                                                    style={[styles.input, styles.maskedInput, { height: 45 }]}
                                                    value={this.state.idNumber}
                                                    autoCapitalize="none"
                                                    onChangeText={this.handleIdChange}
                                                    placeholder={idPlaceHolder}
                                                />
                                            )}
                                        </View>
                                        {integrationFieldIndicator}
                                        {integrationSourceFieldIndicator}
                                    </View>
                                </View>
                            </View>
                        </View>
                        <View style={[{ flex: 1 }, styles.fieldOuterContainer]}>
                            <View style={[styles.labelContainer]}>
                                <View style={{ flexDirection: 'row', flex: 1 }}>
                                    <View style={{ flex: 3, flexDirection: 'row' }}>
                                        <Text style={[styles.label, { paddingStart: 8 }]}>{strings('name')}</Text>
                                        <Text style={[styles.ValidationMessageTextForm, { marginTop: -18 }]}>*</Text>
                                    </View>
                                    <View style={{ flex: 8 }}>
                                        <View style={[styles.fieldContainer, styles.fieldContainerShadowed]}>
                                            <TextInput
                                                style={[styles.input, styles.maskedInput, { height: 45 }]}
                                                onChangeText={this.handleViolatorNameChange}
                                                value={violatorName}
                                                editable={!nameDisabled}
                                                autoCapitalize="none"
                                                placeholder={strings('name')}
                                            />
                                        </View>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        );
    };
}

export default RFViolatorId;
