import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import alertsHelper from 'app/api/helperServices/alerts';

const styles = EStyleSheet.create({
    running: { color: '$primaryMediumTextColor' },
    success: { color: '$primarySuccessTextColor' },
    error: { color: '$primaryErrorTextColor' },
});

const AnimatableIcon = Animatable.createAnimatableComponent(Icon);

export default function({ integrationData }) {
    if (!integrationData) return null;

    //const [tooltipVisible, toggleTooltip] = useState(false);
    // showTooltip = () => {
    //     toggleTooltip(true);
    // };
    // handleTooltipOnClose = () => {
    //     toggleTooltip(false);
    // };
    let alertType;
    let alertTitle;

    showAlert = () => {
        const msg = !!integrationData.error ? `${integrationData.message} [${integrationData.error.detail}]` : integrationData.message;
        alertsHelper.show(alertType, alertTitle, msg);
    };
    handleIconRef = ref => {
        this.icon = ref;
    };

    let showIcon = false;
    let iconProps = { size: 16, iterationCount: 1, easing: 'linear' };
    if (integrationData.running === true) {
        alertType = 'info';
        alertTitle = 'Working...';
        showIcon = true;
        iconProps = {
            ...iconProps,
            name: 'settings',
            color: styles.running.color,
            animation: 'rotate',
            iterationCount: 'infinite',
        };
    } else {
        if (integrationData.success === true) {
            alertType = 'success';
            alertTitle = 'Verified data';
            showIcon = true;
            iconProps = {
                ...iconProps,
                name: 'verified-user',
                color: styles.success.color,
                animation: 'fadeIn',
            };
        } else if (integrationData.success === false) {
            //show error only if explicit false value is provided
            alertType = 'error';
            alertTitle = 'Error';
            showIcon = true;
            iconProps = {
                ...iconProps,
                name: 'error-outline',
                color: styles.error.color,
                animation: 'bounce',
            };
        }
    }
    if (!showIcon) return null;

    return (
        <TouchableOpacity onPress={this.showAlert}>
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: 2,
                }}
            >
                <AnimatableIcon ref={this.handleIconRef} {...iconProps} useNativeDriver />
            </View>
        </TouchableOpacity>
    );
}
