import styles from './styles';
//import AppForm from './AppForm';
import { createForm, createReadOnlyView } from './AppForm';
import IndividualInfoForm from './CommonForms/IndividualInfo/IndividualInfo';
import BuildingInfoForm from './CommonForms/BuildingInfo/BuildingInfo';
import CompanyInfoForm from './CommonForms/CompanyInfo/CompanyInfo';
import PlotInfoForm from './CommonForms/PlotInfo/PlotInfo';
import AbandonedVehicleForm from './CommonForms/AbandonedVehicle/AbandonedVehicle';
import GeneralAppearanceVehicleForm from './CommonForms/GeneralAppearanceVehicle/GeneralAppearanceVehicle';
import GeneralInfoForm from './CommonForms/GeneralInfo/GeneralInfo';
import DistortionForm from './CommonForms/DistortionForm/DistortionForm';
import DynamicForm from './CommonForms/DynamicForm/DynamicForm';
import FollowupForm from './CommonForms/Followup/FollowupForm';
import ReconcileInfoForm from './CommonForms/ReconcileInfo/ReconcileInfo';
import RFField from './InputComponents/RFField';
import RFPicker from './InputComponents/RFPicker';
import RFChildPicker from './InputComponents/RFChildPicker';
import RFTextInput from './InputComponents/RFTextInput';
import RFMaskedTextInput from './InputComponents/RFMaskedTextInput';
import RFSwitch from './InputComponents/RFSwitch';
import RFCustom from './InputComponents/RFCustom';
import RFAmount from './InputComponents/RFAmount';
import RFAttachmentList from './InputComponents/RFAttachmentList/RFAttachmentList';
import RFSignature from './InputComponents/RFSignature';
import RFNumeric from './InputComponents/RFNumericInput';
import RFperiodPicker from './InputComponents/RFPeriodPicker';
import RFDateTimePicker from './InputComponents/RFDateTimePicker';
import ResUnitOccupancyForm from './CommonForms/ResUnitOccupancy/ResUnitOccupancy';
import Occupants from './CommonForms/ResUnitOccupancy/Occupants';
import RFCurrentLocation from './InputComponents/RFCurrentLocation';
import ViolationsFollowup from './CommonForms/ViolationsFollowup/ViolationsFollowup';
import EngineerReviewApproved from './CommonForms/EngineerReviewApproved/EngineerReviewApproved';
import BuildingPenaltCheckItemPreview from './CommonForms/BuildingPenaltCheckItemPreview/BuildingPenaltCheckItemPreview';
import MoreInfoForm from './CommonForms/MoreInfoForm/MoreInfoForm';
import ResUnitOccupancyWarrantApprovedForm from './CommonForms/ResUnitOccupancyWarrantApprovedForm/ResUnitOccupancyWarrantApprovedForm';
import IndividualViolator from './CommonForms/IndividualViolator/IndividualViolator';
import CompanyViolator from './CommonForms/CompanyViolator/CompanyViolator';
import VehicleViolator from './CommonForms/VehicleViolator/VehicleViolator';
import IntegrationFeedback from './IntegrationFeedback/IntegrationFeedback';
import CurentLocation from './CurentLocation/CurentLocation';
import AbandonedVehicleConfig from './CommonForms/AbandonedVehicle/config';
import GeneralAppearanceVehicleConfig from './CommonForms/GeneralAppearanceVehicle/config';
import FoodTruckAndOutdoor from './CommonForms/FoodTruckAndOutdoor/FoodTruckAndOutdoor';
import FoodTruckAndOutdoorFollowUp from './CommonForms/FoodTruckAndOutdoorFollowUp/FoodTruckAndOutdoorFollowUp';
import NoisePollution from './CommonForms/NoisePollution/NoisePollution';
import ResUnitOccupancyConfig from './CommonForms/ResUnitOccupancy/config';
import SiteVisit from './CommonForms/SiteVisit/SiteVisit';

export {
    styles,
    createForm,
    createReadOnlyView,
    IndividualInfoForm,
    BuildingInfoForm,
    CompanyInfoForm,
    PlotInfoForm,
    GeneralInfoForm,
    DistortionForm,
    DynamicForm,
    ReconcileInfoForm,
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    RFSignature,
    RFField,
    RFTextInput,
    RFMaskedTextInput,
    RFSwitch,
    RFCustom,
    RFAmount,
    RFAttachmentList,
    RFPicker,
    RFNumeric,
    RFperiodPicker,
    RFDateTimePicker,
    ResUnitOccupancyForm,
    RFCurrentLocation,
    FollowupForm,
    RFChildPicker,
    ViolationsFollowup,
    EngineerReviewApproved,
    BuildingPenaltCheckItemPreview,
    MoreInfoForm,
    ResUnitOccupancyWarrantApprovedForm,
    IndividualViolator,
    CompanyViolator,
    VehicleViolator,
    IntegrationFeedback,
    CurentLocation,
    AbandonedVehicleConfig,
    GeneralAppearanceVehicleConfig,
    ResUnitOccupancyConfig,
    Occupants,
    FoodTruckAndOutdoor,
    FoodTruckAndOutdoorFollowUp,
    SiteVisit,
    NoisePollution,
};
