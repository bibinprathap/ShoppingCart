import styles from './styles';
//import AppForm from './AppForm';
import { createForm, createReadOnlyView } from './AppForm';
import IndividualInfoForm from './CommonForms/IndividualInfo/IndividualInfo';
import BuildingInfoForm from './CommonForms/BuildingInfo/BuildingInfo';
import CompanyInfoForm from './CommonForms/CompanyInfo/CompanyInfo';
import AbandonedVehicleForm from './CommonForms/AbandonedVehicle/AbandonedVehicle';
import GeneralAppearanceVehicleForm from './CommonForms/GeneralAppearanceVehicle/GeneralAppearanceVehicle';
import GeneralInfoForm from './CommonForms/GeneralInfo/GeneralInfo';
import DynamicForm from './CommonForms/DynamicForm/DynamicForm';
import ReconcileInfoForm from './CommonForms/ReconcileInfo/ReconcileInfo';
import RFField from './InputComponents/RFField';
import RFPicker from './InputComponents/RFPicker';
import RFTextInput from './InputComponents/RFTextInput';
import RFMaskedTextInput from './InputComponents/RFMaskedTextInput';
import RFSwitch from './InputComponents/RFSwitch';
import RFCustom from './InputComponents/RFCustom';
import RFAttachmentList from './InputComponents/RFAttachmentList/RFAttachmentList';
import RFSignature from './InputComponents/RFSignature';
import RFNumeric from './InputComponents/RFNumericInput';
import RFperiodPicker from './InputComponents/RFPeriodPicker';
import RFDateTimePicker from './InputComponents/RFDateTimePicker';
import ResUnitOccupancyForm from './CommonForms/ResUnitOccupancy/ResUnitOccupancy';
import CurentLocation from './CurentLocation/CurentLocation';

export {
    styles,
    createForm,
    createReadOnlyView,
    IndividualInfoForm,
    BuildingInfoForm,
    CompanyInfoForm,
    GeneralInfoForm,
    DynamicForm,
    ReconcileInfoForm,
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    RFSignature,
    RFField,
    RFTextInput,
    RFMaskedTextInput,
    RFSwitch,
    RFCustom,
    RFAttachmentList,
    RFPicker,
    RFNumeric,
    RFperiodPicker,
    RFDateTimePicker,
    ResUnitOccupancyForm,
    CurentLocation,
};
