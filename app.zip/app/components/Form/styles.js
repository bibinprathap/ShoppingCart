import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

//Todo: clean up this stylesheet. create separate folder for each input component, and move their styles to the respective folder
export default EStyleSheet.create({
    container: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
    },
    containerWithoutBorder: {
        flex: 1,
        // marginBottom: 10,
        // marginHorizontal: 5,
    },
    fieldOuterContainer: {
        flex: 1,
        flexDirection: 'column',
        marginVertical: 5,
    },
    titleContainer: {
        flex: 1,
    },
    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
        alignSelf: 'flex-start',
    },
    labelContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
    },
    lableReadOnly: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    labelNotActive: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    valueReadOnlyText: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
    invalid: {
        borderColor: '$primaryInvalidBorderColor',
    },
    fieldContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        marginHorizontal: 10,
        marginTop: 5,
    },
    customFieldContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginHorizontal: 10,
        minHeight: 55,
    },
    fieldContainerShadowed: {
        backgroundColor: '$primaryWhite',
        elevation: 4,
        borderRadius: 8,
    },
    noShadow: {
        elevation: 0,
    },
    justify: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    fieldContainerFlat: {
        //backgroundColor: '$primaryWhite',
        backgroundColor: 'transparent',
        elevation: 0,
        borderBottomWidth: '$primaryBorderThin',
        //borderRadius: 5,
        borderColor: '$primaryDarkPlaceholderColor',
    },
    fieldContainerFlatWithOutBorder: {
        //backgroundColor: '$primaryWhite',
        backgroundColor: 'transparent',
        elevation: 0,
        //borderRadius: 5,
        borderColor: '$primaryDarkPlaceholderColor',
    },
    fieldHeight: {
        height: 45,
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: 'transparent',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    inputLength: {
        position: 'absolute',
        right: 0,
        top: -20,
        color: '$primaryDarkPlaceholderColor',
    },
    picker: { height: 50, width: '100%', flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start' },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    ValidationMessageTextForm: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMandatoryTextBackground',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        marginStart: 10,
        paddingTop: 2,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
});
