import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
//import { connect } from 'react-redux';
import { Button, Appbar, Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';

class AttachmentsHeader extends Component {
    static propTypes = {
        navigation: PropTypes.object.isRequired,
    };

    constructor(props) {
        super(props);
    }

    goBack = () => {
        const { navigation, scene, currentInspection } = this.props;
        /*
            RJ: There is a bug in react-navigation.
                call to navigation.setParams() from the screen component doesn't update the navigation state (that is accessible to the header)
                workarounds mentioned in the below threads do not work for me for whatever reason.
                    //https://github.com/react-navigation/react-navigation/issues/1529
                    //https://stackoverflow.com/questions/47093555/why-is-my-this-props-navigation-setparams-not-working
                but the updated params end up in this.props.scene.route.params
                so instead of this.props.navigation.getParam('onScreenClose');
                we access the param by --> this.props.scene.route.params.onScreenClose;

        */

        const { onScreenClose, onClose } = scene.route.params;
        if (onScreenClose) onScreenClose();
        else {
            if (onClose) onClose();
            this.props.navigation.pop();
        }
    };

    handleCropRotate = () => {
        const { navigation, scene, currentInspection } = this.props;
        const { onCropRotate, selectedAttachmentId } = scene.route.params;
        if (onCropRotate) onCropRotate();
    };

    handleDrawOnImage = () => {
        const { scene } = this.props;
        const { onDrawOnImage } = scene.route.params;
        if (onDrawOnImage) onDrawOnImage();
    };

    render() {
        const { navigation, scene, currentInspection } = this.props;
        const { selectedAttachmentId, editable } = scene.route.params;

        let title = strings('attachments');
        if (navigation.state.params && navigation.state.params.navigationTitle) {
            title = navigation.state.params.navigationTitle;
        }

        return (
            <Appbar style={styles.appBar}>
                <View style={styles.startContainer}>
                    <Appbar.BackAction onPress={this.goBack} color={styles.icon.color} />
                    <Appbar.Content title={title} titleStyle={styles.contentTitle} style={styles.contentContainer} />
                </View>
                {editable && (
                    <View style={styles.endContainer}>
                        {!!selectedAttachmentId && <Appbar.Action icon="crop-rotate" onPress={this.handleCropRotate} color={styles.icon.color} />}
                        {!!selectedAttachmentId && <Appbar.Action icon="edit" onPress={this.handleDrawOnImage} color={styles.icon.color} />}
                    </View>
                )}
            </Appbar>
        );
    }
}

export default AttachmentsHeader;
