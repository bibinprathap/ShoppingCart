import React, { Component } from 'react';
import { View, Text, SafeAreaView, TouchableWithoutFeedback } from 'react-native';

import styles from './styles';

const FollowUpHeader = props => {
    const { navigation } = props;
    const routes = navigation.state.routes;

    return (
        <SafeAreaView style={{ backgroundColor: 'blue' }}>
            <View style={styles.containerrow}>
                {routes.map((route, index) => {
                    const focused = navigation.state.index === index;
                    console.log(route);
                    return (
                        <View key={route.key} style={styles.tabBarItem}>
                            <TouchableWithoutFeedback onPress={() => props.navigation.navigate(route.routeName)}>
                                <View style={[styles.containernew, focused ? styles.active : styles.inactive]}>
                                    {/* <View style={styles.icon}>
            <Icon name={icon} color='white' size={24}/>
          </View> */}
                                    <Text style={styles.textStyle}>{route.routeName}</Text>
                                </View>
                            </TouchableWithoutFeedback>
                        </View>
                    );
                })}
            </View>
        </SafeAreaView>
    );
};

export default FollowUpHeader;
