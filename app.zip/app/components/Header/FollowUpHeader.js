import React, { Component } from 'react';
import { View, Text, SafeAreaView, TouchableWithoutFeedback, ScrollView } from 'react-native';

import styles from './styles';

const FollowUpHeader = props => {
    const { screenProps, navigation } = props;
    const routes = navigation.state.routes;
    let servicesScrollView;
    const setScrollViewRef = element => {
        servicesScrollView = element;
    };
    return (
        <SafeAreaView>
            <View style={styles.containerrow}>
                <ScrollView
                    ref={setScrollViewRef}
                    horizontal
                    style={{ flex: 1 }}
                    onLayout={event => {
                        const { width, x, y } = event.nativeEvent.layout;
                        // if (width && mainServicesCategories.length && selectedServicePosition && this.state.autoScroll) {
                        //     const cardItemWidth = width / mainServicesCategories.length;
                        //     const calculatedXPosition = x + (cardItemWidth + 70) * selectedServicePosition;
                        //     this.servicesScrollView.scrollTo({ x: calculatedXPosition, y: y, animated: true });
                        // }
                    }}
                >
                    {routes.map((route, index) => {
                        const focused = navigation.state.index === index;
                        console.log(route);
                        const title = screenProps.find(k => k.key == route.routeName).tabBarLabel;
                        return (
                            <TouchableWithoutFeedback onPress={() => props.navigation.navigate(route.routeName)}>
                                <View
                                    key={route.key}
                                    style={[
                                        {
                                            flex: index / routes.length,
                                            flexDirection: 'row',
                                            alignItems: 'center',

                                            padding: 5,
                                            margin: 2,
                                        },
                                        focused ? { borderBottomWidth: 3, borderColor: '#3ACCE1' } : { borderBottomWidth: 3, borderColor: '#BBC1C9' },
                                    ]}
                                >
                                    <View style={styles.containernew}>
                                        {/* <View style={styles.icon}>
            <Icon name={icon} color='white' size={24}/>
          </View> */}
                                        <Text style={[styles.textStyle, focused ? { color: '#3ACCE1' } : { color: '#BBC1C9' }]}>{title}</Text>
                                    </View>
                                </View>
                            </TouchableWithoutFeedback>
                        );
                    })}
                </ScrollView>
            </View>
        </SafeAreaView>
    );
};

export default FollowUpHeader;
