import React, { Component } from 'react';
import { I18nManager, Dimensions } from 'react-native';
import { View, Text, SafeAreaView, TouchableWithoutFeedback, ScrollView } from 'react-native';
import { ScrollViewWithIndicator } from 'app/components';
import styles from './styles';

const FollowUpHeader = props => {
    const { screenProps, navigation } = props;
    const routes = navigation.state.routes;

    if (routes.length < 2) return null;
    else
        return (
            <SafeAreaView>
                <View
                    style={[
                        styles.containerrow,
                        { direction: I18nManager.isRTL ? 'rtl' : 'ltr', justifyContent: 'flex-start', alignItems: 'flex-start', marginTop: 10 },
                    ]}
                >
                    <ScrollViewWithIndicator showsHorizontalScrollIndicator={false}>
                        {routes.map((route, index) => {
                            const focused = navigation.state.index === index;

                            const title = screenProps.find(k => k.key == route.routeName).tabBarLabel;
                            const headerItemContainerStyles = [styles.headerItemContainer, focused ? styles.headerItemContainerSelected : null];
                            const headerItemTextStyles = [styles.headerItemText, focused ? styles.headerItemTextSelected : null];
                            return (
                                <TouchableWithoutFeedback key={route.routeName} onPress={() => props.navigation.navigate(route.routeName)}>
                                    <View
                                        style={[
                                            headerItemContainerStyles,
                                            {
                                                flex: index / routes.length,
                                            },
                                        ]}
                                        key={`${route.routeName}_${index}`}
                                    >
                                        <Text style={headerItemTextStyles}>{title}</Text>
                                    </View>
                                </TouchableWithoutFeedback>
                            );
                        })}
                    </ScrollViewWithIndicator>
                </View>
            </SafeAreaView>
        );
};

export default FollowUpHeader;

{
    /* <View
key={route.key}
style={[
    {
        flex: index / routes.length,
        flexDirection: 'row',
        alignItems: 'center',

        padding: 5,
        margin: 2,
    },
    focused ? { borderBottomWidth: 3, borderColor: '#3ACCE1' } : { borderBottomWidth: 3, borderColor: '#BBC1C9' },
]}
>
<View style={styles.containernew}>
    <Text style={[styles.textStyle, focused ? { color: '#3ACCE1' } : { color: '#BBC1C9' }]}>{}</Text>
</View>
</View> */
}
