import React, { Component } from 'react';
import { View } from 'react-native';
import { Appbar } from 'react-native-paper';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

const FollowUpTopHeader = props => {
    backAction = () => {
        if (props.backAction) {
            props.backAction();
        } else if (props.navigation) {
            props.navigation.pop();
        }
        return null;
    };
    console.log(props);
    const inspectionTitle = inspectionsHelper.getLongTitle(
        { inspection: { service: props.service, refNumber: props.currentInspection } },
        true,
        props.services
    );

    return (
        <Appbar style={styles.appBar}>
            <View style={styles.containerGeneric}>
                <Appbar.BackAction onPress={this.backAction} color={styles.icon.color} />
                {props.title && (
                    <Appbar.Content
                        title={props.title}
                        subtitle={inspectionTitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                )}
            </View>
        </Appbar>
    );
};

export default FollowUpTopHeader;
