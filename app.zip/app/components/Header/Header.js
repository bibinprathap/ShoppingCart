import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Image } from 'react-native';
import { Text, Appbar } from 'react-native-paper';
import { DrawerActions } from 'react-navigation-drawer';
import * as Animatable from 'react-native-animatable';
import { withNavigation } from 'react-navigation';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import { createNewInspection } from 'app/actions/inspections';
import styles from './styles';
import images from 'app/images';
import firebase from 'app/api/helperServices/rnFirebaseNative';
import { mainStackDefinition } from 'app/config/routs/defs';
import { NavigationActions } from 'react-navigation';

class Header extends Component {
    static propTypes = {
        navigation: PropTypes.object.isRequired,
        activeProfile: PropTypes.object,
    };

    constructor(props) {
        super(props);
    }
    handleViewRef = ref => (this.view = ref);

    componentDidUpdate(prevProps, prevState, snapshot) {
        const { notifications } = this.props;
        const unreadCount = notifications.unreadCount || 0;
        if (unreadCount > 0 && prevProps.notifications.unreadCount != unreadCount && this.view) {
            if (unreadCount > prevProps.notifications.unreadCount) this.view.bounce(1000);
            firebase.setBadgeNumber(unreadCount);
        }
        if (prevProps.notifications.unreadCount != unreadCount) {
            // Update app icon badge count
            firebase.setBadgeNumber(unreadCount);
        }
    }

    goBack = () => {
        // this.props.navigation.goBack('main');

        this.props.navigation.dispatch(NavigationActions.back());

        //  navigate('main');
    };

    toggleDrawer = () => {
        this.props.navigation.dispatch(DrawerActions.toggleDrawer());
    };

    beginInspection = () => {
        this.props.dispatch(createNewInspection());
        this.props.navigation.navigate('inspection');
    };

    navigateToNotifications = () => {
        this.props.navigation.navigate('notifications');
    };

    render() {
        const { navigation, scene, loggedIn, activeProfile, isRtl, notifications } = this.props;
        const unreadCount = notifications.unreadCount || 0;
        const { routeName, key } = navigation.state.routes[navigation.state.index];

        this.currentRoutedef = _.find(mainStackDefinition.routes, {
            key: key,
        });

        const title = this.currentRoutedef.title; //scene.descriptor.options.title;
        const subtitle = this.currentRoutedef.subtitle; //scene.descriptor.options.subtitle;
        let fullName = !activeProfile ? 'Unknown' : isRtl ? activeProfile.displayNameA : activeProfile.displayNameE;

        while (fullName.indexOf(',,') > -1) fullName = fullName.replace(/,,/g, ',');
        fullName = fullName.replace(/,/g, ' ');

        return (
            <Appbar style={styles.appBar}>
                {navigation.state.index > 0 && <Appbar.BackAction onPress={this.goBack} />}
                <View style={styles.startContainer}>
                    <Appbar.Action icon={images.menu.content} onPress={this.toggleDrawer} color={styles.icon.color} />
                    <Appbar.Content
                        title={`${title}  -  ${fullName}`}
                        subtitle={subtitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                </View>
                <View style={styles.endContainer}>
                    <Appbar.Action icon={images.notification.content} color={styles.icon.color} onPress={this.navigateToNotifications} />
                    {unreadCount > 0 && (
                        <TouchableOpacity onPress={this.navigateToNotifications} style={styles.notificationUnread}>
                            <Animatable.View ref={this.handleViewRef}>
                                <Text style={styles.notificationUnreadCount}>{unreadCount}</Text>
                            </Animatable.View>
                        </TouchableOpacity>
                    )}
                    <Appbar.Action icon={images.new.content} onPress={this.beginInspection} color={styles.icon.color} />
                </View>
            </Appbar>
        );
    }
}

mapStateToProps = state => {
    const allProfiles = state.auth.profiles;
    const activeProfileDomainCustomerId = state.auth.activeProfileDomainCustomerId;
    const activeProfile =
        allProfiles && activeProfileDomainCustomerId ? _.find(allProfiles, { domainCustomerId: activeProfileDomainCustomerId }) : undefined;
    return {
        isRtl: state.settings.isRtl,
        loggedIn: state.auth.loggedIn,
        activeProfile: activeProfile,
        notifications: state.notifications,
    };
};

export default connect(mapStateToProps)(Header);
