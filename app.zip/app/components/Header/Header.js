import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Image } from 'react-native';
import { Text, Appbar } from 'react-native-paper';
import { DrawerActions } from 'react-navigation-drawer';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import { createNewInspection } from 'app/actions/inspections';
import styles from './styles';
import images from 'app/images';

class Header extends Component {
    static propTypes = {
        navigation: PropTypes.object.isRequired,
        activeProfile: PropTypes.object,
    };

    constructor(props) {
        super(props);
    }

    goBack = () => {
        this.props.navigation.pop();
    };

    toggleDrawer = () => {
        this.props.navigation.dispatch(DrawerActions.toggleDrawer());
    };

    beginInspection = () => {
        this.props.dispatch(createNewInspection());
        this.props.navigation.navigate('inspection');
    };

    render() {
        const { navigation, scene, loggedIn, activeProfile, isRtl } = this.props;
        const title = scene.descriptor.options.title;
        const subtitle = scene.descriptor.options.subtitle;
        let fullName = !activeProfile ? 'Unknown' : isRtl ? activeProfile.displayNameA : activeProfile.displayNameE;

        while (fullName.indexOf(',,') > -1) fullName = fullName.replace(/,,/g, ',');
        fullName = fullName.replace(/,/g, ' ');

        return (
            <Appbar style={styles.appBar}>
                {navigation.state.index > 0 && <Appbar.BackAction onPress={this.goBack} />}
                <View style={styles.startContainer}>
                    <Appbar.Action icon={images.menu.content} onPress={this.toggleDrawer} color={styles.icon.color} />
                    <Appbar.Content
                        title={`${title}  -  ${fullName}`}
                        subtitle={subtitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                </View>
                <View style={styles.endContainer}>
                    <Appbar.Action icon={images.notification.content} color={styles.icon.color} />
                    <Appbar.Action icon={images.new.content} onPress={this.beginInspection} color={styles.icon.color} />
                </View>
            </Appbar>
        );
    }
}

mapStateToProps = state => {
    const allProfiles = state.auth.profiles;
    const activeProfileDomainCustomerId = state.auth.activeProfileDomainCustomerId;
    const activeProfile =
        allProfiles && activeProfileDomainCustomerId ? _.find(allProfiles, { domainCustomerId: activeProfileDomainCustomerId }) : undefined;
    return {
        isRtl: state.settings.isRtl,
        loggedIn: state.auth.loggedIn,
        activeProfile: activeProfile,
        //userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(Header);
