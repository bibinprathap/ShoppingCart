import React, { Component } from 'react';
import { View } from 'react-native';
import { Appbar } from 'react-native-paper';
import styles from './styles';

export default function ViolatorSelectorDialogHeader(props) {
    return (
        <Appbar style={styles.appBar}>
            <View style={styles.containerGeneric}>
                <Appbar.BackAction onPress={props.backAction} color={styles.icon.color} />
                {props.title && (
                    <Appbar.Content
                        title={props.title}
                        // subtitle={props.subtitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                )}
            </View>
        </Appbar>
    );
}
