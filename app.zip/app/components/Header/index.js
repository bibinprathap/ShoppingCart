import styles from './styles';
import Header from './Header';
import InspectionHeader from './InspectionHeader';
import AttachmentsHeader from './AttachmentsHeader';
import HeaderGeneric from './HeaderGeneric';
import IdScanHeader from './IdScanHeader';
import FollowUpHeader from './FollowUpHeader';
export { Header, InspectionHeader, AttachmentsHeader, IdScanHeader, HeaderGeneric, styles, FollowUpHeader };
