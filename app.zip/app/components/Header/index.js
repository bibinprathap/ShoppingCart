import styles from './styles';
import Header from './Header';
import InspectionHeader from './InspectionHeader';
import AttachmentsHeader from './AttachmentsHeader';
import HeaderGeneric from './HeaderGeneric';
import IdScanHeader from './IdScanHeader';
export { Header, InspectionHeader, AttachmentsHeader, IdScanHeader, HeaderGeneric, styles };
