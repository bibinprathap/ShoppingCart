import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    appBar: {
        backgroundColor: '$primaryHeaderColor',
        zIndex: 1000,
    },

    container: {
        //position: 'absolute',
        left: 0,
        top: 0,
        right: 0,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        '@media ios': {
            paddingTop: 20,
        },
        '@media android': {
            //paddingTop: StatusBar.currentHeight,
        },
    },
    containerGeneric: {
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    startContainer: {
        flexDirection: 'row',
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    endContainer: {
        flexDirection: 'row',
    },
    contentContainer: {
        alignItems: 'flex-start',
    },
    button: {
        height: '$globalButtonHeight',
    },
    headetItem: {
        paddingVertical: 5,
        paddingHorizontal: 20,
    },
    contentTitle: {
        fontFamily: '$primaryFontHeading',
        color: '$primaryWhite',
    },
    contentSubtitle: {
        fontFamily: '$primaryFontHeading',
        color: '$primaryWhite',
    },
    icon: {
        color: 'white',
    },
    notificationUnread: {
        backgroundColor: '$nofificationCounterBackground',
        position: 'absolute',
        alignSelf: 'flex-end',
        justifyContent: 'center',
        top: 0,
        width: 22,
        height: 20,
        borderRadius: 10,
    },
    notificationUnreadCount: {
        color: '$nofificationCounterText',
        alignSelf: 'center',
        fontSize: '$primaryTextXS',
    },
    containernew: {
        flex: 1,
        alignItems: 'center',
    },
    active: {
        borderTopWidth: 3,
        borderColor: 'white',
    },
    inactive: {
        borderTopWidth: 3,
        borderColor: 'blue',
    },
    textStyle: {
        color: 'white',
        fontSize: 13,
    },
    tabBarItem: {
        flex: 1,
        alignItems: 'center',
    },
    containerrow: {
        flexDirection: 'row',
        alignContent: 'center',
        height: 56,
        width: '100%',
        paddingHorizontal: 16,
        backgroundColor: 'blue',


        justifyContent: 'center',

    },
});
