import React, { useState } from 'react';
import { ActivityIndicator, View, TouchableOpacity, Text, I18nManager } from 'react-native';
import FastImage from 'react-native-fast-image';
import EStyleSheet from 'react-native-extended-stylesheet';
import Icon from 'react-native-vector-icons/MaterialIcons';
import * as Animatable from 'react-native-animatable';
import moment from 'moment';
const AnimatableIcon = Animatable.createAnimatableComponent(Icon);
const styles = EStyleSheet.create({
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: '100%',
        height: '100%',
    },
    animatedContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        position: 'absolute',
        width: '100%',
        height: '100%',
        color: '#FFFFFF',
    },
    zoomableAnimatedContainer: {
        position: 'absolute',
        top: 5,
        left: 745,
        color: '#FFFFFF',
    },
});

export default function(props) {
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setError] = useState(false);

    const handleOnLoadEnd = () => {
        setIsLoading(false);
    };

    const handleOnLoadStart = () => {
        setIsLoading(true);
    };
    const { metadata: { location: { latitude, longitude, time } = {} } = {} } = props;
    const imageTime = time && moment(time).format('YYYY-MM-DD HH:mm:ss');

    const handleRef = ref => (this.theImage = ref);
    return (
        <>
            <FastImage
                ref={handleRef}
                onLoadStart={handleOnLoadStart}
                onLoadEnd={handleOnLoadEnd}
                {...{ ...props, source: { ...props.source, priority: FastImage.priority.normal, headers: { '.ASPXAUTH': props.authCode } } }}
            />
            {!isLoading && !isError && (latitude || longitude || time) && (
                <View style={tempStyles.coordsContainer}>
                    {latitude && (
                        <Animatable.Text
                            style={tempStyles.coordsText}
                            animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                            duration={300}
                            useNativeDriver
                        >
                            Latitude: {latitude}
                        </Animatable.Text>
                    )}
                    {longitude && (
                        <Animatable.Text
                            style={tempStyles.coordsText}
                            animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                            duration={300}
                            useNativeDriver
                        >
                            Longitude: {longitude}
                        </Animatable.Text>
                    )}
                    {imageTime && (
                        <Animatable.Text
                            style={tempStyles.coordsText}
                            animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                            duration={300}
                            useNativeDriver
                        >
                            Time: {imageTime}
                        </Animatable.Text>
                    )}
                </View>
            )}
            {isLoading && (
                <View style={styles.loaderContainer}>
                    <ActivityIndicator size="small" animating color={EStyleSheet.value('$primarySelectedItem')} />
                </View>
            )}
            {!isLoading && props.source.uploading && (
                <View style={props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer}>
                    <AnimatableIcon
                        name={'cloud'}
                        size={props.isZoomable ? 30 : 14}
                        duration={1000}
                        delay={0}
                        animation={{
                            0: {
                                color: 'rgba(0,0,0,0.6)',
                            },
                            0.5: {
                                color: 'rgba(169,169,169, 0.5)',
                            },
                            1: {
                                color: 'rgba(0,0,0,0.6)',
                            },
                        }}
                        iterationCount="infinite"
                        style={{ position: 'absolute', top: 0, left: 0, paddingLeft: props.isZoomable ? 0 : 5 }}
                    />

                    <AnimatableIcon
                        ref={ref => (this.icon = ref)}
                        name={'arrow-upward'}
                        size={props.isZoomable ? 15 : 7}
                        color="white"
                        animation={{
                            0: { translateY: 0, opacity: 1 },
                            0.5: { translateY: props.isZoomable ? -6 : -3, opacity: 1 },
                            1: {
                                translateY: props.isZoomable ? -12 : -6,
                                opacity: 0,
                            },
                        }}
                        duration={1000}
                        delay={0}
                        easing={t => Math.pow(t, 1.7)}
                        iterationCount="infinite"
                        style={{ position: 'absolute', top: props.isZoomable ? 12 : 5, left: props.isZoomable ? 7 : 8 }}
                        useNativeDriver
                    />
                </View>
            )}
            {!isLoading && props.source.uploaded && (
                <View style={[props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer, { paddingLeft: 3 }]}>
                    <Icon name="cloud-done" color="#ffffff" size={props.isZoomable ? 30 : 14} style={[styles.remarkTickMarkIcon]} />
                </View>
            )}
            {!props.isZoomable && !isLoading && props.source.error && (
                <View style={[props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer, { paddingLeft: 3 }]}>
                    <Icon name="cloud-off" color="#ff0000" size={props.isZoomable ? 30 : 14} style={[styles.remarkTickMarkIcon]} />
                </View>
            )}
        </>
    );
}

const tempStyles = EStyleSheet.create({
    coordsContainer: {
        backgroundColor: '$primaryDarkBackground',
        position: 'absolute',
        left: 250,
        top: 20,
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 5,
        opacity: 0.5,
    },
    coordsText: {
        textAlign: 'left',
        textAlignVertical: 'center',
        color: '$primaryWhite',
        opacity: 1,
        paddingVertical: 1,
        fontSize: '$primaryTextXS',
    },
});
