import React from 'react';
import PropTypes from 'prop-types';
import { View, Image } from 'react-native';
import { Text } from 'react-native-paper';
import { Icon } from 'app/components';
import images from 'app/images';
import styles from './styles';

class IconAndLabel extends React.PureComponent {
    static propTypes = {
        label: PropTypes.string,
        containerStyle: PropTypes.object,
        icon: PropTypes.string,
        iconType: PropTypes.string,
        iconStyle: PropTypes.object,
        iconSize: PropTypes.number,
        labelStyle: PropTypes.object,
    };

    render() {
        const { label, iconProps, iconType, containerStyle, iconStyle, labelStyle, iconSize = undefined } = this.props;
        const mergedIconStyle = { ...styles.defaultIconStyle, ...iconStyle };
        const mergedLabelStyle = { ...styles.defaultLabelStyle, ...labelStyle };
        return (
            <View style={[styles.container, containerStyle]}>
                {!!iconProps && <Icon size={45} {...iconProps} style={mergedIconStyle} color={mergedIconStyle.color} />}
                <Text style={mergedLabelStyle}>{label}</Text>
            </View>
        );
    }
}

export default IconAndLabel;
