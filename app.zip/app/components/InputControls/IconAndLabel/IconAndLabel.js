import React from 'react';
import PropTypes from 'prop-types';
import { View, Image } from 'react-native';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import images from 'app/images';
import styles from './styles';

class IconAndLabel extends React.PureComponent {
    static propTypes = {
        label: PropTypes.string,
        containerStyle: PropTypes.object,
        icon: PropTypes.string,
        iconType: PropTypes.string,
        iconStyle: PropTypes.object,
        iconSize: PropTypes.number,
        labelStyle: PropTypes.object,
    };

    render() {
        const { label, icon, iconType, containerStyle, iconStyle, labelStyle, iconSize = undefined } = this.props;
        const mergedIconStyle = { ...styles.defaultIconStyle, ...iconStyle };
        const mergedLabelStyle = { ...styles.defaultLabelStyle, ...labelStyle };
        let iconComponent = undefined;
        if (!!icon) {
            if (iconType === 'default') {
                iconComponent = (
                    <Icon
                        name={icon}
                        size={!!iconSize ? iconSize : mergedLabelStyle.fontSize}
                        color={mergedIconStyle.color}
                        style={mergedIconStyle}
                    />
                );
            } else {
                iconComponent = <Image source={images[icon].content} resizeMode="contain" style={iconStyle} />;
            }
        }
        return (
            <View style={[styles.container, containerStyle]}>
                {iconComponent}
                <Text style={mergedLabelStyle}>{label}</Text>
            </View>
        );
    }
}

export default IconAndLabel;
