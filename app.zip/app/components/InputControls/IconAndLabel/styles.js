import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    defaultIconStyle: {
        color: '$primaryDarkTextColor',
        marginEnd: 10,
    },
    defaultLabelStyle: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
});
