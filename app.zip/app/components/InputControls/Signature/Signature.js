import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, Image } from 'react-native';
import { Title, Button } from 'react-native-paper';
import SignatureCapture from 'ThirdPartyModules/react-native-signature-capture';
import UUIDGenerator from 'react-native-uuid-generator';
import { localeProperty } from 'app/config/i18n/i18n';
import { attachmentsHelper } from 'app/api/helperServices';
import styles from './styles';

class Signature extends Component {
    static propTypes = {
        onChange: PropTypes.func,
        value: PropTypes.any,
    };

    constructor() {
        super();
        this.onSaveEvent = this.onSaveEvent.bind(this);
        this.onDragEvent = this.onDragEvent.bind(this);
        this.state = { uuid: '' };
    }
    ref;

    componentDidMount() {
        UUIDGenerator.getRandomUUID().then(uuid => {
            this.setState({ uuid });
        });
    }

    onSaveEvent = result => {
        if (result.encoded) {
            this.props.onChange(result);
        }
    };

    onDragEvent = () => {};

    saveSign = () => {
        this.refs['sign'].saveImage();
    };

    resetSign = () => {
        this.refs['sign'].resetImage();
    };

    render() {
        if (!this.state.uuid) return null;

        const signatureId = this.props.value;
        const editable = !!this.props.editable;

        const doc = !editable && signatureId && attachmentsHelper.getDoc(signatureId);
        return (
            <View style={styles.container}>
                <View style={styles.signatureCaptureWrapper}>
                    {!editable && doc && doc.path && (
                        <Image resizeMode="contain" style={{ width: '100%', height: '100%' }} source={{ uri: doc.path }} />
                    )}
                    {editable && (
                        <SignatureCapture
                            style={styles.signature}
                            ref="sign"
                            onSaveEvent={this.onSaveEvent}
                            onDragEvent={this.onDragEvent}
                            saveImageFileInExtStorage={true}
                            fileName={`${this.state.uuid}.png`}
                            showNativeButtons={false}
                            showTitleLabel={false}
                            viewMode={'portrait'}
                        />
                    )}
                </View>
                {editable && (
                    <View style={styles.buttonWrapper}>
                        <Button style={styles.resetBtn} onPress={this.resetSign}>
                            <Text style={styles.resetBtnText}>{localeProperty(this.props.config, 'labelReset')}</Text>
                        </Button>
                        <Button style={styles.signatureBtnSave} onPress={this.saveSign}>
                            <Text style={styles.signatureBtnSaveText}>{localeProperty(this.props.config, 'labelSave')}</Text>
                        </Button>
                    </View>
                )}
            </View>
        );
    }
}

export default Signature;
