import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
    },
    titleWrapper: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {},
    buttonWrapper: {
        flexDirection: 'row',
        padding: 10,
        justifyContent: 'center',
    },
    signatureCaptureWrapper: {
        width: '100%',
        height: 300,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    signature: {
        flex: 1,
    },
    signatureBtnSave: {
        backgroundColor: '$primaryDarkButtonBackground',
        margin: 5,
    },
    signatureBtnSaveText: {
        color: '$primaryLightTextColor',
    },
    resetBtn: {
        margin: 5,
        backgroundColor: '$primaryMediumTextColor',
    },
    resetBtnText: {
        color: '$primaryLightTextColor',
    },
});
