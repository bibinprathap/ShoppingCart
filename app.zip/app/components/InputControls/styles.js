import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    fieldContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        marginHorizontal: 10,
        marginTop: 5,
    },
    fieldContainerShadowed: {
        backgroundColor: '$primaryWhite',
        elevation: 4,
        borderRadius: 8,
    },
    fieldContainerFlat: {
        backgroundColor: 'transparent',
        elevation: 0,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryDarkPlaceholderColor',
    },
});
