import EStyleSheet from 'react-native-extended-stylesheet';
export default EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        //paddingBottom: 70,
    },
    MainContainer: {
        flex: 1,
    },
    unknownServiceSelection: {
        flex: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    textHeading: {
        fontSize: '$primaryTextMD',
        textAlign: 'center',
    },
    textDetailText: {
        fontSize: '$primaryTextXXS',
        textAlign: 'center',
        marginVertical: 10,
        marginHorizontal: 20,
    },
    errorText: { color: '$primaryErrorTextColor' },
    retryButton: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    retryButtonIcon: { width: 200 },
    contentWithChecklist: { flex: 10 },
    visitTabContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primarySelectedItem',
    },
    contentContainer: {
        flex: 1,
        //elevation: 2,
        marginVertical: 10,
        marginHorizontal: 5,
        //borderRadius: 10,
    },
    checklistContainer: {
        backgroundColor: '$primaryWhite',
    },
    formContainer: {
        backgroundColor: '$primaryWhite',
    },
    unknownInspectionContainer: {
        backgroundColor: '$primaryLightBackground',
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionButtonsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 20,
    },
    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
});
