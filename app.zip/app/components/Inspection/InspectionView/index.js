import React, { memo, Component } from 'react';
import { View, Text, Dimensions, I18nManager, ScrollView, Animated, Easing } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { FollowUpHeader, VisitView } from 'app/components';
import { createAppContainer } from 'react-navigation';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
const currentLocale = I18nManager.isRTL ? 'ar' : 'en';
const InspectionView = memo(props => {
    const InspectionStackDefinition = {
        routes: [],
        initialRoute: 'currentVisit',
    };
    const inspectionContainer = props.inspection;
    const { inspection } = inspectionContainer;
    inspection.visits.map((v, i) => {
        const visitId = inspection.visits.length - 1 == i ? 'currentVisit' : 'visit' + (i + 1);
        const currentVisitStatus = v.inspectionStatusConst ? v.inspectionStatusConst.toLowerCase() : 'draft';
        const isReadOnlyVisit = v.locallySaved == true || currentVisitStatus !== 'draft';

        InspectionStackDefinition.routes.push({
            key: visitId,
            screen: ({ navigation }) => (
                <VisitView
                    visit={v}
                    visitIndex={i}
                    showSaveButton={true}
                    dispatch={props.dispatch}
                    refNumber={inspection.refNumber}
                    inspection={inspection}
                    currentInspectionVersion={props.currentInspectionVersion}
                    thumbnailSize="extralarge"
                    errorLogs={{}}
                    dataLookups={props.dataLookups}
                    isReadOnlyVisit={isReadOnlyVisit}
                />
            ),
            //Todo: check if we are using this  headerTitle anywhere? if not, remove it
            params: { followupreview: true, headerTitle: strings(visitId, { locale: currentLocale }) },
            title: strings(visitId, { locale: currentLocale }),
            tabBarLabel: strings(visitId, { locale: currentLocale }),
            icon: 'serviceSelection',
            iconType: 'custom',
        });
    });
    const routeConfig = {};
    InspectionStackDefinition.routes.map(item => {
        routeConfig[item.key] = {
            screen: item.screen,
            title: item.title,
            subtitle: item.subtitle,
            navigationOptions: ({ navigation }) => ({
                title: item.title,
                subtitle: item.subtitle,
            }),
            tabBarOptions: {
                scrollEnabled: true,
            },
        };
    });
    const InspectionStackNavigator = createAppContainer(
        createMaterialTopTabNavigator(routeConfig, {
            initialRouteName: InspectionStackDefinition.initialRoute,
            swipeEnabled: false,
            animationEnabled: false,
            lazy: true,
            tabBarPosition: 'top',
            transitionConfig: () => ({
                transitionSpec: {
                    duration: 0,
                },
            }),

            defaultNavigationOptions: {
                tabBarComponent: props => <FollowUpHeader {...props} />,
            },
        })
    );

    return <InspectionStackNavigator screenProps={InspectionStackDefinition.routes} />;
});
export default InspectionView;
