import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { inspectionStackDefinition } from 'app/config/routs/defs';
import { inspectionsHelper } from 'app/api/helperServices';

class InspectionContainer extends Component {
    static propTypes = {
        currentInspectionVersion: PropTypes.any,
        currentInspectionContainer: PropTypes.object,
        selectedService: PropTypes.object,
    };

    currentRouteName = this.props.navigation.state.routeName;

    handleSideNavOnPress = item => {
        this.props.navigation.navigate(item.key);
    };

    render() {
        const { children, selectedService, currentInspectionVersion, currentInspectionContainer } = this.props;
        const adjustedRoutes = inspectionsHelper.getRoutes();
        this.breadCrumbs = adjustedRoutes.map(item => {
            return {
                key: item.key,
                title: item.title,
                selected: item.key === this.currentRouteName,
            };
        });

        this.sidenavRoutes = [
            {
                key: 'dashboard',
                title: strings('dashboard'),
                icon: 'home',
                iconType: 'custom',
            },
        ];
        this.sidenavRoutes = this.sidenavRoutes.concat(adjustedRoutes);

        return (
            <BaseContainer {...this.props}>
                <SearchBar breadCrumbs={this.breadCrumbs} />
                <View style={styles.container}>
                    <View style={styles.sideNavContainer}>
                        <SideNav routes={this.sidenavRoutes} onPress={this.handleSideNavOnPress} currentRouteName={this.currentRouteName} />
                    </View>
                    <View style={styles.contentsContainer}>{children}</View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    let selectedService = undefined;

    if (!currentInspectionContainer) return;

    if (
        state.masterdata.services &&
        currentInspectionContainer &&
        currentInspectionContainer.inspection &&
        currentInspectionContainer.inspection.service
    ) {
        selectedService = _.find(state.masterdata.services, { serviceId: currentInspectionContainer.inspection.service });
    }
    const mappedProps = {
        currentInspectionVersion: state.inspections.currentInspectionVersion,
        currentInspectionContainer: currentInspectionContainer,
        selectedService: selectedService,
    };
    return mappedProps;
};

export default connect(mapStateToProps)(InspectionContainer);
