import styles from './styles';
import InspectionContainer from './InspectionContainer';

export { InspectionContainer, styles };
