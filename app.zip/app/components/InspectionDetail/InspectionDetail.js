import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, FlatList, I18nManager } from 'react-native';
import { Text, List, TouchableRipple, Divider } from 'react-native-paper';
import { connect } from 'react-redux';
import _ from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import { CustomAccordion } from 'app/components/CustomAccordion';
import { Timeline } from 'app/components/Timeline';
import { YesNo } from 'app/components/Checklist/YesNo';
import { Check } from 'app/components/Checklist/Check';
import * as Animatable from 'react-native-animatable';

import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

class InspectionDetail extends Component {
    static propTypes = {
        def: PropTypes.object,
        values: PropTypes.object,
        onValuechanged: PropTypes.func,
        onAttachmentChanged: PropTypes.func,
    };

    constructor(props) {
        super(props);

        this.state = {
            currentValues: !!this.props.values ? this.props.values : {},
        };
    }

    updateStateAndCallback = (data, callback) => {
        let values = { ...this.state.currentValues };
        // let values = this.state.currentValues;
        values[data.code] = data.val;
        this.setState({ currentValues: values }, () => callback && callback(values));
    };

    handleValueChange = data => {
        this.updateStateAndCallback(data, this.props.onValuechanged);
    };

    handleAttachmentChange = data => {
        this.updateStateAndCallback(data, this.props.onAttachmentChanged);
    };

    handleOnRemarksChanged = data => {
        this.updateStateAndCallback(data, this.props.onAttachmentChanged);
    };

    getChecklistGroups(props) {
        const { def, values, editable } = props;
        const groups = [];
        //const checklistItems = [];
        let isFirst = true;
        for (groupDef of def.checklistGroups) {
            const checklistItems = groupDef.checklist.map((i, index) => {
                const selection = values[i.code]; // _.find(values, { code: i.code });
                const checklistItemInstance = this.getChecklistItemInstance(i.questionType, i, selection, editable);
                //
                return (
                    <Animatable.View
                        key={i.code}
                        animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                        duration={400}
                        useNativeDriver={true}
                        easing="ease-out"
                        delay={index * 100}
                    >
                        <View style={styles.checklistSingleItemContainer}>{checklistItemInstance}</View>
                        {/* {index < groupDef.checklist.length - 1 && <Divider style={{ marginHorizontal: 20 }} />} */}
                    </Animatable.View>
                );
            });
            const group = (
                <CustomAccordion
                    key={groupDef.code}
                    title={localeProperty(groupDef, 'title')}
                    expandedAtStart={isFirst}
                    //expandedAtStart={true}
                >
                    <View style={styles.checklistItemsContainer}>{checklistItems}</View>
                </CustomAccordion>
            );
            groups.push({ key: groupDef.code, instance: group });
            isFirst = false;
        }
        return groups;
    }
    getChecklistItemInstance = (questionType, item, value, editable) => {
        switch (questionType) {
            case 'YesNo':
                const question = localeProperty(item, 'question') || 'Unknown question';
                // const violatorType = inspectionsHelper.getServiceviolatorType({
                //     def: this.props.def,
                //     parentViolatorType: this.props.parentViolatorType,
                //     code: item.code,
                // });
                return (
                    <YesNo
                        question={question}
                        editable={editable}
                        code={item.code}
                        isMandatory={item.isMandatory}
                        violationTypeIds={item.violationTypeIds}
                        val={value}
                        //  violatorType={violatorType}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            case 'Checkbox':
                return (
                    <Check
                        editable={editable}
                        code={item.code}
                        isMandatory={item.isMandatory}
                        violationTypeIds={item.violationTypeIds}
                        val={value}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            default:
                return null;
        }
    };

    keyExtractor = (item, index) => {
        // console.log(
        //     `keyExtractor, index: ${index}, item: ${JSON.stringify(item)}`
        // );
        return item.key;
    };
    renderChecklistGroup = ({ item, index, separators }) => {
        const values = this.state.currentValues;

        // console.log(
        //     `renderChecklistGroup ${item.key}. values = ${JSON.stringify(
        //         values
        //     )}`
        // );

        return item.instance;
    };

    render() {
        // console.log('InspectionDetails.render() props --> ');
        // console.log(this.props);
        const { def, editable } = this.props;
        const groups = this.getChecklistGroups(this.props);
        return (
            <Timeline
                //data={def.checklistGroups}
                editable={editable}
                data={groups}
                keyExtractor={this.keyExtractor}
                //renderItem={({ item }) => item.instance}
                renderItem={this.renderChecklistGroup}
                //extraData={this.state}
            />
        );
    }
}

mapStateToProps = state => {
    return {};
};

export default connect(mapStateToProps)(InspectionDetail);
