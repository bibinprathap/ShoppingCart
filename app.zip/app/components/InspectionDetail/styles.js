import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
    },
    checklistItemsContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        marginEnd: 5,
        borderRadius: 10,
    },
    checklistSingleItemContainer: {
        flex: 1,
        backgroundColor: '$primaryMediumBackground',
        borderRadius: 10,
        marginVertical: 10,
        padding: 10,
    },
});
