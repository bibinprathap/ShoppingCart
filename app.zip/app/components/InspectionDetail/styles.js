import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
    },
    checklistItemsContainer: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '$primaryMediumBackground',
        justifyContent: 'center',
        //alignItems: 'center',
        marginEnd: 5,
        //paddingVertical: 20,
        borderRadius: 10,
    },
    checklistSingleItemContainer: {
        flex: 1,
        paddingVertical: 20,
        //borderWidth: 1
    },
});
