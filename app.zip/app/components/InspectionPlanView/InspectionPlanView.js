import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ActivityIndicator } from 'react-native';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import ArcGISMapView from 'rnarcgis';
import styles from './styles';
import AppApi from 'app/api/real';
const api = new AppApi();

class InspectionPlanView extends Component {
    state = {
        loading: false,
    };
    constructor(props) {
        super(props);
    }

    async componentDidMount() {
        //const id=
        this.setState({ loading: true });
        console.log('****** ' + this.props.activeProfileDomainCustomerId);
        try {
            const smartHubData = await api.getInspectorPlanStatus(this.props.activeProfileDomainCustomerId);
            const plotIds = smartHubData.plots.map(item => item.plotId);

            console.log('getInspectorPlanStatus smartHubData: ', JSON.stringify(smartHubData), 'plotIDs = ', plotIds);
            const plotsGeometries = await api.getInspectionsPlotsData(plotIds);
            console.log('plotsGeometries *** ', plotsGeometries);

            const polygonData = plotIds.map(plot => {
                console.log('plot ', plot);
                const plotDataSmartHub = _.find(smartHubData.plots, { plotId: plot });
                console.log('plotDataSmartHub ', plotDataSmartHub);
                const plotDataGeometry = _.find(plotsGeometries, { plotId: plot });
                const plotTitle = plotDataSmartHub.plotTitle;
                let fillColor;
                if (plotDataSmartHub.status == 'done') fillColor = 0x8000ff00;
                else if (plotDataSmartHub.status == 'inprogress') fillColor = 0x800000ff;
                else fillColor = 0x80ff0000;
                const lineColor = fillColor;
                const lineWidth = 1;

                return {
                    PolygonID: plotTitle,
                    polygonFillColor: fillColor,
                    boundaryLineColor: lineColor,
                    lineWidth: lineWidth,
                    coords: plotDataGeometry.geometry,
                };
            });
            const formattedData = { polygons: polygonData };
            this.setState({ inspectorPlotStatusData: formattedData, loading: false });
            console.log('formattedData ', formattedData);
        } catch (error) {
            //console.log('error in getInspectorPlanStatus: ', error);
            throw error;
        }
    }
    render() {
        // console.log('InspectionDetails.render() props --> ');
        // console.log(this.props);  { latitude: 24.488979, longitude: 54.378012 }

        if (this.state.loading)
            return (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator />
                </View>
            );

        return (
            <View style={styles.container}>
                {/* <Text> InspectionPlanView123</Text>
                <Text>{this.state.loading ? 'Loading...' : 'Loaded'}</Text>
                <Text> inspectorPlotStatusData = {JSON.stringify(this.state.inspectorPlotStatusData)}</Text> */}
                <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ flex: 1 }}
                    initialMapCenter={[{ latitude: 24.488979, longitude: 54.378012 }]}
                    recenterIfGraphicTapped={true}
                    basemapUrl="https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer"
                    drawPolygons={JSON.stringify(this.state.inspectorPlotStatusData)}
                    onSingleTap={this.onSingleTap}
                />
            </View>
        );
    }

    onSingleTap = event => {
        points = event.nativeEvent;
        if (!points.mapPoint) {
            return;
        }
        if (points.mapPoint.latitude && points.mapPoint.longitude) {
            console.log('latitude ', points.mapPoint.latitude.toFixed(4), 'longitude ', points.mapPoint.longitude.toFixed(4));
        }
        // console.log('single tap');
        //return;
    };
}

const mapStateToProps = state => {
    return {
        activeProfileDomainCustomerId: state.auth.activeProfileDomainCustomerId,
    };
};

export default connect(mapStateToProps)(InspectionPlanView);
