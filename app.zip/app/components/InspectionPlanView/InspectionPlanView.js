import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ActivityIndicator, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import ADMGISMapView from '../ADMGISMapView/ADMGISMapView';
import styles from './styles';
import AppApi from 'app/api/real';
const api = new AppApi();

class InspectionPlanView extends Component {
    state = {
        loading: false,
    };
    constructor(props) {
        super(props);
    }

    async componentDidMount() {
        this.setState({ loading: true });
        try {
            const smartHubData = await api.getInspectorPlanStatus(this.props.activeProfileUserId);
            const plotGisIds = smartHubData.plots.map(item => item.plotGisId);

            const plotsGeometries = await api.getPlots({
                municipalityId: '1000',
                orderByFields: 'plotNumber',
                plotGisIds,
                ReturnGeometry: true,
            });

            const polygonData = plotGisIds.map(plot => {
                const plotDataSmartHub = _.find(smartHubData.plots, { plotGisId: plot });

                const plotDataGeometry = _.find(plotsGeometries, { plotGisId: plot });
                if (plotDataGeometry) {
                    const plotTitle = plotDataSmartHub.plotTitle;
                    let fillColor;
                    if (plotDataSmartHub.status == 'done') fillColor = 0x8000ff00;
                    else if (plotDataSmartHub.status == 'inprogress') fillColor = 0x800000ff;
                    else fillColor = 0x80ff0000;
                    const lineColor = fillColor;
                    const lineWidth = 1;

                    return {
                        data: { id: plotTitle, type: 'plot' },
                        PolygonID: plotTitle,
                        polygonFillColor: fillColor,
                        boundaryLineColor: lineColor,
                        lineWidth: lineWidth,
                        coords: plotDataGeometry.geometry,
                    };
                }
                // else {

                //     return null;
                // }
            });
            const formattedData = { polygons: polygonData };
            //this.setState({ inspectorPlotStatusData: formattedData, loading: false });

            this.setState({ inspectorPlotStatusData: formattedData, loading: false });
        } catch (error) {
            throw error;
        }
    }
    render() {
        if (this.state.loading)
            return (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator />
                </View>
            );

        return (
            <View style={styles.container}>
                <ADMGISMapView polygonsData={JSON.stringify(this.state.inspectorPlotStatusData)} showMenu={true} />
            </View>
        );
    }

    onSingleTap = event => {
        points = event.nativeEvent;
        if (!points.mapPoint) {
            return;
        }
        if (points.mapPoint.latitude && points.mapPoint.longitude) {
        }

        //return;
    };
}

const mapStateToProps = state => {
    return {
        activeProfileUserId: state.auth.activeProfileUserId,
        preference: state.generic.preference,
    };
};

export default connect(mapStateToProps)(InspectionPlanView);
