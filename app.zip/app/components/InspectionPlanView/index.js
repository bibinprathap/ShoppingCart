import styles from './styles';
import InspectionPlanView from './InspectionPlanView';

export { styles, InspectionPlanView };
