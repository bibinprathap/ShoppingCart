import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    loadingContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',

        backgroundColor: '$primaryLightBackground',
    },
    container: {
        flex: 1,
    },
});
