import React, { Component, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Icon } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { ItemDetailDialog } from 'app/screens';
import EStyleSheet from 'react-native-extended-stylesheet';

export default function SimpleItemInfo({ item, displayFields, detailedDisplayFields, hideDetailsButton, customActions, ...otherProps }) {
    const [isItemInfoDialogVisible, toggleItemInfoDialog] = useState(false);

    if (!displayFields || !displayFields.length) {
        throw `No display fields set`;
    }

    const handleItemDetailIconPress = () => {
        toggleItemInfoDialog(!isItemInfoDialogVisible);
    };
    const handleOnRequestClose = () => {
        toggleItemInfoDialog(!isItemInfoDialogVisible);
    };

    const customActionsComponent = typeof customActions === 'function' ? customActions({ item, ...otherProps }) : null;

    return (
        <View style={styles.itemContainer}>
            {hideDetailsButton !== true && (
                <View style={{ justifyContent: 'center' }}>
                    <ItemDetailDialog
                        isVisible={isItemInfoDialogVisible}
                        item={item}
                        onRequestClose={handleOnRequestClose}
                        hideDetailsButton={true}
                        displayFields={detailedDisplayFields}
                        title={strings('back')}
                    />
                    <TouchableOpacity style={styles.moreDetailIconWrapper} onPress={handleItemDetailIconPress}>
                        <Icon type="MaterialCommunityIcons" name={'view-sequential'} size={24} style={styles.icon} />
                    </TouchableOpacity>
                </View>
            )}
            <View style={styles.itemContent}>
                {item.titleE && (
                    <View style={styles.titleContainer}>
                        <Text style={styles.titleText}>{localeProperty(item, 'title')}</Text>
                    </View>
                )}
                {displayFields.map(field => {
                    return (
                        <View style={styles.otherDetailContainer} key={field}>
                            <View style={styles.otherDetailItem}>
                                <View style={styles.fieldWrapper}>
                                    <Text style={styles.fieldName}>{strings(field)}: </Text>
                                </View>
                                <View style={styles.fieldWrapper}>
                                    <Text style={styles.fieldValue}>{localeProperty(item, field) || item[field]}</Text>
                                </View>
                            </View>
                        </View>
                    );
                })}
            </View>
            {customActionsComponent}
        </View>
    );
}

const styles = EStyleSheet.create({
    itemContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
    },
    icon: { margin: 5 },
    itemContent: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
        //justifyContent: 'center',
    },
    titleContainer: {
        marginBottom: 5,
    },
    fieldWrapper: {
        marginRight: 10,
        flexWrap: 'wrap',
    },
    otherDetailContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    otherDetailItem: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    fieldName: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    fieldValue: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
    },
    moreDetailIconWrapper: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 3,
        margin: 5,
    },
});
