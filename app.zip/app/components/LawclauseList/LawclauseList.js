import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { _ } from 'lodash';
import { strings } from 'app/config/i18n/i18n';
import { MultiSelector } from 'app/components/MultiSelector';
import { Chip } from 'app/components/Chip';
import styles from './styles';

class LawclauseList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            lawClausesTemp: [],
            searchKey: null,
        };
    }

    onSelect = items => {
        const { multiSelect } = this.props;
        const selectedItems = [];
        const SItems = multiSelect ? items : [items];
        _.map(SItems, item => {
            selectedItems.push(item.id);
        });
        this.props.onValueChange(selectedItems);
    };

    searchKeyUpdate = searchKey => {
        if (this.props.violationTypeIds && this.props.violationTypeIds.length > 0) {
            const filterdDataSource = _.filter(this.props.violationTypeIds, item => {
                let value = (item['title'] && item['title'].toLowerCase()) || '';
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ lawClausesTemp: filterdDataSource, searchKey });
        }
    };

    handleSearch = searchKey => {};

    removeItem = item => {
        const selectedItems = this.props.selectedItems || [];
        _.remove(selectedItems, id => {
            return id === item.id;
        });
        this.props.onValueChange(selectedItems);
    };

    render() {
        const { editable, multiSelect } = this.props;
        const source = (this.state.searchKey ? this.state.lawClausesTemp : this.props.violationTypeIds) || [];
        const selectedItemIds = this.props.selectedItems || [];

        strings('lawClausesSelected');

        return (
            <MultiSelector
                placeholder={strings('searchLawClauses')}
                notSelectedText={'No law clause found'}
                selectedText={strings('lawClausesSelected')}
                isLoading={false}
                onSelect={this.onSelect}
                editable={editable}
                source={source}
                selectedIds={selectedItemIds}
                multiSelect={multiSelect}
                removeItem={this.removeItem}
                searchKeyUpdate={this.searchKeyUpdate}
                handleSearch={searchKey => this.handleSearch(searchKey)}
                headerTitle={strings('select')}
            />
        );
    }
}

export default LawclauseList;
