import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Chip } from 'react-native-paper';
import { _ } from 'lodash';
import { strings } from 'app/config/i18n/i18n';
import { Selector } from 'app/components/Selector';
import styles from './styles';

class LawclauseList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showSelectorModal: false,
            lawClausesTemp: [],
            searchKey: null,
        };
    }

    renderSelectText = () => {
        const { selectedItems, lawClauses } = this.props;
        if (lawClauses.length == 0) return 'No law clause found';
        return selectedItems.length ? `${selectedItems.length}  ${strings('lawClausesSelected')}` : strings('selectLawClauses');
    };

    onSelect = items => {
        const selectedItems = [];
        const cleanedItems = _.map(items, item => {
            selectedItems.push(item.id);
        });
        this.props.onValueChange(selectedItems);
    };

    searchKeyUpdate = searchKey => {
        if (this.props.lawClauses && this.props.lawClauses.length > 0) {
            const filterdDataSource = _.filter(this.props.lawClauses, item => {
                let value = (item['title'] && item['title'].toLowerCase()) || '';
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ lawClausesTemp: filterdDataSource, searchKey });
        }
    };

    handleSearch = searchKey => {};

    removeItem = item => {
        const selectedItems = this.props.selectedItems || [];
        _.remove(selectedItems, id => {
            return id === item.id;
        });
        this.props.onValueChange(selectedItems);
    };

    shortString = str => {
        if (str.length > 50) {
            return str.substring(0, 49) + '...';
        }
        return str;
    };

    render() {
        const { editable } = this.props;
        const source = (this.state.searchKey ? this.state.lawClausesTemp : this.props.lawClauses) || [];
        const selectedItemIds = this.props.selectedItems || [];
        const chipItems = [];
        const sourceMapped = _.map(source, item => {
            if (selectedItemIds.length > 0 && selectedItemIds.indexOf(item.id) !== -1) {
                chipItems.push(
                    <Chip
                        key={item.id && item.id.toString()}
                        style={styles.chipStyle}
                        textStyle={styles.chipTextStyle}
                        onClose={editable ? () => this.removeItem(item) : null}
                        onPress={editable ? () => this.setState({ showSelectorModal: !this.state.showSelectorModal }) : null}
                    >
                        {this.shortString(item.title)}
                    </Chip>
                );
            }
            return _.extend({ label: item.title }, item);
        });

        return (
            <View>
                {this.state.showSelectorModal && (
                    <Selector
                        placeholder={strings('searchLawClauses')}
                        isLoading={false}
                        onSelect={this.onSelect}
                        source={sourceMapped}
                        selectedIds={this.props.selectedItems}
                        multiSelect
                        searchKeyUpdate={this.searchKeyUpdate}
                        handleSearch={searchKey => this.handleSearch(searchKey)}
                        onRequestClose={() => this.setState({ showSelectorModal: false })}
                        headerTitle={strings('select')}
                    />
                )}
                <View style={styles.violationsSelectionContainer}>
                    {(editable && (
                        <TouchableOpacity
                            disabled={!editable}
                            style={styles.lawClauseTitleBtn}
                            onPress={() => (editable ? this.setState({ showSelectorModal: !this.state.showSelectorModal }) : null)}
                        >
                            <Text style={styles.lawClauseSelectedText}>{this.renderSelectText()}</Text>
                        </TouchableOpacity>
                    )) ||
                        null}
                    {chipItems && <View style={styles.chipWrapper}>{chipItems}</View>}
                </View>
            </View>
        );
    }
}

export default LawclauseList;
