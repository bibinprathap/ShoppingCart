import styles from './styles';
import LawclauseList from './LawclauseList';

export { styles, LawclauseList };
