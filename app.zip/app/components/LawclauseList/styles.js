import { I18nManager, Dimensions } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        //marginVertical: 10
        //borderWidth: 1
    },
    questionContainer: {
        flex: 1,
        //flexGrow: 3,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        paddingStart: 10,
        marginBottom: 10,
    },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 30,
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
        color: '#333',
    },
    border: {
        borderBottomWidth: 1,
        borderBottomColor: '#dadada',
        marginBottom: 20,
    },
    heading: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 5,
        marginTop: 20,
    },
    label: {
        fontWeight: 'bold',
    },
    switch: {
        marginBottom: 20,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
    },
    selectOrRemoveAll: {
        justifyContent: 'center',
        height: 44,
        borderWidth: 0,
        paddingHorizontal: 10,
        backgroundColor: '$primaryHeaderColor',
        alignItems: 'center',
        fontFamily: '$primaryFontHeading',
        color: '$primaryWhite',
    },
    violationsMultiselect: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        direction: I18nManager.isRTL ? 'rtl' : 'ltr',
    },
    labelContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
    },
    violationsSelectionContainer: {
        flex: 2,
    },
    lawClauseTitleBtn: {
        padding: 12,
        backgroundColor: '$primaryMediumBackground',
        borderWidth: 1,
        borderRadius: 4,
        margin: 5,
        borderColor: '$primaryLightBorder',
    },
    lawClauseSelectedText: {
        fontSize: '$primaryTextXSM',
        fontFamily: '$primaryFontHeading',
        color: '$primaryDarkTextColor',
    },
    chipWrapper: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexWrap: 'wrap',
        padding: 5,
    },
    chipStyle: {
        marginRight: 10,
        marginBottom: 5,
    },
    chipTextStyle: {
        fontSize: '$primaryTextXSM',
        fontFamily: '$primaryFontHeading',
        color: '$primaryDarkTextColor',
    },
});
