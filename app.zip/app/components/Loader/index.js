import Loader from './Loader';
import Spinner from './Spinner';

export { Spinner, Loader };
