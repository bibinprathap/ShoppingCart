import React, { Component } from 'react';
import { View, TouchableOpacity, Linking } from 'react-native';
import { Icon, HeaderGeneric, Modal, DashboardMapView } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { formatAddress } from 'app/api/helperServices/utils';
import { strings } from 'app/config/i18n/i18n';

export default class LocationAndGoogleMaps extends Component {
    constructor() {
        super();
        this.handleShowGoogleMap = this.handleShowGoogleMap.bind(this);
        this.state = { modalVisible: false };
    }
    handleShowGoogleMap() {
        const { location } = this.props;
        const coords = location && location.coords;
        if (!coords) return;
        const formattedAddress = formatAddress(location.address || {});
        const latLng = `${coords.latitude},${coords.longitude}`;
        const label = formattedAddress;
        Linking.openURL(`geo:0,0?q=${latLng}(${label})`);
    }

    render() {
        const { location } = this.props;
        return (
            <View>
                <View style={{ flexDirection: 'row' }}>
                    {location ? (
                        <TouchableOpacity onPress={() => this.setState({ modalVisible: !this.state.modalVisible })}>
                            <View style={styles.locationIconContainer}>
                                <Icon type="MaterialCommunityIcons" name={'map-marker'} style={styles.locationIcon} size={20} />
                            </View>
                        </TouchableOpacity>
                    ) : (
                        <View style={styles.locationIconContainer}>
                            <Icon type="MaterialCommunityIcons" name={'map-marker-off'} style={styles.locationIcon} size={20} />
                        </View>
                    )}
                    <TouchableOpacity style={styles.locationIconContainer} onPress={this.handleShowGoogleMap}>
                        <View style={styles.locationIconContainer}>
                            <Icon type="MaterialCommunityIcons" name={'google-maps'} style={styles.locationIcon} size={20} />
                        </View>
                    </TouchableOpacity>
                </View>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={() => this.setState({ modalVisible: false })} title={strings('mapView')} />
                    <DashboardMapView inspection={{ location: this.props.location }} />
                </Modal>
            </View>
        );
    }
}

const styles = EStyleSheet.create({
    locationIconContainer: {
        height: 27,
        width: 27,
        borderRadius: 5,
        backgroundColor: '$primaryHeaderColor',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
    },
    locationIcon: {
        fontSize: 25,
        justifyContent: 'center',
        alignItems: 'center',
        color: '$primaryWhite',
    },
});
