import React, { Component } from 'react';
import { Modal, StatusBar } from 'react-native';
import alertsHelper from 'app/api/helperServices/alerts';
import DropdownAlert from 'react-native-dropdownalert';
import { connect } from 'react-redux';
import { _ } from 'lodash';

class ModalComponent extends Component {
    dropdownRef;
    componentDidUpdate(prevProps, prevState) {
        if (this.props.alert && this.dropdownRef && this.props.visible) {
            const { type, title, message } = this.props.alert;
            if (!_.isEqual(this.props.alert, prevProps.alert)) this.dropdownRef.alertWithType(type, title, message);
        }
    }

    componentDidMount() {
        if (this.props.alert && this.dropdownRef && this.props.visible) {
            const { type, title, message } = this.props.alert;
            this.dropdownRef.alertWithType(type, title, message);
        }
    }

    handleRef = ref => {
        this.dropdownRef = ref;
    };

    render() {
        const { children, ...otherProps } = this.props;
        return (
            <Modal {...otherProps}>
                <DropdownAlert
                    replaceEnabled={false}
                    closeInterval={6000}
                    wrapperStyle={{ elevation: 10, position: 'absolute', top: 0, width: '100%' }}
                    defaultContainer={{ padding: 8, elevation: 10, paddingTop: StatusBar.currentHeight, flexDirection: 'row' }}
                    ref={this.handleRef}
                    showCancel={true}
                    onClose={() => this.props.alert && alertsHelper.invokeOnClose()}
                />
                {children}
            </Modal>
        );
    }
}

mapStateToProps = state => {
    return {
        alert: state.settings.alert,
    };
};
export default connect(mapStateToProps)(ModalComponent);
