import React, { Component } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity } from 'react-native';
import { IconButton, Checkbox, Button } from 'react-native-paper';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric, Loader, Chip, Modal } from 'app/components';
import { _ } from 'lodash';
import { RadioButton } from 'react-native-paper';

class MultiSelector extends Component {
    constructor(props) {
        super(props);
        const selectedIds = props.selectedIds || [];
        const confirmedSelectedIds = selectedIds;
        this.state = { searchKey: null, modalVisible: false, selectedIds, confirmedSelectedIds };
    }

    componentDidUpdate(prevProps, prevState) {
        if (!this.state.modalVisible && !_.isEqual(_.sortBy(this.props.selectedIds), _.sortBy(prevState.selectedIds))) {
            this.setState({ selectedIds: this.props.selectedIds, confirmedSelectedIds: this.props.selectedIds });
        }
    }

    updateSearchKey = searchKey => {
        this.setState({ searchKey });
        if (this.props.searchKeyUpdate) {
            this.props.searchKeyUpdate(searchKey);
        }
    };

    onPressItem = item => {
        if (!this.props.multiSelect && this.props.onSelect) {
            this.props.onSelect(item);
            const selectedIds = this.props.selectedIds || [];
            this.setState({ modalVisible: false, confirmedSelectedIds: [item.id], selectedIds });
            this.updateSearchKey('');
        } else if (this.props.multiSelect) {
            if (this.state.selectedIds.indexOf(item.id) !== -1) {
                const selectedIds = this.state.selectedIds;
                _.remove(selectedIds, itemKey => itemKey === item.id);
                this.setState({ selectedIds });
            } else {
                this.setState({ selectedIds: [...this.state.selectedIds, item.id] });
            }
        }
    };

    renderItem = ({ item }) => {
        const mappedItem = this.props.mapItem ? this.props.mapItem(item) : item;
        return (
            <TouchableOpacity onPress={() => this.onPressItem(mappedItem)} key={`${mappedItem.id}`} style={styles.itemWrapper}>
                {this.props.multiSelect && (
                    <Checkbox
                        onPress={() => this.onPressItem(mappedItem)}
                        status={this.state.selectedIds.indexOf(mappedItem.id) !== -1 ? 'checked' : 'unchecked'}
                    />
                )}
                {!this.props.multiSelect && (
                    <RadioButton
                        color="#454F63"
                        onPress={() => this.onPressItem(mappedItem)}
                        status={this.state.selectedIds.indexOf(mappedItem.id) !== -1 ? 'checked' : 'unchecked'}
                    />
                )}
                <Text style={styles.itemDetails}>{mappedItem.title || mappedItem.label}</Text>
            </TouchableOpacity>
        );
    };

    onMultiSelect = () => {
        const { selectedIds } = this.state;
        const result = this.props.source.filter(item => selectedIds.indexOf(item.id) !== -1);
        this.props.onSelect(result);
        this.setState({ modalVisible: false, confirmedSelectedIds: selectedIds });
    };

    renderSelectText = () => {
        const { source, multiSelect, placeholder, selectedText, notSelectedText } = this.props;

        const { confirmedSelectedIds } = this.state;
        if (source.length == 0) return notSelectedText || 'No items selected';
        if (!multiSelect) return confirmedSelectedIds.length ? '' : placeholder || '';

        return confirmedSelectedIds.length ? `${confirmedSelectedIds.length}  ${selectedText || ''}` : placeholder || '';
    };

    handleModalVisibility = () => {
        const { editable } = this.props;
        const { modalVisible } = this.state;
        const selectedIds = this.props.selectedIds || [];
        const confirmedSelectedIds = selectedIds;

        if (editable) {
            this.setState({ modalVisible: !modalVisible, selectedIds, confirmedSelectedIds });
            this.updateSearchKey('');
        }
        return null;
    };

    render() {
        const source = this.props.source || [];
        const { isLoading, multiSelect, editable, showChip } = this.props;
        const { selectedIds, confirmedSelectedIds } = this.state;
        const chipItems = [];

        _.map(source, item => {
            if (confirmedSelectedIds.length > 0 && confirmedSelectedIds.indexOf(item.id) !== -1) {
                chipItems.push(
                    <Chip
                        key={item.id && item.id.toString()}
                        editable={editable}
                        multiSelect={multiSelect}
                        onClose={editable && this.props.removeItem ? () => this.props.removeItem(item) : null}
                        onPress={this.handleModalVisibility}
                    >
                        {item.title}
                    </Chip>
                );
            }
        });

        return (
            <View>
                <View style={styles.chipContainer}>
                    {(editable && this.renderSelectText() && (
                        <TouchableOpacity disabled={!editable} style={styles.btn} onPress={this.handleModalVisibility}>
                            <Text style={styles.btnText}>{this.renderSelectText()}</Text>
                        </TouchableOpacity>
                    )) ||
                        null}
                    {chipItems && <View style={styles.chipWrapper}>{chipItems}</View>}
                </View>
                <Modal animationType="slide" transparent={false} visible={this.state.modalVisible} onRequestClose={this.handleModalVisibility}>
                    <View style={styles.container}>
                        <HeaderGeneric backAction={this.handleModalVisibility} title={this.props.headerTitle} />
                        {!this.props.hideSearchBar && (
                            <View style={styles.searchbarWrapper}>
                                <TextInput
                                    placeholder={this.props.placeholder || ''}
                                    style={[styles.textInput]}
                                    autoCorrect={false}
                                    value={this.state.searchKey}
                                    onChangeText={this.updateSearchKey}
                                    autoCapitalize="none"
                                />
                                <IconButton
                                    icon="search"
                                    size={26}
                                    style={styles.searchIcon}
                                    color={styles.searchIcon.color}
                                    onPress={() => (this.props.handleSearch ? this.props.handleSearch(this.state.searchKey) : null)}
                                />
                            </View>
                        )}
                        <View style={styles.resultWrapper}>
                            {isLoading && (
                                <View style={styles.wrapper}>
                                    <Loader loading={isLoading} sprinnerSize={20} />
                                </View>
                            )}
                            {!isLoading && source && source.length === 0 && (
                                <View style={styles.wrapper}>
                                    <Text style={styles.title}>{strings('noResults')}</Text>
                                </View>
                            )}
                            {(source && source.length && (
                                <View style={{ flex: 1 }}>
                                    <FlatList
                                        initialNumToRender={25}
                                        data={source}
                                        extraData={this.state}
                                        keyExtractor={(item, index) => index.toString()}
                                        renderItem={this.props.renderItem || this.renderItem}
                                        ListFooterComponent={() => <View style={{ height: 60 }} />}
                                    />
                                    {multiSelect && (
                                        <View style={styles.footer}>
                                            <Button style={styles.btnSave} onPress={this.onMultiSelect}>
                                                <Text style={styles.btnSaveText}>{strings('confirm')}</Text>
                                            </Button>
                                        </View>
                                    )}
                                </View>
                            )) ||
                                null}
                        </View>
                    </View>
                </Modal>
            </View>
        );
    }
}

export default MultiSelector;
