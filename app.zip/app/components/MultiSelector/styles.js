import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightInputBackground',
    },
    resultWrapper: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 20,
    },
    searchbarWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    textInput: {
        flex: 1,
        borderRadius: 6,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        justifyContent: 'center',
        backgroundColor: '$primaryLightInputBackground',
        paddingStart: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        includeFontPadding: false,
        paddingRight: 40,
    },
    searchIcon: {
        position: 'absolute',
        right: 20,
    },
    itemWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginBottom: 2,
    },
    itemDetails: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
    },
    wrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primaryWhite',
    },
    emptyMessage: {
        color: '$primaryMediumTextColor',
        marginBottom: 15,
    },
    title: {
        fontSize: '$primaryTextSM',
    },
    btnSave: {
        backgroundColor: '$primaryDarkButtonBackground',
        flex: 1,
        padding: 0,
        margin: 0,
        justifyContent: 'center',
    },
    btnSaveText: {
        color: '$primaryLightTextColor',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXSM',
        padding: 0,
        margin: 0,
    },
    footer: {
        position: 'absolute',
        bottom: 0,
        height: 60,
        width: '100%',
        paddingTop: 10,
        backgroundColor: '$primaryLightInputBackground',
    },
    chipContainer: {
        flex: 2,
    },
    btn: {
        padding: 12,
        backgroundColor: '$primaryMediumBackground',
        borderWidth: 1,
        borderRadius: 4,
        margin: 5,
        borderColor: '$primaryLightBorder',
    },
    btnText: {
        fontSize: '$primaryTextXSM',
        fontFamily: '$primaryFontHeading',
        color: '$primaryDarkTextColor',
    },
    chipWrapper: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        flexWrap: 'wrap',
        padding: 5,
    },
});
