import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { requireNativeComponent, ViewPropTypes } from 'react-native';
// import { compose, withHandlers } from 'recompose';

const componentInterface = {
    name: 'NumberPickerAndroid',
    propTypes: {
        initialValues: PropTypes.shape({
            minValue: PropTypes.number,
            maxValue: PropTypes.number,
            initialValue: PropTypes.number,
        }),
        wrapSelectorWheel: PropTypes.bool,
        onChange: PropTypes.func,
        ...ViewPropTypes,
    },
};

const NativeNumberPickerAndroid = requireNativeComponent('NumberPickerAndroid', componentInterface);

const handleValueChange = ({ onChange }) => event => onChange(event.nativeEvent.value);

export class NumberPickerAndroid extends React.PureComponent {
    render() {
        var { values, style, ...otherProps } = this.props;

        return (
            <NativeNumberPickerAndroid onChange={event => this.props.onChange(event.nativeEvent.value)} style={[style && style]} {...otherProps} />
        );
    }
}

// export const NumberPickerAndroid = compose(
//     withHandlers({
//         handleValueChange,
//     })
// )(props => <NativeNumberPickerAndroid {...props} onChange={props.handleValueChange} />);
