import React, { memo } from 'react';
import { View, Picker, TouchableOpacity, Text } from 'react-native';
import { NumericInput } from 'app/components';

import { strings } from 'app/config/i18n/i18n';
import styles from './styles';

const getPeriodNumberPicker = (selectedPeriod, handlePeriodNumberPickerChange, editable) => {
    return (
        <NumericInput
            value={selectedPeriod}
            initValue={selectedPeriod}
            totalWidth={120}
            editable={editable}
            minValue={!editable ? selectedPeriod : 0}
            maxValue={!editable ? selectedPeriod : null}
            totalHeight={40}
            onChange={handlePeriodNumberPickerChange}
        />
    );
};

const getPeriodTypePicker = (periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable) => {
    return (
        <Picker
            selectedValue={selectedPeriodType}
            style={styles.periodTypePicker}
            enabled={editable}
            onValueChange={itemValue => handleChangePeriodType(itemValue)}
            itemStyle={{ textAlign: 'left' }}
        >
            {periodTypeOptions.map((v, i) => {
                return <Picker.Item key={i} label={strings(v)} value={v} />;
            })}
        </Picker>
    );
};

export default props => {
    const { selectedPeriod, periodTypeOptions, selectedPeriodType, handlePeriodNumberPickerChange, handleChangePeriodType, editable } = props;
    const periodNumberPicker = getPeriodNumberPicker(selectedPeriod, handlePeriodNumberPickerChange, editable);
    const periodTypePicker = getPeriodTypePicker(periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable);
    return (
        <View style={styles.actionPeriod}>
            {periodNumberPicker}
            {periodTypePicker}
        </View>
    );
};
