import React from 'react';
import { View, Picker } from 'react-native';
import NumericInput from 'react-native-numeric-input';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';

class PeriodPicker extends React.PureComponent {
    getPeriodNumberPicker = (selectedPeriod, handlePeriodNumberPickerChange, editable) => {
        return (
            <NumericInput
                value={selectedPeriod}
                initValue={selectedPeriod}
                totalWidth={120}
                editable={editable}
                minValue={!editable ? selectedPeriod : 0}
                maxValue={!editable ? selectedPeriod : null}
                totalHeight={40}
                onChange={handlePeriodNumberPickerChange}
            />
        );
    };

    getPeriodTypePicker = (periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable) => {
        return (
            <Picker
                selectedValue={selectedPeriodType}
                style={styles.periodTypePicker}
                enabled={editable}
                onValueChange={itemValue => handleChangePeriodType(itemValue)}
            >
                {periodTypeOptions.map((v, i) => {
                    return <Picker.Item key={i} label={strings(v)} value={v} />;
                })}
            </Picker>
        );
    };

    render() {
        const {
            selectedPeriod,
            periodTypeOptions,
            selectedPeriodType,
            handlePeriodNumberPickerChange,
            handleChangePeriodType,
            editable,
        } = this.props;
        const periodNumberPicker = this.getPeriodNumberPicker(selectedPeriod, handlePeriodNumberPickerChange, editable);
        const periodTypePicker = this.getPeriodTypePicker(periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable);
        return (
            <View style={styles.actionPeriod}>
                {periodNumberPicker}
                {periodTypePicker}
            </View>
        );
    }
}
export default PeriodPicker;
