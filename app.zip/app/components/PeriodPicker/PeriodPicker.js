import React from 'react';
import { View, Picker } from 'react-native';
import NumericInput from 'react-native-numeric-input';
//import InputSpinner from './InputSpinner';

import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
export default function(props) {
    getPeriodNumberPicker = (selectedPeriod, handlePeriodNumberPickerChange, editable) => {
        return (
            <NumericInput
                value={selectedPeriod}
                initValue={selectedPeriod}
                totalWidth={120}
                editable={editable}
                minValue={!editable ? selectedPeriod : 0}
                maxValue={!editable ? selectedPeriod : null}
                totalHeight={40}
                onChange={handlePeriodNumberPickerChange}
            />
        );
    };
    getPeriodTypePicker = (periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable) => {
        return (
            <Picker
                selectedValue={selectedPeriodType}
                style={styles.periodTypePicker}
                enabled={editable}
                onValueChange={itemValue => handleChangePeriodType(itemValue)}
                itemStyle={{ textAlign: 'left' }}
            >
                {periodTypeOptions.map((v, i) => {
                    return <Picker.Item key={i} label={strings(v)} value={v} />;
                })}
            </Picker>
        );
    };
    const { selectedPeriod, periodTypeOptions, selectedPeriodType, handlePeriodNumberPickerChange, handleChangePeriodType, editable } = props;
    const periodNumberPicker = this.getPeriodNumberPicker(selectedPeriod, handlePeriodNumberPickerChange, editable);
    const periodTypePicker = this.getPeriodTypePicker(periodTypeOptions, selectedPeriodType, handleChangePeriodType, editable);
    return (
        <View style={styles.actionPeriod}>
            {periodNumberPicker}
            {periodTypePicker}
        </View>
    );
}
