import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    periodTypePicker: {
        height: 50,
        width: '100%',
        minWidth: 100,
        flex: 1,
        marginLeft: 5,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
    },
    actionPeriod: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'center',
        borderWidth: 0.251173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
    },
});
