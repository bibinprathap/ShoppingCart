import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';
export default EStyleSheet.create({
    container: {},
    violationAmount: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    violationHeadingText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
    },
    violationAmountText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primarySelectedTextColor',
    },
    violationAmountContainer: { flexDirection: 'row' },
    violationHeadingContainer: {
        flexDirection: 'row',
        flex: 1,
    },
    violatorCard: {
        flex: 1,
    },
    violatorCardOuter: {
        flex: 1,
        backgroundColor: '$primaryDividerLightColor',
        width: '99%',
        marginVertical: 4,
        borderRadius: 8,
        borderColor: 'red',
        marginBottom: 15,
        // backgroundColor: '#f5dcdc',
    },
    violationSummaryHeadingContainer: {
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: 10,
        flex: 1,
    },
    violationTotalViolationAmountContainer: {
        alignItems: 'flex-end',
        marginRight: 10,
    },
    groupHeading: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        marginLeft: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    accordionHeading: {
        paddingTop: 5,
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
    },
    violatorOuter: { flex: 1, padding: 5 },
    errorBorder: { borderColor: '$primaryInvalidBorderColor', borderWidth: 1 },
});
