import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableNativeFeedback } from 'react-native';
import { Text } from 'react-native-paper';
import { Icon, ReconciliationPreview, SimpleViolatorInfo, ViolationItemsList } from 'app/components';

import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
class CheckListViolator extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = { infoDialogVisible: false, infoDialogmanuallyClose: false, reconciliationDialogVisible: false };
    }
    handleReconciliation = () => {
        this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible }, () => {
            if (!this.state.reconciliationDialogVisible) this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible });
        });
    };

    handleViolatorDialogDismiss = props => {
        this.setState({ infoDialogVisible: false });
    };

    customActions = props => {
        const { violatordetails, currentInspectionVersion } = props;
        return (
            <View style={styles.violatorFineContainer}>
                {violatordetails.signature ? (
                    <TouchableNativeFeedback onPress={(e, props) => this.handleReconciliation(violatordetails, currentInspectionVersion)}>
                        <View style={styles.violatorInfoClickArea}>
                            <Icon type="AdmIcon" name="wf-1210" size={25} style={[styles.icon, styles.iconActive]} />
                        </View>
                    </TouchableNativeFeedback>
                ) : null}
            </View>
        );
    };

    render() {
        const {
            inspection,
            violatordetails,
            violationItems,

            currentInspectionVersion,
            editable,
            enablePrint,
            errorLogs,
        } = this.props;
        debugger;
        let borderStyle = {};
        if (violatorHasError) borderStyle = styles.errorBorder;
        if (!violatordetails) return null;

        const violatorHasError = false;
        violationItems.map(checklistItem => {
            if (checklistItem.lawClause) {
                const { violationTypeId } = checklistItem.lawClause;
                if (errorLogs[violationTypeId]) borderStyle = styles.errorBorder;
            }
        });

        const noViolations = errorLogs.noViolations;
        if (noViolations) borderStyle = styles.errorBorder;
        const printButtonstyle = enablePrint == true ? styles.buttonPositive : styles.buttonPositiveDisabled;

        return (
            <View style={[styles.violatorCard, borderStyle]}>
                {this.state.reconciliationDialogVisible ? (
                    <ReconciliationPreview
                        readOnly={true}
                        currentInspectionVersion={currentInspectionVersion}
                        violatorId={violatordetails.violatorId}
                        values={{ reconciled: !!violatordetails.signature, signature: violatordetails.signature }}
                        dispatch={this.props.dispatch}
                        navigation={this.props.navigation}
                    />
                ) : null}

                <View style={styles.violatorOuter}>
                    {violatordetails && (
                        <SimpleViolatorInfo
                            key={violatordetails.violatorId}
                            violator={violatordetails}
                            editable={false}
                            customActions={this.customActions}
                            currentInspectionVersion={currentInspectionVersion}
                            violatordetails={violatordetails}
                            violationItems={violationItems}
                            errorLogs={errorLogs}
                        />
                    )}
                </View>
                {violationItems && violationItems.length > 0 && (
                    <ViolationItemsList
                        editable={editable}
                        inspection={inspection}
                        currentInspectionVersion={currentInspectionVersion}
                        violationItems={violationItems}
                        errorLogs={errorLogs}
                        dispatch={this.props.dispatch}
                    />
                )}

                {noViolations ? <Text style={styles.ValidationMessageText}>{errorLogs.noViolations}</Text> : null}
            </View>
        );
    }
}

export default CheckListViolator;
