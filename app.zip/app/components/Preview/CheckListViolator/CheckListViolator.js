import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableNativeFeedback, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings, localeProperty, formatCurrency } from 'app/config/i18n/i18n';
import commonStyles from 'app/components/Preview/styles';
import { CustomAccordion } from 'app/components/CustomAccordion';
import { inspectionsHelper } from 'app/api/helperServices';

import { ChecklistAwarenessSummary } from 'app/components/Preview/ChecklistAwarenessSummary';
import { ChecklistWarningSummary } from 'app/components/Preview/ChecklistWarningSummary';
import { ChecklistViolationSummary } from 'app/components/Preview/ChecklistViolationSummary';
import { IndividualInfoForm, BuildingInfoForm, CompanyInfoForm } from 'app/components/Form';
import { ReconciliationPreview } from 'app/components/Reconciliation';
import styles from './styles';
import { Loader } from 'app/components/Loader';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
class CheckListViolator extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    constructor(props) {
        super(props);
        const { violatordetails, validations } = props;

        this.state = { infoDialogVisible: false, infoDialogmanuallyClose: false, reconciliationDialogVisible: false };
    }

    handleInfoValidator = () => {
        const { violatordetails, validations } = this.props;
        const violatorHasError = this.checkViolatorHasError(violatordetails, validations);
        if (this.state.infoDialogVisible || (!this.state.infoDialogmanuallyClose && violatorHasError))
            this.setState({ infoDialogVisible: false, infoDialogmanuallyClose: true });
        else this.setState({ infoDialogVisible: true, infoDialogmanuallyClose: true });
    };
    handleReconciliation = () => {
        this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible }, () => {
            if (!this.state.reconciliationDialogVisible) this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible });
        });
    };

    handleViolatorDialogDismiss = props => {
        this.setState({ infoDialogVisible: false });
    };
    checkViolatorHasError = (violator, validations) => {
        let violatorhaserror = false;
        switch (violator.violatorType) {
            case 'company':
                if (validations && (validations.company || validations.companyIndividual)) violatorhaserror = true;
                break;
            case 'building':
                if (validations && (validations.building || validations.buildingIndividual)) violatorhaserror = true;
                break;
            case 'individual':
                if (validations && (validations.individual || validations.ticketRecipient)) violatorhaserror = true;
                break;
            default:
                break;
        }
        return violatorhaserror;
    };
    getviolatorInfoForm = (violator, currentInspectionVersion, validations) => {
        let ValidationInfoForm;
        const customFieldContainerStyles = [styles.validatorPressentRowContainer];
        const violatorPresence = violator.ticketRecipient ? false : true;
        switch (violator.violatorType) {
            case 'company':
                ValidationInfoForm = (
                    <React.Fragment key={violator.UIIdentifier}>
                        <View style={styles.violatorInfoWrapper}>
                            <CompanyInfoForm
                                readOnly={true}
                                currentInspectionVersion={currentInspectionVersion}
                                formName={violator.UIIdentifier + 'company'}
                                values={violator.company}
                                validations={validations.company}
                            />
                            <Text style={styles.questionText}>{strings('ticketRecipient')}</Text>
                            <IndividualInfoForm
                                currentInspectionVersion={currentInspectionVersion}
                                readOnly={true}
                                identifier={violator.UIIdentifier}
                                formName={violator.UIIdentifier + 'ticketRecipient'}
                                formTitle={strings('ticketRecipient')}
                                values={violator.ticketRecipient}
                                validations={validations.companyIndividual}
                            />
                        </View>
                    </React.Fragment>
                );

                break;
            case 'building':
                ValidationInfoForm = (
                    <React.Fragment key={violator.UIIdentifier}>
                        <View style={styles.violatorInfoWrapper}>
                            <BuildingInfoForm
                                readOnly={true}
                                formName={violator.UIIdentifier + 'building'}
                                currentInspectionVersion={currentInspectionVersion}
                                values={violator.building}
                                validations={validations.building}
                            />
                            <Text style={styles.questionText}>{strings('ticketRecipient')}</Text>
                            <IndividualInfoForm
                                currentInspectionVersion={currentInspectionVersion}
                                readOnly={true}
                                formName={violator.UIIdentifier + 'ticketRecipient'}
                                formTitle={strings('ticketRecipient')}
                                values={violator.ticketRecipient}
                                validations={validations.buildingIndividual}
                            />
                        </View>
                    </React.Fragment>
                );

                break;
            case 'individual':
                ValidationInfoForm = (
                    <React.Fragment key={violator.UIIdentifier}>
                        <View style={styles.violatorInfoWrapper}>
                            <IndividualInfoForm
                                currentInspectionVersion={currentInspectionVersion}
                                readOnly={true}
                                identifier={violator.UIIdentifier}
                                formName={violator.UIIdentifier + 'violator'}
                                formTitle={strings('violator')}
                                values={violator.violator}
                                validations={validations.individual}
                            />
                            {/* <View style={customFieldContainerStyles}>
                               
                                <Text style={[styles.questionText, { alignSelf: 'center', textAlign: I18nManager.isRTL ? 'right' : 'left' }]}>
                                    {strings('violatorIsPresent')}
                                </Text>
                            
                            </View> */}
                            {!violatorPresence && (
                                <>
                                    <Text style={styles.questionText}>{strings('ticketRecipient')}</Text>
                                    <IndividualInfoForm
                                        currentInspectionVersion={currentInspectionVersion}
                                        readOnly={true}
                                        formName={violator.UIIdentifier + 'ticketRecipient'}
                                        formTitle={strings('ticketRecipient')}
                                        values={violator.ticketRecipient}
                                        validations={validations.ticketRecipient}
                                    />
                                </>
                            )}
                        </View>
                    </React.Fragment>
                );

                break;
            default:
                ValidationInfoForm = <Text key={violator.UIIdentifier}>Todo: handle the unknown violator type: {violator.violatorType}</Text>;
        }
        return ValidationInfoForm;
    };

    renderViolatorsTitle = props => {
        const { violatordetails, identifier, currentInspectionVersion, violationItems, validations } = props;
        const totalViolationAmount = violationItems.reduce((total, checklistItem) => {
            const { violationAmount } = checklistItem.item;

            let finalVolationAmount = checklistItem.lawClause
                ? inspectionsHelper.getViolationAmount({
                      lawClauseIDs: [checklistItem.lawClause.clauseId],
                      occurance: 1,
                      discount: 0,
                  })
                : violationAmount;

            if (finalVolationAmount) {
                total = total + finalVolationAmount;
            }
            return total;
        }, 0);
        const title = inspectionsHelper.getViolatorHeading({
            text: strings('violator'),
            violatorType: violatordetails.violatorType,
            violatordetails: violatordetails,
            identifier,
        });
        const titleColor = title.indexOf(strings('new')) > -1 ? styles.accordionHeadingGray : {};
        const violatorHasError = this.checkViolatorHasError(violatordetails, validations);
        const violatorInfobackground = violatorHasError ? styles.violatorInfobackground : {};
        const violatorPresence = violatordetails.ticketRecipient ? false : true;
        let violatorPresentbackground = {};
        let violatorTypeIcon = 'group';
        let violatorIconColor = styles.violatorPresentIconColor;
        if (violatordetails.violatorType == 'building') {
            violatorTypeIcon = 'business';
        } else if (violatordetails.violatorType == 'individual') {
            violatorTypeIcon = 'face';
            violatorIconColor = violatorPresence || violatorHasError ? styles.violatorPresentIconColor : {};
            if (!violatorHasError)
                violatorPresentbackground = violatorPresence ? styles.violatorPresentbackground : styles.violatorNotPresentBackground;
        }

        return (
            <View style={styles.violatorContainer}>
                <TouchableNativeFeedback onPress={(e, props) => this.handleInfoValidator(violatordetails, currentInspectionVersion)}>
                    <View style={[styles.violatorInfoClickArea]}>
                        <View style={[styles.violatorInfoContainer, violatorInfobackground, violatorPresentbackground]}>
                            <Icon name={violatorTypeIcon} size={20} style={[styles.iconDark, violatorIconColor]} />
                        </View>
                    </View>
                </TouchableNativeFeedback>
                <View style={[commonStyles.generalHeading, styles.violatorInfoTitleContainer]}>
                    <Text style={[commonStyles.generalHeading, styles.accordionHeading, titleColor]}>{title}</Text>
                </View>
                {totalViolationAmount > 0 ? (
                    <View style={[styles.violatorAmountArea]}>
                        <Text style={styles.violationAmount}>{formatCurrency(totalViolationAmount, true)}</Text>
                        <Text style={styles.violationCurrency}>{'AED'}</Text>
                    </View>
                ) : null}

                {violatordetails.signature ? (
                    <TouchableNativeFeedback onPress={(e, props) => this.handleReconciliation(violatordetails, currentInspectionVersion)}>
                        <View style={[styles.violatorInfoClickArea]}>
                            <View style={[styles.violatorInfoContainer]}>
                                <Icon name="done-all" size={25} style={styles.icon} />
                            </View>
                        </View>
                    </TouchableNativeFeedback>
                ) : null}
            </View>
        );
    };
    handleAttachmentPressed = attachments => {
        this.props.navigation.navigate('attachments', {
            attachments: attachments,
            editable: this.props.editable,
        });
    };
    render() {
        const {
            inspection,
            violatordetails,
            violationItems,
            warningItems,
            awarenessItems,
            currentInspectionVersion,
            editable,
            enablePrint,
            validations,
        } = this.props;
        let ValidationInfoForm = null;
        let reconciliationDialog = null;
        const violatorHasError = this.checkViolatorHasError(violatordetails, validations);
        if (this.state.infoDialogVisible || (!this.state.infoDialogmanuallyClose && violatorHasError))
            ValidationInfoForm = this.getviolatorInfoForm(violatordetails, currentInspectionVersion, validations);
        let borderStyle = {};
        if (violatorHasError) borderStyle = styles.errorBorder;
        violationItems.map(checklistItem => {
            if (checklistItem.lawClause) {
                const { clauseId } = checklistItem.lawClause;
                if (validations[clauseId]) borderStyle = styles.errorBorder;
            }
        });
        warningItems.map(checklistItem => {
            if (checklistItem.lawClause) {
                const { clauseId } = checklistItem.lawClause;
                if (validations[clauseId]) borderStyle = styles.errorBorder;
            }
        });
        awarenessItems.map(checklistItem => {
            if (checklistItem.lawClause) {
                const { clauseId } = checklistItem.lawClause;
                if (validations[clauseId]) borderStyle = styles.errorBorder;
            }
        });
        const noViolations = validations.noViolations;
        if (noViolations) borderStyle = styles.errorBorder;
        const printButtonstyle = enablePrint == true ? styles.buttonPositive : styles.buttonPositiveDisabled;

        const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        const currentVisitData = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex] : undefined;

        return (
            <React.Fragment>
                <View style={[styles.violatorCard, borderStyle]}>
                    {this.state.reconciliationDialogVisible ? (
                        <ReconciliationPreview
                            readOnly={true}
                            currentInspectionVersion={currentInspectionVersion}
                            violatorIdentifier={violatordetails.UIIdentifier}
                            values={{ reconciled: !!violatordetails.signature, signature: violatordetails.signature }}
                            dispatch={this.props.dispatch}
                            navigation={this.props.navigation}
                        />
                    ) : null}
                    <CustomAccordion
                        index="1"
                        renderHeaderTitle={this.renderViolatorsTitle}
                        currentInspectionVersion={currentInspectionVersion}
                        violatordetails={violatordetails}
                        violationItems={violationItems}
                        expandedAtStart={true}
                        validations={validations}
                    >
                        <View style={styles.violatorOuter}>
                            <View>{ValidationInfoForm}</View>
                        </View>

                        {violationItems && violationItems.length > 0 && (
                            <ChecklistViolationSummary
                                editable={editable}
                                inspection={inspection}
                                currentInspectionVersion={currentInspectionVersion}
                                items={violationItems}
                                validations={validations}
                                dispatch={this.props.dispatch}
                            />
                        )}
                        {warningItems && warningItems.length > 0 && (
                            <ChecklistWarningSummary
                                editable={editable}
                                inspection={inspection}
                                currentInspectionVersion={currentInspectionVersion}
                                items={warningItems}
                                validations={validations}
                                dispatch={this.props.dispatch}
                            />
                        )}

                        {awarenessItems && awarenessItems.length > 0 && (
                            <ChecklistAwarenessSummary
                                editable={editable}
                                inspection={inspection}
                                currentInspectionVersion={currentInspectionVersion}
                                items={awarenessItems}
                                validations={validations}
                                dispatch={this.props.dispatch}
                            />
                        )}
                        {noViolations ? <Text style={styles.ValidationMessageText}>{validations.noViolations}</Text> : null}
                        <View style={styles.buttonWrapper}>
                            <Icon.Button
                                name="print"
                                borderRadius={25}
                                style={[styles.button, styles.buttonPositive]}
                                onPress={() =>
                                    this.props.printReceipt({
                                        violationItems,
                                        visitDate: currentVisitData.visitDate,
                                        generalInfo: currentVisitData.generalInfo,
                                        def: currentVisitData.def,
                                    })
                                }
                            >
                                <Loader loading={this.props.isPrinting} sprinnerSize={14}>
                                    <Text style={styles.buttonText}>{strings('print')}</Text>
                                </Loader>
                            </Icon.Button>
                        </View>
                        <View style={styles.violatorOuter} />
                    </CustomAccordion>
                </View>
            </React.Fragment>
        );
    }
}

export default CheckListViolator;
