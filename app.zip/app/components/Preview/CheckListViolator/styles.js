import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    violationAmount: {
        zIndex: 100,
        color: '$primaryDividerDarkColor',
        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        fontWeight: 'bold',
    },
    violationCurrency: {
        zIndex: 100,
        color: '$primaryDividerDarkColor',
        fontSize: '$primaryTextXXS',
        fontWeight: 'bold',
    },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    errorBorder: { borderColor: '$primaryInvalidBorderColor', borderWidth: 1 },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 3,
        borderRadius: 5,
    },
    icon: {
        color: '$primaryLightTextColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
    },
    iconDark: {
        color: '$primaryDarkTextColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingVertical: 5,

        marginLeft: 0,
    },
    violatorInfoWrapper: {
        //todo: remove it if not being used, need to verify
        //width: '100%',
        //backgroundColor: '$primaryWhite',
    },

    violatorInfo: {
        flexDirection: 'row-reverse',
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'center',
        margin: 0,
        padding: 0,
        color: '$primaryLightTextColor',
    },
    violatorFineContainer: {
        flexDirection: 'column',
        justifyContent: 'space-between',
        padding: 5,
    },
    violatorInfoClickArea: {
        marginVertical: 5,
        padding: 5,
    },
    violatorAmountArea: {
        flexDirection: 'row',
        // alignItems: 'flex-end',
        // flexWrap: 'wrap',
        //justifyContent: 'center',
    },
    violatorInfobackground: { backgroundColor: '$primaryInvalidBorderColor' },
    // violatorPresentContainer: {
    //     width: 40,
    //     alignItems: 'flex-end',
    //     borderRadius: 95,
    //     marginHorizontal: 20,
    //     marginVertical: 5,
    //     padding: 1,
    //     justifyContent: 'flex-end',
    //     alignItems: 'flex-end',
    // },
    violatorPresentbackground: {
        color: '$primaryLightTextColor',
    },
    iconActive: {
        color: '$primaryHeaderColor',
        //color: '$primarySuccessColor',
    },
    violatorPresentIconColor: {
        color: '$primaryLightTextColor',
    },
    violatorNotPresentBackground: {
        backgroundColor: '#e9f2fb',
    },
    violatorCard: {
        //backgroundColor: '$primaryDividerLightColor',
        backgroundColor: '$primaryWhite',
        borderWidth: 1,
        borderColor: '$primaryLightBorder',
        marginVertical: 4,
        borderRadius: 8,
        marginBottom: 15,
    },
    violatorInfoTitleContainer: {
        flex: 6,
    },
    accordionHeading: {
        paddingTop: 5,
    },
    accordionHeadingGray: {
        color: '$primaryLightPlaceholderColor',
    },
    violatorOuter: {
        padding: 5,
    },
    // validatorPressentRowContainer: {
    //     flex: 1,
    //     flexDirection: 'row',
    //     justifyContent: 'space-between',
    //     flex: 1,
    //     borderWidth: '$primaryBorderThin',
    //     borderRadius: 4,
    //     borderColor: '$primaryMediumTextColor',
    //     paddingVertical: 10,
    //     marginVertical: 10,
    //     marginHorizontal: 5,
    // },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        marginLeft: 10,
    },
    buttonWrapper: {
        flex: 1,
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        marginHorizontal: 10,
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryWhite',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    label: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
    },
});
