import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { commonStyles, CustomAccordion } from 'app/components';
import { ViolationItemReview } from '../ViolationItemReview';
import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
export default memo(function(props) {
    const { items, errorLogs } = props;
    renderViolatorsTitle = props => {
        const { items } = props;
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading]}>
                    {strings('complianceSummaryHeading')} ({items ? items.length : 0})
                </Text>
            </View>
        );
    };
    return (
        <View style={styles.violatorCardOuter}>
            <CustomAccordion index="1" renderHeaderTitle={renderViolatorsTitle} items={items} expandedAtStart={true}>
                {items.map((violationItem, idx) => {
                    const { attachments, remarks } = violationItem.item;
                    return (
                        <ViolationItemReview
                            key={idx.toString()}
                            violationItem={violationItem}
                            selectedActionTypeConst="compliance"
                            attachments={attachments}
                            remarks={remarks}
                            errorLogs={errorLogs[violationItem.item.checkItemId]}
                            violationDescription={localeProperty(violationItem.itemDef, 'question')}
                        />
                    );
                })}
                <View style={styles.violatorOuter} />
            </CustomAccordion>
        </View>
    );
});
