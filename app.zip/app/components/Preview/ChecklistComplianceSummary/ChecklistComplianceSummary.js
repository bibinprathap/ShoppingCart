import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import commonStyles from 'app/components/Preview/styles';
import { CustomAccordion } from 'app/components/CustomAccordion';
import { ChecklistQuestionCameraComment } from '../ChecklistQuestionCameraComment';
import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload

class ChecklistComplianceSummary extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    renderViolatorsTitle = props => {
        const { items } = props;
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading]}>
                    {strings('complianceSummaryHeading')} ({items ? items.length : 0})
                </Text>
            </View>
        );
    };

    render() {
        const { items } = this.props;

        return (
            <React.Fragment>
                <View style={styles.violatorCardOuter}>
                    <CustomAccordion index="1" renderHeaderTitle={this.renderViolatorsTitle} items={items} expandedAtStart={false}>
                        {items.map(checklistItem => {
                            const { attachments, remarks } = checklistItem.item;
                            return (
                                <ChecklistQuestionCameraComment
                                    iconClass="verified-user"
                                    iconColor="#008000"
                                    remarks={remarks}
                                    attachments={attachments}
                                    secondLine={localeProperty(checklistItem.itemDef, 'question')}
                                />
                            );
                        })}
                        <View style={styles.violatorOuter} />
                    </CustomAccordion>
                </View>
            </React.Fragment>
        );
    }
}

export default ChecklistComplianceSummary;
