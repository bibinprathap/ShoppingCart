import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, TouchableNativeFeedback, ScrollView, I18nManager } from 'react-native';
import { List, Divider, Button, Text, Card, TouchableRipple, Chip } from 'react-native-paper';
import { withNavigation } from 'react-navigation';
import Icon from 'react-native-vector-icons/MaterialIcons';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import { Badge } from 'app/components/Badge';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import commonStyles from 'app/components/Preview/styles';
import images from 'app/images';
import { InspectionPreview } from 'app/components/Preview/InspectionPreview';
import { setCheckListDuplicate } from 'app/actions/inspections';
import { DuplicateCheckList, DuplicateCheckReview } from 'app/screens/inspection/DuplicateCheck';
import * as Animatable from 'react-native-animatable';
const AnimatableIcon = Animatable.createAnimatableComponent(Icon);
import { ReviewCategory } from 'app/screens/inspection/Review';
import { Attachments } from 'app/screens/attachments';

//Todo: move it to styles.js when screen is complete. its here for hot-reload

class ChecklistQuestionCameraComment extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            remarksViewVisible: false,
            duplicateViewVisible: false,

            modalVisible: false,
            serviceCategory: 'INSPECTION',
            currentInspectionVersion: 0,
            attachmentModalVisible: false,
            selectedAttachmentId: null,
        };
        this.handleViewReview = this.handleViewReview.bind(this);
        this.optionSelectedNo = this.optionSelectedNo.bind(this);
        this.optionSelectedYes = this.optionSelectedYes.bind(this);
    }
    componentDidMount() {
        const { duplicateInspection } = this.props;
        const { inspectionRefNumber } = this.state;
        if (duplicateInspection && duplicateInspection.length > 0 && inspectionRefNumber == undefined) this.handleViewReview(duplicateInspection[0]);
    }
    handleViewReview(item) {
        this.setState({
            selectedDuplicateInspection: item,
            inspectionRefNumber: item.refNumber,
        });
    }

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleAttachmentClosed = () => {
        this.setState({
            attachmentModalVisible: false,
        });
        //if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(attachments);
    };

    handleAttachmentPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };
    handleIconRef = ref => (this.icon = ref);
    handleRemarksPressed = () => {
        this.setState({ remarksViewVisible: !this.state.remarksViewVisible });
    };
    handleDuplicatePressed = () => {
        this.setState({ modalVisible: true, duplicateViewVisible: !this.state.duplicateViewVisible });
        // const { duplicateInspection } = this.props;
        // const { serviceCategory, currentInspectionVersion } = this.state;
        // this.props.navigation.navigate('reviewduplicate', { inspection: duplicateInspection, serviceCategory, currentInspectionVersion });
    };
    optionSelectedNo = () => {
        const { duplicateInspection } = this.props;
        const { inspectionRefNumber } = this.state;
        const inspection = duplicateInspection.find(i => i.refNumber == inspectionRefNumber);
        this.props.dispatch(setCheckListDuplicate({ option: false, inspection }));
    };
    optionSelectedYes = () => {
        // const { inspection } = this.props;
        const { inspectionRefNumber } = this.state;
        const { duplicateInspection } = this.props;
        const inspection = duplicateInspection.find(i => i.refNumber == inspectionRefNumber);
        this.props.dispatch(setCheckListDuplicate({ option: true, inspection }));
    };
    getvalidationsChips(validations) {
        const clips = validations;
        const maxWidth = 380 / clips.length;
        return clips.map(validation => {
            return (
                <Chip
                    mode="flat"
                    // avatar={<Icon name="error" size={20} style={[styles.iconChips, { margin: 0, padding: 0 }]} />}
                    style={styles.selectedSericesClip}
                    textStyle={{ color: '#FFFFFF', margin: 0, padding: 0, maxWidth: maxWidth, textAlign: I18nManager.isRTL ? 'right' : 'left' }}
                >
                    <Text style={commonStyles.ValidationMessageText}>{validation}</Text>
                </Chip>
            );
        });
    }

    render() {
        const {
            editable,
            inspection,
            duplicateInspection,
            attachments,
            remarks,
            question,
            secondLine,
            hasDuplicate,
            iconClass,
            iconColor,
            validations,
        } = this.props;
        const { serviceCategory, currentInspectionVersion } = this.state;
        const attachmentsCount = !!attachments ? attachments.length : 0;
        const remarksCount = !!remarks ? 1 : 0;

        const allRemarks = !!remarks ? remarks : '';
        const { inspectionRefNumber } = this.state;
        if (duplicateInspection && duplicateInspection.length > 0 && inspectionRefNumber == undefined) this.handleViewReview(duplicateInspection[0]);

        const focusedDuplicateInspection = duplicateInspection && duplicateInspection.find(i => i.refNumber == inspectionRefNumber);
        const duplicateContents =
            duplicateInspection &&
            duplicateInspection.map((item, index) => {
                return (
                    <DuplicateCheckList index={index} inspection={focusedDuplicateInspection} item={item} handleViewReview={this.handleViewReview} />
                );
            });
        let isDuplicate = undefined;
        let isDuplicateMessage = undefined;
        let didDuplicateCheck = undefined;
        let checkingDuplicate = inspection && inspection.duplicateCheck && inspection.duplicateCheck.duplicates && inspection.duplicateCheck.checking;
        if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.duplicates != undefined) {
            //check no duplicate button click
            currentDuplicates = inspection.duplicateCheck.duplicates.filter(function(e) {
                return (
                    duplicateInspection.filter(item => item.refNumber + item.lawClausesID == e.refNumber + e.lawClausesID && e.isDuplicate == true)
                        .length > 0
                );
            });
            if (currentDuplicates.length == 0) {
                const notDuplicates = inspection.duplicateCheck.duplicates.filter(function(e) {
                    return duplicateInspection.filter(item => item.lawClausesID == e.lawClausesID && e.isDuplicate == false).length > 0;
                });
                if (notDuplicates.length > 0) {
                    isDuplicateMessage = undefined;
                    isDuplicate = false;
                    didDuplicateCheck = true;
                }
            } else {
                isDuplicateMessage = strings('referenceNumberShort') + ':' + currentDuplicates[0].refNumber + '   ' + strings('isDuplicate');
                if (focusedDuplicateInspection && currentDuplicates[0].refNumber == focusedDuplicateInspection.refNumber) {
                    isDuplicate = true;
                }
                didDuplicateCheck = true;
            }
        }
        let validationStyle = validations && validations.length > 0 ? styles.errorBox : {};
        const validationsChips = validations && validations.length > 0 && validations[0] != ' ' ? this.getvalidationsChips(validations) : null;

        return (
            <React.Fragment>
                <View style={styles.checkListCard}>
                    <Icon name={iconClass} size={25} style={[styles.icon, { color: iconColor }]} />
                    <View style={[styles.CommentsPhotoContainer, validationStyle]}>
                        <View style={styles.container}>
                            <View style={styles.imageAndComments}>
                                {remarksCount > 0 && (
                                    <View style={styles.buttonContainer}>
                                        <TouchableNativeFeedback disabled={remarksCount == 0} onPress={this.handleRemarksPressed}>
                                            <View style={{ flex: 1 }}>
                                                <View style={styles.remarkTickMark}>
                                                    <Icon name="check" color="#ffffff" size={14} style={[styles.remarkTickMarkIcon]} />
                                                </View>

                                                <Icon name="comment" size={34} style={styles.icon} />
                                            </View>
                                        </TouchableNativeFeedback>
                                    </View>
                                )}
                                {(hasDuplicate || checkingDuplicate) && (
                                    <View style={styles.buttonContainer}>
                                        <TouchableNativeFeedback onPress={this.handleDuplicatePressed}>
                                            <View style={{ flex: 1, width: 100, justifyContent: 'flex-end', alignItems: 'flex-start' }}>
                                                {didDuplicateCheck ? (
                                                    <Icon
                                                        name="check"
                                                        color="#008000"
                                                        size={18}
                                                        style={[
                                                            styles.icon,
                                                            { position: 'absolute', top: 10, left: I18nManager.isRTL ? 0 : 5, color: '#008000' },
                                                        ]}
                                                    />
                                                ) : null}
                                                <AnimatableIcon
                                                    ref={this.handleIconRef}
                                                    name={'content-copy'}
                                                    size={34}
                                                    color="#000000"
                                                    animation={
                                                        checkingDuplicate
                                                            ? {
                                                                  0: { rotateY: '0deg' },
                                                                  1: { rotateY: '360deg' },
                                                                  // 0: { rotateY: '0deg', scale: 1 },
                                                                  // 0.5: { rotateY: '180deg', scale: 1.5 },
                                                                  // 1: { rotateY: '360deg', scale: 1 },
                                                              }
                                                            : undefined
                                                    }
                                                    easing="linear"
                                                    iterationCount="infinite"
                                                    useNativeDriver
                                                />
                                            </View>
                                        </TouchableNativeFeedback>
                                        <Modal
                                            animationType="slide"
                                            transparent={false}
                                            visible={this.state.modalVisible}
                                            onRequestClose={() => {
                                                this.setState({ modalVisible: false });
                                            }}
                                        >
                                            <HeaderGeneric
                                                backAction={() => this.setState({ modalVisible: false })}
                                                title={strings('duplicateInspections')}
                                            />
                                            <View style={{ height: 200 }}>
                                                <ScrollView style={{ flex: 1 }}>{duplicateContents}</ScrollView>
                                            </View>
                                            {focusedDuplicateInspection ? (
                                                <DuplicateCheckReview
                                                    editable={editable}
                                                    isDuplicate={isDuplicate}
                                                    isDuplicateMessage={isDuplicateMessage}
                                                    optionSelectedNo={this.optionSelectedNo}
                                                    optionSelectedYes={this.optionSelectedYes}
                                                    inspection={focusedDuplicateInspection}
                                                    serviceCategory={serviceCategory}
                                                />
                                            ) : null}
                                        </Modal>
                                    </View>
                                )}
                            </View>
                            <View style={styles.penaltyAmount}>{question}</View>
                        </View>
                        {this.state.remarksViewVisible ? (
                            <View style={styles.remarkContainer}>
                                <Text style={styles.remarkText}>{'" ' + allRemarks + ' "'}</Text>
                            </View>
                        ) : null}
                        {secondLine ? (
                            <View style={styles.questionContainer}>
                                <Text style={styles.questionText}>{secondLine}</Text>
                            </View>
                        ) : null}
                        {validations && validations.length > 0 && validations[0] != ' ' ? (
                            <View style={styles.chipsCard}>{validationsChips}</View>
                        ) : null}
                        <View style={styles.outerContainerWithAttachment}>
                            {attachmentsCount > 0 && (
                                <>
                                    <Modal
                                        animationType="slide"
                                        transparent={false}
                                        visible={this.state.attachmentModalVisible}
                                        onRequestClose={this.toggleAttachmentDialog}
                                    >
                                        <Attachments
                                            attachments={attachments}
                                            onClose={this.handleAttachmentClosed}
                                            editable={editable}
                                            attachmentModalVisible={this.state.attachmentModalVisible}
                                        />
                                    </Modal>
                                    <AttachmentList
                                        thumbnailSize="small"
                                        thumbnailType="rounded"
                                        style={styles.attachmentContainer}
                                        attachments={attachments}
                                        hideDelete
                                        onPress={this.handleAttachmentPressed}
                                    />
                                </>
                            )}
                        </View>
                    </View>
                </View>
            </React.Fragment>
        );
    }
}

export default withNavigation(ChecklistQuestionCameraComment);
