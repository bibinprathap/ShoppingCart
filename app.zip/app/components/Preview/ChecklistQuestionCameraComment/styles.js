import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextXS',
        alignSelf: 'flex-start',
        marginHorizontal: 0,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    remarkText: {
        flex: 1,
        fontSize: '$primaryTextXS',
        alignSelf: 'flex-start',
        margin: 5,
        color: '#ffffff',
        padding: 5,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    questionContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
    },
    remarkContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        fontWeight: 'bold',
        fontSize: 18,
        backgroundColor: '#a7a9ac',
        color: '#ffffff',
        textAlign: 'center',
        borderRadius: 5,

        elevation: 2,
        marginLeft: 0,
        width: '90%',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: 15,
    },
    icon: {
        alignSelf: 'center',
    },
    duplicateVerified: {
        color: '$primarySelectedTextColor',
        alignSelf: 'center',
    },
    attachmentContainer: {
        marginHorizontal: 0,
    },

    imageAndComments: {
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'flex-start',
        marginLeft: 0,
        flex: 1,
        flexDirection: 'row',
    },
    penaltyAmount: {
        alignItems: 'flex-end',
        marginRight: 10,
    },
    outerContainerWithAttachment: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',

        width: '100%',
    },
    errorBox: { backgroundColor: '$primaryValidationBackGroundColor' },
    CommentsPhotoContainer: {
        // backgroundColor: '#000000',
        flex: 1,
        width: '97%',
        backgroundColor: '$primaryWhite',
        // elevation: 4,
        borderRadius: 8,
        margin: 5,
        padding: 5,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
    },
    reconciliationWrapper: {
        flex: 1,
        margin: 5,
    },
    checkListCard: {
        flex: 1,
        flexDirection: 'row',
    },
    chipsCard: {
        flexDirection: 'row',
    },
    modalContainer: {
        flex: 1,
        minHeight: 55,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    iconChips: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
        marginLeft: 5,
    },
    agrementWrapper: {
        margin: 5,
    },
    horizontalView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    horizontalViewButton: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    button: {
        marginHorizontal: 10,
        marginVertical: 20,
        borderWidth: 0,
        borderRadius: 5,
        backgroundColor: '$primaryLightButtonBackground',
    },
    optionButton: {
        flex: 1,
        //alignSelf: 'center',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    optionButtonSelectedYes: {
        backgroundColor: '$primaryYesButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    optionButtonSelectedNo: {
        backgroundColor: '$primaryNoButtonBackground',
    },
    optionButtonSelected: {
        color: '$primaryWhite',
    },
    refnoContainer: {
        width: '100%',
        paddingLeft: 20,
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        justifyContent: 'flex-start',
        alignItems: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    rowSelected: {
        backgroundColor: '$primarySelectedItem',
    },
    title: {
        alignSelf: 'flex-start',
    },
    descriptionTitle: {
        alignSelf: 'flex-start',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    iconSelected: {
        tintColor: '$primaryWhite',
    },
    listItemDescription: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 12,
    },
    listItemTitle: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 16,
    },
    selectedSericesClip: {
        backgroundColor: '$primaryValidationChipColor',
        color: '$primaryLightTextColor',
        padding: 0,
        margin: 0,
    },
    remarkTickMark: {
        position: 'absolute',
        top: -5,
        right: -3,
        height: 18,
        borderRadius: 9,
        zIndex: 100,
        borderWidth: 1,
        overflow: 'hidden',
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },

    remarkTickMarkIcon: {
        color: '$primaryWhite',
        alignSelf: 'center',
    },
});
