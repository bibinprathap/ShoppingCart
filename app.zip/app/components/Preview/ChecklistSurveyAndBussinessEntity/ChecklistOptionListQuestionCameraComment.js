import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, I18nManager } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import { withNavigation } from 'react-navigation';
import { AttachmentList, commonStyles, Modal } from 'app/components';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { Attachments } from 'app/screens';

class ChecklistOptionListQuestionCameraComment extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            attachmentModalVisible: false,
            selectedAttachment: null,
        };
    }

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleAttachmentClosed = () => {
        this.setState({
            attachmentModalVisible: false,
        });
    };

    handleAttachmentPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };
    getvalidationsChips(errorLogs) {
        const clips = errorLogs;
        const maxWidth = 380 / clips.length;
        return clips.map((validation, idx) => {
            return (
                <Chip
                    key={idx.toString()}
                    mode="flat"
                    style={styles.selectedSericesClip}
                    textStyle={{ color: '#FFFFFF', margin: 0, padding: 0, maxWidth: maxWidth, textAlign: I18nManager.isRTL ? 'right' : 'left' }}
                >
                    <Text style={commonStyles.ValidationMessageText}>{validation}</Text>
                </Chip>
            );
        });
    }

    render() {
        const { editable, attachments, remarks, question, secondLine, errorLogs, selectedOption, selectedCount } = this.props;

        const attachmentsCount = !!attachments ? attachments.length : 0;
        const remarksCount = !!remarks ? 1 : 0;
        const allRemarks = !!remarks ? remarks : '';
        const validationsChips = errorLogs && errorLogs.length > 0 && errorLogs[0] != ' ' ? this.getvalidationsChips(errorLogs) : null;
        const positive = (selectedOption || '').toLowerCase() == 'yes' || selectedOption.toLowerCase() == 'na';
        return (
            <View style={styles.checkListCard}>
                <View style={[styles.CommentsPhotoContainer]}>
                    <View style={styles.container}>
                        <View style={styles.questionAndAnswers}>
                            <View style={styles.optionListanswer}>
                                <Text style={styles.answerText}>{question}</Text>
                            </View>
                            <View style={styles.optionListanswer}>
                                {secondLine ? (
                                    <Text style={styles.answerText}>{secondLine}</Text>
                                ) : (
                                    <Text style={styles.mutedText}>{strings('notSelected')}</Text>
                                )}
                            </View>
                        </View>
                    </View>
                    {remarksCount > 0 && (
                        <View style={styles.remarkContainer}>
                            <Text style={styles.remarkText}>{'" ' + allRemarks + ' "'}</Text>
                        </View>
                    )}
                    {errorLogs && errorLogs.length > 0 && errorLogs[0] != ' ' ? <View style={styles.chipsCard}>{validationsChips}</View> : null}
                    <View style={styles.outerContainerWithAttachment}>
                        {attachmentsCount > 0 && (
                            <>
                                <Modal
                                    animationType="slide"
                                    transparent={false}
                                    visible={this.state.attachmentModalVisible}
                                    onRequestClose={this.toggleAttachmentDialog}
                                >
                                    <Attachments
                                        attachments={attachments}
                                        onClose={this.handleAttachmentClosed}
                                        editable={editable}
                                        attachmentModalVisible={this.state.attachmentModalVisible}
                                    />
                                </Modal>
                                <AttachmentList
                                    thumbnailSize="large"
                                    style={styles.attachmentContainer}
                                    attachments={attachments}
                                    hideDelete
                                    onPress={this.handleAttachmentPressed}
                                />
                            </>
                        )}
                    </View>
                </View>
            </View>
        );
    }
}

export default withNavigation(ChecklistOptionListQuestionCameraComment);
