import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        marginStart: 10,
        //borderWidth: 1
    },
    violationAmount: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    violationHeadingText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
    },
    violationAmountText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primarySelectedTextColor',
    },
    violationAmountContainer: {},
    violationHeadingContainer: {
        flexDirection: 'row',
        flex: 1,
    },
    businessEntityTitle: {
        zIndex: 100,
        color: '$primaryDividerDarkColor',
        fontSize: '$primaryTextXXS',
        fontWeight: 'bold',
    },

    violatorCard: {
        flex: 1,
    },
    violatorCardOuter: {
        flex: 1,

        width: '99%',
        marginVertical: 4,
        borderRadius: 8,
        marginBottom: 15,
    },
    violationSummaryHeadingContainer: {
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: 10,
        flex: 1,
    },
    violationTotalViolationAmountContainer: {
        alignItems: 'flex-end',
        marginRight: 10,
    },
    groupHeading: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        marginLeft: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    accordionHeading: {
        paddingTop: 5,
        marginStart: 10,
    },
    violatorOuter: { flex: 1, padding: 5 },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextXS',
        alignSelf: 'flex-start',
        marginHorizontal: 0,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    remarkText: {
        flex: 1,
        fontSize: '$primaryTextXXS',
        alignSelf: 'flex-start',
        margin: 5,
        color: '#ffffff',
        padding: 5,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    questionContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
    },
    remarkContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        fontWeight: 'bold',
        fontSize: 18,
        backgroundColor: '#a7a9ac',
        color: '#ffffff',
        textAlign: 'center',
        borderRadius: 5,
        marginVertical: 5,
        elevation: 2,

        marginStart: 10,
        width: '98%',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: 15,
    },

    duplicateVerified: {
        color: '$primarySelectedTextColor',
        alignSelf: 'center',
    },
    attachmentContainer: {
        marginHorizontal: 0,
    },

    imageAndComments: {
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: 0,
        flex: 1,
        flexDirection: 'row',
    },
    question: {
        flex: 12,
        alignItems: 'center',
        marginStart: 2,
        justifyContent: 'center',
    },
    answer: {
        flex: 1,
        alignItems: 'center',
        marginRight: 10,
        justifyContent: 'center',
    },
    outerContainerWithAttachment: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        marginVertical: 5,
        width: '100%',
    },
    errorBox: { backgroundColor: '$primaryValidationBackGroundColor' },
    CommentsPhotoContainer: {
        // backgroundColor: '#000000',
        flex: 1,
    },
    reconciliationWrapper: {
        flex: 1,
        margin: 5,
    },
    checkListCard: {
        flex: 1,
        flexDirection: 'row',
    },
    chipsCard: {
        flexDirection: 'row',
    },
    modalContainer: {
        flex: 1,
        minHeight: 55,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    iconChips: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
        marginLeft: 5,
    },
    agrementWrapper: {
        margin: 5,
    },
    horizontalView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    horizontalViewButton: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    button: {
        marginHorizontal: 10,
        marginVertical: 20,
        borderWidth: 0,
        borderRadius: 5,
        backgroundColor: '$primaryLightButtonBackground',
    },

    optionButtonSelectedYes: {
        backgroundColor: '$primaryYesButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    optionButtonSelectedNo: {
        backgroundColor: '$primaryNoButtonBackground',
    },

    refnoContainer: {
        width: '100%',
        paddingLeft: 20,
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        justifyContent: 'flex-start',
        alignItems: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    rowSelected: {
        backgroundColor: '$primarySelectedItem',
    },
    title: {
        alignSelf: 'flex-start',
    },
    descriptionTitle: {
        alignSelf: 'flex-start',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    iconSelected: {
        tintColor: '$primaryWhite',
    },
    listItemDescription: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 12,
    },
    listItemTitle: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 16,
    },
    selectedSericesClip: {
        backgroundColor: '$primaryValidationChipColor',
        color: '$primaryLightTextColor',
        padding: 0,
        margin: 0,
        marginHorizontal: 5,
    },
    remarkTickMark: {
        position: 'absolute',
        top: -5,
        right: -3,
        height: 18,
        borderRadius: 9,
        zIndex: 100,
        borderWidth: 1,
        overflow: 'hidden',
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    remarkTickMarkIcon: {
        color: '$primaryWhite',
        alignSelf: 'center',
    },
    optionButton: {
        flex: 1,
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextXS',
        fontFamily: '$primaryFontNormal',
    },
    optionButtonSelectedYes: {
        color: '$primaryYesButtonBackground',
    },
    optionButtonContainer: {
        flex: 1,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '$primaryDarkIconbuttonBackground',
        marginEnd: 4,
        height: 32,
    },
    optionNotSelected: {
        flex: 2,

        marginEnd: 4,
        height: 32,
    },

    optionButtonSelectedNo: {
        color: '$primaryNoButtonBackground',
    },

    optionButtonSelectedNa: {
        color: '$primaryNotApplicableButtonBackground',
    },
    optionsAndOtherControlsContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    questionAndAnswers: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    checklistSingleItemContainer: {
        flex: 1,
        backgroundColor: '$primaryMediumBackground',
        borderRadius: 5,
        marginVertical: 7,
        marginStart: 7,
        padding: 5,
    },
    optionListanswer: {
        flex: 1,
        alignItems: 'flex-start',
        marginRight: 10,
        marginStart: 5,
        justifyContent: 'center',
    },
    mutedText: {
        fontSize: 12,
        color: '$primaryMediumTextColor',
    },
});
