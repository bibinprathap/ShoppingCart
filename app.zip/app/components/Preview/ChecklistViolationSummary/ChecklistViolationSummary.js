import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { localeProperty, formatCurrency } from 'app/config/i18n/i18n';
import { ChecklistQuestionCameraComment } from '../ChecklistQuestionCameraComment';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload

export default function(props) {
    const { inspection, items, currentInspectionVersion, editable, validations } = props;

    return (
        <View style={styles.violatorCard}>
            {items.map(checklistItem => {
                const { attachments, remarks, violationAmount } = checklistItem.item;
                const { violationTypeId } = checklistItem.lawClause;
                let finalVolationAmount = checklistItem.lawClause
                    ? inspectionsHelper.getViolationAmount({
                          lawClauseIDs: [checklistItem.lawClause.violationTypeId],
                          occurance: 1,
                          discount: 0,
                      })
                    : violationAmount;
                return (
                    <ChecklistQuestionCameraComment
                        editable={editable}
                        iconClass="remove-circle-outline"
                        iconColor="#FF0000"
                        remarks={remarks}
                        duplicateInspection={checklistItem.duplicate}
                        attachments={attachments}
                        validations={validations[violationTypeId]}
                        currentInspectionVersion={currentInspectionVersion}
                        secondLine={localeProperty(checklistItem.lawClause, 'description')}
                        hasDuplicate={checklistItem.duplicate.length > 0}
                        inspection={inspection}
                        dispatch={props.dispatch}
                        question={
                            <View style={styles.violationAmountContainer}>
                                <Text style={styles.violationAmount}>
                                    {/* {(violationAmount || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' ' + 'AED'} */}
                                    {formatCurrency(finalVolationAmount)}
                                </Text>
                            </View>
                        }
                    />
                );
            })}
        </View>
    );
}
