import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { I18nManager, View, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Text, Divider, TouchableRipple } from 'react-native-paper';

import { strings, localeProperty } from 'app/config/i18n/i18n';
import { ChecklistQuestionCameraComment } from '../ChecklistQuestionCameraComment';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload

class ChecklistWarningSummary extends Component {
    static propTypes = {
        items: PropTypes.any,
    };

    render() {
        const { inspection, items, currentInspectionVersion, editable, validations } = this.props;

        return (
            <View style={styles.violatorCard}>
                {items.map(checklistItem => {
                    const { attachments, remarks, selectedPeriod, selectedPeriodType } = checklistItem.item;
                    const { clauseId } = checklistItem.lawClause;
                    return (
                        <ChecklistQuestionCameraComment
                            editable={editable}
                            iconClass="warning"
                            iconColor="#ffc107"
                            remarks={remarks}
                            duplicateInspection={checklistItem.duplicate}
                            inspection={inspection}
                            attachments={attachments}
                            validations={validations[clauseId]}
                            currentInspectionVersion={currentInspectionVersion}
                            secondLine={localeProperty(checklistItem.lawClause, 'description')}
                            hasDuplicate={checklistItem.duplicate.length > 0}
                            inspection={inspection}
                            dispatch={this.props.dispatch}
                            question={
                                <View style={styles.violationAmountContainer}>
                                    <Icon name="access-time" size={25} style={styles.icon} />
                                    {selectedPeriodType == 'day' || selectedPeriodType == 'hour' ? (
                                        <Text style={styles.violationAmount}>{selectedPeriod + ' ' + strings(selectedPeriodType)}</Text>
                                    ) : null}
                                </View>
                            }
                        />
                    );
                })}
            </View>
        );
    }
}

export default ChecklistWarningSummary;
