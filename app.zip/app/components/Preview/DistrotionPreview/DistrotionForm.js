import React from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView } from 'react-native';
import _ from 'lodash';
import { strings } from 'app/config/i18n/i18n';
import { Text, Divider } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { commonStyles, AttachmentList, Modal } from 'app/components';
import { inspectionsHelper } from 'app/api/helperServices';
import { Attachments } from 'app/screens';
//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        // paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    attachmentContainer: {
        marginHorizontal: 10,
    },
    distortionTypeContainer: {
        width: '100%',
        paddingStart: 10,
    },
});

class DistrotionForm extends React.PureComponent {
    static propTypes = {
        inspection: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = { attachmentModalVisible: false, selectedAttachment: null };
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
    }
    getRemarksAndAttachement(inspection, visit, visitIndex) {
        //const generalRemarks = inspection && inspection.info && inspection.info.generalInfo && inspection.info.generalInfo.remarks;
        const currentVisitData = visit;
        const distortionForm = currentVisitData && currentVisitData.distortionForm;
        //const remarks = this.getRemarks(inspection, visit, visitIndex);
        const attachments = (distortionForm || {}).attachmentList;
        const distortionType = (distortionForm || {}).distortionType;
        const agency = (distortionForm || {}).agency;
        const remarks = (distortionForm || {}).remarks;
        const slaLevels = (distortionForm || {}).slaLevels;
        const applicationNumber = (currentVisitData || {}).applicationNumber;

        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;
        const distortionTypeTitle = inspectionsHelper.getDistortionTypeTitle(distortionType, agency);
        const agencyTitle = inspectionsHelper.getAgencyTitle(agency);
        return {
            attachments,
            address,
            remarks,
            distortionType: distortionTypeTitle,
            coords,
            agency: agencyTitle,
            slaLevels,
            applicationNumber,
        };
    }
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: false,
        });
    };
    render() {
        const {
            visit,
            visitIndex,
            refNumber,
            inspection,
            isSubmitable,
            currentInspectionVersion,
            errorLogs,
            thumbnailSize,
            vertical,
            needValidation,
            pendingUploadDocs,
        } = this.props;
        const { attachments, address, distortionType, remarks, coords, agency, slaLevels, applicationNumber } = this.getRemarksAndAttachement(
            inspection,
            visit,
            visitIndex
        );

        if (needValidation)
            inspectionsHelper
                .validateDistrotionDetails({
                    attachments,
                    remarks,
                    address: coords,
                    inspection,
                    distortionType,
                    agency,
                })
                .then(err => {
                    let hasValidationlogs = Object.getOwnPropertyNames(err).length > 0 ? false : true;
                    if (isSubmitable) isSubmitable(hasValidationlogs, err);
                });

        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <View style={styles.distortionTypeContainer}>
                    <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('agency')}</Text>
                    <Text style={[commonStyles.generalText, !agency ? commonStyles.mutedText : null]}>{agency || strings('emptyagencytype')}</Text>
                    {errorLogs.agency ? <Text style={commonStyles.ValidationMessageText}>{strings('emptyAgencyValidation')}</Text> : null}
                </View>
                <Divider style={commonStyles.divider} />
                <View style={styles.distortionTypeContainer}>
                    <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('distortiontype')}</Text>
                    <Text style={[commonStyles.generalText, !distortionType ? commonStyles.mutedText : null]}>
                        {distortionType || strings('emptydistortiontype')}
                    </Text>
                    {errorLogs.distortionType ? (
                        <Text style={commonStyles.ValidationMessageText}>{strings('emptyDistortionTypeValidation')}</Text>
                    ) : null}
                </View>
                <Divider style={commonStyles.divider} />
                {slaLevels ? (
                    <>
                        <View style={styles.distortionTypeContainer}>
                            <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('slaLevels')}</Text>
                            <Text style={[commonStyles.generalText, !slaLevels ? commonStyles.mutedText : null]}>
                                {strings(slaLevels) || strings('emptyagencytype')}
                            </Text>
                        </View>
                        <Divider style={commonStyles.divider} />
                    </>
                ) : null}
                <View style={styles.distortionTypeContainer}>
                    <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('remarks')}</Text>
                    {errorLogs.remarks ? (
                        <Text style={commonStyles.ValidationMessageText}>{errorLogs.remarks}</Text>
                    ) : (
                        <Text style={commonStyles.generalText}>{remarks}</Text>
                    )}
                </View>
                <Divider style={commonStyles.divider} />
                <Text style={[commonStyles.generalHeading, commonStyles.mutedText, styles.attachmentContainer]}>{strings('attachments')}</Text>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.attachmentModalVisible}
                    onRequestClose={this.toggleAttachmentDialog}
                >
                    <Attachments
                        attachments={attachments}
                        selectedAttachment={this.state.selectedAttachment}
                        editable={this.props.editable}
                        onClose={this.toggleAttachmentDialog}
                        attachmentModalVisible={this.state.attachmentModalVisible}
                    />
                </Modal>
                <AttachmentList
                    thumbnailSize={thumbnailSize || ''}
                    vertical={vertical || false}
                    style={styles.attachmentContainer}
                    attachments={attachments}
                    hideDelete
                    onPress={this.handleThumbnailPressed}
                />
                {errorLogs.attachments ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.scrollContainer, { paddingStart: 10 }]}>{errorLogs.attachments}</Text>
                ) : null}
                <Divider style={commonStyles.divider} />
            </ScrollView>
        );
    }
}

export default DistrotionForm;
