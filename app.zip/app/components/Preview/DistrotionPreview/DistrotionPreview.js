import React, { Component } from 'react';
import { View, Text } from 'react-native';
import GeneralPreview from '../GeneralPreview/GeneralPreview';

export default class DistrotionPreview extends Component {
    render() {
        return <GeneralPreview {...this.props}></GeneralPreview>;
    }
}
