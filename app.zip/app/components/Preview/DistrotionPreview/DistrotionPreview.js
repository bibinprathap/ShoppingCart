import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity, Modal } from 'react-native';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import EStyleSheet from 'react-native-extended-stylesheet';
import commonStyles from 'app/components/Preview/styles';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import { inspectionsHelper } from 'app/api/helperServices';
import { Attachments } from 'app/screens/attachments';
//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    attachmentContainer: {
        marginHorizontal: 10,
    },
    distortionTypeContainer: {
        width: '100%',
        paddingStart: 10,
    },
});

class DistrotionPreview extends React.PureComponent {
    static propTypes = {
        inspection: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = { attachmentModalVisible: false, selectedAttachmentId: null };
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
    }
    getRemarksAndAttachement(inspection) {
        const attachments = inspection && inspection.info && inspection.info.distortionForm && inspection.info.distortionForm.attachmentList;
        const distortionType = inspection && inspection.info && inspection.info.distortionForm && inspection.info.distortionForm.distortionType;
        //const generalRemarks = inspection && inspection.info && inspection.info.generalInfo && inspection.info.generalInfo.remarks;
        const generalRemarks = this.getRemarks(inspection);
        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;
        const distortionTypeTitle = inspectionsHelper.getDistortionTypeTitle(distortionType);
        return { attachments, address, generalRemarks, distortionType: distortionTypeTitle, coords };
    }
    handleThumbnailPressed = docId => {
        const { attachments } = this.getRemarksAndAttachement(this.props.inspection);
        this.setState({ attachmentModalVisible: true, selectedAttachmentId: docId });
    };
    validateDuplicates = async (values, errorlogs) => {
        const res = await new Promise((resolve, reject) => {
            const { inspection } = values;
            if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.checking) {
                errorlogs.duplicate = (errorlogs.duplicate || '') + strings('duplicatechecking');
                return reject();
            } else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.error != undefined) {
                return resolve();
            }
            //offline
            else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.duplicateCantidates.length > 0) {
                if (inspection.duplicateCheck.duplicates == undefined) {
                    errorlogs.duplicate =
                        (errorlogs.duplicate || '') +
                        strings('thereare') +
                        `${inspection.duplicateCheck.duplicateCantidates.length} ` +
                        strings('possibleduplicates');
                    return reject();
                } else {
                    return resolve();
                }
            } else {
                return resolve();
            }
        });
    };

    getRemarks = inspection => {
        const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        const currentVisitData = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex] : undefined;
        const generalInfo = currentVisitData && currentVisitData.generalInfo;
        return (generalInfo || {}).remarks;
    };
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: false,
        });
    };
    render() {
        const { inspection, isSubmitable, currentInspectionVersion, distrotionValidationLogs } = this.props;
        const { attachments, address, distortionType, coords } = this.getRemarksAndAttachement(inspection);
        const generalRemarks = this.getRemarks(inspection);

        inspectionsHelper
            .validateDistrotionDetails({ attachments, generalRemarks, address: coords, inspection, distortionType }, this.validateDuplicates)
            .then(err => {
                let hasValidationlogs = Object.getOwnPropertyNames(err).length == 0;
                if (isSubmitable) isSubmitable(hasValidationlogs, err);
            });

        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <RemarkAndAddressPreview generalRemarks={generalRemarks} address={address} coords={coords} validations={distrotionValidationLogs} />
                <Divider style={commonStyles.divider} />
                <View style={styles.distortionTypeContainer}>
                    <Text style={commonStyles.generalHeading}>{strings('distortiontype')}</Text>
                    <Text style={[commonStyles.generalText, !distortionType ? commonStyles.mutedText : null]}>
                        {distortionType || strings('emptydistortiontype')}
                    </Text>
                    {distrotionValidationLogs.distortionType ? (
                        <Text style={commonStyles.ValidationMessageText}>{strings('emptyDistortionTypeValidation')}</Text>
                    ) : null}
                </View>
                <Divider style={commonStyles.divider} />
                <Text style={[commonStyles.generalHeading, styles.attachmentContainer]}>{strings('attachments')}</Text>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.attachmentModalVisible}
                    onRequestClose={this.toggleAttachmentDialog}
                >
                    <Attachments
                        attachments={attachments}
                        selectedAttachmentId={this.state.selectedAttachmentId}
                        editable={this.props.editable}
                        onClose={this.toggleAttachmentDialog}
                        attachmentModalVisible={this.state.attachmentModalVisible}
                    />
                </Modal>
                <AttachmentList style={styles.attachmentContainer} attachments={attachments} hideDelete onPress={this.handleThumbnailPressed} />
                {distrotionValidationLogs.attachments ? (
                    <Text
                        style={[
                            commonStyles.generalText,
                            styles.attachmentContainer,
                            distrotionValidationLogs.attachments ? commonStyles.mutedText : null,
                        ]}
                    >
                        {strings('emptyAttachement')}
                    </Text>
                ) : null}
                {distrotionValidationLogs.attachments ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.scrollContainer]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}
                <Divider style={commonStyles.divider} />
                {distrotionValidationLogs.duplicate ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.scrollContainer]}>{distrotionValidationLogs.duplicate}</Text>
                ) : null}
            </ScrollView>
        );
    }
}

export default DistrotionPreview;
