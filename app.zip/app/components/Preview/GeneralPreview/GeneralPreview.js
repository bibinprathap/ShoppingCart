import React, { Component } from 'react';
import { View, ScrollView } from 'react-native';
import { _ } from 'lodash';
import { StatusChip } from 'app/components';
import commonStyles from 'app/components/Preview/styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { withNavigation, NavigationActions } from 'react-navigation';
import { inspectionsHelper } from 'app/api/helperServices';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import { ChecklistComplianceSummary } from 'app/components/Preview/ChecklistComplianceSummary';
import {
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    ResUnitOccupancyForm,
    FoodTruckAndOutdoor,
    FoodTruckAndOutdoorFollowUp,
    GeneralInfoForm,
    DynamicForm,
    ViolationsFollowup,
    EngineerReviewApproved,
    BuildingPenaltCheckItemPreview,
    MoreInfoForm,
    ResUnitOccupancyWarrantApprovedForm,
    FollowupForm,
    SiteVisit,
    NoisePollution,
} from 'app/components/Form';
import { CheckListViolator } from 'app/components/Preview/CheckListViolator';
import { ViolationUnAssignedSummary } from 'app/components/Preview/ViolationUnAssignedSummary';
import { ChecklistSurveyAndBussinessEntity } from 'app/components/Preview/ChecklistSurveyAndBussinessEntity';

import DistrotionForm from './../DistrotionPreview/DistrotionForm';
import { Text, Divider } from 'react-native-paper';
import styles from './styles';
import { CommonMessageAndSteps } from '../CommonMessageAndSteps';

class GeneralPreview extends Component {
    constructor(props) {
        super(props);
        this.getrenderedReadonlyForms = this.getrenderedReadonlyForms.bind(this);
    }
    focusListener;

    handleFocus = () => {
        const { visit } = this.props;
        if (!(visit && visit.def)) {
            this.props.navigation.dispatch(NavigationActions.back());
        }
    };

    componentDidMount() {
        this.focusListener = this.props.navigation.addListener('didFocus', this.handleFocus);
        this.handleFocus();
    }

    componentWillUnmount() {
        this.focusListener.remove();
    }

    getrenderedReadonlyForms = ({
        currentVisitData,
        errorLogs,
        visitIndex,
        inspection,
        isSubmitable,
        needValidation,
        dataLookups,
        currentInspectionVersion,
        pendingUploadDocs,
    }) => {
        // /* RJ: temp code start - readonly AppForm */
        const renderedReadonlyForms = [];
        let renderedReadonlyForm = undefined;
        if (currentVisitData.def.type == 'form') {
            currentVisitData.def.def.map((form, index) => {
                const values = form.scope == 'visit' ? currentVisitData[form.name] : inspection.info && inspection.info[form.name];
                if (form.showInPreview === false) {
                } else {
                    if (form.formType == 'fixed') {
                        //get fixed form in readOnly mode
                        switch (form.name) {
                            case 'abandonedVehicleInfo':
                                const { impoundVehicleYardIdRequired } = inspectionsHelper.getVehicleYardState({
                                    inspection: inspection,
                                });
                                if (values) values.impoundVehicleYardIdRequired = impoundVehicleYardIdRequired;
                                renderedReadonlyForm = (
                                    <AbandonedVehicleForm
                                        visitIndex={visitIndex}
                                        inspection={inspection}
                                        readOnly={true}
                                        errorLogs={errorLogs || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        needValidation={needValidation}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'resUnitOccupancySuspicion':
                                renderedReadonlyForm = (
                                    <ResUnitOccupancyForm
                                        readOnly={true}
                                        errorLogs={errorLogs[form.name] || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'foodTruckAndOutdoorSeating':
                                renderedReadonlyForm = (
                                    <FoodTruckAndOutdoor
                                        readOnly={true}
                                        errorLogs={errorLogs[form.name] || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        inspection={inspection}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'foodTruckAndOutdoorSeatingFollowUp':
                                const foodTruckinitialValue =
                                    inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                renderedReadonlyForm = (
                                    <FoodTruckAndOutdoorFollowUp
                                        readOnly={true}
                                        errorLogs={errorLogs[form.name] || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        inspection={inspection}
                                        isSubmitable={isSubmitable}
                                        initialValue={foodTruckinitialValue}
                                    />
                                );
                                break;
                            case 'noisePollution':
                                renderedReadonlyForm = (
                                    <NoisePollution
                                        readOnly={true}
                                        errorLogs={errorLogs[form.name] || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        inspection={inspection}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;

                            case 'generalInfo':
                                renderedReadonlyForm = (
                                    <GeneralInfoForm
                                        readOnly={true}
                                        errorLogs={errorLogs || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'distortionForm':
                                renderedReadonlyForm = (
                                    <DistrotionForm
                                        readOnly={true}
                                        inspection={inspection}
                                        visit={currentVisitData}
                                        visitIndex={visitIndex}
                                        needValidation={needValidation}
                                        isSubmitable={isSubmitable}
                                        currentInspectionVersion={currentInspectionVersion}
                                        formName={'form_' + form.name + '_' + index}
                                        errorLogs={errorLogs || {}}
                                        values={values}
                                        pendingUploadDocs={pendingUploadDocs}
                                    />
                                );
                                break;
                            case 'generalAppearanceVehicleInfo':
                                renderedReadonlyForm = (
                                    <GeneralAppearanceVehicleForm
                                        visitIndex={visitIndex}
                                        inspection={inspection}
                                        readOnly={true}
                                        errorLogs={errorLogs || {}}
                                        formName={'form_' + form.name + '_' + index}
                                        values={values}
                                        needValidation={needValidation}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'moreInfoFollowup':
                                const moreInfoinitialValue = inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                renderedReadonlyForm = (
                                    <MoreInfoForm
                                        visitIndex={visitIndex}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        initialValue={moreInfoinitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'resUnitOccupancyWarrantApproved':
                                const resUnitOccupancyinitialValue =
                                    inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                renderedReadonlyForm = (
                                    <ResUnitOccupancyWarrantApprovedForm
                                        visitIndex={visitIndex}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        initialValue={resUnitOccupancyinitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'distrotionFollowup':
                                const distrotioninitialValue =
                                    inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                renderedReadonlyForm = (
                                    <FollowupForm
                                        visitIndex={visitIndex}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        initialValue={distrotioninitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'abandonedVehiclesFollowup':
                                const initialValue = inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                const actionTypeOptions = (initialValue && initialValue.violationActionTypes) || [];

                                renderedReadonlyForm = (
                                    <ViolationsFollowup
                                        yardOptions={dataLookups ? dataLookups.vehicleYard : []}
                                        visitIndex={visitIndex}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        actionTypeOptions={actionTypeOptions}
                                        initialValue={initialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'buildingPenaltyFollowup':
                            case 'generalAppearanceVehicleInfo':
                                const buildingPenaltyInitialValue =
                                    inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                const buildingPenaltyactionTypeOptions =
                                    (buildingPenaltyInitialValue && buildingPenaltyInitialValue.violationActionTypes) || [];
                                renderedReadonlyForm = (
                                    <ViolationsFollowup
                                        visitIndex={visitIndex}
                                        hideYard={true}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        actionTypeOptions={buildingPenaltyactionTypeOptions}
                                        initialValue={buildingPenaltyInitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            // case 'buildingPenaltyFollowup':
                            case 'engApprovalFollowup':
                                const engApprovalFollowupInitialValue =
                                    inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                                const engApprovalFollowupactionTypeOptions =
                                    (engApprovalFollowupInitialValue && engApprovalFollowupInitialValue.violationActionTypes) || [];
                                renderedReadonlyForm = (
                                    <EngineerReviewApproved
                                        visitIndex={visitIndex}
                                        hideYard={true}
                                        readOnly={true}
                                        editable={false}
                                        dispatch={() => {}}
                                        inspection={inspection}
                                        actionTypeOptions={engApprovalFollowupactionTypeOptions}
                                        initialValue={engApprovalFollowupInitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'buildingPenaltCheckItemPreview':
                                const buildingPenaltiesFormInitialValue =
                                    inspection.visits[visitIndex].buildingPenaltiesForm && inspection.visits[visitIndex].buildingPenaltiesForm;
                                const buildingPenaltiesFormactionTypeOptions =
                                    (buildingPenaltiesFormInitialValue && buildingPenaltiesFormInitialValue.violationActionTypes) || [];
                                renderedReadonlyForm = (
                                    <BuildingPenaltCheckItemPreview
                                        visitIndex={visitIndex}
                                        hideYard={true}
                                        readOnly={true}
                                        editable={false}
                                        dispatch={() => {}}
                                        inspection={inspection}
                                        actionTypeOptions={buildingPenaltiesFormactionTypeOptions}
                                        initialValue={buildingPenaltiesFormInitialValue}
                                        violator={{}}
                                        violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                        isSubmitable={isSubmitable}
                                    />
                                );
                                break;
                            case 'siteVisit':
                                const siteVisitInitialValues = inspection.visits[visitIndex].siteVisit;
                                renderedReadonlyForm = (
                                    <SiteVisit
                                        visitIndex={visitIndex}
                                        readOnly={true}
                                        editable={false}
                                        inspection={inspection}
                                        initialValue={siteVisitInitialValues}
                                        needValidation={needValidation}
                                        isSubmitable={isSubmitable}
                                        // violator={{}}
                                        // violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                    />
                                );
                                break;
                            default:
                                renderedReadonlyForm = (
                                    <View>
                                        <Text>unsupported form {form.name} </Text>
                                    </View>
                                );
                                break;
                        }
                    } else {
                        renderedReadonlyForm = (
                            <DynamicForm
                                readOnly={true}
                                formDef={{ ...form, editable: false }}
                                errorLogs={errorLogs[form.name] || {}}
                                formName={'form_' + form.name + '_' + index}
                                values={values}
                                initialValues={values}
                                formProps={{}}
                                isSubmitable={isSubmitable}
                            />
                        );
                    }

                    renderedReadonlyForms.push(
                        <View style={styles.remarksContainer} key={'inspection_form_' + index}>
                            <Text style={[commonStyles.generalHeading, { paddingStart: 10 }]}>
                                {inspectionsHelper.getGeneralPreviewFormTitle(form)}
                            </Text>
                            {renderedReadonlyForm}
                            {errorLogs.noviolatorAdded ? (
                                <Text style={[commonStyles.ValidationMessageText, styles.violationSummaryHeadingContainer]}>
                                    {errorLogs.noviolatorAdded}
                                </Text>
                            ) : null}
                        </View>
                    );
                }
            });
        }

        return renderedReadonlyForms;
    };

    render() {
        if (!(this.props.visit && this.props.visit.def)) {
            return (
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <Text>{strings('noInspectionTypeSelected')}</Text>
                </View>
            );
        }

        const {
            visit,
            visitIndex,
            inspection,
            errorLogs = {},
            isSubmitable,
            needValidation,
            dispatch,
            unAssignedViolationTypes,
            violatorsAndViolations,
            complianceItems,
            dataLookups,
            currentInspectionVersion,
            pendingUploadDocs,
            serveyItems,
            currentViolator,
            isSurveyFromADM,
        } = this.props;
        const currentVisitData = visit;
        const generalInfo = currentVisitData && currentVisitData.generalInfo;
        const generalRemarks = (generalInfo || { remarks: '.' }).remarks;
        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;

        const renderedReadonlyForms = this.getrenderedReadonlyForms({
            currentVisitData,
            errorLogs,
            visitIndex,
            inspection,
            isSubmitable,
            needValidation,
            dataLookups,
            currentInspectionVersion,
            pendingUploadDocs,
        });
        const checkListViolators = [];
        const violators = (inspection.violators || []).filter(
            v => currentVisitData && currentVisitData.values && currentVisitData.values.find(va => va.violatorId == v.violatorId)
        );
        if (violatorsAndViolations && violatorsAndViolations.length > 0) {
            {
                violators.map((vl, idx) => {
                    const violatorObj = violatorsAndViolations.find(v => v.violatordetails && v.violatordetails.idNumber == vl.idNumber);
                    if (violatorObj) {
                        checkListViolators.push(
                            <CheckListViolator
                                key={idx.toString()}
                                enablePrint={false}
                                editable={false}
                                inspection={inspection}
                                dispatch={dispatch}
                                errorLogs={errorLogs[violatorObj.violatordetails.violatorId] || {}}
                                {...violatorObj}
                            />
                        );
                    }
                });
            }
        }

        //const applicationNumber = currentVisitData.workflowApplicationNumber || currentVisitData.applicationNumber;
        const applicationNumber = inspection.visits[0].applicationNumber;
        //if there are any awareness, warning or violation item, they have their own IssueNumber, the heade issuenumber in that case is not used anywhere
        let issueNumber = inspection.visits[0].workflowApplicationNumber;
        if (violatorsAndViolations && violatorsAndViolations.length > 0) {
            if (violatorsAndViolations.length == 1) {
                const itemWithIssueNumber = _.find(inspection.visits[0].values, item => {
                    if (item.workflowApplicationNumber == issueNumber) return item;
                });
                if (!itemWithIssueNumber) {
                    /*
                        if the single values item (issue) has a different issue number than the first visit issue number
                        then don't show the issue number at the header level as it has no meaning for the inspector or violator.
                        This happens in building penalties and general appearance
                    */
                    issueNumber = undefined;
                }
            } else {
                //if there are more than one values items, then it building penalties and general appearance case, header level issue number has no meaning
                issueNumber = undefined;
            }
        }

        let applicationAndIssuNumberHeader =
            applicationNumber || issueNumber ? (
                <>
                    <View
                        style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginHorizontal: 5,
                            marginVertical: 10,
                        }}
                    >
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-start' }}>
                            <Text style={[commonStyles.generalHeading, commonStyles.mutedText, { textAlign: 'left' }]}>
                                {strings('applicationNumber')}
                            </Text>
                            <Text
                                style={[
                                    commonStyles.generalText,
                                    !applicationNumber ? commonStyles.mutedText : null,
                                    { textAlign: 'left', marginStart: 5 },
                                ]}
                            >
                                {applicationNumber || strings('notAvailable')}
                            </Text>
                        </View>
                        <View>
                            <StatusChip
                                statusConst={inspection.inspectionStatusConst}
                                translatedStatus={localeProperty(inspection, 'inspectionStatus')}
                            />
                        </View>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'flex-end' }}>
                            <Text style={[commonStyles.generalHeading, commonStyles.mutedText, { textAlign: 'right' }]}>
                                {strings('issueNumber')}
                            </Text>
                            <Text style={[commonStyles.generalText, !issueNumber ? commonStyles.mutedText : null, { textAlign: 'right' }]}>
                                {issueNumber || strings('notAvailable')}
                            </Text>
                        </View>
                    </View>
                    {/* <Divider style={commonStyles.divider} /> */}
                </>
            ) : null;

        return (
            <View style={{ flex: 1 }}>
                {applicationAndIssuNumberHeader}
                <ScrollView style={{ flex: 1 }}>
                    {renderedReadonlyForms.map(k => (
                        <View key={k.key}>{k}</View>
                    ))}
                    {checkListViolators.map(k => (
                        <View key={k.key}>{k}</View>
                    ))}
                    {unAssignedViolationTypes && unAssignedViolationTypes.length > 0 && (
                        <ViolationUnAssignedSummary items={unAssignedViolationTypes} errorLogs={errorLogs} />
                    )}
                    {complianceItems && complianceItems.length > 0 && (
                        <>
                            <ChecklistComplianceSummary items={complianceItems} errorLogs={errorLogs} />
                            <Divider style={commonStyles.divider} />
                        </>
                    )}
                    {serveyItems && serveyItems.length > 0 && (
                        <>
                            <ChecklistSurveyAndBussinessEntity
                                violator={currentViolator}
                                errorLogs={errorLogs}
                                items={serveyItems}
                                def={visit.def}
                                // isSurveyFromADM={isSurveyFromADM}
                            />
                            <Divider style={commonStyles.divider} />
                        </>
                    )}

                    <RemarkAndAddressPreview
                        generalRemarks={generalRemarks}
                        address={address}
                        coords={coords}
                        errorLogs={errorLogs}
                        hideRemark={true}
                        headingmuted={true}
                    />
                    <CommonMessageAndSteps errorLogs={errorLogs} visit={visit} />
                </ScrollView>
            </View>
        );
    }
}
export default withNavigation(GeneralPreview);
