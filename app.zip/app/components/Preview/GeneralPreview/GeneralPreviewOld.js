import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity, I18nManager } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import * as yup from 'yup';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import { ViolationUnAssignedSummary } from 'app/components/Preview/ViolationUnAssignedSummary';
import {
    IndividualInfoForm,
    CompanyInfoForm,
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    ResUnitOccupancyForm,
    GeneralInfoForm,
    DynamicForm,
    ViolationsFollowup,
} from 'app/components/Form';
import BuildingInfoConfigTemplate from 'app/components/Form/CommonForms/BuildingInfo/config';
import IndividualInfoConfigTemplate from 'app/components/Form/CommonForms/IndividualInfo/config';
import AbandonedVehicleConfig from 'app/components/Form/CommonForms/AbandonedVehicle/config';
import GeneralAppearanceVehicleConfig from 'app/components/Form/CommonForms/GeneralAppearanceVehicle/config';
import CompanyInfoConfigTemplate from 'app/components/Form/CommonForms/CompanyInfo/config';
import { ValidationHelper } from 'app/api/helperServices';
import { CheckListViolator } from 'app/components/Preview/CheckListViolator';
import ResUnitOccupancyConfig from 'app/components/Form/CommonForms/ResUnitOccupancy/config';
import SimpleViolatorInfo from 'app/components/Violator/SimpleViolatorInfo';
import commonStyles from 'app/components/Preview/styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    bulletcolumn: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        flex: 1,
    },
    bulletrow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        flex: 1,
    },
    bullet: {
        width: 10,
    },
    bulletText: {
        flex: 1,
    },
    boldText: {
        fontWeight: 'bold',
    },
    normalText: {},
    violationSummaryHeadingContainer: {
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: 10,
        flex: 1,
    },
    applicationNoContainer: {
        width: '100%',
        paddingStart: 10,
    },
});

export default memo(function(props) {
    getValidationShape = ConfigTemplate => {
        const validationSchemaShape = {};
        ConfigTemplate.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            }
        });
        return validationSchemaShape;
    };

    validateViolators = (violators, errorlogs, violatorItems, duplicateCandidates, duplicates) => {
        if (violators.length == 0) {
            errorlogs.noviolatorAdded = strings('noViolatorAdded');
            return Promise.all([errorlogs]);
        }
        const results = violators.map(async (violator, index) => {
            const validationSchemaShape = {};
            const violatordetails = violatorItems.find(d => d.violatordetails.idNumber == violator.idNumber);
            if (violatordetails) {
                if (
                    violatordetails.awarenessItems.length == 0 &&
                    violatordetails.warningItems.length == 0 &&
                    violatordetails.violationItems.length == 0
                )
                    errorlogs[violator.idNumber] = { noViolations: strings('noViolationForthisViolator') };
            }
            if (violator.violations) {
                violator.violations.map(law => {
                    const posibleDuplicates = duplicateCandidates.filter(d => d.lawClausesID == law);
                    if (posibleDuplicates.length > 0 && duplicates) {
                        let currentDuplicates = duplicates.filter(item => item.lawClausesID == law);
                        if (currentDuplicates.length == 0) {
                            if (errorlogs[violator.idNumber]) {
                                if (!errorlogs[law])
                                    errorlogs[law] = [strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates')];
                                else errorlogs[law].push(strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates'));
                            } else {
                                errorlogs[violator.idNumber] = {
                                    [law]: [strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates')],
                                };
                            }
                        }
                    }
                });
            }

            switch (violator.violatorType) {
                case 'company':
                    const companyValidationSchema = yup.object().shape(this.getValidationShape(CompanyInfoConfigTemplate));

                    try {
                        await ValidationHelper.validate(violator.company, companyValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].company = errors;
                        else errorlogs[violator.idNumber] = { company: errors };

                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }

                    const companyIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.ticketRecipient, companyIndividualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].companyIndividual = errors;
                        else errorlogs[violator.idNumber] = { companyIndividual: errors };

                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    break;
                case 'building':
                    const buildingValidationSchema = yup.object().shape(this.getValidationShape(BuildingInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.building, buildingValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].building = errors;
                        else errorlogs[violator.idNumber] = { building: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }

                    const buildingIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.ticketRecipient, buildingIndividualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].buildingIndividual = errors;
                        else errorlogs[violator.idNumber] = { buildingIndividual: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    break;
                case 'individual':
                    const individualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.violator, individualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].individual = errors;
                        else errorlogs[violator.idNumber] = { individual: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    if (violator.ticketRecipient) {
                        const ticketRecipientValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                        try {
                            await ValidationHelper.validate(violator.ticketRecipient, ticketRecipientValidationSchema);
                        } catch (errors) {
                            if (errorlogs[violator.idNumber]) errorlogs[violator.idNumber].ticketRecipient = errors;
                            else errorlogs[violator.idNumber] = { ticketRecipient: errors };
                            // Object.getOwnPropertyNames(errors).map(er => {
                            //     errorlogs[er] = errors[er];
                            // });
                        }
                    }
                    break;
                default:
                    break;
            }
            return errorlogs;
        });

        return Promise.all(results);
    };

    validateInspection = async (values, errorlogs) => {
        const res = await new Promise((resolve, reject) => {
            const { inspection, unAssignedItems, currentVisitIndex, currentVisitData } = values;
            const selectedVisitIndex = currentVisitIndex;
            //inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def.def;
            let duplicateCandidates = [];
            let violators = [];
            let duplicates = [];
            if (inspection && inspection.duplicateCheck) {
                duplicateCandidates = inspection.duplicateCheck.duplicateCandidates;
                duplicates = inspection.duplicateCheck.duplicates || [];
            }
            //  const currentVisitData = unAssignedItems;
            //  let unAssignedViolationTypes = [];
            debugger;
            if (currentVisitData && currentVisitData.values.length > 0) {
                // currentVisitData.values.forEach(item => {
                //     if (!item.violatorId) unAssignedViolationTypes.push(item);
                // });

                if (unAssignedItems.length > 0) {
                    errorlogs.unAssignedItems = strings('thereis') + unAssignedItems.length + ' ' + strings('unAssignedItems');
                }
            }

            if (currentVisitData.def.type == 'form') {
                currentVisitData.def.def.map(async (form, index) => {
                    let values = {};
                    if (form.scope == 'visit') {
                        values = inspection.visits[currentVisitIndex || 0][form.name];
                    } else if (inspection.info) {
                        values = inspection.info[form.name];
                    }
                    if (form.formType == 'fixed') {
                        //get fixed form in readOnly mode
                        switch (form.name) {
                            case 'abandonedVehicleInfo':
                                const abandonedVehicleValidationSchema = yup.object().shape(this.getValidationShape(AbandonedVehicleConfig));
                                try {
                                    await ValidationHelper.validate(values, abandonedVehicleValidationSchema);
                                    return resolve();
                                } catch (errors) {
                                    errorlogs[form.name] = errors;
                                    return resolve();
                                    // Object.getOwnPropertyNames(errors).map(er => {
                                    //     errorlogs[er] = errors[er];
                                    // });
                                }
                                break;
                            case 'generalAppearanceVehicleInfo':
                                const generalAppearanceVehicleValidationSchema = yup
                                    .object()
                                    .shape(this.getValidationShape(GeneralAppearanceVehicleConfig));
                                try {
                                    await ValidationHelper.validate(values, generalAppearanceVehicleValidationSchema);
                                    return resolve();
                                } catch (errors) {
                                    errorlogs[form.name] = errors;
                                    return resolve();
                                    // Object.getOwnPropertyNames(errors).map(er => {
                                    //     errorlogs[er] = errors[er];
                                    // });
                                }
                                break;
                            case 'ResUnitOccupancyInfo':
                                const ResUnitOccupancySchema = yup.object().shape(this.getValidationShape(ResUnitOccupancyConfig));
                                try {
                                    await ValidationHelper.validate(values, ResUnitOccupancySchema);
                                    return resolve();
                                } catch (errors) {
                                    errorlogs[form.name] = errors;
                                    return resolve();
                                    // Object.getOwnPropertyNames(errors).map(er => {
                                    //     errorlogs[er] = errors[er];
                                    // });
                                }
                                break;

                            default:
                                break;
                        }
                        if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.checking) {
                            errorlogs.duplicate = (errorlogs.duplicate || '') + strings('duplicatechecking');
                            return reject();
                        } else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.error != undefined) {
                            return resolve();
                        } else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.duplicateCandidates.length > 0) {
                            if (inspection.duplicateCheck.duplicates == undefined) {
                                errorlogs.duplicate =
                                    (errorlogs.duplicate || '') +
                                    strings('thereare') +
                                    `${inspection.duplicateCheck.duplicateCandidates.length} ` +
                                    strings('possibleduplicates');
                                return reject();
                            } else {
                                return resolve();
                            }
                        }

                        //  return resolve();
                    }
                });
            } else {
                return resolve();
            }
        });
    };

    const {
        visit,
        visitIndex,
        inspection,
        isSubmitable,
        currentInspectionVersion,
        editable,
        inspectionValidationLogs,
        selectedService,
        visitindex,
        dataLookups,
    } = props;
    // let allAssignedViolators = [];
    let currentVisitIndex = visitIndex;
    const currentVisitData = visit;
    const generalInfo = currentVisitData && currentVisitData.generalInfo;
    const generalRemarks = (generalInfo || { remarks: '.' }).remarks;
    const address = inspection && inspection.location && inspection.location.address;
    const coords = inspection && inspection.location && inspection.location.coords;
    const violators = inspection.violators || [];
    const duplicateCandidates = (inspection.duplicateCheck && inspection.duplicateCheck.duplicateCandidates) || [];

    //inspection->visit
    const { violatorItems } =
        inspectionsHelper.classifyAwarenessViolationWarningItems({
            visit,
            inspectionDef: currentVisitData.def,
            violators,
            duplicateCandidates,
        }) || {};

    // const { violatorItems } =
    //     inspectionsHelper.classifyAwarenessViolationWarningItems({
    //         inspection,
    //         inspectionDef: currentVisitData.def,
    //         violators,
    //         duplicateCandidates,
    //     }) || {};

    //console.log('checking Validators... violatorType:', selectedService.violatorType, 'selectedService: ', selectedService);
    //
    // const assginedViolators = inspectionsHelper.getAssignedViolators({ violators: inspection.violators || [], visit });
    // if (assginedViolators) {
    //     Object.keys(assginedViolators).forEach(violationId => {
    //         allAssignedViolators.push(
    //             <SimpleViolatorInfo key={assginedViolators[violationId].violatorId} violator={assginedViolators[violationId]} editable={false} />
    //         );
    //     });
    // }

    inspectionsHelper
        .validateInspectionDetails(
            { generalRemarks, address: coords, inspection, currentVisitIndex, unAssignedItems: currentVisitData },
            this.validateInspection
        )
        .then(err => {
            let violators = [];
            if (inspection.violators) violators = inspection.violators;
            // console.log(err);
            let duplicateCandidates = [];
            let duplicates = [];
            if (inspection && inspection.duplicateCheck) {
                duplicateCandidates = inspection.duplicateCheck.duplicateCandidates;
                duplicates = inspection.duplicateCheck.duplicates || [];
            }

            if (!!selectedService.violatorType) {
                if (isSubmitable) isSubmitable(Object.keys(err).length === 0 ? true : false, err);

                // this.validateViolators(violators, err, violatorItems, duplicateCandidates, duplicates).then(verr => {
                //     let finalerrorlog = {};
                //     if (verr.length > 0) {
                //         finalerrorlog = verr[0];
                //     }

                //     let hasValidationlogs = Object.getOwnPropertyNames(finalerrorlog).length == 0;
                //     if (isSubmitable) isSubmitable(hasValidationlogs, finalerrorlog);
                // });
            } else {
                let hasValidationlogs = Object.getOwnPropertyNames(err).length == 0;
                if (isSubmitable) isSubmitable(hasValidationlogs, err);
            }
        });
    // /* RJ: temp code start - readonly AppForm */
    const renderedReadonlyForms = [];
    let renderedReadonlyForm = undefined;
    debugger;
    if (currentVisitData.def.type == 'form') {
        currentVisitData.def.def.map((form, index) => {
            const values = form.scope == 'visit' ? currentVisitData[form.name] : inspection.info && inspection.info[form.name];
            if (form.showInPreview === false) {
            } else {
                if (form.formType == 'fixed') {
                    //get fixed form in readOnly mode
                    switch (form.name) {
                        case 'abandonedVehicleInfo':
                            renderedReadonlyForm = (
                                <AbandonedVehicleForm
                                    readOnly={true}
                                    errorLogs={inspectionValidationLogs[form.name] || {}}
                                    formName={'form_' + form.name + '_' + index}
                                    values={values}
                                />
                            );
                            break;
                        case 'ResUnitOccupancyInfo':
                            renderedReadonlyForm = (
                                <ResUnitOccupancyForm
                                    readOnly={true}
                                    errorLogs={inspectionValidationLogs[form.name] || {}}
                                    formName={'form_' + form.name + '_' + index}
                                    values={values}
                                />
                            );
                            break;
                        case 'generalInfo':
                            renderedReadonlyForm = (
                                <GeneralInfoForm
                                    readOnly={true}
                                    errorLogs={inspectionValidationLogs[form.name] || {}}
                                    formName={'form_' + form.name + '_' + index}
                                    values={values}
                                />
                            );
                            break;
                        case 'generalAppearanceVehicleInfo':
                            renderedReadonlyForm = (
                                <GeneralAppearanceVehicleForm
                                    readOnly={true}
                                    errorLogs={inspectionValidationLogs[form.name] || {}}
                                    formName={'form_' + form.name + '_' + index}
                                    values={values}
                                />
                            );
                            break;
                        case 'abandonedVehiclesFollowup':
                            debugger;
                            const initialValue = inspection.visits[visitIndex].followupForm && inspection.visits[visitIndex].followupForm;
                            const actionTypeOptions = (initialValue && initialValue.violationActionTypes) || [];

                            renderedReadonlyForm = (
                                <ViolationsFollowup
                                    yardOptions={dataLookups.vehicleYard}
                                    visitIndex={visitIndex}
                                    readOnly={true}
                                    editable={false}
                                    inspection={inspection}
                                    actionTypeOptions={actionTypeOptions}
                                    initialValue={initialValue}
                                    violator={{}}
                                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                                />
                            );
                            break;
                        default:
                            renderedReadonlyForm = (
                                <View>
                                    <Text>unsupported form {form.name} </Text>
                                </View>
                            );
                            break;
                    }
                } else {
                    // console.log('herererere: ', form.name);
                    renderedReadonlyForm = (
                        <DynamicForm
                            readOnly={true}
                            formDef={{ ...form, editable: false }}
                            errorLogs={inspectionValidationLogs[form.name] || {}}
                            formName={'form_' + form.name + '_' + index}
                            values={values}
                            initialValues={values}
                            formProps={{}}
                        />
                    );
                }

                renderedReadonlyForms.push(
                    <View style={styles.remarksContainer} key={'inspection_form_' + index}>
                        <Text style={[commonStyles.generalHeading, { paddingStart: 10 }]}>{inspectionsHelper.getGeneralPreviewFormTitle(form)}</Text>
                        {renderedReadonlyForm}
                        {inspectionValidationLogs.noviolatorAdded ? (
                            <Text style={[commonStyles.ValidationMessageText, styles.violationSummaryHeadingContainer]}>
                                {inspectionValidationLogs.noviolatorAdded}
                            </Text>
                        ) : null}
                    </View>
                );
            }
        });
    }

    if (violatorItems && violatorItems.length > 0) {
        {
            violatorItems.map(v => {
                renderedReadonlyForms.push(
                    <CheckListViolator
                        enablePrint={!editable}
                        editable={editable}
                        dispatch={props.dispatch}
                        printReceipt={props.printReceipt}
                        isPrinting={props.isPrinting}
                        inspection={inspection}
                        errorLogs={inspectionValidationLogs[v.violatordetails.violatorId] || {}}
                        currentInspectionVersion={currentInspectionVersion}
                        {...v}
                    />
                );
            });
        }
    }

    let unAssignedViolationTypes = [];
    if (currentVisitData && currentVisitData.values && currentVisitData.values.length > 0) {
        currentVisitData.values.forEach(item => {
            if (!item.violatorId) {
                const lawClause = inspectionsHelper.getLawClauseByClauseId(item.checkItemId);
                unAssignedViolationTypes.push({ item, lawClause });
            }
        });
    }
    // /* RJ: temp code end - readonly AppForm */
    return (
        <>
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                {currentVisitData.workflowApplicationNumber ? (
                    <>
                        <View style={styles.applicationNoContainer}>
                            <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('applicationNumber')}</Text>
                            <Text style={[commonStyles.generalText, !currentVisitData.workflowApplicationNumber ? commonStyles.mutedText : null]}>
                                {currentVisitData.workflowApplicationNumber || ''}
                            </Text>
                        </View>
                        <Divider style={commonStyles.divider} />
                    </>
                ) : null}
                <RemarkAndAddressPreview
                    currentInspectionVersion={currentInspectionVersion}
                    generalRemarks={generalRemarks}
                    address={address}
                    coords={coords}
                    errorLogs={inspectionValidationLogs}
                    hideRemark={true}
                />
                {/* {Object.getOwnPropertyNames(inspectionValidationLogs).length > 0 ? (
                    <Text style={commonStyles.ValidationMessageText}>{JSON.stringify(inspectionValidationLogs)}</Text>
                ) : null} */}
                <Divider style={commonStyles.divider} />

                {unAssignedViolationTypes && unAssignedViolationTypes.length > 0 && (
                    <ViolationUnAssignedSummary
                        currentInspectionVersion={currentInspectionVersion}
                        items={unAssignedViolationTypes}
                        errorLogs={inspectionValidationLogs}
                    />
                )}

                {renderedReadonlyForms}
            </ScrollView>
        </>
    );
});
// class GeneralPreview extends Component {
//     static propTypes = {
//         inspection: PropTypes.any,
//     };

//     render() {

//     }
// }

// export default GeneralPreview;

//selectedService.inspectionDef.type == 'checklist'
