import styles from './styles';
import GeneralPreview from './GeneralPreview';

export { styles, GeneralPreview };
