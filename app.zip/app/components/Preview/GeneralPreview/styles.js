import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        flex: 1,
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    bulletcolumn: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        flex: 1,
    },
    bulletrow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        flex: 1,
    },
    bullet: {
        width: 10,
    },
    bulletText: {
        flex: 1,
    },
    boldText: {
        fontWeight: 'bold',
    },
    normalText: {},
    violationSummaryHeadingContainer: {
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        marginLeft: 10,
        flex: 1,
    },
    applicationNoContainer: {
        width: '100%',
        paddingStart: 10,
    },
});
