import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import EStyleSheet from 'react-native-extended-stylesheet';
import commonStyles from 'app/components/Preview/styles';
// import styles from './styles';
const styles = EStyleSheet.create({
    violationAmount: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextSM',
        justifyContent: 'center',
        alignItems: 'center',
    },
    violationAmountText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryMediumTextColor',
        justifyContent: 'center',
        alignItems: 'center',
    },
    violationTotalViolationAmountContainer: {
        alignItems: 'center',
        marginHorizontal: 10,
    },
    InspectionHeaderContainer: {
        flex: 1,
        justifyContent: 'space-around',
        flexDirection: 'row',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
    scrollContainer: {},
});
export default function(props) {
    const { totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning } = props;
    return (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
            <View style={styles.InspectionHeaderContainer}>
                <View style={styles.violationTotalViolationAmountContainer}>
                    <Text style={styles.violationAmount}>{formatCurrency(totalViolationAmount)}</Text>
                    <Text style={styles.violationAmountText}>{strings('totalPenalty')}</Text>
                </View>
                <View style={styles.violationTotalViolationAmountContainer}>
                    <Text style={styles.violationAmount}>{totalNumberOfWarning}</Text>
                    <Text style={styles.violationAmountText}>{strings('totalWarnings')}</Text>
                </View>
                <View style={styles.violationTotalViolationAmountContainer}>
                    <Text style={styles.violationAmount}>{totalNumberOfAwareness}</Text>
                    <Text style={styles.violationAmountText}>{strings('totalAwareness')}</Text>
                </View>
                {/* <View style={styles.summaryItem}>
                    <Icon.Button name="print" borderRadius={25} style={[styles.button, styles.buttonPositive]} onPress={this.handlePrint}>
                        <Text style={styles.buttonText}>{strings('print')}</Text>
                    </Icon.Button>
                </View> */}
            </View>
            <Divider style={commonStyles.divider} />
        </ScrollView>
    );
}

// class HeaderCounts extends Component {
//     static propTypes = {
//         generalRemarks: PropTypes.string,
//         address: PropTypes.any,
//     };
//     handlePrint = () => {
//         // console.log('Print pressed');
//     };
//     render() {

//     }
// }

// export default HeaderCounts;
