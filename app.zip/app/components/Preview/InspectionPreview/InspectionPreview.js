import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import * as yup from 'yup';
import { _ } from 'lodash';
import { Text, Divider } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { inspectionsHelper } from 'app/api/helperServices';
import { commonStyles, RemarkAndAddressPreview, ChecklistComplianceSummary, ViolationUnAssignedSummary, CheckListViolator } from 'app/components';
import HeaderCounts from './HeaderCounts';
import { ValidationHelper } from 'app/api/helperServices';
import { shallowEqual } from 'app/api/helperServices';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    bulletcolumn: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        flex: 1,
    },
    bulletrow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        flex: 1,
    },
    bullet: {
        width: 10,
    },
    bulletText: {
        flex: 1,
    },
    boldText: {
        fontWeight: 'bold',
    },
    normalText: {},
    buttonWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 5,
    },
    button: {
        height: 30,
        width: 80,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryWhite',
    },
});

class InspectionPreview extends Component {
    static propTypes = {
        inspection: PropTypes.any,
    };
    getValidationShape = ConfigTemplate => {
        const validationSchemaShape = {};
        ConfigTemplate.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            }
        });
        return validationSchemaShape;
    };

    //    validateViolators = (violators, errorLogs, violatorItems) => {
    // validateViolators = (violators, items, errorLogs) => {
    //     //const results = violators.map(async (violator, index) => {
    //     const results = items.map(async (item, index) => {
    //         if (!item.violatorId) return;

    //         const violator = _.find(violators, v => v.violatorId == item.violatorId);
    //         const validationSchemaShape = {};
    //         // const violatordetails = violatorItems.find(d => d.violatordetails.idNumber == violator.idNumber);
    //         // if (violatordetails) {
    //         //     if (
    //         //         violatordetails.awarenessItems.length == 0 &&
    //         //         violatordetails.warningItems.length == 0 &&
    //         //         violatordetails.violationItems.length == 0
    //         //     )
    //         //         errorLogs[violator.idNumber] = { noViolations: strings('noViolationForthisViolator') };
    //         // }
    //         switch (violator.violatorType) {
    //             case 'company':
    //                 const companyValidationSchema = yup.object().shape(this.getValidationShape(CompanyInfoConfigTemplate));

    //                 try {
    //                     await ValidationHelper.validate(violator.company, companyValidationSchema);
    //                 } catch (errors) {
    //                     if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].company = errors;
    //                     else errorLogs[violator.idNumber] = { company: errors };

    //                     // Object.getOwnPropertyNames(errors).map(er => {
    //                     //     errorLogs[er] = errors[er];
    //                     // });
    //                 }

    //                 const companyIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
    //                 try {
    //                     await ValidationHelper.validate(violator.ticketRecipient, companyIndividualValidationSchema);
    //                 } catch (errors) {
    //                     if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].companyIndividual = errors;
    //                     else errorLogs[violator.idNumber] = { companyIndividual: errors };

    //                     // Object.getOwnPropertyNames(errors).map(er => {
    //                     //     errorLogs[er] = errors[er];
    //                     // });
    //                 }
    //                 break;
    //             case 'building':
    //                 const buildingValidationSchema = yup.object().shape(this.getValidationShape(BuildingInfoConfigTemplate));
    //                 try {
    //                     await ValidationHelper.validate(violator.building, buildingValidationSchema);
    //                 } catch (errors) {
    //                     if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].building = errors;
    //                     else errorLogs[violator.idNumber] = { building: errors };
    //                     // Object.getOwnPropertyNames(errors).map(er => {
    //                     //     errorLogs[er] = errors[er];
    //                     // });
    //                 }

    //                 const buildingIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
    //                 try {
    //                     await ValidationHelper.validate(violator.ticketRecipient, buildingIndividualValidationSchema);
    //                 } catch (errors) {
    //                     if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].buildingIndividual = errors;
    //                     else errorLogs[violator.idNumber] = { buildingIndividual: errors };
    //                     // Object.getOwnPropertyNames(errors).map(er => {
    //                     //     errorLogs[er] = errors[er];
    //                     // });
    //                 }
    //                 break;
    //             case 'individual':
    //                 const individualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
    //                 try {
    //                     await ValidationHelper.validate(violator.violator, individualValidationSchema);
    //                 } catch (errors) {
    //                     if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].individual = errors;
    //                     else errorLogs[violator.idNumber] = { individual: errors };
    //                     // Object.getOwnPropertyNames(errors).map(er => {
    //                     //     errorLogs[er] = errors[er];
    //                     // });
    //                 }
    //                 if (violator.ticketRecipient) {
    //                     const ticketRecipientValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
    //                     try {
    //                         await ValidationHelper.validate(violator.ticketRecipient, ticketRecipientValidationSchema);
    //                     } catch (errors) {
    //                         if (errorLogs[violator.idNumber]) errorLogs[violator.idNumber].ticketRecipient = errors;
    //                         else errorLogs[violator.idNumber] = { ticketRecipient: errors };
    //                         // Object.getOwnPropertyNames(errors).map(er => {
    //                         //     errorLogs[er] = errors[er];
    //                         // });
    //                     }
    //                 }
    //                 break;
    //             default:
    //                 break;
    //         }
    //         return errorLogs;
    //     });

    //     return Promise.all(results);
    // };

    validateInspection = async (values, errorLogs) => {
        const res = await new Promise((resolve, reject) => {
            const { inspection, unAssignedItems, currentVisitIndex } = values;
            const selectedVisitIndex = currentVisitIndex;
            //inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def.def[0];
            let duplicateCandidates = [];
            let violators = [];
            let duplicates = [];
            if (inspection && inspection.duplicateInspection) {
                duplicateCandidates = inspection.duplicateInspection.duplicateCandidates;
                duplicates = inspection.duplicates || [];
            }
            if (unAssignedItems.length > 0) {
                errorLogs.unAssignedItems = strings('thereis') + unAssignedItems.length + ' ' + strings('unAssignedItems');
            }

            if (inspection.violators) violators = inspection.violators;
            //each check list item has a configuration for is mandatory, is attachment mandatory is remarks mandatory.?
            const notfilledCheckList = [];
            for (grp of inspectionDefinition.checklistGroups) {
                if (!grp.checklist) continue;
                grp.checklist.forEach(checkItem => {
                    const checklistValue = _.find(selectedVisitValues, selectedItem => selectedItem.checkItemId == checkItem.checkItemId);

                    if (checklistValue) {
                        if (checkItem.violationTypeIds.length > 0) {
                            if (checklistValue.selectedOption == 'no' || checklistValue.selectedOption == true) {
                                const { violatorId } = checklistValue;
                                if (violatorId) {
                                    if (checkItem.isAttachementMandatory && (!checklistValue.attachments || checklistValue.attachments.length == 0)) {
                                        if (errorLogs[violatorId]) {
                                            if (!errorLogs[violatorId][checkItem.violationTypeIds[0]])
                                                errorLogs[violatorId][checkItem.violationTypeIds[0]] = [strings('attachementIsRequired')];
                                            else errorLogs[violatorId][checkItem.violationTypeIds[0]].push(strings('attachementIsRequired'));
                                        } else {
                                            errorLogs[violatorId] = {
                                                [checkItem.violationTypeIds[0]]: [strings('attachementIsRequired')],
                                            };
                                        }
                                    }
                                    if (checkItem.isRemarkMandatory && (!checklistValue.remarks || checklistValue.remarks.length == 0)) {
                                        if (errorLogs[violatorId]) {
                                            if (!errorLogs[violatorId][checkItem.violationTypeIds[0]])
                                                errorLogs[violatorId][checkItem.violationTypeIds[0]] = [strings('remarksIsRequired')];
                                            else errorLogs[violatorId][checkItem.violationTypeIds[0]].push(strings('remarksIsRequired'));
                                        } else {
                                            errorLogs[violatorId] = {
                                                [checkItem.violationTypeIds[0]]: [strings('remarksIsRequired')],
                                            };
                                        }
                                    }
                                    checklistValue.violationTypeIds.map(law => {
                                        const possibleDuplicates = duplicateCandidates.duplicates
                                            ? duplicateCandidates.duplicates.filter(d => d.lawClausesID == law)
                                            : [];
                                        if (possibleDuplicates.length > 0 && duplicates) {
                                            currentDuplicates = duplicates.filter(item => item.lawClausesID == law);
                                            if (currentDuplicates.length == 0) {
                                                if (errorLogs[violatorId]) {
                                                    if (!errorLogs[violatorId][law])
                                                        errorLogs[violatorId][law] = [
                                                            strings('thereis') + possibleDuplicates.length + ' ' + strings('possibleDuplicates'),
                                                        ];
                                                    else
                                                        errorLogs[violatorId][law].push(
                                                            strings('thereis') + possibleDuplicates.length + ' ' + strings('possibleDuplicates')
                                                        );
                                                } else {
                                                    errorLogs[violatorId] = {
                                                        [law]: [strings('thereis') + possibleDuplicates.length + ' ' + strings('possibleDuplicates')],
                                                    };
                                                }
                                            }
                                        }
                                    });
                                }

                                if (checklistValue.violationTypeIds.length == 0) {
                                    if (!errorLogs[checkItem.checkItemId]) errorLogs[checkItem.checkItemId] = [strings('lawClauseIsRequired')];
                                    else errorLogs[checkItem.checkItemId].push(strings('lawClauseIsRequired'));
                                }
                            }
                        }
                    } else {
                        if (checkItem.isMandatory) {
                            notfilledCheckList.push(c);
                        }
                    }
                });
            }
            if (notfilledCheckList.length > 0) {
                errorLogs.notTouchedCheckList = notfilledCheckList.map(n => localeProperty(n, 'question'));
            }

            // check info forms

            // errorlogif the duplicate is not selected

            if (inspection && inspection.duplicateInspection && inspection.duplicateInspection.checking) {
                errorLogs.duplicate = (errorLogs.duplicate || '') + strings('duplicatechecking');
                return reject();
            } else if (inspection && inspection.duplicateInspection && inspection.duplicateInspection.error != undefined) {
                return resolve();
            } else {
                return resolve();
            }
        });
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    render() {
        const { visitIndex, visit, refNumber, inspection, isSubmitable, currentInspectionVersion, editable, errorLogs } = this.props;
        let currentVisitIndex = visitIndex;
        const currentVisitData = visit || {};
        const generalInfo = currentVisitData && currentVisitData.generalInfo;
        const generalRemarks = (generalInfo || {}).remarks;
        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;
        const violators = inspection.violators || [];
        const duplicateCandidates = (inspection.duplicateInspection && inspection.duplicateInspection.duplicateCandidates) || [];
        const applicationNumber = (currentVisitData || {}).applicationNumber;
        // const { complianceItems, unAssignedItems, violatorItems, totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning } = {
        //     complianceItems: [],
        //     unAssignedItems: [],
        //     violatorItems: [],
        //     totalNumberOfAwareness: 0,
        //     totalViolationAmount: 0,
        //     totalNumberOfWarning: 0,
        // };

        const {
            complianceItems,
            unAssignedItems,
            violatorItems,
            totalNumberOfAwareness,
            totalViolationAmount,
            totalNumberOfWarning,
            violatorViolations,
        } =
            inspectionsHelper.classifyChecklistItems({
                items: currentVisitData.values,
                inspectionDef: currentVisitData.def,
                violators,
                duplicateCandidates: duplicateCandidates,
            }) || {};

        if (!(currentVisitData && currentVisitData.def && currentVisitData.def.type == 'form')) {
            inspectionsHelper
                .validateInspectionDetails(
                    { address: coords, inspection, currentVisitIndex, currentVisitData, unAssignedItems },
                    this.validateInspection
                )
                .then(err => {
                    if (isSubmitable) isSubmitable(Object.keys(err).length === 0 ? true : false, err);
                    // if (violators.length > 0) {
                    //     this.validateViolators(violators, currentVisitData.values, err).then(verr => {
                    //         let finalerrorlog = {};
                    //         if (verr.length > 0) {
                    //             finalerrorlog = verr[0];
                    //         }
                    //         let hasValidationlogs = Object.getOwnPropertyNames(finalerrorlog).length == 0;
                    //         if (isSubmitable) isSubmitable(hasValidationlogs, finalerrorlog);
                    //     });
                    // } else {
                    //     if (isSubmitable) isSubmitable(Object.keys(err).length === 0 ? true : false, err);
                    // }
                });
        }

        return (
            <View style={{ flex: 1 }}>
                <ScrollView style={{ flex: 1, paddingBottom: 10 }} contentContainerStyle={styles.scrollContainer}>
                    {totalNumberOfAwareness || totalNumberOfWarning || totalViolationAmount ? (
                        <HeaderCounts
                            totalNumberOfAwareness={totalNumberOfAwareness}
                            totalNumberOfWarning={totalNumberOfWarning}
                            totalViolationAmount={totalViolationAmount}
                        />
                    ) : null}
                    {applicationNumber ? (
                        <>
                            <View style={{ width: '100%', paddingStart: 10 }}>
                                <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('applicationNumber')}</Text>
                                <Text style={[commonStyles.generalText, !applicationNumber ? commonStyles.mutedText : null]}>
                                    {applicationNumber || ''}
                                </Text>
                            </View>
                            <Divider style={commonStyles.divider} />
                        </>
                    ) : null}

                    {/* {Object.getOwnPropertyNames(errorLogs).length > 0 ? (
                        <Text style={commonStyles.ValidationMessageText}>{JSON.stringify(errorLogs)}</Text>
                    ) : null} */}

                    {currentVisitData &&
                        currentVisitData.def &&
                        currentVisitData.def.type == 'form' &&
                        violators.map((v, i) => {
                            return (
                                <View key={i.toString()}>
                                    <CheckListViolator
                                        enablePrint={!editable}
                                        editable={editable}
                                        dispatch={this.props.dispatch}
                                        inspection={inspection}
                                        visitindex={this.props.visitindex}
                                        errorLogs={{}}
                                        violatordetails={{ ...v }}
                                        currentInspectionVersion={currentInspectionVersion}
                                        isPrinting={this.props.isPrinting}
                                        printReceipt={this.props.printReceipt}
                                    />
                                </View>
                            );
                        })}
                    {unAssignedItems && unAssignedItems.length > 0 && (
                        <ViolationUnAssignedSummary
                            currentInspectionVersion={currentInspectionVersion}
                            items={unAssignedItems}
                            errorLogs={errorLogs}
                        />
                    )}
                    {violatorItems &&
                        violatorItems.length > 0 &&
                        violatorItems.map((v, idx) => {
                            return (
                                <View key={idx.toString()}>
                                    <CheckListViolator
                                        enablePrint={!editable}
                                        editable={editable}
                                        dispatch={this.props.dispatch}
                                        inspection={inspection}
                                        visitindex={this.props.visitindex}
                                        errorLogs={errorLogs[v.violatordetails && v.violatordetails.violatorId] || {}}
                                        currentInspectionVersion={currentInspectionVersion}
                                        {...v}
                                        isPrinting={this.props.isPrinting}
                                        printReceipt={this.props.printReceipt}
                                    />
                                </View>
                            );
                        })}
                    {complianceItems && complianceItems.length > 0 && (
                        <>
                            <ChecklistComplianceSummary currentInspectionVersion={currentInspectionVersion} items={complianceItems} />
                            <Divider style={commonStyles.divider} />
                        </>
                    )}
                    {errorLogs.notTouchedCheckList && errorLogs.notTouchedCheckList.length > 0 ? (
                        <>
                            <Text style={commonStyles.ValidationMessageText}>{strings('followingCheckListsAreMandtory')}</Text>
                            <View style={styles.bulletcolumn}>
                                {errorLogs.notTouchedCheckList.map(q => (
                                    <View style={styles.bulletrow}>
                                        <View style={styles.bullet}>
                                            <Text>{'\u2022' + ' '}</Text>
                                        </View>
                                        <View style={styles.bulletText}>
                                            <Text style={[commonStyles.ValidationMessageText, { marginHorizontal: 10 }]}>{q}</Text>
                                        </View>
                                    </View>
                                ))}
                            </View>
                        </>
                    ) : null}
                    <Divider style={commonStyles.divider} />
                    <RemarkAndAddressPreview
                        currentInspectionVersion={currentInspectionVersion}
                        generalRemarks={generalRemarks}
                        address={address}
                        coords={coords}
                        errorLogs={errorLogs}
                        headingmuted={true}
                        hideRemark={true}
                    />
                </ScrollView>
            </View>
        );
    }
}

export default InspectionPreview;

//selectedService.inspectionDef.type == 'checklist'
