import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity, I18nManager } from 'react-native';
import { connect } from 'react-redux';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import * as yup from 'yup';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import EStyleSheet from 'react-native-extended-stylesheet';
import { inspectionsHelper } from 'app/api/helperServices';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import { ChecklistComplianceSummary } from 'app/components/Preview/ChecklistComplianceSummary';
import { ChecklistAwarenessSummary } from 'app/components/Preview/ChecklistAwarenessSummary';
import { ChecklistWarningSummary } from 'app/components/Preview/ChecklistWarningSummary';
import { ChecklistViolationSummary } from 'app/components/Preview/ChecklistViolationSummary';
import { IndividualInfoForm, CompanyInfoForm, AbandonedVehicleForm, GeneralAppearanceVehicleForm } from 'app/components/Form';
import { CheckListUnAssignedSummary } from 'app/components/Preview/CheckListUnAssignedSummary';
import { CheckListViolator } from 'app/components/Preview/CheckListViolator';
import HeaderCounts from './HeaderCounts';
import BuildingInfoConfigTemplate from 'app/components/Form/CommonForms/BuildingInfo/config';
import IndividualInfoConfigTemplate from 'app/components/Form/CommonForms/IndividualInfo/config';
import CompanyInfoConfigTemplate from 'app/components/Form/CommonForms/CompanyInfo/config';
import { ValidationHelper } from 'app/api/helperServices';
import commonStyles from 'app/components/Preview/styles';
import { shallowEqual } from 'app/api/helperServices';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    allPicturesContainer: {
        flex: 1,
        maxHeight: 100,
        width: '100%',
        borderWidth: 1,
    },
    violationsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    warningsContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 100,
        borderWidth: 1,
    },
    bulletcolumn: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        flex: 1,
    },
    bulletrow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        flex: 1,
    },
    bullet: {
        width: 10,
    },
    bulletText: {
        flex: 1,
    },
    boldText: {
        fontWeight: 'bold',
    },
    normalText: {},
    buttonWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 5,
    },
    button: {
        height: 30,
        width: 80,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonText: {
        fontSize: '$primaryTextXS',
        color: '$primaryWhite',
    },
});

class InspectionPreview extends Component {
    static propTypes = {
        inspection: PropTypes.any,
    };
    getValidationShape = ConfigTemplate => {
        const validationSchemaShape = {};
        ConfigTemplate.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            }
        });
        return validationSchemaShape;
    };

    validateViolators = (violators, errorlogs, violatorItems) => {
        const results = violators.map(async (violator, index) => {
            const validationSchemaShape = {};
            const violatordetails = violatorItems.find(d => d.violatordetails.UIIdentifier == violator.UIIdentifier);
            if (violatordetails) {
                if (
                    violatordetails.awarenessItems.length == 0 &&
                    violatordetails.warningItems.length == 0 &&
                    violatordetails.violationItems.length == 0
                )
                    errorlogs[violator.UIIdentifier] = { noViolations: strings('noViolationForthisViolator') };
            }
            switch (violator.violatorType) {
                case 'company':
                    const companyValidationSchema = yup.object().shape(this.getValidationShape(CompanyInfoConfigTemplate));

                    try {
                        await ValidationHelper.validate(violator.company, companyValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].company = errors;
                        else errorlogs[violator.UIIdentifier] = { company: errors };

                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }

                    const companyIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.ticketRecipient, companyIndividualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].companyIndividual = errors;
                        else errorlogs[violator.UIIdentifier] = { companyIndividual: errors };

                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    break;
                case 'building':
                    const buildingValidationSchema = yup.object().shape(this.getValidationShape(BuildingInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.building, buildingValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].building = errors;
                        else errorlogs[violator.UIIdentifier] = { building: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }

                    const buildingIndividualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.ticketRecipient, buildingIndividualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].buildingIndividual = errors;
                        else errorlogs[violator.UIIdentifier] = { buildingIndividual: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    break;
                case 'individual':
                    const individualValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                    try {
                        await ValidationHelper.validate(violator.violator, individualValidationSchema);
                    } catch (errors) {
                        if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].individual = errors;
                        else errorlogs[violator.UIIdentifier] = { individual: errors };
                        // Object.getOwnPropertyNames(errors).map(er => {
                        //     errorlogs[er] = errors[er];
                        // });
                    }
                    if (violator.ticketRecipient) {
                        const ticketRecipientValidationSchema = yup.object().shape(this.getValidationShape(IndividualInfoConfigTemplate));
                        try {
                            await ValidationHelper.validate(violator.ticketRecipient, ticketRecipientValidationSchema);
                        } catch (errors) {
                            if (errorlogs[violator.UIIdentifier]) errorlogs[violator.UIIdentifier].ticketRecipient = errors;
                            else errorlogs[violator.UIIdentifier] = { ticketRecipient: errors };
                            // Object.getOwnPropertyNames(errors).map(er => {
                            //     errorlogs[er] = errors[er];
                            // });
                        }
                    }
                    break;
                default:
                    break;
            }
            return errorlogs;
        });

        return Promise.all(results);
    };

    validateInspection = async (values, errorlogs) => {
        const res = await new Promise((resolve, reject) => {
            const { inspection, unAssignedItems, currentVisitIndex } = values;
            const selectedVisitIndex = currentVisitIndex;
            //inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def.def;
            let duplicateCantidates = [];
            let violators = [];
            let duplicates = [];
            if (inspection && inspection.duplicateCheck) {
                duplicateCantidates = inspection.duplicateCheck.duplicateCantidates;
                duplicates = inspection.duplicateCheck.duplicates || [];
            }
            if (unAssignedItems.length > 0) {
                errorlogs.unAssignedItems = strings('thereis') + unAssignedItems.length + ' ' + strings('unAssignedItems');
            }
            if (inspection.info && inspection.info.violators) violators = inspection.info.violators;
            //each check list item has a configuration for is mandatory, is attachment mandatory is remarks mandatory.?
            const notfilledCheckList = [];
            for (grp of inspectionDefinition.checklistGroups) {
                if (!grp.checklist) continue;
                grp.checklist.map(c => {
                    const haschecklistValue = Object.getOwnPropertyNames(selectedVisitValues).find(v => v == c.code);
                    if (haschecklistValue) {
                        const checklistValue = selectedVisitValues[c.code];
                        if (c.violationTypeIds.length > 0) {
                            if (checklistValue.selectedOption == 'no' || checklistValue.selectedOption == true) {
                                //debugger;
                                let assignedViolation = violators.filter(vio => vio.violations.find(o => o == c.violationTypeIds[0]) != undefined);
                                if (assignedViolation.length > 0) {
                                    const violator = assignedViolation[0];
                                    if (c.isAttachementMandatory && (!checklistValue.attachments || checklistValue.attachments.length == 0)) {
                                        if (errorlogs[violator.UIIdentifier]) {
                                            if (!errorlogs[violator.UIIdentifier][c.violationTypeIds[0]])
                                                errorlogs[violator.UIIdentifier][c.violationTypeIds[0]] = [strings('attachementIsRequired')];
                                            else errorlogs[violator.UIIdentifier][c.violationTypeIds[0]].push(strings('attachementIsRequired'));
                                        } else {
                                            errorlogs[violator.UIIdentifier] = {
                                                [c.violationTypeIds[0]]: [strings('attachementIsRequired')],
                                            };
                                        }
                                    }
                                    if (c.isRemarkMandatory && (!checklistValue.remarks || checklistValue.remarks.length == 0)) {
                                        if (errorlogs[violator.UIIdentifier]) {
                                            if (!errorlogs[violator.UIIdentifier][c.violationTypeIds[0]])
                                                errorlogs[violator.UIIdentifier][c.violationTypeIds[0]] = [strings('remarksIsRequired')];
                                            else errorlogs[violator.UIIdentifier][c.violationTypeIds[0]].push(strings('remarksIsRequired'));
                                        } else {
                                            errorlogs[violator.UIIdentifier] = {
                                                [c.violationTypeIds[0]]: [strings('remarksIsRequired')],
                                            };
                                        }
                                    }
                                    c.violationTypeIds.map(law => {
                                        const posibleDuplicates = duplicateCantidates.filter(d => d.lawClausesID == law);
                                        if (posibleDuplicates.length > 0 && duplicates) {
                                            currentDuplicates = duplicates.filter(item => item.lawClausesID == law);
                                            if (currentDuplicates.length == 0) {
                                                if (errorlogs[violator.UIIdentifier]) {
                                                    if (!errorlogs[violator.UIIdentifier][law])
                                                        errorlogs[violator.UIIdentifier][law] = [
                                                            strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates'),
                                                        ];
                                                    else
                                                        errorlogs[violator.UIIdentifier][law].push(
                                                            strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates')
                                                        );
                                                } else {
                                                    errorlogs[violator.UIIdentifier] = {
                                                        [law]: [strings('thereis') + posibleDuplicates.length + ' ' + strings('posibleDuplicates')],
                                                    };
                                                }
                                            }
                                        }
                                    });
                                }

                                if (checklistValue.selectedLawClause.length == 0) {
                                    if (!errorlogs[c.code]) errorlogs[c.code] = [strings('lawClauseIsRequired')];
                                    else errorlogs[c.code].push(strings('lawClauseIsRequired'));
                                }
                            }
                        }
                    } else {
                        if (c.isMandatory) {
                            notfilledCheckList.push(c);
                        }
                    }
                });
            }
            if (notfilledCheckList.length > 0) {
                errorlogs.notTouchedCheckList = notfilledCheckList.map(n => localeProperty(n, 'question'));
            }

            // check info forms

            // errorlogif the duplicate is not selected

            if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.checking) {
                errorlogs.duplicate = (errorlogs.duplicate || '') + strings('duplicatechecking');
                return reject();
            } else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.error != undefined) {
                return resolve();
            }
            // //offline
            // else if (inspection && inspection.duplicateCheck && inspection.duplicateCheck.duplicateCantidates.length > 0) {
            //     if (inspection.duplicateCheck.duplicates == undefined) {
            //         errorlogs.duplicate =
            //             (errorlogs.duplicate || '') +
            //             strings('thereare') +
            //             `${inspection.duplicateCheck.duplicateCantidates.length} ` +
            //             strings('possibleduplicates');
            //         return reject();
            //     } else {
            //         return resolve();
            //     }
            // }
            else {
                return resolve();
            }
        });
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    render() {
        //console.warn('InspectionPreview rerender' + Math.random());
        const { inspection, isSubmitable, currentInspectionVersion, editable, inspectionValidationLogs } = this.props;

        let currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        if (this.props.visitindex != undefined) currentVisitIndex = this.props.visitindex;
        const currentVisitData = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex] : undefined;
        const generalInfo = currentVisitData && currentVisitData.generalInfo;
        const generalRemarks = (generalInfo || {}).remarks;
        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;
        const violators = (inspection.info && inspection.info.violators) || [];
        const duplicateCantidates = (inspection.duplicateCheck && inspection.duplicateCheck.duplicateCantidates) || [];
        // const { complianceItems, unAssignedItems, violatorItems, totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning } = {
        //     complianceItems: [],
        //     unAssignedItems: [],
        //     violatorItems: [],
        //     totalNumberOfAwareness: 0,
        //     totalViolationAmount: 0,
        //     totalNumberOfWarning: 0,
        // };
        const { complianceItems, unAssignedItems, violatorItems, totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning } =
            inspectionsHelper.classifyChecklistItems({
                items: currentVisitData.values,
                inspectionDef: currentVisitData.def,
                violators,
                duplicateCantidates: duplicateCantidates,
            }) || {};
        inspectionsHelper
            .validateInspectionDetails({ generalRemarks, address: coords, inspection, currentVisitIndex, unAssignedItems }, this.validateInspection)
            .then(err => {
                let violators = [];
                if (inspection.info && inspection.info.violators) violators = inspection.info.violators;
                if (violators.length > 0) {
                    this.validateViolators(violators, err, violatorItems).then(verr => {
                        let finalerrorlog = {};
                        if (verr.length > 0) {
                            finalerrorlog = verr[0];
                        }
                        // Object.getOwnPropertyNames(err).map(er => {
                        //     finalerrorlog[er] = err[er];
                        // });
                        let hasValidationlogs = Object.getOwnPropertyNames(finalerrorlog).length == 0;
                        if (isSubmitable) isSubmitable(hasValidationlogs, finalerrorlog);
                    });
                } else {
                    if (isSubmitable) isSubmitable(Object.keys(err).length === 0 ? true : false, err);
                }
            });
        return (
            <>
                <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                    <HeaderCounts
                        totalNumberOfAwareness={totalNumberOfAwareness}
                        totalNumberOfWarning={totalNumberOfWarning}
                        totalViolationAmount={totalViolationAmount}
                    />
                    <RemarkAndAddressPreview
                        currentInspectionVersion={currentInspectionVersion}
                        generalRemarks={generalRemarks}
                        address={address}
                        coords={coords}
                        validations={inspectionValidationLogs}
                    />
                    {/* {Object.getOwnPropertyNames(inspectionValidationLogs).length > 0 ? (
                        <Text style={commonStyles.ValidationMessageText}>{JSON.stringify(inspectionValidationLogs)}</Text>
                    ) : null} */}
                    <Divider style={commonStyles.divider} />

                    {unAssignedItems && unAssignedItems.length > 0 && (
                        <CheckListUnAssignedSummary
                            currentInspectionVersion={currentInspectionVersion}
                            items={unAssignedItems}
                            validations={inspectionValidationLogs}
                        />
                    )}
                    {violatorItems &&
                        violatorItems.length > 0 &&
                        violatorItems.map(v => {
                            return (
                                <View>
                                    <CheckListViolator
                                        enablePrint={!editable}
                                        editable={editable}
                                        dispatch={this.props.dispatch}
                                        inspection={inspection}
                                        visitindex={this.props.visitindex}
                                        validations={inspectionValidationLogs[v.violatordetails.UIIdentifier] || {}}
                                        currentInspectionVersion={currentInspectionVersion}
                                        {...v}
                                        isPrinting={this.props.isPrinting}
                                        printReceipt={this.props.printReceipt}
                                    />
                                </View>
                            );
                        })}

                    {complianceItems && complianceItems.length > 0 && (
                        <>
                            <ChecklistComplianceSummary currentInspectionVersion={currentInspectionVersion} items={complianceItems} />
                            <Divider style={commonStyles.divider} />
                        </>
                    )}
                    {inspectionValidationLogs.notTouchedCheckList && inspectionValidationLogs.notTouchedCheckList.length > 0 ? (
                        <>
                            <Text style={commonStyles.ValidationMessageText}>{strings('followingCheckListsAreMandtory')}</Text>
                            <View style={styles.bulletcolumn}>
                                {inspectionValidationLogs.notTouchedCheckList.map(q => (
                                    <View style={styles.bulletrow}>
                                        <View style={styles.bullet}>
                                            <Text>{'\u2022' + ' '}</Text>
                                        </View>
                                        <View style={styles.bulletText}>
                                            <Text style={[commonStyles.ValidationMessageText, { marginHorizontal: 10 }]}>{q}</Text>
                                        </View>
                                    </View>
                                ))}
                            </View>
                        </>
                    ) : null}
                </ScrollView>
            </>
        );
    }
}

export default InspectionPreview;

//selectedService.inspectionDef.type == 'checklist'
