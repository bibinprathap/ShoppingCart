import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import ADMGISMapView from 'app/components/ADMGISMapView/ADMGISMapView';
import commonStyles from 'app/components/Preview/styles';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { formatAddress } from 'app/api/helperServices/utils';
import styles from './styles';

class RemarkAndAddressPreview extends Component {
    static propTypes = {
        generalRemarks: PropTypes.string,
        address: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
        };
    }

    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };

    render() {
        const { generalRemarks, address, validations, coords, headingmuted } = this.props;

        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];
        const formattedAddress = formatAddress(address);
        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={this.toggleLocationDialog} title={formattedAddress} />
                    <View style={{ height: '100%', width: '100%' }}>
                        <ADMGISMapView coords={coords} placeMarks={placeMarkData} />
                    </View>
                </Modal>
                <View style={styles.remarksContainer}>
                    <Text style={headingmuted ? [commonStyles.generalText, commonStyles.mutedText] : commonStyles.generalHeading}>
                        {strings('remarks')}
                    </Text>
                    <Text style={[commonStyles.generalText, !generalRemarks ? commonStyles.mutedText : null]}>
                        {generalRemarks || strings('emptyRemarksList')}
                    </Text>
                    {validations.generalRemarks ? <Text style={commonStyles.ValidationMessageText}>{strings('emptyRemarksValidation')}</Text> : null}
                </View>
                <Divider style={commonStyles.divider} />
                <View style={styles.addressContainer}>
                    <View style={{ flex: 1 }}>
                        <Text style={headingmuted ? [commonStyles.generalText, commonStyles.mutedText] : commonStyles.generalHeading}>
                            {strings('address')}
                        </Text>
                        <Text style={commonStyles.generalText}>{formattedAddress}</Text>
                        <Text style={styles.coordsText}>
                            {coords
                                ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                                : strings('latitudeAndLongitude')}
                        </Text>
                    </View>
                    <View style={styles.addressIconContainer}>
                        <TouchableRipple onPress={this.toggleLocationDialog}>
                            <LineIcons style={styles.addressIcon} name={'location-pin'} size={20} color={'white'} />
                        </TouchableRipple>
                    </View>
                </View>
                {validations.address ? (
                    <View>
                        <Text style={commonStyles.ValidationMessageText}>{strings('emptyAddressValidation')}</Text>
                    </View>
                ) : null}
            </ScrollView>
        );
    }
}

export default RemarkAndAddressPreview;
