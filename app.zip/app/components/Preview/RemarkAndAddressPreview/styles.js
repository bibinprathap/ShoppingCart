import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarksContainer: {
        width: '100%',
    },
    addressContainer: {
        width: '100%',
        flexDirection: 'row',
    },
    addressIconContainer: {
        flex: 1,
        maxWidth: 50,
        minWidth: 50,
        justifyContent: 'center',
    },
    addressIcon: {
        alignSelf: 'center',
        backgroundColor: '$primaryDarkBackground',
        paddingVertical: 8,
        paddingHorizontal: 5,
        borderRadius: 5,
    },
    addressText: {
        fontSize: '$primaryTextXS',
        color: '$primaryMediumTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    coordsText: {
        fontSize: '$primaryTextXS',
        color: '$primaryMediumTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
});
