import React, { memo } from 'react';
import { View } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Text } from 'react-native-paper';
import { Icon } from 'app/components';
import styles from './styles';

export default memo(function(props) {
    const { selectedActionTypeConst, hideText } = props;
    let iconColor = '';
    let iconName = '';
    let actionText = '';

    if (selectedActionTypeConst == 'violation') {
        iconColor = '#FF0000';
        iconName = 'minus-circle-outline';
        actionText = strings('violations');
    } else if (selectedActionTypeConst == 'warning') {
        iconColor = '#ffc107';
        iconName = 'alert';
        actionText = strings('warning');
    } else if (selectedActionTypeConst == 'awareness') {
        iconColor = '#3ACCE1';
        iconName = 'information';
        actionText = strings('awareness');
    } else if (selectedActionTypeConst == 'compliance') {
        iconColor = '#008000';
        iconName = 'shield-check';
        actionText = strings('awareness');
    } else if (selectedActionTypeConst == 'engineeringReview') {
        iconColor = '';
        iconName = null;
        actionText = '';
    } else if (selectedActionTypeConst == 'noActionTypeSelected') {
        iconColor = '';
        iconName = null;
        actionText = '';
    } else if (selectedActionTypeConst == 'unassigned') {
        iconColor = '#000000';
        iconName = 'triangle';
        actionText = strings('unAssigned');
    } else {
        iconColor = '#000000';
        iconName = 'triangle';
        actionText = strings('unAssigned');
    }
    if (hideText) return <Icon type="MaterialCommunityIcons" name={iconName} size={25} style={[styles.icon, { color: iconColor }]} />;
    return (
        <View style={styles.violationAmountContainer}>
            <View style={styles.violationLeft}>
                {iconName && <Icon type="MaterialCommunityIcons" name={iconName} size={25} style={[styles.icon, { color: iconColor }]} />}
                <Text style={styles.smallText}>{actionText}</Text>
            </View>
        </View>
    );
});
