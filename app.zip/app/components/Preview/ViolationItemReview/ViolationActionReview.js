import React, { memo } from 'react';
import { View } from 'react-native';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { Text } from 'react-native-paper';
import { Icon } from 'app/components';
import styles from './styles';
import ViolationActionIconAndText from './ViolationActionIconAndText';

export default memo(function(props) {
    const { selectedActionTypeConst, amount, selectedPeriod, selectedPeriodType } = props;

    return (
        <View style={styles.violationAmountContainer}>
            <ViolationActionIconAndText selectedActionTypeConst={selectedActionTypeConst}> </ViolationActionIconAndText>

            {selectedActionTypeConst == 'violation' ? (
                <View style={styles.violationRight}>
                    <Text style={styles.violationAmount}>{formatCurrency(amount)}</Text>
                </View>
            ) : selectedActionTypeConst == 'warning' ? (
                <View style={styles.violationRight}>
                    <Icon type="MaterialCommunityIcons" name="clock-outline" size={25} style={styles.icon} />
                    <Text style={styles.violationAmount}>
                        {selectedPeriod + ' ' + strings(`${selectedPeriodType || 'day'}${selectedPeriod <= 1 ? '' : 's'}`)}
                    </Text>
                </View>
            ) : selectedActionTypeConst == 'awareness' ? (
                <View style={styles.violationRight}>
                    <Icon type="MaterialCommunityIcons" name="clock-outline" size={25} style={styles.icon} />
                    <Text style={styles.violationAmount}>
                        {selectedPeriod + ' ' + strings(`${selectedPeriodType || 'day'}${selectedPeriod <= 1 ? '' : 's'}`)}
                    </Text>
                </View>
            ) : selectedActionTypeConst == 'engineeringReview' ? (
                <View style={styles.engineeringReviewRight}>
                    <View style={styles.engineeringReviewMsgContainer}>
                        <Text style={styles.label}>{strings('engineeringReviewRequied')}</Text>
                    </View>
                </View>
            ) : selectedActionTypeConst == 'noActionTypeSelected' ? (
                <View style={styles.engineeringReviewRight}>
                    <View style={styles.engineeringReviewMsgContainer}>
                        <Text style={styles.label}>{strings('noActionTypeSelected')}</Text>
                    </View>
                </View>
            ) : null}
        </View>
    );
});
