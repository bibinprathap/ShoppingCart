import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, I18nManager } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import { withNavigation } from 'react-navigation';
import { AttachmentList, commonStyles, Modal, StatusChip } from 'app/components';
import styles from './styles';
import { setCheckListDuplicate } from 'app/actions/inspections';
import { DuplicateCheckDialog, Attachments } from 'app/screens';
import { store } from 'app/config/store';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import ViolationActionReview from './ViolationActionReview';
import ViolationActionIconAndText from './ViolationActionIconAndText';

class ViolationItemReview extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {
            attachmentModalVisible: false,
            selectedAttachment: null,
        };
        this.optionSelected = this.optionSelected.bind(this);
    }

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleAttachmentClosed = () => {
        this.setState({
            attachmentModalVisible: false,
        });
    };

    handleAttachmentPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    optionSelected = ({ inspection, option }) => {
        const { violationItem } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(this.props.inspection);
        store.dispatch(
            setCheckListDuplicate({
                option,
                inspection: this.props.inspection,
                currentVisitIndex,
                applicationNumber: inspection.applicationNumber,
                workflowInstanceId: inspection.workflowInstanceId,
                workflowApplicationNumber: inspection.workflowApplicationNumber,
                inspTypeCheckItemId: violationItem && violationItem.item && violationItem.item.inspTypeCheckItemId,
            })
        );
    };

    // getvalidationsChips(errorLogs) {
    //     const clips = errorLogs;
    //     const maxWidth = 380 / clips.length;
    //     console.log('validation', errorLogs);
    //     return clips.map((validation, idx) => {
    //         return (
    //             <Chip
    //                 key={idx.toString()}
    //                 mode="flat"
    //                 style={styles.selectedSericesClip}
    //                 textStyle={{ color: '#FFFFFF', margin: 0, padding: 0, maxWidth: maxWidth, textAlign: I18nManager.isRTL ? 'right' : 'left' }}
    //             >
    //                 <Text style={commonStyles.ValidationMessageText}>{validation}</Text>
    //             </Chip>
    //         );
    //     });
    // }

    getvalidationsMessageChip(message) {
        return (
            <Chip
                mode="flat"
                style={styles.selectedSericesClip}
                textStyle={{ color: '#FFFFFF', margin: 0, padding: 0, maxWidth: 380, textAlign: I18nManager.isRTL ? 'right' : 'left' }}
            >
                <Text style={commonStyles.ValidationMessageText}>{message}</Text>
            </Chip>
        );
    }

    render() {
        const {
            editable,
            attachments,
            remarks,
            violationDescription,
            errorLogs,
            duplicateInspection,
            inspection,
            dispatch,
            violationItem,
            selectedActionTypeConst,
            amount,
            selectedPeriod,
            selectedPeriodType,
        } = this.props;

        const attachmentsCount = !!attachments ? attachments.length : 0;
        let showRemarksAndAttachements = true;
        const { inspectionTypeDetail } = inspection || {};
        if (
            inspectionTypeDetail &&
            (inspectionTypeDetail.workflowConst === 'MimsAbandonedVehicles' || inspectionTypeDetail.workflowConst === 'MimsGeneralAppearanceForCars')
        ) {
            showRemarksAndAttachements = false;
        }
        const allRemarks = !!remarks ? remarks : '';
        let validationStyle = errorLogs && errorLogs.length > 0 ? styles.errorBox : {};
        //const validationsChips = errorLogs && errorLogs.length > 0 && errorLogs[0] != ' ' ? this.getvalidationsChips(errorLogs) : null;

        let duplicateCheckErrorLogComp = null;
        let remarkErrorLogComp = null;
        let attachementErrorLogComp = null;
        if (errorLogs && errorLogs.length > 0) {
            const duplicateCheckErrorLog = errorLogs.find(v => v.duplicate);
            if (duplicateCheckErrorLog) {
                duplicateCheckErrorLogComp = this.getvalidationsMessageChip(duplicateCheckErrorLog.duplicate);
            }
            const remarkErrorLog = errorLogs.find(v => v.remark);
            if (remarkErrorLog) {
                remarkErrorLogComp = this.getvalidationsMessageChip(remarkErrorLog.remark);
            }
            const attachementErrorLog = errorLogs.find(v => v.attachement);
            if (attachementErrorLog) {
                attachementErrorLogComp = this.getvalidationsMessageChip(attachementErrorLog.attachement);
            }
        }

        return (
            <View style={styles.checkListCard}>
                <View style={[styles.CommentsPhotoContainer, validationStyle]}>
                    <View style={{ flexDirection: 'row' }}>
                        {violationItem.item.workflowApplicationNumber && (
                            <View style={styles.issueNumberRow}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={[commonStyles.generalHeading, commonStyles.mutedText]}>{strings('issueNumber')}</Text>
                                    <Text style={[commonStyles.generalText]}>{violationItem.item.workflowApplicationNumber}</Text>
                                </View>
                                {violationItem.item.inspectionStatusConst && (
                                    <StatusChip
                                        statusConst={violationItem.item.inspectionStatusConst}
                                        translatedStatus={localeProperty(violationItem.item, 'inspectionStatus')}
                                    />
                                )}
                            </View>
                        )}
                    </View>
                    {selectedActionTypeConst && selectedActionTypeConst != 'unassigned' && selectedActionTypeConst != 'compliance' && (
                        <View style={styles.firstRow}>
                            <View style={styles.firstRowColumn}>
                                <DuplicateCheckDialog
                                    duplicateInspection={duplicateInspection}
                                    duplicatesDecision={violationItem.item.duplicates}
                                    inspection={inspection}
                                    optionSelected={this.optionSelected}
                                    violationItem={violationItem}
                                    showButton={true}
                                    isChecklist={true}
                                    dispatch={dispatch}
                                    editable={editable}
                                    errorLog={duplicateCheckErrorLogComp}
                                />
                            </View>
                            <View style={styles.firstRowColumn}>
                                <ViolationActionReview
                                    selectedActionTypeConst={selectedActionTypeConst}
                                    amount={amount}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                ></ViolationActionReview>
                            </View>
                        </View>
                    )}
                    {/* <View style={styles.firstRow}>{duplicateCheckErrorLogComp}</View> */}
                    {showRemarksAndAttachements && allRemarks ? (
                        <View style={styles.remarkContainer}>
                            <Text style={styles.remarkText}>{allRemarks}</Text>
                        </View>
                    ) : null}
                    <View style={styles.firstRow}>{remarkErrorLogComp}</View>

                    {violationDescription ? (
                        <View style={styles.questionContainer}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                {(selectedActionTypeConst == 'unassigned' || selectedActionTypeConst == 'compliance') && (
                                    <ViolationActionIconAndText
                                        selectedActionTypeConst={selectedActionTypeConst}
                                        hideText
                                    ></ViolationActionIconAndText>
                                )}
                                <Text style={styles.questionText}>{violationDescription}</Text>
                            </View>
                        </View>
                    ) : null}
                    {/* {errorLogs && errorLogs.length > 0 && errorLogs[0] != ' ' ? (
                            <View style={styles.chipsCard}>{validationsChips}</View>
                        ) : null} */}
                    <View style={styles.outerContainerWithAttachment}>
                        {showRemarksAndAttachements && attachmentsCount > 0 && (
                            <>
                                <Modal
                                    animationType="slide"
                                    transparent={false}
                                    visible={this.state.attachmentModalVisible}
                                    onRequestClose={this.toggleAttachmentDialog}
                                >
                                    <Attachments
                                        attachments={attachments}
                                        onClose={this.handleAttachmentClosed}
                                        editable={editable}
                                        attachmentModalVisible={this.state.attachmentModalVisible}
                                    />
                                </Modal>
                                <AttachmentList
                                    thumbnailSize="large"
                                    style={styles.attachmentContainer}
                                    attachments={attachments}
                                    hideDelete
                                    onPress={this.handleAttachmentPressed}
                                />
                            </>
                        )}
                    </View>
                    <View style={styles.firstRow}>{attachementErrorLogComp}</View>
                </View>
            </View>
        );
    }
}

export default withNavigation(ViolationItemReview);
