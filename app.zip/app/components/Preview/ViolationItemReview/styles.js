import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    questionText: {
        fontSize: '$primaryTextXXS',
        marginHorizontal: 0,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingRight: 20,
    },
    remarkText: {
        fontSize: '$primaryTextXXS',
        alignSelf: 'flex-start',
        margin: 5,
        color: '$primaryDarkTextColor',
        padding: 5,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    questionContainer: {
        justifyContent: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        alignItems: 'flex-start',
        margin: 5,
    },
    remarkContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'stretch',
        borderRadius: 5,
        //backgroundColor: '$primaryMediumBackground',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        //margin: 5,
    },
    buttonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginRight: 15,
    },
    icon: {
        alignSelf: 'center',
    },
    duplicateVerified: {
        color: '$primarySelectedTextColor',
        alignSelf: 'center',
    },
    attachmentContainer: {
        marginHorizontal: 0,
    },

    imageAndComments: {
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'flex-start',
        marginLeft: 0,
        flex: 1,
        flexDirection: 'row',
    },
    penaltyAmount: {
        alignItems: 'flex-end',
        marginRight: 10,
    },
    outerContainerWithAttachment: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        flex: 1,
        //width: '100%',
    },
    errorBox: { backgroundColor: '$primaryValidationBackGroundColor', padding: 5, borderRadius: 5 },
    CommentsPhotoContainer: {
        // backgroundColor: '#000000',
        flex: 1,
        //backgroundColor: '$primaryWhite',
        // elevation: 4,
        borderRadius: 8,
        margin: 5,
        //padding: 5,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
    },
    reconciliationWrapper: {
        flex: 1,
        margin: 5,
    },
    checkListCard: {
        flexDirection: 'row',
        flex: 1,
    },
    chipsCard: {
        flexDirection: 'row',
    },
    modalContainer: {
        flex: 1,
        minHeight: 55,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    iconChips: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
        marginLeft: 5,
    },
    agrementWrapper: {
        margin: 5,
    },
    horizontalView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    horizontalViewButton: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    button: {
        marginHorizontal: 10,
        marginVertical: 20,
        borderWidth: 0,
        borderRadius: 5,
        backgroundColor: '$primaryLightButtonBackground',
    },
    optionButton: {
        flex: 1,
        //alignSelf: 'center',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    optionButtonSelectedYes: {
        backgroundColor: '$primaryYesButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    optionButtonSelectedNo: {
        backgroundColor: '$primaryNoButtonBackground',
    },
    optionButtonSelected: {
        color: '$primaryWhite',
    },
    refnoContainer: {
        width: '100%',
        paddingLeft: 20,
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        justifyContent: 'flex-start',
        alignItems: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    rowSelected: {
        backgroundColor: '$primarySelectedItem',
    },
    title: {
        alignSelf: 'flex-start',
    },
    descriptionTitle: {
        alignSelf: 'flex-start',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    iconSelected: {
        tintColor: '$primaryWhite',
    },
    listItemDescription: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 12,
    },
    listItemTitle: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 16,
    },
    selectedSericesClip: {
        backgroundColor: '$primaryValidationChipColor',
        color: '$primaryLightTextColor',
        padding: 0,
        margin: 0,
    },
    remarkTickMark: {
        position: 'absolute',
        top: -5,
        right: -3,
        height: 18,
        borderRadius: 9,
        zIndex: 100,
        borderWidth: 1,
        overflow: 'hidden',
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    remarkTickMarkIcon: {
        color: '$primaryWhite',
        alignSelf: 'center',
    },
    duplicateContainer: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'flex-start',
        flexDirection: 'row',
    },
    firstRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginTop: 10,
        marginBottom: 15,
    },
    firstRowColumn: {
        flex: 1,
    },
    issueNumberRow: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 10,
    },
    secondRowFirstColumn: {
        flex: 1,
    },
    violationAmountContainer: { flex: 1, flexDirection: 'row' },
    violationLeft: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',

        flexDirection: 'row',
    },
    violationRight: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',

        flexDirection: 'row',
    },
    violationAmount: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    smallText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    engineeringReviewMsgContainer: {
        borderWidth: '$primaryBorderThin',
        backgroundColor: '$primaryIndicatorMutedColor',
        borderColor: '$primaryBorderColor',
        padding: 5,
        borderRadius: 5,
        margin: 5,
    },
    engineeringReviewRight: {
        alignItems: 'center',
        justifyContent: 'flex-end',
        flexDirection: 'row',
    },
    label: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
    },
});
