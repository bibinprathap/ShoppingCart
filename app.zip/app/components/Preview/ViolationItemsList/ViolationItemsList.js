import React, { memo, Component } from 'react';
import { View } from 'react-native';
import { localeProperty } from 'app/config/i18n/i18n';
import { ViolationItemReview } from '../ViolationItemReview';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload

export default memo(function(props) {
    const { inspection, violationItems, currentInspectionVersion, editable, errorLogs } = props;

    return (
        <View style={styles.violatorCard}>
            {violationItems.map((violationItem, idx) => {
                debugger;
                const selectedActionTypeConst = inspectionsHelper.getViolationActionTypeConst({ item: violationItem.item });
                const {
                    attachments,
                    remarks,
                    violationAmount,
                    reconciledAmount,
                    reconciled,
                    selectedPeriod,
                    selectedPeriodType,
                    inspectionStatusConst,
                    inspectionStatusE,
                    inspectionStatusA,
                } = violationItem.item;
                const { violationTypeId } = violationItem.lawClause;
                let finalVolationAmount = 0;
                if (violationAmount) finalVolationAmount = reconciled ? reconciledAmount : violationAmount;
                return (
                    <ViolationItemReview
                        key={idx.toString()}
                        editable={editable}
                        selectedActionTypeConst={selectedActionTypeConst}
                        violationItem={violationItem}
                        attachments={attachments}
                        remarks={remarks}
                        violationDescription={localeProperty(violationItem.lawClause, 'description')}
                        errorLogs={errorLogs[violationTypeId]}
                        currentInspectionVersion={currentInspectionVersion}
                        inspection={inspection}
                        duplicateInspection={violationItem.item.duplicateInspection}
                        dispatch={props.dispatch}
                        amount={finalVolationAmount}
                        selectedPeriod={selectedPeriod}
                        selectedPeriodType={selectedPeriodType}
                        inspectionStatusConst={inspectionStatusConst}
                        inspectionStatusE={inspectionStatusE}
                        inspectionStatusA={inspectionStatusA}
                    />
                );
            })}
        </View>
    );
});
