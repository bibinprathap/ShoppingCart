//common styles for Preview components
import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    generalHeading: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        justifyContent: 'flex-end',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    mutedText: { color: '$primaryMediumTextColor' },
    generalText: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    mutedText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
});
