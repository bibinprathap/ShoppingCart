import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import styles from './styles';
import { Text, Button, Checkbox, RadioButton } from 'react-native-paper';

class RadioButtonGroup extends Component {
    constructor(props) {
        super(props);

        this.state = {
            showLayersList: false,
            baseMapTypes: ['DARK_GRAY', 'IMAGERY', 'LIGHT_GRAY', 'STREETS'],
            value: 'LIGHT_GRAY',
        };
    }

    handleSelectlayers = () => {
        console.log('abc');
        this.setState({ showLayersList: !this.state.showLayersList });
    };

    onSelectConfirm = () => {
        console.log('onSelectConfirm', this.state.value);
        this.setState({ showLayersList: !this.state.showLayersList });
        this.props.onBaseMapChange(this.state.value);
    };

    render() {
        return (
            <View
                style={{
                    position: 'absolute',
                    top: 0,
                    right: 170,
                    height: this.state.showLayersList ? 200 : 20,
                    width: 170,
                    elevation: 1,
                    backgroundColor: '#F7F7FA',
                    borderRadius: 5,
                }}
            >
                <Button mode="contained" dark={true} style={{ backgroundColor: '#F7F7FA', borderWidth: 0 }} onPress={this.handleSelectlayers}>
                    <Text styles={{ color: '#555', width: 170, height: 20 }}>Select Base Map</Text>
                </Button>
                {this.state.showLayersList ? (
                    <View>
                        <RadioButton.Group onValueChange={value => this.setState({ value })} value={this.state.value}>
                            {this.state.baseMapTypes.map((basemap, i) => (
                                <View key={i} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                                    <RadioButton value={basemap} color="#0000ff" uncheckedColor="#000000" />
                                    <Text>{basemap}</Text>
                                </View>
                            ))}
                        </RadioButton.Group>

                        <Button
                            mode="contained"
                            dark={true}
                            style={{ backgroundColor: '#F7F7FA', borderWidth: 0 }}
                            onPress={this.state.value ? this.onSelectConfirm : null}
                        >
                            <Text styles={{ color: '#555' }}>Confirm</Text>
                        </Button>
                    </View>
                ) : null}
            </View>
        );
    }
}

export default RadioButtonGroup;
