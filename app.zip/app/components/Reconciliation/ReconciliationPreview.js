import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, Image, Alert } from 'react-native';
import { Text, Button } from 'react-native-paper';
import { IconAndLabel } from 'app/components/InputControls';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { ReconcileInfoForm } from 'app/components/Form';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import { attachmentsHelper, liquidEngine } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { addImageAttachment, removeImageAttachment } from 'app/actions/attachments';
import { addViolatorSignature, removeViolatorSignature } from 'app/actions/inspections';

//Todo: Integrate with EID Reader, (REST API?), or read from the MRZ of the emirates ID photo.
class ReconciliationPreview extends Component {
    static propTypes = {
        value: PropTypes.object,
        onChange: PropTypes.func,
        violatorIdentifier: PropTypes.number,
    };

    constructor(props) {
        super(props);
        this.state = { modalVisible: props.readOnly || false, reconciliationAgreement: null };
    }

    componentDidMount() {
        const termsAndConditionsTemplate = `I {{firstName}} {{lastName}} declare that my name & signature is below and all data provided on the form is correct and validated and to bear any result of any error, whether intentional or unintentional data I also declare that I'm committed to attach all the required documents after validating them. In the case of disobeying the above, Department of Urban Planning and Municipal Affairs may proceed to take Legal actions and I declare not to claim any future compensation from Department of Urban Planning & Municipal Affairs `;

        const params = { firstName: 'Ben', lastName: 'Paul' };
        liquidEngine.parseAndRender(termsAndConditionsTemplate, params).then(reconciliationAgreement => this.setState({ reconciliationAgreement }));
    }

    handleAddReconciliation = () => {
        this.setState({ modalVisible: true });
    };

    handleReconcileInfoChange = (values, dispatch, props, previousValues) => {
        if (values.signature && values.signature.pathName) {
            const path = `file://${values.signature.pathName}`;
            Image.getSize(
                path,
                (width, height) => {
                    const imageObj = {
                        path,
                        height,
                        width,
                    };
                    const captureImageQuality = 1;
                    const newAttachment = attachmentsHelper.prepareNewImageForAttachment(
                        imageObj,
                        captureImageQuality,
                        null,
                        this.props.inspectionId
                    );
                    newAttachment.extension = 'png';
                    const actions = [
                        addImageAttachment(newAttachment, true),
                        addViolatorSignature({ violatorIdentifier: this.props.violatorIdentifier, attachmentId: newAttachment.id }),
                    ];
                    dispatch(actions);
                    this.setState({ modalVisible: false });
                },
                error => {
                    console.log('Check external storage permission');
                    alertsHelper.show('error', 'Error', strings('unknown_error'));
                }
            );
        }
    };

    viewSignature = () => {
        if (this.props.values && this.props.values.signature) {
            this.setState({ modalVisible: true });
        }
    };

    removeSignature = () => {
        Alert.alert(
            strings('remove'),
            strings('confirm_remove'),
            [
                { text: strings('no'), style: 'cancel', onPress: () => null },
                {
                    text: strings('yes'),
                    onPress: () => {
                        const actions = [
                            removeImageAttachment({ id: this.props.values.signature }),
                            removeViolatorSignature({ violatorIdentifier: this.props.violatorIdentifier }),
                        ];
                        this.props.dispatch(actions);
                    },
                },
            ],
            { cancelable: true }
        );
    };

    render() {
        const { reconciled, signature } = this.props.values || {};
        const { editable, readOnly } = this.props;
        return (
            <View>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.modalVisible}
                    onRequestClose={() => {
                        this.setState({ modalVisible: false });
                    }}
                >
                    <HeaderGeneric backAction={() => this.setState({ modalVisible: false })} title={strings('reconciliation')} />
                    <ScrollView style={styles.reconciliationWrapper}>
                        <View style={styles.agrementWrapper}>
                            <Text>{this.state.reconciliationAgreement}</Text>
                            <Text style={styles.signTitle}>{reconciled ? strings('signature') : strings('sign_below')}</Text>
                        </View>
                        <ReconcileInfoForm
                            editable={!reconciled}
                            values={{ signature }}
                            formName="reconcileInfo"
                            onFormChange={this.handleReconcileInfoChange}
                        />
                    </ScrollView>
                </Modal>
                {!readOnly && reconciled && (
                    <View style={styles.container}>
                        <IconAndLabel
                            iconStyle={styles.violatorIconStyle}
                            label={strings('violatorHasReconciled')}
                            icon="check-circle"
                            iconType="default"
                        />
                        <View style={styles.reconciliationButtonsContainer}>
                            <Button
                                icon="remove-circle-outline"
                                mode="outlined"
                                disabled={!editable}
                                onPress={this.removeSignature}
                                style={styles.reconciliationButton}
                            >
                                {strings('remove')}
                            </Button>
                            <Button icon="remove-red-eye" mode="outlined" onPress={this.viewSignature} style={styles.reconciliationButton}>
                                {strings('view')}
                            </Button>
                        </View>
                    </View>
                )}
                {!readOnly && !reconciled && (
                    <View style={styles.container}>
                        <Text>{strings('violatorHasNotReconciled')}</Text>
                        <Button
                            icon="add-circle-outline"
                            mode="outlined"
                            disabled={!editable}
                            onPress={this.handleAddReconciliation}
                            style={styles.reconciliationButton}
                        >
                            {strings('addReconciliation')}
                        </Button>
                    </View>
                )}
            </View>
        );
    }
}

export default ReconciliationPreview;
