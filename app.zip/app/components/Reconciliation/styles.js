import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        minHeight: 55,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    reconciliationWrapper: {
        flex: 1,
        margin: 5,
    },
    agrementWrapper: {
        margin: 5,
    },
    signTitle: {
        fontSize: 14,
        marginTop: 15,
        fontWeight: 'bold',
    },
    reconciliationButtonsContainer: {
        flexDirection: 'row',
    },
    reconciliationButton: {
        marginStart: 10,
        marginVertical: 5,
        minWidth: 80,
    },
    violatorIconStyle: {
        color: '$primarySelectedItem',
    },
});
