import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import * as Animatable from 'react-native-animatable';
import moment from 'moment';

// const Rotatable = function({ wrappedComponent }) {
//     return wrappedComponent;
// };

const Animations = {
    rotate: {
        0: {
            rotate: '0deg',
        },
        1: {
            rotate: '180deg',
        },
    },
    revert: {
        0: {
            rotate: '180deg',
        },
        1: {
            rotate: '0deg',
        },
    },
};

const createRotatable = (wrappedComponent, position, rotated) => {
    const AnimatableComponent = Animatable.createAnimatableComponent(wrappedComponent);

    class RotatableComponent extends React.Component {
        state = { rotated: rotated || false };

        handleRef = ref => (this.animatable = ref);
        handlePress = () => {
            const newVal = !this.state.rotated;
            this.setState({ rotated: newVal });
            this.props.onRotatablePress && this.props.onRotatablePress(newVal);
        };

        render() {
            const animation = this.state.rotated ? Animations.rotate : Animations.revert;
            return (
                <TouchableOpacity onPress={this.handlePress}>
                    <AnimatableComponent
                        ref={this.handleRef}
                        {...this.props}
                        animation={animation}
                        easing="linear"
                        iterationCount={1}
                        duration={200}
                        useNativeDriver
                    >
                        {this.props.children}
                    </AnimatableComponent>
                </TouchableOpacity>
            );
        }
    }
    return RotatableComponent;
};

export { createRotatable };
