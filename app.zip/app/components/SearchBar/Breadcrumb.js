import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

class SearchBar extends Component {
    static propTypes = {
        breadCrumbs: PropTypes.array,
    };

    render() {
        const { breadCrumbs } = this.props;
        return (
            <View style={styles.breadcrumbContainer}>
                {!!breadCrumbs && breadCrumbs.length && <Icon name={'chevron-right'} size={30} style={styles.breadcrumbArrow} />}
                {breadCrumbs &&
                    breadCrumbs.map((item, index) => {
                        const breadcrumbTextStyles = [styles.breadcrumbText];
                        if (!!item.selected) breadcrumbTextStyles.push(styles.breadcrumbTextSelected);
                        return (
                            <View key={item.key} style={styles.breadcrumb}>
                                <Text style={breadcrumbTextStyles}>{item.title}</Text>
                                {index < breadCrumbs.length - 1 && <Icon name={'chevron-right'} size={30} style={styles.breadcrumbArrow} />}
                            </View>
                        );
                    })}
            </View>
        );
    }
}

export default SearchBar;
