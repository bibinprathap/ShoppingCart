import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TextInput, Picker, TouchableOpacity } from 'react-native';
import { IconButton, Button } from 'react-native-paper';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import moment from 'moment';
import { strings } from 'app/config/i18n/i18n';
import DatePicker from 'react-native-datepicker';
//import styles from './styles';
import Breadcrumb from './Breadcrumb';
import { NetWorkStatus } from 'app/screens';
import { withNavigation } from 'react-navigation';
import { setSearchKey, setFilter, search, resetSearch, setSearchDate, setAddress } from 'app/actions/search';
import { AddressPicker } from 'app/components';

import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager, Dimensions } from 'react-native';
import { Text } from 'react-native-paper';

const screenWidth = Dimensions.get('window').width;
const searchIconMargin = screenWidth - 50;

const styles = EStyleSheet.create({
    container: {
        //flex: 1,
        left: 0,
        right: 0,
        height: 60,
        backgroundColor: '$primaryWhite',
        flexDirection: 'row',
        alignItems: 'center',
        //justifyContent: 'space-between',
        paddingVertical: 10,
        paddingHorizontal: 10,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    breadcrumbContainer: {
        flex: 3,
        backgroundColor: '$primaryWhite',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    breadcrumb: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },

    breadcrumbArrow: {
        marginStart: -5,
        transform: [{ rotate: I18nManager.isRTL ? '180deg' : '0deg' }],
    },
    breadcrumbText: {
        fontSize: '$primaryTextXXS',
        marginStart: -5,
    },
    breadcrumbTextSelected: {
        color: '$primarySelectedTextColor',
    },
    textInput: {
        flex: 1,
        borderRadius: 6,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        backgroundColor: '$primaryLightInputBackground',
        paddingStart: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        includeFontPadding: false,
        paddingRight: 40,
    },
    searchIcon: {
        position: 'absolute',
        marginLeft: searchIconMargin,
    },
    pickerItem: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: 'transparent',
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        // maxWidth: 100,
        // minWidth: 120,
        justifyContent: 'flex-start',
    },
});

class SearchBar extends Component {
    static propTypes = {
        breadCrumbs: PropTypes.array,
    };

    constructor(props) {
        super(props);
        this.state = { searchKey: props.search.searchKey, fromDate: props.search.searchFromDate, toDate: props.search.searchToDate };
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.search.searchKey != this.state.searchKey) {
            this.setState({ searchKey: this.props.search.searchKey });
        }
    }

    handleSearch = () => {
        const { search, navigation, actions } = this.props;
        if (search.isLoading) return;
        const routeName = (navigation && navigation.state.routeName) || null;
        if (routeName !== 'search') {
            if (this.state.searchKey) actions.search(this.state.searchKey, search.filter);
            return navigation.navigate('search');
        }
        actions.search(this.state.searchKey, search.filter);
    };

    updateSearchKey = searchKey => {
        this.setState({ searchKey });
        this.props.actions.setSearchKey(searchKey);
        if (!searchKey) {
            this.props.actions.resetSearch();
        }
    };
    setFromDateBetween = fromDate => {
        this.setState({ fromDate });
        this.props.actions.setSearchDate({ fromDate, toDate: this.state.toDate });
    };
    setToDateBetween = toDate => {
        this.setState({ toDate });
        this.props.actions.setSearchDate({ fromDate: this.state.fromDate, toDate });
    };

    render() {
        const { breadCrumbs, navigation, search, actions, handleSearch, SearchBar } = this.props;
        const routeName = (navigation && navigation.state.routeName) || null;

        const filterTypeInput =
            this.props.search.filter && (this.props.search.filter.type === 'address' || this.props.search.filter.type === 'betweendate');
        const { fromDate, toDate } = this.state;
        const fromDatemoment = moment(fromDate, 'LL', true);
        const formattedfromDateValue = fromDatemoment.isValid() ? fromDatemoment.format('LL') : fromDate;
        const toDatemoment = moment(toDate, 'LL', true);
        const formattedtoDateValue = toDatemoment.isValid() ? toDatemoment.format('LL') : toDate;
        const textInputTheme = {
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        return (
            <View style={styles.container}>
                {routeName !== 'search' ? (
                    <NetWorkStatus />
                ) : (
                    // <Breadcrumb breadCrumbs={breadCrumbs} />
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <Picker
                            selectedValue={search.filter.type}
                            style={{ height: 50, width: 180 }}
                            onValueChange={(type, itemIndex) => actions.setFilter({ type })}
                        >
                            <Picker.Item label={strings('applicationNumber')} value="referenceNumber" style={styles.pickerItem} />
                            <Picker.Item label={strings('emiratesId')} value="emiratesID" style={styles.pickerItem} />
                            <Picker.Item label={strings('address')} value="address" style={styles.pickerItem} />
                            <Picker.Item label={strings('phoneNumber')} value="phone" style={styles.pickerItem} />
                            <Picker.Item label={strings('nearby')} value="nearby" style={styles.pickerItem} />
                            <Picker.Item label={strings('betweendate')} value="betweendate" style={styles.pickerItem} />
                        </Picker>
                        {search.filter && search.filter.type === 'address' && <AddressPicker actions={actions} handleSearch={handleSearch} />}
                        {search.filter && search.filter.type === 'betweendate' && (
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <View style={{ flex: 1, height: 55, flexDirection: 'row' }}>
                                    <Text style={[styles.label, { paddingVertical: 14 }]}> {strings('fromdate')} </Text>
                                    <DatePicker
                                        style={{ width: 120 }}
                                        date={fromDate}
                                        mode="date"
                                        placeholder="select date"
                                        format="YYYY-MM-DD"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        customStyles={{
                                            dateIcon: {
                                                width: 0,
                                                height: 0,
                                            },
                                            dateInput: {
                                                marginLeft: 10,
                                            },
                                            // ... You can check the source to find the other keys.
                                        }}
                                        onDateChange={this.setFromDateBetween}
                                    />
                                </View>
                                <View style={{ flex: 1, height: 55, flexDirection: 'row' }}>
                                    <Text style={[styles.label, { paddingVertical: 14 }]}> {strings('todate')} </Text>
                                    <DatePicker
                                        style={{ width: 120 }}
                                        date={toDate}
                                        mode="date"
                                        placeholder="select date"
                                        format="YYYY-MM-DD"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        customStyles={{
                                            dateIcon: {
                                                width: 0,
                                                height: 0,
                                            },
                                            dateInput: {
                                                marginLeft: 10,
                                            },
                                            // ... You can check the source to find the other keys.
                                        }}
                                        onDateChange={this.setToDateBetween}
                                    />
                                </View>
                            </View>
                        )}
                    </View>
                )}
                {!filterTypeInput && (
                    <TextInput
                        style={[styles.textInput]}
                        autoCorrect={false}
                        value={this.state.searchKey}
                        onChangeText={this.updateSearchKey}
                        autoCapitalize="none"
                    />
                )}
                {this.props.search.filter && this.props.search.filter.type != 'address' && (
                    <IconButton icon="search" size={20} style={styles.searchIcon} onPress={handleSearch.bind(this, this.state)} />
                )}
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators(
            {
                setSearchKey,
                setAddress,
                setFilter,
                search,
                resetSearch,
                setSearchDate,
            },
            dispatch
        ),
        dispatch,
    };
};

const connectedNotifications = connect(mapStateToProps, mapDispatchToProps)(SearchBar);

export default withNavigation(connectedNotifications);
