import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TextInput as RNTextInput } from 'react-native';
import { IconButton, TextInput } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import Breadcrumb from './Breadcrumb';

class SearchBar extends Component {
    static propTypes = {
        breadCrumbs: PropTypes.array,
    };

    handleSearch = () => {
        console.log('handleSearch is not implemented.');
    };

    render() {
        const { breadCrumbs } = this.props;
        return (
            <View style={styles.container}>
                <Breadcrumb breadCrumbs={breadCrumbs} />
                {/* 
                    using RN TextInput, because react-native-paper TextInput currentl doesn't support changing font size.
                    for this reason, fontFamily style has been set manually
                */}
                <RNTextInput
                    style={[styles.textInput]}
                    //label='Search bar'
                    autoCorrect={false}
                    autoCapitalize="none"
                />
                <IconButton icon="search" size={20} style={styles.searchIcon} color={styles.searchIcon.color} onPress={this.handleSearch} />
            </View>
        );
    }
}

export default SearchBar;
