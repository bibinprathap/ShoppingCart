import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TextInput as RNTextInput, Picker } from 'react-native';
import { IconButton, TextInput } from 'react-native-paper';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import Breadcrumb from './Breadcrumb';
import { withNavigation } from 'react-navigation';
import { setSearchKey, setFilter, search, resetSearch } from 'app/actions/search';

class SearchBar extends Component {
    static propTypes = {
        breadCrumbs: PropTypes.array,
    };

    // constructor(props) {
    //     super(props);
    //     this.state = { searchKey: props.search.searchKey };
    // }

    handleSearch = () => {
        const { search, navigation, actions } = this.props;
        if (search.isLoading) return;

        //return this.props.actions.resetSearch();
        const routeName = (navigation && navigation.state.routeName) || null;
        if (routeName !== 'search') {
            return navigation.navigate('search');
        }
        actions.search(search.searchKey, search.filter);
    };

    render() {
        const { breadCrumbs, navigation, search, actions } = this.props;
        const routeName = (navigation && navigation.state.routeName) || null;

        return (
            <View style={styles.container}>
                {routeName !== 'search' ? (
                    <Breadcrumb breadCrumbs={breadCrumbs} />
                ) : (
                    <Picker
                        selectedValue={search.filter.type}
                        style={{ height: 50, width: 220 }}
                        onValueChange={(type, itemIndex) => actions.setFilter({ type })}
                    >
                        <Picker.Item label={strings('referenceNumberShort')} value="referenceNumber" style={styles.pickerItem} />
                        <Picker.Item label={strings('emiratesId')} value="emiratesID" style={styles.pickerItem} />
                        <Picker.Item label={strings('address')} value="address" style={styles.pickerItem} />
                        <Picker.Item label={strings('phoneNumber')} value="phone" style={styles.pickerItem} />
                        <Picker.Item label={strings('nearby')} value="nearby" style={styles.pickerItem} />
                    </Picker>
                )}
                <RNTextInput
                    style={[styles.textInput]}
                    autoCorrect={false}
                    value={search.searchKey}
                    onChangeText={searchKey => {
                        actions.setSearchKey(searchKey);
                    }}
                    autoCapitalize="none"
                />
                <IconButton icon="search" size={20} style={styles.searchIcon} color={styles.searchIcon.color} onPress={this.handleSearch} />
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators(
            {
                setSearchKey,
                setFilter,
                search,
                resetSearch,
            },
            dispatch
        ),
        dispatch,
    };
};

const connectedNotifications = connect(
    mapStateToProps,
    mapDispatchToProps
)(SearchBar);

export default withNavigation(connectedNotifications);
