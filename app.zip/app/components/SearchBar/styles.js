import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager, Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;
const searchIconMargin = screenWidth - 60;

export default EStyleSheet.create({
    container: {
        //flex: 1,
        left: 0,
        right: 0,
        height: 60,
        backgroundColor: '$primaryWhite',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    breadcrumbContainer: {
        flex: 3,
        backgroundColor: '$primaryWhite',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    breadcrumb: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },

    breadcrumbArrow: {
        marginStart: -5,
        transform: [{ rotate: I18nManager.isRTL ? '180deg' : '0deg' }],
    },
    breadcrumbText: {
        fontSize: '$primaryTextXS',
        marginStart: -5,
    },
    breadcrumbTextSelected: {
        color: '$primarySelectedTextColor',
    },
    textInput: {
        flex: 1,
        borderRadius: 6,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        backgroundColor: '$primaryLightInputBackground',
        paddingStart: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        includeFontPadding: false,
    },
    searchIcon: {
        position: 'absolute',
        marginLeft: searchIconMargin,
        //color: '$primaryLightPlaceholderColor'
    },
    pickerItem: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
    },
});
