import React, { Component } from 'react';
import { View, FlatList, ActivityIndicator } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { SearchResultListViewItem } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings } from 'app/config/i18n/i18n';

class SearchResultListView extends Component {
    renderItem = ({ item, index, separators }) => {
        const { sourceType, onItemPress } = this.props;
        return <SearchResultListViewItem sourceType={sourceType} item={item} onItemPress={onItemPress} />;
    };

    keyExtractor = (item, index) => {
        //Todo: remove index from teh key, applicationNumber should be unique, but search api is returning duplicate records
        return `${item.applicationNumber}_${index}`;
    };

    renderSeparator = highlighted => {
        return <Divider />;
    };

    render() {
        const { items = [], loading, onLoadNextPage, onRefresh, refreshing = false } = this.props;
        return (
            <View style={styles.container}>
                {items.length === 0 && loading === true && (
                    <View style={styles.centerContentWrapper}>
                        <ActivityIndicator />
                    </View>
                )}
                {loading !== true && items.length === 0 && (
                    <View style={styles.centerContentWrapper}>
                        <Text style={styles.itemMediumText}>{strings('noRecordsToDisplay')}</Text>
                    </View>
                )}
                {items.length > 0 && (
                    <FlatList
                        data={items}
                        renderItem={this.renderItem}
                        keyExtractor={this.keyExtractor}
                        ItemSeparatorComponent={this.renderSeparator}
                        initialNumToRender={6}
                        onEndReachedThreshold={0.5}
                        onEndReached={onLoadNextPage}
                        onRefresh={onRefresh}
                        refreshing={refreshing}
                    />
                )}
            </View>
        );
    }
}

export default SearchResultListView;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'transparent',
    },
    centerContentWrapper: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
});
