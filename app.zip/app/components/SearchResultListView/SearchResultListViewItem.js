import React, { Component } from 'react';
import { View, Image, TouchableOpacity } from 'react-native';
import { TouchableRipple } from 'react-native-paper';
import { Text } from 'react-native-paper';
import moment from 'moment';
import { Icon, LocationAndGoogleMaps, StatusChip, TaskType } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { tasksHelper } from 'app/api/helperServices';
import EStyleSheet from 'react-native-extended-stylesheet';

const SearchResultListViewItem = ({ sourceType, item, onItemPress }) => {
    const { inspectionTypeDetail = {} } = item;
    let title;
    let description;

    let unifiedItem;
    if (sourceType === 'history') {
        title = `${localeProperty(inspectionTypeDetail, 'title')} - ${item.workflowApplicationNumber || item.applicationNumber}`;
        description = localeProperty(inspectionTypeDetail, 'serviceDesc');
        unifiedItem = {
            itemDate: item.createdDate,
            statusConst: item.inspectionStatusConst,
            translatedStatus: localeProperty(item, 'inspectionStatus'),
            location: item.location,
            icon: inspectionTypeDetail.icon,
            itemNumber: item.workflowApplicationNumber || item.applicationNumber,
            title,
            description,
        };
    } else if (sourceType === 'tasks') {
        title = tasksHelper.getTaskTitleWithNumber(item);
        description = localeProperty(item, 'title');
        unifiedItem = {
            itemDate: item.expectedStartDate,
            statusConst: item.taskStatusConst,
            secondaryStatusConst: item.overdueHours && item.overdueHours > 0 ? 'overdue' : undefined,
            taskTypeConst: item.taskType && item.taskType.toLowerCase(),
            taskTypeNameE: item.taskTypeNameE,
            taskTypeNameA: item.taskTypeNameA,
            //translatedStatus: localeProperty(item, 'status'),
            location: item.location,
            icon: item.icon,
            itemNumber: item.taskId,
            title,
            description,
            otherProps: { overdueHours: item.overdueHours },
        };
    }

    const { itemDate, statusConst, secondaryStatusConst, translatedStatus, location, ...restProps } = unifiedItem;

    const handleItemOnPress = evt => {
        if (typeof onItemPress === 'function') onItemPress(item);
    };
    return (
        <TouchableRipple onPress={handleItemOnPress}>
            <View style={styles.itemContainer}>
                <ItemHeader
                    itemDate={itemDate}
                    statusConst={statusConst}
                    secondaryStatusConst={secondaryStatusConst}
                    translatedStatus={translatedStatus}
                    location={location}
                    {...restProps}
                />
                <ItemBody {...restProps} />
            </View>
        </TouchableRipple>
    );
};

const ItemHeader = ({ itemDate, statusConst, secondaryStatusConst, translatedStatus, location, otherProps }) => {
    const isToday = moment(itemDate).isSame(moment(), 'day');
    const formattedDate = isToday ? moment(itemDate).fromNow() : moment(itemDate).format('LLL');
    return (
        <View style={{ flex: 1, flexDirection: 'row' }}>
            <View style={{ flex: 1, alignSelf: 'flex-start', maxWidth: 225, minWidth: 225, width: 225 }}>
                <Text style={styles.itemSmallText}>{formattedDate}</Text>
            </View>

            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between' }}>
                <StatusChip statusConst={statusConst} translatedStatus={translatedStatus} />
                {secondaryStatusConst && <StatusChip statusConst={secondaryStatusConst} {...otherProps} />}
                <LocationAndGoogleMaps location={location} />
            </View>
        </View>
    );
};

const ItemBody = ({ icon = {}, itemNumber, title, description, taskTypeConst, taskTypeNameE, taskTypeNameA }) => {
    return (
        <View style={{ flexDirection: 'row' }}>
            <View style={styles.itemIconContainer}>
                <Icon {...icon} size={24} style={styles.itemIcon} />
            </View>
            <View style={{ flex: 1 }}>
                <Text style={styles.itemMediumText}>{`${title}`}</Text>
                <Text style={styles.itemSmallText}>{description}</Text>
            </View>
            {taskTypeConst && (
                <View>
                    <TaskType taskTypeConst={taskTypeConst} taskTypeNameE={taskTypeNameE} taskTypeNameA={taskTypeNameA} />
                </View>
            )}
        </View>
    );
};

export default SearchResultListViewItem;

const styles = EStyleSheet.create({
    itemContainer: {
        marginHorizontal: 5,
        marginVertical: 15,
        justifyContent: 'flex-end',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    itemSmallText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    itemIconContainer: {
        margin: 5,
        borderRadius: 5,
        backgroundColor: '$primaryHeaderColor',
        justifyContent: 'center',
        alignItems: 'center',
        width: 30,
        height: 30,
    },
    itemIcon: {
        fontSize: 25,
        justifyContent: 'center',
        alignItems: 'center',
        color: '$primaryWhite',
    },
    itemImageIcon: {
        width: 25,
        height: 25,
    },
});
