import React, { Component } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity } from 'react-native';
import { IconButton, Checkbox, Button } from 'react-native-paper';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric, Loader, Modal } from 'app/components';
import { _ } from 'lodash';

class Selector extends Component {
    constructor(props) {
        super(props);
        const checkedItemIds = props.selectedIds || [];
        this.state = { searchKey: null, modalVisible: true, checkedItemIds };
    }

    updateSearchKey = searchKey => {
        this.setState({ searchKey });
        if (this.props.searchKeyUpdate) {
            this.props.searchKeyUpdate(searchKey);
        }
    };

    onPressItem = item => {
        if (!this.props.multiSelect && this.props.onSelect) {
            this.props.onSelect(item);
            this.setState({ modalVisible: false });
        } else if (this.props.multiSelect) {
            if (this.state.checkedItemIds.indexOf(item.id) !== -1) {
                const checkedItemIds = this.state.checkedItemIds;
                _.remove(checkedItemIds, itemKey => itemKey === item.id);
                this.setState({ checkedItemIds });
            } else {
                this.setState({ checkedItemIds: [...this.state.checkedItemIds, item.id] });
            }
        }
    };

    renderItem = ({ item }) => {
        const mappedItem = this.props.mapItem ? this.props.mapItem(item) : item;
        return (
            <TouchableOpacity onPress={() => this.onPressItem(mappedItem)} key={`${mappedItem.id}`} style={styles.itemWrapper}>
                {this.props.multiSelect && <Checkbox status={this.state.checkedItemIds.indexOf(mappedItem.id) !== -1 ? 'checked' : 'unchecked'} />}
                <Text style={styles.itemDetails}>{mappedItem.label}</Text>
            </TouchableOpacity>
        );
    };

    onMultiSelect = () => {
        const { checkedItemIds } = this.state;
        const result = this.props.source.filter(item => checkedItemIds.indexOf(item.id) !== -1);
        this.props.onSelect(result);
        this.setState({ modalVisible: false });
    };

    render() {
        const source = this.props.source || [];
        const { isLoading, multiSelect } = this.props;

        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.modalVisible}
                onRequestClose={() => {
                    this.setState({ modalVisible: false });
                    this.props.onRequestClose();
                }}
            >
                <View style={styles.container}>
                    <HeaderGeneric
                        backAction={() => {
                            this.setState({ modalVisible: false });
                            this.props.onRequestClose();
                        }}
                        title={this.props.headerTitle}
                    />
                    {!this.props.hideSearchBar && (
                        <View style={styles.searchbarWrapper}>
                            <TextInput
                                placeholder={this.props.placeholder || ''}
                                style={[styles.textInput]}
                                autoCorrect={false}
                                value={this.state.searchKey}
                                onChangeText={this.updateSearchKey}
                                autoCapitalize="none"
                            />
                            <IconButton
                                icon="search"
                                size={26}
                                style={styles.searchIcon}
                                color={styles.searchIcon.color}
                                onPress={() => (this.props.handleSearch ? this.props.handleSearch(this.state.searchKey) : null)}
                            />
                        </View>
                    )}
                    <View style={styles.resultWrapper}>
                        {isLoading && (
                            <View style={styles.wrapper}>
                                <Loader loading={isLoading} sprinnerSize={20} />
                            </View>
                        )}
                        {!isLoading && source && source.length === 0 && (
                            <View style={styles.wrapper}>
                                <Text style={styles.title}>{strings('noResults')}</Text>
                            </View>
                        )}
                        {(source && source.length && (
                            <View style={{ flex: 1 }}>
                                <FlatList
                                    initialNumToRender={25}
                                    data={source}
                                    extraData={this.state}
                                    keyExtractor={(item, index) => index.toString()}
                                    renderItem={this.props.renderItem || this.renderItem}
                                    ListFooterComponent={() => <View style={{ height: 60 }} />}
                                />
                                {multiSelect && (
                                    <View style={styles.footer}>
                                        <Button style={styles.btnSave} onPress={this.onMultiSelect}>
                                            <Text style={styles.btnSaveText}>{strings('confirm')}</Text>
                                        </Button>
                                    </View>
                                )}
                            </View>
                        )) ||
                            null}
                    </View>
                </View>
            </Modal>
        );
    }
}

export default Selector;
