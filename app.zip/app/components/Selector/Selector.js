import React, { Component } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Modal } from 'react-native';
import { IconButton } from 'react-native-paper';
//import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import { Loader } from 'app/components/Loader';
import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager, Dimensions } from 'react-native';
const screenWidth = Dimensions.get('window').width;
const searchIconMargin = screenWidth - 60;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightInputBackground',
    },
    resultWrapper: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 20,
    },
    searchbarWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    textInput: {
        flex: 1,
        borderRadius: 6,
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        justifyContent: 'center',
        backgroundColor: '$primaryLightInputBackground',
        //backgroundColor: '$primaryWhite',
        paddingStart: 20,
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        includeFontPadding: false,
        paddingRight: 40,
    },
    searchIcon: {
        position: 'absolute',
        right: 20,
    },
    itemWrapper: {
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 10,
        marginBottom: 2,
    },
    itemDetails: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
    },
    wrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    emptyMessage: {
        color: '$primaryMediumTextColor',
        marginBottom: 15,
    },
    title: {
        fontSize: '$primaryTextSM',
    },
});

class Selector extends Component {
    constructor(props) {
        super(props);
        this.state = { searchKey: null, modalVisible: true };
    }

    updateSearchKey = searchKey => {
        this.setState({ searchKey });
        if (this.props.searchKeyUpdate) {
            this.props.searchKeyUpdate(searchKey);
        }
    };

    onPressItem = item => {
        if (!this.props.multiSelect && this.props.onSelect) {
            this.props.onSelect(item);
            this.setState({ modalVisible: false });
        }
    };

    renderItem = ({ item }) => (
        <TouchableOpacity onPress={() => this.onPressItem(item)} KEY={item.key} style={styles.itemWrapper}>
            <Text style={styles.itemDetails}>{item.label}</Text>
        </TouchableOpacity>
    );

    render() {
        const source = this.props.source || [];
        const { isLoading } = this.props;
        return (
            <Modal
                animationType="slide"
                transparent={false}
                visible={this.state.modalVisible}
                onRequestClose={() => {
                    this.setState({ modalVisible: false });
                    this.props.onRequestClose();
                }}
            >
                <View style={styles.container}>
                    <HeaderGeneric
                        backAction={() => {
                            this.setState({ modalVisible: false });
                            this.props.onRequestClose();
                        }}
                        title={this.props.headerTitle}
                    />
                    <View style={styles.searchbarWrapper}>
                        <TextInput
                            placeholder={this.props.placeholder || ''}
                            style={[styles.textInput]}
                            autoCorrect={false}
                            value={this.state.searchKey}
                            onChangeText={this.updateSearchKey}
                            autoCapitalize="none"
                        />
                        <IconButton
                            icon="search"
                            size={26}
                            style={styles.searchIcon}
                            color={styles.searchIcon.color}
                            onPress={() => (this.props.handleLocationSearch ? this.props.handleLocationSearch(this.state.searchKey) : null)}
                        />
                    </View>
                    <View style={styles.resultWrapper}>
                        {isLoading && (
                            <View style={styles.wrapper}>
                                <Loader loading={isLoading} sprinnerSize={20} />
                            </View>
                        )}
                        {!isLoading && source && source.length === 0 && (
                            <View style={styles.wrapper}>
                                <Text style={styles.title}>{strings('noResults')}</Text>
                            </View>
                        )}
                        {(source && source.length && <FlatList data={source} renderItem={this.props.renderItem || this.renderItem} />) || null}
                    </View>
                </View>
            </Modal>
        );
    }
}

export default Selector;
