import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, I18nManager } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import images from 'app/images';

class ServiceCard extends React.PureComponent {
    static propTypes = {
        serviceDefinition: PropTypes.object,
        selected: PropTypes.bool,
        onPress: PropTypes.func,
    };

    handleOnPress = serviceDefinition => {
        if (this.props.onPress) this.props.onPress(serviceDefinition);
    };

    render() {
        const { serviceDefinition, selected } = this.props;
        let styleClassName = 'titleMD';
        /*
        //below is a very dirty and poor solution adjust the fontsize based on text length.
        //android doesn't support adjustsFontSizeToFit, a better solution can be made with some R&D
        //for now live with it

        let titleLength = serviceDefinition.title.length;
        if (titleLength <= 15)
            styleClassName = 'titleLG';
        else if (titleLength <= 20)
            styleClassName = 'titleMD';
        else styleClassName = 'titleSM';
        */
        const titleStyles = [styles.title, styles[styleClassName]];
        const containerStyles = [styles.container, selected ? styles.selected : null];

        return (
            <TouchableRipple onPress={() => this.handleOnPress(serviceDefinition)}>
                <View style={containerStyles}>
                    {serviceDefinition.icon.type === 'custom' && <Image source={images[serviceDefinition.icon.name].content} style={styles.icon} />}

                    <Text adjustsFontSizeToFit={true} minimumFontScale={0.1} style={titleStyles}>
                        {localeProperty(serviceDefinition, 'title')}
                    </Text>
                </View>
            </TouchableRipple>
        );
    }
}

export default ServiceCard;
