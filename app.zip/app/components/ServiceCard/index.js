import styles from './styles';
import ServiceCard from './ServiceCard';

export { ServiceCard, styles };
