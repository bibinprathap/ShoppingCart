import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        //alignItems: 'center',
        //justifyContent: 'space-between',
        backgroundColor: '$primaryDarkBackground',
        width: 180,
        height: 120,
        margin: 10,
        borderRadius: 20,
    },
    selected: {
        backgroundColor: '$primarySelectedItem',
    },
    iconAndTextContainer: {
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    icon: {
        color: '$primaryWhite',
        fontSize: 40,
    },
    title: {
        color: '$primaryWhite',
    },
    titleSM: {
        fontSize: '$primaryTextSM',
    },
    titleMD: {
        fontSize: '$primaryTextMD',
    },
    titleLG: {
        fontSize: '$primaryTextLG',
    },
    infoTouch: {
        position: 'absolute',
        right: 8,
        top: 8,
    },
    infoIcon: {
        color: '$primaryWhite',
    },
    popoverContainer: {
        padding: 10,
        borderRadius: 10,
    },
    popoverText: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
});
