import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '$primaryDarkBackground',
        width: 200,
        height: 180,
        margin: 10,
        borderRadius: 20,
    },
    selected: {
        backgroundColor: '$primarySelectedItem',
    },

    icon: {
        marginTop: 30,
        //marginBottom: 10
    },
    title: {
        flex: 1,
        color: '$primaryWhite',
        marginHorizontal: 5,
        textAlign: 'center',
    },
    titleSM: {
        fontSize: '$primaryTextSM',
    },
    titleMD: {
        fontSize: '$primaryTextMD',
    },
    titleLG: {
        fontSize: '$primaryTextLG',
    },
});
