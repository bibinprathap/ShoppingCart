import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, ScrollView, FlatList, I18nManager, UIManager, LayoutAnimation } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import { _ } from 'lodash';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import images from 'app/images';
import { Icon, ServiceCard, SubServiceItem } from 'app/components';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

class ServiceSelector extends Component {
    static propTypes = {
        services: PropTypes.array,
        selectedService: PropTypes.any,
        onServiceSelected: PropTypes.func,
    };

    animationConfig = {
        duration: 300,
        create: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
        update: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
        delete: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
    };

    findService = inspectionTypeId => {
        return inspectionsHelper.findService({ services: this.props.services, inspectionTypeId });
        // if (inspectionTypeId) {
        //     return _.find(this.props.services, {
        //         inspectionTypeId: inspectionTypeId,
        //     });
        // }
        // return undefined;
    };

    findSubServices = inspectionTypeId => {
        return inspectionsHelper.findSubServices({ services: this.props.services, inspectionTypeId });
        // const filteredServices = _.filter(this.props.services, item => {
        //     return item.parentInspectionTypeId == inspectionTypeId;
        // });
        // if (filteredServices && filteredServices.length == 0) return undefined;
        // return filteredServices;
    };

    findTopLevelParentService = inspectionTypeId => {
        return inspectionsHelper.findTopLevelParentService({ services: this.props.services, inspectionTypeId });
        // const parentService = _.find(this.props.services, item => {
        //     return item.inspectionTypeId == inspectionTypeId;
        // });
        // if (parentService && parentService.parentInspectionTypeId !== undefined) {
        //     return this.findTopLevelParentService(parentService.parentInspectionTypeId);
        // } else {
        //     return parentService;
        // }
    };

    findTopLevelParentServiceTree = (inspectionTypeId, servicesTree) => {
        return inspectionsHelper.findTopLevelParentService({ services: this.props.services, inspectionTypeId, servicesTree });
        // parentService = _.find(this.props.services, item => {
        //     return item.inspectionTypeId == inspectionTypeId;
        // });
        // servicesTree.push(parentService);
        // if (parentService && parentService.parentInspectionTypeId !== undefined) {
        //     return this.findTopLevelParentServiceTree(parentService.parentInspectionTypeId, servicesTree);
        // } else {
        //     return parentService;
        // }
    };

    constructor(props) {
        super(props);
        // UIManager.setLayoutAnimationEnabledExperimental &&
        //     UIManager.setLayoutAnimationEnabledExperimental(true);
        let selectedService = undefined;
        let selectedSubService = undefined;
        if (this.props.selectedService) {
            var tempSrvc = this.findService(this.props.selectedService);
            if (tempSrvc && tempSrvc.parentInspectionTypeId === undefined) {
                //this is a a top level service
                selectedService = tempSrvc;
            } else {
                //this is a subService, find the top level parent
                selectedSubService = tempSrvc;
                selectedService = tempSrvc ? this.findTopLevelParentService(tempSrvc.parentInspectionTypeId) : undefined;
            }
        }

        let currentSelectableSubServices = undefined;
        if (selectedService) {
            if (selectedSubService) {
                //siblings of the currently selected subservice
                currentSelectableSubServices = this.findSubServices(selectedSubService.parentInspectionTypeId);
            } else {
                //children of the currently selected service
                currentSelectableSubServices = this.findSubServices(selectedService.inspectionTypeId);
            }
        }

        this.state = {
            autoScroll: true,
            selectedService: selectedService,
            selectedSubService: selectedSubService,
            currentSelectableSubServices: currentSelectableSubServices,
        };
    }

    servicesScrollView;

    handleServiceOnPress = serviceDefinition => {
        //LayoutAnimation.configureNext(this.animationConfig);

        const { onServiceSelected } = this.props;
        const currentSelectableSubServices = this.findSubServices(serviceDefinition.inspectionTypeId);
        this.setState(
            {
                selectedService: serviceDefinition,
                autoScroll: false,
                selectedSubService: undefined,
                currentSelectableSubServices: currentSelectableSubServices,
            },
            () => {
                if (!!onServiceSelected) onServiceSelected(serviceDefinition);
            }
        );
    };

    handleSubServiceOnPress = serviceDefinition => {
        const { onServiceSelected } = this.props;
        let newSubServices = this.findSubServices(serviceDefinition.inspectionTypeId);
        if (!newSubServices || newSubServices.length == 0) {
            newSubServices = this.findSubServices(serviceDefinition.parentInspectionTypeId);
        }
        this.setState(
            {
                selectedSubService: serviceDefinition,
                currentSelectableSubServices: newSubServices || this.state.currentSelectableSubServices,
            },
            () => {
                if (!!onServiceSelected) onServiceSelected(serviceDefinition);
            }
        );
    };

    setScrollViewRef = element => {
        this.servicesScrollView = element;
    };

    render() {
        const { services, editable } = this.props;
        const subServiceColumns = 2;
        const { selectedService, selectedSubService, currentSelectableSubServices } = this.state;
        const mainServicesCategories = this.findSubServices(undefined);
        let selectedServicePosition = 0;
        const cards = mainServicesCategories.map((item, index) => {
            const selected = selectedService ? item.inspectionTypeId == selectedService.inspectionTypeId : false;
            if (!selectedServicePosition && selected) {
                selectedServicePosition = index;
            }
            return (
                <ServiceCard
                    key={item.inspectionTypeId}
                    serviceDefinition={item}
                    icon={item.icon}
                    selected={selected}
                    onPress={this.handleServiceOnPress}
                />
            );
        });
        const subServices = currentSelectableSubServices
            ? currentSelectableSubServices.map((item, index) => {
                  const selected = !!selectedSubService ? item.inspectionTypeId == selectedSubService.inspectionTypeId : false;
                  return <SubServiceItem serviceDefinition={item} onPress={this.handleSubServiceOnPress} selected={selected} />;
              })
            : undefined;

        let subServicesContent = !!selectedService ? (
            <Text style={styles.noSubServiceText}>
                {localeProperty(selectedService, 'title')} {strings('noSubServices')}
            </Text>
        ) : null;

        if (!!subServices) {
            const remainder = Math.abs(subServices.length % subServiceColumns);
            if (remainder > 0) {
                for (let i = 0; i < subServiceColumns - remainder; i++) {
                    const emptyServiceDefinition = {
                        inspectionTypeId: `empty.${i}`,
                        titleE: '',
                        titleA: '',
                        isDummy: true,
                    };
                    subServices.push(<SubServiceItem serviceDefinition={emptyServiceDefinition} />);
                }
            }

            if (subServices.length) {
                subServicesContent = (
                    <FlatList
                        style={{ margin: 5 }}
                        data={subServices}
                        numColumns={subServiceColumns}
                        keyExtractor={(item, index) => {
                            const { serviceDefinition } = item.props;
                            return serviceDefinition.inspectionTypeId;
                        }}
                        renderItem={({ item, index, separators }) => item}
                    />
                );
            }
        }
        if (editable) {
            return (
                <View style={styles.container}>
                    <Text style={styles.selectServiceMessage}>{strings('selectService')}</Text>
                    <ScrollView
                        ref={this.setScrollViewRef}
                        horizontal
                        onLayout={event => {
                            const { width, x, y } = event.nativeEvent.layout;
                            if (width && mainServicesCategories.length && selectedServicePosition && this.state.autoScroll) {
                                const cardItemWidth = width / mainServicesCategories.length;
                                const calculatedXPosition = x + (cardItemWidth + 70) * selectedServicePosition;
                                this.servicesScrollView.scrollTo({ x: calculatedXPosition, y: y, animated: true });
                            }
                        }}
                    >
                        {cards}
                    </ScrollView>
                    {subServices && !!selectedService && !!selectedService.inspectionTypeId && selectedService.inspectionTypeId != 1 && (
                        <React.Fragment>
                            {/* <Text>[Todo: show breadcrumb for the selected services tree]</Text> */}
                            <View
                                style={[
                                    styles.subServicesContainer,
                                    !subServices || subServices.length == 0 ? styles.subServicesContainerWithNoSubServices : null,
                                ]}
                            >
                                {subServicesContent}
                            </View>
                        </React.Fragment>
                    )}
                </View>
            );
        } else if (this.props.selectedService) {
            const selectedServiceTree = [];
            this.findTopLevelParentServiceTree(this.props.selectedService, selectedServiceTree);
            const serviceTree = selectedServiceTree.reverse().map((item, index) => {
                const serviceIcon =
                    item.icon.type === 'AdmIcon' ? (
                        <Icon {...item.icon} size={30} style={styles.icon} />
                    ) : (
                        <Icon type="MaterialCommunityIcons" name={'home'} size={30} style={styles.icon} />
                    );
                return (
                    <View key={item.inspectionTypeId} style={{ flex: index / selectedServiceTree.length, flexDirection: 'row' }}>
                        <Chip avatar={serviceIcon} mode="outlined" style={styles.selectedSericesClip} textStyle={{ color: '#FFFFFF' }}>
                            <Text style={{ color: '#FFFFFF' }}> {localeProperty(item, 'title')} </Text>
                        </Chip>
                        {index < selectedServiceTree.length - 1 && (
                            <Icon type="MaterialCommunityIcons" name={'chevron-right'} size={30} style={styles.breadcrumbArrow} />
                        )}
                    </View>
                );

                return;
            });
            return (
                <View style={styles.container}>
                    <Text style={styles.selectServiceMessage}>{strings('selectedService')}</Text>
                    <ScrollView>
                        <View style={styles.selectedSericesContainer}>{serviceTree}</View>
                    </ScrollView>
                </View>
            );
        }
        return null;
    }
}

export default ServiceSelector;
