import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, ScrollView, FlatList, I18nManager, UIManager, LayoutAnimation } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import { _ } from 'lodash';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import images from 'app/images';
import { ServiceCard } from 'app/components/ServiceCard';
import { SubServiceItem } from 'app/components/SubServiceItem';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';

class ServiceSelector extends Component {
    static propTypes = {
        services: PropTypes.array,
        selectedService: PropTypes.any,
        onServiceSelected: PropTypes.func,
    };

    animationConfig = {
        duration: 300,
        create: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
        update: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
        delete: {
            property: LayoutAnimation.Properties.opacity,
            type: LayoutAnimation.Types.spring,
            springDamping: 1,
        },
    };

    findService = serviceId => {
        if (serviceId) {
            return _.find(this.props.services, {
                serviceId: serviceId,
            });
        }
        return undefined;
    };

    findSubServices = serviceId => {
        const filteredServices = _.filter(this.props.services, item => {
            return item.parentServiceId == serviceId;
        });
        if (filteredServices && filteredServices.length == 0) return undefined;
        return filteredServices;
    };

    findTopLevelParentService = serviceId => {
        parentService = _.find(this.props.services, item => {
            return item.serviceId == serviceId;
        });
        if (parentService && parentService.parentServiceId !== undefined) {
            //not toplevel, check further up
            return this.findTopLevelParentService(parentService.parentServiceId);
        } else {
            //found it
            return parentService;
        }
    };

    findTopLevelParentServiceTree = (serviceId, servicesTree) => {
        parentService = _.find(this.props.services, item => {
            return item.serviceId == serviceId;
        });
        servicesTree.push(parentService);
        if (parentService && parentService.parentServiceId !== undefined) {
            //not toplevel, check further up
            return this.findTopLevelParentServiceTree(parentService.parentServiceId, servicesTree);
        } else {
            //found it
            return parentService;
        }
    };

    constructor(props) {
        super(props);
        // UIManager.setLayoutAnimationEnabledExperimental &&
        //     UIManager.setLayoutAnimationEnabledExperimental(true);
        let selectedService = undefined;
        let selectedSubService = undefined;
        if (this.props.selectedService) {
            var tempSrvc = this.findService(this.props.selectedService);
            if (tempSrvc && tempSrvc.parentServiceId === undefined) {
                //this is a a top level service
                selectedService = tempSrvc;
            } else {
                //this is a subService, find the top level parent
                selectedSubService = tempSrvc;
                selectedService = tempSrvc ? this.findTopLevelParentService(tempSrvc.parentServiceId) : undefined;
            }
        }

        let currentSelectableSubServices = undefined;
        if (selectedService) {
            if (selectedSubService) {
                //siblings of the currently selected subservice
                currentSelectableSubServices = this.findSubServices(selectedSubService.parentServiceId);
            } else {
                //children of the currently selected service
                currentSelectableSubServices = this.findSubServices(selectedService.serviceId);
            }
        }

        this.state = {
            autoScroll: true,
            selectedService: selectedService,
            selectedSubService: selectedSubService,
            currentSelectableSubServices: currentSelectableSubServices,
        };
    }

    servicesScrollView;

    handleServiceOnPress = serviceDefinition => {
        //LayoutAnimation.configureNext(this.animationConfig);

        const { onServiceSelected } = this.props;
        const currentSelectableSubServices = this.findSubServices(serviceDefinition.serviceId);
        this.setState(
            {
                selectedService: serviceDefinition,
                autoScroll: false,
                selectedSubService: undefined,
                currentSelectableSubServices: currentSelectableSubServices,
            },
            () => {
                if (!!onServiceSelected) onServiceSelected(serviceDefinition);
            }
        );
    };

    handleSubServiceOnPress = serviceDefinition => {
        const { onServiceSelected } = this.props;
        let newSubServices = this.findSubServices(serviceDefinition.serviceId);
        if (!newSubServices || newSubServices.length == 0) {
            newSubServices = this.findSubServices(serviceDefinition.parentServiceId);
        }
        this.setState(
            {
                selectedSubService: serviceDefinition,
                currentSelectableSubServices: newSubServices || this.state.currentSelectableSubServices,
            },
            () => {
                if (!!onServiceSelected) onServiceSelected(serviceDefinition);
            }
        );
    };

    setScrollViewRef = element => {
        this.servicesScrollView = element;
    };

    render() {
        // console.log('ServiceSelector.render() props -->');
        // console.log(this.props);

        const { services, editable } = this.props;
        const subServiceColumns = 2;
        const { selectedService, selectedSubService, currentSelectableSubServices } = this.state;
        const mainServicesCategories = this.findSubServices(undefined);
        let selectedServicePosition = 0;
        const cards = mainServicesCategories.map((item, index) => {
            const selected = selectedService ? item.serviceId == selectedService.serviceId : false;
            if (!selectedServicePosition && selected) {
                selectedServicePosition = index;
            }
            return (
                <ServiceCard key={item.serviceId} serviceDefinition={item} icon={item.icon} selected={selected} onPress={this.handleServiceOnPress} />
            );
        });
        const subServices = currentSelectableSubServices
            ? currentSelectableSubServices.map((item, index) => {
                  const selected = !!selectedSubService ? item.serviceId == selectedSubService.serviceId : false;
                  return <SubServiceItem serviceDefinition={item} onPress={this.handleSubServiceOnPress} selected={selected} />;
              })
            : undefined;

        let subServicesContent = !!selectedService ? (
            <Text style={styles.noSubServiceText}>
                {localeProperty(selectedService, 'title')} {strings('noSubServices')}
            </Text>
        ) : null;

        if (!!subServices) {
            const remainder = Math.abs(subServices.length % subServiceColumns);
            if (remainder > 0) {
                for (let i = 0; i < subServiceColumns - remainder; i++) {
                    const emptyServiceDefinition = {
                        serviceId: `empty.${i}`,
                        titleE: '',
                        titleA: '',
                    };
                    subServices.push(<SubServiceItem serviceDefinition={emptyServiceDefinition} />);
                }
            }

            if (subServices.length) {
                subServicesContent = (
                    <FlatList
                        style={{ margin: 5 }}
                        data={subServices}
                        numColumns={subServiceColumns}
                        keyExtractor={(item, index) => {
                            const { serviceDefinition } = item.props;
                            return serviceDefinition.serviceId;
                        }}
                        renderItem={({ item, index, separators }) => item}
                    />
                );
            }
        }
        if (editable) {
            return (
                <View style={styles.container}>
                    <Text style={styles.selectServiceMessage}>{strings('selectService')}</Text>
                    <ScrollView
                        ref={this.setScrollViewRef}
                        horizontal
                        onLayout={event => {
                            const { width, x, y } = event.nativeEvent.layout;
                            if (width && mainServicesCategories.length && selectedServicePosition && this.state.autoScroll) {
                                const cardItemWidth = width / mainServicesCategories.length;
                                const calculatedXPosition = x + (cardItemWidth + 70) * selectedServicePosition;
                                this.servicesScrollView.scrollTo({ x: calculatedXPosition, y: y, animated: true });
                            }
                        }}
                    >
                        {cards}
                    </ScrollView>
                    {!!selectedService && !!selectedService.serviceId && selectedService.serviceId != 1 && (
                        <React.Fragment>
                            <Text>[Todo: show breadcrumb for the selected services tree]</Text>
                            <View
                                style={[
                                    styles.subServicesContainer,
                                    !subServices || subServices.length == 0 ? styles.subServicesContainerWithNoSubServices : null,
                                ]}
                            >
                                {subServicesContent}
                            </View>
                        </React.Fragment>
                    )}
                </View>
            );
        } else {
            const selectedServiceTree = [];
            this.findTopLevelParentServiceTree(this.props.selectedService, selectedServiceTree);
            const serviceTree = selectedServiceTree.reverse().map((item, index) => {
                const iconName = item.icon.name;
                const avatarIcon =
                    item.icon.type === 'custom' ? (
                        <Image source={images[iconName].content} style={styles.icon} />
                    ) : (
                        <Icon name={iconName} size={30} style={styles.icon} />
                    );
                return (
                    <View key={item.serviceId} style={{ flex: index / selectedServiceTree.length, flexDirection: 'row' }}>
                        <Chip avatar={avatarIcon} mode="outlined" style={styles.selectedSericesClip} textStyle={{ color: '#FFFFFF' }}>
                            <Text style={{ color: '#FFFFFF' }}> {localeProperty(item, 'title')} </Text>
                        </Chip>
                        {index < selectedServiceTree.length - 1 && <Icon name={'chevron-right'} size={30} style={styles.breadcrumbArrow} />}
                    </View>
                );

                return;
            });
            return (
                <View style={styles.container}>
                    <Text style={styles.selectServiceMessage}>{strings('selectedService')}</Text>
                    <ScrollView>
                        <View style={styles.selectedSericesContainer}>{serviceTree}</View>
                    </ScrollView>
                </View>
            );
        }
    }
}

export default ServiceSelector;
