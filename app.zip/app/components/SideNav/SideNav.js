import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, ScrollView } from 'react-native';
import { TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';
import images from 'app/images';
import { connect } from 'react-redux';

class SideNav extends Component {
    static propTypes = {
        routes: PropTypes.array,
        currentRouteName: PropTypes.string,
        onPress: PropTypes.func,
        userData: PropTypes.object,
    };

    handleOnPress = item => {
        if (this.props.onPress && typeof this.props.onPress === 'function') this.props.onPress(item);
    };

    render() {
        const { routes, currentRouteName, userData } = this.props;
        const routeItems = !routes
            ? null
            : routes.map(item => {
                  let icon = null;
                  if (item.iconType === 'default') {
                      icon = <Icon name={item.icon} size={45} style={styles.routeItemIcon} />;
                  } else {
                      icon = <Image source={images[item.icon].content} resizeMode="contain" />;
                  }
                  let routeItemContainerStyles = [styles.routeItemContainer];
                  if (currentRouteName && currentRouteName === item.key) routeItemContainerStyles.push(styles.routeItemContainerSelected);
                  return (
                      <TouchableRipple key={item.key} onPress={() => this.handleOnPress(item)}>
                          <View style={routeItemContainerStyles}>{icon}</View>
                      </TouchableRipple>
                  );
              });
        return (
            <View style={styles.outerContainer}>
                <ScrollView>
                    <View style={styles.container}>
                        <View style={styles.avatarContainer}>
                            {!!userData && <Image source={{ uri: `data:image/jpg;base64,${userData.photo}` }} style={styles.avatar} />}
                            {!userData && <Image source={images.avatar.content} style={styles.avatar} />}
                        </View>
                        {routeItems}
                    </View>
                </ScrollView>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(SideNav);
