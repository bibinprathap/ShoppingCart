import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Modal, View, Image, ScrollView, TouchableWithoutFeedback, TouchableOpacity, I18nManager } from 'react-native';
import { Text, TouchableRipple, Divider } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styles from './styles';
import images from 'app/images';
import { connect } from 'react-redux';
import FeatherIcon from 'react-native-vector-icons/Feather';
import { createRotatable } from 'app/components/Rotatable';
import * as Animatable from 'react-native-animatable';
import { strings } from 'app/config/i18n/i18n';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import Settings from 'app/screens/main/Settings';

const dashboardNavItems = [
    { key: 'history', icon: 'schedule', iconType: 'default' },
    { key: 'inspectionPlan', icon: 'schedule', iconType: 'default' },
    { key: 'tasks', icon: 'schedule', iconType: 'default' },
    { key: 'overdue', icon: 'schedule', iconType: 'default' },
];

class SideNav extends Component {
    static propTypes = {
        routes: PropTypes.array,
        currentRouteName: PropTypes.string,
        onPress: PropTypes.func,
        userData: PropTypes.object,
    };

    constructor(props) {
        super(props);
        this.renderRoutes = this.renderRoutes.bind(this);
        this.state = { settingsModalVisible: false, dashboardNavExpanded: false, selectedDashboardNavItem: props.selectedDashboardTab || 'history' };
    }
    icon = createRotatable(FeatherIcon);

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };

    handleDashboardNavSelection = key => {
        //console.log('handleDashboardNavSelection: ', key);

        this.setState({ selectedDashboardNavItem: key });
        this.props.onDashboardNavChanged && this.props.onDashboardNavChanged(key, this.state.dashboardNavExpanded, new Date());
    };

    handleDashboardNavMenuOnPress = expanded => {
        //console.log('handleExpandDashboardNav... expanded: ', expanded);
        this.setState({ dashboardNavExpanded: expanded }, () => {
            this.props.onDashboardNavChanged &&
                this.props.onDashboardNavChanged(
                    this.state.selectedDashboardNavItem,
                    this.state.dashboardNavExpanded,
                    this.props.navigationPressedTime
                );
        });
    };

    renderRoutes(routes, currentRouteName) {
        return routes.map(item => {
            let icon = null;
            if (item.showInsidePanel) {
                return null;
            }
            if (item.iconType === 'default') {
                icon = <Icon name={item.icon} size={45} style={styles.routeItemIcon} />;
            } else {
                icon = <Image source={images[item.icon].content} resizeMode="contain" />;
            }
            let routeItemContainerStyles = [styles.routeItemContainer];
            if (currentRouteName && currentRouteName === item.key) routeItemContainerStyles.push(styles.routeItemContainerSelected);
            return (
                <TouchableOpacity key={item.key} onPress={() => this.handleOnPress(item)}>
                    <View style={routeItemContainerStyles}>{icon}</View>
                </TouchableOpacity>
            );
        });
    }
    handleOnPress = item => {
        __DEV__ && console.log('sidenavepressed');

        if (item.key === 'settings') {
            this.toggleSettingsDialog();
            return;
        }

        setTimeout(() => {
            if (this.props.onPress && typeof this.props.onPress === 'function') this.props.onPress(item);
        });
    };

    render() {
        const RotatableIcon = this.icon;
        const { routes, currentRouteName, userData } = this.props;
        const routeItems = !routes ? null : this.renderRoutes(routes, currentRouteName);
        const { dashboardNavExpanded } = this.state;
        const avatarStyles = [styles.avatar, { width: 56, height: 56, borderRadius: 28 }];
        //console.log('dashboardNavExpanded: ', dashboardNavExpanded);
        return (
            <View>
                <Modal animationType="slide" transparent={false} visible={this.state.settingsModalVisible} onRequestClose={this.toggleSettingsDialog}>
                    <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                    <Settings requestClose={this.toggleSettingsDialog} />
                </Modal>
                <View style={{ flexDirection: 'row', height: '100%' }}>
                    <View style={[styles.sideNavOuterContainer, { zIndex: 100 }]}>
                        <ScrollView>
                            <View style={styles.sideNavInnerContainer}>
                                {this.props.showDashboardMenu && (
                                    <RotatableIcon
                                        name={I18nManager.isRTL ? 'chevrons-left' : 'chevrons-right'}
                                        size={40}
                                        style={styles.menuToggleArrow}
                                        onRotatablePress={this.handleDashboardNavMenuOnPress}
                                    />
                                )}
                                <View style={[styles.avatarContainer, {}]}>
                                    {!!userData && <Image source={{ uri: `data:image/jpg;base64,${userData.photo}` }} style={avatarStyles} />}
                                    {!userData && <Image source={images.avatar.content} style={avatarStyles} />}
                                </View>
                                {routeItems}
                            </View>
                        </ScrollView>
                    </View>
                    {this.props.showDashboardMenu && (
                        <Animatable.View
                            style={[
                                styles.dashboardNavContainer,
                                { zIndex: 1, width: dashboardNavExpanded ? 150 : 0 },
                                //     //{ left: dashboardNavExpanded ? 100 : 0 },
                                //     //{ transform: [{ translateX: dashboardNavExpanded ? 100 : 0 }] },
                            ]}
                            animation={
                                I18nManager.isRTL
                                    ? dashboardNavExpanded
                                        ? 'slideInRight'
                                        : 'slideOutRight'
                                    : dashboardNavExpanded
                                    ? 'slideInLeft'
                                    : 'slideOutLeft'
                            }
                            easing="linear"
                            duration={150}
                            useNativeDriver
                        >
                            {dashboardNavItems.map((item, index) => {
                                const isActive = this.state.selectedDashboardNavItem == item.key;
                                //Todo: add icons next to DashboardNav menu items
                                return (
                                    <View key={item.key} style={[styles.dashboardNavItem, isActive && styles.dashboardNavItemActive]}>
                                        <TouchableOpacity
                                            style={styles.dashboardNavItemTouchableContainer}
                                            onPress={() => this.handleDashboardNavSelection(item.key)}
                                        >
                                            <Text style={[styles.dashboardNavItemTitle, isActive && styles.dashboardNavItemActiveTitle]}>
                                                {strings(item.key)}
                                            </Text>
                                            <Text style={[styles.dashboardNavItemDescription, isActive && styles.dashboardNavItemActiveDescription]}>
                                                {strings(`${item.key}Description`)}
                                            </Text>
                                        </TouchableOpacity>
                                        <Divider />
                                    </View>
                                );
                            })}
                        </Animatable.View>
                    )}
                </View>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(SideNav);
