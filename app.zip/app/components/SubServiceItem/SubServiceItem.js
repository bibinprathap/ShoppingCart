import React from 'react';
import PropTypes from 'prop-types';
import { View, Image, I18nManager } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import images from 'app/images';

class SubServiceItem extends React.PureComponent {
    static propTypes = {
        serviceDefinition: PropTypes.object,
        onPress: PropTypes.func,
        selected: PropTypes.bool,
    };

    handleOnPress = serviceDefinition => {
        if (this.props.onPress) this.props.onPress(serviceDefinition);
    };

    render() {
        const { serviceDefinition, selected } = this.props;
        const title = localeProperty(serviceDefinition, 'title');
        const titleStyles = [styles.title, styles.titleMD, selected ? styles.titleSelected : null];
        const containerStyles = [
            styles.container,
            title.length > 0 ? styles.nonEmptyContainer : styles.emptyContainer,
            selected ? styles.selected : null,
        ];
        return (
            <View style={containerStyles}>
                <TouchableRipple onPress={() => this.handleOnPress(serviceDefinition)} style={styles.touchWrapper}>
                    <Text key={serviceDefinition.serviceId} style={titleStyles}>
                        {title}
                    </Text>
                </TouchableRipple>
            </View>
        );
    }
}

export default SubServiceItem;
