import React from 'react';
import PropTypes from 'prop-types';
import { View, Image, I18nManager } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import images from 'app/images';
import alertsHelper from 'app/api/helperServices/alerts';
import IconCommunity from 'react-native-vector-icons/Feather';

class SubServiceItem extends React.PureComponent {
    static propTypes = {
        serviceDefinition: PropTypes.object,
        onPress: PropTypes.func,
        selected: PropTypes.bool,
    };

    handleOnPress = () => {
        if (this.props.onPress) this.props.onPress(this.props.serviceDefinition);
    };
    showServiceDesc = (alertType, title, ServiceDesc) => {
        const desc = localeProperty(this.props.serviceDefinition, 'serviceDesc');
        //console.log('showServiceDesc: ', desc);
        if (desc) {
            const title = localeProperty(this.props.serviceDefinition, 'title');
            alertsHelper.show('info', title, desc);
        }

        alertsHelper.show(alertType, title, ServiceDesc);
    };
    render() {
        const { serviceDefinition, selected } = this.props;
        const infoStyles = [styles.info];
        const containerService = [styles.containerService];
        const title = localeProperty(serviceDefinition, 'title');
        const titleStyles = [styles.title, styles.titleSM, selected ? styles.titleSelected : null];
        const containerStyles = [
            styles.container,
            title.length > 0 ? styles.nonEmptyContainer : styles.emptyContainer,
            selected ? styles.selected : null,
        ];
        return (
            <TouchableRipple onPress={this.handleOnPress} style={styles.touchWrapper}>
                <View style={containerStyles}>
                    <View style={infoStyles}>
                        <IconCommunity name="info" style={titleStyles} size={20} onPress={this.showServiceDesc} />
                    </View>
                    <View style={containerService}>
                        <Text key={serviceDefinition.serviceId} style={titleStyles}>
                            {title}
                        </Text>
                    </View>
                </View>
            </TouchableRipple>
        );
    }
}

export default SubServiceItem;
