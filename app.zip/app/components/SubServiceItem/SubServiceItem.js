import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Icon } from 'app/components';
import Popover from 'react-native-popover-view';

class SubServiceItem extends React.PureComponent {
    static propTypes = {
        serviceDefinition: PropTypes.object,
        onPress: PropTypes.func,
        selected: PropTypes.bool,
    };

    constructor() {
        super();
        this.state = { isVisible: false, popoverDesc: null };
    }
    touchable;

    handleOnPress = () => {
        if (this.props.onPress) this.props.onPress(this.props.serviceDefinition);
    };

    showServiceDesc = (alertType, title, ServiceDesc) => {
        const desc = localeProperty(this.props.serviceDefinition, 'serviceDesc');
        this.setState({ isVisible: true, popoverDesc: desc });
    };

    closePopover = () => {
        this.setState({ isVisible: false });
    };

    render() {
        const { serviceDefinition, selected } = this.props;
        const infoStyles = [styles.info];
        const containerService = [styles.containerService];
        const title = localeProperty(serviceDefinition, 'title');
        const titleStyles = [styles.title, styles.titleSM, selected ? styles.titleSelected : null];
        const containerStyles = [
            styles.container,
            title.length > 0 ? styles.nonEmptyContainer : styles.emptyContainer,
            selected ? styles.selected : null,
        ];

        return (
            <View style={{ flex: 1 }}>
                <Popover isVisible={this.state.isVisible} fromView={this.touchable} onRequestClose={this.closePopover}>
                    <View style={styles.popoverContainer}>
                        <Text style={styles.popoverText}>{this.state.popoverDesc}</Text>
                    </View>
                </Popover>
                <TouchableRipple onPress={this.handleOnPress} style={styles.touchWrapper}>
                    <View style={containerStyles}>
                        {serviceDefinition.isDummy !== true && (
                            <View style={infoStyles}>
                                <Icon
                                    type="MaterialCommunityIcons"
                                    name="alert-circle-outline"
                                    ref={ref => (this.touchable = ref)}
                                    style={titleStyles}
                                    size={20}
                                    onPress={this.showServiceDesc}
                                />
                            </View>
                        )}
                        <View style={containerService}>
                            {serviceDefinition.isDummy !== true && <Icon {...serviceDefinition.icon} style={[styles.icon, { marginRight: 10 }]} />}
                            <Text key={serviceDefinition.inspectionTypeId} style={titleStyles}>
                                {title}
                            </Text>
                        </View>
                    </View>
                </TouchableRipple>
            </View>
        );
    }
}

export default SubServiceItem;
