import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 2,
        // flexDirection: 'row',
        margin: 5,
        borderRadius: 10,
        paddingHorizontal: 10,
        height: 40,
    },

    containerService: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },

    nonEmptyContainer: {
        backgroundColor: '$serviceItemBackgroundColor',
    },
    emptyContainer: {
        backgroundColor: '$primaryDarkBackground',
    },
    selected: {
        backgroundColor: '$primarySelectedItem',
    },
    touchWrapper: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    title: {
        color: '$primaryMediumTextColor',
        alignSelf: 'center',
        textAlign: 'center',
    },
    titleSM: {
        fontSize: '$primaryTextSM',
    },
    titleMD: {
        fontSize: '$primaryTextMD',
    },
    titleLG: {
        fontSize: '$primaryTextLG',
    },
    info: {
        position: 'absolute',
        right: 4,
        top: 4,
    },
    popoverContainer: {
        padding: 10,
        borderRadius: 10,
    },
    popoverText: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
    icon: {
        color: '$primaryWhite',
        fontSize: 18,
    },
});
