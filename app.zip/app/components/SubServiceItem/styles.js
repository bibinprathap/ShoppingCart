import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 0.5,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 10,
        borderRadius: 10,
        paddingHorizontal: 5,
        height: 65,
    },
    nonEmptyContainer: {
        backgroundColor: '$selectedItemBackgroundColor',
    },
    emptyContainer: {
        backgroundColor: '$primaryDarkBackground',
    },
    selected: {
        backgroundColor: '$primarySelectedItem',
    },
    touchWrapper: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    title: {
        flex: 1,
        color: '$primaryMediumTextColor',
        alignSelf: 'center',
        textAlign: 'center',
    },
    titleSM: {
        fontSize: '$primaryTextSM',
    },
    titleMD: {
        fontSize: '$primaryTextMD',
    },
    titleLG: {
        fontSize: '$primaryTextLG',
    },
});
