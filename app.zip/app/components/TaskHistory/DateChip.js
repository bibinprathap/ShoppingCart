import React from 'react';
import { I18nManager } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import styles from './styles';

const DateChip = props => {
    return (
        <Chip
            mode="flat"
            // avatar={<Icon name="error" size={20} style={[styles.iconChips, { margin: 0, padding: 0 }]} />}
            style={[styles.selectedSericesClip, { maxHeight: 25, maxWidth: 200 }]}
            textStyle={{
                color: '#FFFFFF',
                margin: 0,
                padding: 0,
                marginTop: 0,

                textAlign: I18nManager.isRTL ? 'right' : 'left',
            }}
        >
            <Text style={[styles.refNumbersmall, { color: '#ffffff' }]} numberOfLines={1}>
                {props.date}
            </Text>
        </Chip>
    );
};
export default DateChip;
