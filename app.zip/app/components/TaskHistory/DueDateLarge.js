import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';
import commonStyles from 'app/components/Preview/styles';

import moment from 'moment';

const DueDateLarge = props => {
    const formatedFromDate = moment(props.deadlineFromDate).format('LL');
    const formatedToDate = moment(props.deadlineToDate).format('LL');
    if (formatedFromDate == formatedToDate)
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('deadline') + ' '}</Text>
                <Text style={commonStyles.generalHeading}>
                    {strings('on') + ' '}
                    {formatedFromDate}
                </Text>
            </View>
        );
    else
        return (
            <View style={{ flex: 1 }}>
                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('deadline')}</Text>
                <Text style={commonStyles.generalHeading}>
                    {strings('between') + ' '}
                    {formatedFromDate}
                </Text>
                <Text style={commonStyles.generalHeading}>
                    {strings('and') + ' '}
                    {formatedToDate}
                </Text>
            </View>
        );
};
export default DueDateLarge;
