import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View, I18nManager } from 'react-native';
import { Text, Chip } from 'react-native-paper';
import styles from './styles';
import commonStyles from 'app/components/Preview/styles';

import moment from 'moment';

const DueDateLarge = props => {
    const formatedFromDate = moment(props.deadlineFromDate).format('LL');
    const formatedToDate = moment(props.deadlineToDate).format('LL');
    if (formatedFromDate == formatedToDate)
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <View style={{ flex: 1, justifyContent: 'flex-start' }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText, { alignSelf: 'flex-start' }]}>{strings('deadline') + ' ' + strings('on') + ' '}  </Text>
                </View>
                <View style={{ flex: 1, justifyContent: 'flex-end' }}>
                    <Text style={[commonStyles.generalHeading, { alignSelf: 'flex-end', marginEnd: 10 }]}>
                        {formatedFromDate}
                    </Text>
                </View>
            </View>
        );
    else
        return (
            <View style={{ flex: 1 }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('deadline') + ' ' + strings('between') + ' '}</Text>
                </View>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                    <Chip
                        mode="flat"
                        // avatar={<Icon name="error" size={20} style={[styles.iconChips, { margin: 0, padding: 0 }]} />}
                        style={styles.selectedSericesClip}
                        textStyle={{
                            color: '#FFFFFF',
                            margin: 0, padding: 0,
                            textAlign: I18nManager.isRTL ? 'right' : 'left'
                        }}
                    >
                        <Text style={[commonStyles.generalHeading]}>
                            {formatedFromDate}
                        </Text>
                    </Chip>
                    <Text style={[commonStyles.generalHeading]}>
                        {strings('and') + ' '}
                    </Text>
                    <Chip
                        mode="flat"
                        // avatar={<Icon name="error" size={20} style={[styles.iconChips, { margin: 0, padding: 0 }]} />}
                        style={styles.selectedSericesClip}
                        textStyle={{
                            color: '#FFFFFF',
                            margin: 0, padding: 0,
                            textAlign: I18nManager.isRTL ? 'right' : 'left'
                        }}
                    >
                        <Text style={[commonStyles.generalHeading]}>
                            {formatedToDate}
                        </Text>
                    </Chip>
                </View>
            </View>
        );
};
export default DueDateLarge;
