import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';
import commonStyles from 'app/components/Preview/styles';
import DateChip from './DateChip';

import moment from 'moment';

const DueDateLarge = props => {
    const format = props.dashboardNavExpanded ? 'll' : 'LL';
    const formatedFromDate = moment(props.deadlineFromDate).format(format);
    const formatedToDate = moment(props.deadlineToDate).format(format);

    if (formatedFromDate == formatedToDate)
        return (
            <View style={[styles.remarksContainer, { flex: 3, flexDirection: 'row' }]}>
                <View style={{ flex: 1, justifyContent: 'flex-start' }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText, { alignSelf: 'flex-start' }]}>
                        {strings('deadline') + ' ' + strings('on') + ' '}
                    </Text>
                </View>
                <View style={{ justifyContent: 'flex-end', marginEnd: 15 }}>
                    <DateChip date={formatedFromDate} />
                </View>
            </View>
        );
    else
        return (
            <View style={[styles.remarksContainer, { flex: 1, flexDirection: 'row' }]}>
                <View style={{ flex: 2 }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('deadline') + ' ' + strings('between') + ' '}</Text>
                </View>
                <View style={{ flex: 4, flexDirection: 'row', justifyContent: 'flex-end', marginEnd: 15 }}>
                    <DateChip date={formatedFromDate} />
                    <Text style={[commonStyles.generalHeading, { fontSize: 12, marginVertical: 5 }]}>{' & '}</Text>

                    <DateChip date={formatedToDate} />
                </View>
            </View>
        );
};
export default DueDateLarge;
