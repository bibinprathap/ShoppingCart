import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';

import moment from 'moment';

const DueDateSmall = props => {
    const formatedFromDate = moment(props.deadlineFromDate).format('LL');
    const formatedToDate = moment(props.deadlineToDate).format('LL');
    if (formatedFromDate == formatedToDate)
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <Text style={styles.refNumbersmall} numberOfLines={1}>
                    {strings('deadlinePeriod') + ' '}
                </Text>
                <Text style={styles.refNumbersmall} numberOfLines={1}>
                    {strings('on') + ' '}
                    {formatedFromDate}
                </Text>
            </View>
        );
    else
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <Text style={styles.refNumbersmall} numberOfLines={1}>
                    {strings('deadlinePeriod') + ' '}
                </Text>
                <Text style={styles.refNumbersmall} numberOfLines={1}>
                    {strings('between') + ' '}
                    {formatedFromDate}
                </Text>
                <Text style={[styles.refNumbersmall, styles.refNumbersmallTo]} numberOfLines={1}>
                    {' ' + strings('and') + ' '}
                    {formatedToDate}
                </Text>
            </View>
        );
};
export default DueDateSmall;
