import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';
import DateChip from './DateChip';

import moment from 'moment';

const DueDateSmall = props => {
    const format = props.dashboardNavExpanded ? 'll' : 'LL';
    const formatedFromDate = moment(props.deadlineFromDate).format(format);
    const formatedToDate = moment(props.deadlineToDate).format(format);

    if (formatedFromDate == formatedToDate)
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <Text style={[styles.refNumbersmall, { marginTop: 5 }]} numberOfLines={1}>
                    {strings('deadlinePeriod') + ' ' + strings('on') + ' '}
                </Text>
                <DateChip date={formatedFromDate} />
            </View>
        );
    else
        return (
            <View style={{ flex: 3, flexDirection: 'row' }}>
                <Text style={[styles.refNumbersmall, { marginTop: 5 }]} numberOfLines={1}>
                    {strings('deadline') + ' ' + strings('between') + ' '}
                </Text>
                <DateChip date={formatedFromDate} />
                <Text style={[styles.refNumbersmall, { marginTop: 5 }]}>{' & '}</Text>
                <DateChip date={formatedToDate} />
            </View>
        );
};
export default DueDateSmall;
