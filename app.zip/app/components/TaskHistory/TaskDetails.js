import React, { Component } from 'react';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { View, TouchableOpacity, I18nManager, ScrollView } from 'react-native';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import styles from './styles';
import commonStyles from 'app/components/Preview/styles';
import moment from 'moment';
import { Loader } from 'app/components/Loader';
import Icon from 'react-native-vector-icons/MaterialIcons';
import DueDateLarge from './DueDateLarge';

const Taskdetails = props => {
    const readOnlyRtlStyles = I18nManager.isRTL
        ? { flex: 1, textAlign: 'right', alignSelf: 'flex-start' }
        : { flex: 1, textAlign: 'left', alignSelf: 'flex-start' };

    return (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
            <View style={styles.remarksContainer}>
                <Text style={[commonStyles.generalHeading, { paddingVertical: 10 }]}>{props.taskdetails.title}</Text>
            </View>
            <Divider style={commonStyles.divider} />
            <RemarkAndAddressPreview
                generalRemarks={props.taskdetails.remarks}
                address={props.taskdetails.location.address}
                coords={props.taskdetails.location.coords}
                headingmuted={true}
                validations={{}}
            />
            <Divider style={commonStyles.divider} />
            <View style={styles.remarksContainer}>
                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('assignedBy')}</Text>
                <Text style={commonStyles.generalHeading}>{props.taskdetails.assignedBy}</Text>
            </View>
            <Divider style={commonStyles.divider} />
            <View style={[styles.remarksContainer, { flexDirection: 'row' }]}>
                <View style={{ flex: 1, justifyContent: 'flex-start' }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText]}> {strings('fromReferenceNumberShort') + ' '}</Text>
                </View>
                <View style={{ flex: 1, justifyContent: 'flex-end', flexDirection: 'row' }}>
                    <TouchableOpacity onPress={props.onSourceInspectionClick}>
                        <Text style={[commonStyles.generalHeading, { color: '#3ACCE1' }]}>{props.taskdetails.parentRefNo}</Text>
                    </TouchableOpacity>
                    <Icon name="pageview" size={25} style={styles.icon} />
                </View>
            </View>
            <Divider style={commonStyles.divider} />
            {props.taskdetails.refNumber ? <>
                <View style={[styles.remarksContainer, { flexDirection: 'row' }]}>
                    <View style={{ flex: 1, justifyContent: 'flex-start' }}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}> {strings('createdReferenceNumberShort') + ' '}</Text>
                    </View>
                    <View style={{ flex: 1, justifyContent: 'flex-end', flexDirection: 'row' }}>
                        <TouchableOpacity onPress={props.onCreatedInspectionClick}>
                            <Text style={[commonStyles.generalHeading, { color: '#3ACCE1' }]}>{props.taskdetails.refNumber}</Text>
                        </TouchableOpacity>
                        <Icon name="pageview" size={25} style={styles.icon} />
                    </View>
                </View>
                <Divider style={commonStyles.divider} />
            </> : null}
            <View style={[styles.remarksContainer, { flexDirection: 'row' }]}>
                <View style={{ flex: 1, justifyContent: 'flex-start' }}>
                    <Text style={[commonStyles.generalText, commonStyles.mutedText, { alignSelf: 'flex-start' }]}>{strings('assignedDate')}</Text>
                </View>
                <View style={{ flex: 1, justifyContent: 'flex-end' }}>
                    <Text style={[commonStyles.generalHeading, { alignSelf: 'flex-end', marginEnd: 10 }]}>
                        {moment(props.taskdetails.assignedDate).format('LL')}
                    </Text>
                </View>
            </View>
            <Divider style={commonStyles.divider} />
            <View style={styles.remarksContainer}>
                <DueDateLarge deadlineFromDate={props.taskdetails.deadlineFromDate} deadlineToDate={props.taskdetails.deadlineToDate} />
            </View>
            <Divider style={styles.divider} />
            <View style={styles.summaryContainer}>
                {!props.taskdetails.refNumber ? <View style={styles.summaryItem}>
                    <Loader loading={false} spinnerStyle={{ marginBottom: 20 }}>
                        <Icon.Button
                            name={'play-circle-filled'}
                            borderRadius={25}
                            style={[styles.button, styles.buttonPositive]}
                            onPress={props.onStartClick}
                        >
                            <Text style={styles.buttonText}>{strings('start')}</Text>
                        </Icon.Button>
                    </Loader>
                </View> : null}
                <View style={styles.summaryItem}>
                    <Icon.Button name="arrow-back" borderRadius={25} style={[styles.button, styles.buttonNegative]} onPress={props.onBackClick}>
                        <Text style={styles.buttonText}>{strings('back')}</Text>
                    </Icon.Button>
                </View>
            </View>
        </ScrollView>
    );
};
export default Taskdetails;
