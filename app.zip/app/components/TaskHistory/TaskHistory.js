import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Title, Headline, Text, TouchableRipple } from 'react-native-paper';
import moment from 'moment';
import { strings } from 'app/config/i18n/i18n';
import { Timeline } from 'app/components/Timeline';
import { tasksHelper } from 'app/api/helperServices';
import TaskDetails from './TaskDetails';
import IconFontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from './styles';
import DueDateSmall from './DueDateSmall';
import TaskStatus from './TaskStatus';
import images from 'app/images';
import { getTaskDetails } from 'app/actions/tasks';
class TaskHistory extends Component {
    static propTypes = {
        local: PropTypes.string,
        history: PropTypes.object,
        onSelect: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            sortasc: false,
            showTaskDetails: false,
        };
        this.sortHistory = this.sortHistory.bind(this);
        this.showTaskDetails = this.showTaskDetails.bind(this);
    }
    handleOnPress = (task, refNumber) => {
        const taskId = refNumber;
        this.props.dispatch(getTaskDetails(taskId)).then(this.showTaskDetails);
    };
    showTaskDetails = taskId => {
        this.props.onSelect && this.props.onSelect(this.props.history[taskId], taskId);
        this.setState({ showTaskDetails: true });
    };
    handleHideTaskHistorySelection = item => {
        this.setState({ showTaskDetails: false });
    };

    sortHistory = () => {
        this.setState({ sortasc: !this.state.sortasc });
    };
    componentDidUpdate(prevProps) {
        if (prevProps.navigationPressedTime) {
            if (prevProps.navigationPressedTime !== this.props.navigationPressedTime) this.setState({ showTaskDetails: false });
        }
    }
    render() {
        const {
            history,
            onStartClick,
            taskdetails,
            overdue,
            showOverdue,
            onSourceInspectionClick,
            onCreatedInspectionClick,
            dashboardNavExpanded,
        } = this.props;
        const { showTaskDetails } = this.state;

        let visibleTaskList = history;
        if (showOverdue) visibleTaskList = overdue;

        const tasks = Object.keys(visibleTaskList).map(refNumber => {
            const task = visibleTaskList[refNumber];
            return { task, refNumber };
        });
        function compareAsc(a, b) {
            if (a.task.assignedDate < b.task.assignedDate) {
                return -1;
            }
            if (a.task.assignedDate > b.task.assignedDate) {
                return 1;
            }
            return 0;
        }
        function compareDsc(a, b) {
            if (a.task.assignedDate > b.task.assignedDate) {
                return -1;
            }
            if (a.task.assignedDate < b.task.assignedDate) {
                return 1;
            }
            return 0;
        }
        let sortedtask = [];
        if (this.state.sortasc) sortedtask = tasks.sort(compareAsc);
        else sortedtask = tasks.sort(compareDsc);

        const historyContent = sortedtask.map(taskRefNumber => {
            const task = taskRefNumber.task;
            const refNumber = taskRefNumber.refNumber;
            return (
                <View key={refNumber} style={styles.historyItem}>
                    <TouchableOpacity onPress={() => this.handleOnPress(task, refNumber)} style={styles.touchWrapper}>
                        {task.icon.type === 'custom' && (
                            <Image
                                source={images[task.icon.name].content}
                                style={[
                                    styles.icon,
                                    { position: 'absolute', top: 0, right: 0, borderRadius: 10, backgroundColor: '#39579A', width: 20, height: 20 },
                                ]}
                            />
                        )}

                        <View>
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <Text style={styles.createdDate}>{moment(task.assignedDate).fromNow()}</Text>
                                <TaskStatus status={task.status} />
                            </View>
                            {!!task.title && <Text style={styles.servicesTitle}>{task.title}</Text>}
                            {task.parentRefNo ? (
                                <Text style={styles.refNumbersmall} numberOfLines={1}>
                                    {strings('fromReferenceNumberShort')} - {task.parentRefNo}
                                </Text>
                            ) : null}
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <DueDateSmall
                                    dashboardNavExpanded={dashboardNavExpanded}
                                    deadlineFromDate={task.deadlineFromDate}
                                    deadlineToDate={task.deadlineToDate}
                                />
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        });
        if (showTaskDetails) {
            return (
                <TaskDetails
                    onStartClick={onStartClick}
                    onCreatedInspectionClick={onCreatedInspectionClick}
                    onSourceInspectionClick={onSourceInspectionClick}
                    taskdetails={taskdetails}
                    onBackClick={this.handleHideTaskHistorySelection}
                    dashboardNavExpanded={dashboardNavExpanded}
                />
            );
        } else if (!historyContent || (!!historyContent && historyContent.length == 0)) {
            return (
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <Headline>{!showOverdue ? strings('tasks') : strings('overdue') + ' ' + strings('tasks')}</Headline>
                    <Title>{!showOverdue ? strings('taskisempty') : strings('noOverdueTask')} </Title>
                </View>
            );
        } else {
            return (
                <>
                    <Text style={styles.historyHeading}>{showOverdue ? strings('allOverdueTasks') : strings('tasksDescription')}</Text>
                    <View
                        style={{
                            flex: 1,
                            justifyContent: 'center',
                            alignItems: 'center',
                            position: 'absolute',
                            top: 0,
                            right: 10,
                        }}
                    >
                        <TouchableRipple onPress={this.sortHistory}>
                            <View
                                style={{
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    width: 50,
                                    height: 50,
                                }}
                            >
                                <IconFontAwesome
                                    name={this.state.sortasc ? 'sort-alpha-asc' : 'sort-alpha-desc'}
                                    size={20}
                                    style={styles.sortAscORDsc}
                                />
                            </View>
                        </TouchableRipple>
                    </View>
                    <Timeline data={historyContent} renderItem={({ item }) => item} />
                </>
            );
        }
    }
}

mapStateToProps = state => {
    const history = tasksHelper.getTaskHistory({
        domainCustomerId: state.auth.activeProfileDomainCustomerId,
        allHistory: state.tasks.history,
    });
    const overdue = tasksHelper.getOverDueTaskHistory({
        history,
    });
    return {
        locale: state.settings.locale,
        history: history || {},
        overdue: overdue || {},
    };
};

export default connect(mapStateToProps)(TaskHistory);
