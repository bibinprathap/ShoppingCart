import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Title, Headline, Text, TouchableRipple } from 'react-native-paper';
import moment from 'moment';
import { strings } from 'app/config/i18n/i18n';
import { Timeline } from 'app/components/Timeline';
import { tasksHelper } from 'app/api/helperServices';
import TaskDetails from './TaskDetails';
import IconFontAwesome from 'react-native-vector-icons/FontAwesome';
import styles from './styles';
class TaskHistory extends Component {
    static propTypes = {
        local: PropTypes.string,
        history: PropTypes.object,
        onSelect: PropTypes.func,
    };

    constructor(props) {
        super(props);
        this.state = {
            sortasc: true
        };
        this.sortHistory = this.sortHistory.bind(this);
    }
    handleOnPress = (task, refNumber) => {
        this.props.onSelect && this.props.onSelect(task, refNumber);
    };

    sortHistory = () => {
        this.setState({ sortasc: !this.state.sortasc })
    }

    render() {
        const { history, showTaskDetails, onStartClick, onBackClick, taskdetails } = this.props;
        console.log(history);
        const historyContent = Object.keys(history).map(refNumber => {
            const task = history[refNumber];
            return (
                <View key={refNumber} style={styles.historyItem}>
                    <TouchableOpacity onPress={() => this.handleOnPress(task, refNumber)} style={styles.touchWrapper}>
                        <View>
                            <Text style={styles.createdDate}>{moment(task.assignedDate).fromNow()}</Text>
                            {!!task.title && <Text style={styles.servicesTitle}>{task.title}</Text>}
                            <Text style={styles.refNumbersmall} numberOfLines={1}>
                                {strings('fromReferenceNumberShort')} - {task.parentRefNo}
                            </Text>
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <View style={{ flex: 1 }}>
                                    <Text style={styles.refNumbersmall} numberOfLines={1}>
                                        {strings('deadlinePeriod')}
                                    </Text>
                                </View>
                                <View style={{ flex: 3 }}>
                                    <Text style={styles.refNumbersmall} numberOfLines={1}>
                                        {strings('from')}
                                        {moment(task.deadlineFromDate).format('YYYY-MM-DD HH:mm:ss')}
                                    </Text>
                                    <Text style={[styles.refNumbersmall, styles.refNumbersmallTo]} numberOfLines={1}>
                                        {strings('to')}
                                        {moment(task.deadlineToDate).format('YYYY-MM-DD HH:mm:ss')}
                                    </Text>
                                </View>
                            </View>
                        </View>
                    </TouchableOpacity>
                </View>
            );
        });
        if (showTaskDetails) {
            return (<TaskDetails
                onStartClick={onStartClick}
                taskdetails={taskdetails}
                onBackClick={onBackClick}
            />);
        }
        else if (!historyContent || (!!historyContent && historyContent.length == 0)) {
            return (
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        alignItems: 'center',
                    }}
                >
                    <Headline>Tasks</Headline>
                    <Title>Task is empty</Title>
                </View>
            );
        } else {
            return <View
                style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                }}
            >
                <TouchableRipple onPress={this.sortHistory}>
                    <IconFontAwesome name={this.state.sortasc ? "sort-alpha-asc" : "sort-alpha-desc"} size={50} style={styles.sortAscORDsc} />
                </TouchableRipple>
                <Timeline data={historyContent} renderItem={({ item }) => item} />
            </View>
        }
    }
}

mapStateToProps = state => {
    const history = tasksHelper.getTaskHistory({
        domainCustomerId: state.auth.activeProfileDomainCustomerId,
        allHistory: state.tasks.history,
    });
    return {
        locale: state.settings.locale,
        history: history || {},
    };
};

export default connect(mapStateToProps)(TaskHistory);
