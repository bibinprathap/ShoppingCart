import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';

const TaskStatus = props => {
    let backgroundcolor = '#058DFC';
    if (props.status == 'completed') backgroundcolor = '#008000';
    else if (props.status == 'InProgress') backgroundcolor = '#959DAD';
    return (
        <View style={{ borderRadius: 10, maxWidth: 80, backgroundColor: backgroundcolor, marginHorizontal: 15 }}>
            <Text style={[styles.refNumbersmall, { alignSelf: 'center', color: '#ffffff', paddingHorizontal: 5 }]} numberOfLines={1}>
                {strings(props.status)}
            </Text>
        </View>
    );
};
export default TaskStatus;
