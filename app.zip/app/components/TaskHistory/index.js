import styles from './styles';
import TaskHistory from './TaskHistory';
import TaskDetails from './TaskDetails';

export { styles, TaskHistory, TaskDetails };
