import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {},
    historyItem: {
        flex: 1,
        margin: 10,
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    touchWrapper: { flex: 1 },
    createdDate: { fontSize: '$primaryTextXS' },
    servicesTitle: { fontSize: '$primaryTextSM', alignSelf: 'flex-start', textAlign: I18nManager.isRTL ? 'right' : 'left' },
    refNumber: { fontSize: '$primaryTextSM', alignSelf: 'flex-start', textAlign: I18nManager.isRTL ? 'right' : 'left' },
    refNumbersmall: { fontSize: '$primaryTextXS', alignSelf: 'flex-start', textAlign: I18nManager.isRTL ? 'right' : 'left' },
    refNumbersmallTo: {},
    lableReadOnly: {
        fontSize: '$primaryTextXS',
        color: '$primaryMediumTextColor',
    },

    valueReadOnlyText: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
    remarksContainer: {
        width: '100%',
        marginHorizontal: 10,
    },
    summaryContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 80,
        width: '100%',
        marginVertical: 10,
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
    historyHeading: {
        marginHorizontal: 10,
        marginVertical: 10,
    },
    selectedSericesClip: {
        backgroundColor: '$primaryValidationChipColor',
        color: '$primaryLightTextColor',
        padding: 0,
        margin: 0,
    },
});
