import React from 'react';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { Icon } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';

const taskTypeIcons = {
    followup: 'reply',
    incident: 'alarm-light-outline',
    ondemand: 'calendar-clock',
};
const TaskType = props => {
    const { taskTypeConst = '', textProps, textStyle, iconProps, iconStyle } = props;
    let translatedTaskName = localeProperty(props, 'taskTypeName');
    if (!translatedTaskName) translatedTaskName = strings(taskTypeConst);

    return (
        <View style={styles.container}>
            <Icon
                type="MaterialCommunityIcons"
                name={taskTypeIcons[taskTypeConst]}
                style={styles.icon}
                color={styles.icon.color}
                size={24}
                style={iconStyle}
                {...iconProps}
            />
            <Text style={[styles.text, textStyle]} numberOfLines={1} {...textProps}>
                {translatedTaskName}
            </Text>
        </View>
    );
};
export default TaskType;

const styles = EStyleSheet.create({
    container: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
    },
    icon: { color: '$primaryHeaderColor' },
    text: {
        color: '$primaryHeaderColor',
        fontSize: '$primaryTextXXS',
        paddingHorizontal: 5,
        alignSelf: 'center',
        //textAlign: I18nManager.isRTL ? 'right' : 'left',
        textAlign: 'center',
        textAlignVertical: 'center',
    },
});
