import React, { Component } from 'react';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import PropTypes from 'prop-types';
import { View, Text, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Image from 'app/components/Image/Image';
import styles from './styles';

class Thumbnail extends React.PureComponent {
    static propTypes = {
        id: PropTypes.any,
        //attachment: PropTypes.object,
        hideDelete: PropTypes.bool,
        thumbnailSize: PropTypes.string,
        thumbnailType: PropTypes.string,
        aspectRatio: PropTypes.string,
        onPress: PropTypes.func,
        onRemove: PropTypes.func,
    };

    handleOnPress = () => {
        if (this.props.onPress) this.props.onPress(this.props.id);
    };

    removeOnPress = () => {
        if (this.props.onRemove) this.props.onRemove(this.props.id);
    };

    render() {
        const { attachment, ...rest } = this.props;
        if (typeof attachment === 'undefined') return null;
        if (attachment && attachment.mediaType == 'image') return this.renderImage(attachment, rest);
        else {
            return (
                <View style={{ borderWidth: 1, borderColor: 'red', margin: 5 }}>
                    <Text style={{ color: 'white' }}>
                        Todo: handle mediaType {attachment.mediaType}
                        Id {this.props.id}
                    </Text>
                </View>
            );
        }
    }

    renderImage = (image, { aspectRatio = 'auto', editable = false, hideDelete = false, thumbnailType = 'default', thumbnailSize = 'large' }) => {
        if (!image) return <Icon name="broken-image" color={styles.brokenImageIcon.color} size={containerHeight / 2} />;
        if (!!image) {
            const imageStyles = {};
            switch (thumbnailSize) {
                case 'medium':
                    imageStyles.width = 50;
                    imageStyles.height = 50;
                    break;
                case 'small':
                    imageStyles.width = 35;
                    imageStyles.height = 35;
                    break;
                default:
                    imageStyles.width = 70;
                    imageStyles.height = 70;
                    break;
            }

            switch (thumbnailType) {
                case 'rounded':
                    imageStyles.borderRadius = imageStyles.width / 2;
                    break;
                default:
                    imageStyles.borderRadius = 5;
                    break;
            }

            return (
                <View style={styles.container}>
                    <TouchableOpacity onPress={this.handleOnPress}>
                        <View style={[styles.innerContainer]}>
                            <Image
                                authCode={this.props.authCode}
                                style={[imageStyles, this.props.selected && styles.selectedImage]}
                                source={{ uri: image.path, uploading: image.uploading, uploaded: image.uploaded, error: image.error }}
                                resizeMode={'cover'}
                            />
                        </View>
                    </TouchableOpacity>
                    {editable && !hideDelete && (
                        <TouchableOpacity style={styles.removeIcon} onPress={this.removeOnPress}>
                            <Icon name="delete" size={14} color="#CCCCCC" />
                        </TouchableOpacity>
                    )}
                </View>
            );
        }
    };
}

mapStateToProps = (state, ownProps) => {
    const attachment = ownProps.id && _.find(state.attachments.docs, docItem => docItem.id == ownProps.id);

    return { attachment };
};

export default connect(mapStateToProps)(Thumbnail);
