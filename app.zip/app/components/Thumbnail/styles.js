import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        justifyContent: 'center',
        alignContent: 'center',
        paddingHorizontal: 2,
        backgroundColor: 'transparent',
    },
    innerContainer: {
        paddingRight: 5,
    },
    image: {},
    selectedImage: {
        borderWidth: '$primaryBorderThick',
        borderColor: '$primaryHeaderColor',
    },
    brokenImageIcon: {
        color: '$primaryLightTextColor',
    },
    removeIcon: {
        position: 'absolute',
        top: 8,
        right: 5,
        padding: 3,
        borderRadius: 13,
        backgroundColor: 'rgba(1,1,1,0.3)',
    },
});
