import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, FlatList } from 'react-native';
import * as Animatable from 'react-native-animatable';
import styles from './styles';

class Timeline extends React.PureComponent {
    renderTimelineItem = renderItemProps => {
        const {
            renderItem,
            containerStyle,
            lineContainerStyle,
            topLineStyle,
            botomLineStyle,
            dotContainerStyle,
            contentContainerStyle,
            ...otherProps
        } = this.props; //component props
        const { item, index, separators } = renderItemProps;
        const _containerStyles = [styles.container, containerStyle === undefined ? null : containerStyle];
        const _lineContainerStyles = [styles.lineContainer, lineContainerStyle === undefined ? null : lineContainerStyle];
        const _topLineStyles = [
            styles.line,
            topLineStyle === undefined ? null : topLineStyle,
            index === 0 ? styles.hiddenTopLine : null,
            index === this.dataLendth - 1 ? styles.croppedTopLine : null,
        ];
        const _botomLineStyles = [
            styles.line,
            botomLineStyle === undefined ? null : botomLineStyle,
            index === this.dataLendth - 1 ? styles.hiddenBottomLine : null,
        ];
        const _dotContainerStyles = [styles.dotContainer, dotContainerStyle === undefined ? null : dotContainerStyle];
        const _contentContainerStyles = [styles.contentContainer, contentContainerStyle === undefined ? null : contentContainerStyle];
        return (
            <Animatable.View
                style={_containerStyles}
                animation="fadeInDown"
                duration={300}
                useNativeDriver={true}
                //easing="ease-out"
                delay={index * 75}
            >
                <View style={_lineContainerStyles}>
                    <View style={styles.lineCover}>
                        <View style={_topLineStyles} />
                    </View>
                    <View style={styles.lineCover}>
                        <View style={_botomLineStyles} />
                    </View>
                    <View style={_dotContainerStyles} />
                </View>
                <View style={_contentContainerStyles}>{renderItem(renderItemProps)}</View>
            </Animatable.View>
        );
    };

    render() {
        this.dataLendth = !!this.props.data ? this.props.data.length : 0;
        const { renderItem, ...otherProps } = this.props;
        //console.log('Timeline.render()');
        return (
            <FlatList
                {...otherProps}
                //data={inspectionData.def.checklistGroups}
                //keyExtractor={this.keyExtractor}
                renderItem={this.renderTimelineItem}
            />
        );
    }
}
export default Timeline;
