import EStyleSheet from 'react-native-extended-stylesheet';
const dotTopMargin = 25;
export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    lineContainer: {
        width: 20,
        alignItems: 'center',
    },
    lineCover: {
        flex: 1,
        width: '$primaryBorderThin',
        maxWidth: '$primaryBorderThin',
    },
    line: {
        opacity: 0.2,
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderStyle: 'dashed',
        borderRadius: 1,
    },
    dotContainer: {
        position: 'absolute',
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: '$primaryMediumTextColor',
        marginTop: dotTopMargin,
        alignItems: 'center',
    },
    contentContainer: {
        flex: 1,
    },
    hiddenTopLine: {
        marginTop: dotTopMargin,
    },
    croppedTopLine: {
        //usefull for the last item, if it expanded
        maxHeight: dotTopMargin,
    },
    hiddenBottomLine: {
        opacity: 0,
    },
});
