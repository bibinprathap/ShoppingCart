import EStyleSheet from 'react-native-extended-stylesheet';
const dotTopMargin = 25;
export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    lineContainer: {
        width: 20,
        alignItems: 'center',
    },
    line: {
        opacity: 0.2,
    },
    topLineContainer: {
        flex: 1,
        width: '$primaryBorderThick',
        backgroundColor: '$primaryMediumTextColor',
    },
    botomLineContainer: {
        flex: 1,
        width: '$primaryBorderThick',
        backgroundColor: '$primaryMediumTextColor',
    },
    dotContainer: {
        position: 'absolute',
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: '$primaryMediumTextColor',
        marginTop: dotTopMargin,
        alignItems: 'center',
    },
    contentContainer: {
        flex: 1,
    },
    hiddenTopLine: {
        marginTop: dotTopMargin,
    },
    croppedTopLine: {
        //usefull for the last item, if it expanded
        maxHeight: dotTopMargin,
    },
    hiddenBottomLine: {
        opacity: 0,
    },
});
