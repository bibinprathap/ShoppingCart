import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, TouchableOpacity, I18nManager, Dimensions } from 'react-native';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';

class ViolationsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            items: null,
            loading: false,

            selectedItems2: [],
            selectedItemObjects: [],
            currentItems: [],
            showDropDowns: false,
            single: false,
            readOnlyHeadings: false,
            highlightChildren: false,
            selectChildren: false,
            hasErrored: false,
        };
        this.termId = 100;
    }

    onSelectedItemsChange = selectedItems => {
        this.props.onValueChange(selectedItems);
    };
    onConfirm = () => {
        this.setState({ currentItems: this.props.selectedItems });
    };
    onCancel = () => {
        this.SectionedMultiSelect._removeAllItems();

        this.props.onValueChange(this.state.currentItems);
        // this.setState({
        //     selectedItems: this.state.currentItems,
        // })
        // console.log(this.state.selectedItems);
    };
    onSelectedItemObjectsChange = selectedItemObjects => {
        this.setState({ selectedItemObjects });
        console.log(selectedItemObjects);
    };
    renderSelectText = () => {
        const { selectedItems } = this.props;
        return selectedItems.length ? `${selectedItems.length}  ${strings('violationsSelected')}` : strings('selectViolation');
    };
    SelectOrRemoveAll = () =>
        this.SectionedMultiSelect && (
            <TouchableOpacity
                style={styles.selectOrRemoveAll}
                onPress={this.props.selectedItems.length ? this.SectionedMultiSelect._removeAllItems : this.SectionedMultiSelect._selectAllItems}
            >
                <Text style={{ color: 'white', fontWeight: 'bold' }}>
                    {this.props.selectedItems.length ? strings('remove') : strings('select')} {strings('allViolation')}
                </Text>
            </TouchableOpacity>
        );

    onToggleSelector = toggled => {
        console.log('selector is ', toggled ? 'open' : 'closed');
    };

    render() {
        const remainingViolations = inspectionsHelper.getRemainingViolationsForSelectOptions(
            this.props.violations,
            this.props.violators,
            this.props.selectedItems
        );
        //  const remainingViolations = this.props.violations;
        const modalHeight = 200 + remainingViolations.length * 35;
        return (
            <View style={styles.violationsSelectionContainer}>
                <View style={styles.labelContainer}>
                    <Text style={styles.label}>{strings('violations')}</Text>
                </View>
                <View>
                    <SectionedMultiSelect
                        items={remainingViolations}
                        style={styles.violationsMultiselect}
                        ref={SectionedMultiSelect => (this.SectionedMultiSelect = SectionedMultiSelect)}
                        uniqueKey="id"
                        displayKey="title"
                        iconKey="icon"
                        hideConfirm={!this.props.editable}
                        hideSelect={!this.props.editable}
                        modalWithTouchable
                        headerComponent={this.SelectOrRemoveAll}
                        searchPlaceholderText={strings('searchViolations')}
                        removeAllText={strings('removeAll')}
                        loading={this.state.loading}
                        chipsPosition="bottom"
                        renderSelectText={this.renderSelectText}
                        loadingComponent={<View hasErrored={this.state.hasErrored} fetchCategories={this.fetchCategories} />}
                        chipRemoveIconComponent={
                            !this.props.editable ? (
                                <View
                                    style={{
                                        marginHorizontal: 6,
                                    }}
                                />
                            ) : (
                                <Icon
                                    style={{
                                        fontSize: 18,
                                        marginHorizontal: 6,
                                    }}
                                >
                                    cancel
                                </Icon>
                            )
                        }
                        showDropDowns={this.state.showDropDowns}
                        expandDropDowns={this.state.expandDropDowns}
                        animateDropDowns={false}
                        readOnlyHeadings={this.state.readOnlyHeadings}
                        single={this.state.single}
                        filterItems={this.filterItems}
                        onSelectedItemsChange={this.onSelectedItemsChange}
                        onSelectedItemObjectsChange={this.onSelectedItemObjectsChange}
                        onCancel={this.onCancel}
                        onConfirm={this.onConfirm}
                        onToggleSelector={this.onToggleSelector}
                        confirmText={strings('confirm')}
                        selectedItems={this.props.selectedItems}
                        colors={{ primary: this.props.selectedItems.length ? 'forestgreen' : 'crimson' }}
                        itemNumberOfLines={3}
                        selectLabelNumberOfLines={3}
                        styles={{
                            chipText: {
                                maxWidth: Dimensions.get('screen').width - 90,
                            },
                            itemText: {
                                color: this.props.selectedItems.length ? 'lightgrey' : '#959DAD',
                                fontWeight: 'normal',
                                fontSize: 18,
                            },
                            selectedItemText: {
                                color: '#349EFB',
                            },
                            selectedSubItemText: {
                                color: '#349EFB',
                            },
                            button: {
                                borderRadius: 25,
                                justifyContent: 'center',
                                alignItems: 'center',
                                backgroundColor: this.props.selectedItems.length ? '#3ACCE1' : '#2A2E43',
                                marginBottom: 10,
                            },
                            container: {
                                height: modalHeight > 900 ? '90%' : modalHeight,
                                flex: 0,
                            },
                        }}
                        cancelIconComponent={<Icon size={20} name="close" style={{ color: 'white' }} />}
                    />
                </View>
            </View>
        );
    }
}

export default ViolationsList;
