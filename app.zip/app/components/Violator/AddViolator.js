import React, { Component } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, Picker, Modal } from 'react-native';
import { Icon, Switch, SimpleViolatorInfo } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import ViolatorDialog from 'app/screens/inspection/ViolationDetails/ViolatorDialog';
import AddViolatorButton from 'app/screens/inspection/ViolationDetails/AddViolatorButton';
import EStyleSheet from 'react-native-extended-stylesheet';
import { SignatureDialog } from 'app/screens';

const styles = EStyleSheet.create({
    row: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    rowContainer: {
        margin: 5,
        marginVertical: 5,
        borderRadius: 5,
        backgroundColor: '$primaryWhite',
    },
    iconDark: {
        color: '$primaryDarkTextColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
    },
    signatureReadOnly: {
        color: '$selectedItemBackgroundColor',
    },
    iconWrapper: {
        flexDirection: 'column',
        justifyContent: 'space-between',
    },
    iconButton: {
        padding: 5,
    },
});

export default class AddViolator extends Component {
    constructor(props) {
        super(props);
        this.state = { signatureDialogVisible: false };
        this.handleSignatureDialogRequestClose = this.handleSignatureDialogRequestClose.bind(this);
        this.handleOnAddSignature = this.handleOnAddSignature.bind(this);
        this.handleReconciliationChange = this.handleReconciliationChange.bind(this);
        this.showSignature = this.showSignature.bind(this);
    }

    showSignature = () => {
        this.setState({ signatureDialogVisible: true });
    };

    handleSignatureDialogRequestClose = () => {
        this.setState({ signatureDialogVisible: false });
    };

    handleOnAddSignature = attachment => {
        const { onReconciled, violator = {} } = this.props;
        if (typeof onReconciled === 'function') onReconciled({ reconciled: true, attachment, violatorId: violator.violatorId });
        this.setState({ signatureDialogVisible: false });
    };

    handleReconciliationChange = value => {
        const { onReconciled, reconciled, violator } = this.props;
        if (reconciled) {
            if (typeof onReconciled === 'function') onReconciled({ reconciled: false, attachment: null, violatorId: violator.violatorId });
        } else {
            this.setState({ signatureDialogVisible: true });
        }
    };

    customActionsForViolatorInfo = () => {
        const { inspTypeCheckItemId, violationTypeId, violator, onViolatorRemoved, onViolatorEdited, reconciledViolators, editable } = this.props;

        const handleOnViolatorRemoved = () => {
            if (typeof onViolatorRemoved === 'function') onViolatorRemoved(inspTypeCheckItemId, violator.violatorId);
        };
        const handleOnViolatorEditPressed = () => {
            this.violatorDialog.showEdit(violator);
        };
        const handleOnViolatorEdited = (violator, changed) => {
            if (typeof onViolatorEdited === 'function') onViolatorEdited({ editedViolator: violator, inspTypeCheckItemId, changed, violationTypeId });
        };
        const handleViolatorDialogRef = ref => {
            this.violatorDialog = ref;
        };

        if (editable) {
            return (
                <View style={styles.iconWrapper}>
                    <ViolatorDialog
                        ref={handleViolatorDialogRef}
                        onViolatorEdited={handleOnViolatorEdited}
                        reconciledViolators={reconciledViolators}
                    />
                    <TouchableOpacity onPress={handleOnViolatorRemoved} style={styles.iconButton}>
                        <Icon type="MaterialCommunityIcons" name="delete" size={20} style={styles.iconDark} />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={handleOnViolatorEditPressed} style={styles.iconButton}>
                        <Icon type="MaterialCommunityIcons" name="pencil" size={20} style={styles.iconDark} />
                    </TouchableOpacity>
                </View>
            );
        }
        if (violator && violator.signature) {
            return (
                <View style={styles.iconWrapper}>
                    <TouchableOpacity onPress={this.showSignature} style={styles.iconButton}>
                        <Icon type="AdmIcon" name="wf-1210" size={25} style={[styles.iconDark, styles.signatureReadOnly]} />
                    </TouchableOpacity>
                </View>
            );
        }
        return null;
    };

    handleOnViolatorSelected = (selectedViolator, changed) => {
        const { onViolatorSelected, violationTypeId } = this.props;
        if (typeof onViolatorSelected === 'function') onViolatorSelected({ selectedViolator, changed, violationTypeId });
    };

    handleOnViolatorEdited = (editedViolator, changed) => {
        const { onViolatorEdited, inspTypeCheckItemId, violationTypeId } = this.props;
        if (typeof onViolatorEdited === 'function') onViolatorEdited({ editedViolator, inspTypeCheckItemId, changed, violationTypeId });
    };

    reconciliationLabel = () => <Text style={styles.label}>{strings('isReconciled')}</Text>;

    render() {
        const { editable, violator, buttonText, reconciled, inspection, showReconciliation } = this.props;
        const { signatureDialogVisible } = this.state;
        const possibleViolatorTypes = this.props.possibleViolatorTypes || ['individual', 'vehicle', 'company'];
        return (
            <View style={styles.rowContainer}>
                <View style={[styles.row]}>
                    <View style={{ flex: 1 }}>
                        {violator && (
                            <SimpleViolatorInfo
                                key={violator.violatorId}
                                violator={violator}
                                editable={editable}
                                customActions={this.customActionsForViolatorInfo}
                            />
                        )}
                    </View>
                </View>
                {!violator && editable && (
                    <View style={styles.row}>
                        <View style={{ flex: 1 }}>
                            <View style={{ marginTop: 5, justifyContent: 'flex-start', alignItems: 'flex-start' }}>
                                <AddViolatorButton
                                    {...this.props}
                                    showModalDefault={true}
                                    selectLabel={buttonText || strings('addViolator')}
                                    possibleViolatorTypes={possibleViolatorTypes}
                                    onViolatorSelected={this.handleOnViolatorSelected}
                                    onViolatorEdited={this.handleOnViolatorEdited}
                                    onViolatorRemoved={this.handleOnViolatorRemoved}
                                />
                            </View>
                        </View>
                    </View>
                )}
                {(showReconciliation && (
                    <View style={{ alignItems: 'flex-end', flex: 1 }}>
                        <SignatureDialog
                            visible={signatureDialogVisible}
                            onRequestClose={this.handleSignatureDialogRequestClose}
                            editable={!reconciled && editable}
                            inspection={inspection}
                            onAddSignature={this.handleOnAddSignature}
                            violator={violator}
                            value={violator && violator.signature}
                        />
                        <View style={{ flex: 1 }}>
                            <View style={{ justifyContent: 'flex-end', alignItems: 'flex-end', marginVertical: 10 }}>
                                <Switch
                                    editable={editable}
                                    showHint={false}
                                    onChange={this.handleReconciliationChange}
                                    value={reconciled}
                                    renderLabel={this.reconciliationLabel}
                                    label={strings('isReconciled')}
                                    iconProps={{ name: 'face', type: 'MaterialCommunityIcons', size: 24 }}
                                />
                            </View>
                        </View>
                    </View>
                )) ||
                    null}
            </View>
        );
    }
}
