import React from 'react';
import { View, Text, SafeAreaView, ScrollView, I18nManager } from 'react-native';
import { ViolatorIcon, ViolatorLabel } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import moment from 'moment';

export default function CompanyViolatorDetailInfo({ violator, onDetailLoaded }) {
    debugger;
    const { violatorType, detail, idNumber, registeredPhoneNumber } = violator || {};
    const { identityExpiryDate, email, fax, landLine, mobile, pobox, website } = detail;
    const getFormatedDate = date => {
        return date ? moment(date).format('LL') : '';
    };

    return (
        <SafeAreaView style={{ margin: 10 }}>
            <View style={styles.violatorContent}>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="idLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{idNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('tradeLicenseExpiryDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(identityExpiryDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="nationalityLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'nationalityName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{registeredPhoneNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('addressCity')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'addressCityName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('emirateName')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'emirateName')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('address')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'address')}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('fax')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{fax}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('landLine')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{landLine}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('pobox')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{pobox}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('website')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{website}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('email')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{email}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('mobileNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{mobile}</Text>
                        </View>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = EStyleSheet.create({
    icon: { margin: 5 },
    violatorContent: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
        //justifyContent: 'center',
    },
    idLabel: { marginRight: 10 },
    otherDetailContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 6,
    },
    otherDetailItem: {
        flex: 1,

        alignItems: 'flex-start',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    normalText: {
        fontSize: '$primaryTextSM',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
    valueText: {
        fontSize: '$primaryTextSM',
    },
    activeIcon: {
        color: '$primaryHeaderColor',
    },
});
