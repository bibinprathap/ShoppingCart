import React from 'react';
import { View, Text, SafeAreaView, ScrollView, I18nManager } from 'react-native';
import { ViolatorIcon, ViolatorLabel } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import IndividualViolatorDetailInfo from './IndividualViolatorDetailInfo';
import CompanyViolatorDetailInfo from './CompanyViolatorDetailInfo';
import VehicleViolatorDetailInfo from './VehicleViolatorDetailInfo';
import moment from 'moment';

export default function DetailViolatorInfo({ violator, onDetailLoaded }) {
    debugger;
    const { violatorType, detail } = violator || {};
    const { identificationExpiryDate } = detail;
    const getFormatedDate = date => {
        return date ? moment(identificationExpiryDate).format('LL') : '';
    };

    return (
        <SafeAreaView style={{ margin: 10 }}>
            <View style={styles.violatorItem}>
                <View style={styles.violatorContent}>
                    <View style={styles.titleAndIdContainer}>
                        <View style={{ alignItems: 'center', justifyContent: 'center', padding: 3 }}>
                            <ViolatorIcon key={violatorType} violatorType={violatorType} size={24} icon={styles.icon} />
                        </View>
                        <View style={styles.titleContainer}>
                            <Text style={styles.titleText}>{localeProperty(violator, 'title')}</Text>
                        </View>
                    </View>

                    <ScrollView>
                        <View style={{ marginBottom: 20 }}>
                            {violatorType == 'individual' ? (
                                <IndividualViolatorDetailInfo violator={violator} />
                            ) : violatorType == 'company' ? (
                                <CompanyViolatorDetailInfo violator={violator} />
                            ) : (
                                <VehicleViolatorDetailInfo violator={violator} />
                            )}
                        </View>
                    </ScrollView>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = EStyleSheet.create({
    rowContainer: {
        borderStyle: 'solid',
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        minHeight: 40,
    },
    rowContent: {
        flex: 1,
        flexDirection: 'row',
    },
    cellContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    containerrow: {
        flexDirection: 'row',
        alignContent: 'center',
        width: '100%',
        paddingHorizontal: 16,
        justifyContent: 'center',
    },
    cellTextBold: {
        fontWeight: 'bold',
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 200,
    },
    cellText: {
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 300,
    },
    violatorItem: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
        padding: 2,
    },
    icon: { margin: 5 },
    violatorContent: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
        //justifyContent: 'center',
    },
    titleAndIdContainer: {
        //flex: 1,
        flexDirection: 'row',
        marginBottom: 5,
    },
    titleContainer: {
        //flex: 1,
    },
    idContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    idLabel: { marginRight: 10 },
    otherDetailContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 6,
    },
    otherDetailItem: {
        flex: 1,

        alignItems: 'flex-start',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    normalText: {
        fontSize: '$primaryTextSM',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
    valueText: {
        fontSize: '$primaryTextSM',
    },
    activeIcon: {
        color: '$primaryHeaderColor',
    },
});
