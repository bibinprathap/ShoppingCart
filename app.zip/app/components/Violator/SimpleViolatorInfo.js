import React, { Component, useState } from 'react';
import { View, Text } from 'react-native';
import { Icon } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { ViolatorInfoDialog } from 'app/screens';
import EStyleSheet from 'react-native-extended-stylesheet';

const violatorConf = {
    company: {
        iconName: 'account-group',
        titleLabel: 'company',
        idLabel: 'tradeLicenseNumber',
        nationalityLabel: 'country',
    },
    vehicle: {
        iconName: 'car',
        titleLabel: 'Vehicle',
        idLabel: 'plateNumber',
        nationalityLabel: 'country',
    },
    individual: {
        iconName: 'face',
        titleLabel: 'fullName',
        idLabel: 'emiratesId',
        nationalityLabel: 'nationality',
    },
    building: {
        iconName: 'home-city-outline',
        titleLabel: 'building',
        idLabel: 'buildingNumber',
        nationalityLabel: 'building',
    },
};

export default function SimpleViolatorInfo({ violator, customActions, ...otherProps }) {
    const [isViolatorInfoDialogVisible, toggleViolatorInfoDialog] = useState(false);

    const { violatorType, idNumber, registeredPhoneNumber, violatorPhoneNumber } = violator;
    const conf = violatorConf[violatorType];
    if (!conf) {
        throw `Unknown violator type: ${violatorType}`;
    }
    const customActionsComponent = typeof customActions === 'function' ? customActions({ violator, ...otherProps }) : null;

    const handleViolatorDetailIconPress = () => {
        toggleViolatorInfoDialog(!isViolatorInfoDialogVisible);
    };
    const handleOnRequestClose = () => {
        toggleViolatorInfoDialog(!isViolatorInfoDialogVisible);
    };

    const violatorIconStyle = violator.isPresent ? [styles.icon, styles.activeIcon] : styles.icon;

    return (
        <View>
            <ViolatorInfoDialog isVisible={isViolatorInfoDialogVisible} violator={violator} onRequestClose={handleOnRequestClose} />
            <View style={styles.violatorItem}>
                <View style={{ alignItems: 'center', justifyContent: 'center', padding: 3 }}>
                    <Icon
                        type="MaterialCommunityIcons"
                        name={conf.iconName}
                        size={24}
                        style={violatorIconStyle}
                        onPress={violator.detail ? handleViolatorDetailIconPress : null}
                    />
                </View>
                <View style={styles.violatorContent}>
                    <View style={styles.titleAndIdContainer}>
                        <View style={styles.titleContainer}>
                            <Text style={styles.titleText}>{localeProperty(violator, 'title')}</Text>
                        </View>
                        {/* <View style={styles.idContainer}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.idLabel)}</Text>
                            </View>
                            <View style={{ marginStart: 10 }}>
                                <Text>{idNumber}</Text>
                            </View>
                        </View> */}
                    </View>
                    <View style={styles.otherDetailContainer}>
                        <View style={styles.otherDetailItem}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.idLabel)}</Text>
                            </View>
                            <View>
                                <Text>{idNumber}</Text>
                            </View>
                        </View>
                        {violatorType !== 'building' && (
                            <View style={styles.otherDetailItem}>
                                <View style={styles.idLabel}>
                                    <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                                </View>
                                <View>
                                    <Text>{registeredPhoneNumber}</Text>
                                </View>
                            </View>
                        )}
                    </View>

                    <View style={styles.otherDetailContainer}>
                        <View style={styles.otherDetailItem}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.nationalityLabel)}</Text>
                            </View>
                            <View>
                                <Text>{localeProperty(violator, 'nationalityName')}</Text>
                            </View>
                        </View>
                        {violatorType !== 'building' && (
                            <View style={styles.otherDetailItem}>
                                <View style={styles.idLabel}>
                                    <Text style={[styles.headingText, styles.mutedText]}>{strings('otherPhoneNumber')}</Text>
                                </View>
                                <View>
                                    <Text>{violatorPhoneNumber}</Text>
                                </View>
                            </View>
                        )}
                    </View>

                    {/* <View style={styles.otherDetailContainer}>
                        <View>
                            <View style={styles.otherDetailItem}>
                                <View style={styles.idLabel}>
                                    <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.idLabel)}</Text>
                                </View>
                                <View>
                                    <Text>{idNumber}</Text>
                                </View>
                            </View>

                            <View style={styles.otherDetailItem}>
                                <View style={styles.idLabel}>
                                    <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.nationalityLabel)}</Text>
                                </View>
                                <View>
                                    <Text>{localeProperty(violator, 'nationality')}</Text>
                                </View>
                            </View>
                        </View>
                    </View>
                    <View style={styles.otherDetailContainer}>
                        <View>
                            <View style={styles.otherDetailItem}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                            </View>
                            <Text>{registeredPhoneNumber}</Text>
                        </View>

                        <View>
                            <View style={styles.otherDetailItem}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings('otherPhoneNumber')}</Text>
                            </View>
                            <Text>{otherPhoneNumber}</Text>
                        </View> */}

                    {/* <View style={[styles.otherDetailItem, { flex: 2 }]}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings(conf.nationalityLabel)}</Text>
                            </View>
                            <Text>{localeProperty(violator, 'nationality')}</Text>
                        </View>
                        <View style={[styles.otherDetailItem, { alignItems: 'flex-end' }]}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                            </View>
                            <Text>{registeredPhoneNumber}</Text>
                        </View>
                        <View style={[styles.otherDetailItem, { alignItems: 'flex-end' }]}>
                            <View style={styles.idLabel}>
                                <Text style={[styles.headingText, styles.mutedText]}>{strings('otherPhoneNumber')}</Text>
                            </View>
                            <Text>{otherPhoneNumber}</Text>
                        </View> 
                    </View>*/}
                </View>
                {customActionsComponent}
            </View>
        </View>
    );
}

const styles = EStyleSheet.create({
    violatorItem: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
        padding: 2,
    },
    icon: { margin: 5 },
    violatorContent: {
        flex: 1,
        flexDirection: 'column',
        //justifyContent: 'center',
    },
    titleAndIdContainer: {
        //flex: 1,
        marginBottom: 5,
    },
    titleContainer: {
        //flex: 1,
    },
    idContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    idLabel: { marginRight: 10 },
    otherDetailContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    otherDetailItem: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    normalText: {
        fontSize: '$primaryTextSM',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
    activeIcon: {
        color: '$primaryHeaderColor',
    },
});
