import React from 'react';
import { View, Text, SafeAreaView, ScrollView, I18nManager } from 'react-native';
import { ViolatorLabel } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import moment from 'moment';

export default function VehicleViolatorDetailInfo({ violator, onDetailLoaded }) {
    debugger;
    const { violatorType, detail, idNumber, registeredPhoneNumber } = violator || {};

    const { chassisNumber, plateCategoryDesc, vehicleDesc } = detail;
    const getFormatedDate = date => {
        return date ? moment(date).format('LL') : '';
    };

    return (
        <SafeAreaView style={{ margin: 10 }}>
            <View style={styles.violatorContent}>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="idLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{idNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('chassisNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{chassisNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="nationalityLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'nationalityName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{registeredPhoneNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('plateCategoryDesc')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{plateCategoryDesc}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('vehicleDesc')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{vehicleDesc}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('plateCategory')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'plateCategoryName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('plateColor')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'plateColorName')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('plateKind')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'plateKindName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('vehicleColor')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'vehicleColorName')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('vehicleMake')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'vehicleMakeName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('vehicleModel')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'vehicleModelName')}</Text>
                        </View>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = EStyleSheet.create({
    icon: { margin: 5 },
    violatorContent: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
        //justifyContent: 'center',
    },
    idLabel: { marginRight: 10 },
    otherDetailContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 6,
    },
    otherDetailItem: {
        flex: 1,

        alignItems: 'flex-start',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    normalText: {
        fontSize: '$primaryTextSM',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
    valueText: {
        fontSize: '$primaryTextSM',
    },
    activeIcon: {
        color: '$primaryHeaderColor',
    },
});
