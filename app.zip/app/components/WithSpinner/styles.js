import EStyleSheet from 'react-native-extended-stylesheet';

export default (styles = EStyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    containerLight: {
        backgroundColor: '$primaryLightBackground',
    },
    containerDark: {
        backgroundColor: '$primaryDarkBackground',
    },
}));
