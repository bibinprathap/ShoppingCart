import mock from 'app/api/mock';
import real from 'app/api/real';

const env = {
    dev: { apiBase: 'http://localhost/something' },
    dev: { apiBase: 'http://staging/something' },
    prod: { apiBase: 'http://prod/something' },
};

//console.log(`Returning api service ${mock}`);
//todo: check for some configuration in json, and return the appropriate api with
export default mock; //for now just returning mock api
