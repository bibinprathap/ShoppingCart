import alertsHelper from 'app/api/helperServices/alerts';
import { setJSExceptionHandler } from 'react-native-exception-handler';
import RNRestart from 'react-native-restart';
import { Alert } from 'react-native';
import { logError } from './logger';
import { strings } from './i18n/i18n';
import { store } from 'app/config/store';
import { logJSErrors } from 'app/actions/generic';

/*global exception handler setup*/
const errorHandler = (error, isFatal) => {
    logError(error, isFatal);

    if (isFatal) {
        //warnings are not fatal, will not show alert
        const errorType = strings(isFatal ? 'fatalError' : 'error');
        const restartMessage = '\n\n' + strings('restartMessage');
        const errorDetail = strings('unhandledExceptionMessage', { errorType, errorMessage: error.message, restartMessage });
        store.dispatch(logJSErrors(errorDetail.substring(0, 120), { error: errorDetail }));
        //alertsHelper.show('error', strings('unhandledExceptionTitle'), errorDetail);

        // Alert.alert(strings('unhandledExceptionTitle'), `${errorDetail}`, [
        //     {
        //         text: 'Restart',
        //         onPress: () => {
        //             RNRestart.Restart();
        //         },
        //     },
        // ]);

        //Alert.alert(strings('unhandledExceptionTitle'), errorDetail, [{ text: strings('OK'), onPress: () => console.log('OK Pressed') }]);
    }
};

export function setGlobalHandler() {
    // setJSExceptionHandler(errorHandler, true);
}
