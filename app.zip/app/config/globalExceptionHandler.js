import alertsHelper from 'app/api/helperServices/alerts';
import { setJSExceptionHandler } from 'react-native-exception-handler';
import { logError } from './logger';
import { strings } from './i18n/i18n';

/*global exception handler setup*/
const errorHandler = (error, isFatal) => {
    logError(error, isFatal);

    if (isFatal) {
        //warnings are not fatal, will not show alert
        const errorType = strings(isFatal ? 'fatalError' : 'error');
        const restartMessage = '\n\n' + strings('restartMessage');
        const errorDetail = strings('unhandledExceptionMessage', { errorType, errorMessage: error, restartMessage });

        alertsHelper.show('error', strings('unhandledExceptionTitle'), errorDetail);

        //Alert.alert(strings('unhandledExceptionTitle'), errorDetail, [{ text: strings('OK'), onPress: () => console.log('OK Pressed') }]);
    }
};

export function setGlobalHandler() {
    setJSExceptionHandler(errorHandler, true);
}
