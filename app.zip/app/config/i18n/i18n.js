import ReactNative, { I18nManager } from 'react-native';
import RNRestart from 'react-native-restart';
import moment from 'moment';
// import RNFileUploader from 'app/api/helperServices/uploaderNative';
import I18n from 'i18n-js';
import * as RNLocalize from 'react-native-localize';
import memoize from 'lodash.memoize';

import en from './locales/en';
import ar from './locales/ar';

I18n.fallbacks = true;

const locales = RNLocalize.getLocales();

if (Array.isArray(locales)) {
    I18n.locale = locales[0].languageTag;
}
I18n.translations = {
    en,
    ar,
};

export const handleLocales = async () => {
    this.locales = RNLocalize.getLocales();
};

export const getLocale = () => {
    if (this.locales) {
        if (Array.isArray(this.locales)) {
            return this.locales[0];
        }
    }
    return null;
};

// Allow RTL alignment in RTL languages

export const langCodeFromLocale = locale => {
    if (!!locale) {
        return locale.indexOf('ar') > -1 ? 'A' : 'E';
    } else {
        return '';
    }
};

export const strings = memoize(
    (key, config) => I18n.t(key, config),
    (key, config) => (config ? key + JSON.stringify(config) : key)
);

// function strings(name, params = {}) {
//     return I18n.t(name, params);
// }

export function localeProperty(obj, propName, lang) {
    const langCode = langCodeFromLocale(lang || I18n.locale);
    const localePropName = `${propName}${langCode}`;
    if (!!obj) {
        return obj[localePropName];
    } else return undefined;
}

export function setLocale(newLocale) {
    const newIsRtl = newLocale.indexOf('ar') > -1;
    if (newIsRtl) {
        I18n.locale = newLocale;
        //moment.locale('ar');
    } else {
        I18n.locale = newLocale;
        //moment.locale('en');
    }
    strings.cache.clear();
    ReactNative.I18nManager.allowRTL(newIsRtl);

    ReactNative.I18nManager.forceRTL(newIsRtl);
    // RNFileUploader.forceRTL('test').then(completeduploadids => {});
    if (I18nManager.isRTL != newIsRtl) RNRestart.Restart();
}

export function formatCurrency(amount, notShowCurrency) {
    const currencyOptions = {
        precision: 0,
        unit: '',
        format: '%u %n',
        delimiter: ',',
    };
    return I18n.toCurrency(amount || 0, currencyOptions) + (notShowCurrency ? '' : ' AED');
}

export default I18n;
