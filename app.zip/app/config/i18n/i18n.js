import ReactNative, { I18nManager } from 'react-native';
import RNRestart from 'react-native-restart';
import moment from 'moment';
import I18n from 'react-native-i18n';
import en from './locales/en';
import ar from './locales/ar';

I18n.fallbacks = true;

I18n.translations = {
    en,
    ar,
};

export const langCodeFromLocale = locale => {
    if (!!locale) {
        return locale.indexOf('ar') > -1 ? 'A' : 'E';
    } else {
        return '';
    }
};

export function strings(name, params = {}) {
    return I18n.t(name, params);
}

export function localeProperty(obj, propName, lang) {
    const langCode = langCodeFromLocale(lang || I18n.locale);
    const localePropName = `${propName}${langCode}`;
    if (!!obj) {
        return obj[localePropName];
    } else return undefined;
}

export function setLocale(newLocale) {
    const newIsRtl = newLocale.indexOf('ar') > -1;
    if (newIsRtl) {
        I18n.locale = newLocale;
        //moment.locale('ar');
    } else {
        I18n.locale = newLocale;
        //moment.locale('en');
    }
    I18nManager.allowRTL(newIsRtl);
    I18nManager.forceRTL(newIsRtl);

    if (I18nManager.isRTL != newIsRtl) RNRestart.Restart();
}

export function formatCurrency(amount, notShowCurrency) {
    const currencyOptions = {
        precision: 0,
        unit: '',
        format: '%u %n',
        delimiter: ',',
    };
    return I18n.toCurrency(amount || 0, currencyOptions) + (notShowCurrency ? '' : ' AED');
}

export default I18n;
