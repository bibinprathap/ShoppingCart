/*global logger*/
//TODO: change it to a "provider" and injext in all components, so that we could log errors/warnings from where in the app
export const logError = (error, isFatal) => {
    if (error) console.log(`Logged${isFatal ? 'Fatal' : ''} error: ${error}`); //log locally as well as send to server
};
