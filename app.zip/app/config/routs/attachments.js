import React from 'react';
import { I18nManager } from 'react-native';
import { createStackNavigator } from 'react-navigation';
import { Attachments } from 'app/screens/attachments';
import { AttachmentsHeader } from 'app/components/Header';
import I18n from 'react-native-i18n';
import { strings, langCodeFromLocale } from 'app/config/i18n/i18n';

const lang = langCodeFromLocale(I18n.locale);

export const attachmentsStackDefinition = {
    routes: [
        {
            key: 'attachments',
            screen: Attachments,
            title: strings('attachments', { locale: lang }),
            icon: 'attachment',
            iconType: 'default',
        },
    ],
    initialRoute: 'attachments',
};
const routeConfig = {};

attachmentsStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const AttachmentsStackNavigator = createStackNavigator(routeConfig, {
    initialRouteName: attachmentsStackDefinition.initialRoute,
    defaultNavigationOptions: {
        header: props => <AttachmentsHeader {...props} />,
    },
});

export default AttachmentsStackNavigator;
