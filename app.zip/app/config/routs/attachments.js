import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import { Attachments } from 'app/screens';
import { AttachmentsHeader } from 'app/components';
import I18n from 'i18n-js';
import { strings, langCodeFromLocale } from 'app/config/i18n/i18n';

const lang = langCodeFromLocale(I18n.locale);

export const attachmentsStackDefinition = {
    routes: [
        {
            key: 'attachments',
            screen: Attachments,
            title: strings('attachments', { locale: lang }),
            icon: 'attachment',
            iconType: 'default',
        },
    ],
    initialRoute: 'attachments',
};
const routeConfig = {};

attachmentsStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const AttachmentsStackNavigator = createStackNavigator(routeConfig, {
    initialRouteName: attachmentsStackDefinition.initialRoute,
    defaultNavigationOptions: {
        header: props => <AttachmentsHeader {...props} />,
    },
});

export default AttachmentsStackNavigator;
