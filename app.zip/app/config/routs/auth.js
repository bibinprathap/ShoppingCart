import { createStackNavigator, createAppContainer } from 'react-navigation';
import Login from 'app/screens/auth/Login';

const AuthNavigator = createStackNavigator(
    {
        login: { screen: Login },
    },
    {
        headerMode: 'none',
    }
);

export default AuthNavigator;
