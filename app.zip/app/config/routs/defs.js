import { I18nManager } from 'react-native';
import { strings } from 'app/config/i18n/i18n';

/*main stack screens*/
import Dashboard from 'app/screens/main/Dashboard';
import Search from 'app/screens/main/Search';
import Notifications from 'app/screens/main/Notifications';
import ScheduledWork from 'app/screens/main/ScheduledWork';
import Settings from 'app/screens/main/Settings';
import Profile from 'app/screens/main/Profile';

/*inspection stack screen*/

import { ServiceSelection } from 'app/screens/inspection/ServiceSelection';
import { Checklist } from 'app/screens/inspection/Checklist';
import { ViolatorDetails } from 'app/screens/inspection/ViolatorDetails';
import { DuplicateCheck } from 'app/screens/inspection/DuplicateCheck';
import { Review, FollowupReview } from 'app/screens/inspection/Review';

import { IdScan } from 'app/screens/idScan';

const currentLocale = I18nManager.isRTL ? 'ar' : 'en';
/*
    when navigators are created, I18nManager.isRTL shows correct setting,
    but somehow I18n doesn't seem to be initialized, and it I18n.t returns wrong resource.
    so we force it to return the correct one by passing in the locale
*/
export const mainStackDefinition = {
    routes: [
        {
            key: 'dashboard',
            screen: Dashboard, //IdScan
            title: strings('appTitle', { locale: currentLocale }),
            subtitle: strings('dashboard', { locale: currentLocale }),
            icon: 'home',
            iconType: 'custom',
        },
        {
            key: 'search',
            screen: Search,
            title: strings('search', { locale: currentLocale }),
            icon: 'search',
            iconType: 'default',
        },
        {
            key: 'notifications',
            screen: Notifications,
            title: strings('notifications', { locale: currentLocale }),
            icon: 'notification',
            iconType: 'custom',
            showInsidePanel: true,
        },
        {
            key: 'scheduledWork',
            screen: ScheduledWork,
            title: strings('scheduledWork', { locale: currentLocale }),
            icon: 'schedule',
            iconType: 'default',
        },
        {
            key: 'settings',
            screen: null,
            title: strings('settings', { locale: currentLocale }),
            icon: 'settings',
            iconType: 'default',
        },
        {
            key: 'profile',
            screen: Profile,
            title: strings('profile', { locale: currentLocale }),
            icon: 'person-outline',
            iconType: 'default',
        },
        {
            key: 'logout',
            screen: null,
            title: strings('logout', { locale: currentLocale }),
            icon: 'power-settings-new',
            iconType: 'default',
        },
    ],
    initialRoute: 'dashboard',
};

export const inspectionStackDefinition = {
    routes: [
        {
            key: 'serviceSelection',
            screen: ServiceSelection,
            params: { headerTitle: strings('serviceSelection', { locale: currentLocale }) },
            title: strings('serviceSelection', { locale: currentLocale }),
            tabBarLabel: strings('serviceSelection', { locale: currentLocale }),
            icon: 'serviceSelection',
            iconType: 'custom',
        },
        {
            key: 'checklist',
            screen: Checklist,
            title: strings('performInspection', { locale: currentLocale }),
            icon: 'checklist',
            iconType: 'custom',
        },
        {
            key: 'violatorDetails',
            screen: ViolatorDetails,
            title: strings('violatorDetails', { locale: currentLocale }),
            icon: 'violatorDetails',
            iconType: 'custom',
        },
        {
            key: 'duplicateCheck',
            screen: DuplicateCheck,
            title: strings('confirmDuplicates', { locale: currentLocale }),
            icon: 'content-copy',
            iconType: 'default',
        },
        {
            key: 'review',
            screen: Review,
            title: strings('review', { locale: currentLocale }),
            icon: 'review',
            iconType: 'custom',
        },
    ],
    initialRoute: 'serviceSelection',
};

export const followupStackDefinition = {
    routes: [
        {
            key: 'followuptabs',
            screen: FollowupReview,
            params: { headerTitle: strings('inspectionFollowup', { locale: currentLocale }) },
            title: strings('inspectionFollowup', { locale: currentLocale }),
            tabBarLabel: strings('inspectionFollowup', { locale: currentLocale }),
            icon: 'serviceSelection',
            iconType: 'custom',
        },
    ],
    initialRoute: 'followuptabs',
};
