import React from 'react';
import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { View } from 'react-native';

import FollowUpHeader from 'app/components/Header/FollowUpHeader';

import { followupStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

followupStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        title: item.title,
        subtitle: item.subtitle,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const FollowupStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: followupStackDefinition.initialRoute,
    swipeEnabled: false,
    animationEnabled: false,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 0,
        },
    }),

    defaultNavigationOptions: {
        tabBarComponent: props => <FollowUpHeader {...props} />,
    },
});

export default FollowupStackNavigator;
