import React from 'react';
import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { View } from 'react-native';

import { followupStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

followupStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        title: item.title,
        subtitle: item.subtitle,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const FollowupStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: followupStackDefinition.initialRoute,
    swipeEnabled: false,
    animationEnabled: false,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 0,
        },
    }),
});

export default FollowupStackNavigator;
