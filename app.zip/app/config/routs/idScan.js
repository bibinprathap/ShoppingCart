import React from 'react';
import { I18nManager, View, Text } from 'react-native';
import { createStackNavigator } from 'react-navigation';
import { IdScan } from 'app/screens/idScan';
import { IdScanHeader } from 'app/components/Header';
import I18n from 'react-native-i18n';
import { strings, langCodeFromLocale } from 'app/config/i18n/i18n';

const lang = langCodeFromLocale(I18n.locale);

export const idScanStackDefinition = {
    routes: [
        {
            key: 'idScan',
            screen: IdScan,
            title: strings('scan', { locale: lang }),
            icon: 'attachment',
            iconType: 'default',
        },
    ],
    initialRoute: 'idScan',
};
const routeConfig = {};

idScanStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const IdScansStackNavigator = createStackNavigator(routeConfig, {
    initialRouteName: idScanStackDefinition.initialRoute,
    defaultNavigationOptions: {
        header: props => <IdScanHeader title={strings('scanTheId')} {...props} />,
        // header: props => (
        //     <View>
        //         <Text>Id Scan header</Text>
        //     </View>
        // ),
    },
});

export default IdScansStackNavigator;
