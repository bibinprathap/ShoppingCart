import { createSwitchNavigator, createAppContainer } from 'react-navigation';
import authNavigator from './auth';
import mainNavigator from './main';
import inspectionNavigator from './inspection';
import AuthLoading from 'app/screens/auth/AuthLoading';

// create switch navigation with authentication flow and main app
const SwitchNavigator = createSwitchNavigator(
    {
        authLoading: AuthLoading,
        auth: authNavigator,
        main: mainNavigator,
        inspection: inspectionNavigator,
    },
    {
        initialRouteName: 'authLoading',
    }
);

export default createAppContainer(SwitchNavigator);
