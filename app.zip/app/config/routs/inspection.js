import React from 'react';
import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { View } from 'react-native';

import { InspectionHeader } from 'app/components/Header';

import idScanNavigator from './idScan';
import { inspectionStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

inspectionStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        title: item.title,
        subtitle: item.subtitle,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };

    routeConfig['idScan'] = idScanNavigator;
});

export const InspectionStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: inspectionStackDefinition.initialRoute,
    swipeEnabled: false,
    animationEnabled: true,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 750,
            easing: Easing.out(Easing.poly(4)),
            timing: Animated.timing,
            useNativeDriver: true,
        },
    }),

    defaultNavigationOptions: {
        tabBarComponent: props => <InspectionHeader {...props} />,
    },
});

export default InspectionStackNavigator;

export const subRoutesWithOwnHeader = ['idScan'];
