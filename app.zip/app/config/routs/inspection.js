import React from 'react';
import { createStackNavigator, createAppContainer } from 'react-navigation';
import { View } from 'react-native';

import { InspectionHeader } from 'app/components/Header';
import attachmentsNavigator from './attachments';
import idScanNavigator from './idScan';
import { inspectionStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

inspectionStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
    routeConfig['attachments'] = attachmentsNavigator;
    routeConfig['idScan'] = idScanNavigator;
});

export const InspectionStackNavigator = createStackNavigator(routeConfig, {
    initialRouteName: inspectionStackDefinition.initialRoute,
    defaultNavigationOptions: {
        header: props => <InspectionHeader {...props} />,
    },
});

export default InspectionStackNavigator;

export const subRoutesWithOwnHeader = ['attachments', 'idScan'];
