import React from 'react';
import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { View } from 'react-native';

import { InspectionHeader } from 'app/components/Header';

import idScanNavigator from './idScan';
import { inspectionStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

inspectionStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        title: item.title,
        subtitle: item.subtitle,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };

    routeConfig['idScan'] = idScanNavigator;
});

export const InspectionStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: inspectionStackDefinition.initialRoute,
    swipeEnabled: false,
    animationEnabled: false,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 0,
        },
    }),

    defaultNavigationOptions: {
        tabBarComponent: props => <InspectionHeader {...props} />,
    },
});

export default InspectionStackNavigator;

export const subRoutesWithOwnHeader = ['idScan'];
