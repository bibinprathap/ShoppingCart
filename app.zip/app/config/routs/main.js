import React from 'react';
import { I18nManager } from 'react-native';
import { createStackNavigator, createAppContainer, createDrawerNavigator, createMaterialTopTabNavigator } from 'react-navigation';
import { widthPercentageToDP, heightPercentageToDP, listenOrientationChange, removeOrientationListener } from 'react-native-responsive-screen';

import DrawerMenu from 'app/screens/DrawerMenu';
import { Header } from 'app/components/Header';
import { mainStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

mainStackDefinition.routes.map(item => {
    if (!!item.screen) {
        routeConfig[item.key] = {
            screen: item.screen,
            navigationOptions: ({ navigation }) => ({
                title: item.title,
                subtitle: item.subtitle,
            }),
        };
    }
});

export const MainStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: 'dashboard',
    swipeEnabled: false,
    animationEnabled: false,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 0,
        },
    }),
    defaultNavigationOptions: {
        tabBarComponent: props => <Header {...props} />,
    },
});

// create and configure drawer parent navigator for main app
const AppNavigator = createDrawerNavigator(
    {
        Home: { screen: MainStackNavigator },
    },
    {
        contentComponent: DrawerMenu,
        drawerWidth: widthPercentageToDP('40%'),
        initialRouteName: 'Home',
        drawerPosition: I18nManager.isRTL ? 'right' : 'left',
    }
);

//export default createAppContainer(MainStackNavigator);
//export default createAppContainer(AppNavigator);
export default AppNavigator;
