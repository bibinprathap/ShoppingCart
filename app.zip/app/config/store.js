import { Platform } from 'react-native';
import { combineReducers, createStore, applyMiddleware, compose } from 'redux';
import { persistStore, persistReducer, createTransform } from 'redux-persist';
import { reducer as formReducer } from 'redux-form';
import storage from 'redux-persist/lib/storage';
import FilesystemStorage from 'redux-persist-filesystem-storage';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import { auth, settings, masterdata, inspections, attachments, tracking, notifications, tasks, search, generic } from 'app/reducers';
import logger from 'redux-logger';
import thunk from 'redux-thunk';
import omit from 'lodash/omit';
import reduxMulti from 'redux-multi';
import { batchedSubscribe } from 'redux-batched-subscribe';
//import createSagaMiddleware from 'redux-saga';
//import rootSaga from './sagas';
//const sagaMiddleware = createSagaMiddleware();
//const middleware = [sagaMiddleware];

const middleware = [thunk, reduxMulti];
const enhancers = [];

if (process.env.NODE_ENV === 'development') {
    middleware.push(logger); //logger should be the last middleware //removed redux-logger for now, instead using react-native-debugger

    const devToolsExtension = window.__REDUX_DEVTOOLS_EXTENSION__;
    if (typeof devToolsExtension === 'function') {
        enhancers.push(devToolsExtension());
    }
}
enhancers.push(batchedSubscribe(fn => fn()));

const rootReducer = combineReducers({
    auth,
    settings,
    masterdata,
    inspections,
    attachments,
    tracking,
    form: formReducer,
    notifications,
    tasks,
    search,
    generic,
});

const blacklistTransform = createTransform((inboundState, key) => {
    //console.log('transforming store for persistance.');
    switch (key) {
        case 'auth':
            let authState = omit(inboundState, ['loggedIn', 'loggingIn', 'authStarted', 'error']);
            if (!authState.remember) delete authState.currentUser;
            return authState;
        case 'inspections':
            let inspectionsState = omit(inboundState, ['currentInspectionRef']);
            return inspectionsState;
        //  case 'attachments':
        //only persist the attachments that are not uploaded yet
        // const pendingUploadAttachments =
        // inboundState.docs &&
        // inboundState.docs.map(doc => {
        //     if (doc.uploaded == false) return doc;
        // });
        // if (pendingUploadAttachments) {
        //     return { docs: pendingUploadAttachments };
        // } else return null;
        case 'form':
        case 'search':
            return undefined;
        default:
            return inboundState;
    }
});

/*
for mobile devices storage returned by "redux-persist/lib/storage" is AsyncStorage.
on android AsyncStorage has a limit of 6MB, so for android we will use FilesystemStorage instead
*/

const rootPersistConfig = {
    key: 'root',
    storage: Platform.OS === 'ios' ? storage : FilesystemStorage,
    transforms: [blacklistTransform],
    stateReconciler: autoMergeLevel2, // see "Merge Process" section for details @ https://blog.reactnativecoach.com/the-definitive-guide-to-redux-persist-84738167975
    timeout: 0,
    //throttle: 1000,
};

const persistedReducer = persistReducer(rootPersistConfig, rootReducer);

const composedEnhancers = compose(
    applyMiddleware(...middleware),
    ...enhancers
);

const initialState = {};

export let persistor = null;
export let store = null;
export let _state = undefined;

export default (configureStore = onRehydrationDone => {
    const _store = createStore(persistedReducer, initialState, composedEnhancers);
    const result = {
        store: _store,
        persistor: persistStore(_store, null, onRehydrationDone),
    };
    persistor = result.persistor;
    store = _store;
    _store.subscribe(() => {
        _state = store.getState();
        //console.log('store.subscribe(), state: ', _state);
    });
    return result;
});

/*
//to create store without redux-persist
const store = createStore(reducers, applyMiddleware(...middleware));
//sagaMiddleware.run(rootSaga);
export default store;
*/
