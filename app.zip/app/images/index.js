//pre-loaded, global collection of static image contents

//Todo: get the icons evenly sized where possible
export default {
    logo: { content: require('app/images/logo.png'), width: 0, height: 0 },
    avatar: { content: require('app/images/avatar.png'), width: 0, height: 0 }, //Todo: load dynamically when user logs in
    menu: { content: require('app/images/menu.png'), width: 52, height: 35 },
    new: { content: require('app/images/new.png'), width: 47, height: 47 },
    notification: { content: require('app/images/notification.png'), width: 43, height: 43 },
    checklist: { content: require('app/images/checklist.png'), width: 36, height: 36 },
    home: { content: require('app/images/home.png'), width: 44, height: 44 },
    info: { content: require('app/images/info.png'), width: 44, height: 44 },
    review: { content: require('app/images/review.png'), width: 44, height: 44 },
    serviceSelection: { content: require('app/images/serviceSelection.png'), width: 35, height: 45 },
    violatorDetails: { content: require('app/images/violatorDetails.png'), width: 44, height: 49 },
    all: { content: require('app/images/all.png'), width: 41, height: 41 },
    allSelected: { content: require('app/images/all.png'), width: 41, height: 41 }, //todo: get the allSelected icon from gfx team
    completed: { content: require('app/images/completed.png'), width: 44, height: 44 },
    completedSelected: { content: require('app/images/completed.png'), width: 44, height: 44 }, //todo: get the completedSelected icon from gfx team
    warnings: { content: require('app/images/warningsSelected.png'), width: 44, height: 44 }, //todo: get the warnings icon from gfx team
    warningsSelected: { content: require('app/images/warningsSelected.png'), width: 44, height: 44 },
    violations: { content: require('app/images/violations.png'), width: 44, height: 44 },
    violationsSelected: { content: require('app/images/violations.png'), width: 44, height: 44 }, //todo: get the violationsSelected icon from gfx team
    inprogress: { content: require('app/images/inprogress.png'), width: 44, height: 44 },
    inprogressSelected: { content: require('app/images/inprogress.png'), width: 44, height: 44 }, //todo: get the inprogressSelected icon from gfx team
    handshake: { content: require('app/images/handshake.png'), width: 44, height: 44 },
    chartExpand: { content: require('app/images/chartExpand.png'), width: 44, height: 44 }, //todo: get the inprogressSelected icon from gfx team
    chartCollapse: { content: require('app/images/chartCollapse.png'), width: 44, height: 44 },
    imagery: { content: require('app/images/imagery.png'), width: 20, height: 20 },
    darkGray: { content: require('app/images/darkgray.png'), width: 20, height: 20 },
    //lightGray: { content: require('app/images/lightgray.png'), width: 20, height: 20 },
    streets: { content: require('app/images/streets.png'), width: 20, height: 20 },
    //temp
    temp: {
        mapView: { content: require('app/images/temp/mapView.png'), width: 0, height: 0 },
    },
};
