import React from 'react';
import { StatusBar } from 'react-native';
import { Provider } from 'react-redux';
import configureStore from './config/store';
import { Provider as PaperProvider } from 'react-native-paper';
import { setGlobalHandler } from './config/globalExceptionHandler';
import SwitchNavigator from './config/routs';
import { setLocale } from './config/i18n/i18n';
import { initLanguage, setDeeplink } from './actions/settings';
import { addNotification, updateFCMToken, fcmInitialize, markNotificationAsRead } from './actions/notifications';
import { appStateChange } from './actions/tracking';
import { createInitialTasks } from './actions/tasks';
import { theme } from './styles';
import DropdownAlert from 'react-native-dropdownalert';
import alertsHelper from 'app/api/helperServices/alerts';
import { inspectionStackDefinition, mainStackDefinition } from 'app/config/routs/defs';
import { initAllRoutesDefinitions } from 'app/api/helperServices/inspections';
import firebase from 'app/api/helperServices/rnFirebaseNative';

import { startBackgroundLocationTracking, stopBackgroundLocationTracking, cancelAllBackgroundJobs } from 'app/api/helperServices/geolocation';
import { attachmentsHelper } from 'app/api/helperServices';
//import notificationsHelper from 'app/api/helperServices/notifications';

import SplashScreen from 'react-native-splash-screen';
import { View, Text, YellowBox, Linking, Platform, AppState } from 'react-native';

import { RNFileUploader, deeplinkHelper } from 'app/api/helperServices';
import envConfig from 'app/api/config';
import { _state, store } from 'app/config/store';
import BackgroundJob from 'react-native-background-job';
import AppApi from 'app/api/real';
import { createNewTask } from 'app/actions/tasks';

const api = new AppApi();

//import { ScrollView, View, Text } from 'react-native';
const env = envConfig;

let _globalStore = undefined;
let uploaderListener = undefined;
setGlobalHandler();

let storeHydrationResult = configureStore(() => {
    _globalStore = storeHydrationResult.store; //storeHydrationTimer will pick up this value and proceed to rendering the <App/> first time
    _globalStore.dispatch(appStateChange('terminated'));
    //Appp will be set to active when root react component updated after store hydration,
    //otherwise, in background job case when application had been terminated, the appState will remain 'terminated'
    startBackgroundLocationTracking();

    const store = _globalStore;
    if (!store) return null;
    const storedState = store.getState();
    const { settings } = storedState;
    const { environment, backgroundTimerInterval } = settings;
    attachmentsHelper.checkUploadIdInSharedPreferences().then(() => {});

    uploaderListener = RNFileUploader.addListener('progress', '', data => {
        //this.handleProgress(+data.progress);
        __DEV__ && console.log(`periodiccall: ${JSON.stringify(data)}%`);
        // this will be executed every 15 minit
        // even when app is the the background
        if (data.pereodiccall && data.pereodiccall == 'every15minit') {
            __DEV__ && console.log('timmer upload started');

            const { settings, auth } = _state;
            if (auth) {
                const { userData, authCode } = auth;
                if (userData) {
                    attachmentsHelper.checkUploadIdInSharedPreferences(userData.uuid).then(() => {
                        const pendingUploads = attachmentsHelper.getPendingUploadAttachement(env[environment].baseURL);
                        pendingUploads.map(p => {
                            if (p.fileName) RNFileUploader.cancelUpload(p.fileName);
                            if (userData) attachmentsHelper.startUpload(p, environment, authCode, userData.uuid);
                        });
                    });
                }
            }
        }
    });

    const { auth, tasks } = storedState;
    if (auth) {
        const { userData, authCode } = auth;
        if (userData) {
            if (!(tasks && Object.getOwnPropertyNames(tasks.history).length > 0)) {
                const { userData, authCode } = auth;
                this.getInitialTasks(store, userData);
            }
        }
    }
    cancelAllBackgroundJobs();
});

getInitialTasks = async (store, userData) => {
    const result = await api.getInitialTasks(userData);
    store.dispatch(createInitialTasks(result));
};
class App extends React.Component {
    constructor(props) {
        super(props);

        //Todo: remove it soon... how soon?
        YellowBox.ignoreWarnings([
            'Warning: componentWillMount is deprecated',
            'Warning: componentWillReceiveProps is deprecated',
            'Warning: componentWillUpdate is deprecated',
        ]);

        this.state = {
            isStoreHydrated: false,
            appStateInitialized: false,
        };

        this.storeHydrationTimer = setInterval(() => {
            if (_globalStore) {
                console.log('Store hydrated !');
                clearInterval(this.storeHydrationTimer);
                this.setState({ isStoreHydrated: true, store: _globalStore });
                this.getRegistrationToken();
            } else {
                console.log('store not hydrated yet...');
            }
        }, 200);

        console.log('constructor');
    }

    handleAppStateChange = nextAppState => {
        this.setState({ appState: nextAppState });
        const { store } = this.state;
        if (store) {
            store.dispatch(appStateChange(nextAppState));
        }
    };

    componentDidUpdate() {
        if (!this.state.appStateInitialized && this.state.isStoreHydrated) {
            console.log('setting AppState to: ', AppState.currentState);
            this.setState({ appStateInitialized: true }, () => this.state.store.dispatch(appStateChange(AppState.currentState)));
        }

        if (this.state.isStoreHydrated) {
            this.getInitialNotification();
        }
    }

    componentDidMount() {
        BackgroundJob.cancelAll();
        // console.log('Cancelled all jobs. ******************************************');
        // console.log('Cancelled all jobs. ******************************************');
        // console.log('Cancelled all jobs. ******************************************');

        // TEST deeplink command:  adb shell am start -W -a android.intent.action.VIEW -d "adm://mims/search" com.mims

        AppState.addEventListener('change', this.handleAppStateChange);
        if (Platform.OS === 'android') {
            Linking.getInitialURL().then(deeplink => {
                this.handleLinks({ url: deeplink });
            });
        }

        Linking.addEventListener('url', this.handleLinks);

        // Start a timer that runs continuous after X milliseconds
        // setTimeout(() => {
        //     BackgroundTimer.clearInterval(intervalId);
        // }, 800000);
        // Cancel the timer when you are done with it
        this.notificationsListner = firebase.addListener(this.handleNotifications);
    }

    componentWillUnmount() {
        AppState.removeEventListener('change', this.handleAppStateChange);
        Linking.removeEventListener('url', this.handleLinks);
        if (this.splashTimer) {
            clearTimeout(this.splashTimer);
        }
        if (this.deeplinkTimer) {
            clearTimeout(this.deeplinkTimer);
        }
        if (this.notificationsListner) this.notificationsListner.remove();
    }

    deeplinkTimer;
    splashTimer;
    navigatorRef;
    notificationsListner;

    getRegistrationToken = () => {
        const { store } = this.state;
        store.dispatch(fcmInitialize());
        //firebase.subscribeToTopic('testTopic');
    };

    getInitialNotification = () => {
        const { store } = this.state;
        const storedState = store.getState();
        firebase.getInitialNotification((error, notification) => {
            const { notifications } = storedState;
            if (notification) {
                const messageId = notification['google.message_id'] || notification.message_id;
                if (messageId && typeof notifications[messageId] === 'undefined') {
                    store.dispatch(addNotification(notification));
                    if (notification.data && notification.data.task) store.dispatch(createNewTask(JSON.parse(notification.data.task)));
                }

                if (
                    notification.url &&
                    (typeof notifications[messageId] === 'undefined' || (notifications[messageId] && !notifications[messageId].readAt))
                ) {
                    this.handleLinks(notification);
                    store.dispatch(markNotificationAsRead(messageId));
                }

                notifications[messageId] && !notifications[messageId].readAt;
            }
        });
    };

    handleNotifications = notification => {
        console.log('firebaseListener', notification);
        const { store } = this.state;
        if (store) {
            switch (notification.type) {
                case 'NOTIFICATION':
                    store.dispatch(addNotification(notification.data));
                    if (notification.data.task) {
                        store.dispatch(createNewTask(JSON.parse(notification.data.task)));
                    }
                    break;
                case 'FCM_NEW_TOKEN':
                    console.log('Firebase notification token ', notification.data);
                    store.dispatch(updateFCMToken(notification.data));
                    break;
                default:
                    break;
            }
        }
    };

    handleLinks = event => {
        if (event.url) {
            this.deeplinkTimer = setTimeout(() => {
                const { store } = this.state;
                const storedState = store.getState();
                const { auth } = storedState;
                const loggedIn = (auth && auth.loggedIn) || false;
                if (this.navigatorRef) {
                    store.dispatch(setDeeplink({ deeplink: event.url }));
                    deeplinkHelper.handleLink({ deeplink: event.url, loggedIn, dispatch: store.dispatch, navigation: this.navigatorRef });
                }
            }, 1000);
        }
    };

    render() {
        if (this.state.isStoreHydrated) {
            const { store } = this.state;

            //first handle the language settings in the stored state, if any.
            //it may restart the app if current languange is different from the stored one.

            const defaultLocale = 'en-US';
            const storedState = store.getState();
            if (!!storedState && !!storedState.settings && !!storedState.settings.locale) {
                store.dispatch(initLanguage(storedState.settings.locale));
                setLocale(storedState.settings.locale);
            } else {
                store.dispatch(initLanguage(defaultLocale));
                setLocale(defaultLocale);
            }

            initAllRoutesDefinitions(mainStackDefinition, inspectionStackDefinition);
            this.splashTimer = setTimeout(() => {
                SplashScreen.hide();
            }, 300);

            return (
                <Provider store={store}>
                    <PaperProvider theme={theme}>
                        <SwitchNavigator
                            ref={navigatorRef => {
                                if (navigatorRef) {
                                    this.navigatorRef = navigatorRef;
                                }
                            }}
                        />
                        <DropdownAlert
                            defaultContainer={{ padding: 8, paddingTop: StatusBar.currentHeight, flexDirection: 'row' }}
                            ref={ref => alertsHelper.setAlertProvider(ref)}
                            showCancel={true}
                            onClose={() => alertsHelper.invokeOnClose()}
                            onCancel={data => alertsHelper.invokeOnCancel(data)}
                        />
                    </PaperProvider>
                </Provider>
            );
        } else return null;
    }
}

export default App;

/*
    //without redux-persist use below code

    //export default () => <Provider store={store}><MainStackNavigator /></Provider>

    export default () => <Provider store={store}><SwitchNavigator /></Provider>

    // export default () => {
    //     return (
    //         <PaperProvider>
    //             <AuthNavigator />
    //         </PaperProvider>
    //     );
    // }

    //export default () => <AlertProvider><Navigator /></AlertProvider>
*/
