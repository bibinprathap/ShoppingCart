import React from 'react';
import { StatusBar } from 'react-native';
import { Provider } from 'react-redux';
import configureStore from './config/store';
import { Provider as PaperProvider } from 'react-native-paper';
import { setGlobalHandler } from './config/globalExceptionHandler';
import SwitchNavigator from './config/routs';
import { setLocale } from './config/i18n/i18n';
import { initLanguage, handleDeeplink } from './actions/settings';
import { appStateChange } from './actions/tracking';
import { theme } from './styles';
import DropdownAlert from 'react-native-dropdownalert';
import alertsHelper from 'app/api/helperServices/alerts';
import { inspectionStackDefinition, mainStackDefinition } from 'app/config/routs/defs';
import { initAllRoutesDefinitions } from 'app/api/helperServices/inspections';
import notificationsHelper from 'app/api/helperServices/notifications';
import {
    startBackgroundGeolocation,
    stopBackgroundGeolocation,
    startBackgroundLocationTracking,
    stopBackgroundLocationTracking,
} from 'app/api/helperServices/geolocation';
import SplashScreen from 'react-native-splash-screen';
import { YellowBox, Linking, Platform, AppState } from 'react-native';

//import { ScrollView, View, Text } from 'react-native';

setGlobalHandler();

class App extends React.Component {
    constructor(props) {
        super(props);
        //Todo: remove it soon... how soon?
        YellowBox.ignoreWarnings([
            'Warning: componentWillMount is deprecated',
            'Warning: componentWillReceiveProps is deprecated',
            'Warning: componentWillUpdate is deprecated',
        ]);

        this.state = {
            isStoreHydrated: false,
            hydratedStore: configureStore(() => {
                setTimeout(() => {
                    this.setState({ isStoreHydrated: true }, () => {
                        this.state.hydratedStore.store.dispatch(appStateChange(AppState.currentState));
                    });
                    //startBackgroundGeolocation();
                    //notificationsHelper.configure();
                }, 200);
            }),
        };
    }

    handleAppStateChange = nextAppState => {
        this.setState({ appState: nextAppState });
        const { store } = this.state.hydratedStore;
        if (store) {
            store.dispatch(appStateChange(nextAppState));
        }
    };

    componentDidMount() {
        // TEST deeplink command:  adb shell am start -W -a android.intent.action.VIEW -d "adm://mims/search" com.mims
        AppState.addEventListener('change', this.handleAppStateChange);
        startBackgroundLocationTracking();
        if (Platform.OS === 'android') {
            Linking.getInitialURL().then(deeplink => {
                this.handleLinks({ url: deeplink });
            });
        }
        Linking.addEventListener('url', this.handleLinks);
    }

    componentWillUnmount() {
        //stopBackgroundLocationTracking();
        AppState.removeEventListener('change', this.handleAppStateChange);
        Linking.removeEventListener('url', this.handleLinks);
        if (this.splashTimer) {
            clearTimeout(this.splashTimer);
        }
        if (this.deeplinkTimer) {
            clearTimeout(this.deeplinkTimer);
        }
    }

    deeplinkTimer;
    splashTimer;
    navigatorRef;

    handleLinks = event => {
        if (event.url) {
            this.deeplinkTimer = setTimeout(() => {
                const { store } = this.state.hydratedStore;
                const storedState = store.getState();
                const { auth } = storedState;
                const loggedIn = (auth && auth.loggedIn) || false;
                if (this.navigatorRef) {
                    store.dispatch(handleDeeplink({ deeplink: event.url, loggedIn, dispatch: this.navigatorRef.dispatch }));
                }
            }, 1000);
        }
    };

    render() {
        if (this.state.isStoreHydrated) {
            const { store, persistor } = this.state.hydratedStore;

            //first handle the language settings in the stored state, if any.
            //it may restart the app if current languange is different from the stored one.

            const defaultLocale = 'en-US';
            const storedState = store.getState();
            if (!!storedState && !!storedState.settings && !!storedState.settings.locale) {
                store.dispatch(initLanguage(storedState.settings.locale));
                setLocale(storedState.settings.locale);
            } else {
                store.dispatch(initLanguage(defaultLocale));
                setLocale(defaultLocale);
            }

            initAllRoutesDefinitions(mainStackDefinition, inspectionStackDefinition);
            this.splashTimer = setTimeout(() => {
                SplashScreen.hide();
            }, 300);

            return (
                <Provider store={store}>
                    <PaperProvider theme={theme}>
                        <SwitchNavigator
                            ref={navigatorRef => {
                                if (navigatorRef) {
                                    this.navigatorRef = navigatorRef;
                                }
                            }}
                        />
                        <DropdownAlert
                            defaultContainer={{ padding: 8, paddingTop: StatusBar.currentHeight, flexDirection: 'row' }}
                            ref={ref => alertsHelper.setAlertProvider(ref)}
                            showCancel={true}
                            onClose={() => alertsHelper.invokeOnClose()}
                            onCancel={data => alertsHelper.invokeOnCancel(data)}
                        />
                    </PaperProvider>
                </Provider>
            );
        } else return null;
    }
}

export default App;

/*
    //without redux-persist use below code

    //export default () => <Provider store={store}><MainStackNavigator /></Provider>

    export default () => <Provider store={store}><SwitchNavigator /></Provider>

    // export default () => {
    //     return (
    //         <PaperProvider>
    //             <AuthNavigator />
    //         </PaperProvider>
    //     );
    // }

    //export default () => <AlertProvider><Navigator /></AlertProvider>
*/
