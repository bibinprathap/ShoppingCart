import update, { extend } from 'immutability-helper';
import {
    ATTACHMENTS_UNLOAD_ALL,
    ATTACHMENT_ADD_IMAGE,
    ATTACHMENT_REMOVE_IMAGE,
    ATTACHMENT_ADD_AUDIO,
    ATTACHMENT_ADD_VIDEO,
    ATTACHMENT_ADD_PDF,
    ATTACHMENT_STARTED_UPLOADING,
    ATTACHMENT_STARTED_UPLOADED,
    ATTACHMENT_UPLOAD_ERROR,
} from 'app/actions/attachments';
import { INSPECTION_CLEARHISTORY } from 'app/actions/inspections';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';

import { _ } from 'lodash';

const initialState = {
    hasPendingUploads: false,
    hasPendingDownloads: false,
    uploading: false,
    downloading: false,
    docs: [],
    envState: {},
};

const getDoc = (state, id) => {
    return _.find(state.docs, docItem => docItem.id == id);
};

const addDoc = (state, payload) => {
    const newArray = state.docs.slice();
    newArray.push(payload);
    return { ...state, hasPendingUploads: true, docs: newArray };
};

const addOrUpdateDoc = (state, payload) => {
    if (!payload) return state;
    const { id } = payload || {};
    if (!id) throw 'To add an attachment, payload must have an Id';
    const index = _.findIndex(state.docs, docItem => docItem.id == id);
    if (index == -1) {
        //couldn't find, add it
        return addDoc(state, payload);
    }
    const newArray = state.docs.slice();
    newArray[index] = { ...newArray[index], ...payload };

    return { ...state, hasPendingUploads: true, docs: newArray };
};

const updateDoc = (state, payload) => {
    if (!payload) return state;
    const { id } = payload || {};
    if (!id) throw 'To update an attachment, payload must have an Id';
    const index = _.findIndex(state.docs, docItem => docItem.id == id);
    if (index == -1) {
        //couldn't find, return state
        return state;
    }
    return update(state, {
        hasPendingUploads: { $set: true },
        docs: {
            [index]: {
                fileName: { $set: payload.uploadId },
                createdBy: { $set: payload.createdBy },
                inspectionId: { $set: payload.inspectionId },
                uploading: { $set: payload.uploading },
                error: { $set: undefined },
            },
        },
    });
};

const updatedDoc = (state, payload) => {
    if (!payload) return state;
    const { fileName } = payload || {};
    if (!fileName) throw 'To complete update an attachment, payload must have an Id';
    const index = _.findIndex(state.docs, docItem => docItem.fileName == fileName);
    if (index == -1) {
        //couldn't find, return state
        return state;
    }

    return update(state, {
        hasPendingUploads: { $set: false },
        docs: {
            [index]: {
                uploading: { $set: payload.uploading },
                uploaded: { $set: payload.uploaded },
                createdDate: { $set: payload.createdDate },

                createdBy: {
                    $apply: function(x) {
                        if (payload.createdBy == undefined) return x;
                        else return payload.createdBy;
                    },
                },
                uploadedDate: { $set: payload.uploadedDate },
                fileName: { $set: payload.fileName },
                path: { $set: payload.path },
                deleteToken: { $set: payload.deleteToken },
                documentId: { $set: payload.documentId },
            },
        },
    });
};

const updateErrorDoc = (state, payload) => {
    if (!payload) return state;
    const { fileName } = payload || {};
    if (!fileName) throw 'To complete update an attachment, payload must have an Id';
    const index = _.findIndex(state.docs, docItem => docItem.fileName == fileName);
    if (index == -1) {
        //couldn't find, return state
        return state;
    }

    return update(state, {
        hasPendingUploads: { $set: true },
        docs: {
            [index]: {
                error: { $set: payload.error },
                uploading: { $set: false },
                uploaded: { $set: false },
                uploadedDate: { $set: payload.uploadedDate },
            },
        },
    });
};

const removeDoc = (state, payload) => {
    if (!payload) return state;
    const { id } = payload || {};
    if (!id) throw 'To remove an attachment, payload must have an Id';
    const index = _.findIndex(state.docs, docItem => docItem.id == id);
    if (index == -1) {
        //couldn't find, return state
        return state;
    }

    if (index === 0 && state.docs.length === 1) {
        return { ...state, hasPendingUploads: false, docs: [] };
    }

    return { ...state, hasPendingUploads: false, docs: [...state.docs.slice(0, index), ...state.docs.slice(index + 1)] };
};

const reducer = (state = initialState, action) => {
    let newState = undefined;
    switch (action.type) {
        case INSPECTION_CLEARHISTORY:
            //Todo: keep the attachments that are not uploaded yet, for the inspections that are in history
            //for now just remove all
            return initialState;
        case ATTACHMENTS_UNLOAD_ALL:
            return initialState;
        case ATTACHMENT_ADD_IMAGE:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_STARTED_UPLOADING:
            newState = updateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_STARTED_UPLOADED:
            newState = updatedDoc(state, action.payload);
            return newState;
        case ATTACHMENT_UPLOAD_ERROR:
            newState = updateErrorDoc(state, action.payload);
            return newState;
        case ATTACHMENT_REMOVE_IMAGE:
            newState = removeDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_AUDIO:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_VIDEO:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_PDF:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = Object.assign({}, state);
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: { ...state.envState, ...backupState } };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        default:
            return state;
    }
};

export default reducer;
