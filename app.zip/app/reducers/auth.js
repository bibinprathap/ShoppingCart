import { AUTH_BEGIN, AUTH_START_BASIC, AUTH_START_SMARTPASS, AUTH_FAILURE, AUTH_SUCESS, AUTH_LOGOUT, AUTH_CANCEL_LOGIN } from 'app/actions/auth';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';

const initialState = {
    //authStarted: false,
    //loggedIn: false,
    //loggingIn: false,
};

const authSuccessDefaults = data => {
    //perhaps we should get domainCustomerId in the above line? for now using applicationUserId because the tasks and notifications are being sent to applicationUserId
    return {
        authStarted: false,
        loggedIn: true,
        loggingIn: false,
        error: null,
        tokenData: data.tokenData,
        userData: data.userData,
        authCode: data.authCode,
        profiles: data.profiles,
        activeProfileUserId: data.activeProfileUserId,
    };
};

const authFailureDefaults = error => ({
    authStarted: false,
    loggedIn: false,
    loggingIn: false,
    error: error,
});

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case AUTH_BEGIN:
            return {
                ...state,
                loggingIn: true,
                remember: action.remember,
                loginType: action.loginType,
            };
        case AUTH_START_BASIC:
            return { ...state, authStarted: true };
        case AUTH_START_SMARTPASS:
            return { ...state, authStarted: true };
        case AUTH_SUCESS:
            return { ...state, ...authSuccessDefaults(action.data) };
        case AUTH_FAILURE:

            const failureState = {
                ...state,
                ...authFailureDefaults(action.error),
            };
            delete failureState.tokenData;
            return failureState;
        case AUTH_LOGOUT:
            return {
                ...initialState,
                remember: state.remember,
                userData: state.remember ? state.userData : null,
            };
        case SETTINGS_CHANGE_ENVIRONMENT:
            return { ...initialState };
        case AUTH_CANCEL_LOGIN: {

            const cancelledLoginState = {
                ...state,
                ...authFailureDefaults(),
            };
            return cancelledLoginState;
        }
        default:
            return state;
    }
};

export default reducer;
