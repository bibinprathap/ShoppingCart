import { AUTH_BEGIN, AUTH_START_BASIC, AUTH_START_SMARTPASS, AUTH_FAILURE, AUTH_SUCESS, AUTH_LOGOUT } from 'app/actions/auth';

const initialState = {
    //authStarted: false,
    //loggedIn: false,
    //loggingIn: false,
};

const authSuccessDefaults = data => {
    const { profiles } = data;
    const activeProfile = (profiles && profiles.length > 0 && profiles[0]) || {};
    const activeProfileDomainCustomerId = activeProfile.domainCustomerId;
    return {
        authStarted: false,
        loggedIn: true,
        loggingIn: false,
        error: null,
        tokenData: data.tokenData,
        userData: data.userData,
        authCode: data.authCode,
        profiles: data.profiles,
        activeProfileDomainCustomerId,
    };
};

const authFailureDefaults = error => ({
    authStarted: false,
    loggedIn: false,
    loggingIn: false,
    error: error,
});

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case AUTH_BEGIN:
            return {
                ...state,
                loggingIn: true,
                remember: action.remember,
                loginType: action.loginType,
            };
        case AUTH_START_BASIC:
            return { ...state, authStarted: true };
        case AUTH_START_SMARTPASS:
            return { ...state, authStarted: true };
        case AUTH_SUCESS:
            return { ...state, ...authSuccessDefaults(action.data) };
        case AUTH_FAILURE:
            console.log('AUTH_FAILURE... error:', action.error);
            const failureState = {
                ...state,
                ...authFailureDefaults(action.error),
            };
            delete failureState.tokenData;
            return failureState;
        case AUTH_LOGOUT:
            return {
                ...initialState,
                remember: state.remember,
                userData: state.remember ? state.userData : null,
            };
        default:
            return state;
    }
};

export default reducer;
