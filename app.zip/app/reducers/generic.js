import update, { extend } from 'immutability-helper';
import { CHART_SUCCESS, CHART_FAILURE } from 'app/actions/generic';

const initialState = { dashboardChart: { isLoading: false, results: [] } };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case CHART_SUCCESS:
            return { ...state, dashboardChart: { isLoading: false, results: action.results } };

        case CHART_FAILURE:
            return { ...state, dashboardChart: { isLoading: false } };

        default:
            return state;
    }
};

export default reducer;
