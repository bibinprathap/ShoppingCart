import { GET_CHART_SUCCESS, GET_CHART_FAILURE, GET_LIST, GET_LIST_SUCCESS, GET_LIST_FAILURE, RESET_LISTS } from 'app/actions/generic';
import { INSPECTION_CLEARHISTORY } from 'app/actions/inspections';

const initialState = { dashboardChart: { lastRefresh: true, results: [] }, form: {} };
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_CHART_SUCCESS:
            return { ...state, dashboardChart: { lastRefresh: action.lastRefresh, results: action.results } };

        case GET_CHART_FAILURE:
            return { ...state, dashboardChart: {} };
        case GET_LIST:
        case GET_LIST_SUCCESS:
        case GET_LIST_FAILURE:
            const { formName, fieldName, data } = action.params;
            if (formName && fieldName) {
                const formObj = {};
                formObj[formName] = typeof state.form[formName] === 'undefined' ? {} : { ...state.form[formName] };

                if (typeof formObj[fieldName] === 'undefined') {
                    formObj[formName][fieldName] = {};
                }
                formObj[formName][fieldName].isLoading = action.type === 'GET_LIST' ? true : false;
                formObj[formName][fieldName].data = action.type === 'GET_LIST_SUCCESS' && data ? data : [];
                return { ...state, form: { ...state.form, ...formObj } };
            }
            return state;
        case RESET_LISTS:
            let { params } = action;
            if (params.formName && params.fieldNames && params.fieldNames.length > 0) {
                const formObjRest = {};
                formObjRest[params.formName] = typeof state.form[params.formName] === 'undefined' ? {} : { ...state.form[params.formName] };
                params.fieldNames.forEach(fieldName => {
                    if (typeof formObjRest[params.formName][fieldName] === 'undefined') {
                        formObjRest[params.formName][fieldName] = {};
                    }
                    formObjRest[params.formName][fieldName] = { isLoading: false, data: [] };
                });
                return { ...state, form: { ...state.form, ...formObjRest } };
            }
            return state;

        case INSPECTION_CLEARHISTORY:
            return { ...state, ...initialState };
        default:
            return state;
    }
};

export default reducer;
