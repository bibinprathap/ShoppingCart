import { CHART_SUCCESS, CHART_FAILURE, SET_FORM_FIELD_LOADER } from 'app/actions/generic';

const initialState = { dashboardChart: { isLoading: false, results: [] }, formFieldLoader: {} };
debugger;
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case CHART_SUCCESS:
            return { ...state, dashboardChart: { isLoading: false, results: action.results } };

        case CHART_FAILURE:
            return { ...state, dashboardChart: { isLoading: false } };
        case SET_FORM_FIELD_LOADER:
            if (action.formName && action.fieldName) {
                const formObj = {};

                formObj[action.formName] = Object.assign({}, state.formFieldLoader[action.formName]);
                formObj[action.formName][action.fieldName] = action.isLoading;

                return { ...state, formFieldLoader: { ...formObj } };
            }
            return state;
        default:
            return state;
    }
};

export default reducer;
