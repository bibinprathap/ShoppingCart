import { combineReducers } from 'redux';
import auth from './auth';
import settings from './setttings';
import masterdata from './masterdata';
import inspections from './inspections';
import attachments from './attachments';
import tracking from './tracking';
import notifications from './notifications';
import tasks from './tasks';

export { auth, settings, masterdata, inspections, attachments, tracking, notifications, tasks };
