import { combineReducers } from 'redux';
import auth from './auth';
import settings from './setttings';
import masterdata from './masterdata';
import inspections from './inspections';
import attachments from './attachments';
import tracking from './tracking';
import notifications from './notifications';
import tasks from './tasks';
import search from './search';
import generic from './generic';
import loader from './loader';

export { auth, settings, masterdata, inspections, attachments, tracking, notifications, tasks, search, generic, loader };
