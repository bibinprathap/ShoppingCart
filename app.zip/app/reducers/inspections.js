import update, { extend } from 'immutability-helper';
import { _ } from 'lodash';

import {
    INSPECTION_CREATENEW,
    INSPECTION_COORDSCHANGED,
    INSPECTION_ADDRESSCHANGED,
    INSPECTION_SELECTSERVICE,
    INSPECTION_CLEARHISTORY,
    INSPECTION_VALUECHANGED,
    INSPECTION_INFOCHANGED,
    INSPECTION_SELECT,
    INSPECTION_SELECT_SUCCESS,
    INSPECTION_SAVENEW,
    INSPECTION_SAVE_SUCESS,
    INSPECTION_SAVE_FAILURE,
    INSPECTION_UPDATE,
    INSPECTION_INFOVIOLATORCHANGED,
    INSPECTION_ADDEDNEWVIOLATOR,
    INSPECTION_ADDNEWLOG,
    INSPECTION_UPDATEVIOLATIONS,
    INSPECTION_REMOVEVIOLATOR,
    INSPECTION_DUPCHK_START,
    INSPECTION_DUPCHK_SUCCESS,
    INSPECTION_DUPCHK_FAILURE,
    INSPECTION_RECORDCREATE_START,
    INSPECTION_RECORDCREATE_SUCCESS,
    INSPECTION_RECORDCREATE_FAILURE,
    INSPECTION_SET_DUPLICATE,
    INSPECTION_CHECKLIST_SET_DUPLICATE,
    INSPECTION_ADD_VIOLATIOR_SIGNATURE,
    INSPECTION_REMOVE_VIOLATIOR_SIGNATURE,
    INSPECTION_ADD_NEXT_VISIT,
} from 'app/actions/inspections';

import { unloadAllAttachments } from 'app/actions/attachments';
import { inspectionsHelper } from 'app/api/helperServices';

const initialState = { currentInspectionRef: null, history: {} };

const getInspectionProperty = (state, refNumber, key) => {
    const inspectionContainer = state.history[refNumber];
    return { ...inspectionContainer.inspection[key] };
};

const setInspectionProperty = (state, refNumber, key, value) => {
    const inspectionContainer = state.history[refNumber];
    const valueChanged = inspectionContainer.inspection[key] !== value;
    return update(state, {
        currentInspectionVersion: {
            $apply: function(currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [refNumber]: {
                inspection: {
                    [key]: { $set: value },
                },
                saved: { $set: valueChanged ? false : inspectionContainer.saved },
            },
        },
    });
};

const setNexVisit = (state, refNumber) => {
    const nexinspection = {
        type: 'followup',
        values: {},
        def: {
            def: [
                {
                    name: 'generalInfoForm',
                    titleE: 'General Information',
                    titleA: 'معلومات عامة',
                    showFormTitle: true,
                    collapsible: true,
                    showLabels: true,
                    fields: [
                        {
                            name: 'fieldGroup1',
                            type: 'fieldGroup',
                            fields: [
                                {
                                    name: 'remarks',
                                    type: 'text',
                                    labelE: 'Remarks',
                                    labelA: 'ملاحظات',
                                    placeholderE: 'Remarks',
                                    placeholderA: 'ملاحظات',
                                    maxLength: 200,
                                    multiline: true,
                                    mode: 'flat',
                                    debounce: 500,
                                    validationRule: ['string', 'required'],
                                },
                            ],
                        },
                    ],
                },
            ],
        },
    };
    //return state;
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: { $push: [nexinspection] },
                },
            },
        },
    });
};

const setCreateInspectionRecordProperty = (state, refNumber, creatingInspectionID, inspectionID, creatingInspectionError) => {
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    saving: { $set: creatingInspectionID },
                    inspectionID: { $set: inspectionID },
                    savingerror: { $set: creatingInspectionError },
                },
            },
        },
    });
};

const setInitialDistrotionTypeProperty = (newState, refNumber, value) => {
    if (!newState.history[refNumber].inspection.info) newState.history[refNumber].inspection.info = { distortionForm: {} };
    else if (!newState.history[refNumber].inspection.info.distortionForm) newState.history[refNumber].inspection.info.distortionForm = {};
    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        distortionForm: {
                            distortionType: { $set: value },
                        },
                    },
                },
            },
        },
    });
};

const setInspectionLocation = (state, refNumber, key, value) => {
    const inspectionContainer = state.history[refNumber];

    const valueChanged =
        (inspectionContainer &&
            inspectionContainer.inspection &&
            inspectionContainer.inspection.location &&
            inspectionContainer.inspection.location.address) !== value;
    if (inspectionContainer.inspection.location == undefined) inspectionContainer.inspection.location = {};
    return update(state, {
        currentInspectionVersion: {
            $apply: function(currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [refNumber]: {
                inspection: {
                    location: { $merge: { [key]: value } },
                    info: {
                        $apply: function(currentVersion) {
                            return currentVersion;
                        },
                    },
                },
                saved: { $set: valueChanged ? false : inspectionContainer.saved },
            },
        },
    });
};

const getMergedChecklistDef = (state, refNumber, checklistDef) => {
    const currentInspectionContainer = state.history[refNumber];
    let mergedChecklistDef = {
        ...(currentInspectionContainer.inspection.checklistDef || undefined),
        ...(checklistDef || undefined),
    };
    return mergedChecklistDef;
};

const clearHistory = state => {
    //Todo: keep the inspections which have unsaved data
    //for now just remove all history.
    return initialState;
};

const getTrimmedServiceObject = serviceDefinition => {
    if (!!serviceDefinition) {
        return serviceDefinition.serviceId;
        // return {
        //     serviceId: serviceDefinition.serviceId,
        //     titleE: serviceDefinition.titleE,
        //     titleA: serviceDefinition.titleA,
        // };
    } else return undefined;
};

const setInspectionValues = (state, refNumber, visitIndex, newValues) => {
    const newState = { ...state };
    newState.history[refNumber].inspection.visits[visitIndex].values = newValues;
    return newState;
};

const setInspectionInfo = (state, refNumber, key, value) => {
    const newState = { ...state };
    const newInfo = { ...newState.history[refNumber].inspection.info, [key]: value };
    newState.history[refNumber].inspection.info = newInfo;
    return newState;
};
const setInspectionViolatorInfo = (state, refNumber, key, value, uiIdentifier) => {
    let violatorindex = state.history[refNumber].inspection.info.violators
        .map(function(e) {
            return e.UIIdentifier || 0;
        })
        .indexOf(uiIdentifier || 0);
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        violators: {
                            [violatorindex]: {
                                [key]: { $set: value },
                            },
                        },
                    },
                },
            },
        },
    });
    // if (key == 'violatorType') {
    //     let newViolator = {
    //         UIIdentifier: uiIdentifier,
    //         Order: 1,
    //         violatorType: value,
    //     };
    //     return update(state, {
    //         history: {
    //             [refNumber]: {
    //                 inspection: {
    //                     info: {
    //                         violators: {
    //                             [violatorindex]: { $set: newViolator },
    //                         },
    //                     },
    //                 },
    //             },
    //         },
    //     });
    // }
};
const getNewDuplicates = (newState, refNumber) => {
    if (newState.history[refNumber].inspection.duplicateCheck.duplicates != undefined) {
        //already there is some  duplicate
        if (newState.history[refNumber].inspection.duplicateCheck.duplicates.length > 0) {
            let newDuplicate = { ...newState.history[refNumber].inspection.duplicateCheck.duplicates };
            let newDuplicateArray = [];
            newDuplicate.map((d, i) => {
                let duplicateindex = newState.history[refNumber].inspection.duplicateCheck.duplicateCantidates
                    .map(function(e) {
                        return e.refNumber || 0;
                    })
                    .indexOf(d.refNumber || 0);
                if (duplicateindex > -1) {
                    newDuplicateArray.push(d);
                }
            });
            if (newDuplicateArray.length == 0) return undefined;
            else return newDuplicateArray;
        }
        // currently user deside  there is no duplicate
        else {
            return [];
        }
    }
    return undefined;
};
const addNewDuplicateInspection = (state, refNumber, newDuplicate) => {
    if (state.history[refNumber].inspection.duplicateCheck.duplicates != undefined) {
        return update(state, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicateCheck: {
                            duplicates: { $set: newDuplicate },
                        },
                    },
                },
            },
        });
    } else return state;
};

const setCheckListDuplicateInspection = (state, refNumber, value, duplicaterefNumber, lawClausesID) => {
    let newState = { ...state };
    if (newState.history[refNumber].inspection.duplicateCheck.duplicates == undefined) {
        newState.history[refNumber].inspection.duplicateCheck.duplicates = [];
    }
    const visitIndex = newState.history[refNumber].inspection.visits.length - 1;
    let duplicateInspectionIndex = state.history[refNumber].inspection.duplicateCheck.duplicates
        .map(function(e) {
            return e.lawClausesID;
        })
        .indexOf(lawClausesID);
    // is a violation
    if (duplicateInspectionIndex > -1) {
        newState = update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicateCheck: {
                            duplicates: { $splice: [[duplicateInspectionIndex, 1]] },
                        },
                    },
                },
            },
        });
    }
    let newDuplicate = {};
    // is a violation
    if (value == true) {
        newDuplicate = { refNumber: duplicaterefNumber, lawClausesID, isDuplicate: true, item: null };
    } else {
        newDuplicate = { lawClausesID, isDuplicate: false, item: null };
    }

    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    duplicateCheck: {
                        duplicates: { $push: [newDuplicate] },
                    },
                },
            },
        },
    });

    // return update(newState, {
    //     history: {
    //         [refNumber]: {
    //             inspection: {
    //                 visits: {
    //                     [visitIndex]: {
    //                         values: {
    //                             [checklistItemCode]: {
    //                                 didDuplicateCheck: { $set: true }
    //                             }
    //                         }
    //                     }
    //                 }
    //             },
    //         },
    //     },
    // });
};

const setDuplicateInspection = (state, refNumber, value, duplicaterefNumber) => {
    let newState = { ...state };
    if (newState.history[refNumber].inspection.duplicateCheck.duplicates == undefined) {
        newState.history[refNumber].inspection.duplicateCheck.duplicates = [];
    }
    // is a violation
    if (value == true) {
        const newDuplicate = { refNumber: duplicaterefNumber, item: null };
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicateCheck: {
                            duplicates: { $set: [newDuplicate] },
                        },
                    },
                },
            },
        });
    } else {
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicateCheck: {
                            duplicates: { $set: [] },
                        },
                    },
                },
            },
        });
    }
};

const updateViolationsOfAViolator = (state, refNumber, violatorIndex, violations) => {
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        violators: {
                            [violatorIndex]: { violations: { $set: violations } },
                        },
                    },
                },
            },
        },
    });
};

const removeAViolator = (state, refNumber, identifier) => {
    let violatorindex = state.history[refNumber].inspection.info.violators
        .map(function(e) {
            return e.UIIdentifier || 0;
        })
        .indexOf(identifier || 0);
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        violators: {
                            $splice: [[violatorindex, 1]],
                        },
                    },
                },
            },
        },
    });
};

const setNewViolatorsInfo = (newState, refNumber, value) => {
    if (!newState.history[refNumber].inspection.info) newState.history[refNumber].inspection.info = { violators: [] };
    else if (!newState.history[refNumber].inspection.info.violators) newState.history[refNumber].inspection.info.violators = [];
    let newViolator = {
        UIIdentifier: Math.floor(Math.random() * 100000000),
        Order: 1,
        violatorType: value.violatorType,
        violations: value.violations,
    };
    if (value.violatorType == 'individual') newViolator.violatorIsPresent = true;
    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        violators: { $push: [newViolator] },
                    },
                },
            },
        },
    });
};

const addNewLog = (newState, refNumber, log) => {
    // currentInspectionVersion: {
    //     $apply: function(currentVersion) {
    //         return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
    //     },
    // },
    const refno = log.inspectionID || refNumber;
    if (refno && newState.history[refno])
        return update(newState, {
            history: {
                [log.inspectionID || refNumber]: {
                    logs: { $push: [log] },
                },
            },
        });
    else return newState;
};

const setInspectionVisitInfo = (state, refNumber, visitIndex, key, value) => {
    const newState = { ...state };
    const currentVisitData = newState.history[refNumber].inspection.visits[visitIndex];
    newState.history[refNumber].inspection.visits[visitIndex] = { ...currentVisitData, [key]: value };
    return newState;
};

const setInspectionDefinition = (state, refNumber, visitIndex, def) => {
    const newState = { ...state };
    newState.history[refNumber].inspection.visits[visitIndex].def = def;
    return newState;
};

const updateVersion = state => {
    /*
    update the currently selected inspection version
    to signal the subscribing components that they should re-render.
    for performance reasons most component will use the outer container, and will not re-render when
    some embedded property of the selected inspection is changed.
    this version gives us control on when we want to trigger the re-render such components   
    */
    return update(state, {
        currentInspectionVersion: {
            $apply: function(currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
    });
    // const currentVersion = state.currentInspectionVersion;
    // return { ...state, currentInspectionVersion: isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1 };
};
const createNewInspection = (state, newInspection) => {
    // return update(state, {
    //     currentInspectionRef: { $set: newInspection.refNumber },
    //     currentInspectionVersion: { $set: '' },
    //     history: {
    //         [newInspection.refNumber]: {
    //             $set: {
    //                 status: 'new',
    //                 saved: false,
    //                 inspection: newInspection,
    //             }
    //         }
    //     }
    // });
    return {
        ...state,
        currentInspectionRef: newInspection.refNumber,
        currentInspectionVersion: '',
        history: {
            [newInspection.refNumber]: {
                status: 'new',
                saved: false,
                inspection: newInspection,
                logs: [],
            },
            ...state.history,
        },
    };
};

const addViolatorSignature = (state, payload) => {
    const violators = inspectionsHelper.getViolators(state.history[state.currentInspectionRef]);
    var violatorindex = _.findIndex(violators, { UIIdentifier: payload.violatorIdentifier });

    return update(state, {
        currentInspectionVersion: {
            $apply: function(currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [state.currentInspectionRef]: {
                inspection: {
                    info: {
                        violators: {
                            [violatorindex]: {
                                signature: { $set: payload.attachmentId },
                            },
                        },
                    },
                },
            },
        },
    });
};

const removeViolatorSignature = (state, payload) => {
    const violators = inspectionsHelper.getViolators(state.history[state.currentInspectionRef]);
    var violatorindex = _.findIndex(violators, { UIIdentifier: payload.violatorIdentifier });

    return update(state, {
        currentInspectionVersion: {
            $apply: function(currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [state.currentInspectionRef]: {
                inspection: {
                    info: {
                        violators: {
                            [violatorindex]: {
                                signature: { $set: null },
                            },
                        },
                    },
                },
            },
        },
    });
};

const reducer = (state = initialState, action) => {
    let newState = undefined;
    let updatedDuplicateCheckProp = undefined;
    switch (action.type) {
        case INSPECTION_CREATENEW:
            newState = createNewInspection(state, action.payload);
            return newState;
        case INSPECTION_UPDATE:
            return { ...state, [action.payload.prop]: action.payload.value };
        case INSPECTION_SAVE_SUCESS:
            newState = setInspectionProperty(state, state.currentInspectionRef, 'locallySaved', true);
            return updateVersion(newState);
        case INSPECTION_ADD_NEXT_VISIT:
            newState = setNexVisit(state, state.currentInspectionRef);
            return updateVersion(newState);
        case INSPECTION_COORDSCHANGED:
            return setInspectionLocation(state, state.currentInspectionRef, 'coords', action.payload);
        case INSPECTION_ADDRESSCHANGED:
            return setInspectionLocation(state, state.currentInspectionRef, 'address', action.payload);
        case INSPECTION_SELECT:
            return { ...state, currentInspectionRef: action.payload, currentInspectionVersion: 0 };
        case INSPECTION_SELECT_SUCCESS:
            const inspectionId = action.payload.inspection['refNumber'];
            const inspectionObj = {};
            inspectionObj[inspectionId] = action.payload.inspection;
            return { ...state, history: { ...state.history, ...inspectionObj }, currentInspectionRef: inspectionId };
        case INSPECTION_SELECTSERVICE:
            const serviceObj = getTrimmedServiceObject(action.payload);
            newState = setInspectionProperty(state, state.currentInspectionRef, 'service', serviceObj);
            newState = setInspectionDefinition(newState, state.currentInspectionRef, 0, !action.payload ? undefined : action.payload.inspectionDef);
            // if (serviceObj == 1) {
            //     const distortionTypeDefaultValue = inspectionsHelper.getDistortionTypeDefaultValue();
            //     newState = setInitialDistrotionTypeProperty(newState, state.currentInspectionRef, distortionTypeDefaultValue);
            // }
            return updateVersion(newState);
        case INSPECTION_ADDEDNEWVIOLATOR:
            newState = setNewViolatorsInfo(state, state.currentInspectionRef, {
                violatorType: action.payload.value,
                violations: action.payload.violations,
            });
            return updateVersion(newState);
        case INSPECTION_ADDNEWLOG:
            return addNewLog(state, state.currentInspectionRef, action.payload.log);

        case INSPECTION_UPDATEVIOLATIONS:
            newState = updateViolationsOfAViolator(state, state.currentInspectionRef, action.payload.violatorindex, action.payload.violations);
            return updateVersion(newState);
        case INSPECTION_REMOVEVIOLATOR:
            newState = removeAViolator(state, state.currentInspectionRef, action.payload.identifier);
            return updateVersion(newState);
        case INSPECTION_VALUECHANGED:
            newState = setInspectionValues(state, state.currentInspectionRef, action.payload.visitIndex, action.payload.newValues);
            return updateVersion(newState);
        case INSPECTION_INFOVIOLATORCHANGED:
            newState = setInspectionViolatorInfo(
                state,
                state.currentInspectionRef,
                action.payload.key,
                action.payload.value,
                action.payload.identifier
            );
            return updateVersion(newState);
        case INSPECTION_INFOCHANGED:
            if (action.payload && action.payload.visit !== undefined) {
                newState = setInspectionVisitInfo(state, state.currentInspectionRef, action.payload.visit, action.payload.key, action.payload.value);
            } else {
                newState = setInspectionInfo(state, state.currentInspectionRef, action.payload.key, action.payload.value);
            }
            return updateVersion(newState);
        case INSPECTION_CLEARHISTORY:
            return clearHistory();
        case INSPECTION_DUPCHK_START:
            updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateCheck'),
                checking: true,
                error: undefined,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateCheck', updatedDuplicateCheckProp);
            return updateVersion(newState);
        case INSPECTION_DUPCHK_SUCCESS:
            let updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateCheck'),
                checking: false,
                error: undefined,
                ...action.payload.data,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateCheck', updatedDuplicateCheckProp);
            let newDuplicates = getNewDuplicates(newState, action.payload.refNumber);
            let newStateWithDuplicates = addNewDuplicateInspection(newState, action.payload.refNumber, newDuplicates);
            return updateVersion(newStateWithDuplicates);
        case INSPECTION_DUPCHK_FAILURE:
            updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateCheck'),
                checking: false,
                error: action.payload.error,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateCheck', updatedDuplicateCheckProp);
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_START:
            newState = setCreateInspectionRecordProperty(state, state.currentInspectionRef, true);
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_SUCCESS:
            newState = setCreateInspectionRecordProperty(state, state.currentInspectionRef, false, action.payload.inspectionID);
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_FAILURE:
            newState = setCreateInspectionRecordProperty(state, state.currentInspectionRef, false, undefined, action.payload.error);
            return updateVersion(newState);
        case INSPECTION_SET_DUPLICATE:
            newState = setDuplicateInspection(state, state.currentInspectionRef, action.payload.option, action.payload.inspection.refNumber);
            return updateVersion(newState);
        case INSPECTION_CHECKLIST_SET_DUPLICATE:
            newState = setCheckListDuplicateInspection(
                state,
                state.currentInspectionRef,
                action.payload.option,
                action.payload.inspection.refNumber,
                action.payload.inspection.lawClausesID
            );
            return updateVersion(newState);
        case INSPECTION_ADD_VIOLATIOR_SIGNATURE:
            return addViolatorSignature(state, action.payload);
        case INSPECTION_REMOVE_VIOLATIOR_SIGNATURE:
            return removeViolatorSignature(state, action.payload);

        default:
            return state;
    }
};

export default reducer;
