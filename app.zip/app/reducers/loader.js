import { LOADING_DATA, DATA_LOADED, MODAL_SHOWING, MODAL_CLOSED, RERENDER_MODAL } from 'app/actions/loader';

const initialState = { isLoading: false, modalShowing: false };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case LOADING_DATA:
            // console.warn('isLoading');
            return { ...state, isLoading: true };
        case DATA_LOADED:
            //  console.warn('isLoaded');
            return { ...state, isLoading: false };
        case MODAL_SHOWING:
            //  console.warn('isLoaded');
            return { ...state, modalShowing: true };
        case MODAL_CLOSED:
            //  console.warn('isLoaded');
            return { ...state, modalShowing: false };
        case RERENDER_MODAL:
            return { ...state, rerender: Math.random() };
        default:
            return state;
    }
};
export default reducer;
