import { LOADER_LOADING, LOADER_LOADED } from 'app/actions/loader';

const initialState = { isLoading: false };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case LOADER_LOADING:
            return { ...state, isLoading: true, ...action.payload };
        case LOADER_LOADED:
            return { ...state, isLoading: false, ...action.payload, isRunning: false };
        default:
            return state;
    }
};
export default reducer;
