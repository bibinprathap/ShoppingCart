import { _ } from 'lodash';
import {
    ADD_NOTIFICATION,
    NOTIFICATION_READ,
    NOTIFICATION_DELETE,
    NOTIFICATION_REFRESH_UNREAD_COUNT,
    NOTIFICATION_TOKEN,
    CLEAR_FCM_INSANCE,
    RESET_NOTIFICATIONS,
} from 'app/actions/notifications';
import moment from 'moment';
import firebase from 'app/api/helperServices/rnFirebaseNative';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';

const initialState = {
    notifications: {},
    unreadCount: 0,
    envState: {},
    fcmToken: null,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ADD_NOTIFICATION:
            let messageId = action.notification['google.message_id'] || action.notification['message_id'];

            if (action.notification && messageId && typeof state.notifications[messageId] === 'undefined') {
                const notificationObj = {};
                notificationObj[messageId] = action.notification;
                notificationObj[messageId].readAt = null;
                let orderedArray = _.orderBy({ ...state.notifications, ...notificationObj }, ['timestamp'], ['desc']);

                let orderedNotifications = {};
                let msgId = null;

                _.map(orderedArray, (item, index) => {
                    msgId = item['google.message_id'] || item['message_id'];
                    orderedNotifications[msgId] = item;
                });

                if (Object.keys(orderedNotifications).length >= 99 && msgId) {
                    delete orderedNotifications[msgId];
                }

                firebase.setBadgeNumber(state.unreadCount + 1);
                return {
                    ...state,
                    unreadCount: state.unreadCount + 1,
                    notifications: { ...orderedNotifications },
                };
            } else {
                return state;
            }
        case NOTIFICATION_READ:
            const notificationObj = {};
            notificationObj[action.notificationId] = {
                ...state.notifications[action.notificationId],
                readAt: moment().format('YYYY-MM-DD HH mm ss'),
            };

            let unreadCount = state.unreadCount;
            if (!state.notifications[action.notificationId].readAt && unreadCount > 0) {
                unreadCount = state.unreadCount - 1;
            }

            firebase.setBadgeNumber(unreadCount);
            return {
                ...state,
                unreadCount,
                notifications: { ...state.notifications, ...notificationObj },
            };

        case NOTIFICATION_DELETE:
            if (action.deleteAll === true) {
                return {
                    ...state,
                    unreadCount: 0,
                    notifications: {},
                };
            }
            const { [action.notificationId]: deletedItem, ...rest } = state.notifications;

            let unreadCountAfterDelete = state.unreadCount;
            if (!state.notifications[action.notificationId].readAt && unreadCountAfterDelete > 0) {
                unreadCountAfterDelete = state.unreadCount - 1;
            }

            firebase.setBadgeNumber(unreadCountAfterDelete);
            return {
                ...state,
                unreadCount: unreadCountAfterDelete,
                notifications: rest,
            };
        case NOTIFICATION_REFRESH_UNREAD_COUNT:
            return {
                ...state,
                unreadCount: _.filter(state.notifications, function(n) {
                    return n.readAt === null;
                }).length,
            };

        case NOTIFICATION_TOKEN:
            return {
                ...state,
                fcmToken: action.fcmToken,
            };

        case CLEAR_FCM_INSANCE:
            return {
                ...state,
            };

        case RESET_NOTIFICATIONS:
            return initialState;

        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = { ...state, envState: {} };
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: backupState };
                //return { ...state.envState[action.newenvironment], envState: { ...state.envState, ...backupState } };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        default:
            return state;
    }
};

export default reducer;
