import { _ } from 'lodash';
import {
    ADD_NOTIFICATION,
    NOTIFICATION_READ,
    NOTIFICATION_REFRESH_UNREAD_COUNT,
    NOTIFICATION_TOKEN,
    CLEAR_FCM_INSANCE,
    RESET_NOTIFICATIONS,
} from 'app/actions/notifications';
import moment from 'moment';
import firebase from 'app/api/helperServices/rnFirebaseNative';

const initialState = {
    notifications: {},
    unreadCount: 0,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ADD_NOTIFICATION:
            let messageId = action.notification['google.message_id'] || action.notification['message_id'];

            if (action.notification && messageId && typeof state.notifications[messageId] === 'undefined') {
                const notificationObj = {};
                notificationObj[messageId] = action.notification;
                notificationObj[messageId].readAt = null;
                let orderedArray = _.orderBy({ ...state.notifications, ...notificationObj }, ['timestamp'], ['desc']);

                let orderedNotifications = {};
                let msgId = null;

                _.map(orderedArray, (item, index) => {
                    msgId = item['google.message_id'] || item['message_id'];
                    orderedNotifications[msgId] = item;
                });

                if (Object.keys(orderedNotifications).length >= 99 && msgId) {
                    delete orderedNotifications[msgId];
                }

                firebase.setBadgeNumber(state.unreadCount + 1);
                return {
                    ...state,
                    unreadCount: state.unreadCount + 1,
                    notifications: { ...orderedNotifications },
                };
            } else {
                return state;
            }
        case NOTIFICATION_READ:
            const notificationObj = {};
            notificationObj[action.notificationId] = {
                ...state.notifications[action.notificationId],
                readAt: moment().format('YYYY-MM-DD HH mm ss'),
            };

            let unreadCount = state.unreadCount;
            if (!state.notifications[action.notificationId].readAt && unreadCount > 0) {
                unreadCount = state.unreadCount - 1;
            }

            firebase.setBadgeNumber(unreadCount);
            return {
                ...state,
                unreadCount,
                notifications: { ...state.notifications, ...notificationObj },
            };

        case NOTIFICATION_REFRESH_UNREAD_COUNT:
            return {
                ...state,
                unreadCount: _.filter(state.notifications, function(n) {
                    return n.readAt === null;
                }).length,
            };

        case NOTIFICATION_TOKEN:
            return {
                ...state,
                fcmToken: action.fcmToken,
            };

        case CLEAR_FCM_INSANCE:
            return {
                ...state,
                fcmToken: null,
            };

        case RESET_NOTIFICATIONS:
            return initialState;
        default:
            return state;
    }
};

export default reducer;
