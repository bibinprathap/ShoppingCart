import update, { extend } from 'immutability-helper';
import { SET_SEARCH_KEY, SEARCH, SET_FILTER, SEARCH_SUCCESS, SEARCH_FAILURE, RESET_SEARCH } from 'app/actions/search';

const initialState = { isLoading: false, results: [], searchKey: null, filter: { type: 'referenceNumber' } };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case SET_SEARCH_KEY:
            return { ...state, searchKey: action.searchKey };
        case SET_FILTER:
            return { ...state, filter: action.filter };
        case SEARCH:
            return { ...state, searchKey: action.searchKey, filter: action.filter, isLoading: true, results: [] };
        case SEARCH_SUCCESS:
            return { ...state, isLoading: false, results: action.results };
        case SEARCH_FAILURE:
            return { ...state, isLoading: false };
        case RESET_SEARCH:
            return { ...state, ...initialState, filter: state.filter };
        default:
            return state;
    }
};

export default reducer;
