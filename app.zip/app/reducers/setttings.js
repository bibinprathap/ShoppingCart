import {
    SETTINGS_INIT_LANGUANGE,
    SETTINGS_CALIBRATION,
    SETTINGS_CHANGE_ENVIRONMENT,
    SETTINGS_SELECTEDPRINTER,
    SET_DEEPLINK,
    CLEAR_DEEPLINK,
    SETTINGS_CAMERA_FLASH,
    SETTINGS_DASHBOARDNAV_CHANGED,
    SETTINGS_DASHBOARDHIS_CHANGED,
    SET_ALERT,
    UPDATE_SETTINGS,
} from 'app/actions/settings';
import I18n from 'i18n-js';

const initialState = {
    locale: I18n.locale.indexOf('ar') > -1 ? 'en-US' : 'ar-AE',
    isRtl: I18n.locale ? I18n.locale.indexOf('ar') > -1 : false,
    environment: 'test',
    selectedPrinter: {},
    deeplink: null,
    flashOn: false,
    backgroundTimerInterval: 1000000,
    triggerInterval: 3,
    calibration: 0,
    soundDecibelGraphInterval: 200,
    calendarView: false,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case UPDATE_SETTINGS:
            return { ...state, ...action.payload };
        case SETTINGS_INIT_LANGUANGE:
            const isRtl = I18n.locale ? I18n.locale.indexOf('ar') > -1 : false;
            return { ...state, locale: action.locale, isRtl };
        case SETTINGS_CALIBRATION:
            return { ...state, calibration: action.locale.calibration };
        case SETTINGS_CHANGE_ENVIRONMENT:
            return { ...state, environment: action.newenvironment, deeplink: null };
        case SETTINGS_SELECTEDPRINTER:
            return { ...state, selectedPrinter: action.printer };
        case SETTINGS_CAMERA_FLASH:
            return { ...state, flashOn: action.flash };
        case SET_DEEPLINK:
            return { ...state, deeplink: action.deeplink };
        case CLEAR_DEEPLINK:
            return { ...state, deeplink: null };
        case SETTINGS_DASHBOARDNAV_CHANGED:
            return { ...state, ...action.payload };
        case SETTINGS_DASHBOARDHIS_CHANGED:
            return { ...state, calendarView: action.calendarView };
        case SET_ALERT:
            return { ...state, alert: action.payload ? { ...action.payload } : null };
        default:
            return state;
    }
};

export default reducer;
