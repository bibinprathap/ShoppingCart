import {
    SETTINGS_INIT_LANGUANGE,
    SETTINGS_CHANGE_ENVIRONMENT,
    SETTINGS_SELECTEDPRINTER,
    SET_DEEPLINK,
    CLEAR_DEEPLINK,
    SETTINGS_CAMERA_FLASH,
} from 'app/actions/settings';

const initialState = {
    locale: 'en-US',
    isRtl: false,
    environment: 'development',
    selectedPrinter: {},
    deeplink: null,
    flashOn: false,
    backgroundTimerInterval: 60000,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case SETTINGS_INIT_LANGUANGE:
            const isRtl = action.locale.indexOf('ar') > -1;
            return { ...state, locale: action.locale, isRtl };
        case SETTINGS_CHANGE_ENVIRONMENT:
            return { ...state, environment: action.env };
        case SETTINGS_SELECTEDPRINTER:
            return { ...state, selectedPrinter: action.printer };
        case SETTINGS_CAMERA_FLASH:
            return { ...state, flashOn: action.flash };
        case SET_DEEPLINK:
            return { ...state, deeplink: action.deeplink, dispatch: action.dispatch };
        case CLEAR_DEEPLINK:
            return { ...state, deeplink: null };
        default:
            return state;
    }
};

export default reducer;
