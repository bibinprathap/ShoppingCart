import update, { extend } from 'immutability-helper';
import { TASK_CLEARHISTORY, TASK_CREATENEW, TASK_INITIALCREATE } from 'app/actions/tasks';
import { TASK_STARTED } from 'app/actions/inspections';

const initialState = { currentTaskRef: null, history: {} };

const createNewTask = (state, newTask) => {
    return update(state, {
        history: {
            [newTask.refNumber]: {
                $set: { ...newTask, status: 'new' },
            },
        },
    });
};

const createInitialTask = (state, tasks) => {
    return update(state, {
        history: { $set: tasks },
    });
};

const updateTaskStatus = (state, refNumber, taskId, status) => {
    return update(state, {
        history: {
            [taskId]: {
                refNumber: { $set: refNumber },
                status: { $set: status },
            },
        },
    });
};

const clearTask = state => {
    return initialState;
};
const reducer = (state = initialState, action) => {
    let newState = undefined;
    switch (action.type) {
        case TASK_CREATENEW:
            newState = createNewTask(state, action.payload);
            return newState;
        case TASK_INITIALCREATE:
            newState = createInitialTask(state, action.payload);
            return newState;
        case TASK_CLEARHISTORY:
            return clearTask();
        case TASK_STARTED:
            newState = updateTaskStatus(state, action.payload.refNumber, action.payload.taskId, action.payload.status);
            return newState;
        default:
            return state;
    }
};

export default reducer;
