import update, { extend } from 'immutability-helper';
import { TASK_CLEARHISTORY, TASK_CREATENEW, TASK_INITIALCREATE, TASK_DETAILS, TASK_REFRESH } from 'app/actions/tasks';
import { TASK_STARTED } from 'app/actions/inspections';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';

const initialState = { currentTaskRef: null, history: {}, envState: {} };

const createNewTask = (state, newTask) => {
    if (state.history[newTask.taskId]) return state;
    else
        return update(state, {
            history: {
                [newTask.taskId]: {
                    $set: { ...newTask, status: 'new' },
                },
            },
        });
};

const createInitialTask = (state, tasks) => {
    return update(state, {
        history: { $set: tasks },
    });
};

const refreshTasks = (state, tasks) => {
    Object.getOwnPropertyNames(state.history).map(t => {
        const taskId = state.history[t].taskId;
        if (!tasks[taskId]) {
            tasks[taskId] = state.history[t];
        }
    });
    return update(state, {
        history: { $set: tasks },
    });
};

const updateTaskStatus = (state, refNumber, taskId, status) => {
    return update(state, {
        history: {
            [taskId]: {
                refNumber: { $set: refNumber },
                status: { $set: status },
            },
        },
    });
};

const updateTaskDetails = (state, taskId, remarks, typeOfTasks, assignedBy, attachements) => {
    return update(state, {
        history: {
            [taskId]: {
                remarks: { $set: remarks },
                typeOfTasks: { $set: typeOfTasks },
                assignedBy: { $set: assignedBy },
                attachements: { $set: attachements },
            },
        },
    });
};

const clearTask = state => {
    return initialState;
};
const reducer = (state = initialState, action) => {
    let newState = undefined;
    switch (action.type) {
        case TASK_CREATENEW:
            newState = createNewTask(state, action.payload);
            return newState;
        case TASK_INITIALCREATE:
            newState = createInitialTask(state, action.payload);
            return newState;
        case TASK_REFRESH:
            newState = refreshTasks(state, action.payload);
            return newState;
        case TASK_CLEARHISTORY:
            return clearTask();
        case TASK_STARTED:
            newState = updateTaskStatus(state, action.payload.refNumber, action.payload.taskId, action.payload.status);
            return newState;
        case TASK_DETAILS:
            newState = updateTaskDetails(
                state,
                action.payload.taskId,
                action.payload.remarks,
                action.payload.typeOfTasks,
                action.payload.assignedBy,
                action.payload.attachements
            );
            return newState;

        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = Object.assign({}, state);
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: { ...state.envState, ...backupState } };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        default:
            return state;
    }
};

export default reducer;
