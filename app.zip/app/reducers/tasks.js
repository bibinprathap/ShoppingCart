import update, { extend } from 'immutability-helper';
import { TASK_CLEARHISTORY, TASK_CREATENEW, TASK_INITIALCREATE } from 'app/actions/tasks';

const initialState = { currentTaskRef: null, history: {} };

const createNewTask = (state, newTask) => {
    return update(state, {
        history: {
            [newTask.refNumber]: {
                $set: { ...newTask, status: 'new' },
            },
        },
    });
};

const createInitialTask = (state, tasks) => {
    return update(state, {
        history: { $set: tasks },
    });
};
const clearTask = state => {
    return initialState;
};
const reducer = (state = initialState, action) => {
    let newState = undefined;
    switch (action.type) {
        case TASK_CREATENEW:
            newState = createNewTask(state, action.payload);
            return newState;
        case TASK_INITIALCREATE:
            newState = createInitialTask(state, action.payload);
            return newState;
        case TASK_CLEARHISTORY:
            return clearTask();
        default:
            return state;
    }
};

export default reducer;
