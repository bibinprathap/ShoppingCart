import { TRACKING_LOCATION_UPDATE, TRACKING_APPSTATE_CHANGE } from 'app/actions/tracking';

const maxBacklog = 1000;
const initialState = {
    //lastEvent: undefined,
    //backlog: [],
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case TRACKING_LOCATION_UPDATE:
            return { ...state, lastEvent: action.event };
        case TRACKING_APPSTATE_CHANGE:
            return { ...state, appState: action.appState };
        default:
            return state;
    }
};

export default reducer;
