import React, { Component } from 'react';
import { _ } from 'lodash';
import { View, TouchableOpacity, Image } from 'react-native';
import { connect } from 'react-redux';
import { addImageAttachment, removeImageAttachment } from 'app/actions/attachments';
import { inspectionsHelper } from 'app/api/helperServices';
import { Text, Button } from 'react-native-paper';
import { Icon, AttachmentList, ZoomableImage, ImageMarker, AttachmentsHeader, Modal } from 'app/components';
import { screenWithSpinner } from 'app/components/WithSpinner';
import ImagePicker from 'react-native-image-crop-picker';
import RNFetchBlob from 'rn-fetch-blob';

import { strings } from 'app/config/i18n/i18n';
import { attachmentsHelper } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { getLocation } from 'app/api/helperServices/geolocation';
import styles from './styles';
import envConfig from 'app/api/config';
import AppApi from 'app/api/real';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { RNFileUploader } from 'app/api/helperServices';
import Pdf from 'react-native-pdf';
import { setLoaded } from 'app/actions/loader';
const api = new AppApi();

const env = envConfig;

const captureImageQuality = 1; //todo: take this from config/ store
const includeBase64 = false;
const swipThreshold = 100;

class Attachments extends Component {
    constructor(props) {
        super(props);
        this.state = { showImageEditor: false };
        this.addPicture = this.addPicture.bind(this);
        //this.setselectedAttachment = this.setselectedAttachment.bind(this);

        this.startUpload = this.startUpload.bind(this);
    }
    uploaderListener;
    componentDidMount() {
        const { attachments, onClose, selectedAttachment, editable } = this.props;
        const firstAttachment = !!attachments && attachments[0];
        this.setState({
            attachments,
            startedEmpty: !attachments || attachments.length == 0,
            selectedAttachment: selectedAttachment || firstAttachment,
            onClose,
            editable,
        });
    }

    componentDidUpdate() {
        const { firstUpdateDone, startedEmpty, editable } = this.state;
        if (!firstUpdateDone && startedEmpty && editable) {
            this.setState({ firstUpdateDone: true }, () => {
                this.handleAddPicturePressed(true);
            });
        }
    }
    onLayout = event => {
        const { width, height } = event.nativeEvent.layout;
        /*
            thumbnail with height and width same as (height - offset) of the parent view
        */
        const offset = styles.imageListContainer.padding * 2;
        if (!this.state.layoutDone) this.setState({ layoutDone: true, thumbnailHeight: height - offset, thumbnailWidth: height - offset });
    };

    handleOnClose = () => {
        //Todo: do any cleanup etc before closing this screen
        const { onClose } = this.state;
        // const payload = { result: {}, isRunning: false };
        if (onClose) onClose();
    };

    launchDrawEditor = () => {
        this.setState({ showImageEditor: true });
    };

    launchCropEditor = () => {
        const selectedAttachment = attachmentsHelper.getCommonImageProperties(this.state.selectedAttachment);
        const path = selectedAttachment && selectedAttachment.path;
        if (!path) return;
        try {
            if (path.indexOf('http') === 0) {
                attachmentsHelper.getRemoteImage(path).then(result => {
                    if (result) {
                        this.openCropper('file://' + result.path());
                    }
                });
            } else {
                this.openCropper(path);
            }
        } catch (e) {}
    };

    openCropper = async path => {
        const imageToCrop = this.state.selectedAttachment;
        if (!imageToCrop) return;
        try {
            const croppedImage = await ImagePicker.openCropper({
                path: path,
                width: imageToCrop.width,
                height: imageToCrop.height,
                cropperStatusBarColor: '#058DFC',
                cropperToolbarColor: '#058DFC',
                enableRotationGesture: true,
                freeStyleCropEnabled: true,
                compressImageQuality: captureImageQuality, //Todo: take this from settings
            });
            if (croppedImage) {
                this.handleImageRemove(imageToCrop);
                this.addPicture({ image: croppedImage, isNewImage: false });
            }
        } catch (e) {}
    };
    startUpload = uploadattachement => {
        const newAttachment = uploadattachement.path ? uploadattachement : this.state.selectedAttachment;
        attachmentsHelper.startUpload(newAttachment, this.props.environment, this.props.authCode, this.props.userData.uuid, 'InspectionPhoto');
    };

    addPicture = ({ image, isNewImage, coords }) => {
        try {
            const { inspInstanceId, inspTypeCheckItemId, parentInspectionId, workflowInstanceId, refNumber, visitIndex } = this.props;
            attachmentsHelper
                .prepareNewImageForAttachment({
                    contents: image,
                    quality: captureImageQuality,
                    mobileReferenceNumber: null,
                    inspInstanceId,
                    inspTypeCheckItemId,
                    parentInspectionId,
                    workflowInstanceId,
                    refNumber,
                    coords,
                    visitIndex,
                })
                .then(newAttachment => {
                    this.props.dispatch(addImageAttachment(newAttachment)).then(() => {
                        //dispach action for updating the reducer by inspectionid and uploading
                        this.startUpload(newAttachment);
                    });
                    const { onAdd } = this.props;
                    if (onAdd) onAdd(newAttachment);
                    const { attachments } = this.state;
                    const newAttachmentsArray = attachments || [];
                    if (!newAttachmentsArray.find(a => a.mobileReferenceNumber == newAttachment.mobileReferenceNumber))
                        newAttachmentsArray.push(newAttachment);
                    this.setState({
                        attachments: newAttachmentsArray,
                        selectedAttachment: newAttachment,
                    });
                });
        } catch (e) {}
    };

    handleAddPicturePressed = async isFirstAttachment => {
        var cancelRequested = false;
        const blockingTaskOptions = {
            id: 'attachment',
            message: strings('gettingLocation'),
            autoClose: true,
            autoRetry: false,

            maxTries: 0,
            requestCancel: () => {
                cancelRequested = true;
            },
            runner: async (options, updateOptions) => {
                let coords = null;

                try {
                    coords = await getLocation();

                    if (cancelRequested) {
                        throw 'Cancelled   by user';
                    }

                    if (cancelRequested) {
                        throw 'Cancelled   by user';
                    }
                } catch (error) {
                    updateOptions({ ...options, maxTries: 1, autoClose: false });
                    throw ` ${getErrorMessageWithDetail(error)}`;
                }

                const finalResult = await new Promise(async (resolve, reject) => {
                    ImagePicker.openCamera({
                        includeBase64: includeBase64,
                        includeExif: true,
                        enableRotationGesture: true,
                        compressImageQuality: captureImageQuality, //Todo: take this from settings
                        //cropping: true,
                    })
                        .then(image => {
                            //this.deleteFile(image.path);
                            //delete image.path; //don't store the path as file is going to be deleted anyway

                            this.addPicture({ image, isNewImage: true, coords });
                            resolve();
                        })
                        .catch(error => {
                            this.props.dispatch(setLoaded());
                            updateOptions({ ...options, maxTries: 0, autoClose: true });
                            if (error.code == 'E_PICKER_CANCELLED') {
                                const { startedEmpty, attachments } = this.state;
                                if (startedEmpty && (!attachments || attachments.length == 0)) {
                                    //if it had started empty and user cancelled the camera without taking snap
                                    this.handleOnClose();
                                    resolve();
                                }
                            } else {
                                alert(error);
                                resolve();
                            }
                        });
                });
                if (cancelRequested) {
                    throw 'Cancelled by user';
                }
                return finalResult;
            },
        };

        try {
            const result = await runBlockingTask(blockingTaskOptions);
        } catch (error) {
            if (isFirstAttachment) this.handleOnClose();
        }

        //Todo: fix the dimensions of the pic (default = portrait)
    };

    deleteFile = async path => {
        try {
            await RNFetchBlob.fs.unlink(path);
        } catch (e) {
            const msg = `Failed to delete file: ${path}`;

            alert(msg);
        }
    };

    handleThumbnailOnPress = doc => {
        setTimeout(() => {
            this.setState({ selectedAttachment: doc });
        }, 0);
    };

    handleImageRemove = async doc => {
        const { onRemove } = this.props;
        if (onRemove) onRemove(doc);

        const { selectedAttachment, attachments } = this.state;
        const { mobileReferenceNumber } = doc;

        // Todo: move below logic to the AttachmentList, as user can remove the attachment without opening the dialog

        if (typeof selectedAttachment === 'undefined') return;

        let currentIndex = _.findIndex(attachments, { mobileReferenceNumber: doc.mobileReferenceNumber });

        if (selectedAttachment.mobileReferenceNumber == doc.mobileReferenceNumber) {
            if (currentIndex == attachments.length - 1) currentIndex--;
        } else if (currentIndex > 0) {
            currentIndex--;
        }

        const newAttachmentsArray = _.filter(attachments, d => d.mobileReferenceNumber != doc.mobileReferenceNumber);

        this.setState({
            attachments: newAttachmentsArray,
            selectedAttachment: newAttachmentsArray.length ? newAttachmentsArray[currentIndex] : null,
        });
        this.props.dispatch(removeImageAttachment({ mobileReferenceNumber: mobileReferenceNumber }));
        const pendingUpload = this.props.pendingUploadDocs[mobileReferenceNumber];
        if (pendingUpload && pendingUpload.uploading) {
            RNFileUploader.cancelUpload(pendingUpload.mobileReferenceNumber);
        } else {
            const result = await api.deleteUploadedDocument(doc.mobileReferenceNumber);
            if (result && result.success) {
                // delete successfull
            }
        }

        // this.props.dispatch(removeImageAttachment({ mobileReferenceNumber: doc.mobileReferenceNumber }));
        // if (selectedAttachmentfromStore && selectedAttachmentfromStore.uploading) {
        //     RNFileUploader.cancelUpload(selectedAttachmentfromStore.fileName);
        // } else {
        //     const result = await api.deleteUploadedDocument(selectedAttachmentfromStore.deleteToken);
        //     if (result && result.success) {
        //         // delete successfull
        //     }
        // }
    };

    handleSwipLeft = xDiff => {
        if (xDiff >= swipThreshold) {
            this.selectAttachmentByIndexOffset(1);
        }
    };

    handleSwipRight = xDiff => {
        if (xDiff => swipThreshold) {
            this.selectAttachmentByIndexOffset(-1);
        }
    };

    selectAttachmentByIndexOffset = indexOffset => {
        const { selectedAttachment, attachments } = this.state;
        if (typeof selectedAttachment === 'undefined') return;
        const maxIndex = attachments.length - 1;
        if (maxIndex < 0) return;

        let currentIndex = _.findIndex(attachments, { mobileReferenceNumber: selectedAttachment.mobileReferenceNumber });

        let newIndex = currentIndex + indexOffset;
        if (newIndex < 0) {
            newIndex = maxIndex;
        } else if (newIndex > maxIndex) {
            newIndex = 0;
        }
        const newSelectedAttachment = attachments[newIndex];
        if (newSelectedAttachment) {
            this.setState({
                selectedAttachment: newSelectedAttachment,
            });
        }
    };

    saveEditedImage = imagePath => {
        if (imagePath) {
            const path = `file://${imagePath}`;

            Image.getSize(
                path,
                (width, height) => {
                    const imageObj = {
                        path,
                        height,
                        width,
                    };
                    const captureImageQuality = 1;
                    const coords = this.state.selectedAttachment.location.coords;
                    //    const address = this.state.selectedAttachment.location.address;

                    const {
                        inspInstanceId,
                        inspTypeCheckItemId,
                        parentInspectionId,
                        workflowInstanceId,
                        refNumber,
                        visitIndex,
                        inspectionTypeId,
                    } = this.props;
                    attachmentsHelper
                        .prepareNewImageForAttachment({
                            contents: imageObj,
                            quality: captureImageQuality,
                            mobileReferenceNumber: this.state.selectedAttachment.mobileReferenceNumber,
                            inspInstanceId,
                            inspTypeCheckItemId,
                            parentInspectionId,
                            workflowInstanceId,
                            refNumber,
                            coords,
                            visitIndex,
                        })
                        .then(editedImage => {
                            if (editedImage && this.state.selectedAttachment) {
                                editedImage.extension = 'jpg';
                                this.handleImageRemove(this.state.selectedAttachment);
                                this.addPicture({
                                    image: editedImage,
                                    isNewImage: false,
                                    coords: coords,
                                });
                                this.setState({ showImageEditor: false });
                            } else {
                                this.setState({ showImageEditor: false });
                                alertsHelper.show('error', 'Error', strings('unknown_error'));
                            }
                        });
                },
                error => {
                    this.setState({ showImageEditor: false });
                    alertsHelper.show('error', 'Error', strings('unknown_error'));
                }
            );
        }
    };

    render() {
        //Todo: if there are no exising attachments, open the camera without waiting for user to click on the button
        const { attachments, editable } = this.state;
        const selectedAttachment = this.state.selectedAttachment ? attachmentsHelper.getCommonImageProperties(this.state.selectedAttachment) : null;

        const aspectRatio = selectedAttachment ? selectedAttachment.width / selectedAttachment.height : 0;
        const imageStyles = [styles.previewImage, { aspectRatio: aspectRatio }];
        let attachmenterror = false;
        if (selectedAttachment) {
            attachmenterror = selectedAttachment.error;
            const pendingUpload = this.props.pendingUploadDocs[selectedAttachment.mobileReferenceNumber];
            if (pendingUpload) {
                attachmenterror = pendingUpload.error;
            }
        }
        let pdfuri = '';
        let isPdf = false;
        if (
            this.state.selectedAttachment &&
            this.state.selectedAttachment.attachmentTitle &&
            this.state.selectedAttachment.attachmentTitle.toLowerCase().indexOf('.pdf') > -1
        ) {
            const doc = attachmentsHelper.verifyImageProperties(this.state.selectedAttachment);
            if (doc && doc.path) {
                pdfuri = doc.path;
            }
            isPdf = true;
        }

        return (
            <View style={styles.container}>
                <AttachmentsHeader
                    editable={editable}
                    selectedAttachment={selectedAttachment}
                    onScreenClose={this.handleOnClose}
                    onCropRotate={this.launchCropEditor}
                    onDrawOnImage={this.launchDrawEditor}
                    onClose={this.handleOnClose}
                    handleImageRemove={this.handleImageRemove}
                />

                {selectedAttachment && selectedAttachment.path && (
                    <Modal visible={this.state.showImageEditor} onRequestClose={() => this.setState({ showImageEditor: false })}>
                        <ImageMarker
                            onSave={this.saveEditedImage}
                            onRequestClose={() => this.setState({ showImageEditor: false })}
                            path={selectedAttachment.path}
                            mobileReferenceNumber={selectedAttachment.mobileReferenceNumber}
                            documentId={selectedAttachment.documentId}
                        />
                    </Modal>
                )}
                <View style={styles.previewContainer}>
                    {!!selectedAttachment && (
                        <View style={styles.previewInnerContainer}>
                            {attachmenterror ? (
                                <TouchableOpacity
                                    style={{
                                        position: 'absolute',
                                        top: 0,
                                        right: 250,
                                        zIndex: 1000,
                                    }}
                                    onPress={this.startUpload}
                                >
                                    <Icon type="MaterialCommunityIcons" name="cloud-sync" color="#ff0000" size={30} />
                                </TouchableOpacity>
                            ) : null}
                            {isPdf ? (
                                <Pdf source={{ uri: pdfuri, cache: true }} style={styles.pdf} />
                            ) : (
                                <ZoomableImage
                                    style={[imageStyles, { flex: 1 }]}
                                    offsetTop={0}
                                    offsetLeft={0}
                                    imageWidth={selectedAttachment.width}
                                    imageHeight={selectedAttachment.height}
                                    startUpload={this.startUpload}
                                    //source={{ uri: `data:${selectedAttachment.mime};base64,${selectedAttachment.data}` }}
                                    source={{
                                        uri: selectedAttachment.path,
                                        uploading: selectedAttachment.uploading,
                                        uploaded: selectedAttachment.uploaded,
                                        error: selectedAttachment.error,
                                    }}
                                    authCode={this.props.authCode}
                                    onSwipLeft={this.handleSwipLeft}
                                    onSwipRight={this.handleSwipRight}
                                    metadata={selectedAttachment}
                                />
                            )}
                        </View>
                    )}
                    {!selectedAttachment && <Text style={styles.previewNoImageSelectedText}>Select an attachment...</Text>}
                </View>
                {!!attachments && (
                    <View style={styles.imageListContainer}>
                        <AttachmentList
                            attachments={attachments}
                            onPress={this.handleThumbnailOnPress}
                            editable={editable}
                            onRemove={this.handleImageRemove}
                            hideDelete={this.props.hideDelete}
                            selectedAttachment={selectedAttachment}
                        />
                        {editable && (
                            <View style={styles.addPictureButtonContainer}>
                                <TouchableOpacity onPress={this.handleAddPicturePressed} style={styles.addPictureButton}>
                                    <Icon type="MaterialCommunityIcons" name="camera" size={45} style={styles.addPictureButtonIcon} />
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                )}
                <Button style={styles.doneButton} title="Done" onPress={this.handleOnClose}>
                    {strings('done')}
                </Button>
            </View>
        );
    }
}

mapStateToProps = (state, ownProps) => {
    let inspInstanceId = null;
    let parentInspectionId = null;
    let refNumber = null;
    let workflowInstanceId = null;
    let visitIndex = null;
    let inspectionTypeId = null;

    if (
        state.inspections.currentInspectionRef &&
        state.inspections.history[state.inspections.currentInspectionRef] &&
        state.inspections.history[state.inspections.currentInspectionRef].inspection
    ) {
        const inspectionRef = state.inspections.history[state.inspections.currentInspectionRef];
        const { currentVisitIndex, currentVisit } = inspectionsHelper.getCurrentVisit(inspectionRef.inspection);
        visitIndex = currentVisitIndex;

        if (currentVisit) {
            inspectionTypeId = inspectionRef.inspection.inspectionTypeDetail.inspectionTypeId;
            if (currentVisit.inspectionId) {
                inspInstanceId = currentVisit.inspectionId;
            } else {
                inspInstanceId = inspectionRef.inspection.inspectionId;
            }
            if (currentVisit.workflowInstanceId) workflowInstanceId = currentVisit.workflowInstanceId;
        } else {
            inspInstanceId = inspectionRef.inspection.inspectionId;
        }
        parentInspectionId = inspectionRef.inspection.inspectionId;
        refNumber = inspectionRef.inspection.refNumber;
    }

    return {
        userData: state.auth.userData,
        authCode: state.auth.authCode,
        inspInstanceId,
        parentInspectionId,
        refNumber,
        workflowInstanceId,
        environment: state.settings.environment,
        visitIndex,
        inspectionTypeId,
        pendingUploadDocs: state.attachments.pendingUploadDocs || {},
    };
};

const connectedAttachments = connect(mapStateToProps)(Attachments);
export default screenWithSpinner(connectedAttachments, { theme: 'light' });
