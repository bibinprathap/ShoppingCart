import React, { Component } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { _ } from 'lodash';
import { View, ScrollView, TouchableOpacity, Modal, Image } from 'react-native';
import { connect } from 'react-redux';
import {
    addImageAttachment,
    removeImageAttachment,
    uploadingImageAttachment,
    uploadedImageAttachment,
    uploadErrorImageAttachment,
} from 'app/actions/attachments';
import { inspectionAddLogs } from 'app/actions/inspections';

import { Text, TextInput, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-crop-picker';
import RNFetchBlob from 'rn-fetch-blob';
import UUIDGenerator from 'react-native-uuid-generator';
import { screenWithSpinner } from 'app/components/WithSpinner';
//import { LargeThumbnail } from 'app/components/Thumbnail';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import { RNFileUploader } from 'app/api/helperServices';
import { strings } from 'app/config/i18n/i18n';
import { attachmentsHelper } from 'app/api/helperServices';
import { ZoomableImage, ImageMarker } from 'app/components/Image';
import alertsHelper from 'app/api/helperServices/alerts';
import { AttachmentsHeader } from 'app/components/Header';
import styles from './styles';
import envConfig from 'app/api/config';
import AppApi from 'app/api/real';
const api = new AppApi();

const env = envConfig;

const captureImageQuality = 1; //todo: take this from config/ store
const includeBase64 = false;
const swipThreshold = 100;

class Attachments extends Component {
    constructor(props) {
        super(props);
        this.state = { showImageEditor: false };
        this.addPicture = this.addPicture.bind(this);
        this.setselectedAttachment = this.setselectedAttachment.bind(this);

        this.startUpload = this.startUpload.bind(this);
    }
    uploaderListener;
    componentDidMount() {
        // const attachments = this.props.navigation.getParam('attachments');
        // const onClose = this.props.navigation.getParam('onClose');
        // const onAdd = this.props.navigation.getParam('onAdd');
        // const onRemove = this.props.navigation.getParam('onRemove');
        // const selectedAttachmentId = this.props.navigation.getParam('selectedAttachmentId');
        // const editable = this.props.navigation.getParam('editable');

        const { attachments, onClose, onAdd, onRemove, selectedAttachmentId, editable } = this.props;
        const firstAttachmentId = !!attachments && attachments[0];
        const selectedAttachment = attachmentsHelper.getDoc(selectedAttachmentId || firstAttachmentId);

        this.setState({
            attachments,
            startedEmpty: !attachments,
            selectedAttachmentId: selectedAttachmentId || firstAttachmentId,
            selectedAttachment: selectedAttachment,
            onClose,
            onAdd,
            onRemove,
            editable,
        });
        // this.props.navigation.setParams({
        //     onScreenClose: this.handleOnClose,
        //     onCropRotate: this.launchCropEditor,
        //     onDrawOnImage: this.launchDrawEditor,
        //     //selectedAttachmentId: firstAttachmentId,
        // });
    }

    componentDidUpdate() {
        const { firstUpdateDone, startedEmpty, editable } = this.state;
        if (!firstUpdateDone && startedEmpty && editable) {
            this.setState({ firstUpdateDone: true }, () => {
                this.handleAddPicturePressed();
            });
        }
    }
    onLayout = event => {
        const { width, height } = event.nativeEvent.layout;
        /*
            thumbnail with height and width same as (height - offset) of the parent view
        */
        const offset = styles.imageListContainer.padding * 2;
        if (!this.state.layoutDone) this.setState({ layoutDone: true, thumbnailHeight: height - offset, thumbnailWidth: height - offset });
    };

    handleOnClose = () => {
        //Todo: do any cleanup etc before closing this screen
        const { onClose } = this.state;
        if (onClose) onClose();
    };

    launchDrawEditor = () => {
        this.setState({ showImageEditor: true });
    };

    launchCropEditor = async () => {
        const imageToCrop = this.state.selectedAttachment;
        if (!imageToCrop) return;
        try {
            const croppedImage = await ImagePicker.openCropper({
                path: imageToCrop.path,
                width: imageToCrop.width,
                height: imageToCrop.height,
                cropperStatusBarColor: '#058DFC',
                cropperToolbarColor: '#058DFC',
                enableRotationGesture: true,
                freeStyleCropEnabled: true,
                compressImageQuality: captureImageQuality, //Todo: take this from settings
            });
            if (croppedImage) {
                this.handleImageRemove(imageToCrop.id);
                this.addPicture(croppedImage, false);
            }
        } catch (e) {
            console.log('failed to crop image', e);
        }
    };
    startUpload = uploadattachement => {
        const newAttachment = uploadattachement.path ? uploadattachement : this.state.selectedAttachment;
        let attachement = { ...newAttachment, path: newAttachment.path.replace('file://', '') };
        const envConfig = env[this.props.environment];
        RNFileUploader.getFileInfo(attachement.path).then(metadata => {
            const options = Object.assign(
                {
                    url: envConfig.baseURL + '/DummyMims/upload_multipart',
                    field: 'uploaded_media',
                    type: 'multipart',
                    method: 'POST',
                    headers: {
                        'content-type': metadata.mimeType, // server requires a content-type header
                        '.ASPXAUTH': this.props.authCode,
                    },
                    timeout: envConfig.timeout || 0, //doesn't always work. need to fix this
                    withCredentials: true,
                },
                attachement
            );
            RNFileUploader.startUpload(options)
                .then(
                    (uploadId => {
                        console.log(`RNFileUploader started with options: ${JSON.stringify(options)}`);
                        this.props
                            .dispatch(
                                uploadingImageAttachment({
                                    id: attachement && attachement.id,
                                    uploadId,
                                    uploading: true,
                                    createdBy: this.props.userData.uuid,
                                    id: attachement.id,
                                    inspectionID: this.props.inspectionID,
                                })
                            )
                            .then(this.setselectedAttachment);
                        this.setState({ uploadId, progress: 0 });
                        this.uploaderListener = RNFileUploader.addListener('progress', uploadId, data => {
                            //this.handleProgress(+data.progress);
                            console.log(`Progress: ${JSON.stringify(data)}%`);

                            if (data.responseCode && data.responseCode == 200) {
                                //RNFileUploader.getString('CompletedUploadIds').then(completeduploadids => {
                                // __DEV__ && console.log('CompletedUploadIds' + completeduploadids);
                                //   if (completeduploadids.indexOf(uploadId) > -1)
                                //    RNFileUploader.setString('CompletedUploadIds', completeduploadids.replace(uploadId, '').trim());
                                //  RNFileUploader.getString(uploadId).then(responce => {
                                //  __DEV__ && console.log('responceUploadIds');
                                //    __DEV__ && console.log(responce);
                                //   if (completeduploadids.indexOf(uploadId) > -1)
                                //    RNFileUploader.setString('CompletedUploadIds', completeduploadids.replace(uploadId, '').trim());
                                //  });
                                //   });

                                this.props
                                    .dispatch(
                                        uploadedImageAttachment({
                                            id: attachement && attachement.id,
                                            uploading: false,
                                            uploaded: true,
                                            createdDate: new Date(),
                                            createdBy: this.props.userData.uuid,
                                            uploadedDate: new Date(),
                                            fileName: data.id,
                                            path: JSON.parse(data.responseBody).result.path,
                                        })
                                    )
                                    .then(this.setselectedAttachment);

                                this.props.dispatch(
                                    inspectionAddLogs({
                                        documentid: data.id,
                                        inspectionID: attachement.inspectionID,
                                        date: new Date(),
                                        message: 'Uploaded Successfully',
                                        success: true,
                                    })
                                );
                            } else if (data.error || (data.responseCode && data.responseCode != 200)) {
                                this.props
                                    .dispatch(
                                        uploadErrorImageAttachment({
                                            id: attachement && attachement.id,
                                            uploading: false,
                                            uploaded: false,
                                            error: data.error,
                                            uploadedDate: new Date(),
                                            fileName: data.id,
                                        })
                                    )
                                    .then(this.setselectedAttachment);

                                this.props.dispatch(
                                    inspectionAddLogs({
                                        documentid: data.id,
                                        date: new Date(),
                                        inspectionID: attachement.inspectionID,
                                        message: 'Error While Uploading',
                                        success: false,
                                    })
                                );

                                // RNFileUploader.getString('FailedUploadIds').then(failedUploadIds => {
                                // if (failedUploadIds.indexOf(uploadId) > -1)
                                // RNFileUploader.setString('FailedUploadIds', failedUploadIds.replace(uploadId, '').trim());
                                // });
                            } else if (data.cancelled) {
                                __DEV__ && console.log(`[INFO] RNFileUploader cancelled!`);
                                const pendingUploads = attachmentsHelper.getUploadingAttachement();
                                if (pendingUploads.length == 0) this.uploaderListener.remove();

                                this.props.dispatch(
                                    inspectionAddLogs({
                                        documentid: data.id,
                                        date: new Date(),
                                        message: 'Upload Cancelled',
                                        success: true,
                                    })
                                );

                                // RNFileUploader.getString('CancelledUploadIds').then(cancelleduploadids => {
                                //  if (cancelleduploadids.indexOf(uploadId) > -1)
                                //  RNFileUploader.setString('CancelledUploadIds', cancelleduploadids.replace(uploadId, '').trim());
                                // });
                            }
                        });
                    }).bind(this)
                )

                .catch(function(err) {
                    //this.setState({ uploadId: null, progress: null });
                    console.log('RNFileUploader error!', err);
                });
        });
    };

    addPicture = (image, updateLocation) => {
        const newAttachment = attachmentsHelper.prepareNewImageForAttachment(image, captureImageQuality);
        this.props.dispatch(addImageAttachment(newAttachment, updateLocation)).then(() => {
            //dispach action for updating the reducer by inspectionid and uploading

            this.startUpload(newAttachment);
        });
        const { onAdd } = this.state;
        if (onAdd) onAdd(newAttachment.id);
        const { attachments } = this.state;
        const newAttachmentsArray = attachments ? attachments.slice() : [];
        newAttachmentsArray.push(newAttachment.id);
        this.setState({
            attachments: newAttachmentsArray,
            selectedAttachmentId: newAttachment.id,
            selectedAttachment: newAttachment,
        });
    };

    handleAddPicturePressed = props => {
        //console.log(props);
        //Todo: fix the dimensions of the pic (default = portrait)
        ImagePicker.openCamera({
            includeBase64: includeBase64,
            includeExif: true,
            enableRotationGesture: true,
            compressImageQuality: captureImageQuality, //Todo: take this from settings
            //cropping: true,
        })
            .then(image => {
                //this.deleteFile(image.path);
                //delete image.path; //don't store the path as file is going to be deleted anyway
                console.log('image', image);
                this.addPicture(image, true);
            })
            .catch(error => {
                if (error.code == 'E_PICKER_CANCELLED') {
                    const { startedEmpty, attachments } = this.state;
                    if (startedEmpty && (!attachments || attachments.length == 0)) {
                        //if it had started empty and user cancelled the camera without taking snap
                        this.handleOnClose();
                    }
                } else {
                    console.log({ error });
                    alert(error);
                }
            });
    };

    deleteFile = async path => {
        try {
            await RNFetchBlob.fs.unlink(path);
            console.log(`File deleted: ${path}`);
        } catch (e) {
            const msg = `Failed to delete file: ${path}`;
            console.log(msg, e);
            alert(msg);
        }
    };
    setselectedAttachment = m => {
        this.setState({
            selectedAttachment: attachmentsHelper.getDoc(m.payload.id),
        });

        const pendingUploads = attachmentsHelper.getUploadingAttachement();
        if (pendingUploads.length == 0) this.uploaderListener.remove();
    };

    handleThumbnailOnPress = id => {
        const selectedAttachment = attachmentsHelper.getDoc(id);
        setTimeout(() => {
            this.setState({ selectedAttachmentId: id, selectedAttachment: selectedAttachment });
            // this.props.navigation.setParams({
            //     selectedAttachmentId: id,
            // });
        }, 0);
    };

    handleImageRemove = async id => {
        const { onRemove } = this.state;
        if (onRemove) onRemove(id);

        const { selectedAttachment, attachments } = this.state;
        if (typeof selectedAttachment === 'undefined') return;
        let currentIndex = attachments.indexOf(id);

        if (selectedAttachment.id == id) {
            if (currentIndex == attachments.length - 1) currentIndex--;
        } else if (currentIndex > 0) {
            currentIndex--;
        }

        const newAttachmentsArray = _.without(attachments, id);

        //if (newAttachmentsArray.length > 0) {
        this.setState({
            attachments: newAttachmentsArray,
            selectedAttachmentId: newAttachmentsArray.length ? newAttachmentsArray[currentIndex] : null,
            selectedAttachment: newAttachmentsArray.length ? attachmentsHelper.getDoc(newAttachmentsArray[currentIndex]) : null,
        });
        //}
        const selectedAttachmentfromStore = attachmentsHelper.getDoc(id);
        this.props.dispatch(removeImageAttachment({ id: id }));
        if (selectedAttachmentfromStore.uploading) {
            RNFileUploader.cancelUpload(selectedAttachmentfromStore.fileName);
        } else {
            const result = await api.deleteUploadedDocument(selectedAttachmentfromStore.fileName);
        }
    };

    handleSwipLeft = xDiff => {
        if (xDiff >= swipThreshold) {
            this.selectAttachmentByIndexOffset(1);
        }
    };

    handleSwipRight = xDiff => {
        if (xDiff => swipThreshold) {
            this.selectAttachmentByIndexOffset(-1);
        }
    };

    selectAttachmentByIndexOffset = indexOffset => {
        const { selectedAttachment, attachments } = this.state;
        if (typeof selectedAttachment === 'undefined') return;
        const maxIndex = attachments.length - 1;
        if (maxIndex < 0) return;

        const currentIndex = attachments.indexOf(selectedAttachment.id);
        let newIndex = currentIndex + indexOffset;
        if (newIndex < 0) {
            newIndex = maxIndex;
        } else if (newIndex > maxIndex) {
            newIndex = 0;
        }
        const newSelectedAttachmentId = attachments[newIndex];
        if (newSelectedAttachmentId) {
            this.setState({
                selectedAttachmentId: newSelectedAttachmentId,
                selectedAttachment: attachmentsHelper.getDoc(newSelectedAttachmentId),
            });
        }
    };

    saveEditedImage = imagePath => {
        if (imagePath) {
            const path = `file://${imagePath}`;
            console.log('path', path);
            Image.getSize(
                path,
                (width, height) => {
                    const imageObj = {
                        path,
                        height,
                        width,
                    };
                    const captureImageQuality = 1;
                    const editedImage = attachmentsHelper.prepareNewImageForAttachment(imageObj, captureImageQuality);
                    console.log('editedImage', editedImage);
                    if (editedImage && this.state.selectedAttachment) {
                        editedImage.extension = 'jpg';
                        this.handleImageRemove(this.state.selectedAttachment.id);
                        this.addPicture(editedImage, false);
                        this.setState({ showImageEditor: false });
                    } else {
                        this.setState({ showImageEditor: false });
                        alertsHelper.show('error', 'Error', strings('unknown_error'));
                    }
                },
                error => {
                    console.log('Check external storage permission', error);
                    this.setState({ showImageEditor: false });
                    alertsHelper.show('error', 'Error', strings('unknown_error'));
                }
            );
        }
    };

    render() {
        //Todo: if there are no exising attachments, open the camera without waiting for user to click on the button
        const { selectedAttachmentId, attachments, layoutDone, thumbnailHeight, thumbnailWidth, editable } = this.state;
        let selectedAttachment = this.state.selectedAttachment;
        // if (!selectedAttachment && selectedAttachmentId) {
        //     selectedAttachment = attachmentsHelper.getDoc(selectedAttachmentId);
        // }

        const aspectRatio = selectedAttachment ? selectedAttachment.width / selectedAttachment.height : 0;
        const imageStyles = [styles.previewImage, { aspectRatio: aspectRatio }];

        return (
            <View style={styles.container}>
                <AttachmentsHeader
                    editable={editable}
                    selectedAttachmentId={selectedAttachment ? selectedAttachment.id : null}
                    onScreenClose={this.handleOnClose}
                    onCropRotate={this.launchCropEditor}
                    onDrawOnImage={this.launchDrawEditor}
                    onClose={this.props.onClose}
                />

                {selectedAttachment && selectedAttachment.path && (
                    <Modal visible={this.state.showImageEditor} onRequestClose={() => this.setState({ showImageEditor: false })}>
                        <ImageMarker
                            onSave={this.saveEditedImage}
                            onRequestClose={() => this.setState({ showImageEditor: false })}
                            path={selectedAttachment.path}
                        />
                    </Modal>
                )}
                <View style={styles.previewContainer}>
                    {!!selectedAttachment && (
                        <View style={styles.previewInnerContainer}>
                            {selectedAttachment.error ? (
                                <TouchableOpacity
                                    style={{
                                        position: 'absolute',
                                        top: 0,
                                        right: 250,
                                        zIndex: 1000,
                                    }}
                                    onPress={this.startUpload}
                                >
                                    <Icon name="cloud-off" color="#ff0000" size={30} />
                                </TouchableOpacity>
                            ) : null}
                            <ZoomableImage
                                style={[imageStyles, { flex: 1 }]}
                                offsetTop={0}
                                offsetLeft={0}
                                imageWidth={selectedAttachment.width}
                                imageHeight={selectedAttachment.height}
                                startUpload={this.startUpload}
                                //source={{ uri: `data:${selectedAttachment.mime};base64,${selectedAttachment.data}` }}
                                source={{
                                    uri: selectedAttachment.path,
                                    uploading: selectedAttachment.uploading,
                                    uploaded: selectedAttachment.uploaded,
                                    error: selectedAttachment.error,
                                }}
                                authCode={this.props.authCode}
                                onSwipLeft={this.handleSwipLeft}
                                onSwipRight={this.handleSwipRight}
                                metadata={selectedAttachment}
                            />
                        </View>
                    )}
                    {!selectedAttachment && <Text style={styles.previewNoImageSelectedText}>Select an attachment...</Text>}
                </View>
                {!!attachments && (
                    <View style={styles.imageListContainer}>
                        <AttachmentList
                            attachments={attachments}
                            onPress={this.handleThumbnailOnPress}
                            editable={editable}
                            onRemove={this.handleImageRemove}
                            authCode={this.props.authCode}
                            selectedAttachmentId={selectedAttachment ? selectedAttachment.id : null}
                        />
                        {editable && (
                            <View style={styles.addPictureButtonContainer}>
                                <TouchableOpacity onPress={this.handleAddPicturePressed} style={styles.addPictureButton}>
                                    <Icon name="add-a-photo" size={45} style={styles.addPictureButtonIcon} />
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                )}
            </View>
        );
    }
}

mapStateToProps = (state, ownProps) => {
    let inspectionID = null;
    if (
        state.inspections.currentInspectionRef &&
        state.inspections.history[state.inspections.currentInspectionRef] &&
        state.inspections.history[state.inspections.currentInspectionRef].inspection
    )
        inspectionID = state.inspections.history[state.inspections.currentInspectionRef].inspection.inspectionID;
    return {
        userData: state.auth.userData,
        authCode: state.auth.authCode,
        inspectionID,
        environment: state.settings.environment,
    };
};

const connectedAttachments = connect(mapStateToProps)(Attachments);
export default screenWithSpinner(connectedAttachments, { theme: 'light' });
