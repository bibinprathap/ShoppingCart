import React, { Component } from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { _ } from 'lodash';
import { View, ScrollView, TouchableOpacity, Modal, Image } from 'react-native';
import { connect } from 'react-redux';
import {
    addImageAttachment,
    removeImageAttachment,
    uploadingImageAttachment,
    uploadedImageAttachment,
    uploadErrorImageAttachment,
} from 'app/actions/attachments';
import { Text, TextInput, TouchableRipple } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialIcons';
import ImagePicker from 'react-native-image-crop-picker';
import RNFetchBlob from 'rn-fetch-blob';
import UUIDGenerator from 'react-native-uuid-generator';
import { screenWithSpinner } from 'app/components/WithSpinner';
//import { LargeThumbnail } from 'app/components/Thumbnail';
import AttachmentList from 'app/components/AttachmentList/AttachmentList';
import Upload from 'react-native-background-upload';
import { strings } from 'app/config/i18n/i18n';
import { attachmentsHelper } from 'app/api/helperServices';
import { ZoomableImage, ImageMarker } from 'app/components/Image';
import alertsHelper from 'app/api/helperServices/alerts';
import styles from './styles';

const captureImageQuality = 1; //todo: take this from config/ store
const includeBase64 = false;
const swipThreshold = 100;
class Attachments extends Component {
    constructor(props) {
        super(props);
        this.state = { showImageEditor: false };
        this.addPicture = this.addPicture.bind(this);
    }

    componentDidMount() {
        const attachments = this.props.navigation.getParam('attachments');
        const onClose = this.props.navigation.getParam('onClose');
        const onAdd = this.props.navigation.getParam('onAdd');
        const onRemove = this.props.navigation.getParam('onRemove');
        const selectedAttachmentId = this.props.navigation.getParam('selectedAttachmentId');
        const firstAttachmentId = !!attachments && attachments[0];
        const selectedAttachment = attachmentsHelper.getDoc(selectedAttachmentId || firstAttachmentId);
        const editable = this.props.navigation.getParam('editable');

        this.setState({
            attachments,
            startedEmpty: !attachments,
            selectedAttachmentId: selectedAttachmentId || firstAttachmentId,
            selectedAttachment: selectedAttachment,
            onClose,
            onAdd,
            onRemove,
            editable,
        });
        this.props.navigation.setParams({
            onScreenClose: this.handleOnClose,
            onCropRotate: this.launchCropEditor,
            onDrawOnImage: this.launchDrawEditor,
            //selectedAttachmentId: firstAttachmentId,
        });
    }

    componentDidUpdate() {
        const { firstUpdateDone, startedEmpty, editable } = this.state;
        if (!firstUpdateDone && startedEmpty && editable) {
            this.setState({ firstUpdateDone: true }, () => {
                this.handleAddPicturePressed();
            });
        }
    }
    onLayout = event => {
        const { width, height } = event.nativeEvent.layout;
        /*
            thumbnail with height and width same as (height - offset) of the parent view
        */
        const offset = styles.imageListContainer.padding * 2;
        if (!this.state.layoutDone) this.setState({ layoutDone: true, thumbnailHeight: height - offset, thumbnailWidth: height - offset });
    };

    handleOnClose = () => {
        //Todo: do any cleanup etc before closing this screen
        const { onClose } = this.state;
        if (onClose) onClose();
        this.props.navigation.pop();
    };

    launchDrawEditor = () => {
        this.setState({ showImageEditor: true });
    };

    launchCropEditor = async () => {
        const imageToCrop = this.state.selectedAttachment;
        if (!imageToCrop) return;
        try {
            const croppedImage = await ImagePicker.openCropper({
                path: imageToCrop.path,
                width: imageToCrop.width,
                height: imageToCrop.height,
                cropperStatusBarColor: '#058DFC',
                cropperToolbarColor: '#058DFC',
                enableRotationGesture: true,
                freeStyleCropEnabled: true,
                compressImageQuality: captureImageQuality, //Todo: take this from settings
            });
            if (croppedImage) {
                this.handleImageRemove(imageToCrop.id);
                this.addPicture(croppedImage);
            }
        } catch (e) {
            console.log('failed to crop image', e);
        }
    };

    addPicture = image => {
        const newAttachment = attachmentsHelper.prepareNewImageForAttachment(image, captureImageQuality);
        this.props.dispatch(addImageAttachment(newAttachment)).then(() => {
            //dispach action for updating the reducer by inspectionid and uploading
            let attachement = { ...newAttachment, path: newAttachment.path.replace('file://', '') };
            Upload.getFileInfo(attachement.path).then(metadata => {
                const options = Object.assign(
                    {
                        url: 'http://localhost:3000/upload_multipart',
                        field: 'uploaded_media',
                        type: 'multipart',
                        method: 'POST',
                        headers: {
                            'content-type': metadata.mimeType, // server requires a content-type header
                        },
                    },
                    attachement
                );

                Upload.startUpload(options)
                    .then(uploadId => {
                        console.log(`Upload started with options: ${JSON.stringify(options)}`);
                        this.props
                            .dispatch(
                                uploadingImageAttachment({ uploadId, uploading: true, id: attachement.id, inspectionID: this.props.inspectionID })
                            )
                            .then(m => {
                                this.setState({
                                    selectedAttachment: attachmentsHelper.getDoc(attachement.id),
                                });
                            });
                        this.setState({ uploadId, progress: 0 });
                        Upload.addListener('progress', uploadId, data => {
                            //this.handleProgress(+data.progress);
                            console.log(`Progress: ${data.progress}%`);
                        });
                        Upload.addListener('cancelled', uploadId, data => {
                            __DEV__ && console.log(`[INFO] Upload cancelled!`);
                        });
                        Upload.addListener('error', uploadId, data => {
                            console.log(`Error: ${data.error}%`);
                            this.props
                                .dispatch(
                                    uploadErrorImageAttachment({
                                        id: attachement.id,
                                        uploading: false,
                                        uploaded: false,
                                        error: data.error,
                                        uploadedDate: new Date(),
                                        fileName: uploadId,
                                    })
                                )
                                .then(m => {
                                    this.setState({
                                        selectedAttachment: attachmentsHelper.getDoc(attachement.id),
                                    });
                                });
                        });

                        Upload.addListener('completed', uploadId, data => {
                            console.log(data);
                            debugger;
                            this.props
                                .dispatch(
                                    uploadedImageAttachment({
                                        id: attachement.id,
                                        uploading: false,
                                        uploaded: true,
                                        createdDate: new Date(),
                                        createdBy: this.props.userData.uuid,
                                        uploadedDate: new Date(),
                                        fileName: uploadId,
                                        path: 'http://localhost:3000' + JSON.parse(data.responseBody).path,
                                    })
                                )
                                .then(m => {
                                    this.setState({
                                        selectedAttachment: attachmentsHelper.getDoc(attachement.id),
                                    });
                                });
                            console.log('Completed!');
                        });
                    })
                    .catch(function(err) {
                        this.setState({ uploadId: null, progress: null });
                        console.log('Upload error!', err);
                    });
            });
        });
        const { onAdd } = this.state;
        if (onAdd) onAdd(newAttachment.id);
        const { attachments } = this.state;
        const newAttachmentsArray = attachments ? attachments.slice() : [];
        newAttachmentsArray.push(newAttachment.id);
        this.setState({
            attachments: newAttachmentsArray,
            selectedAttachmentId: newAttachment.id,
            selectedAttachment: newAttachment,
        });
    };

    handleAddPicturePressed = props => {
        //console.log(props);
        //Todo: fix the dimensions of the pic (default = portrait)
        ImagePicker.openCamera({
            includeBase64: includeBase64,
            includeExif: true,
            enableRotationGesture: true,
            compressImageQuality: captureImageQuality, //Todo: take this from settings
            //cropping: true,
        })
            .then(image => {
                //this.deleteFile(image.path);
                //delete image.path; //don't store the path as file is going to be deleted anyway
                console.log('image', image);
                this.addPicture(image);
            })
            .catch(error => {
                if (error.code == 'E_PICKER_CANCELLED') {
                    const { startedEmpty, attachments } = this.state;
                    if (startedEmpty && (!attachments || attachments.length == 0)) {
                        //if it had started empty and user cancelled the camera without taking snap
                        this.handleOnClose();
                    }
                } else {
                    console.log({ error });
                    alert(error);
                }
            });
    };

    deleteFile = async path => {
        try {
            await RNFetchBlob.fs.unlink(path);
            console.log(`File deleted: ${path}`);
        } catch (e) {
            const msg = `Failed to delete file: ${path}`;
            console.log(msg, e);
            alert(msg);
        }
    };

    handleThumbnailOnPress = id => {
        const selectedAttachment = attachmentsHelper.getDoc(id);
        setTimeout(() => {
            this.setState({ selectedAttachmentId: id, selectedAttachment: selectedAttachment });
            // this.props.navigation.setParams({
            //     selectedAttachmentId: id,
            // });
        }, 0);
    };

    handleImageRemove = id => {
        const { onRemove } = this.state;
        if (onRemove) onRemove(id);

        const { selectedAttachment, attachments } = this.state;
        if (typeof selectedAttachment === 'undefined') return;
        let currentIndex = attachments.indexOf(id);

        if (selectedAttachment.id == id) {
            if (currentIndex == attachments.length - 1) currentIndex--;
        } else if (currentIndex > 0) {
            currentIndex--;
        }

        const newAttachmentsArray = _.without(attachments, id);

        //if (newAttachmentsArray.length > 0) {
        this.setState({
            attachments: newAttachmentsArray,
            selectedAttachmentId: newAttachmentsArray.length ? newAttachmentsArray[currentIndex] : null,
            selectedAttachment: newAttachmentsArray.length ? attachmentsHelper.getDoc(newAttachmentsArray[currentIndex]) : null,
        });
        //}
        const selectedAttachmentfromStore = attachmentsHelper.getDoc(id);
        if (selectedAttachmentfromStore.uploading) {
            Upload.cancelUpload(selectedAttachmentfromStore.fileName);
        }

        this.props.dispatch(removeImageAttachment({ id: id }));
    };

    handleSwipLeft = xDiff => {
        if (xDiff >= swipThreshold) {
            this.selectAttachmentByIndexOffset(1);
        }
    };

    handleSwipRight = xDiff => {
        if (xDiff => swipThreshold) {
            this.selectAttachmentByIndexOffset(-1);
        }
    };

    selectAttachmentByIndexOffset = indexOffset => {
        const { selectedAttachment, attachments } = this.state;
        if (typeof selectedAttachment === 'undefined') return;
        const maxIndex = attachments.length - 1;
        if (maxIndex < 0) return;

        const currentIndex = attachments.indexOf(selectedAttachment.id);
        let newIndex = currentIndex + indexOffset;
        if (newIndex < 0) {
            newIndex = maxIndex;
        } else if (newIndex > maxIndex) {
            newIndex = 0;
        }
        const newSelectedAttachmentId = attachments[newIndex];
        if (newSelectedAttachmentId) {
            this.setState({
                selectedAttachmentId: newSelectedAttachmentId,
                selectedAttachment: attachmentsHelper.getDoc(newSelectedAttachmentId),
            });
        }
    };

    saveEditedImage = imagePath => {
        if (imagePath) {
            const path = `file://${imagePath}`;
            console.log('path', path);
            Image.getSize(
                path,
                (width, height) => {
                    const imageObj = {
                        path,
                        height,
                        width,
                    };
                    const captureImageQuality = 1;
                    const editedImage = attachmentsHelper.prepareNewImageForAttachment(imageObj, captureImageQuality);
                    console.log('editedImage', editedImage);
                    if (editedImage && this.state.selectedAttachment) {
                        editedImage.extension = 'jpg';
                        this.handleImageRemove(this.state.selectedAttachment.id);
                        this.addPicture(editedImage);
                        this.setState({ showImageEditor: false });
                    } else {
                        this.setState({ showImageEditor: false });
                        alertsHelper.show('error', 'Error', strings('unknown_error'));
                    }
                },
                error => {
                    console.log('Check external storage permission', error);
                    this.setState({ showImageEditor: false });
                    alertsHelper.show('error', 'Error', strings('unknown_error'));
                }
            );
        }
    };

    render() {
        //Todo: if there are no exising attachments, open the camera without waiting for user to click on the button
        const { selectedAttachment, attachments, layoutDone, thumbnailHeight, thumbnailWidth, editable } = this.state;
        const aspectRatio = selectedAttachment ? selectedAttachment.width / selectedAttachment.height : 0;
        const imageStyles = [styles.previewImage, { aspectRatio: aspectRatio }];

        return (
            <View style={styles.container}>
                {selectedAttachment && selectedAttachment.path && (
                    <Modal visible={this.state.showImageEditor} onRequestClose={() => this.setState({ showImageEditor: false })}>
                        <ImageMarker
                            onSave={this.saveEditedImage}
                            onRequestClose={() => this.setState({ showImageEditor: false })}
                            path={selectedAttachment.path}
                        />
                    </Modal>
                )}
                <View style={styles.previewContainer}>
                    {!!selectedAttachment && (
                        //Todo: fix image dimensions on tab. proper border/ shadow of the enlarged picture will show up when dimensions are fixed.
                        <View style={styles.previewInnerContainer}>
                            <ZoomableImage
                                style={[imageStyles, { flex: 1 }]}
                                offsetTop={0}
                                offsetLeft={0}
                                imageWidth={selectedAttachment.width}
                                imageHeight={selectedAttachment.height}
                                //source={{ uri: `data:${selectedAttachment.mime};base64,${selectedAttachment.data}` }}
                                source={{
                                    uri: selectedAttachment.path,
                                    uploading: selectedAttachment.uploading,
                                    uploaded: selectedAttachment.uploaded,
                                    error: selectedAttachment.error,
                                }}
                                onSwipLeft={this.handleSwipLeft}
                                onSwipRight={this.handleSwipRight}
                            />
                        </View>
                    )}
                    {!selectedAttachment && <Text style={styles.previewNoImageSelectedText}>Select an attachment...</Text>}
                </View>
                {!!attachments && (
                    <View style={styles.imageListContainer}>
                        <AttachmentList
                            attachments={attachments}
                            onPress={this.handleThumbnailOnPress}
                            editable={editable}
                            onRemove={this.handleImageRemove}
                            selectedAttachmentId={selectedAttachment ? selectedAttachment.id : null}
                        />
                        {editable && (
                            <View style={styles.addPictureButtonContainer}>
                                <TouchableOpacity onPress={this.handleAddPicturePressed} style={styles.addPictureButton}>
                                    <Icon name="add-a-photo" size={45} style={styles.addPictureButtonIcon} />
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                )}
            </View>
        );
    }
}

mapStateToProps = (state, ownProps) => {
    let inspectionID = null;
    if (
        state.inspections.currentInspectionRef &&
        state.inspections.history[state.inspections.currentInspectionRef] &&
        state.inspections.history[state.inspections.currentInspectionRef].inspection
    )
        inspectionID = state.inspections.history[state.inspections.currentInspectionRef].inspection.inspectionID;
    return {
        userData: state.auth.userData,
        inspectionID,
    };
};

const connectedAttachments = connect(mapStateToProps)(Attachments);
export default screenWithSpinner(connectedAttachments, { theme: 'light' });
