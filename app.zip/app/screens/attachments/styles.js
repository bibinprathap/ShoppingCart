import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    previewContainer: {
        flex: 1,
        marginBottom: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    previewInnerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    previewNoImageSelectedText: {
        color: '$primaryMediumTextColor',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    previewImage: {},
    addPictureButtonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    addPictureButton: {
        padding: 10,
    },
    addPictureButtonIcon: {
        color: '$primaryWhite',
    },
    imageListContainer: {
        flex: 1,
        maxHeight: 100,
        padding: 5,
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
    },
    imageList: {},
});
