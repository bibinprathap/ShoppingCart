import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { authSuccess } from 'app/actions/auth';
import { loadLatestMasterdata } from 'app/actions/masterdata';
import EStyleSheet from 'react-native-extended-stylesheet';
import { ActivityIndicator, StatusBar, StyleSheet, View, Text } from 'react-native';
import moment from 'moment';
import AppApi from 'app/api/real';
const api = new AppApi();

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '$primaryDarkBackground',
    },
});

class AuthLoading extends Component {
    static propTypes = {
        remember: PropTypes.bool,
        loggedIn: PropTypes.bool,
        tokenData: PropTypes.object,
        userData: PropTypes.object,
        authCode: PropTypes.string,
        masterdataLastUpdated: PropTypes.string,
    };

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        //console.log('AuthLoading.componentDidMount()');
        this.checkAuthState();
    }

    // componentWillUnmount() {
    //     if (this.checkStateTimer) {
    //         clearTimeout(this.checkStateTimer);
    //     }
    // }
    // checkStateTimer;

    gotoMainStack() {
        this.props.navigation.navigate('main');
    }
    componentDidUpdate() {
        //console.log('AuthLoading.componentDidUpdate()');
        if (this.props.loggedIn) {
            this.props.dispatch(loadLatestMasterdata(this.props.masterdataLastUpdated));
            this.gotoMainStack();
        } else {
            this.checkAuthState();
        }
    }

    checkAuthState = async () => {
        const { loggedIn, remember, tokenData, userData, authCode, profiles } = this.props;
        const { access_token, expires_in } = tokenData || {};

        if (loggedIn) {
            //RJ: this happens when user was already logged in, but closed the app using
            //    back button of device, and then resumed it from "recently used apps" screen.
            //    redux store is hydrated from where user had left it, and AuthLoading.componentDidUpdate will not fire.
            this.gotoMainStack();
        }

        //for now if there is an authcode assume that its a valid login
        //Todo: if online, validate the authcode, and navigate to main or auth stack based on its validity

        if (!!authCode) {
            //TODO: also check if user account is active in SmartHub?
            try {
                const userProfile = await api.getPofiles(authCode);
                this.props.dispatch(authSuccess({ tokenData, userData, authCode, profiles: userProfile }));
            } catch (error) {
                if (error && error.code === 401) {
                    this.props.navigation.navigate('auth');
                }
            }
        } else {
            this.props.navigation.navigate('auth');
        }
    };

    render() {
        //console.log('AuthLoading.render() props: ', this.props);
        return (
            // <BaseContainer {...this.props} >
            <View style={styles.container}>
                <ActivityIndicator />
                <StatusBar translucent={false} hidden={false} barStyle="default" backgroundColor={styles.container.backgroundColor} />
                <Text>Loading authentication state</Text>
            </View>
            // </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    const tokenData = state.auth.tokenData;
    const userData = state.auth.userData;
    const authCode = state.auth.authCode;
    const profiles = state.auth.profiles;
    return {
        remember: state.auth.remember,
        loggedIn: state.auth.loggedIn,
        tokenData,
        userData,
        authCode,
        profiles,
        masterdataLastUpdated: state.masterdata.lastUpdated,
    };
};

export default connect(mapStateToProps)(AuthLoading);
