import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { authSuccess } from 'app/actions/auth';
import { loadLatestMasterdata } from 'app/actions/masterdata';
import EStyleSheet from 'react-native-extended-stylesheet';
import { ActivityIndicator, StatusBar, StyleSheet, View, Text } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { CancelLogin, Icon } from 'app/components';
import { throwMimsError } from 'app/api/helperServices/utils';
import moment from 'moment';
import AppApi from 'app/api/real';
import { store } from 'app/config/store';
const api = new AppApi();
import { authLogout } from 'app/actions/auth';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '$primaryDarkBackground',
    },
    message: {
        color: '$primaryMediumTextColor',
        fontSize: '$primaryTextXS',
    },
});

class AuthLoading extends Component {
    static propTypes = {
        loggedIn: PropTypes.bool,
        tokenData: PropTypes.object,
        userData: PropTypes.object,
        authCode: PropTypes.string,
        masterdataLastUpdated: PropTypes.string,
    };

    constructor(props) {
        super(props);
        //this.calledGetProfiles = false;
    }

    componentDidMount() {
        this.checkAuthState();
    }

    // shouldComponentUpdate(nextProps, nextState) {
    //     console.log('AuthLoading.shouldComponentUpdate()  currentProps:', this.props, 'nextProps:', nextProps);
    //     return true;
    // }

    gotoMainStack() {
        this.props.navigation.navigate('main');
    }
    componentDidUpdate() {
        if (this.props.loggedIn) {
            this.props.dispatch(loadLatestMasterdata(this.props.masterdataLastUpdated));
            this.gotoMainStack();
        } else {
            this.checkAuthState();
        }
    }

    checkAuthState = async () => {
        // if (this.calledGetProfiles) {
        //     console.log('AuthLoading.checkAuthState() already called getPofiles once, not calling again...');
        //     return;
        // }
        // this.calledGetProfiles = true;
        const { loggedIn, tokenData, userData, authCode, profiles, isConnected } = this.props;
        const { access_token, expires_in } = tokenData || {};
        if (!isConnected) return;

        if (!!authCode && !!userData && !!tokenData) {
            console.log('AuthLoading.checkAuthState() calling getProfiles');
            try {
                //try to get profiles, if it works, that means session is still valid.
                const profiles = await api.getPofiles();

                const newState = store.getState();
                const newTokenData = newState.auth && newState.auth.tokenData;
                // the below check ensures that the environment is same.
                if (newTokenData && tokenData.access_token == newTokenData.access_token) {
                    if (!profiles || (profiles && profiles.length == 0)) throwMimsError('Not allowed to use MIMS, no active profile.');
                    const activeProfileUrlArgs = profiles[0].urlArgs;
                    const activeProfile = await api.switchMimsRole(activeProfileUrlArgs);
                    this.props.dispatch(
                        authSuccess({ tokenData, userData, authCode: activeProfile.authCode, profiles, activeProfileUserId: activeProfile.userId })
                    );
                }
            } catch (error) {
                //if (error && error.code === 401) {
                //if (!error.isCancel) {
                this.props.dispatch(authLogout(true));
                this.props.navigation.navigate('auth');
                //}
                //}
            }
        } else {
            this.props.navigation.navigate('auth');
        }
    };

    render() {
        return (
            // <BaseContainer {...this.props} >
            <View style={{ flex: 1 }}>
                {this.props.isConnected && (
                    <View style={styles.container}>
                        <ActivityIndicator size="large" />
                        <StatusBar translucent={false} hidden={false} barStyle="default" backgroundColor={styles.container.backgroundColor} />
                        <Text style={styles.message}>{strings('restoringSession')}</Text>
                        <CancelLogin />
                    </View>
                )}
                {!this.props.isConnected && (
                    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                        <Icon type="MaterialCommunityIcons" name="wifi-off" color="#ccc" size={50} />
                    </View>
                )}
            </View>
            // </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    const tokenData = state.auth.tokenData;
    const userData = state.auth.userData;
    const authCode = state.auth.authCode;
    const profiles = state.auth.profiles;
    const loggedIn = state.auth.loggedIn || false;
    return {
        loggedIn,
        tokenData,
        userData,
        authCode,
        profiles,
        masterdataLastUpdated: state.masterdata.lastUpdated,
        isConnected: (state.settings && state.settings.isInternetReachable) || false,
    };
};

export default connect(mapStateToProps)(AuthLoading);
