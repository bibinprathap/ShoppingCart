import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Dimensions } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { Headline, Title, Text } from 'react-native-paper';
import { TabView, TabViewAnimated, TabBar, SceneMap } from 'react-native-tab-view';
import { widthPercentageToDP, heightPercentageToDP, listenOrientationChange, removeOrientationListener } from 'react-native-responsive-screen';
import { Basic } from 'app/components/Auth/Basic';
import { SmartPass } from 'app/components/Auth/SmartPass';
import { strings } from 'app/config/i18n/i18n';
import { authBegin } from 'app/actions/auth';
import { loadLatestMasterdata } from 'app/actions/masterdata';
import { handleDeeplink } from 'app/actions/settings';

class Login extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
        loggingIn: PropTypes.bool,
        loggedIn: PropTypes.bool,
        remember: PropTypes.bool,
        currentUser: PropTypes.object,
    };

    constructor(props) {
        super(props);
        const { username, password } = props.currentUser || {};
        const remember = props.remember;
        this.state = {
            index: 1,
            routes: [
                { key: 'basic', title: strings('login') },
                { key: 'smartPass', title: strings('smartPass') },
                { key: 'admin', title: strings('admin') },
            ],
            //username, password, remember
        };

        /*
        this.basicTab = () => <Basic isAdmin={false} username={username} password={password} remember={remember} onBeginLogin={(remember) => this.beginLogin('basic', remember)} />;
        this.adminTab = () => <Basic isAdmin={true} username={username} password={password} remember={remember} onBeginLogin={(remember) => this.beginLogin('admin', remember)} />;
        this.smartPassTab = () => <SmartPass onBeginLogin={(remember) => this.beginLogin('smartPass', remember)} />;
        */
        this.basicTab = () => (
            <Basic isAdmin={false} onBeginLogin={(remember, username, password) => this.beginLogin('basic', remember, username, password)} />
        );
        this.adminTab = () => (
            <Basic isAdmin={true} onBeginLogin={(remember, username, password) => this.beginLogin('admin', remember, username, password)} />
        );
        this.smartPassTab = () => <SmartPass onBeginLogin={remember => this.beginLogin('smartPass', remember)} />;

        this.renderScene = SceneMap({
            basic: this.basicTab,
            admin: this.adminTab,
            smartPass: this.smartPassTab,
        });
    }

    componentDidUpdate() {
        const { dispatch, navigation, loggedIn, deeplink, masterdataLastUpdated } = this.props;
        if (loggedIn) {
            dispatch(loadLatestMasterdata(masterdataLastUpdated));

            if (deeplink) dispatch(handleDeeplink({ deeplink, loggedIn, dispatch: navigation.dispatch }));
            else navigation.navigate('main');
        }
    }

    beginLogin = (type, remember, username, password) => {
        this.props.dispatch(authBegin(type, remember, username, password));
    };

    _handleIndexChange = index =>
        this.setState({
            index,
        });

    _renderTabBar = props => (
        <TabBar {...props} scrollEnabled indicatorStyle={styles.indicator} style={styles.tabbar} tabStyle={styles.tab} labelStyle={styles.label} />
    );

    render() {
        const width = Dimensions.get('window').width;
        initialLayout = {
            height: 0,
            width: width,
        };
        return (
            <TabView
                style={[styles.container, this.props.style]}
                navigationState={this.state}
                renderScene={this.renderScene}
                renderTabBar={this._renderTabBar}
                onIndexChange={this._handleIndexChange}
                initialLayout={initialLayout}
                tabBarPosition="bottom"
            />
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
        loggingIn: state.auth.loggingIn,
        loggedIn: state.auth.loggedIn,
        remember: state.auth.remember,
        currentUser: state.auth.currentUser,
        deeplink: state.settings.deeplink,
    };
};

export default connect(mapStateToProps)(Login);

const styles = EStyleSheet.create({
    container: {
        flex: 1,
    },
    tabbar: {
        backgroundColor: '$primaryDarkButtonBackground',
    },
    tab: {
        width: widthPercentageToDP('33%'),
    },
    indicator: {
        backgroundColor: '$primaryIndicatorColor',
    },
    label: {
        fontFamily: '$primaryFontNormal',
        color: '$primaryWhite',
    },
});
