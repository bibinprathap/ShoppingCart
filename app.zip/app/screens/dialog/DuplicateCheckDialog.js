import React, { Component } from 'react';
import { View, TouchableNativeFeedback, TouchableOpacity } from 'react-native';
import { Text, Button } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { inspectionsHelper } from 'app/api/helperServices';
import { HeaderGeneric, DuplicateInspection, Modal, Icon, commonStyles } from 'app/components';

export default class DuplicateCheckDialog extends Component {
    constructor(props) {
        super(props);
        this.state = { isShowing: false, applicationNumber: null };

        this.handleViewReview = this.handleViewReview.bind(this);
    }

    componentDidMount() {
        const { duplicateInspection } = this.props;
        if (duplicateInspection && duplicateInspection.length > 0 && !this.state.applicationNumber) {
            this.handleViewReview(duplicateInspection[0]);
        }
    }

    handleOnRequestClose = event => {
        if (this.props.showButton) {
            this.setState({ isShowing: false });
            return;
        }

        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    handleDuplicatePressed = () => {
        this.setState({ isShowing: true });
    };

    handleViewReview(item) {
        this.setState({
            applicationNumber: item.applicationNumber,
        });
    }
    onShowInspection(markedAsDuplicate) {
        const { inspection, navigation } = this.props;

        const inspectionParams = {
            workflowInstanceId: markedAsDuplicate.workflowInstanceId,
            applicationNumber: markedAsDuplicate.applicationNumber,
            workflowApplicationNumber: markedAsDuplicate.workflowApplicationNumber,

            inspectionTypeId: inspection.inspectionTypeDetail.inspectionTypeId,
            workflowConst: inspection.inspectionTypeDetail.workflowConst,
            source: 'issueNumber',
        };

        inspectionsHelper.showInspection({ navigation, inspectionParams, onSuccess: this.handleOnRequestClose(), showDialog: true });
    }

    render() {
        const {
            showButton,
            duplicateInspection,
            optionSelected,
            inspection,
            editable,
            isChecklist,
            violationItem,
            errorLog,
            duplicatesDecision,
        } = this.props;
        let applicationNumber = this.state.applicationNumber;
        if (!showButton && !this.props.isShowing) return null;
        const isShowing = this.props.showButton ? this.state.isShowing : this.props.isShowing;

        if (editable && !(duplicateInspection && duplicateInspection.duplicateCandidates && duplicateInspection.duplicateCandidates.length > 0)) {
            return null;
        }
        const { duplicateCandidates } = duplicateInspection || {};

        if (duplicateInspection && duplicateInspection.length > 0 && !applicationNumber) {
            applicationNumber = duplicateCandidates[0].applicationNumber;
        }

        //  const selectedDuplicateInspection = duplicateCandidates.find(i => i.applicationNumber == applicationNumber);

        let didDuplicateCheck = undefined;
        let checkingDuplicate = duplicateInspection && duplicateInspection.checking;
        let currentDuplicates = null;

        if (!checkingDuplicate && duplicateInspection && duplicatesDecision != undefined) {
            currentDuplicates = duplicatesDecision.filter(function(duplicate) {
                return (
                    duplicateCandidates.filter(item => item.applicationNumber === duplicate.applicationNumber && duplicate.isDuplicate == true)
                        .length > 0
                );
            });
            if (currentDuplicates && currentDuplicates.length === 0) {
                const notDuplicates = duplicatesDecision.filter(function(e) {
                    return duplicateCandidates.filter(item => item.applicationNumber == e.applicationNumber && e.isDuplicate == false).length > 0;
                });

                if (notDuplicates && notDuplicates.length > 0) {
                    didDuplicateCheck = true;
                }
            } else {
                didDuplicateCheck = true;
            }
        }
        let markedAsDuplicate = {};
        if (duplicatesDecision && duplicatesDecision.length > 0) {
            markedAsDuplicate = duplicatesDecision.find(i => i && i.isDuplicate == true);
        }
        const showDuplicateOf = markedAsDuplicate && markedAsDuplicate.applicationNumber;
        return (
            <View>
                {showButton && (
                    <View style={styles.duplicateContainer}>
                        {duplicateInspection && duplicateInspection.duplicateCandidates && duplicateInspection.duplicateCandidates.length > 0 && (
                            <TouchableOpacity onPress={this.handleDuplicatePressed}>
                                <View style={styles.flexrow}>
                                    <Icon name={'content-copy'} type="MaterialCommunityIcons" size={24} color="#000000" />
                                    {errorLog}
                                    {didDuplicateCheck && !showDuplicateOf && <Text style={styles.smallText}> {strings('notDuplicate')} </Text>}
                                </View>
                            </TouchableOpacity>
                        )}
                        {!showDuplicateOf &&
                            (!duplicateInspection ||
                                !duplicateInspection.duplicateCandidates ||
                                duplicateInspection.duplicateCandidates.length == 0) && (
                                <View style={styles.flexrow}>
                                    <Text style={[styles.smallText, styles.mutedText]}> {strings('noDuplicateDetected')} </Text>
                                </View>
                            )}

                        {!errorLog && showDuplicateOf && (
                            <View style={styles.flexrow}>
                                <Text style={styles.smallText}> {strings('duplicateOf') + ' '} </Text>
                                <TouchableOpacity onPress={this.onShowInspection.bind(this, markedAsDuplicate)} style={styles.flexEnd}>
                                    <Text style={[commonStyles.generalText, commonStyles.linkText]}>
                                        {markedAsDuplicate.workflowApplicationNumber}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                )}
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric backAction={this.handleOnRequestClose} title={strings('duplicateInspections')} />
                    <DuplicateInspection
                        optionSelected={optionSelected}
                        duplicateInspection={duplicateInspection}
                        duplicatesDecision={duplicatesDecision}
                        inspection={inspection}
                        editable={editable}
                        isChecklist={isChecklist}
                        violationItem={violationItem}
                    />
                    <Button style={styles.doneButton} title="Done" onPress={this.handleOnRequestClose}>
                        {strings('done')}
                    </Button>
                </Modal>
            </View>
        );
    }
}

const styles = EStyleSheet.create({
    doneButton: {
        backgroundColor: '$primaryLightButtonBackground',
        alignSelf: 'center',
        width: '98%',
        marginVertical: 5,
        paddingVertical: 5,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
    smallText: {
        zIndex: 100,
        textAlign: 'center',
        textAlignVertical: 'center',
        color: '$primaryDividerDarkColor',

        fontSize: '$primaryTextXXS',
        justifyContent: 'center',
        alignItems: 'center',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    duplicateContainer: { flex: 1, flexDirection: 'row', justifyContent: 'space-between' },
    flexrow: { flex: 1, flexDirection: 'row' },
    flexEnd: { flexDirection: 'row', justifyContent: 'flex-end' },
});
