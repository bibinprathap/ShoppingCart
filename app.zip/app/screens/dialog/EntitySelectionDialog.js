import React, { Component } from 'react';
import { View, Modal, I18nManager, Image, ImageBackground, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { SafeAreaView } from 'react-navigation';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';

const getEntityRects = () => {
    const entityRects = [
        { top: 95, left: 35, width: 260, height: 155, entityConst: 'EA', backgroundColor: 'red' },
        { top: 95, left: 315, width: 260, height: 155, entityConst: 'TADWEER', backgroundColor: 'green' },
        { top: 265, left: 35, width: 260, height: 155, entityConst: 'ADM', backgroundColor: 'green' },
        { top: 265, left: 315, width: 260, height: 155, entityConst: 'ITC', backgroundColor: 'red' },
        { top: 440, left: 35, width: 260, height: 155, entityConst: 'ADSSC', backgroundColor: 'red' },
        { top: 440, left: 315, width: 260, height: 155, entityConst: 'ADDC', backgroundColor: 'red' },
        { top: 610, left: 35, width: 260, height: 155, entityConst: 'ADAFSA', backgroundColor: 'red' },
        { top: 610, left: 315, width: 260, height: 155, entityConst: 'AWQAF', backgroundColor: 'red' },
    ];

    const swapEntities = (index1, index2) => {
        const tempLeft = entityRects[index2].left;
        entityRects[index2].left = entityRects[index1].left;
        entityRects[index1].left = tempLeft;
    };

    if (I18nManager.isRTL === true) {
        swapEntities(0, 1);
        swapEntities(2, 3);
        swapEntities(4, 5);
        swapEntities(6, 7);
    }
    return entityRects;
};

export default class EntitySelectionDialog extends Component {
    constructor(props) {
        super(props);
    }

    handleOnRequestClose = event => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    handleOnEntityPress = selectedEntity => {
        const { onRequestClose, onEntitySelected } = this.props;
        if (selectedEntity) {
            if (typeof onEntitySelected === 'function') onEntitySelected(selectedEntity);
        } else {
            if (typeof onRequestClose === 'function') onRequestClose();
        }
    };

    render() {
        const entityRects = getEntityRects();
        const { isShowing } = this.props;
        if (!isShowing) return null;
        else {
            return (
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric title={strings('chooseEntity')} backAction={this.handleOnRequestClose} />
                    <View style={styles.container}>
                        <Text style={styles.heading}>{strings('chooseEntity')}</Text>
                        <ImageBackground style={styles.backgroundImage} source={require('app/images/entitySelection.png')}>
                            {entityRects.map((entity, index) => {
                                const { top, left, width, height, entityConst, backgroundColor } = entity;
                                return (
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.handleOnEntityPress(entityConst);
                                        }}
                                        key={index}
                                        style={{
                                            width: width,
                                            height: height,
                                            position: 'absolute',
                                            top: top,
                                            left: left,
                                            elevation: 1,
                                            borderRadius: 6,
                                        }}
                                    ></TouchableOpacity>
                                );
                            })}
                        </ImageBackground>
                    </View>
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    backgroundImage: {
        //position: 'absolute',
        top: -50,
        left: 0,
        width: 610,
        height: 800,
    },
    heading: {
        zIndex: 100,
        marginTop: 20,
        marginLeft: 20,
        color: '$primaryMediumTextColor',
        fontSize: '$primaryTextMD',
    },
});
