import React, { Component } from 'react';
import { View, Image, ActivityIndicator } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric } from 'app/components';
import { ZoomableImage, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';

export default class ImageDialog extends Component {
    constructor(props) {
        super(props);
        this.state = { width: 0, height: 0, uri: null };
    }

    componentDidMount() {
        if (this.props.source) {
            Image.getSize(this.props.source.uri, (width, height) => {
                this.setState({ width, height, uri: this.props.source.uri });
            });
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.isVisible && this.props.source && this.props.source.uri != this.state.uri) {
            Image.getSize(this.props.source.uri, (width, height) => {
                this.setState({ width, height });
            });
        }
    }

    render() {
        const { isVisible, source, title } = this.props;
        if (!isVisible) return null;
        const aspectRatio = this.state.width ? this.state.width / this.state.height : 0;
        const imageStyles = { aspectRatio: aspectRatio };

        return (
            <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.props.onRequestClose}>
                <HeaderGeneric backAction={this.props.onRequestClose} title={title || strings('back')} />
                <View style={styles.wrapper}>
                    {(this.state.width > 0 && (
                        <ZoomableImage
                            style={imageStyles}
                            isRemoteImage={true}
                            offsetTop={0}
                            offsetLeft={0}
                            imageWidth={this.state.width}
                            imageHeight={this.state.height}
                            source={source}
                        />
                    )) ||
                        null}
                    {(!this.state.width && (
                        <View style={styles.loaderContainer}>
                            <ActivityIndicator />
                        </View>
                    )) ||
                        null}
                </View>
            </Modal>
        );
    }
}

const styles = EStyleSheet.create({
    wrapper: {
        flex: 1,
        margin: 10,
    },
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
