import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Dimensions, TouchableOpacity, I18nManager, requireNativeComponent, UIManager, findNodeHandle, DeviceEventEmitter } from 'react-native';
import { Text, Button } from 'react-native-paper';
// import { ScrollView } from 'react-native';

import { Loader } from 'app/components/Loader';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/MaterialIcons';

import * as Animatable from 'react-native-animatable';

import styles from './styles';
import AppApi from 'app/api/real';
const api = new AppApi();


class TestTracking extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <View style={styles.container}>
                <Text>test background Worker</Text>
            </View>
        );
    }
}

export default TestTracking;
