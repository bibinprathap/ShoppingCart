import styles from './styles';
import IdScan from './IdScan';

export { styles, IdScan };
