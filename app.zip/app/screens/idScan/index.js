import styles from './styles';
import IdScan from './IdScan';
import TestTracking from './TestTracking';

export { styles, IdScan, TestTracking };
