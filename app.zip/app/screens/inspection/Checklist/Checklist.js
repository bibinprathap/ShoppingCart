import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { Text, IconButton } from 'react-native-paper';
import styles from './styles';
import EStyleSheet from 'react-native-extended-stylesheet';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { InspectionDetail } from 'app/components/InspectionDetail';
import { valueChanged, infoChanged, createInspectionRecord, checkDuplicate } from 'app/actions/inspections';
import { GeneralInfoForm, DynamicForm, ResUnitOccupancyForm, AbandonedVehicleForm, GeneralAppearanceVehicleForm } from 'app/components/Form';
import { strings } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { _state } from 'app/config/store';
import { withNavigationFocus } from 'react-navigation';

// Todo: Find a better way to do this,
// how can we load it dynamically (without static import)
// or from some central place

const getFixedForm = ({ name, key, title, onFormChange, initialValues, editable, currentInspectionVersion }) => {
    switch (name) {
        case 'generalInfo':
            return (
                <GeneralInfoForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{ remar22222ks: { editable: true } }}
                />
            );
        case 'abandonedVehicleInfo':
            return (
                <AbandonedVehicleForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                />
            );
        case 'generalAppearanceVehicleInfo':
            return (
                <GeneralAppearanceVehicleForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                />
            );
        case 'ResUnitOccupancyInfo':
            return (
                <ResUnitOccupancyForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                />
            );
        default:
            return <Text>{`Invalid fixed form name:${name}`}</Text>;
    }
};
const generateFormComponents = (
    inspectionDefinition,
    selectedVisit,
    inspection,
    handleVisitInfoChange,
    handleInfoChange,
    editable,
    currentInspectionVersion
) => {
    let theForms = null;
    if (inspectionDefinition && inspectionDefinition.type === 'form') {
        theForms = inspectionDefinition.def.map((formDef, index) => {
            let TheFormComponent = undefined;
            const theKey = `${formDef.name}_${index}`;
            const formChangeHandler = formDef.scope == 'visit' ? handleVisitInfoChange : handleInfoChange;
            const initialValues =
                formDef.scope == 'visit' ? selectedVisit && selectedVisit[formDef.name] : inspection.info && inspection.info[formDef.name];
            if (formDef.formType == 'fixed') {
                return getFixedForm({
                    name: formDef.name,
                    key: theKey,
                    title: undefined,
                    onFormChange: formChangeHandler,
                    initialValues: initialValues,
                    editable: editable,
                    currentInspectionVersion: currentInspectionVersion,
                });
            } else {
                return (
                    <DynamicForm
                        key={theKey}
                        formDef={{ ...formDef, editable: editable }}
                        initialValues={initialValues}
                        formChangeHandler={formChangeHandler}
                        currentInspectionVersion={currentInspectionVersion}
                    />
                );
            }
        });
    }
    return (
        <View style={[styles.contentContainer, styles.formContainer]}>
            <ScrollView style={{ flex: 1 }}>{theForms}</ScrollView>
        </View>
    );
};

class Checklist extends Component {
    constructor(props) {
        super(props);
        const currentInspection = props.currentInspectionContainer.inspection;
        const selectedVisitIndex = currentInspection.visits.length - 1;
        this.state = { selectedVisitIndex };
        this.createInspection = this.createInspection.bind(this);
    }

    createInspection = () => {
        const { navigation, dispatch } = this.props;
        if (this.props.isFocused) {
            const { inspection } = this.props.currentInspectionContainer || {};
            const { selectedVisitIndex } = this.state;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            if (inspectionDefinition) {
                dispatch(
                    createInspectionRecord({
                        visitIndex: selectedVisitIndex,
                    })
                );
            }
        }
    };
    componentDidUpdate(prevProps) {
        if (prevProps.isFocused !== this.props.isFocused) {
            this.createInspection();
        }
    }
    componentDidMount() {
        this.createInspection();
    }

    retryInspectionRecordCreation() {
        const { dispatch } = this.props;
        const { inspection } = this.props.currentInspectionContainer || {};
        const { selectedVisitIndex } = this.state;
        const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
        const inspectionDefinition = selectedVisit && selectedVisit.def;
        if (inspectionDefinition) {
            dispatch(
                createInspectionRecord({
                    visitIndex: selectedVisitIndex,
                })
            );
        }
    }

    static propTypes = {
        currentInspectionContainer: PropTypes.object,
    };

    handleInfoChange = (values, dispatch, props, previousValues) => {
        //console.log(`Checklist.handleInfoChange: form: ${props.form}, values:`, values);
        this.props.dispatch(infoChanged(props.form, values));
        if (this.props.editable && values.distortionType && !(previousValues.distortionType && previousValues.distortionType == values.distortionType))
            this.props.dispatch(checkDuplicate());
    };

    handleVisitInfoChange = (values, dispatch, props, previousValues) => {
        //console.log(`Checklist.handleVisitInfoChange: form: ${props.form}, values:`, values);
        const { inspection } = this.props.currentInspectionContainer || {};
        const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        this.props.dispatch(infoChanged(props.form, values, currentVisitIndex));
    };

    handleValueChange = newValues => {
        const previousState = _state;
        let actions = inspectionsHelper.getChecklistActions({
            newValues,
            selectedVisitIndex: this.state.selectedVisitIndex,
            selectedService: this.props.selectedService,
            currentInspectionContainer: this.props.currentInspectionContainer,
            previousState,
        });
        this.props.dispatch(actions);
    };

    handleAttachmentChange = newValues => {
        /*
            for now we dispatch valueChanged action which will take care of saving the updated attachments to the store
            we may want to change this in future, to trigger upload in the background even before user saves their work
        */
        this.props.dispatch(
            valueChanged({
                visitIndex: this.state.selectedVisitIndex,
                newValues: newValues,
            })
        );
    };

    render() {
        const { currentInspectionContainer } = this.props;
        const { inspection } = currentInspectionContainer;
        const totalVisits = inspection.visits && inspection.visits.length;
        const { selectedVisitIndex } = this.state;
        const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
        const selectedVisitValues = selectedVisit && selectedVisit.values;
        const inspectionDefinition = selectedVisit && selectedVisit.def;
        const coords = inspection && inspection.location && inspection.location.coords;
        const inspectionID = inspection && inspection.inspectionID;
        if (!inspectionDefinition || !coords) {
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.unknownServiceSelection}>
                            <Text style={styles.unknownServiceHeading}>
                                {!inspectionDefinition ? strings('noservicemethod') : strings('nolocationselected')}
                            </Text>
                        </View>
                    </View>
                </InspectionContainer>
            );
        } else if (inspectionID) {
            const { editable, currentInspectionVersion } = this.props;

            this.theFormComponents = generateFormComponents(
                inspectionDefinition,
                selectedVisit,
                inspection,
                this.handleVisitInfoChange,
                this.handleInfoChange,
                editable,
                currentInspectionVersion
            );
            let content = undefined;

            if (inspectionDefinition.type === 'checklist') {
                const parentViolatorType = this.props.selectedService[0].violatorType;
                content = (
                    <View style={[styles.contentContainer, styles.checklistContainer]}>
                        <InspectionDetail
                            def={inspectionDefinition.def}
                            values={selectedVisitValues}
                            editable={editable}
                            parentViolatorType={parentViolatorType}
                            onValuechanged={this.handleValueChange}
                            onAttachmentChanged={this.handleAttachmentChange}
                        />
                    </View>
                );
            } else if (inspectionDefinition.type === 'form') {
                content = this.theFormComponents;
            } else {
                //can there be any other kind of inspection?
                content = (
                    <View style={[styles.contentContainer, styles.unknownInspectionContainer]}>
                        <Text>{strings('unknownInspectionDef')}</Text>
                    </View>
                );
            }
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.contentWithChecklist}>
                            {/* <View style={styles.visitTabContainer}>
                                <Text>
                                    Visits tabs will go here [total visits {totalVisits}, selected visit index
                                    {selectedVisitIndex}]
                                </Text>
                            </View> */}
                            {content}
                        </View>
                    </View>
                </InspectionContainer>
            );
        } else {
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.unknownServiceSelection}>
                            {inspection.saving ? (
                                <Text style={styles.unknownServiceHeading}>{strings('creatingInspectionRecord')} </Text>
                            ) : (
                                    <View>
                                        <Text style={[styles.unknownServiceHeading, styles.errortext]}>{strings('serviceNotAvailable')}</Text>
                                        <View style={styles.retryButton}>
                                            <IconButton
                                                icon="refresh"
                                                style={styles.retryButtonIcon}
                                                color={EStyleSheet.value('$primaryDarkButtonBackground')}
                                                size={60}
                                                onPress={() => this.retryInspectionRecordCreation()}
                                            />
                                        </View>
                                    </View>
                                )}
                        </View>
                    </View>
                </InspectionContainer>
            );
        }
    }
}

mapStateToProps = state => {
    const currentInspection = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    let selectedService = undefined;
    if (state.masterdata.services && currentInspection && currentInspection.inspection && currentInspection.inspection.service) {
        selectedService = state.masterdata.services.filter(service => service.serviceId == currentInspection.inspection.service);
    }

    return {
        currentInspectionContainer: { ...currentInspection },
        selectedService: selectedService,
        editable: inspectionsHelper.getIsEditable(currentInspection),
        currentInspectionVersion: state.inspections.currentInspectionVersion,
    };
};

const connectedChecklist = connect(mapStateToProps)(withNavigationFocus(Checklist));
export default screenWithSpinner(connectedChecklist, { theme: 'light' });
