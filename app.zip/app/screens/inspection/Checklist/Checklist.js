import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { Text, IconButton } from 'react-native-paper';
import styles from './styles';
import EStyleSheet from 'react-native-extended-stylesheet';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { InspectionDetail } from 'app/components/InspectionDetail';
import { valueChanged, infoChanged, createInspectionRecord, checkDuplicate } from 'app/actions/inspections';
import {
    GeneralInfoForm,
    DynamicForm,
    ResUnitOccupancyForm,
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    FollowupForm,
} from 'app/components/Form';
import { strings } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { _state } from 'app/config/store';
import { withNavigationFocus } from 'react-navigation';
import { shallowEqual } from 'app/api/helperServices';

// Todo: Find a better way to do this,
// how can we load it dynamically (without static import)
// or from some central place

const getFixedForm = ({ name, key, title, onFormChange, initialValues, editable, currentInspectionVersion, dispatch }) => {
    switch (name) {
        case 'generalInfo':
            return (
                <GeneralInfoForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{ remar22222ks: { editable: true } }}
                />
            );
        case 'abandonedVehicleInfo':
            return (
                <AbandonedVehicleForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                />
            );
        case 'generalAppearanceVehicleInfo':
            return (
                <GeneralAppearanceVehicleForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                />
            );
        case 'ResUnitOccupancyInfo':
            return (
                <ResUnitOccupancyForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                    dispatch={dispatch}
                />
            );
        default:
            return <Text>{`Invalid fixed form name:${name}`}</Text>;
    }
};
const generateFormComponents = (
    inspectionDefinition,
    selectedVisit,
    inspection,
    handleVisitInfoChange,
    handleInfoChange,
    editable,
    currentInspectionVersion,
    backAction,
    dispatch
) => {
    let theForms = null;
    if (inspectionDefinition && inspectionDefinition.type === 'form') {
        theForms = inspectionDefinition.def.map((formDef, index) => {
            let TheFormComponent = undefined;
            const theKey = `${formDef.name}_${index}`;
            const formChangeHandler = formDef.scope == 'visit' ? handleVisitInfoChange : handleInfoChange;
            const initialValues =
                formDef.scope == 'visit' ? selectedVisit && selectedVisit[formDef.name] : inspection.info && inspection.info[formDef.name];
            if (formDef.formType == 'fixed') {
                return getFixedForm({
                    name: formDef.name,
                    key: theKey,
                    title: undefined,
                    onFormChange: formChangeHandler,
                    initialValues: initialValues,
                    editable: editable,
                    currentInspectionVersion: currentInspectionVersion,
                    dispatch: dispatch,
                });
            } else if (formDef.formType == 'followup') {
                return (
                    <FollowupForm
                        backAction={backAction}
                        key={theKey}
                        dispatch={dispatch}
                        formDef={{ ...formDef, editable: editable }}
                        initialValues={initialValues}
                        formChangeHandler={formChangeHandler}
                        inspection={inspection}
                        currentInspectionVersion={currentInspectionVersion}
                    />
                );
            } else {
                return (
                    <DynamicForm
                        key={theKey}
                        formDef={{ ...formDef, editable: editable }}
                        initialValues={initialValues}
                        formChangeHandler={formChangeHandler}
                        currentInspectionVersion={currentInspectionVersion}
                        formProps={{ attachmentList: { editable: true } }}
                    />
                );
            }
        });
    }
    return (
        <View style={[styles.contentContainer, styles.formContainer]}>
            <ScrollView style={{ flex: 1 }}>{theForms}</ScrollView>
        </View>
    );
};

class Checklist extends Component {
    constructor(props) {
        super(props);
        const currentInspection = props.currentInspectionContainer.inspection;
        let selectedVisitIndex = currentInspection.visits.length - 1;
        if (props.visitindex) selectedVisitIndex = props.visitindex;
        this.state = { selectedVisitIndex };
        this.createInspection = this.createInspection.bind(this);
        this.handleVisitInfoChange = this.handleVisitInfoChange.bind(this);
    }

    shouldComponentUpdate(nextProps, nextState) {
        //
        if (nextProps.followupreview) {
            const currentVisitsProps = this.props.currentInspectionContainer.inspection.visits;
            const nextVisitsProps = nextProps.currentInspectionContainer.inspection.visits;
            return (
                !this.shallowEqualState(this.state, nextState) ||
                !this.shallowEqualWithoutReactElements(currentVisitsProps[currentVisitsProps.length - 1], nextVisitsProps[nextVisitsProps.length - 1])
            );
        } else {
            return shallowEqual(this.props, nextProps, this.state, nextState);
        }
    }

    shallowEqualState = (thisState, nextState) => {
        return thisState === nextState;
    };

    shallowEqualWithoutReactElements = (thisProps, nextProps) => {
        let equals = false;
        if (thisProps === nextProps) {
            equals = true;
        } else if (typeof thisProps === 'object' && typeof nextProps === 'object') {
            equals = true;
            const propNames = new Set(Object.keys(thisProps), Object.keys(nextProps));
            for (const propName of propNames) {
                // if (propName == 'navigation' || propName == 'currentInspectionContainer') {
                // } else

                if (propName != 'formDef' && thisProps[propName] !== nextProps[propName] && !this.isReactElement(thisProps[propName])) {
                    // No need to check nextProps[propName] as well, as we know they are not equal
                    equals = false;
                    break;
                }
            }
        }
        return equals;
    };
    isReactElement = suspectedElement => {
        let isElem = false;
        if (React.isValidElement(suspectedElement)) {
            isElem = true;
        } else if (Array.isArray(suspectedElement)) {
            for (let i = 0, l = suspectedElement.length; i < l; i++) {
                if (React.isValidElement(suspectedElement[i])) {
                    isElem = true;
                    break;
                }
            }
        }
        return isElem;
    };

    createInspection = () => {
        //console.log('Checklist.createInspection()');
        const { navigation, dispatch } = this.props;
        if (this.props.isFocused) {
            const { inspection } = this.props.currentInspectionContainer || {};
            const { selectedVisitIndex } = this.state;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            const payload = { visitIndex: selectedVisitIndex, refNumber: inspection.refNumber };
            if (inspectionDefinition) {
                const { canCreateInspection, reason } = inspectionsHelper.canCreateInspectionRecord({ inspection, payload });
                if (!!canCreateInspection) {
                    dispatch(createInspectionRecord(inspection, payload));
                } else {
                    console.log('canCreateInspection failure... canCreateInspection: ', canCreateInspection, 'reason: ', reason);
                }
            }
        }
    };
    componentDidUpdate(prevProps) {
        const { inspection } = this.props.currentInspectionContainer || {};
        if (
            prevProps.isFocused !== this.props.isFocused ||
            (inspection && !inspection.inspectionId && !inspection.saving && !inspection.savingError)
        ) {
            this.createInspection();
        }
    }
    componentDidMount() {
        this.createInspection();
    }

    static propTypes = {
        currentInspectionContainer: PropTypes.object,
    };

    handleInfoChange = (values, dispatch, props, previousValues) => {
        //console.log(`Checklist.handleInfoChange: form: ${props.form}, values:`, values);
        this.props.dispatch(infoChanged(props.form, values));
    };

    handleVisitInfoChange = async (values, dispatch, props, previousValues) => {
        //console.log(`Checklist.handleVisitInfoChange: form: ${props.form}, values:`, values);
        const { inspection } = this.props.currentInspectionContainer || {};
        let currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        if (this.props.visitindex != undefined) currentVisitIndex = this.props.visitindex;
        this.props.dispatch(infoChanged(props.form, values, currentVisitIndex));
        debugger;
        if (
            this.props.editable &&
            values.distortionType &&
            !(previousValues.distortionType && previousValues.distortionType == values.distortionType)
        ) {
            await inspectionsHelper.nextFrame();
            this.props.dispatch(checkDuplicate());
        }
    };

    handleValueChange = newValues => {
        const previousState = _state;
        // debugger;

        let actions = inspectionsHelper.getChecklistActions({
            newValues,
            selectedVisitIndex: this.state.selectedVisitIndex,
            selectedService: this.props.selectedService,
            currentInspectionContainer: this.props.currentInspectionContainer,
            previousState,
        });
        this.props.dispatch(actions);
    };

    handleAttachmentChange = newValues => {
        /*
            for now we dispatch valueChanged action which will take care of saving the updated attachments to the store
            we may want to change this in future, to trigger upload in the background even before user saves their work
        */
        this.props.dispatch(
            valueChanged({
                visitIndex: this.state.selectedVisitIndex,
                newValues: newValues,
            })
        );
    };

    render() {
        const { currentInspectionContainer, backAction, dispatch } = this.props;
        const { inspection } = currentInspectionContainer;
        const totalVisits = inspection.visits && inspection.visits.length;
        const { selectedVisitIndex } = this.state;
        const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
        const selectedVisitValues = selectedVisit && selectedVisit.values;
        const inspectionDefinition = selectedVisit && selectedVisit.def;
        const coords = inspection && inspection.location && inspection.location.coords;
        const inspectionId = inspection && inspection.inspectionId;
        // console.warn('Checklist Rendering... inspectionDefinition: ', inspectionDefinition);
        if (!inspectionDefinition || !coords) {
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.unknownServiceSelection}>
                            <Text style={styles.textHeading}>
                                {!inspectionDefinition ? strings('noservicemethod') : strings('nolocationselected')}
                            </Text>
                        </View>
                    </View>
                </InspectionContainer>
            );
        } else if (inspectionId) {
            const { editable, currentInspectionVersion } = this.props;

            this.theFormComponents = generateFormComponents(
                inspectionDefinition,
                selectedVisit,
                inspection,
                this.handleVisitInfoChange,
                this.handleInfoChange,
                editable,
                currentInspectionVersion,
                backAction,
                dispatch
            );
            let content = undefined;

            if (inspectionDefinition.type === 'checklist') {
                // const parentViolatorType = this.props.selectedService[0].violatorType;
                content = (
                    <View style={[styles.contentContainer, styles.checklistContainer]}>
                        <InspectionDetail
                            def={inspectionDefinition.def}
                            values={selectedVisitValues}
                            editable={editable}
                            // parentViolatorType={parentViolatorType}
                            onValuechanged={this.handleValueChange}
                            onAttachmentChanged={this.handleAttachmentChange}
                        />
                    </View>
                );
            } else if (inspectionDefinition.type === 'form') {
                content = this.theFormComponents;
            } else {
                //can there be any other kind of inspection?
                content = (
                    <View style={[styles.contentContainer, styles.unknownInspectionContainer]}>
                        <Text>{strings('unknownInspectionDef')}</Text>
                    </View>
                );
            }
            if (this.props.followupreview) {
                return (
                    <View style={styles.MainContainer}>
                        <View style={styles.contentWithChecklist}>{content}</View>
                    </View>
                );
            }
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.contentWithChecklist}>
                            {/* <View style={styles.visitTabContainer}>
                                <Text>
                                    Visits tabs will go here [total visits {totalVisits}, selected visit index
                                    {selectedVisitIndex}]
                                </Text>
                            </View> */}
                            {content}
                        </View>
                    </View>
                </InspectionContainer>
            );
        } else {
            let errorDetail = {};
            if (!inspection.saving) {
                const payload = { visitIndex: selectedVisitIndex, refNumber: inspection.refNumber };
                const { canCreateInspection, reason } = inspectionsHelper.canCreateInspectionRecord({ inspection, payload });
                if (!canCreateInspection) {
                    errorDetail.message = reason;
                } else {
                    errorDetail = inspection.savingError;
                }
            }
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.MainContainer}>
                        <View style={styles.unknownServiceSelection}>
                            {inspection.saving ? (
                                <Text style={styles.textHeading}>{strings('creatingInspectionRecord')} </Text>
                            ) : (
                                <View>
                                    <Text style={[styles.textHeading, styles.errorText]}>{strings('serviceNotAvailable')}</Text>
                                    {errorDetail && errorDetail.message && <Text style={styles.textDetailText}>{errorDetail.message}</Text>}
                                    {errorDetail && errorDetail.detail && <Text style={styles.textDetailText}>{errorDetail.detail}</Text>}
                                    <View style={styles.retryButton}>
                                        <IconButton
                                            icon="refresh"
                                            style={styles.retryButtonIcon}
                                            color={EStyleSheet.value('$primaryDarkTextColor')}
                                            size={32}
                                            onPress={this.createInspection}
                                        />
                                    </View>
                                </View>
                            )}
                        </View>
                    </View>
                </InspectionContainer>
            );
        }
    }
}

mapStateToProps = state => {
    const currentInspection = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    let selectedService = undefined;
    if (state.masterdata.services && currentInspection && currentInspection.inspection && currentInspection.inspection.service) {
        selectedService = state.masterdata.services.filter(service => service.serviceId == currentInspection.inspection.service);
    }

    return {
        currentInspectionContainer: { ...currentInspection },
        selectedService: selectedService,
        editable: inspectionsHelper.getIsEditable(currentInspection),
        currentInspectionVersion: 1,
    };
};
// currentInspectionVersion: state.inspections.currentInspectionVersion,

const connectedChecklist = connect(mapStateToProps)(withNavigationFocus(Checklist));
export default screenWithSpinner(connectedChecklist, { theme: 'light' });
