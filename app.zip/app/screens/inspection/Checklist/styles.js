import EStyleSheet from 'react-native-extended-stylesheet';
export default EStyleSheet.create({
    MainContainer: {
        flex: 1,
    },
    unknownServiceSelection: {
        flex: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    unknownServiceHeading: {
        fontSize: '$primaryTextMD',
        textAlign: 'center',
    },
    errortext: { color: '$primaryErrorTextColor' },
    retryButton: {
        justifyContent: 'center',
        alignItems: 'flex-start',
    },
    retryButtonIcon: { width: 200 },
    unknownServiceText: {
        fontSize: '$primaryTextSM',
        textAlign: 'center',
    },
    contentWithChecklist: { flex: 10 },
    visitTabContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primarySelectedItem',
    },
    contentContainer: {
        flex: 12,
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 5,
        borderRadius: 10,
    },
    checklistContainer: {
        backgroundColor: '$primaryWhite',
    },
    formContainer: {
        backgroundColor: '$primaryLightBackground',
    },
    unknownInspectionContainer: {
        backgroundColor: '$primaryLightBackground',
        justifyContent: 'center',
        alignItems: 'center',
    },
});
