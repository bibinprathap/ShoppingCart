import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ScrollView } from 'react-native';
import { Button, Card } from 'react-native-paper';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { _state } from 'app/config/store';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';
import { ReviewCategory } from 'app/screens/inspection/Review';
import { setDuplicate } from 'app/actions/inspections';
import DuplicateCheckList from './DuplicateCheckList';
import DuplicateCheckReview from './DuplicateCheckReview';

class DuplicateCheck extends Component {
    static propTypes = {
        currentInspectionContainer: PropTypes.object,
    };
    constructor() {
        super();
        this.state = {
            showDetails: false,
        };
        this.handleViewReview = this.handleViewReview.bind(this);
        this.optionSelectedNo = this.optionSelectedNo.bind(this);
        this.optionSelectedYes = this.optionSelectedYes.bind(this);
    }
    componentDidMount() {
        const { currentInspectionContainer } = this.props;
        const { inspectionRefNumber } = this.state;
        if (currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates.length > 0 && inspectionRefNumber == undefined)
            this.handleViewReview(currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates[0]);
    }
    onReviewSuccess = result => {
        if (result && result.success) {
            const { formProps } = this.props;
            //const { uaeId, expiryDate, firstName, middleName, lastName, familyName, dateOfBirth, nationality } = result.data || {};
            const data = result.data || {};
            //console.log('data = ', data);
            Object.keys(data).forEach(key => {
                //console.log(`${key} = ${data[key]}`);
                formProps.change(key, data[key]);
            });
        }
    };
    handleViewReview(item) {
        let selectedService = undefined;
        if (_state.masterdata.services && item.service) {
            selectedService = _state.masterdata.services.find(s => s.serviceId == item.service);
        }
        let serviceCategory;
        if (selectedService) serviceCategory = inspectionsHelper.getServiceCategory(selectedService);
        this.setState({
            showDetails: true,
            serviceCategory: serviceCategory,
            inspectionRefNumber: item.refNumber,
        });
    }

    optionSelectedNo = () => {
        setTimeout(() => {
            const { currentInspectionContainer } = this.props;
            const { inspectionRefNumber } = this.state;
            const inspection = currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates.find(i => i.refNumber == inspectionRefNumber);
            this.props.dispatch(setDuplicate({ option: false, inspection }));
        });
    };
    optionSelectedYes = () => {
        setTimeout(() => {
            const { currentInspectionContainer } = this.props;
            const { inspectionRefNumber } = this.state;
            const inspection = currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates.find(i => i.refNumber == inspectionRefNumber);
            this.props.dispatch(setDuplicate({ option: true, inspection }));
        });
    };

    render() {
        const { currentInspectionContainer, editable } = this.props;
        const { showDetails, serviceCategory, inspectionRefNumber } = this.state;
        const inspection = currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates.find(i => i.refNumber == inspectionRefNumber);
        const duplicateContents = currentInspectionContainer.inspection.duplicateCheck.duplicateCantidates.map((item, index) => {
            return <DuplicateCheckList index={index} inspection={inspection} item={item} handleViewReview={this.handleViewReview} />;
        });
        let isDuplicate = undefined;
        let isDuplicateMessage = undefined;
        if (inspection && currentInspectionContainer.inspection.duplicateCheck.duplicates != undefined) {
            if (currentInspectionContainer.inspection.duplicateCheck.duplicates.length > 0) {
                isDuplicateMessage =
                    strings('referenceNumberShort') +
                    ':' +
                    currentInspectionContainer.inspection.duplicateCheck.duplicates[0].refNumber +
                    '   ' +
                    strings('isDuplicate');

                if (
                    currentInspectionContainer.inspection.duplicateCheck.duplicates
                        .map(function(e) {
                            return e.refNumber || 0;
                        })
                        .indexOf(inspection.refNumber) != -1
                )
                    isDuplicate = true;
            } else isDuplicate = false;
        }

        return (
            <InspectionContainer {...this.props}>
                <View style={styles.container}>
                    <View style={{ height: 200 }}>
                        <ScrollView style={{ flex: 1 }}>{duplicateContents}</ScrollView>
                    </View>
                    {showDetails ? (
                        <DuplicateCheckReview
                            editable={editable}
                            isDuplicate={isDuplicate}
                            isDuplicateMessage={isDuplicateMessage}
                            optionSelectedNo={this.optionSelectedNo}
                            optionSelectedYes={this.optionSelectedYes}
                            inspection={inspection}
                            serviceCategory={serviceCategory}
                        />
                    ) : null}
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        currentInspectionContainer: currentInspectionContainer,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
    };
};
const connectedDuplicateCheck = connect(mapStateToProps)(DuplicateCheck);
export default screenWithSpinner(connectedDuplicateCheck, { theme: 'light' });
