import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { List, TouchableRipple, Divider, Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import images from 'app/images';
import styles from './styles';
class DuplicateCheckList extends React.PureComponent {
    static propTypes = {
        items: PropTypes.any,
    };

    render() {
        const { index, item, inspection, handleViewReview } = this.props;
        const rowStyles = [styles.row];
        const titleStyles = [styles.title];
        const descriptionStyles = [styles.descriptionTitle];
        const iconStyle = [];
        if (inspection && item.refNumber == inspection.refNumber) {
            rowStyles.push(styles.rowSelected);
            titleStyles.push(styles.titleSelected);
            descriptionStyles.push(styles.titleSelected);
            iconStyle.push(styles.iconSelected);
        }
        return (
            <View key={index}>
                <TouchableRipple onPress={() => handleViewReview(item)}>
                    <View>
                        <List.Item
                            style={rowStyles}
                            title={
                                <Text style={styles.listItemTitle}>
                                    {strings('referenceNumberShort')}: {item.refNumber}
                                </Text>
                            }
                            description={() => (
                                <Text style={styles.listItemDescription}>
                                    {strings('address')}: {item.location && item.location.address ? item.location.address.zone : ''}{' '}
                                    {item.info && item.info.generalInfo ? ', ' + strings('remarks') + ' : ' + item.info.generalInfo.remarks : ''}
                                </Text>
                            )}
                            titleStyle={titleStyles}
                            descriptionStyle={descriptionStyles}
                            left={props => <List.Icon {...props} style={styles.iconSelected} icon={images.review.content} />}
                            // right={props => (

                            // )}
                        />
                    </View>
                </TouchableRipple>
                <Divider />
            </View>
        );
    }
}

export default DuplicateCheckList;
