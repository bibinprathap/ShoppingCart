import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView } from 'react-native';
import { Button, Card, Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import { ReviewCategory } from 'app/screens/inspection/Review';
import styles from './styles';

export default function(props) {
    const { editable, isDuplicate, isDuplicateMessage, optionSelectedNo, optionSelectedYes, inspection, selectedWorkflowConst } = props;
    return (
        <ScrollView style={{ flex: 1 }}>
            <View style={{ margin: 5 }}>
                <Card>
                    <Card.Actions>
                        <View style={styles.horizontalView}>
                            <View style={styles.horizontalViewButton}>
                                <Button
                                    name="content-copy1"
                                    borderRadius={25}
                                    disabled={isDuplicate == false || editable == false}
                                    style={[
                                        styles.button,
                                        styles.optionButton,
                                        isDuplicate == false || editable == false
                                            ? [styles.optionButtonSelected, styles.buttonPositiveDisabled]
                                            : null,
                                    ]}
                                    onPress={optionSelectedNo}
                                >
                                    <Text style={styles.buttonText}>{strings('notDuplicate')}</Text>
                                </Button>
                                <View style={[styles.refnoContainer]}>
                                    <Text style={styles.ValidationMessageText}>
                                        {isDuplicate != false ? '' : strings('allare') + ' ' + strings('notDuplicate')}
                                    </Text>
                                </View>
                            </View>

                            <View style={styles.horizontalViewButton}>
                                <Button
                                    name="content-copy2"
                                    borderRadius={25}
                                    disabled={isDuplicate == true || editable == false}
                                    style={[
                                        styles.button,
                                        styles.optionButton,
                                        isDuplicate == true || editable == false
                                            ? [styles.optionButtonSelected, styles.buttonPositiveDisabled]
                                            : null,
                                    ]}
                                    onPress={optionSelectedYes}
                                >
                                    <Text style={styles.buttonText}>{strings('isDuplicate')}</Text>
                                </Button>
                                <Text style={styles.ValidationMessageText}>{isDuplicateMessage ? isDuplicateMessage : ''}</Text>
                            </View>
                        </View>
                    </Card.Actions>
                    <Card.Title title={strings('inspectionDetails')} subtitle={strings('referenceNumberShort') + ' : ' + inspection.refNumber} />
                    <Card.Content>
                        {inspection && (
                            <ReviewCategory
                                inspection={inspection}
                                selectedWorkflowConst={selectedWorkflowConst}
                                isSubmitable={() => {}}
                                isAllowedToSave={false}
                                validationErrors={{}}
                                currentInspectionVersion={0}
                            />
                        )}
                    </Card.Content>
                </Card>
            </View>
        </ScrollView>
    );
}
