import styles from './styles';
import DuplicateCheck from './DuplicateCheck';
import DuplicateCheckList from './DuplicateCheckList';
import DuplicateCheckReview from './DuplicateCheckReview';

export { styles, DuplicateCheck, DuplicateCheckList, DuplicateCheckReview };
