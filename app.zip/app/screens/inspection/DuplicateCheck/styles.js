import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryWhite',
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 10,
        padding: 10,
        borderRadius: 10,
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    rowSelected: {
        backgroundColor: '$primarySelectedItem',
    },
    titleSelected: {
        color: '$primaryWhite',
    },
    iconSelected: {
        tintColor: '$primaryWhite',
    },
    refnoContainer: {
        width: '100%',
        paddingLeft: 20,
    },
    generalHeading: {
        fontSize: '$primaryTextMD',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    generalText: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    listItemDescription: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 12,
    },
    listItemTitle: {
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        fontSize: 16,
    },
    yesButton: {
        marginTop: 8,
        height: '$globalButtonHeight',
        backgroundColor: '$primaryDarkButtonBackground',
    },
    noButton: {
        marginTop: 8,
        height: '$globalButtonHeight',
        backgroundColor: '$primaryNoButtonBackground',
    },
    title: {
        alignSelf: 'flex-start',
    },
    descriptionTitle: {
        alignSelf: 'flex-start',
    },
    horizontalView: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    horizontalViewButton: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    button: {
        marginHorizontal: 10,
        marginVertical: 20,
        borderWidth: 0,
        borderRadius: 5,
        backgroundColor: '$primaryLightButtonBackground',
    },
    optionButton: {
        flex: 1,
        //alignSelf: 'center',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    optionButtonSelectedYes: {
        backgroundColor: '$primaryYesButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    optionButtonSelectedNo: {
        backgroundColor: '$primaryNoButtonBackground',
    },
    optionButtonSelected: {
        color: '$primaryWhite',
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
});
