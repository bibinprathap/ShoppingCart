import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { BaseContainer } from 'app/components/BaseContainer';

class Inspection extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    render() {
        return (
            <BaseContainer {...this.props}>
                <Text>Build the inspection screen here with its own tab navigator</Text>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
    };
};

export default connect(mapStateToProps)(Inspection);
