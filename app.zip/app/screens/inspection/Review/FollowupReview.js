import React, { Component } from 'react';
import { View, Text, Dimensions, I18nManager, ScrollView, Animated, Easing } from 'react-native';

import Review from './Review';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import { strings } from 'app/config/i18n/i18n';
import FollowUpHeader from 'app/components/Header/FollowUpHeader';
import styles from './styles';

import { createStackNavigator, createAppContainer, createBottomTabNavigator, createMaterialTopTabNavigator } from 'react-navigation';
const currentLocale = I18nManager.isRTL ? 'ar' : 'en';

const FollowUpTopHeader = props => {
    const followupStackDefinition = {
        routes: [
            {
                key: 'visit1',
                screen: ({ navigation }) => <Review followupreview={true} visitindex={0} />,
                params: { visit: 1, followupreview: true, headerTitle: strings('visit1', { locale: currentLocale }) },
                title: strings('visit1', { locale: currentLocale }),
                tabBarLabel: strings('visit1', { locale: currentLocale }),
                icon: 'serviceSelection',
                iconType: 'custom',
            },
            {
                key: 'visit2',
                screen: ({ navigation }) => <Review followupreview={true} visitindex={0} />,
                params: { visit: 2, followupreview: true, headerTitle: strings('visit2', { locale: currentLocale }) },
                title: strings('visit2', { locale: currentLocale }),
                tabBarLabel: strings('visit2', { locale: currentLocale }),
                icon: 'serviceSelection',
                iconType: 'custom',
            },
            {
                key: 'visit3',
                screen: ({ navigation }) => <Review followupreview={true} visitindex={1} />,
                params: { visit: 3, followupreview: true, headerTitle: strings('visit3', { locale: currentLocale }) },
                title: strings('visit3', { locale: currentLocale }),
                tabBarLabel: strings('visit3', { locale: currentLocale }),
                icon: 'serviceSelection',
                iconType: 'custom',
            },
        ],
        initialRoute: 'visit1',
    };
    const routeConfig = {};
    followupStackDefinition.routes.map(item => {
        routeConfig[item.key] = {
            screen: item.screen,
            title: item.title,
            subtitle: item.subtitle,
            navigationOptions: ({ navigation }) => ({
                title: item.title,
                subtitle: item.subtitle,
            }),
            tabBarOptions: {
                scrollEnabled: true,
            },
        };
    });
    const FollowupStackNavigator = createAppContainer(
        createMaterialTopTabNavigator(routeConfig, {
            initialRouteName: followupStackDefinition.initialRoute,
            initialRouteName: followupStackDefinition.initialRoute,
            swipeEnabled: false,
            animationEnabled: false,
            lazy: true,
            tabBarPosition: 'top',
            transitionConfig: () => ({
                transitionSpec: {
                    duration: 0,
                },
            }),

            defaultNavigationOptions: {
                tabBarComponent: props => <FollowUpHeader {...props} />,
            },
        })
    );
    return (
        <ScrollView style={{ flex: 1 }}>
            <FollowupStackNavigator screenProps={followupStackDefinition.routes} />
        </ScrollView>
    );
};
export default FollowUpTopHeader;

// import * as React from 'react';
// import { View, StyleSheet, Dimensions } from 'react-native';
// import { TabView, SceneMap } from 'react-native-tab-view';

// const FirstRoute = () => <View style={[styles.scene, { height: 500, backgroundColor: '#ff4081' }]} />;

// const SecondRoute = () => <View style={[styles.scene, { height: 500, backgroundColor: '#673ab7' }]} />;

// export default class FollowupReview extends React.Component {
//     state = {
//         index: 0,
//         routes: [{ key: 'first', title: 'First' }, { key: 'second', title: 'Second' }],
//     };

//     render() {
//         return (
//             <TabView
//                 navigationState={this.state}
//                 renderScene={SceneMap({
//                     first: FirstRoute,
//                     second: SecondRoute,
//                 })}
//                 onIndexChange={index => this.setState({ index })}
//                 initialLayout={{ width: 500 }}
//             />
//         );
//     }
// }

// const styles = StyleSheet.create({
//     scene: {
//         flex: 1,
//     },
// });
