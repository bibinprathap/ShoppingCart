import React from 'react';

import { TabView, SceneMap } from 'react-native-tab-view';

import Review from './Review';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';

const FirstRoute = () => <Review followupreview={true} />;

const SecondRoute = () => <View style={[styles.scene, { backgroundColor: '#673ab7' }]} />;

class FollowupReview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            index: 0,
            routes: [{ key: 'first', title: 'First Visit' }, { key: 'second', title: 'Current Visit' }],
        };
    }
    render() {
        return (
            <View>
                <HeaderGeneric backAction={this.props.navigation.pop} title={'task Followup'} />
                <TabView
                    navigationState={this.state}
                    renderScene={SceneMap({
                        first: FirstRoute,
                        second: SecondRoute,
                    })}
                    onIndexChange={index => this.setState({ index })}
                    initialLayout={{ width: Dimensions.get('window').width }}
                />
            </View>
        );
    }
}
export default FollowupReview;
