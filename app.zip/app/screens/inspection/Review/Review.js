import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import { _ } from 'lodash';
import moment from 'moment';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { InspectionPreview } from 'app/components/Preview/InspectionPreview';
import { GeneralPreview } from 'app/components/Preview/GeneralPreview';
import { DistrotionPreview } from 'app/components/Preview/DistrotionPreview';
import EStyleSheet from 'react-native-extended-stylesheet';
import commonStyles from 'app/components/Preview/styles';
import LineIcons from 'react-native-vector-icons/SimpleLineIcons';
import { inspectionsHelper, liquidEngine, zebra } from 'app/api/helperServices';
import { saveNewInspection, checkDuplicate } from 'app/actions/inspections';
import { Loader } from 'app/components/Loader';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { receiptTemplate, testTemplate } from 'app/api/mockData';
import alertsHelper from 'app/api/helperServices/alerts';
import { getParsedTemplate } from 'app/api/helperServices';

//import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
const styles = EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    contentsContainer: {
        flex: 1,
        // justifyContent: 'flex-start',
        // alignItems: 'center',
        backgroundColor: '$primaryWhite',
        elevation: 2,
        marginVertical: 10,
        marginHorizontal: 10,
        //padding: 10,
        borderRadius: 10,
    },
    summaryContainer: {
        flex: 1,
        flexDirection: 'row',
        maxHeight: 80,
        width: '100%',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    summaryValue: {
        fontSize: '$primaryTextSM',
        maxWidth: 65,
    },
    summaryHeading: {
        fontSize: '$primaryTextXS',
    },
    actionsContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        maxHeight: 70,
        width: '100%',
    },
    actionItem: {
        marginHorizontal: 10,
    },
    button: {
        height: 50,
        width: 120,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonTextPositiveDisabled: {
        color: '$primaryWhite',
    },
    buttonNegative: {
        backgroundColor: '$primaryDarkBackground',
    },
    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
});

class Review extends Component {
    static propTypes = {
        currentInspectionVersion: PropTypes.any,
        currentInspectionContainer: PropTypes.object,
        services: PropTypes.array,
    };
    constructor(props) {
        super(props);
        this.state = { isAllowedToSave: false, validationErrors: {} };
    }

    componentWillUnmount() {
        if (this.zebraListener) {
          //  this.zebraListener.remove();
        }
        if (this.focusListener) {
            this.focusListener.remove();
        }
        // this.zebraListener.remove();
        this.focusListener.remove();
        if (this.connectTimer) {
            clearTimeout(this.connectTimer);
        }
    }

    componentDidMount() {
        const { navigation, dispatch, selectedService, editable } = this.props;
        let serviceCategory;
        if (selectedService) serviceCategory = inspectionsHelper.getServiceCategory(selectedService);

        this.focusListener = navigation.addListener('didFocus', () => {
            if (serviceCategory == 'INSPECTION' && editable == true) dispatch(checkDuplicate());
        });
    }

    zebraListener;
    connectTimer;

    isSubmitable = (submitable, err) => {
        if (submitable != this.state.isAllowedToSave || JSON.stringify(this.state.validationErrors) != JSON.stringify(err))
            this.setState({ isAllowedToSave: submitable, validationErrors: err });
    };

    handleSave = () => {
        const { inspection } = this.props.currentInspectionContainer;
        this.props.dispatch(saveNewInspection(inspection));
    };

    handleCancel = () => {
        // console.log('cancel pressed');
    };

    printReceipt = params => {
        if (this.state.isPrinting) {
            return;
        }
        if (this.zebraListener) {
            this.zebraListener.remove();
        }

        if (this.connectTimer) {
            clearTimeout(this.connectTimer);
        }

        this.zebraListener = zebra.addListener(res => {
            console.log('Printer events', res);
            if (res) {
                if (res.DISCONNECTED) {
                    this.setState({ isPrinterConnected: false });
                }

                if (res.CONNECT_ERROR) {
                    alertsHelper.show('error', 'Printer', strings('printerNotConnected'));
                }

                if (res.CONNECTED) {
                    this.setState({ isPrinterConnected: true });
                }
                if (res.PRINTING_START) {
                    this.setState({ isPrinting: true });
                }
                if (res.PRINTING_ENDS) {
                    this.setState({ isPrinting: false });
                }
                if (res.PRINTER_NO_PAPER) {
                    alertsHelper.show('error', 'Printer', strings('printerNoPaper'));
                    this.setState({ isPrinting: false });
                }
            }
        });

        const { selectedPrinter } = this.props.settings;
        if (selectedPrinter && selectedPrinter.address) {
            zebra.disconnect();
        }

        const { selectedService } = this.props;
        const { inspection } = this.props.currentInspectionContainer;

        let serviceCategoryType = inspectionsHelper.getServiceCategory(selectedService);
        if (serviceCategoryType === 'INSPECTION') {
            if (selectedService && selectedService.inspectionDef && selectedService.inspectionDef.type == 'checklist') {
                serviceCategoryType = 'INSPECTION_CHECKLIST';
            }
        }
        if (!serviceCategoryType) return;

        const test = true;
        if (test) {
            if (this.state.isPrinterConnected) {
                zebra.print(testTemplate);
            } else {
                zebra.connect(selectedPrinter.address);
                this.connectTimer = setTimeout(() => {
                    if (this.state.isPrinterConnected) {
                        zebra.print(testTemplate);
                    }
                }, 2000);
            }
            return;
        }

        getParsedTemplate(this.props.printTemplate, serviceCategoryType, { ...params, inspection }).then(console.log);
        return;

        if (selectedPrinter && selectedPrinter.address && this.props.printTemplate) {
            console.log('this.state.isPrinterConnected', this.state.isPrinterConnected);
            getParsedTemplate(this.props.printTemplate, serviceCategoryType, { ...params, inspection }).then(zplInvoiceData => {
                if (this.state.isPrinterConnected) {
                    zebra.print(zplInvoiceData);
                } else {
                    zebra.connect(selectedPrinter.address);
                    this.connectTimer = setTimeout(() => {
                        if (this.state.isPrinterConnected) {
                            zebra.print(zplInvoiceData);
                        }
                    }, 2000);
                }
            });
        } else {
            alertsHelper.show('error', 'Printer', 'Printer is not connected');
        }
    };

    render() {
        const { inspection } = this.props.currentInspectionContainer;
        const { selectedService, inspections, currentInspectionVersion, editable } = this.props;
        const { isAllowedToSave, validationErrors } = this.state;
        let serviceCategory;
        if (selectedService) serviceCategory = inspectionsHelper.getServiceCategory(selectedService);
        const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const saveTextstyle = isAllowedToSave && editable == true ? styles.buttonText : styles.buttonTextPositiveDisabled;
        let showPrintButton = true;
        if (!serviceCategory) {
            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.ADMMapViewContainer}>
                        <View style={styles.unknownServiceSelection}>
                            <Text style={styles.unknownServiceHeading}>No service selected, for Review</Text>
                        </View>
                    </View>
                </InspectionContainer>
            );
        } else {
            let content = undefined;
            if (serviceCategory === 'INSPECTION') {
                if (selectedService && selectedService.inspectionDef && selectedService.inspectionDef.type == 'checklist') {
                    showPrintButton = false;
                    content = (
                        <InspectionPreview
                            inspection={inspection}
                            isSubmitable={this.isSubmitable}
                            isAllowedToSave={isAllowedToSave}
                            dispatch={this.props.dispatch}
                            editable={editable}
                            inspectionValidationLogs={validationErrors}
                            currentInspectionVersion={currentInspectionVersion}
                            isPrinting={this.state.isPrinting}
                            printReceipt={this.printReceipt}
                        />
                    );
                } else {
                    content = (
                        <GeneralPreview
                            inspection={inspection}
                            isSubmitable={this.isSubmitable}
                            isAllowedToSave={isAllowedToSave}
                            dispatch={this.props.dispatch}
                            editable={editable}
                            inspectionValidationLogs={validationErrors}
                            currentInspectionVersion={currentInspectionVersion}
                            printReceipt={this.printReceipt}
                            isPrinting={this.state.isPrinting}
                        />
                    );
                }
            } else if (serviceCategory === 'DISTORTION') {
                content = (
                    <DistrotionPreview
                        inspection={inspection}
                        isSubmitable={this.isSubmitable}
                        isAllowedToSave={isAllowedToSave}
                        distrotionValidationLogs={validationErrors}
                        currentInspectionVersion={currentInspectionVersion}
                    />
                );
                showPrintButton = false;
            } else {
            }

            return (
                <InspectionContainer {...this.props}>
                    <View style={styles.container}>
                        <View style={styles.contentsContainer}>
                            {content}
                            <Divider style={styles.divider} />
                            <View style={styles.summaryContainer}>
                                <View style={styles.summaryItem}>
                                    <Loader loading={inspections.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                                        <Icon.Button
                                            name="save"
                                            borderRadius={25}
                                            disabled={!isAllowedToSave || !editable}
                                            style={[styles.button, saveButtonstyle]}
                                            onPress={this.handleSave}
                                        >
                                            <Text style={saveTextstyle}>{strings('save')}</Text>
                                        </Icon.Button>
                                    </Loader>
                                </View>
                                <View style={styles.summaryItem}>
                                    <Icon.Button
                                        name="cancel"
                                        borderRadius={25}
                                        style={[styles.button, styles.buttonNegative]}
                                        onPress={this.handleCancel}
                                    >
                                        <Text style={styles.buttonText}>{strings('cancel')}</Text>
                                    </Icon.Button>
                                </View>
                                {showPrintButton ? (
                                    <View style={styles.summaryItem}>
                                        <Icon.Button
                                            name="print"
                                            borderRadius={25}
                                            style={[styles.button, styles.buttonPositive]}
                                            onPress={() => this.printReceipt({})}
                                        >
                                            <Loader loading={this.state.isPrinting} sprinnerSize={14}>
                                                <Text style={styles.buttonText}>{strings('print')}</Text>
                                            </Loader>
                                        </Icon.Button>
                                    </View>
                                ) : null}
                            </View>

                            <View />
                        </View>
                    </View>
                </InspectionContainer>
            );
        }
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    let selectedService = undefined;
    if (
        state.masterdata.services &&
        currentInspectionContainer &&
        currentInspectionContainer.inspection &&
        currentInspectionContainer.inspection.service
    ) {
        selectedService = _.find(state.masterdata.services, { serviceId: currentInspectionContainer.inspection.service });
    }

    return {
        currentInspectionVersion: state.inspections.currentInspectionVersion,
        currentInspectionContainer: currentInspectionContainer,
        selectedService: selectedService,
        inspections: state.inspections,
        settings: state.settings,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
        printTemplate: state.masterdata && state.masterdata.printTemplate,
    };
};

const connectedReview = connect(mapStateToProps)(Review);
export default screenWithSpinner(connectedReview, { theme: 'light' });
