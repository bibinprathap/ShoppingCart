import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { inspectionsHelper } from 'app/api/helperServices';
import { InspectionPreview } from 'app/components/Preview/InspectionPreview';
import { DistrotionPreview } from 'app/components/Preview/DistrotionPreview';
import { GeneralPreview } from 'app/components/Preview/GeneralPreview';

class ReviewCategory extends React.PureComponent {
    static propTypes = {
        inspection: PropTypes.any,
        isSubmitable: PropTypes.func,
        isAllowedToSave: PropTypes.any,
        inspectionValidationLogs: PropTypes.any,
        currentInspectionVersion: PropTypes.any,
    };
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        const { inspection, serviceCategory, isSubmitable, isAllowedToSave, validationErrors, currentInspectionVersion } = this.props;
        if (serviceCategory === 'INSPECTION') {
            const selectedVisitIndex = inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            if (inspectionDefinition.type == 'form')
                return (
                    <GeneralPreview
                        inspection={inspection}
                        isSubmitable={isSubmitable}
                        isAllowedToSave={isAllowedToSave}
                        inspectionValidationLogs={validationErrors}
                        currentInspectionVersion={currentInspectionVersion}
                    />
                );
            else
                return (
                    <InspectionPreview
                        inspection={inspection}
                        isSubmitable={isSubmitable}
                        isAllowedToSave={isAllowedToSave}
                        inspectionValidationLogs={validationErrors}
                        currentInspectionVersion={currentInspectionVersion}
                    />
                );
        } else if (serviceCategory === 'DISTORTION') {
            return (
                <DistrotionPreview
                    inspection={inspection}
                    isSubmitable={isSubmitable}
                    isAllowedToSave={isAllowedToSave}
                    distrotionValidationLogs={validationErrors}
                    currentInspectionVersion={currentInspectionVersion}
                />
            );
        }
        return <View />;
    }
}
export default ReviewCategory;
