import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { inspectionsHelper } from 'app/api/helperServices';
import { InspectionPreview } from 'app/components/Preview/InspectionPreview';
import { DistrotionPreview } from 'app/components/Preview/DistrotionPreview';
import { GeneralPreview } from 'app/components/Preview/GeneralPreview';
export default function(props) {
    const { inspection, selectedWorkflowConst, isSubmitable, isAllowedToSave, validationErrors, currentInspectionVersion } = props;
    if (selectedWorkflowConst != 'MimsDistortion') {
        const selectedVisitIndex = inspection.visits.length - 1;
        const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
        const inspectionDefinition = selectedVisit && selectedVisit.def;
        if (inspectionDefinition.type == 'form')
            return (
                <GeneralPreview
                    inspection={inspection}
                    isSubmitable={isSubmitable}
                    isAllowedToSave={isAllowedToSave}
                    inspectionValidationLogs={validationErrors}
                    currentInspectionVersion={currentInspectionVersion}
                />
            );
        else
            return (
                <InspectionPreview
                    inspection={inspection}
                    isSubmitable={isSubmitable}
                    isAllowedToSave={isAllowedToSave}
                    inspectionValidationLogs={validationErrors}
                    currentInspectionVersion={currentInspectionVersion}
                />
            );
    } else if (selectedWorkflowConst === 'MimsDistortion') {
        return (
            <DistrotionPreview
                inspection={inspection}
                isSubmitable={isSubmitable}
                isAllowedToSave={isAllowedToSave}
                distrotionValidationLogs={validationErrors}
                currentInspectionVersion={currentInspectionVersion}
            />
        );
    }
    return <View />;
}
