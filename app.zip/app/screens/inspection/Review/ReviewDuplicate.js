import React, { Component } from 'react';

import { _ } from 'lodash';
import { View, ScrollView, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';

import { screenWithSpinner } from 'app/components/WithSpinner';
import { ReviewCategory } from 'app/screens/inspection/Review';
//import { LargeThumbnail } from 'app/components/Thumbnail';

import styles from './styles';

const captureImageQuality = 1; //todo: take this from config/ store
const includeBase64 = false;
class ReviewDuplicate extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    componentDidMount() {
        const inspection = this.props.navigation.getParam('inspection');
        const serviceCategory = this.props.navigation.getParam('serviceCategory');
        const currentInspectionVersion = this.props.navigation.getParam('currentInspectionVersion');

        this.setState({
            inspection,
            serviceCategory,
            currentInspectionVersion,
        });
    }

    handleOnClose = () => {
        //Todo: do any cleanup etc before closing this screen
        const { onClose } = this.state;
        if (onClose) onClose();
        this.props.navigation.pop();
    };

    render() {
        //Todo: if there are no exising attachments, open the camera without waiting for user to click on the button
        const { inspection, serviceCategory, currentInspectionVersion } = this.state;
        return (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.scrollContainer}>
                <View style={styles.container}>
                    <View style={styles.previewContainer}>
                        {inspection && (
                            <ReviewCategory
                                inspection={inspection}
                                serviceCategory={serviceCategory}
                                isSubmitable={() => {}}
                                isAllowedToSave={false}
                                validationErrors={{}}
                                currentInspectionVersion={currentInspectionVersion}
                            />
                        )}
                    </View>
                </View>
            </ScrollView>
        );
    }
}

mapStateToProps = (state, ownProps) => {};

const connectedReviewDuplicate = connect(mapStateToProps)(ReviewDuplicate);
export default screenWithSpinner(connectedReviewDuplicate, { theme: 'light' });
