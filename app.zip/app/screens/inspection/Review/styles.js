import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryWhite',
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 10,
        padding: 10,
        borderRadius: 10,
    },
    styles: {
        flex: 1,
    },
});
