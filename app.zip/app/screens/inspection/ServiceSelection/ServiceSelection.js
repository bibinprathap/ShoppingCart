import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ActivityIndicator, Image, Picker } from 'react-native';
import { withNavigationFocus } from 'react-navigation';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { ADMMapView } from 'app/components/ADMMapView';
import { ADMGISMapView } from 'app/components/ADMGISMapView';
import { ServiceSelector } from 'app/components/ServiceSelector';
import { selectService, coordsChanged, addressChanged } from 'app/actions/inspections';
import { getLocation } from 'app/api/helperServices/geolocation';
import { inspectionsHelper } from 'app/api/helperServices';
import AppApi from 'app/api/real';
const api = new AppApi();
import styles from './styles';
import { shallowEqual } from 'app/api/helperServices';

class ServiceSelection extends Component {
    constructor(props) {
        super(props);
        this.state = { showMap: true, lastPoint: 'nothing' };
    }

    static propTypes = {
        services: PropTypes.array,
        currentInspectionContainer: PropTypes.object,
    };

    handleOnServiceSelected = selection => {
        if (this.props.editable && this.props.serviceEditable) this.props.dispatch(selectService(selection));
    };

    handleCoordsChanged = async coords => {
        if (this.props.editable) {
            this.props.dispatch(coordsChanged(coords));
            try {
                const address = await api.getAddress(coords);
                this.props.dispatch(addressChanged(address));
            } catch (error) {
                console.log('error in api.getAddress. ', error);
            }
        }
    };
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    componentDidUpdate(prevProps) {
        // this.setState({ lastPoint: 'componentDidUpdate' });
        // if (prevProps.isFocused !== this.props.isFocused) {
        //     if (this.props.isFocused) {
        //         this.setState({ showMap: true });
        //     } else {
        //         this.setState({ showMap: false });
        //     }
        // }
    }

    async componentDidMount() {
        const { location } = this.props.currentInspectionContainer.inspection;
        // // console.log('location123', location);
        if (!(location && location.coords)) {
            try {
                const currentLocation = await getLocation();
                console.log('currentLocation', currentLocation);
                await this.handleCoordsChanged(currentLocation);
            } catch (error) {
                console.log('getLocation error: ', error);
            }
        }
    }

    handleOnSingleTap = async points => {
        if (this.props.editable) {
            const tappedCoords = points.mapPoint;
            await this.handleCoordsChanged(tappedCoords);
        }
    };

    render() {
        //console.warn('Service Selection Rendating' + Math.random());
        // console.log('ServiceSelect.render() props -->');
        // console.log(this.props);
        const { services, currentInspectionContainer, editable, serviceEditable } = this.props;
        const { service } = currentInspectionContainer.inspection;
        const { location } = currentInspectionContainer.inspection;
        const coords = location && location.coords;
        const { checked } = this.state;
        console.log('location', location, checked);
        console.log('coords', coords);

        if (!services || services.length == 0) {
            return (
                //Todo: manage styles properly
                <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                    <ActivityIndicator />
                    <Text>Services masterdata loading...</Text>
                </View>
            );
        }

        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];

        console.log('placeMarkData', JSON.stringify(placeMarkData));
        return (
            <InspectionContainer {...this.props}>
                {/* <View>
                    <RadioButton.Group onValueChange={value => this.setState({ value })} value={this.state.value}>
                        <View>
                            <Text>First</Text>
                            <RadioButton value="first" color="#0000ff" uncheckedColor="#000000" />
                        </View>
                        <View>
                            <Text>Second</Text>
                            <RadioButton value="second" color="#0000ff" uncheckedColor="#000000" />
                        </View>
                    </RadioButton.Group>
                </View> */}
                <View style={styles.ADMMapViewContainer}>
                    {/* {this.state.showMap ? <ADMGISMapView /> : null} */}
                    {/* coords={location && location.coords} placeMarks={placeMarkData} */}
                    {coords ? (
                        <>
                            {/* <Text>{JSON.stringify(Image.resolveAssetSource(require('app/images/normalpoint.png')), null, 4)}</Text> */}
                            <ADMGISMapView
                                coords={coords}
                                placeMarks={placeMarkData}
                                //layers={['sectors']}
                                //basemap="DARK_GRAY"
                                onSingleTap={this.handleOnSingleTap}
                                showMenu={true}
                            />
                        </>
                    ) : null}
                </View>
                <View style={styles.ServiceSelectorContainer}>
                    <ServiceSelector
                        editable={editable && serviceEditable}
                        services={services}
                        selectedService={service}
                        onServiceSelected={this.handleOnServiceSelected}
                    />
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        services: state.masterdata.services,
        currentInspectionContainer: currentInspectionContainer,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
        serviceEditable: inspectionsHelper.getIsServiceEditable(currentInspectionContainer),
    };
};

const connectedServiceSelection = connect(mapStateToProps)(withNavigationFocus(ServiceSelection));
export default screenWithSpinner(connectedServiceSelection, { theme: 'light' });
