import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, ActivityIndicator } from 'react-native';
import { withNavigationFocus } from 'react-navigation';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { ADMMapView } from 'app/components/ADMMapView';
import ADMGISMapView from 'app/components/ADMGISMapView/ADMGISMapView';
import { ServiceSelector } from 'app/components/ServiceSelector';
import { selectService, coordsChanged, addressChanged } from 'app/actions/inspections';
import { getLocation } from 'app/api/helperServices/geolocation';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';

class ServiceSelection extends Component {
    constructor(props) {
        super(props);
        this.state = { showMap: true };
        //Todo: remove the two timeouts below. its a workaround for testing till ADMMapView starts working on emulator
        // setTimeout(() => {
        //     this.handleCoordsChanged({
        //         latitude: 24.486775,
        //         longitude: 54.378501,
        //     });
        // }, 2000);

        // setTimeout(() => {
        //     this.handleAddressChanged({
        //         zone: 11,
        //         sector: 22,
        //         plot: 33,
        //     });
        // }, 2500);
    }

    static propTypes = {
        services: PropTypes.array,
        currentInspectionContainer: PropTypes.object,
    };

    handleOnServiceSelected = selection => {
        if (this.props.editable && this.props.serviceEditable) this.props.dispatch(selectService(selection));
    };

    handleCoordsChanged = data => {
        if (this.props.editable) this.props.dispatch(coordsChanged(data));
    };

    handleAddressChanged = data => {
        if (this.props.editable) this.props.dispatch(addressChanged(data));
    };

    componentDidUpdate(prevProps) {
        if (prevProps.isFocused !== this.props.isFocused) {
            if (this.props.isFocused) {
                this.setState({ showMap: true });
            } else {
                this.setState({ showMap: false });
            }
        }
    }

    getCurrentLocation = async () => {
        console.log('getCurrentLocation: _lastEvent: ');
        try {
            const currentLocation = await getLocation();
            console.log('getCurrentLocation success. calling handler', currentLocation);
            const data = { latitude: currentLocation.latitude, longitude: currentLocation.longitude };
            this.handleCoordsChanged(data);
        } catch (error) {
            console.log('getLocation error: ', error);
        }
    };

    componentDidMount() {
        // console.log('arcgisMap componentDidMount');
        const { location } = this.props.currentInspectionContainer.inspection;

        // console.log('location123', location);

        if (typeof location !== 'undefined') {
            console.log(location.coords.latitude + '    ' + location.coords.longitude);
        } else {
            // console.log('location undefined');
            this.getCurrentLocation();
        }
    }
    render() {
        // console.log('ServiceSelect.render() props -->');
        // console.log(this.props);
        const { services, currentInspectionContainer, editable, serviceEditable } = this.props;
        const { service } = currentInspectionContainer.inspection;
        const { location } = currentInspectionContainer.inspection;
        const coords = location && location.coords;
        //   console.log('location', location);

        if (!services || services.length == 0) {
            return (
                //Todo: manage styles properly
                <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                    <ActivityIndicator />
                    <Text>Services masterdata loading...</Text>
                </View>
            );
        }
        return (
            <InspectionContainer {...this.props}>
                <View style={styles.ADMMapViewContainer}>
                    {/* <ADMMapView onCoordinateschanged={this.handleCoordsChanged} onAddressChanged={this.handleAddressChanged} /> */}
                    {/* location={coords} */}
                    {this.state.showMap ? (
                        <ADMGISMapView
                            editable={editable}
                            location={coords}
                            onCoordinateschanged={this.handleCoordsChanged}
                            onAddressChanged={this.handleAddressChanged}
                        />
                    ) : null}
                </View>
                <View style={styles.ServiceSelectorContainer}>
                    <ServiceSelector
                        editable={editable && serviceEditable}
                        services={services}
                        selectedService={service}
                        onServiceSelected={this.handleOnServiceSelected}
                    />
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        services: state.masterdata.services,
        currentInspectionContainer: currentInspectionContainer,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
        serviceEditable: inspectionsHelper.getIsServiceEditable(currentInspectionContainer),
    };
};

const connectedServiceSelection = connect(mapStateToProps)(withNavigationFocus(ServiceSelection));
export default screenWithSpinner(connectedServiceSelection, { theme: 'light' });
