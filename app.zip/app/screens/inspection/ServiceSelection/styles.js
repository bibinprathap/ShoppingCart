import EStyleSheet, { absoluteFill } from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    ADMMapViewContainer: {
        flex: 1,
    },
    ServiceSelectorContainer: {
        position: 'absolute',
        bottom: 0,
        flex: 1,
        width: '100%',
    },
    actionPicker: { height: 50, width: '100%', flex: 1, justifyContent: 'flex-start', alignSelf: 'flex-start' },
});
