import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ScrollView, Picker, Alert } from 'react-native';
import { connect } from 'react-redux';
import { Button } from 'react-native-paper';

import { _ } from 'lodash';
import {
    infoChanged,
    inspectionViolatorAdded,
    violatorInfoChanged,
    inspectionViolationsupdated,
    infoViolatorChanged,
    inspectionRemoveViolator,
} from 'app/actions/inspections';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { createForm, IndividualInfoForm, BuildingInfoForm, CompanyInfoForm, GeneralInfoForm } from 'app/components/Form';
import { styles as fieldStyles, Switch } from 'app/components/InputControls';
import { ReconciliationPreview } from 'app/components/Reconciliation';
import { IconAndLabel } from 'app/components/InputControls';
import { strings } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import styles from './styles';
import { CustomAccordion } from 'app/components/CustomAccordion';
import { inspectionsHelper } from 'app/api/helperServices';
import { LawclauseList } from 'app/components/LawclauseList';
import { withNavigationFocus } from 'react-navigation';
import Icon from 'react-native-vector-icons/MaterialIcons';
import alertsHelper from 'app/api/helperServices/alerts';
import { shallowEqual } from 'app/api/helperServices';
import { setLoading, setLoaded } from 'app/actions/loader';
const AddViolatorButton = ({ editable, violationsTypeoptions, handleAddViolation, stickyFooter }) => {
    handleOnpress = () => {
        handleAddViolation(violationsTypeoptions, null);
    };
    return (
        <View style={stickyFooter ? [styles.violatorPickerTopContainer, styles.stickyButton] : styles.violatorPickerTopContainer}>
            <Icon.Button name="add" disabled={!editable} borderRadius={25} style={styles.violatorButtonContainer} onPress={this.handleOnpress}>
                <Text style={styles.buttonText}>{strings('addviolation')}</Text>
            </Icon.Button>
        </View>
    );
};

const AddViolatorPicker = ({ editable, violationsTypeoptions, handleAddViolation, stickyFooter, handlescrollToEnd }) => {
    handleOnChange = (itemValue, itemIndex) => {
        handleAddViolation(null, itemValue);
        handlescrollToEnd();
        //  this.scrollTimout = setTimeout(() => this.scrollViewElm.scrollToEnd({ animated: true }), 300);
    };
    return (
        <View style={stickyFooter ? [styles.violatorPickerTopContainer, styles.stickyButton] : styles.violatorPickerTopContainer}>
            <View style={[styles.violatorButtonContainer, styles.violatorButtonRounded]}>
                <Icon name="add" size={35} style={styles.addIcon} />
                <Picker selectedValue="" enabled={editable} style={styles.violatorPicker} onValueChange={this.handleOnChange}>
                    <Picker.Item style={styles.violatorPickerItems} value="" label={strings('addviolation')} />
                    {violationsTypeoptions &&
                        violationsTypeoptions.map((v, i) => {
                            return <Picker.Item style={styles.violatorPickerItems} key={i} label={strings(v)} value={v} />;
                        })}
                </Picker>
            </View>
        </View>
    );
};

class ViolatorDetails extends Component {
    static propTypes = {
        currentInspectionContainer: PropTypes.object,
        services: PropTypes.array,
    };

    constructor(props) {
        super(props);
        this.state = {
            //Todo: get these values from the selected/ current inspection

            awarenessGiven: false,
            reconciliationDetail: { reconciled: false, stickyFooter: false },
        };
        this.handleAddViolation = this.handleAddViolation.bind(this);
        this.getViolatorTypePicker = this.getViolatorTypePicker.bind(this);
        this.formProps = {};
        this.updateContentHeight = this.updateContentHeight.bind(this);
    }
    scrollViewElm;
    scrollTimout;
    formProps;
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleInfoChange = (values, dispatch, props, previousValues) => {
        this.props.dispatch(infoChanged(props.form, values));
    };

    handlescrollToEnd = () => {
        this.scrollTimout = setTimeout(() => this.scrollViewElm.scrollToEnd({ animated: true }), 300);
    };
    componentDidUpdate(prevProps) {
        if (prevProps.isFocused !== this.props.isFocused) {
            if (this.props.isFocused) {
                const { navigation, dispatch, selectedService } = this.props;
                if (selectedService.inspectionDef && selectedService.inspectionDef.type == 'form' && selectedService.violatorType) {
                    const primaryViolatorstype = selectedService.violatorType.split(',')[0];
                    const { inspection } = this.props.currentInspectionContainer || {};
                    if (primaryViolatorstype && (!inspection.info || !inspection.info.violators || inspection.info.violators.length == 0)) {
                        dispatch(inspectionViolatorAdded(primaryViolatorstype, selectedService.violationTypeIds));
                    }
                }
            }
        }
    }

    componentWillUnmount() {
        if (this.scrollTimout) {
            clearTimeout(this.scrollTimout);
        }
    }
    handleVisitInfoChange = (values, dispatch, props, previousValues) => {
        const { inspection } = this.props.currentInspectionContainer || {};
        const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        this.props.dispatch(infoChanged(props.form, values, currentVisitIndex));
    };
    handleAddViolation = (violationsTypeoptions, selectedViolatortype) => {
        if (selectedViolatortype == '') return;
        this.props.dispatch(setLoading());
        // Auto assigning law clause to violator
        const { currentInspectionContainer, selectedService } = this.props;
        const { inspection } = currentInspectionContainer;
        const { info } = inspection;
        let violationTypeIds = [];
        if (!selectedService.violationTypeIds) {
            const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
            const currentVisitCheckListValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].values : undefined;
            const violationsOptions = inspectionsHelper.getViolationsOptionsByViolatorsType({
                selectedService: selectedService,
                def: selectedService.inspectionDef.def,
                checklist: currentVisitCheckListValues,
                violatorType: selectedViolatortype,
                parentViolatorType: selectedViolatortype,
            });

            let assignedViolationIds = [];
            if (info.violators && info.violators.length > 0) {
                info.violators.map((violator, index) => {
                    if (violator && violator.violations) {
                        assignedViolationIds = [...assignedViolationIds, ...violator.violations];
                    }
                });
            }
            if (violationsOptions.length > 0) {
                _.map(violationsOptions, opt => {
                    if (assignedViolationIds.indexOf(opt.id) === -1) violationTypeIds.push(opt.id);
                });
            }
        } else {
            violationTypeIds = selectedService.violationTypeIds;
        }
        // Auto assigning law clause to violator - code ends here

        if (selectedViolatortype) {
            this.props.dispatch(inspectionViolatorAdded(selectedViolatortype, violationTypeIds));
            this.setState({ violatorType: selectedViolatortype });
        } else {
            let nextViolatorType = undefined;
            if (violationsTypeoptions.length > 0) {
                nextViolatorType = violationsTypeoptions[0];
            }
            if (nextViolatorType) this.props.dispatch(inspectionViolatorAdded(nextViolatorType, violationTypeIds));
        }
        setTimeout(() => {
            this.props.dispatch(setLoaded());
        }, 3000);
    };

    handleRemoveViolation = identifier => {
        Alert.alert('Delete Violator', 'Do you want to delete Violator?', [
            { text: 'NO', onPress: () => console.log('NO Pressed'), style: 'cancel' },
            {
                text: 'YES',
                onPress: () => {
                    this.props.dispatch(setLoading());
                    setTimeout(() => {
                        this.props.dispatch(setLoaded());
                    }, 3000);
                    this.props.dispatch(inspectionRemoveViolator(identifier));
                },
            },
        ]);
    };
    handleViolationInfoChange = (values, dispatch, props, previousValues, parentProps) => {
        this.props.dispatch(infoViolatorChanged(parentProps.storeName, values, parentProps.identifier));
    };

    handleViolatorPresence = (value, violator) => {
        this.handleViolationInfoChange(value, null, { form: 'violations' }, null, {
            identifier: violator.UIIdentifier,
            storeName: 'violatorIsPresent',
        });
        if (value == true && violator.ticketRecipient)
            this.handleViolationInfoChange(undefined, null, { form: 'violations' }, null, {
                identifier: violator.UIIdentifier,
                storeName: 'ticketRecipient',
            });
        else {
            this.handleViolationInfoChange({}, null, { form: 'violations' }, null, {
                identifier: violator.UIIdentifier,
                storeName: 'ticketRecipient',
            });
        }

        //this.setState({ violatorPresence: value });
    };

    handleAwarenessCheck = value => {
        this.setState({ awarenessGiven: value });
    };

    handleReconciliationChange = value => {
        console.log(`handleReconciliationChange(value): ${JSON.stringify(value)}`);
    };
    renderViolatorsTitle = props => {
        const { violatordetails, identifier, violationsTypeoptions, editable } = props;

        return (
            <View style={styles.violatorContainer}>
                <View style={styles.violatorTitleContainer}>
                    <Text style={styles.title}>
                        {inspectionsHelper.getViolatorHeading({
                            text: strings('violator'),
                            violatorType: props.violatordetails.violatorType,
                            violatordetails: violatordetails,
                            identifier,
                        })}
                    </Text>
                </View>
                {editable ? (
                    <View style={styles.violatorRemoveContainer}>
                        <Icon.Button
                            identifier={identifier}
                            size={30}
                            disabled={!editable}
                            name="delete"
                            borderRadius={25}
                            style={[styles.button, styles.violatorRemove]}
                            onPress={(e, props) => this.handleRemoveViolation(identifier)}
                        >
                            <Text style={styles.buttonText}>{strings('removeviolation')}</Text>
                        </Icon.Button>
                    </View>
                ) : null}
            </View>
        );
    };

    getViolatorTypePicker = (selectedServiceType, violationsTypeoptions, editable) => {
        if (!editable || violationsTypeoptions.length == 0) return null;
        else if (violationsTypeoptions.length < 2)
            return (
                <AddViolatorButton
                    selectedServiceType={selectedServiceType}
                    handleAddViolation={this.handleAddViolation}
                    violationsTypeoptions={violationsTypeoptions}
                    editable={editable}
                    stickyFooter={this.state.stickyFooter}
                />
            );
        else
            return (
                <AddViolatorPicker
                    selectedServiceType={selectedServiceType}
                    handleAddViolation={this.handleAddViolation}
                    violationsTypeoptions={violationsTypeoptions}
                    editable={editable}
                    stickyFooter={this.state.stickyFooter}
                    handlescrollToEnd={this.handlescrollToEnd}
                />
            );
    };
    getViolatorsFormsAndControls = (selectedService, info, checklistValues, awarenessGiven, reconciliationDetail, editable, flashOn) => {
        let inputFormsAndControls = [];
        if (selectedService && selectedService.inspectionDef) {
            const violationsTypeoptions = inspectionsHelper.getDistinctViolatorstype({
                checklist: checklistValues,
                def: selectedService.inspectionDef.def,
                parentViolatorType: selectedService.violatorType,
            });

            const customFieldContainerStyles = [fieldStyles.fieldContainer, fieldStyles.fieldContainerShadowed, styles.customFieldRowContainer];
            if (info.violators && info.violators.length > 0) {
                info.violators.map((violator, index) => {
                    let violatorPresence = violator.violatorIsPresent;
                    const violationsOptions = inspectionsHelper.getViolationsOptionsByViolatorsType({
                        selectedService: selectedService,
                        def: selectedService.inspectionDef.def,
                        checklist: checklistValues,
                        violatorType: violator.violatorType,
                        parentViolatorType: selectedService.violatorType,
                    });
                    const selectedViolations = (violator.violations || []).filter(v => violationsOptions.find(o => o.id == v));
                    if (selectedViolations.length != (violator.violations || []).length)
                        this.props.dispatch(inspectionViolationsupdated(selectedViolations, index));

                    let assignedViolationIds = [];
                    if (info.violators && info.violators.length > 0) {
                        info.violators.map(violatorObj => {
                            if (violatorObj && violatorObj.violations && violatorObj.UIIdentifier !== violator.UIIdentifier) {
                                assignedViolationIds = [...assignedViolationIds, ...violatorObj.violations];
                            }
                        });
                    }

                    const violationsOptionsUnassigned = violationsOptions.filter(o => assignedViolationIds.indexOf(o.id) === -1);

                    switch (violator.violatorType) {
                        case 'company':
                            inputFormsAndControls.push(
                                <React.Fragment key={violator.UIIdentifier}>
                                    <CustomAccordion
                                        index={index}
                                        editable={editable}
                                        renderHeaderTitle={this.renderViolatorsTitle}
                                        violatordetails={violator}
                                        violationsTypeoptions={violationsTypeoptions}
                                        identifier={violator.UIIdentifier}
                                        expandedAtStart={true}
                                    >
                                        <LawclauseList
                                            multiSelect
                                            editable={editable}
                                            violationTypeIds={violationsOptionsUnassigned || []}
                                            violators={info.violators}
                                            selectedItems={selectedViolations}
                                            onValueChange={(itemValue, itemIndex) =>
                                                this.handleViolationInfoChange(itemValue, null, { form: 'violations' }, null, {
                                                    identifier: violator.UIIdentifier,
                                                    storeName: 'violations',
                                                })
                                            }
                                        />
                                        <CompanyInfoForm
                                            editable={editable}
                                            formProps={this.formProps}
                                            formName={violator.UIIdentifier + 'company'}
                                            storeName="company"
                                            onFormChange={this.handleViolationInfoChange}
                                            identifier={violator.UIIdentifier}
                                            values={violator.company}
                                            dispatch={this.props.dispatch}
                                        />
                                        <IndividualInfoForm
                                            editable={editable}
                                            formProps={this.formProps}
                                            formName={violator.UIIdentifier + 'ticketRecipient'}
                                            formTitle={strings('ticketRecipient')}
                                            storeName="ticketRecipient"
                                            onFormChange={this.handleViolationInfoChange}
                                            identifier={violator.UIIdentifier}
                                            values={violator.ticketRecipient}
                                            flashOn={flashOn}
                                            dispatch={this.props.dispatch}
                                        />
                                    </CustomAccordion>
                                </React.Fragment>
                            );
                            break;
                        case 'building':
                            inputFormsAndControls.push(
                                <React.Fragment key={violator.UIIdentifier}>
                                    <CustomAccordion
                                        editable={editable}
                                        index={index}
                                        renderHeaderTitle={this.renderViolatorsTitle}
                                        violatordetails={violator}
                                        identifier={violator.UIIdentifier}
                                        expandedAtStart={true}
                                    >
                                        <LawclauseList
                                            multiSelect
                                            editable={editable}
                                            violationTypeIds={violationsOptionsUnassigned || []}
                                            violators={info.violators}
                                            identifier={violator.UIIdentifier}
                                            selectedItems={selectedViolations}
                                            onValueChange={(itemValue, itemIndex) =>
                                                this.handleViolationInfoChange(itemValue, null, { form: 'violations' }, null, {
                                                    identifier: violator.UIIdentifier,
                                                    storeName: 'violations',
                                                })
                                            }
                                        />

                                        <BuildingInfoForm
                                            editable={editable}
                                            formProps={this.formProps}
                                            storeName="building"
                                            formName={violator.UIIdentifier + 'building'}
                                            onFormChange={this.handleViolationInfoChange}
                                            identifier={violator.UIIdentifier}
                                            values={violator.building}
                                        />
                                        <IndividualInfoForm
                                            editable={editable}
                                            formProps={this.formProps}
                                            formName={violator.UIIdentifier + 'ticketRecipient'}
                                            storeName="ticketRecipient"
                                            formTitle={strings('ticketRecipient')}
                                            onFormChange={this.handleViolationInfoChange}
                                            identifier={violator.UIIdentifier}
                                            values={violator.ticketRecipient}
                                            flashOn={flashOn}
                                            dispatch={this.props.dispatch}
                                        />
                                    </CustomAccordion>
                                </React.Fragment>
                            );
                            break;
                        case 'individual':
                            inputFormsAndControls.push(
                                <React.Fragment key={violator.UIIdentifier}>
                                    <CustomAccordion
                                        editable={editable}
                                        index={index}
                                        renderHeaderTitle={this.renderViolatorsTitle}
                                        violatordetails={violator}
                                        identifier={violator.UIIdentifier}
                                        expandedAtStart={true}
                                    >
                                        <LawclauseList
                                            multiSelect
                                            editable={editable}
                                            violationTypeIds={violationsOptionsUnassigned || []}
                                            violators={info.violators}
                                            identifier={violator.UIIdentifier}
                                            selectedItems={selectedViolations}
                                            onValueChange={(itemValue, itemIndex) =>
                                                this.handleViolationInfoChange(itemValue, null, { form: 'violations' }, null, {
                                                    identifier: violator.UIIdentifier,
                                                    storeName: 'violations',
                                                })
                                            }
                                        />
                                        <IndividualInfoForm
                                            editable={editable}
                                            formProps={this.formProps}
                                            storeName="violator"
                                            formName={violator.UIIdentifier + 'violator'}
                                            formTitle={strings('violator')}
                                            onFormChange={this.handleViolationInfoChange}
                                            identifier={violator.UIIdentifier}
                                            values={violator.violator}
                                            flashOn={flashOn}
                                            dispatch={this.props.dispatch}
                                        />
                                        <View style={customFieldContainerStyles}>
                                            <Switch
                                                editable={editable}
                                                onChange={value => this.handleViolatorPresence(value, violator)}
                                                value={violatorPresence}
                                                label={strings('violatorIsPresent')}
                                                iconProps={{ icon: 'face', iconType: 'default' }}
                                            />
                                        </View>
                                        {!!violatorPresence && (
                                            <View style={customFieldContainerStyles}>
                                                <ReconciliationPreview
                                                    editable={editable}
                                                    violatorIdentifier={violator.UIIdentifier}
                                                    values={{ reconciled: !!violator.signature, signature: violator.signature }}
                                                    onChange={this.handleReconciliationChange}
                                                    dispatch={this.props.dispatch}
                                                    navigation={this.props.navigation}
                                                />
                                            </View>
                                        )}
                                        {!violatorPresence && (
                                            <IndividualInfoForm
                                                editable={editable}
                                                formProps={this.formProps}
                                                identifier={violator.UIIdentifier}
                                                storeName="ticketRecipient"
                                                formName={violator.UIIdentifier + 'ticketRecipient'}
                                                formTitle={strings('ticketRecipient')}
                                                onFormChange={this.handleViolationInfoChange}
                                                values={violator.ticketRecipient}
                                                flashOn={flashOn}
                                                dispatch={this.props.dispatch}
                                            />
                                        )}
                                    </CustomAccordion>
                                </React.Fragment>
                            );
                            break;
                        default:
                            inputFormsAndControls.push(
                                <Text key={violator.UIIdentifier}>Todo: handle the unknown violator type: {violator.violatorType}</Text>
                            );
                    }
                });
            }
        }
        return inputFormsAndControls;
    };

    updateContentHeight = (width, height) => {
        this.setState({ stickyFooter: height > 800 });
    };

    render() {
        // console.warn('ViolatorDetails rerender' + Math.random());
        const { awarenessGiven, reconciliationDetail } = this.state;
        const { currentInspectionContainer, selectedService, editable, flashOn } = this.props;
        const { inspection } = currentInspectionContainer;
        const currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;
        if (!selectedService) return this.noServiceSelected();

        const values = inspection.info || {};
        const currentVisitCheckListValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].values : undefined;
        let inputFormsAndControls = this.getViolatorsFormsAndControls(
            selectedService,
            values,
            currentVisitCheckListValues,
            awarenessGiven,
            reconciliationDetail,
            editable,
            flashOn
        );
        const currentVisitGeneralInfoValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].generalInfo : undefined;
        const selectedServiceType = selectedService.inspectionDef.type;
        const violationsTypeoptions =
            selectedService.inspectionDef.type == 'checklist'
                ? inspectionsHelper.getDistinctViolatorstype({
                      checklist: currentVisitCheckListValues,
                      def: selectedService.inspectionDef.def,
                      parentViolatorType: selectedService.violatorType,
                  })
                : selectedService.violatorType && selectedService.violatorType.split(',');
        const violatorTypePicker = this.getViolatorTypePicker(selectedServiceType, violationsTypeoptions, editable);

        return (
            <InspectionContainer {...this.props}>
                <View style={styles.container}>
                    <ScrollView style={{ flex: 1 }} ref={ref => (this.scrollViewElm = ref)} onContentSizeChange={this.updateContentHeight}>
                        <GeneralInfoForm
                            formName="generalInfo"
                            editable={editable}
                            //formTitle={strings('violator')}
                            onFormChange={this.handleVisitInfoChange}
                            values={currentVisitGeneralInfoValues}
                        />
                        {inputFormsAndControls}
                        {!this.state.stickyFooter && violatorTypePicker}
                    </ScrollView>
                    {this.state.stickyFooter && violatorTypePicker}
                </View>
            </InspectionContainer>
        );
    }
    noServiceSelected() {
        return (
            <InspectionContainer {...this.props}>
                <View style={styles.container}>
                    <Text>No service selected. Todo: handle gracefully</Text>
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    let selectedService = undefined;
    if (
        state.masterdata.services &&
        currentInspectionContainer &&
        currentInspectionContainer.inspection &&
        currentInspectionContainer.inspection.service
    ) {
        selectedService = _.find(state.masterdata.services, { serviceId: currentInspectionContainer.inspection.service });
    }
    return {
        currentInspectionContainer: currentInspectionContainer,
        selectedService: selectedService,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
        currentInspectionVersion: state.inspections.currentInspectionVersion,
        flashOn: state.settings.flashOn,
    };
};
const connectedViolatorDetails = connect(mapStateToProps)(withNavigationFocus(ViolatorDetails));
export default screenWithSpinner(connectedViolatorDetails, { theme: 'light' });
