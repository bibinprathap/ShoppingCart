import styles from './styles';
import ViolatorDetails from './ViolatorDetails';

export { styles, ViolatorDetails };
