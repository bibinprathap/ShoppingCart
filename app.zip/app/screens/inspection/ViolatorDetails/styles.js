
import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
  container: {
    flex: 1,
    //flexDirection: 'row',
    //alignItems: 'flex-start',
    //justifyContent: 'center',
    backgroundColor: '$primaryLightBackground',
  },
  sideNavContainer: {
    flex: 1,
    borderColor: '$primaryBorderColor',
    borderEndWidth: '$primaryBorderThin',
  },
  contentsContainer: {
    flex: 8,
    backgroundColor: '$primaryWhite',
    elevation: 2,
    marginVertical: 20,
    marginHorizontal: 30,
    borderRadius: 10,
  },
  customFieldRowContainer: {
    marginTop: 20,
    marginBottom: 5,
  },
  violatorContainer: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '$primaryLightBackground',
  },
  violatorPickerContainer: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '$primaryLightBackground',
    borderWidth:0.751173,
    borderRadius:4,
    borderColor:'$primaryBorderColor',
    marginHorizontal:5
  },
  violatorPicker:{ height:50,
width:'80%',
color:"white",
  },
  title: {
    fontSize: '$primaryTextLG',
    color: '$primaryDarkTextColor',
    marginStart: 10,
    alignSelf: 'flex-start',
},
violatorButton: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
},
violatorPickerTopContainer:{
  flex: 1,
  flexDirection:'row'
},
violatorPickerContainer: {
  flex: 2,
  justifyContent: 'center',
  alignItems: 'center',
  flexDirection:'row',
  backgroundColor:"$primaryLightButtonBackground",
  borderRadius:25
},
addIcon:{
  color:"white"
}
,violatorTitleContainer: {
  flex: 5,
  justifyContent: 'center',
  alignItems: 'center',
},violatorRemoveContainer: {
  flex: 1,
  alignItems :'flex-start'
  },violatorRemove: {
padding:2,
marginLeft:8 
}
, buttonText: {
  fontSize: '$primaryTextMD',
  color: '$primaryWhite',
},
    labelContainer: {
        flex:1,
        justifyContent: 'center',
        alignSelf: 'center',
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal:5
    },
});
