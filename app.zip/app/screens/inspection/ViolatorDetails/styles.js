import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        //flexDirection: 'row',
        //alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
        paddingBottom: 70,
    },
    sideNavContainer: {
        flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 8,
        backgroundColor: '$primaryWhite',
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 30,
        borderRadius: 10,
    },
    customFieldRowContainer: {
        marginTop: 20,
        marginBottom: 5,
    },
    violatorContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
    },
    violatorPicker: { height: 40, width: '80%', color: 'white', fontFamily: '$primaryFontNormal', fontSize: '$primaryTextSM' },
    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
        alignSelf: 'flex-start',
    },

    violatorPickerTopContainer: {
        height: 60,
        //paddingVertical: 10,
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
    },
    stickyButton: {
        position: 'absolute',
        bottom: 0,
    },
    violatorButtonContainer: {
        flexDirection: 'row',
        backgroundColor: '$primaryLightButtonBackground',
        borderWidth: 0.751173,
        borderColor: '$primaryDividerDarkColor',
        paddingHorizontal: 15,
    },
    violatorButtonRounded: {
        borderRadius: 25,
        marginHorizontal: 5,
        width: 230,
    },
    violatorPickerItems: {
        width: 200,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
    },
    addIcon: {
        color: 'white',
    },
    violatorTitleContainer: {
        flex: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
    violatorRemoveContainer: {
        flex: 1,
        alignItems: 'flex-start',
    },
    violatorRemove: {
        padding: 2,
        marginLeft: 8,
    },
    buttonText: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        color: '$primaryWhite',
        alignSelf: 'center',
    },
    labelContainer: {
        flex: 1,
        justifyContent: 'center',
        alignSelf: 'center',
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
    },
});
