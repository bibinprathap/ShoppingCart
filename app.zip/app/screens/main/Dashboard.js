import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity, LayoutAnimation, Image } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Portal, Button, Provider, Dialog, TouchableHighlight } from 'react-native-paper';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { mainStackDefinition } from 'app/config/routs/defs';
import { authLogout } from 'app/actions/auth';
import { DashboardHistory } from 'app/components/DashboardHistory';
import { TaskHistory } from 'app/components/TaskHistory';
import EStyleSheet from 'react-native-extended-stylesheet';
import DashboardChart from 'app/components/DashboardCharts/AdmChart/DashboardChart';
import InspectionPlanView from 'app/components/InspectionPlanView/InspectionPlanView';
import FollowUpTopHeader from 'app/components/Header/FollowUpTopHeader';
import { FollowupReview } from 'app/screens/inspection/Review';
import images from 'app/images';
import { inspectionsHelper } from 'app/api/helperServices';
import {
    selectService,
    createNewInspectionFromTask,
    createInspectionRecordFromTask,
    selectServiceFromTask,
    selectInspection,
    selectInspectionSuccess,
    addNextVisit,
} from 'app/actions/inspections';
import AppApi from 'app/api/real';
const api = new AppApi();

/* uncomment below lines to test gisApi */

// import AppApi from 'app/api/real';
// import { replaceFieldNames } from 'app/api/real';
// const api = new AppApi();

/* uncomment above lines to test gisApi */

class Dashboard extends Component {
    state = {
        visible: false,
        selectedDashboardTab: 'history',
        expanded: true,
        dashboardNavExpanded: true,
        loading: false,
        // dashboardChartsData: this.props.dashboardChartsData,
        // count:  this.props.dashboardChartsData.length,
        followupModalVisible: false,
        selectedInspection: null,
    };

    static propTypes = {
        isRtl: PropTypes.bool,
    };
    currentRouteName = this.props.navigation.state.routeName;
    breadCrumbs = [{ key: 'dashboard', title: strings('dashboard'), selected: true }];

    toggleFollowupDialog = () => {
        this.setState({ followupModalVisible: !this.state.followupModalVisible });
    };

    handleSideNavOnPress = item => {
        console.log(`Dashboard.handleSideNavOnPress(${item.key})`);
        if (item.key === 'logout') {
            this.props.dispatch(authLogout());
            this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
        } else {
            this.props.navigation.navigate(item.key);
        }
    };
    showHistory = (inspection, item) => {
        const visitsLength = inspection.inspection.visits.length;
        if (visitsLength > 1) {
            const currentInspection = inspection.inspection;
            //
            //selectedTask: null,
            this.setState(
                {
                    selectedInspection: inspection,
                    selectedTask: {
                        parentRefNo: currentInspection.refNumber,
                        selectedService: currentInspection.service,
                        assignedToInspectorId: currentInspection.createdByDomainCustomerId,
                    },
                },
                () => {
                    this.props.dispatch(selectInspection(currentInspection.refNumber));
                    this.toggleFollowupDialog();
                }
            );
        } else {
            inspectionsHelper.selectInspection(item, this.props.navigation);
        }
    };

    handleHistorySelection = item => {
        const inspections = this.props.inspectionsHistory;
        const inspection = inspections[item] || null;
        this.showHistory(inspection, item);
    };
    onSourceInspectionClick = () => {
        console.log('onSourceInspectionClick' + this.state.selectedTask.parentRefNo);
    };
    onCreatedInspectionClick = () => {
        console.log('onCreatedInspectionClick' + this.state.selectedTask.refNumber);
    };
    handleStartTaskSelection = async item => {
        console.log('handleStartTaskSelection');
        if (this.state.selectedTask.stepAction && this.state.selectedTask.stepAction == 'followup') {
            // apicall for checking is i assigned for this user
            //inspectionsHelper.selectInspectionFollowup(this.state.selectedTask.parentRefNo, this.props.navigation);
            const inspections = this.props.inspectionsHistory;
            const inspection = inspections[this.state.selectedTask.parentRefNo] || null;
            try {
                if (inspection) {
                    this.props.dispatch(selectInspection(this.state.selectedTask.parentRefNo));
                } else {
                    const result = await api.getInspection(this.state.selectedTask.parentRefNo);
                    result.inspection['refNumber'] = this.state.selectedTask.parentRefNo;
                    this.props.dispatch(selectInspectionSuccess(result));
                }
                const visitsLength = inspection.inspection.visits.length;
                if (visitsLength > 0 && !(inspection.inspection.visits[visitsLength - 1].type == this.state.selectedTask.stepAction)) {
                    this.props.dispatch(
                        addNextVisit({
                            stepAction: this.state.selectedTask.stepAction,
                            duedate: this.state.selectedTask.deadlineToDate,
                            assignedToInspectorId: this.state.selectedTask.assignedToInspectorId,
                            taskId: this.state.taskId,
                        })
                    );
                }
                //show modal
                this.toggleFollowupDialog();
            } catch (e) {}
        } else if (!this.state.selectedTask.refNumber) {
            const history = this.props.inspectionsHistory;
            // const existingInspection = Object.keys(history).find(i => history[i].inspection && history[i].inspection.taskId == this.state.taskId);

            //create New Inspection task
            this.props
                .dispatch(createNewInspectionFromTask(this.state.taskId, this.state.selectedTask.selectedService, this.state.selectedTask.location))
                .then(sk => {
                    const taskService = this.props.services.find(s => s.serviceId == this.state.selectedTask.selectedService);
                    this.props
                        .dispatch(
                            selectServiceFromTask({
                                serviceId: this.state.selectedTask.selectedService,
                                inspectionDef: taskService.inspectionDef,
                            })
                        )
                        .then(st => {
                            this.props.dispatch(createInspectionRecordFromTask(this.state.taskId, this.props.currentInspectionRef));
                            inspectionsHelper.selectInspection(this.props.currentInspectionRef, this.props.navigation);
                        });
                });
        } else {
            // pull inspection from server and add to history
        }
        //pull tInspection and add tohistory
        //showtaskinthehistory
        //  inspectionsHelper.selectInspection(this.state.selectedTask, this.props.navigation);
        //this.props.dispatch(selectInspection(item));
        //this.props.navigation.navigate('inspection');
    };

    handleTaskHistorySelection = (task, taskId) => {
        this.setState({ selectedTask: task, taskId, selectedInspection: null });
    };

    handleDashboardNavChanged = (selectedDashboardTab, dashboardNavExpanded, navigationPressedTime) => {
        this.setState({ selectedDashboardTab, navigationPressedTime, dashboardNavExpanded });
    };

    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    };

    renderDashboardContent = () => {
        switch (this.state.selectedDashboardTab) {
            case 'history':
                return (
                    <>
                        <View>
                            <TouchableOpacity
                                activeOpacity={0.8}
                                onPress={this.changeLayout}
                                style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}
                            >
                                <Image
                                    source={this.state.expanded ? images.chartCollapse.content : images.chartExpand.content}
                                    style={{ width: 15, height: 15, margin: 10 }}
                                />
                                <Text>{this.state.expanded ? strings('hideCharts') : strings('showCharts')}</Text>
                            </TouchableOpacity>

                            <View style={{ marginHorizontal: 10, height: this.state.expanded ? null : 0 }}>
                                <ScrollView horizontal={true}>
                                    <View style={styles.chartContainer}>
                                        <DashboardChart />
                                    </View>
                                </ScrollView>
                            </View>
                        </View>
                        <View style={styles.contentsHistoryContainer}>
                            <Text style={styles.historyHeading}>{strings('historyDescription')}</Text>
                            <DashboardHistory onSelect={this.handleHistorySelection} />
                        </View>
                    </>
                );

            case 'inspectionPlan':
                return <InspectionPlanView />;
            case 'tasks':
                return (
                    <View style={styles.contentsHistoryContainer}>
                        <TaskHistory
                            onStartClick={this.handleStartTaskSelection}
                            taskdetails={this.state.selectedTask}
                            onSelect={this.handleTaskHistorySelection}
                            onSourceInspectionClick={this.onSourceInspectionClick}
                            onCreatedInspectionClick={this.onCreatedInspectionClick}
                            navigationPressedTime={this.state.navigationPressedTime}
                            dashboardNavExpanded={this.state.dashboardNavExpanded}
                        />
                    </View>
                );
            case 'overdue':
                return (
                    <View style={styles.contentsHistoryContainer}>
                        <TaskHistory
                            showOverdue={true}
                            onStartClick={this.handleStartTaskSelection}
                            taskdetails={this.state.selectedTask}
                            onSelect={this.handleTaskHistorySelection}
                            onSourceInspectionClick={this.onSourceInspectionClick}
                            onCreatedInspectionClick={this.onCreatedInspectionClick}
                            navigationPressedTime={this.state.navigationPressedTime}
                            dashboardNavExpanded={this.state.dashboardNavExpanded}
                        />
                    </View>
                );
            default:
                <View style={{ flex: 1 }}>
                    <Text>Unknown dashboard content</Text>
                </View>;
        }
    };

    async testGisAPI() {
        //console.log('testGisAPI()');
        //zoneId 35 = Abu Dhabi Island
        //sectorId: 302 = E16 (Al Zahiya)
        // const zones = await api.getZones({ zoneId: 35, municipalityCode: 'ADM' });
        // console.log('zones: ', zones);
        // const sectors = await api.getSectors({ sectorId: 302, zoneId: 35, municipalityCode: 'ADM' });
        // console.log('sectors: ', sectors);
        // const plots = await api.getPlots({ sectorId: 302, zoneId: 35 });
        // console.log('plots: ', plots);
        // const replacedSectorFields = replaceFieldNames(1, 'out', ['sectorId', 'sectorNameE']);
        // console.log('replacedSectorFields: ', replacedSectorFields);
        // const replacedZoneFields = replaceFieldNames(2, 'out', ['zonePopularNameE', 'municipalityCode', 'asdasd']);
        // console.log('replacedZoneFields: ', replacedZoneFields);
        // const replacedPlotFields = replaceFieldNames(0, 'in', ['COMMUNITYARA', 'DISTRICTENG', 'asdasd']);
        // console.log('replacedPlotFields: ', replacedPlotFields);
        // const multiplePlots = await api.getPlotsCustom(35, 302, ['BT02', 'BT03', 'BT04']);
        // console.log('multiplePlots: ', multiplePlots);
    }
    render() {
        const { selectedDashboardTab } = this.state;

        this.testGisAPI();
        let currentInspectionRefNumber = this.state.selectedInspection ? this.state.selectedInspection.refNumber : '';
        let currentSelectedService = this.state.selectedInspection ? this.state.selectedInspection.service : '';
        const inspectionRefnumber =
            this.state.selectedTask && this.state.selectedTask.parentRefNo ? this.state.selectedTask.parentRefNo : currentInspectionRefNumber;
        return (
            <BaseContainer {...this.props}>
                <Modal animationType="slide" transparent={false} visible={this.state.followupModalVisible} onRequestClose={this.toggleFollowupDialog}>
                    <FollowUpTopHeader
                        backAction={this.toggleFollowupDialog}
                        currentInspection={inspectionRefnumber}
                        service={
                            this.state.selectedTask && this.state.selectedTask.selectedService
                                ? this.state.selectedTask.selectedService
                                : currentSelectedService
                        }
                        services={this.props.services}
                        title={strings('followup')}
                    />
                    <FollowupReview
                        inspection={this.props.inspectionsHistory[inspectionRefnumber] || null}
                        {...this.props}
                        taskdetails={this.state.selectedTask}
                        requestClose={this.toggleFollowupDialog}
                        activeProfileDomainCustomerId={this.props.activeProfileDomainCustomerId}
                    />
                </Modal>
                <View style={{ flex: 1 }}>
                    <SearchBar breadCrumbs={this.breadCrumbs} />
                    <View style={styles.container}>
                        <View style={[styles.sideNavContainer, { height: '100%' }]}>
                            <SideNav
                                routes={mainStackDefinition.routes}
                                onPress={this.handleSideNavOnPress}
                                currentRouteName={this.currentRouteName}
                                onDashboardNavChanged={this.handleDashboardNavChanged}
                                showDashboardMenu={true}
                                navigationPressedTime={this.state.navigationPressedTime}
                                selectedDashboardTab={selectedDashboardTab}
                            />
                        </View>
                        <View style={styles.contentsContainer}>{this.renderDashboardContent()}</View>
                    </View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        currentInspectionRef: state.inspections.currentInspectionRef,
        inspectionsHistory: state.inspections.history,
        services: state.masterdata.services,
        isRtl: state.settings.isRtl,
        activeProfileDomainCustomerId: state.auth && state.auth.activeProfileDomainCustomerId,
    };
};

const connectedDashboard = connect(mapStateToProps)(Dashboard);
export default screenWithSpinner(connectedDashboard, { theme: 'light' });

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    contentsHistoryContainer: {
        flex: 1,
        margin: 10,
        paddingBottom: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    historyHeading: {
        color: '$primaryDarkTextColor',
        fontSize: '$primaryTextSM',
        marginVertical: 10,
        marginStart: 10,
    },
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
        height: 250,
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
});
