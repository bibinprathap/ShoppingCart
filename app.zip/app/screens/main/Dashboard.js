import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Portal, Button, Provider, Dialog, TouchableHighlight } from 'react-native-paper';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { DashboardNav } from 'app/components/DashboardNav';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { mainStackDefinition } from 'app/config/routs/defs';
import { authLogout } from 'app/actions/auth';
import { selectInspection } from 'app/actions/inspections';
import { DashboardHistory } from 'app/components/DashboardHistory';
import EStyleSheet from 'react-native-extended-stylesheet';
import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';

import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import Settings from 'app/screens/main/Settings';

class Dashboard extends Component {
    state = {
        visible: false,
        settingsModalVisible: false,
    };

    static propTypes = {
        isRtl: PropTypes.bool,
    };
    currentRouteName = this.props.navigation.state.routeName;
    breadCrumbs = [{ key: 'dashboard', title: strings('dashboard'), selected: true }];

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };

    handleSideNavOnPress = item => {
        console.log(`Dashboard.handleSideNavOnPress(${item.key})`);
        if (item.key === 'logout') {
            this.props.dispatch(authLogout());
            this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
        }
        if (item.key === 'settings') {
            this.toggleSettingsDialog();
        } else this.props.navigation.navigate(item.key);
    };

    handleHistorySelection = item => {
        this.props.dispatch(selectInspection(item));
        this.props.navigation.navigate('inspection');
    };

    render() {
        return (
            <BaseContainer {...this.props}>
                <Modal animationType="slide" transparent={false} visible={this.state.settingsModalVisible} onRequestClose={this.toggleSettingsDialog}>
                    <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                    <Settings {...this.props} requestClose={this.toggleSettingsDialog} />
                </Modal>
                <View style={{ flex: 1 }}>
                    <SearchBar breadCrumbs={this.breadCrumbs} />
                    <View style={styles.container}>
                        <View style={styles.sideNavContainer}>
                            <SideNav
                                routes={mainStackDefinition.routes}
                                onPress={this.handleSideNavOnPress}
                                currentRouteName={this.currentRouteName}
                            />
                        </View>
                        <View style={styles.dashboardNavContainer}>
                            <DashboardNav />
                        </View>

                        <View style={styles.contentsRightContainer}>
                            <ScrollView horizontal={true}>
                                <View style={styles.chartContainer}>
                                    <AdmChart />
                                </View>
                            </ScrollView>
                            <View style={styles.contentsRightContainer2}>
                                <DashboardHistory onSelect={this.handleHistorySelection} />
                            </View>
                        </View>
                    </View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
    };
};

const connectedDashboard = connect(mapStateToProps)(Dashboard);
export default screenWithSpinner(connectedDashboard, { theme: 'light' });

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        //justifyContent: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        //flex: 1,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',

        width: '$sideNavWidth',
        minWidth: '$sideNavWidth',
        maxWidth: '$sideNavWidth',

        //minWidth: 120, width: '15%', height: '100%',
    },
    dashboardNavContainer: {
        //flex: 2,
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',

        width: '$dashboardNavWidth',
        minWidth: '$dashboardNavWidth',
        maxWidth: '$dashboardNavWidth',

        //minWidth: 250, width: '30%', height: '100%',
    },
    contentsScrollContainer: {
        flex: 1,
        // width: '$mainContentWidth',
        // minWidth: '$mainContentWidth',
        // maxWidth: '$mainContentWidth',

        marginVertical: 5,
        marginHorizontal: 5,
        //padding: 5,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
    },
    contentsRightContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
        borderColor: '$primaryBorderColor',
    },
    contentsRightContainer1: {
        flex: 2,
        margin: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    contentsRightContainer2: {
        flex: 3,
        margin: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    chartContainer: {
        width: 1000,
        justifyContent: 'space-between',
        backgroundColor: '$primaryWhite',
        borderColor: '$primaryBorderColor',
        elevation: 1,
        borderRadius: 10,
        margin: 10,
    },

    chartBox: {
        flex: 1,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    Dialog: {
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'stretch',
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
});
