import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity, LayoutAnimation, Image } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Portal, Button, Provider, Dialog, TouchableHighlight } from 'react-native-paper';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { mainStackDefinition } from 'app/config/routs/defs';
import { authLogout } from 'app/actions/auth';
import { DashboardHistory } from 'app/components/DashboardHistory';
import { TaskHistory } from 'app/components/TaskHistory';
import EStyleSheet from 'react-native-extended-stylesheet';
import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';
import InspectionPlanView from 'app/components/InspectionPlanView/InspectionPlanView';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import FollowUpTopHeader from 'app/components/Header/FollowUpTopHeader';
import Settings from 'app/screens/main/Settings';
import { FollowupReview } from 'app/screens/inspection/Review';
import images from 'app/images';
import { inspectionsHelper } from 'app/api/helperServices';
import {
    selectService,
    createNewInspectionFromTask,
    createInspectionRecordFromTask,
    selectServiceFromTask,
    selectInspection,
    selectInspectionSuccess,
    addNextVisit,
} from 'app/actions/inspections';
import AppApi from 'app/api/real';
const api = new AppApi();

/* uncomment below lines to test gisApi */

// import AppApi from 'app/api/real';
// import { replaceFieldNames } from 'app/api/real';
// const api = new AppApi();

/* uncomment above lines to test gisApi */

class Dashboard extends Component {
    state = {
        visible: false,
        settingsModalVisible: false,
        selectedDashboardTab: 'history',
        expanded: true,
        dashboardNavExpanded: true,
        loading: false,
        dashboardChartsData: this.props.dashboardChartsData,
        count: 0,
        //this.props.dashboardChartsData.length,
        followupModalVisible: false,
    };

    static propTypes = {
        isRtl: PropTypes.bool,
    };
    currentRouteName = this.props.navigation.state.routeName;
    breadCrumbs = [{ key: 'dashboard', title: strings('dashboard'), selected: true }];

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };
    toggleFollowupDialog = () => {
        this.setState({ followupModalVisible: !this.state.followupModalVisible });
    };

    handleSideNavOnPress = item => {
        console.log(`Dashboard.handleSideNavOnPress(${item.key})`);
        if (item.key === 'logout') {
            this.props.dispatch(authLogout());
            this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
        }
        if (item.key === 'settings') {
            this.toggleSettingsDialog();
        } else this.props.navigation.navigate(item.key);
    };
    showHistory = (inspection,item)=>
    {
           const visitsLength = inspection.inspection.visits.length;
           if (visitsLength > 1 ) {
            this.setState({selectedTask:{parentRefNo:item,selectedService:inspection.inspection.service}},()=>{
                this.toggleFollowupDialog();
            });
            }
            else
            {
                inspectionsHelper.selectInspection(item, this.props.navigation);
            }
    }

    handleHistorySelection = item => {
        const inspections = this.props.inspectionsHistory;
        const inspection = inspections[item] || null;
        try {
            if (!inspection) {
                const result = await api.getInspection(item);
                this.props.dispatch(selectInspectionSuccess(result));
            }
            this.showHistory(inspection,item);
        } catch (e) {

        }
    };
    onSourceInspectionClick = () => {
        console.log('onSourceInspectionClick' + this.state.selectedTask.parentRefNo);
    };
    onCreatedInspectionClick = () => {
        console.log('onCreatedInspectionClick' + this.state.selectedTask.refNumber);
    };
    handleStartTaskSelection = async item => {
        console.log('handleStartTaskSelection');
        if (this.state.selectedTask.stepAction && this.state.selectedTask.stepAction == 'followup') {
            // apicall for checking is i assigned for this user
            //inspectionsHelper.selectInspectionFollowup(this.state.selectedTask.parentRefNo, this.props.navigation);
            const inspections = this.props.inspectionsHistory;
            const inspection = inspections[this.state.selectedTask.parentRefNo] || null;
            try {
                if (inspection) {
                    this.props.dispatch(selectInspection(this.state.selectedTask.parentRefNo));
                } else {
                    const result = await api.getInspection(this.state.selectedTask.parentRefNo);
                    result.inspection['refNumber'] = this.state.selectedTask.parentRefNo;
                    this.props.dispatch(selectInspectionSuccess(result));
                }
                const visitsLength = inspection.inspection.visits.length;
                if (visitsLength > 0 && !(inspection.inspection.visits[visitsLength - 1].type == this.state.selectedTask.stepAction)) {
                    this.props.dispatch(addNextVisit({ stepAction: this.state.selectedTask.stepAction }));
                }
                //show modal
                this.toggleFollowupDialog();
            } catch (e) {}
        } else if (!this.state.selectedTask.refNumber) {
            const history = this.props.inspectionsHistory;
            // const existingInspection = Object.keys(history).find(i => history[i].inspection && history[i].inspection.taskId == this.state.taskId);

            //create New Inspection task
            this.props
                .dispatch(createNewInspectionFromTask(this.state.taskId, this.state.selectedTask.selectedService, this.state.selectedTask.location))
                .then(sk => {
                    const taskService = this.props.services.find(s => s.serviceId == this.state.selectedTask.selectedService);
                    this.props
                        .dispatch(
                            selectServiceFromTask({
                                serviceId: this.state.selectedTask.selectedService,
                                inspectionDef: taskService.inspectionDef,
                            })
                        )
                        .then(st => {
                            this.props.dispatch(createInspectionRecordFromTask(this.state.taskId, this.props.currentInspectionRef));
                            inspectionsHelper.selectInspection(this.props.currentInspectionRef, this.props.navigation);
                        });
                });
        } else {
            // pull inspection from server and add to history
        }
        //pull tInspection and add tohistory
        //showtaskinthehistory
        //  inspectionsHelper.selectInspection(this.state.selectedTask, this.props.navigation);
        //this.props.dispatch(selectInspection(item));
        //this.props.navigation.navigate('inspection');
    };

    handleTaskHistorySelection = (task, taskId) => {
        this.setState({ selectedTask: task, taskId });
    };

    handleDashboardNavChanged = (selectedDashboardTab, dashboardNavExpanded, navigationPressedTime) => {
        this.setState({ selectedDashboardTab, navigationPressedTime, dashboardNavExpanded });
    };

    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    };

    renderChartContent = () => {
        var myloop = [];
        var { dashboardChartsData, count } = this.state;

        for (let i = 0; i < count; i++) {
            myloop.push(
                <View key={i}>
                    <View style={styles.chartBox}>{<View>{/* <AdmChart chartData={dashboardChartsData[i]} chartSeq={i} /> */}</View>}</View>
                </View>
            );
        }
        return myloop;
    };

    renderDashboardContent = () => {
        switch (this.state.selectedDashboardTab) {
            case 'history':
                return (
                    <>
                        <View>
                            <TouchableOpacity
                                activeOpacity={0.8}
                                onPress={this.changeLayout}
                                style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}
                            >
                                <Image
                                    source={this.state.expanded ? images.chartCollapse.content : images.chartExpand.content}
                                    style={{ width: 15, height: 15, margin: 10 }}
                                />
                                <Text>{this.state.expanded ? strings('hideCharts') : strings('showCharts')}</Text>
                            </TouchableOpacity>

                            <View style={{ marginHorizontal: 10, height: this.state.expanded ? null : 0 }}>
                                <ScrollView horizontal={true}>
                                    <View style={styles.chartContainer}>{this.renderChartContent()}</View>
                                </ScrollView>
                            </View>
                        </View>
                        <View style={styles.contentsHistoryContainer}>
                            <Text style={styles.historyHeading}>{strings('historyDescription')}</Text>
                            <DashboardHistory onSelect={this.handleHistorySelection} />
                        </View>
                    </>
                );

            case 'inspectionPlan':
                return <InspectionPlanView />;
            case 'tasks':
                return (
                    <View style={styles.contentsHistoryContainer}>
                        <TaskHistory
                            onStartClick={this.handleStartTaskSelection}
                            taskdetails={this.state.selectedTask}
                            onSelect={this.handleTaskHistorySelection}
                            onSourceInspectionClick={this.onSourceInspectionClick}
                            onCreatedInspectionClick={this.onCreatedInspectionClick}
                            navigationPressedTime={this.state.navigationPressedTime}
                            dashboardNavExpanded={this.state.dashboardNavExpanded}
                        />
                    </View>
                );
            case 'overdue':
                return (
                    <View style={styles.contentsHistoryContainer}>
                        <TaskHistory
                            showOverdue={true}
                            onStartClick={this.handleStartTaskSelection}
                            taskdetails={this.state.selectedTask}
                            onSelect={this.handleTaskHistorySelection}
                            onSourceInspectionClick={this.onSourceInspectionClick}
                            onCreatedInspectionClick={this.onCreatedInspectionClick}
                            navigationPressedTime={this.state.navigationPressedTime}
                            dashboardNavExpanded={this.state.dashboardNavExpanded}
                        />
                    </View>
                );
            default:
                <View style={{ flex: 1 }}>
                    <Text>Unknown dashboard content</Text>
                </View>;
        }
    };

    async testGisAPI() {
        //console.log('testGisAPI()');
        //zoneId 35 = Abu Dhabi Island
        //sectorId: 302 = E16 (Al Zahiya)
        // const zones = await api.getZones({ zoneId: 35, municipalityCode: 'ADM' });
        // console.log('zones: ', zones);
        // const sectors = await api.getSectors({ sectorId: 302, zoneId: 35, municipalityCode: 'ADM' });
        // console.log('sectors: ', sectors);
        // const plots = await api.getPlots({ sectorId: 302, zoneId: 35 });
        // console.log('plots: ', plots);
        // const replacedSectorFields = replaceFieldNames(1, 'out', ['sectorId', 'sectorNameE']);
        // console.log('replacedSectorFields: ', replacedSectorFields);
        // const replacedZoneFields = replaceFieldNames(2, 'out', ['zonePopularNameE', 'municipalityCode', 'asdasd']);
        // console.log('replacedZoneFields: ', replacedZoneFields);
        // const replacedPlotFields = replaceFieldNames(0, 'in', ['COMMUNITYARA', 'DISTRICTENG', 'asdasd']);
        // console.log('replacedPlotFields: ', replacedPlotFields);
        // const multiplePlots = await api.getPlotsCustom(35, 302, ['BT02', 'BT03', 'BT04']);
        // console.log('multiplePlots: ', multiplePlots);
    }
    render() {
        const { selectedDashboardTab } = this.state;

        this.testGisAPI();
        return (
            <BaseContainer {...this.props}>
                <Modal animationType="slide" transparent={false} visible={this.state.settingsModalVisible} onRequestClose={this.toggleSettingsDialog}>
                    <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                    <Settings {...this.props} requestClose={this.toggleSettingsDialog} />
                </Modal>
                <Modal animationType="slide" transparent={false} visible={this.state.followupModalVisible} onRequestClose={this.toggleFollowupDialog}>
                    <FollowUpTopHeader
                        backAction={this.toggleFollowupDialog}
                        currentInspection={this.state.selectedTask ? this.state.selectedTask.parentRefNo : ''}
                        service={this.state.selectedTask ? this.state.selectedTask.selectedService : ''}
                        services={this.props.services}
                        title={strings('followup')}
                    />
                    <FollowupReview
                        inspection={this.state.selectedTask ? this.props.inspectionsHistory[this.state.selectedTask.parentRefNo] : null}
                        {...this.props}
                        taskdetails={this.state.selectedTask}
                        requestClose={this.toggleFollowupDialog}
                    />
                </Modal>
                <View style={{ flex: 1 }}>
                    <SearchBar breadCrumbs={this.breadCrumbs} />
                    <View style={styles.container}>
                        <View style={[styles.sideNavContainer, { height: '100%' }]}>
                            <SideNav
                                routes={mainStackDefinition.routes}
                                onPress={this.handleSideNavOnPress}
                                currentRouteName={this.currentRouteName}
                                onDashboardNavChanged={this.handleDashboardNavChanged}
                                showDashboardMenu={true}
                                navigationPressedTime={this.state.navigationPressedTime}
                                selectedDashboardTab={selectedDashboardTab}
                            />
                        </View>
                        <View style={styles.contentsContainer}>{this.renderDashboardContent()}</View>
                    </View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        currentInspectionRef: state.inspections.currentInspectionRef,
        inspectionsHistory: state.inspections.history,
        services: state.masterdata.services,
        isRtl: state.settings.isRtl,
        dashboardChartsData: state.generic.results,
        loading: state.generic.isLoading,
    };
};

const connectedDashboard = connect(mapStateToProps)(Dashboard);
export default screenWithSpinner(connectedDashboard, { theme: 'light' });

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    contentsHistoryContainer: {
        flex: 1,
        margin: 10,
        paddingBottom: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    historyHeading: {
        color: '$primaryDarkTextColor',
        fontSize: '$primaryTextSM',
        marginVertical: 10,
        marginStart: 10,
    },
    chartContainer: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'space-around',
        height: 250,
    },

    chartBox: {
        flex: 2,
        width: 200,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
        margin: 5,
    },
});
