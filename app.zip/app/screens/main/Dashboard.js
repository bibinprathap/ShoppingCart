import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Modal, ScrollView, TouchableOpacity, LayoutAnimation, Image } from 'react-native';
import { connect } from 'react-redux';
import { Title, Text, Portal, Button, Provider, Dialog, TouchableHighlight } from 'react-native-paper';
import { BaseContainer } from 'app/components/BaseContainer';
import { SearchBar } from 'app/components/SearchBar';
import { SideNav } from 'app/components/SideNav';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { mainStackDefinition } from 'app/config/routs/defs';
import { authLogout } from 'app/actions/auth';
import { selectInspection } from 'app/actions/inspections';
import { DashboardHistory } from 'app/components/DashboardHistory';
import { TaskHistory } from 'app/components/TaskHistory';
import EStyleSheet from 'react-native-extended-stylesheet';
import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';
import InspectionPlanView from 'app/components/InspectionPlanView/InspectionPlanView';
import HeaderGeneric from 'app/components/Header/HeaderGeneric';
import Settings from 'app/screens/main/Settings';
import images from 'app/images';
import { inspectionsHelper } from 'app/api/helperServices';
import { selectService, createNewInspectionFromTask, createInspectionRecordFromTask, selectServiceFromTask } from 'app/actions/inspections';

class Dashboard extends Component {
    state = {
        visible: false,
        settingsModalVisible: false,
        selectedDashboardTab: 'history',
        expanded: true,
    };

    static propTypes = {
        isRtl: PropTypes.bool,
    };
    currentRouteName = this.props.navigation.state.routeName;
    breadCrumbs = [{ key: 'dashboard', title: strings('dashboard'), selected: true }];

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };

    handleSideNavOnPress = item => {
        console.log(`Dashboard.handleSideNavOnPress(${item.key})`);
        if (item.key === 'logout') {
            this.props.dispatch(authLogout());
            this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
        }
        if (item.key === 'settings') {
            this.toggleSettingsDialog();
        } else this.props.navigation.navigate(item.key);
    };

    handleHistorySelection = item => {
        inspectionsHelper.selectInspection(item, this.props.navigation);
        //this.props.dispatch(selectInspection(item));
        //this.props.navigation.navigate('inspection');
    };
    handleStartTaskSelection = item => {
        console.log('handleStartTaskSelection');
        if (!this.state.selectedTask.refNumber) {
            const history = this.props.inspectionsHistory;
            // const existingInspection = Object.keys(history).find(i => history[i].inspection && history[i].inspection.taskId == this.state.taskId);

            //create New Inspection task
            this.props
                .dispatch(createNewInspectionFromTask(this.state.taskId, this.state.selectedTask.selectedService, this.state.selectedTask.location))
                .then(sk => {
                    const taskService = this.props.services.find(s => s.serviceId == this.state.selectedTask.selectedService);
                    this.props
                        .dispatch(
                            selectServiceFromTask({
                                serviceId: this.state.selectedTask.selectedService,
                                inspectionDef: taskService.inspectionDef,
                            })
                        )
                        .then(st => {
                            this.props.dispatch(createInspectionRecordFromTask(this.state.taskId, this.props.currentInspectionRef));
                            inspectionsHelper.selectInspection(this.props.currentInspectionRef, this.props.navigation);
                        });
                });
        } else {
            // pull inspection from server and add to history
        }
        //pull tInspection and add tohistory
        //showtaskinthehistory
        //  inspectionsHelper.selectInspection(this.state.selectedTask, this.props.navigation);
        //this.props.dispatch(selectInspection(item));
        //this.props.navigation.navigate('inspection');
    };

    handleTaskHistorySelection = (task, taskId) => {
        this.setState({ selectedTask: task, taskId });
    };

    handleDashboardNavChanged = selectedDashboardTab => {
        this.setState({ selectedDashboardTab, navigationPressedTime: new Date() });
    };

    changeLayout = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        this.setState({ expanded: !this.state.expanded });
    };

    renderDashboardContent = () => {
        switch (this.state.selectedDashboardTab) {
            case 'history':
                return (
                    <>
                        <View>
                            <TouchableOpacity
                                activeOpacity={0.8}
                                onPress={this.changeLayout}
                                style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}
                            >
                                <Image
                                    source={this.state.expanded ? images.chartCollapse.content : images.chartExpand.content}
                                    style={{ width: 20, height: 20, margin: 10 }}
                                />
                                <Text>{this.state.expanded ? strings('hideCharts') : strings('showCharts')}</Text>
                            </TouchableOpacity>

                            <View style={{ marginHorizontal: 10, height: this.state.expanded ? null : 0 }}>
                                <ScrollView horizontal={true}>
                                    <View style={styles.chartContainer}>
                                        <AdmChart />
                                    </View>
                                </ScrollView>
                            </View>
                        </View>
                        <View style={styles.contentsHistoryContainer}>
                            <Text style={styles.historyHeading}>{strings('historyDescription')}</Text>
                            <DashboardHistory onSelect={this.handleHistorySelection} />
                        </View>
                    </>
                );

            case 'inspectionPlan':
                return <InspectionPlanView />;
            case 'tasks':
                return (
                    <View style={styles.contentsHistoryContainer}>
                        <TaskHistory
                            onStartClick={this.handleStartTaskSelection}
                            taskdetails={this.state.selectedTask}
                            onSelect={this.handleTaskHistorySelection}
                            navigationPressedTime={this.state.navigationPressedTime}
                        />
                    </View>
                );
            case 'overdue':
                return (
                    <View style={{ flex: 1 }}>
                        <Text>{strings('overdueDescription')}</Text>
                        <Text>Overdue tasks - not implemented yet</Text>
                    </View>
                );
            default:
                <View style={{ flex: 1 }}>
                    <Text>Unknown dashboard content</Text>
                </View>;
        }
    };
    render() {
        const { selectedDashboardTab } = this.state;
        return (
            <BaseContainer {...this.props}>
                <Modal animationType="slide" transparent={false} visible={this.state.settingsModalVisible} onRequestClose={this.toggleSettingsDialog}>
                    <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                    <Settings {...this.props} requestClose={this.toggleSettingsDialog} />
                </Modal>
                <View style={{ flex: 1 }}>
                    <SearchBar breadCrumbs={this.breadCrumbs} />
                    <View style={styles.container}>
                        <View style={[styles.sideNavContainer, { height: '100%' }]}>
                            <SideNav
                                routes={mainStackDefinition.routes}
                                onPress={this.handleSideNavOnPress}
                                currentRouteName={this.currentRouteName}
                                onDashboardNavChanged={this.handleDashboardNavChanged}
                                showDashboardMenu={true}
                                selectedDashboardTab={selectedDashboardTab}
                            />
                        </View>
                        <View style={styles.contentsContainer}>{this.renderDashboardContent()}</View>
                    </View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        currentInspectionRef: state.inspections.currentInspectionRef,
        inspectionsHistory: state.inspections.history,
        services: state.masterdata.services,
        isRtl: state.settings.isRtl,
    };
};

const connectedDashboard = connect(mapStateToProps)(Dashboard);
export default screenWithSpinner(connectedDashboard, { theme: 'light' });

const styles = EStyleSheet.create({
    //pity that EStyleSheet currently supports only ONE math operation in a statement.
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    contentsHistoryContainer: {
        flex: 1,
        margin: 10,
        paddingBottom: 10,
        backgroundColor: '$primaryWhite',
        elevation: 1,
        borderRadius: 10,
        borderColor: '$primaryBorderColor',
    },
    chartContainer: {
        flex: 1,
        minWidth: 200,
        height: 200,
        justifyContent: 'space-between',
        margin: 10,
    },
    historyHeading: {
        color: '$primaryDarkTextColor',
        fontSize: '$primaryTextSM',
        marginVertical: 10,
        marginStart: 10,
    },
});
