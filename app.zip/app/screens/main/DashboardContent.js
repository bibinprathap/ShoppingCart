import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Text } from 'react-native-paper';

import AdmChart from 'app/components/DashboardCharts/AdmChart/AdmChart';
import InspectionPlanView from 'app/components/InspectionPlanView/InspectionPlanView';

import { DashboardHistory } from 'app/components/DashboardHistory';
import { TaskHistory } from 'app/components/TaskHistory';
import images from 'app/images';

const DashboardContent = props => {
    let retdashboard = null;
    switch (props.selectedDashboardTab) {
        case 'history':
            retdashboard = (
                <>
                    <View>
                        <TouchableOpacity
                            activeOpacity={0.8}
                            onPress={this.changeLayout}
                            style={{ flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center' }}
                        >
                            <Image
                                source={props.expanded ? images.chartCollapse.content : images.chartExpand.content}
                                style={{ width: 20, height: 20, margin: 10 }}
                            />
                            <Text>{props.expanded ? strings('hideCharts') : strings('showCharts')}</Text>
                        </TouchableOpacity>

                        <View style={{ marginHorizontal: 10, height: props.expanded ? null : 0 }}>
                            <ScrollView horizontal={true}>
                                <View style={styles.chartContainer}>
                                    <AdmChart />
                                </View>
                            </ScrollView>
                        </View>
                    </View>
                    <View style={styles.contentsHistoryContainer}>
                        <Text style={styles.historyHeading}>{strings('historyDescription')}</Text>
                        <DashboardHistory onSelect={props.handleHistorySelection} />
                    </View>
                </>
            );
            break;
        case 'inspectionPlan':
            retdashboard = <InspectionPlanView />;
            break;
        case 'tasks':
            retdashboard = (
                <View style={styles.contentsHistoryContainer}>
                    <TaskHistory
                        onStartClick={props.handleStartTaskSelection}
                        taskdetails={props.selectedTask}
                        onSelect={props.handleTaskHistorySelection}
                        onSourceInspectionClick={props.onSourceInspectionClick}
                        onCreatedInspectionClick={props.onCreatedInspectionClick}
                        navigationPressedTime={props.navigationPressedTime}
                        dashboardNavExpanded={props.dashboardNavExpanded}
                    />
                </View>
            );
            break;
        case 'overdue':
            retdashboard = (
                <View style={styles.contentsHistoryContainer}>
                    <TaskHistory
                        showOverdue={true}
                        onStartClick={props.handleStartTaskSelection}
                        taskdetails={props.selectedTask}
                        onSelect={props.handleTaskHistorySelection}
                        onSourceInspectionClick={props.onSourceInspectionClick}
                        onCreatedInspectionClick={props.onCreatedInspectionClick}
                        navigationPressedTime={props.navigationPressedTime}
                        dashboardNavExpanded={props.dashboardNavExpanded}
                    />
                </View>
            );
            break;
        default:
            retdashboard = (
                <View style={{ flex: 1 }}>
                    <Text>Unknown dashboard content</Text>
                </View>
            );
            break;
    }
    return retdashboard;
};
export default DashboardContent;
