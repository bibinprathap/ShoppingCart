import React, { Component } from 'react';
import PropTypes from 'prop-types';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Text } from 'react-native-paper';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import { ScrollView, View, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { markNotificationAsRead, refreshNotificationUnreadCount } from 'app/actions/notifications';
import { setDeeplink } from 'app/actions/settings';
import { deeplinkHelper } from 'app/api/helperServices';
import moment from 'moment';
import { _ } from 'lodash';

const styles = EStyleSheet.create({
    notificationItem: {
        paddingHorizontal: 20,
        paddingVertical: 10,
        marginHorizontal: 10,
        marginBottom: 2,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    timestamp: {
        position: 'absolute',
        alignSelf: 'flex-end',
        fontSize: '$primaryTextXS',
        paddingRight: 10,
    },
    title: {
        fontSize: '$primaryTextSM',
    },
    body: {
        fontSize: '$primaryTextXS',
    },
    emptyNotificationWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    emptyNotification: {
        color: '$primaryMediumTextColor',
        marginBottom: 15,
    },
    unreadMessage: {
        backgroundColor: '$nofificationsUnreadItem',
        borderRadius: 5,
    },
    unreadTitle: {
        fontWeight: 'bold',
    },
});

class NotificationsScreen extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    constructor() {
        super();
        this.state = { refreshCount: 0 };
    }

    componentDidMount() {
        this.props.actions.refreshNotificationUnreadCount();
        this.refreshTimer = setInterval(() => {
            this.setState({ refreshCount: this.state.refreshCount + 1 });
        }, 10000);
    }

    componentWillUnmount() {
        if (this.refreshTimer) {
            clearInterval(this.refreshTimer);
        }
    }

    refreshTimer;

    handleNotification(notificationId, notification) {
        this.props.actions.markNotificationAsRead(notificationId);
        if (notification.url) {
            const { auth, navigation, dispatch } = this.props;
            const loggedIn = (auth && auth.loggedIn) || false;
            deeplinkHelper.handleLink({ deeplink: notification.url, loggedIn, dispatch, navigation });
        }
    }

    render() {
        const notifications = this.props.notifications;
        if (!notifications) return null;

        return (
            <BaseContainerWithSideNav {...this.props}>
                <View style={{ flex: 1 }}>
                    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingVertical: 10, flexGrow: 1 }}>
                        {notifications &&
                            Object.keys(notifications).length > 0 &&
                            _.map(notifications, (notification, message_id) => {
                                const itemStyle = [styles.notificationItem];
                                const itemTitleStyle = [styles.title];
                                if (!notification) return null;

                                let dateTime = null;
                                if (notification.timestamp) {
                                    dateTime =
                                        moment(Number(notification.timestamp)).format('YYYYMMDD') === moment().format('YYYYMMDD')
                                            ? moment(Number(notification.timestamp)).fromNow()
                                            : moment(Number(notification.timestamp)).format('M/D/YYYY h:m:s a');
                                }

                                if (!notification.readAt) {
                                    itemStyle.push(styles.unreadMessage);
                                    itemTitleStyle.push(styles.unreadTitle);
                                }
                                return (
                                    <TouchableOpacity
                                        style={itemStyle}
                                        key={message_id}
                                        onPress={() => this.handleNotification(message_id, notification)}
                                    >
                                        <Text style={styles.timestamp}>{dateTime}</Text>
                                        <Text style={itemTitleStyle}>{notification.title || null}</Text>
                                        <Text style={styles.body}>{notification.body || null}</Text>
                                    </TouchableOpacity>
                                );
                            })}
                        {notifications && Object.keys(notifications).length == 0 && (
                            <View style={styles.emptyNotificationWrapper}>
                                <Icon name="notifications-none" size={70} style={styles.emptyNotification} />
                                <Text style={styles.title}>{strings('noNotifications')}</Text>
                            </View>
                        )}
                    </ScrollView>
                </View>
            </BaseContainerWithSideNav>
        );
    }
}

const mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
        auth: state.auth,
        notifications: state.notifications.notifications,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators(
            {
                markNotificationAsRead,
                refreshNotificationUnreadCount,
                setDeeplink,
            },
            dispatch
        ),
        dispatch,
    };
};

const connectedNotifications = connect(
    mapStateToProps,
    mapDispatchToProps
)(NotificationsScreen);

export default screenWithSpinner(connectedNotifications, { theme: 'light' });
