import React, { Component } from 'react';
import { View, ScrollView, DeviceEventEmitter, NativeModules, Text } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Title, List, IconButton, TouchableRipple, Divider } from 'react-native-paper';
import { _ } from 'lodash';
import { strings } from 'app/config/i18n/i18n';
import { Loader } from 'app/components/Loader';

const { Bluetooth } = NativeModules;

const styles = EStyleSheet.create({
    container: {
        paddingLeft: 55,
        flexDirection: 'column',
        minHeight: 100,
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    button: {
        marginTop: 8,
        height: '$globalButtonHeight',
        backgroundColor: '$primaryDarkButtonBackground',
    },
    title: {
        alignSelf: 'flex-start',
    },
    searchButton: {
        marginVertical: 20,
        justifyContent: 'center',
        alignSelf: 'center',
    },
    errorBlock: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
    },
    errorText: {
        color: '$primaryErrorTextColor',
    },
    noDeviceFound: {
        justifyContent: 'center',
        alignSelf: 'center',
        marginTop: 20,
        fontSize: 14,
    },
});

class Printers extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pairedDevices: [],
            isBluetoothEnabled: true,
            isSearching: false,
        };
    }

    componentDidMount() {
        Bluetooth.isBluetoothEnabled().then(isBluetoothEnabled => this.setState({ isBluetoothEnabled }), err => {});

        this.listener1 = DeviceEventEmitter.addListener(Bluetooth.EVENT_DEVICE_ALREADY_PAIRED, pairedDevice => {
            const { pairedDevices } = this.state;
            if (pairedDevice && pairedDevice.address) {
                this.setState({ pairedDevices: [...pairedDevices, pairedDevice] });
            }
        });

        Bluetooth.scanDevices().then(pairedDevices => {}, er => {});

        if (!this.props.connectedPrinter) {
            this.scanPrinters();
        }
    }

    componentWillUnmount() {
        this.listener1.remove();
    }

    listener1;

    connectToPrinter(printer) {
        this.props.connectToPrinter(printer);
    }

    scanPrinters() {
        if (this.state.isSearching) return;

        this.setState({ isSearching: true, pairedDevices: [] });

        Bluetooth.scanDevices().then(
            res => {
                const paireddevices = JSON.parse(res).paired;

                if (paireddevices) {
                    //&& paireddevices.length > 0
                    // console.warn(JSON.stringify(paireddevices))
                    let deviceList =
                        this.props.connectedPrinter && this.props.connectedPrinter.address
                            ? [this.props.connectedPrinter, ...paireddevices]
                            : paireddevices;
                    if (this.props.connectedPrinter) {
                        deviceList = _.uniqBy(deviceList, 'address');
                    }
                    this.setState({ pairedDevices: deviceList, isSearching: false });
                    if (deviceList.length == 1) {
                        this.props.connectToPrinter(paireddevices[0]);
                    }
                }
            },
            er => {
                this.setState({
                    isSearching: false,
                });
            }
        );
    }

    render() {
        const { isBluetoothEnabled, pairedDevices, isSearching } = this.state;
        const { connectedPrinter } = this.props;
        return (
            <View style={styles.container}>
                {!isBluetoothEnabled && (
                    <View style={styles.errorBlock}>
                        <Text style={styles.errorText}>{strings('bluetoothError')}</Text>
                    </View>
                )}
                {isSearching && <Loader loading={true} />}
                <ScrollView>
                    {!isSearching && !pairedDevices.length && !connectedPrinter && <Text style={styles.noDeviceFound}>No device found</Text>}
                    {!isSearching &&
                        pairedDevices.map((pairedDevice, key) => {
                            return (
                                <View key={key}>
                                    <TouchableRipple onPress={() => this.connectToPrinter(pairedDevice)}>
                                        <List.Item
                                            style={styles.row}
                                            title={pairedDevice.name}
                                            description={pairedDevice.address}
                                            titleStyle={styles.title}
                                            right={props => {
                                                if (connectedPrinter && connectedPrinter.address === pairedDevice.address) {
                                                    return (
                                                        <List.Icon
                                                            {...props}
                                                            color={EStyleSheet.value('$primaryDarkButtonBackground')}
                                                            icon="check"
                                                        />
                                                    );
                                                } else {
                                                    return null;
                                                }
                                            }}
                                        />
                                    </TouchableRipple>
                                    <Divider />
                                </View>
                            );
                        })}
                    {!isSearching && isBluetoothEnabled && (
                        <View style={styles.searchButton}>
                            <IconButton
                                icon="search"
                                color={EStyleSheet.value('$primaryDarkButtonBackground')}
                                size={30}
                                onPress={() => this.scanPrinters()}
                            />
                        </View>
                    )}
                </ScrollView>
            </View>
        );
    }
}

export default Printers;
