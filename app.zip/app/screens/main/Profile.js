import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { View, ScrollView } from 'react-native';
import { Text, Headline } from 'react-native-paper';
import { _ } from 'lodash';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
    },
    rowContainer: {
        borderStyle: 'solid',
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        minHeight: 40,
    },
    rowContent: {
        flex: 1,
        flexDirection: 'row',
    },
    cellContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    cellTextBold: {
        fontWeight: 'bold',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXSM',
        padding: 5,
    },
    cellText: {
        flex: 1,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXSM',
        padding: 5,
    },
    title: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
        fontWeight: 'bold',
        marginBottom: 5,
        paddingLeft: 5,
    },
});

const ProfileView = ({ profile }) => {
    //console.log('Profile.renderProfile: ', profile);
    return (
        <View>
            <View style={styles.rowContainer}>
                <View style={styles.cellContainer}>
                    <Text style={styles.cellTextBold}>{strings('nameA')}</Text>
                    <Text style={styles.cellText}>{profile.displayNameA}</Text>
                </View>
            </View>
            <View style={styles.rowContainer}>
                <View style={styles.cellContainer}>
                    <Text style={styles.cellTextBold}>{strings('nameE')}</Text>
                    <Text style={styles.cellText}>{profile.displayNameE}</Text>
                </View>
            </View>
            <View style={styles.rowContainer}>
                <View style={styles.cellContainer}>
                    <Text style={styles.cellTextBold}>domainCustomerNameA</Text>
                    <Text style={styles.cellText}>{profile.domainCustomerNameA}</Text>
                </View>
            </View>
            <View style={styles.rowContainer}>
                <View style={styles.cellContainer}>
                    <Text style={styles.cellTextBold}>domainCustomerNameE</Text>
                    <Text style={styles.cellText}>{profile.domainCustomerNameE}</Text>
                </View>
            </View>
        </View>
    );
};

class Profile extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    render() {
        const { activeProfile, profiles } = this.props;
        return (
            <BaseContainerWithSideNav {...this.props}>
                <ScrollView style={styles.container}>
                    <Text style={styles.title}>Active profile:</Text>
                    {activeProfile && <ProfileView profile={activeProfile} />}
                    <View style={{ marginVertical: 15 }} />
                    <Text style={styles.title}>Other profiles:</Text>
                    {profiles && profiles.map((p, index) => <ProfileView key={index} profile={p} />)}
                </ScrollView>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    const allProfiles = state.auth.profiles;
    const activeProfileDomainCustomerId = state.auth.activeProfileDomainCustomerId;
    const activeProfile =
        allProfiles && activeProfileDomainCustomerId ? _.find(allProfiles, { domainCustomerId: activeProfileDomainCustomerId }) : undefined;

    //console.log('Profile.mapStateToProps... allProfiles', allProfiles, 'activeProfile: ', activeProfile);
    return {
        profiles: allProfiles,
        activeProfile: activeProfile,
    };
};

const connectedProfile = connect(mapStateToProps)(Profile);
export default screenWithSpinner(connectedProfile, { theme: 'light' });
