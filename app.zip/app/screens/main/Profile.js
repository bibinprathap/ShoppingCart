import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { View, ScrollView } from 'react-native';
import { Text, Headline, Divider } from 'react-native-paper';
import { _ } from 'lodash';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';

const P = ({ profile }) => {
    //console.log('Profile.renderProfile: ', profile);
    return (
        <View style={{ borderWidth: 1, borderRadius: 10, margin: 5 }}>
            <Text>displayNameA {profile.displayNameA}</Text>
            <Text>displayNameE {profile.displayNameE}</Text>
            <Text>domainCustomerNameA {profile.domainCustomerNameA}</Text>
            <Text>domainCustomerNameE {profile.domainCustomerNameE}</Text>
        </View>
    );
};

class Profile extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    render() {
        const { activeProfile, profiles } = this.props;
        const renderedProfiles = profiles && profiles.map(p => this.renderProfile);
        return (
            <BaseContainerWithSideNav {...this.props}>
                <ScrollView>
                    <Headline>Active profile:</Headline>
                    {activeProfile && <P profile={activeProfile} />}
                    <Divider style={{ marginVertical: 30 }} />
                    <Headline>Other profiles:</Headline>
                    {profiles && profiles.map((p, index) => <P key={index} profile={p} />)}
                </ScrollView>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    const allProfiles = state.auth.profiles;
    const activeProfileDomainCustomerId = state.auth.activeProfileDomainCustomerId;
    const activeProfile =
        allProfiles && activeProfileDomainCustomerId ? _.find(allProfiles, { domainCustomerId: activeProfileDomainCustomerId }) : undefined;

    //console.log('Profile.mapStateToProps... allProfiles', allProfiles, 'activeProfile: ', activeProfile);
    return {
        profiles: allProfiles,
        activeProfile: activeProfile,
    };
};

const connectedProfile = connect(mapStateToProps)(Profile);
export default screenWithSpinner(connectedProfile, { theme: 'light' });
