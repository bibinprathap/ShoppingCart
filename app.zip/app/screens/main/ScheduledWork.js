import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';

class ScheduledWork extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    render() {
        return (
            <BaseContainerWithSideNav {...this.props}>
                <Text>Scheduled work</Text>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
    };
};

const connectedScheduledWork = connect(mapStateToProps)(ScheduledWork);
export default screenWithSpinner(connectedScheduledWork, { theme: 'light' });
