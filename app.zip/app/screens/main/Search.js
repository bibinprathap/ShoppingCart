import React, { Component } from 'react';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
//import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import { ScrollView, View, TouchableOpacity } from 'react-native';
import moment from 'moment';
import { _ } from 'lodash';
import Icon from 'react-native-vector-icons/Entypo';
import { Loader } from 'app/components/Loader';
import { deeplinkHelper } from 'app/api/helperServices';

const styles = EStyleSheet.create({
    item: {
        paddingHorizontal: 20,
        paddingVertical: 12,
        marginHorizontal: 10,
        marginBottom: 2,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    timestamp: {
        position: 'absolute',
        alignSelf: 'flex-end',
        fontSize: '$primaryTextXS',
        paddingRight: 10,
        marginTop: -2,
    },
    title: {
        fontSize: '$primaryTextSM',
    },
    details: {
        fontSize: '$primaryTextXS',
    },
    emptyWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    emptyMessage: {
        color: '$primaryMediumTextColor',
        marginBottom: 15,
    },
    unreadMessage: {
        backgroundColor: '$nofificationsUnreadItem',
        borderRadius: 5,
    },
    unreadTitle: {
        fontWeight: 'bold',
    },
    boldText: {
        fontWeight: 'bold',
    },
});

class Search extends Component {
    handleSearchItem(result) {
        if (!result.refNumber) return;
        const link = `adm://mims/inspection/${result.refNumber}`;
        const { dispatch, navigation } = this.props;
        deeplinkHelper.handleLink({ deeplink: link, loggedIn: true, dispatch, navigation });
    }

    render() {
        const { results, isLoading } = this.props.search;

        return (
            <BaseContainerWithSideNav {...this.props}>
                <View style={{ flex: 1 }}>
                    <ScrollView style={{ flex: 1, paddingVertical: 5 }} contentContainerStyle={{ paddingVertical: 10, flexGrow: 1 }}>
                        {(isLoading && (
                            <View style={{ flex: 1 }}>
                                <Loader loading={isLoading} sprinnerSize={20} />
                            </View>
                        )) ||
                            null}
                        {(!isLoading &&
                            results.length &&
                            _.map(results, (result, key) => {
                                if (!result) return null;

                                const createdDateTime = moment(result.createdDate).format('M/D/YYYY h:m:s a');
                                const updatedDateTime = moment(result.updatedDate).format('M/D/YYYY h:m:s a');
                                const { address, violator } = result;

                                return (
                                    <TouchableOpacity style={styles.item} key={key} onPress={() => this.handleSearchItem(result)}>
                                        <Text style={styles.title}>{result.title || null}</Text>
                                        {result.refNumber && (
                                            <Text style={[styles.details, styles.boldText]}>
                                                {strings('referenceNumberShort')}: {result.refNumber}
                                            </Text>
                                        )}
                                        {address && (
                                            <Text style={styles.details}>
                                                {`${strings('zone')}: ${address.zone}, ${strings('sector')}: ${address.sector}, ${strings('plot')}: ${
                                                    address.plot
                                                }`}
                                            </Text>
                                        )}
                                        {violator && (
                                            <View>
                                                <Text style={[styles.details, styles.boldText]}>{strings('violatorDetails')}</Text>
                                                {violator.type === 'individual' && (
                                                    <View>
                                                        {violator.emiratesId && (
                                                            <Text style={styles.details}>
                                                                {strings('emiratesId')}: {violator.emiratesId}
                                                            </Text>
                                                        )}
                                                        {violator.firstName && (
                                                            <Text style={styles.details}>
                                                                {strings('firstName')}: {violator.firstName}
                                                            </Text>
                                                        )}
                                                        {violator.lastName && (
                                                            <Text style={styles.details}>
                                                                {strings('lastName')}: {violator.lastName}
                                                            </Text>
                                                        )}
                                                    </View>
                                                )}
                                                {violator.type === 'company' && (
                                                    <View>
                                                        {violator.tradeLicenseNumber && (
                                                            <Text style={styles.details}>
                                                                {strings('tradeLicenseNumber')}: {violator.tradeLicenseNumber}
                                                            </Text>
                                                        )}
                                                        {violator.companyName && (
                                                            <Text style={styles.details}>
                                                                {strings('companyName')}: {violator.companyName}
                                                            </Text>
                                                        )}
                                                    </View>
                                                )}
                                            </View>
                                        )}
                                        <Text style={styles.details}>Created by: {result.createdBy}</Text>
                                        <Text style={styles.details}>Created on: {createdDateTime}</Text>
                                        <Text style={styles.details}>Updated by: {result.lastUpdatedBy}</Text>
                                        <Text style={styles.details}>Last updated: {updatedDateTime}</Text>
                                    </TouchableOpacity>
                                );
                            })) ||
                            null}
                        {!isLoading && results.length == 0 && (
                            <View style={styles.emptyWrapper}>
                                <Icon name="emoji-sad" size={70} style={styles.emptyMessage} />
                                <Text style={styles.title}>{strings('noResults')}</Text>
                            </View>
                        )}
                    </ScrollView>
                </View>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search,
    };
};

export default connect(mapStateToProps)(Search);
