import React, { Component } from 'react';
import PropTypes from 'prop-types';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Text } from 'react-native-paper';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
//import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import { ScrollView, View, TouchableOpacity } from 'react-native';
import moment from 'moment';
import { _ } from 'lodash';
import Icon from 'react-native-vector-icons/Entypo';
import { Loader } from 'app/components/Loader';

const styles = EStyleSheet.create({
    item: {
        paddingHorizontal: 20,
        paddingVertical: 12,
        marginHorizontal: 10,
        marginBottom: 2,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    timestamp: {
        position: 'absolute',
        alignSelf: 'flex-end',
        fontSize: '$primaryTextXS',
        paddingRight: 10,
        marginTop: -2,
    },
    title: {
        fontSize: '$primaryTextSM',
    },
    body: {
        fontSize: '$primaryTextXS',
    },
    emptyWrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    emptyMessage: {
        color: '$primaryMediumTextColor',
        marginBottom: 15,
    },
    unreadMessage: {
        backgroundColor: '$nofificationsUnreadItem',
        borderRadius: 5,
    },
    unreadTitle: {
        fontWeight: 'bold',
    },
});

class Search extends Component {
    handleSearchItem(result) {}

    render() {
        const { results, isLoading } = this.props.search;

        return (
            <BaseContainerWithSideNav {...this.props}>
                <View style={{ flex: 1 }}>
                    <ScrollView style={{ flex: 1, paddingVertical: 5 }} contentContainerStyle={{ paddingVertical: 10, flexGrow: 1 }}>
                        {(isLoading && (
                            <View style={{ flex: 1 }}>
                                <Loader loading={isLoading} sprinnerSize={20} />
                            </View>
                        )) ||
                            null}
                        {(!isLoading &&
                            results.length &&
                            _.map(results, (result, key) => {
                                if (!result) return null;

                                const createdDateTime = moment(result.createdDate).format('M/D/YYYY h:m:s a');
                                const updatedDateTime = moment(result.updatedDate).format('M/D/YYYY h:m:s a');

                                return (
                                    <TouchableOpacity style={styles.item} key={key} onPress={() => this.handleSearchItem(result)}>
                                        <Text style={styles.title}>{result.title || null}</Text>
                                        <Text style={styles.body}>Created by: {result.createdBy}</Text>
                                        <Text style={styles.body}>Created on: {createdDateTime}</Text>
                                        <Text style={styles.body}>Updated by: {result.lastUpdatedBy}</Text>
                                        <Text style={styles.body}>Last updated: {updatedDateTime}</Text>
                                    </TouchableOpacity>
                                );
                            })) ||
                            null}
                        {!isLoading && results.length == 0 && (
                            <View style={styles.emptyWrapper}>
                                <Icon name="emoji-sad" size={70} style={styles.emptyMessage} />
                                <Text style={styles.title}>{strings('noResults')}</Text>
                            </View>
                        )}
                    </ScrollView>
                </View>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    return {
        search: state.search,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        actions: bindActionCreators({}, dispatch),
        dispatch,
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Search);
