import React, { Component } from 'react';
import PropTypes from 'prop-types';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { strings } from 'app/config/i18n/i18n';
import { ScrollView, View } from 'react-native';

class Search extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
    };

    render() {
        const dummyContent = [];
        for (let i = 0; i < 50; i++) {
            dummyContent.push(
                <View key={i} style={styles.searchItem}>
                    <Text>Search Result Item {i}</Text>
                </View>
            );
        }

        return (
            <BaseContainerWithSideNav {...this.props}>
                <View style={{ flex: 1 }}>
                    <Text>Generic search</Text>
                    <ScrollView>{dummyContent}</ScrollView>
                </View>
            </BaseContainerWithSideNav>
        );
    }
}

mapStateToProps = state => {
    return {
        isRtl: state.settings.isRtl,
    };
};

const connectedSearch = connect(mapStateToProps)(Search);
export default screenWithSpinner(connectedSearch, { theme: 'light' });

const styles = EStyleSheet.create({
    searchItem: {
        margin: 10,
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
});
