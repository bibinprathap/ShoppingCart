import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, Picker, ScrollView, TextInput } from 'react-native';
import RNRestart from 'react-native-restart';
import { connect } from 'react-redux';
import moment from 'moment';
import { Title, List, Button, Switch, TouchableRipple, Divider } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { BaseContainer, BaseContainerWithSideNav } from 'app/components/BaseContainer';
import { setLocale, strings } from 'app/config/i18n/i18n';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { persistor } from 'app/config/store';
import { clearMasterdata } from 'app/actions/masterdata';
import { initLanguage, changeEnvironment, setSelectedPrinter } from 'app/actions/settings';
import firebase from 'app/api/helperServices/rnFirebaseNative';
import { authLogout } from 'app/actions/auth';
import { clearHistory } from 'app/actions/inspections';
import alertsHelper from 'app/api/helperServices/alerts';
import Printers from 'app/screens/main/Printers';
const styles = EStyleSheet.create({
    container: {
        paddingTop: 100,
        flexDirection: 'column',
    },
    row: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    button: {
        marginTop: 8,
        height: '$globalButtonHeight',
        backgroundColor: '$primaryDarkButtonBackground',
    },
    title: {
        alignSelf: 'flex-start',
        fontSize: '$primaryTextSM',
    },
    input: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
        fontSize: '$primaryTextSM',
        marginEnd: 10,
    },
    error: { backgroundColor: '$primaryErrorTextColor' },
    warning: { backgroundColor: '$primaryIndicatorColor' },
    info: { backgroundColor: '$primaryHeaderColor' },
    success: { backgroundColor: 'green' /*'$primaryYesButtonBackground'*/ },
    environmentPicker: { height: 50, width: 200 },
});

class Settings extends Component {
    static propTypes = {
        isRtl: PropTypes.bool,
        locale: PropTypes.string,
        loggedIn: PropTypes.bool,
        selectedPrinter: PropTypes.any,
        environment: PropTypes.string,
        tracking: PropTypes.object,
    };
    constructor() {
        super();
        this.state = {
            showBTPriters: false,
        };
    }

    handleLanguageSwitch = () => {
        setTimeout(() => {
            const newLocale = this.props.isRtl ? 'en-US' : 'ar-AE';
            this.props.dispatch(initLanguage(newLocale));
            persistor.flush().then(() => {
                setLocale(newLocale);
            });
        }, 0);
        this.props.requestClose && this.props.requestClose();
    };

    handlePrinterSelect = selectedPrinter => {
        this.props.dispatch(setSelectedPrinter(selectedPrinter));
        // persistor.flush().then(() => {
        // });
        this.setState({ showBTPriters: false });
    };

    handlePurgeStorage = () => {
        persistor.purge().then(() => {
            console.log('Storage purged.');
        });
    };

    handleClearHistory = () => {
        persistor.purge().then(() => {
            this.props.dispatch(clearHistory());
        });
    };

    handleClearMasterdata = () => {
        persistor.purge().then(() => {
            this.props.dispatch(clearMasterdata());
        });
    };

    handleShowAlert = alertType => {
        alertsHelper.show(alertType, 'Sample alert message', 'Sample alert detail, and more detail, and some more.');
    };

    handleEnvironmentChange = env => {
        setTimeout(() => {
            this.props.dispatch(changeEnvironment(env)).then(() => {
                if (!!this.props.loggedIn) {
                    RNRestart.Restart();
                }
            });
        }, 0);
        this.props.requestClose && this.props.requestClose();
    };

    render() {
        const connectedPrinter = this.props.selectedPrinter;
        const { showBTPriters } = this.state;
        const lastEventLocation = this.props.tracking && this.props.tracking.lastEvent && this.props.tracking.lastEvent.location;
        const lastEventDateTime = lastEventLocation && moment(lastEventLocation.time).format('YYYY-MM-DD HH-mm-ss');

        //console.log('lastEventDateTime: ', lastEventDateTime);
        return (
            // <BaseContainerWithSideNav {...this.props}>
            <View style={{ flex: 1 }}>
                <ScrollView>
                    <View style={{ height: 50, alignItems: 'center', marginVertical: 20, marginHorizontal: 20 }}>
                        <View>
                            <Text style={styles.title}>Last Event @: {lastEventDateTime} </Text>
                        </View>
                        <View
                            style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'space-around',
                                alignItems: 'center',
                                padding: 5,
                            }}
                        >
                            <Text style={{ flex: 1 }}> Long(X):{lastEventLocation && lastEventLocation.longitude}</Text>
                            <Text style={{ flex: 1 }}> Lat(Y):{lastEventLocation && lastEventLocation.latitude}</Text>
                        </View>
                    </View>
                    <TouchableRipple onPress={() => this.handleLanguageSwitch()}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title={strings('language')}
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="language" />}
                                right={props => (
                                    <Button mode="contained" style={styles.button}>
                                        {this.props.isRtl ? 'English' : 'العربية'}
                                    </Button>
                                )}
                            />
                        </View>
                    </TouchableRipple>
                    <Divider />
                    <TouchableRipple onPress={() => console.log('other setting')}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title={strings('otherSetting')}
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="settings" />}
                                right={props => <Switch value={true} />}
                            />
                        </View>
                    </TouchableRipple>
                    <Divider />
                    <TouchableRipple onPress={() => this.setState({ showBTPriters: !showBTPriters })}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title={strings('printers')}
                                description={!this.state.showBTPriters && connectedPrinter && connectedPrinter.name ? connectedPrinter.name : null}
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="print" />}
                                right={
                                    !this.state.showBTPriters && connectedPrinter && connectedPrinter.name
                                        ? props => <List.Icon {...props} icon="check" color={EStyleSheet.value('$primaryDarkButtonBackground')} />
                                        : null
                                }
                            />
                        </View>
                    </TouchableRipple>
                    {showBTPriters && <Printers connectedPrinter={connectedPrinter} connectToPrinter={this.handlePrinterSelect} />}
                    <Divider />
                    <TouchableRipple onPress={this.handleClearHistory}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title="Clear inspection history (all users)"
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="history" />}
                            />
                        </View>
                    </TouchableRipple>
                    <Divider />
                    <TouchableRipple onPress={this.handleClearMasterdata}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title="Clear Masterdata (experimental)"
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="details" />}
                            />
                        </View>
                    </TouchableRipple>
                    <Divider />
                    <TouchableRipple onPress={this.handlePurgeStorage}>
                        <View>
                            <List.Item
                                style={styles.row}
                                title="Purge storage/ reset (experimental)"
                                titleStyle={styles.title}
                                left={props => <List.Icon {...props} icon="clear" />}
                            />
                        </View>
                    </TouchableRipple>
                    <Divider />
                    <View style={{ flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center', marginVertical: 20 }}>
                        <Button mode="contained" style={[styles.button, styles.error]} onPress={() => this.handleShowAlert('error')}>
                            Error
                        </Button>
                        <Button mode="contained" style={[styles.button, styles.warning]} onPress={() => this.handleShowAlert('warn')}>
                            Warning
                        </Button>
                        <Button mode="contained" style={[styles.button, styles.info]} onPress={() => this.handleShowAlert('info')}>
                            Info
                        </Button>
                        <Button mode="contained" style={[styles.button, styles.success]} onPress={() => this.handleShowAlert('success')}>
                            Success
                        </Button>
                    </View>
                    <Divider />
                    <View style={{ flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center', marginVertical: 20 }}>
                        <Button
                            mode="contained"
                            style={[styles.button]}
                            onPress={() =>
                                firebase.localNotification({
                                    title: 'local notification for inspection',
                                    body: 'notification body inspection',
                                    url: 'adm://mims/inspection/20190805090909725',
                                })
                            }
                        >
                            Inspection Notification
                        </Button>
                        <Button
                            mode="contained"
                            style={[styles.button]}
                            onPress={() =>
                                firebase.scheduleLocalNotification({
                                    title: 'local notification for inspection',
                                    body: 'notification body inspection',
                                    url: 'adm://mims/inspection/20190805090909725',
                                    seconds: 5,
                                })
                            }
                        >
                            Show notification after 10 seconds
                        </Button>
                    </View>
                    <View
                        style={{
                            flexDirection: 'row',
                            justifyContent: 'space-around',
                            alignItems: 'center',
                            marginVertical: 20,
                            marginHorizontal: 20,
                        }}
                    >
                        <Text style={styles.title} textAlignVertical="center">
                            Environment
                        </Text>
                        <Picker
                            selectedValue={this.props.environment}
                            style={[styles.environmentPicker, { borderWidth: 1 }]}
                            onValueChange={this.handleEnvironmentChange}
                        >
                            <Picker.Item label="Development" value="development" />
                            <Picker.Item label="Test" value="test" />
                            <Picker.Item label="Production" value="prod" />
                        </Picker>
                    </View>
                </ScrollView>
            </View>
            //</BaseContainerWithSideNav>
        );
    }
}

const mapStateToProps = state => {
    return {
        locale: state.settings.locale,
        isRtl: state.settings.isRtl,
        loggedIn: state.auth.loggedIn,
        selectedPrinter: state.settings.selectedPrinter,
        environment: state.settings.environment,
        tracking: state.tracking,
    };
};

const connectedSettings = connect(mapStateToProps)(Settings);
export default screenWithSpinner(connectedSettings, { theme: 'light' });
//alertsHelper.show('error', error.message, error.detail);
