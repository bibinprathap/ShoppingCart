package com.mims;

import com.facebook.react.ReactActivity;
import com.facebook.react.ReactActivityDelegate;
import com.facebook.react.ReactRootView;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.modules.core.PermissionListener;
import com.mims.VideoView.VideoProxyManager;
import com.swmansion.gesturehandler.react.RNGestureHandlerEnabledRootView;

import org.devio.rn.splashscreen.SplashScreen;

import android.Manifest;
import android.app.AlertDialog;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;

import com.facebook.react.modules.i18nmanager.I18nUtil;

import android.content.Intent;
import android.os.Handler;
//import android.os.ResultReceiver;
import android.util.Log;
import android.widget.Toast;
//import android.view.View;
//import android.view.Window;
//import java.util.concurrent.TimeUnit;
//import androidx.lifecycle.Lifecycle;
//import androidx.work.ExistingPeriodicWorkPolicy;
//import androidx.work.ExistingWorkPolicy;
//import androidx.work.PeriodicWorkRequest;
//import androidx.work.OneTimeWorkRequest;
//import androidx.work.WorkManager;
import androidx.annotation.RequiresPermission;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;

import java.util.ArrayList;
import java.util.Arrays;

//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.location.FusedLocationProviderClient;
//import static com.mims.uploader.UploaderModule.TriggerIntervalCount;
//import com.google.android.gms.location.LocationCallback;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationResult;
//import android.location.Location;
//import android.util.Log;

// import com.google.android.libraries.places.api.Places;
// import com.google.android.libraries.places.api.net.PlacesClient;

//import com.mims.uploader.FitPlaceWorker;
//import com.mims.uploader.PlaceUpdateWorker;

public class MainActivity extends ReactActivity implements MyResultReceiver.Receiver {
    public static MyResultReceiver mReceiver;
    public static final int PERMISSION_REQ_CODE = 1234;

    // public static   Window myWindow ;

    // public static PlacesClient placesClient;
    // public static FusedLocationProviderClient mFusedLocationClient;
    public static ReactApplicationContext reactContextMain;

    String[] perms = { "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_NETWORK_STATE",
            "android.permission.INTERNET","android.permission.READ_PHONE_STATE" ,"android.permission.RECORD_AUDIO","android.permission.READ_EXTERNAL_STORAGE","android.permission.WRITE_EXTERNAL_STORAGE"};
    private static final String W_TAG = "Periodic Worker";
    public SampleLifecycleListener lifecycleListener = new SampleLifecycleListener();
    private static int count = 0;
    private static boolean initiallocationupdate = true;
    private static boolean PreviousGeoCheck = false;



    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
             //  WritableMap writableMap=Arguments.fromBundle(resultData);

        WritableMap params = Arguments.createMap();
        boolean emitEvent = initiallocationupdate;
        String triggerName = "";
        Log.i("onReceiveResult", "onReceiveResult");
        if  (resultCode==0) {

            count++;


            boolean newGeoCheck = resultData.getBoolean("geoCheck");
            params.putString("latitude", resultData.getString("latitude"));
            params.putString("longitude", resultData.getString("longitude"));
            params.putString("altitude", resultData.getString("altitude"));
            params.putString("accuracy", resultData.getString("accuracy"));
            params.putString("bearing", resultData.getString("bearing"));
            params.putString("speed", resultData.getString("speed"));
            params.putString("timestamp", resultData.getString("timestamp"));
            params.putString("deviceId", resultData.getString("deviceId"));
            params.putString("serialNumber", resultData.getString("serialNumber"));
            params.putString("systemName", resultData.getString("systemName"));
            params.putString("systemVersion", resultData.getString("systemVersion"));
            params.putString("carrier", resultData.getString("carrier"));
            params.putString("batteryLevel", resultData.getString("batteryLevel"));
            params.putString("ipAddress", resultData.getString("ipAddress"));
            params.putString("phoneNumber", resultData.getString("phoneNumber"));
            params.putString("uniqueId", resultData.getString("uniqueId"));
            params.putString("appState", resultData.getString("appState"));

            params.putBoolean("geoCheck", newGeoCheck);
            triggerName = "locationChange";


            SharedPreferences preferences = getSharedPreferences("uploaderid", MODE_PRIVATE);
            int TriggerIntervalCount = (Integer) preferences.getAll().get("TriggerIntervalCount");
            if (count == TriggerIntervalCount || newGeoCheck != PreviousGeoCheck) {
                // for pending uploads

                count = 0;
                emitEvent = true;
            }
//            // for geofancing change
//            if (newGeoCheck != PreviousGeoCheck) {
//                emitEvent = true;
//            }


        }
        else  {
                emitEvent=true;
            triggerName = "checkpointEvent";
            String event=resultData.getString("event");
            ArrayList<String> stringArrayList= resultData.getStringArrayList("ids");
            String arraylistasString = stringArrayList.toString();
            //Arguments.
                //    ReadableArray idsReadableArray= Arguments.
                            //writableMap.getArray("ids");

            params.putString("ids",arraylistasString);
            params.putString("event",event);

        }
        if (emitEvent && reactContextMain != null) {
            initiallocationupdate = false;
            params.putString("triggername", triggerName);
            Log.i("onReceiveResult", "emittingEvent "+ triggerName + "params: " + params);
            reactContextMain.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                    .emit("UPLOAD_NOTIFICATION", params);
        }

    }

    public void setupLifecycleListener() {
        ProcessLifecycleOwner.get().getLifecycle().addObserver(lifecycleListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // SplashScreen.show(this); // here
        super.onCreate(savedInstanceState);
        // mFusedLocationClient =
        // LocationServices.getFusedLocationProviderClient(getApplicationContext());
        mReceiver = new MyResultReceiver(new Handler());
        mReceiver.setReceiver(this);
        // myWindow = getWindow();
        // Places.initialize(getApplicationContext(), "23333");
        // placesClient = Places.createClient(this);
        checkPerms();
        //  ensurePermissions();
        // setupLifecycleListener();
        getLifecycle().addObserver(new SampleLifecycleListener());
        VideoProxyManager. getInstance().init(getApplicationContext(),"");
                I18nUtil sharedI18nUtilInstance = I18nUtil.getInstance();
        sharedI18nUtilInstance.allowRTL(getApplicationContext(), true);

        ReactInstanceManager mReactInstanceManager = getReactNativeHost().getReactInstanceManager();

        // PeriodicWorkRequest fireUploadBuilder =
        // new PeriodicWorkRequest.Builder(FitPlaceWorker.class, 15,
        // TimeUnit.MINUTES).build();
        // WorkManager.getInstance().enqueueUniquePeriodicWork(W_TAG,
        // ExistingPeriodicWorkPolicy.KEEP, fireUploadBuilder);
        // OneTimeWorkRequest fireUploadBuilder =
        // new OneTimeWorkRequest.Builder(FitPlaceWorker.class ) .setInitialDelay( 20,
        // TimeUnit.SECONDS).build();
        // WorkManager.getInstance().enqueue( fireUploadBuilder);

        // OneTimeWorkRequest updatePlaceBuilder =
        // new OneTimeWorkRequest .Builder(PlaceUpdateWorker.class)
        // .setInitialDelay( 1, TimeUnit.MINUTES)
        // .build();

        // WorkManager.getInstance().enqueue(updatePlaceBuilder);

        mReactInstanceManager.addReactInstanceEventListener(new ReactInstanceManager.ReactInstanceEventListener() {
            public void onReactContextInitialized(ReactContext validContext) {
                ReactApplicationContext context = (ReactApplicationContext) mReactInstanceManager
                        .getCurrentReactContext();
                reactContextMain = context;
            }
        });
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    /**
     * Returns the name of the main component registered from JavaScript. This is
     * used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "mims";
    }

    public void checkPerms() {
        // Checking if device version > 22 and we need to use new permission model
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP_MR1) {

            for (String perm : perms) {
                // Checking each persmission and if denied then requesting permissions
                if (checkSelfPermission(perm) == PackageManager.PERMISSION_DENIED) {
                    requestPermissions(perms, PERMISSION_REQ_CODE, new PermissionListener() {
                        @Override
                        public boolean onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

                            for (int i = 0; i < grantResults.length; i++) {

                                int permResult = grantResults[i];
                                if (permResult == -1) {
                                    String rejectedPermission = permissions[i];
                                    showAlert(rejectedPermission);


                                }
                            }
                            Log.d("requestCode", "onRequestPermissionsResult: " + requestCode);
                            return false;
                        }
                    });


                    break;
                }
            }

        }
    }

    public void showAlert(String rejectedPermission) {

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage("Please Grant All Permissions");
        dialog.setTitle("Permission Not Granted " + rejectedPermission);
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        finishAndRemoveTask();

                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();

    }

//public void permissionListner(PermissionListener permissionListener){
//    new PermissionListener() {
//        @Override
//        public boolean onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//            return false;
//        }
//    }
//
//}

    // Window overlay permission intent result

    @Override
    protected ReactActivityDelegate createReactActivityDelegate() {
        return new ReactActivityDelegate(this, getMainComponentName()) {
            @Override
            protected ReactRootView createRootView() {
                return new RNGestureHandlerEnabledRootView(MainActivity.this);
            }
        };
    }
}
