package com.mims.NumberPicker;

import android.widget.NumberPicker;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Color;
import android.content.res.Resources;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.common.MapBuilder;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.UIManagerModule;
import com.facebook.react.uimanager.annotations.ReactProp;
import com.facebook.react.uimanager.events.Event;
import com.facebook.react.uimanager.events.RCTEventEmitter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class NumberPickerViewManager extends SimpleViewManager<ReactNumberPickerView> {

    private static final String EVENT_NAME = "onChange";

    @Override
    public String getName() {
        return "NumberPickerAndroid";
    }

    @Override
    protected ReactNumberPickerView createViewInstance(ThemedReactContext reactContext) {
        return new ReactNumberPickerView(reactContext);
    }

    @Override
    public Map<String, Object> getExportedCustomBubblingEventTypeConstants() {
        Map<String, Map<String, String>> eventBinding = MapBuilder.of("phasedRegistrationNames",
                MapBuilder.of("bubbled", EVENT_NAME));

        return MapBuilder.<String, Object>builder().put(EVENT_NAME, eventBinding).build();
    }

    public void addEventEmitters(final ThemedReactContext reactContext, ReactNumberPickerView view) {

        view.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int oldValue, int newValue) {
                final WritableMap eventData = Arguments.createMap();
                eventData.putInt("value", newValue == numberPicker.getMinValue() ? -1 : newValue);

                reactContext.getNativeModule(UIManagerModule.class).getEventDispatcher()
                        .dispatchEvent(new Event(numberPicker.getId()) {

                            @Override
                            public String getEventName() {
                                return EVENT_NAME;
                            }

                            @Override
                            public void dispatch(RCTEventEmitter emitter) {
                                emitter.receiveEvent(getViewTag(), getEventName(), eventData);
                            }
                        });
            }
        });
    }

    private void changeDividerColor(NumberPicker picker, int color) {

        java.lang.reflect.Field[] pickerFields = NumberPicker.class.getDeclaredFields();
        for (java.lang.reflect.Field pf : pickerFields) {
            if (pf.getName().equals("mSelectionDivider")) {
                pf.setAccessible(true);
                try {
                    ColorDrawable colorDrawable = new ColorDrawable(color);
                    pf.set(picker, colorDrawable);
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (Resources.NotFoundException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
                break;
            }
        }
    }

    @ReactProp(name = "initialValues")
    public void setInitialValues(ReactNumberPickerView view, ReadableMap map) {
        view.setMinValue(map.getInt("minValue") - 1);
        // view.setMinValue(0);
        view.setMaxValue(map.getInt("maxValue"));
        view.setValue(map.getInt("initialValue"));
        invalidateDisplayedValues(view);
        changeDividerColor(view, Color.parseColor("#F7F7FA"));
    }

    @ReactProp(name = "wrapSelectorWheel")
    public void setWrapSelectorWheel(ReactNumberPickerView view, boolean wrap) {
        view.setWrapSelectorWheel(wrap);
    }

    private void invalidateDisplayedValues(ReactNumberPickerView view) {
        List<String> displayedValues = new ArrayList<>();
        // displayedValues.add("Nothing");

        for (int i = view.getMinValue(); i <= view.getMaxValue(); i++) {
            displayedValues.add(String.valueOf(i));
        }

        view.setDisplayedValues(displayedValues.toArray(new String[0]));
    }
}