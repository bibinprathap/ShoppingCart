package com.mims.VideoView;

import android.content.Context;
import android.widget.MediaController;

public class MyMediaController extends MediaController {

    public MyMediaController(Context context, boolean useFastForward) {
        super(context, useFastForward);
    }

    @Override
    public void hide() {
        this.show(0);
    }

}
