package com.mims.VideoView;

import android.net.Uri;
import android.content.Context;
import android.text.TextUtils;

import com.danikula.videocache.HttpProxyCacheServer;
import com.danikula.videocache.headers.HeaderInjector;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class VideoProxyManager {

    private HttpProxyCacheServer httpProxyCacheServer;
    private  Context proxyContext;
    public static String AuthASPX ="";
    private static final long DEFAULT_MAX_SIZE = 600 * 1024 * 1024; //最大缓存容量
    public static int DEFAULT_MAX_FILE_COUNT = 50; //最大缓存数量

    public static boolean isUseCache = true; // 全局是否使用缓存,Server端下发配置

    private VideoProxyManager() {
    }

    private static class VideoProxyManagerHolder {
        private static VideoProxyManager videoProxyManager = new VideoProxyManager();
    }

    public static VideoProxyManager getInstance() {
        return VideoProxyManagerHolder.videoProxyManager;
    }

    public void init(Context context, String aspxAuth) {
        if(proxyContext == null)
              proxyContext = context;
        LinkedHashMap<String, String> headers = new LinkedHashMap<>();
        headers.put(".ASPXAUTH", aspxAuth);
        httpProxyCacheServer = new HttpProxyCacheServer.Builder(context).maxCacheSize(DEFAULT_MAX_SIZE)
                .maxCacheFilesCount(DEFAULT_MAX_FILE_COUNT)
                    .headerInjector(new HeaderInjector() {
            @Override
            public Map<String, String> addHeaders(String url) {
                return headers;
            }
        }) .build();
    }

    /**
     * 传给播放器的url替换成代理的url
     **/

    public String getProxyUrl(String url) {
        if (TextUtils.isEmpty(url) || !isUseCache) {
            return url;
        }
          Uri mUri =  Uri.parse(url);
          Set<String> paramNames = mUri.getQueryParameterNames();
        for (String paramName : paramNames) {
            if(paramName.toString().indexOf("ASPXAUTH") > -1  && AuthASPX != mUri.getQueryParameter(paramName) ) {
                init(proxyContext, mUri.getQueryParameter(paramName));
            }
        }
        return httpProxyCacheServer.getProxyUrl(url);
    }

    /**
     * 需要非常小心，可能会误杀多播放器共享一个url的情况
     * @param url
     */
    public void shutdownOneClient(String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
      //  httpProxyCacheServer.shutdownOneClient(url);
    }

    public void shutdown() {
        httpProxyCacheServer.shutdown();
    }
}
