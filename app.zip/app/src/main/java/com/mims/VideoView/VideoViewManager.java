package com.mims.VideoView;

import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
// import android.support.v7.app.AppCompatActivity;

import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import com.facebook.react.uimanager.ViewGroupManager;
import com.facebook.react.uimanager.ViewManager;
import android.media.MediaPlayer;

import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;

public class VideoViewManager extends ViewGroupManager<FrameLayout> implements UniversalVideoView.VideoViewCallback {
    @Override
    public void onPause(MediaPlayer mediaPlayer) {
        Log.d(TAG, "onPause UniversalVideoView callback");
    }

    @Override
    public void onStart(MediaPlayer mediaPlayer) {
        Log.d(TAG, "onStart UniversalVideoView callback");
    }

    @Override
    public void onBufferingStart(MediaPlayer mediaPlayer) {
        Log.d(TAG, "onBufferingStart UniversalVideoView callback");
    }

    @Override
    public void onBufferingEnd(MediaPlayer mediaPlayer) {
        Log.d(TAG, "onBufferingEnd UniversalVideoView callback");
    }


    @Override
    public void onScaleChange(boolean isFullscreen) {
        this.isFullscreen = isFullscreen;
        if (isFullscreen) {
            ViewGroup.LayoutParams layoutParams = mVideoLayout.getLayoutParams();
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
            mVideoLayout.setLayoutParams(layoutParams);
            mBottomLayout.setVisibility(View.GONE);

        } else {
            ViewGroup.LayoutParams layoutParams = mVideoLayout.getLayoutParams();
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutParams.height = this.cachedHeight;
            mVideoLayout.setLayoutParams(layoutParams);
            mBottomLayout.setVisibility(View.VISIBLE);
        }

       // switchTitleBar(!isFullscreen);
    }

    // private void switchTitleBar(boolean show) {
    //     android.support.v7.app.ActionBar supportActionBar = getSupportActionBar();
    //     if (supportActionBar != null) {
    //         if (show) {
    //             supportActionBar.show();
    //         } else {
    //             supportActionBar.hide();
    //         }
    //     }
    // }

    private RelativeLayout mLayout;
    View mBottomLayout;
    View mVideoLayout;

    private static final String TAG = "VideoViewManager";
    private static final String SEEK_POSITION_KEY = "SEEK_POSITION_KEY";
    private static final String VIDEO_URL = "https://www.radiantmediaplayer.com/media/bbb-360p.mp4";
    TextView mStart;

    private int mSeekPosition;
    private int cachedHeight;
    private boolean isFullscreen;

    private UniversalVideoView  mVideoView;
    private UniversalMediaController  mediaController;

    private FrameLayout mFrameLayout;
    private SurfaceView mSurfaceView;
    private void setVideoAreaSize( ) {

        mVideoLayout.post(new Runnable() {
            @Override
            public void run() {
                int width = mVideoLayout.getWidth();
                cachedHeight = (int) (width * 405f / 720f);
//                cachedHeight = (int) (width * 3f / 4f);
//                cachedHeight = (int) (width * 9f / 16f);
                ViewGroup.LayoutParams videoLayoutParams = mVideoLayout.getLayoutParams();
                videoLayoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                videoLayoutParams.height = cachedHeight;
                mVideoLayout.setLayoutParams(videoLayoutParams);
              //  mVideoView.setVideoPath(url);
                //mVideoView.setVideoPath(VIDEO_URL);
                mVideoView.requestFocus();
               // mVideoView.start();
            }
        });
    }

    public static final String REACT_CLASS = "VideoView";
    @Override
    public String getName() {
        return REACT_CLASS;
    }
    @Override
    protected FrameLayout createViewInstance(ThemedReactContext reactContext) {

        mFrameLayout = new FrameLayout(reactContext);
        mFrameLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT));

        mLayout = new RelativeLayout(reactContext);
        mLayout.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT));
        mVideoView = new UniversalVideoView(reactContext);
        mVideoLayout = new View(reactContext);
        mBottomLayout = new View(reactContext);
        mVideoView.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        mSurfaceView = new SurfaceView(reactContext);
        mSurfaceView.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.FILL_PARENT, FrameLayout.LayoutParams.FILL_PARENT));

        mSurfaceView.setZOrderMediaOverlay(false);
        mSurfaceView.setZOrderOnTop(false);

        mediaController = new UniversalMediaController (reactContext);
        mFrameLayout.addView(mSurfaceView);
        mFrameLayout.addView(mVideoView);
        mFrameLayout.addView(mediaController);
        mLayout.addView(mVideoLayout);
        mLayout.addView(mBottomLayout);
        mFrameLayout.addView(mLayout);

       // setContentView(mFrameLayout);


        mVideoView.setMediaController(mediaController);
        setVideoAreaSize();
        mVideoView.setVideoViewCallback(this);


        // mediaController.setMediaPlayer(mVideo);
        // mVideo.requestFocus();
        // // MediaController mediaController = new MyMediaController(reactContext, true);
        // // mediaController.setAnchorView(videoView);
        // mVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
        //     @Override
        //     public void onPrepared(MediaPlayer mp) {
        //         mediaController.show();
        //         mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
        //             @Override
        //             public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        //                 /*
        //                  * add media controller
        //                  */

        //                 mVideo.setMediaController(mediaController);
        //                 /*
        //                  * and set its position on screen
        //                  */
        //                 mediaController.setAnchorView(mVideo);
        //             }
        //         });
        //     }
        // });

        // mVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() {
        //     @Override
        //     public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
        //         return false;
        //     }
        // });

        // mVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
        //     @Override
        //     public void onCompletion(MediaPlayer mediaPlayer) {

        //         mediaPlayer.release();
        //     }
        // });


        return mFrameLayout;
    }
    @ReactProp(name="url")
    public void setVideoPath(FrameLayout videoView, String urlPath) {

       // Uri uri = Uri.parse(urlPath);
        if(urlPath.indexOf("http")>-1)
        mVideoView.setVideoPath(VideoProxyManager. getInstance(). getProxyUrl(urlPath));
        else
            mVideoView.setVideoPath(urlPath);

        mVideoView.requestFocus();
        //mVideoView.start();
       // mediaController.setTitle("Big Buck Bunny");
       // setVideoAreaSize(urlPath);
       // mVideoView.setVideoViewCallback(this);
      //  mVideoView.setVideoURI(uri);

    }

}
