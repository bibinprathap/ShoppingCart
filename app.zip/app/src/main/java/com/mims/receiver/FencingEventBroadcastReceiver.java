package com.mims.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.JobIntentService;

import com.mims.service.FecngingEventJobIntentService;

public class FencingEventBroadcastReceiver extends BroadcastReceiver {

    public FencingEventBroadcastReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("FencingEventReceiver", "Broadcasting geofence event");
        JobIntentService.enqueueWork(context, FecngingEventJobIntentService.class, 0, intent);
    }
}