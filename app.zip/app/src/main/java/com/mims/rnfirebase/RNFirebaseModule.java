package com.mims.rnfirebase;

import com.facebook.react.bridge.*;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.bridge.Promise;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.app.Activity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import android.os.Bundle;
import com.mims.R;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;
import android.graphics.PorterDuff;
import android.view.View;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;
import java.util.Calendar;
import android.app.AlarmManager;
import android.app.PendingIntent;
import java.util.Random;
import java.util.Iterator;

import javax.annotation.Nullable;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import androidx.annotation.NonNull;
import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.Date;
import java.lang.System;
import java.lang.Math;
import java.util.UUID;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import android.content.SharedPreferences;

import com.mims.rnfirebase.RNFirebaseJSONConvert;

public class RNFirebaseModule extends ReactContextBaseJavaModule implements LifecycleEventListener {

    private static ReactApplicationContext reactContext = null;
    private static final String EVENTS = "EVENTS";
    private static final String TAG = "RNFirebase";
    private static String lastNotificationId = null;
    public static JSONObject currentNotificationData = null;
    private RNFirebaseBadgeHelper mBadgeHelper;
    private static boolean mIsForeground = false;
    private static final Random randomNumberGenerator = new Random(System.currentTimeMillis());
    private static final String PREFERENCES_FILE = "mimsPreferences";
    private static final String admNotifications = "admNotifications";

    public RNFirebaseModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
        mBadgeHelper = new RNFirebaseBadgeHelper(reactContext.getApplicationContext());
        reactContext.addLifecycleEventListener(this);
    }

    @Override
    public String getName() {
        return "RNFirebase";
    }

    private static String getAllSavedNotifications(Context context) {
        if (context == null) {
            Log.d(TAG, "getAllSavedNotifications context is null");
            return null;
        }
        SharedPreferences sp = (SharedPreferences) context.getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE);
        return sp.getString(admNotifications, null);
    }

    private static void removeAllSavedNotifications(Context context) {
        if (context == null) {
            Log.d(TAG, "removeAllSavedNotifications context is null");
            return;
        }
        SharedPreferences sp = (SharedPreferences) context.getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE);
        sp.edit().remove(admNotifications).commit();
    }

    public void getSavedNotifications() {
        // Gets all saved notifications. Including cancelled ones
        if (reactContext == null) {
            Log.d(TAG, "getSavedNotifications context is null ");
            return;
        }
        String allBackgroundNotifications = getAllSavedNotifications(reactContext.getApplicationContext());
        if (allBackgroundNotifications == null) {
            return;
        }

        try {
            JSONObject notificaions = new JSONObject(allBackgroundNotifications.trim());
            if (notificaions.length() > 0) {
                Iterator<String> keys = notificaions.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    if (notificaions.get(key) instanceof JSONObject) {
                        JSONObject message = (JSONObject) notificaions.get(key);
                        // Log.d(TAG, "******************************************");
                        // Log.d(TAG, "notification: " + message.toString());
                        sendNotificationData(message);
                    }
                }
            }
            removeAllSavedNotifications(reactContext.getApplicationContext());
        } catch (Exception e) {
            Log.d(TAG, "getSavedNotifications " + e.getMessage());
        }
    }

    private static void saveNotification(Context context, String messageId, JSONObject message) {
        if (context == null)
            return;
        SharedPreferences sp = (SharedPreferences) context.getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        String savedMessages = getAllSavedNotifications(context);
        try {
            JSONObject notificaionObj = new JSONObject();
            if (savedMessages == null) {
                notificaionObj.put(messageId, message);
            } else {
                notificaionObj = new JSONObject(savedMessages.trim());
                notificaionObj.put(messageId, message);
                Log.d(TAG, "JSON length " + notificaionObj.length());
            }
            editor.putString(admNotifications, notificaionObj.toString());
            editor.apply();
        } catch (Exception e) {
            Log.d(TAG, "saveNotification " + e.getMessage());
        }

    }

    @ReactMethod
    public void setBadgeNumber(int badgeNumber) {
        mBadgeHelper.setBadgeCount(badgeNumber);
    }

    @ReactMethod
    public void getBadgeNumber(Promise promise) {
        promise.resolve(mBadgeHelper.getBadgeCount());
    }

    @ReactMethod
    public void subscribeToTopic(String topic) {
        FirebaseMessaging.getInstance().subscribeToTopic(topic);
    }

    @ReactMethod
    public void unsubscribeFromTopic(String topic) {
        FirebaseMessaging.getInstance().unsubscribeFromTopic(topic);
    }

    @ReactMethod
    public void deleteInstance() {
        try {
            FirebaseInstanceId.getInstance().deleteInstanceId();
        } catch (Exception e) {
            Log.d(TAG, "Error deleteInstance " + e.getMessage());
        }
    }

    @ReactMethod
    private void clearAllNotifications() {
        try {
            NotificationManager notificationManager = (NotificationManager) reactContext
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancelAll();
            mBadgeHelper.setBadgeCount(0);
        } catch (Exception e) {
            Log.d(TAG, "Error clearAllNotifications " + e.getMessage());
        }
    }

    @ReactMethod
    public void getInitialNotification(Callback callback) {
        Log.d(TAG, "getInitialNotification called");
        try {
            if (currentNotificationData != null) {
                // Log.d(TAG, "getInitialNotification currentNotificationData
                // "+currentNotificationData.toString());
                final WritableMap data = RNFirebaseJSONConvert.jsonToReact(currentNotificationData);
                callback.invoke(null, data);

            } else {
                callback.invoke(null, null);
            }

            // Gets all saved notifications. Including cancelled ones
            getSavedNotifications();

        } catch (Exception e) {
            Log.d(TAG, "Error getInitialNotification " + e.getMessage());
        }
    }

    @ReactMethod
    public void getRegistrationToken(Callback callback) {
        Log.d(TAG, "getRegistrationToken");
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            // Log.w(TAG, "getInstanceId failed", task.getException());
                            callback.invoke("Failed to get token", "");
                            return;
                        }
                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        // Log.d(TAG, token);
                        callback.invoke(null, token);

                    }
                });

    }

    @ReactMethod
    public void localNotification(ReadableMap details) {
        Bundle extras = Arguments.toBundle(details);
        // If notification ID is not provided by the user, generate one at random
        Long timestamp = System.currentTimeMillis();
        if (extras.getString("message_id") == null) {
            extras.putString("message_id", UUID.randomUUID().toString());
        }

        extras.putString("timestamp", timestamp.toString());
        sendNotification(extras, reactContext);

    }

    @ReactMethod
    public void scheduleLocalNotification(ReadableMap details) {

        try {
            Bundle extras = Arguments.toBundle(details);

            int seconds = (int) extras.getDouble("seconds", 0);
            if (seconds == 0) {
                return;
            }

            int requestCode = (int) Math.abs(randomNumberGenerator.nextInt());

            Intent intent = new Intent(reactContext, RNFirebaseBroadcastReceiver.class);

            if (extras.getString("message_id") == null) {
                extras.putString("message_id", UUID.randomUUID().toString());
            }

            intent.putExtras(extras);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(reactContext.getApplicationContext(), requestCode,
                    intent, 0);

            Calendar wakeUpTime = Calendar.getInstance();
            wakeUpTime.add(Calendar.SECOND, seconds);

            AlarmManager alarmManager = (AlarmManager) reactContext.getSystemService(Context.ALARM_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, wakeUpTime.getTimeInMillis(), pendingIntent);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, wakeUpTime.getTimeInMillis(), pendingIntent);
            }

            // Toast.makeText(reactContext, "Alarm set in " + seconds + " seconds",
            // Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(reactContext, e.getMessage(), Toast.LENGTH_LONG).show();
            Log.d(TAG, "Error " + e.getMessage());
        }
    }

    public static void sendNotification(Bundle extras, Context mContext) {

        try {
            Log.d(TAG, "sendNotification");

            // JSONObject messageBody = RNFirebaseJSONConvert.bundleToJSON(extras);
            // android.intent.action.MAIN

            if (extras.getString("title") == null || extras.getString("body") == null) {
                Log.d(TAG, "Empty title or body");
                return;
            }

            Context serviceContext = mContext;
            Intent intent = null;
            if (reactContext != null && reactContext.getCurrentActivity() != null
                    && reactContext.getCurrentActivity().getIntent() != null) {
                intent = reactContext.getCurrentActivity().getIntent();
                serviceContext = reactContext;
            } else if (mContext != null && mContext.getPackageName() != null) {
                serviceContext = mContext;
                String packageName = serviceContext.getPackageName();
                intent = serviceContext.getPackageManager().getLaunchIntentForPackage(packageName);
            } else {
                Log.d(TAG, "Context is not available");
                return;
            }

            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            String channelId = "adm_mims_default_channel";
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            String title = extras.getString("title");
            String body = extras.getString("body");
            int requestCode = (int) randomNumberGenerator.nextInt();
            if (title != null && body != null) {

                intent.putExtras(extras);
                PendingIntent pendingIntent = PendingIntent.getActivity(serviceContext, requestCode /* Request code */,
                        intent, PendingIntent.FLAG_ONE_SHOT);

                NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(serviceContext,
                        channelId).setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(body)
                                .setAutoCancel(true).setPriority(NotificationManager.IMPORTANCE_HIGH)
                                .setSound(defaultSoundUri).setContentIntent(pendingIntent);
                NotificationManager notificationManager = (NotificationManager) serviceContext
                        .getSystemService(Context.NOTIFICATION_SERVICE);
                // Since android Oreo notification channel is needed.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel(channelId, title,
                            NotificationManager.IMPORTANCE_DEFAULT);
                    notificationManager.createNotificationChannel(channel);
                }
                /* param 1: ID of notification */
                notificationManager.notify(requestCode, notificationBuilder.build());
                JSONObject messageBody = RNFirebaseJSONConvert.bundleToJSON(extras);

                String messageId = extras.getString("message_id") != null ? extras.getString("message_id")
                        : extras.getString("google.message_id");

                if (reactContext == null) {
                    Log.d(TAG, "reactContext is null");
                }

                if (messageId != null && reactContext == null) {
                    saveNotification(serviceContext, messageId, messageBody);
                    Log.d(TAG, "Set messages in preference");
                }

                // Show toast
                Handler handler = new Handler(Looper.getMainLooper());
                final Context contextToast = serviceContext;
                handler.post(new Runnable() {
                    public void run() {

                        Toast toast = Toast.makeText(contextToast, title + ". " + body, Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);

                        View view = toast.getView();
                        view.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
                        TextView text = view.findViewById(android.R.id.message);
                        text.setTextColor(Color.BLACK);
                        text.setShadowLayer(0, 0, 0, 0);
                        toast.show();

                    }
                });

                sendNotificationData(messageBody);

            }

        } catch (Exception e) {
            Log.d(TAG, "Error " + e.getMessage());
        }
    }

    public JSONObject getNotificationFromIntent() {
        if (reactContext != null && reactContext.getCurrentActivity() != null
                && reactContext.getCurrentActivity().getIntent() != null
                && reactContext.getCurrentActivity().getIntent().getExtras() != null) {
            Intent intent = reactContext.getCurrentActivity().getIntent();
            JSONObject notificationObj = new JSONObject();
            try {

                String messageId = intent.hasExtra("message_id") ? intent.getExtras().getString("message_id")
                        : intent.getExtras().getString("google.message_id");

                if (messageId == null) {
                    return null;
                }

                if (intent.getExtras().getString("title") == null || intent.getExtras().getString("body") == null) {
                    Log.d(TAG, "Empty title or body");
                    return null;
                }

                Long timestamp = System.currentTimeMillis();
                for (String key : intent.getExtras().keySet()) {
                    String value = intent.getExtras().getString(key);
                    if (value != null) {
                        notificationObj.put(key, value);
                    }
                }

                if (notificationObj != null && notificationObj.length() > 0 && messageId != null) {

                    if (messageId == lastNotificationId) {
                        return null;
                    }

                    notificationObj.put("timestamp", timestamp.toString());
                    // Need to send notification event. Otherwise opening app from tray will not
                    // trigger notify event
                    sendNotificationData(notificationObj);
                    return notificationObj;
                }

            } catch (JSONException e) {
                // e.printStackTrace();
                Log.d(TAG, "getNotificationFromIntent JSON error");
                return null;
            }

        } else {
            Log.d(TAG, "reactContext is not available");
        }
        return null;
    }

    public static void sendNotificationData(JSONObject notificationObj) {

        if (reactContext == null)
            return;
        try {

            if (notificationObj == null)
                return;

            String messageId = notificationObj.has("message_id") ? notificationObj.getString("message_id")
                    : notificationObj.getString("google.message_id");

            if (messageId == null || (lastNotificationId != null && lastNotificationId.equals(messageId))) {
                return;
            }

            Log.d(TAG, "sendNotificationData");
            lastNotificationId = messageId;
            notifyJSONEvent("NOTIFICATION", notificationObj);
        } catch (JSONException e) {
            Log.d(TAG, "sendNotificationData JSON error");
        }
    }

    @Override
    public void onHostResume() {
        // Activity `onResume`
        Log.d(TAG, "onHostResume called");
        mIsForeground = true;
        currentNotificationData = getNotificationFromIntent();
        if (currentNotificationData != null) {
            sendNotificationData(currentNotificationData);
        }
    }

    @Override
    public void onHostPause() {
        // Activity `onPause`
        mIsForeground = false;
        Log.d(TAG, "onHostPause called");
    }

    @Override
    public void onHostDestroy() {
        // Activity `onDestroy`
        Log.d(TAG, "onHostDestroy called");
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<>();
        constants.put(EVENTS, EVENTS);
        return constants;
    }

    /**
     * Notify event
     *
     * @param String  eventCode
     * @param message
     */
    public static void notifyEvent(String eventCode, String message) {
        final WritableMap event = Arguments.createMap();
        event.putString("type", eventCode);
        event.putString("data", message);
        emitDeviceEvent(event);
    }

    /**
     * Notify event
     *
     * @param String eventCode
     * 
     * @param json   object
     * 
     */
    private static void notifyJSONEvent(String eventCode, JSONObject obj) {
        try {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("type", eventCode);
            jsonObj.put("data", obj);
            final WritableMap event = RNFirebaseJSONConvert.jsonToReact(jsonObj);
            emitDeviceEvent(event);
        } catch (Exception e) {
        }
    }

    /**
     * Notify event
     *
     * @param String  eventCode
     * @param Boolean val
     *
     */
    private static void notifyEventBoolean(String eventCode, Boolean val) {
        final WritableMap event = Arguments.createMap();
        event.putString("type", eventCode);
        event.putBoolean("data", val);
        emitDeviceEvent(event);
    }

    private static void emitDeviceEvent(@Nullable WritableMap eventData) {
        if (reactContext != null) {
            reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(EVENTS, eventData);
        }
    }

}