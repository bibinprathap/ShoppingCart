/**
 * Copyright 2016 Google Inc. All Rights Reserved.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mims.rnfirebase;

import android.util.Log;
import java.util.Map;
import java.lang.System;
import android.os.Bundle;
import android.content.Context;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import org.json.JSONException;
import org.json.JSONObject;

import com.mims.rnfirebase.RNFirebaseModule;

/**
 * NOTE: There can only be one service in each app that receives FCM messages.
 * If multiple are declared in the Manifest then the first one will be chosen.
 *
 * In order to make this Java sample functional, you must remove the following
 * from the Kotlin messaging service in the AndroidManifest.xml:
 *
 * <intent-filter> <action android:name="com.google.firebase.MESSAGING_EVENT" />
 * </intent-filter>
 */

public class RNFirebaseService extends FirebaseMessagingService {

    private static final String TAG = "RNFirebase";

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase
     *                      Cloud Messaging.
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // [START_EXCLUDE]
        // There are two types of messages data messages and notification messages. Data
        // messages
        // are handled
        // here in onMessageReceived whether the app is in the foreground or background.
        // Data
        // messages are the type
        // traditionally used with GCM. Notification messages are only received here in
        // onMessageReceived when the app
        // is in the foreground. When the app is in the background an automatically
        // generated
        // notification is displayed.
        // When the user taps on the notification they are returned to the app. Messages
        // containing both notification
        // and data payloads are treated as notification messages. The Firebase console
        // always
        // sends notification
        // messages. For more see:
        // https://firebase.google.com/docs/cloud-messaging/concept-options
        // [END_EXCLUDE]

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ

        Log.d(TAG, "Message data payload received");
        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
            try {

                Bundle extras = new Bundle();
                if (remoteMessage.getNotification() != null) {
                    String title = remoteMessage.getNotification().getTitle();
                    String body = remoteMessage.getNotification().getBody();

                    extras.putString("title", title);
                    extras.putString("body", body);
                }

                extras.putString("google.message_id", remoteMessage.getMessageId());
                extras.putInt("google.original_priority", remoteMessage.getOriginalPriority());
                extras.putInt("google.delivered_priority", remoteMessage.getPriority());
                extras.putString("from", remoteMessage.getFrom());

                Long timestamp = System.currentTimeMillis();
                for (Map.Entry<String, String> entry : remoteMessage.getData().entrySet()) {
                    extras.putString(entry.getKey(), entry.getValue());
                }

                extras.putString("collapse_key", remoteMessage.getCollapseKey());
                extras.putString("timestamp", timestamp.toString());

                increaseBadgeCount();
                RNFirebaseModule.sendNotification(extras, this.getApplication());

            } catch (Exception e) {
                Log.d(TAG, "onMessageReceived error " + e.getMessage());
            }
        }

    }
    // [END receive_message]

    public void increaseBadgeCount() {
        RNFirebaseBadgeHelper badgeHelper = new RNFirebaseBadgeHelper(this);
        try {
            int badgeCount = badgeHelper.getBadgeCount() + 1;
            badgeHelper.setBadgeCount(badgeCount);
        } catch (Exception e) {
            Log.d(TAG, "Badge count needs to be an integer", e);
        }
    }

    // [START on_new_token]

    /**
     * Called if InstanceID token is updated. This may occur if the security of the
     * previous token had been compromised. Note that this is called when the
     * InstanceID token is initially generated so this is where you would retrieve
     * the token.
     */
    @Override
    public void onNewToken(String token) {
        RNFirebaseModule.notifyEvent("FCM_NEW_TOKEN", token);
        Log.d(TAG, "Refreshed token: " + token);
    }
    // [END on_new_token]

}