package com.mims.service;

            import android.Manifest;
            import android.app.NotificationManager;
            import android.app.PendingIntent;
            import android.content.BroadcastReceiver;
            import android.content.Context;
            import android.content.Intent;
            import  android.app.Service;
            import android.content.IntentFilter;
            import android.content.pm.PackageManager;
            import android.net.wifi.WifiInfo;
            import android.net.wifi.WifiManager;
            import android.os.AsyncTask;
            import android.os.BatteryManager;
            import android.os.Build;
            import android.os.IBinder;
            import android.os.ResultReceiver;
            import android.preference.PreferenceManager;
            import android.provider.Settings;
            import android.telephony.TelephonyManager;
            import android.text.format.Formatter;
            import android.util.JsonReader;
            import android.util.Log;

            import androidx.annotation.NonNull;
            import androidx.core.app.ActivityCompat;
            import android.os.Bundle;

            import android.content.SharedPreferences;

            import android.location.Location;
            import android.location.LocationManager;


            import androidx.lifecycle.Lifecycle;

            import com.esri.arcgisruntime.geometry.Geometry;
            import com.esri.arcgisruntime.geometry.GeometryEngine;
            import com.esri.arcgisruntime.geometry.Point;
            import com.esri.arcgisruntime.geometry.PointCollection;
            import com.esri.arcgisruntime.geometry.Polygon;
            import com.esri.arcgisruntime.geometry.SpatialReferences;
            import com.facebook.react.bridge.Arguments;
            import com.facebook.react.bridge.Promise;
            import com.facebook.react.bridge.ReadableArray;
            import com.facebook.react.bridge.WritableMap;
            import com.google.android.gms.common.ConnectionResult;
            import com.google.android.gms.common.api.GoogleApiClient;
            import com.google.android.gms.location.Geofence;
            import com.google.android.gms.location.GeofencingClient;
            import com.google.android.gms.location.GeofencingRequest;
            import com.google.android.gms.location.LocationRequest;
            import com.google.android.gms.location.LocationServices;
            import com.google.android.gms.tasks.OnFailureListener;
            import com.google.android.gms.tasks.OnSuccessListener;
            import com.mims.MainActivity;
            import com.mims.MainApplication;
            import com.mims.receiver.FencingEventBroadcastReceiver;
            import com.mims.uploader.UploaderModule;

            import org.json.JSONArray;
            import org.json.JSONException;
            import org.json.JSONObject;

            import java.io.InputStream;
            import java.io.InputStreamReader;
            import java.io.OutputStreamWriter;
            import java.net.HttpURLConnection;
            import java.net.InetAddress;
            import java.net.NetworkInterface;
            import java.net.URL;
            import java.text.DateFormat;
            import java.text.SimpleDateFormat;
            import java.util.ArrayList;
            import java.util.Calendar;
            import java.util.Collections;
            import java.util.Date;
            import java.util.List;


            import javax.annotation.Nullable;
            import javax.net.ssl.HttpsURLConnection;

            import static com.mims.MainActivity.reactContextMain;
             import static com.mims.uploader.UploaderModule.geoCheckData;
            import static com.mims.uploader.UploaderModule.LocationApi;
            import static com.mims.uploader.UploaderModule.enableGeofence;
            public class LocationService extends Service implements GoogleApiClient.ConnectionCallbacks,
                    GoogleApiClient.OnConnectionFailedListener {
                private static final String TAG = "DRIVER";
                private LocationManager mLocationManager = null;
                private static final int LOCATION_INTERVAL = 30000;
                private static final float LOCATION_DISTANCE = 0;
                private double Latitude, Longitude,Altitude,Accuracy,Bearing,Speed;
                private Long Time;
                private String Carrier,BatteryLevel,IpAddress,PhoneNumber,imeiNumber;
                private SharedPreferences pref;
                private String driverId ,uniqueId,appstate ;
                private  boolean geoCheck;
                WifiInfo wifiInfo;
                ResultReceiver receiver;
                private GoogleApiClient mGoogleApiClient;
                // A request to connect to Location Services
                private LocationRequest mLocationRequest;

                private LocationListener locationListener;
                private String bateria = "Nada";


//              public static LocationService getInstant(){
//                     return mInstant;
//                 }

                public static final String ON_ENTER = "onEnter";
                public static final String ON_EXIT = "onExit";
                private GeofencingClient mGeofencingClient;
                private PendingIntent mBoundaryPendingIntent;
                public static final String GEOFENCE_DATA_TO_EMIT = "com.mims.uploader.GEOFENCE_DATA_TO_EMIT";
                /*
                * Recupera nível de bateria
                */
                private BroadcastReceiver BatInfoReceiver = new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context arg0, Intent intent) {

                        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

                        float batteryPct = level / (float)scale;

                        bateria = String.valueOf(batteryPct);
                    }
                };
                private class LocationListener implements
                        com.google.android.gms.location.LocationListener {

                    public LocationListener() {
                    }

                    @Override
                    public void onLocationChanged(Location location) {
                        Log.e(TAG, "onLocationChanged: " + location);
                        Latitude = location.getLatitude();
                        Longitude = location.getLongitude();
                        Altitude = location.getAltitude();
                        Accuracy = location.getAccuracy();
                        Bearing = location.getBearing();
                        Speed = location.getSpeed();
                        Time = location.getTime();



                    }


                }


                @Override
                public IBinder onBind(Intent arg0) {
                    return null;
                }

                @Override
                public int onStartCommand(Intent intent, int flags, int startId) {
                    Log.e(TAG, "onStartCommand");
                    Log.e(TAG,  "onStartCommand currentLat" + String.valueOf(  Latitude ));
                    Log.e(TAG, "onStartCommand currentLng" + String.valueOf(Longitude));

                    if(intent != null)
                    {
                        uniqueId =  intent.getStringExtra("uniqueId");
                       // geoCheckData =   intent.getStringExtra("geoCheckDatanew");
                        receiver = intent.getParcelableExtra("receiverTagnew");
                        appstate  = intent.getStringExtra("appstate");
                    }
                    this.registerReceiver(this.BatInfoReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                    //  WritableMap params = Arguments.createMap();
                    // params.putString("currentLocation", "Locationevery15minit");

                    //params.putBoolean("geoCheck",  this.geoFencingCheck(geoCheckData,response.getLatitude(),response.getLongitude()));
                    //   Log.d("geoCheck1", "findCurrentPlaceWithPermissions: "+geoCheckData);

                    // if (reactContextMain != null)
                    //   params.putString("uniqueId",  Settings.Secure.getString(reactContextMain.getContentResolver(), Settings.Secure.ANDROID_ID));


                    // if (reactContextMain != null &&
                    //          (reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED ||
                    //                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) ||
                    //               (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && reactContextMain.checkCallingOrSelfPermission(Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED))) {
                    //   TelephonyManager telMgr = (TelephonyManager) reactContextMain.getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                    //    params.putString("phoneNumber", telMgr.getLine1Number());
                    //} else {
                    //     params.putString("phoneNumber", null);
                    // }
                    // MainActivity.preferences.getString( "", "" );
                    super.onStartCommand(intent, flags, startId);
                    if(!(Latitude>0))
                    {
                        startLocationUpates();
                        return START_STICKY;
                    }
                    //  Carrier =  this.getCarrier();
                    //  BatteryLevel =  Float.toString(this.getBatteryLevel());
                    SharedPreferences preferences = getSharedPreferences ("uploaderid",MODE_MULTI_PROCESS);
                    IpAddress =  this.getIPAddress(true);

                    // SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);


                    String url=(String)preferences.getAll().get("LocationApi")==null? LocationApi:(String)preferences.getAll().get("LocationApi")  ;
                    String userID=(String) preferences.getAll().get("userId");
              //      String geoCheckData=(String) preferences.getAll().get("geoCheckData");


                    geoCheck =  this.geoFencingCheck(geoCheckData,Latitude,Longitude);

                    if(url != null)
                    {



                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run()  {

                                try {
                                    URL Endpoint = new URL(url);
                                    Log.e("onStartCommand"  , url);
            // Create connection
                                    HttpURLConnection myConnection = (HttpURLConnection) Endpoint.openConnection();
            //setting request properties and method type
                                    myConnection.setRequestProperty("Content-Type", "application/json");
                                    myConnection.setRequestMethod("POST");
                                    // myConnection.setRequestProperty("User-Agent", "my-rest-app-v0.1");
                                    //  myConnection.setRequestProperty("Accept",    "application/vnd.github.v3+json");
                                    //  myConnection.setRequestProperty("InspectionId",    "hathibelagal@example.com");
            //                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            //                            != PackageManager.PERMISSION_GRANTED)
            //                    TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
            //                    context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
            //                  String imeiNumber=  telephonyManager.getDeviceId();

                                    //DateTime
                                    Date dateTime = new Date(Time);
                                    DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                                   // df.setTimeZone();
                                    String dateTimeString =df.format(dateTime);
                                    JSONObject params = new JSONObject();

                                    params.put("imei",  imeiNumber);
                                    params.put("batteryLevel",  bateria);
                                    params.put("geoCheck",    Boolean.toString(geoCheck));
                                    params.put("ipAddress",   IpAddress);
                                    params.put("gsmCarrier",  Carrier);
                                    params.put("phoneNumber",   PhoneNumber);
                                    if(appstate != null && !appstate.isEmpty())
                                        params.put("appState",   appstate);
                                    else
                                        params.put("appState",   "unknown");
                                    params.put("gpsTime",dateTimeString);
                                    params.put("loggedInUserID", userID);
                                    params.put("latitude", Double.toString(Latitude));
                                    params.put("longitude", Double.toString( Longitude ));
                                    params.put("accuracy", Double.toString(Accuracy));
                                    params.put("speed", Double.toString(Speed));
                                    params.put("bearing", Double.toString(Bearing));

                                    Bundle bundle = new Bundle();
                                    bundle.putBoolean("geoCheck", geoCheck);
                                    bundle.putString("latitude", Double.toString(Latitude));
                                    bundle.putString("longitude", Double.toString( Longitude ));
                                    bundle.putString("altitude", Double.toString(Altitude));
                                    bundle.putString("accuracy", Double.toString(Accuracy));
                                    bundle.putString("bearing", Double.toString(Bearing));
                                    bundle.putString("speed", Double.toString(Speed));
                                    bundle.putString("timestamp",  dateTimeString);
                                    bundle.putString("deviceId", Build.BOARD);
                                    bundle.putString("serialNumber",  Build.SERIAL);
                                    bundle.putString("systemName",  "Android");
                                    bundle.putString("systemVersion",Build.VERSION.RELEASE);
                                    bundle.putString("carrier",  Carrier);
                                    bundle.putString("batteryLevel",  bateria);
                                // bundle.putB("geoCheck",    Boolean.toString(geoCheck));
                                    bundle.putString("ipAddress",   IpAddress);
                                    bundle.putString("phoneNumber",   PhoneNumber);
                                    bundle.putString("appState",   appstate);
                                    bundle.putString("uniqueId",   uniqueId);
                                    if(receiver!=null)
                                        receiver.send(0, bundle);


                                    OutputStreamWriter out = new   OutputStreamWriter(myConnection.getOutputStream());
                                    out.write(params.toString());
                                    out.close();

                                    if (myConnection.getResponseCode() == 200) {
            // Success
            // Further processing here
                                        InputStream responseBody = myConnection.getInputStream();
                                        InputStreamReader responseBodyReader =new InputStreamReader(responseBody, "UTF-8");
                                        JsonReader jsonReader = new JsonReader(responseBodyReader);
                                        jsonReader.beginObject(); // Start processing the JSON object
                                        while (jsonReader.hasNext()) {
                                            String key = jsonReader.nextName();
                                            if (key.equals("organization_url")) {

                                                String value = jsonReader.nextString();


                                                // Do something with the value
                                                // ...

                                                break; // Break out of the loop
                                            } else {
                                                jsonReader.skipValue(); // Skip values of other keys
                                            }
                                        }
                                        jsonReader.close();

                                    } else {
            // Error handling code goes here
                                    }
                                    myConnection.disconnect();
                                }
                                catch (Exception e){
                                    Log.d("exception", "run: "+e);
                                }
                            }
                        });

                        // boolean stopService = false;
                        // if (intent != null)
                        //   stopService = intent.getBooleanExtra("stopservice", false);

                        // System.out.println("stopservice " + stopService);

                    }

                    return START_STICKY;
                }

                public boolean geoFencingCheck(String polygonJson, Double latitude, Double longitude){
                    JSONObject polygons;
                    Log.d("geoFencingCheck", "geoFencingCheck: "+polygonJson);
                    boolean contains=false;
                    try {
                        if(polygonJson != null) {
                            Geometry currentLocationGeometry = new Point(longitude, latitude, SpatialReferences.getWgs84());

                            polygons = new JSONObject(polygonJson);

                            JSONArray polygonsJSONArray = polygons.getJSONArray("polygons");
                            for (int i = 0; i < polygonsJSONArray.length(); i++) {
                                if(!contains ) {
                                    JSONObject polygon = polygonsJSONArray.getJSONObject(i);

                                    JSONArray pointsJSONArray = polygon.getJSONArray("coords");
                                    PointCollection polygonPoints = new PointCollection(SpatialReferences.getWgs84());
                                    for (int j = 0; j < pointsJSONArray.length(); j++) {

                                        JSONObject coords = pointsJSONArray.getJSONObject(j);
                                        Double latitude1 = coords.getDouble("latitude");
                                        Double longitude1 = coords.getDouble("longitude");
                                        polygonPoints.add(new com.esri.arcgisruntime.geometry.Point(longitude1, latitude1));


                                    }
                                    Polygon shape = new Polygon(polygonPoints);

                                    contains = (GeometryEngine.contains(shape, currentLocationGeometry) || GeometryEngine.touches(shape, currentLocationGeometry));
                                    //                boolean crosses =GeometryEngine.crosses(shape,currentLocationGeometry);
                                    //                boolean intersects=	GeometryEngine.intersects(shape,currentLocationGeometry);
                                    //                boolean overlap=	GeometryEngine.overlaps(shape,currentLocationGeometry);
                                    //                boolean touches=GeometryEngine.touches(shape,currentLocationGeometry);
              
                                    if(enableGeofence && contains)
                                     {
                                       JSONArray checkPointsJSONArray = polygon.getJSONArray("checkPoints");
                                       add(checkPointsJSONArray);
                                    }
                                }
                            }

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    return  contains ;
                }


                public void removeAll() {
                    mGeofencingClient.removeGeofences(getBoundaryPendingIntent())
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.i(TAG, "Successfully removed all geofences");

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.i(TAG, "Failed to remove all geofences");

                                }
                            });
                }
                public void add(JSONArray jsonArray) {//final ReadableMap readableMap, final Promise promise
            //        final GeofencingRequest geofencingRequest = createGeofenceRequest(createGeofence());
            //        addGeofence( geofencingRequest, geofencingRequest.getGeofences().get(0).getRequestId());

                    removeAll();
                    GeofencingRequest geofencingRequest = createGeofenceRequest(createGeofences(jsonArray));

                    addGeofence( geofencingRequest);
                }

                private List<Geofence> createGeofences(JSONArray jsonArray) {
                    List<Geofence> geofences = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); ++i) {
                        try {
                            geofences.add(createGeofence(jsonArray.getJSONObject(i)));
                        }
                        catch (Exception ex){

                        }
                    }
                    return geofences;
                }
                private Geofence createGeofence(JSONObject coords) throws Exception {


                //
                    //24.489132, 54.380323
                    //24.487815, 54.378281 ADM
                    return new Geofence.Builder()
                            .setRequestId(coords.getString("Id"))
                            .setCircularRegion(coords.getDouble("latitude"), coords.getDouble("longitude"), (float) 500)
                            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT)
                            //.setLoiteringDelay (2000)
                            .setExpirationDuration(Geofence.NEVER_EXPIRE)
                            .build();
                }

                private GeofencingRequest createGeofenceRequest(List<Geofence> geofences) {
                    return new GeofencingRequest.Builder()
                            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
                            .addGeofences(geofences)
                            .build();
                }
                private void addGeofence( final GeofencingRequest geofencingRequest) {
            //        int permission = ActivityCompat.checkSelfPermission(getReactApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
            //
            //
            //        if (permission != PackageManager.PERMISSION_GRANTED) {
            //            permission = requestPermissions();
            //        }
            //
            //        if (permission != PackageManager.PERMISSION_GRANTED) {
            //            promise.reject("PERM", "Access fine location is not permitted. Hello");
            //        } else {
                    Log.i(TAG, "Attempting to add geofence.");

                    mGeofencingClient.addGeofences(
                            geofencingRequest,
                            getBoundaryPendingIntent()
                    )
                            .addOnSuccessListener(aVoid -> {
                                Log.i(TAG, "Successfully added geofence.");
            //                            promise.resolve(requestId);
                            })
                            .addOnFailureListener(e -> {
                                Log.i(TAG, "Failed to add geofence.");
            //                            promise.reject(e);
                            });
                    // }
                }
                private PendingIntent getBoundaryPendingIntent() {
                    if (mBoundaryPendingIntent != null) {
                        return mBoundaryPendingIntent;
                    }
                    Intent intent = new Intent(getApplicationContext(), FencingEventBroadcastReceiver.class);
                    mBoundaryPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                    return mBoundaryPendingIntent;
                }




                public  String getIPAddress(boolean useIPv4) {
                    try {
                        List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
                        for (NetworkInterface intf : interfaces) {
                            List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                            for (InetAddress addr : addrs) {
                                if (!addr.isLoopbackAddress()) {
                                    String sAddr = addr.getHostAddress();
                                    //boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
                                    boolean isIPv4 = sAddr.indexOf(':')<0;

                                    if (useIPv4) {
                                        if (isIPv4)
                                            return sAddr;
                                    } else {
                                        if (!isIPv4) {
                                            int delim = sAddr.indexOf('%'); // drop ip6 zone suffix
                                            return delim<0 ? sAddr.toUpperCase() : sAddr.substring(0, delim).toUpperCase();
                                        }
                                    }
                                }
                            }
                        }
                    } catch (Exception ignored) { } // for now eat exceptions
                    return "";
                }







                @Override
                public void onCreate() {

                    this.mGeofencingClient = LocationServices.getGeofencingClient(getApplicationContext());
                    Log.e(TAG, "onCreate");
                    pref = getSharedPreferences("driver_app", MODE_PRIVATE);
                    driverId = pref.getString("driver_id", "");
                    mGoogleApiClient = new GoogleApiClient.Builder(this)
                            .addApi(LocationServices.API).addConnectionCallbacks(this)
                            .addOnConnectionFailedListener(this).build();
                    locationListener = new LocationListener();
                    if (!mGoogleApiClient.isConnected())
                        mGoogleApiClient.connect();
                    try{
                        TelephonyManager telMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
                        // boolean check=  hasPhoneStatePermission(getBaseContext());


            //              if(check) {
                        checkPermission(Manifest.permission.READ_PHONE_STATE,0, 1);
                        Carrier = telMgr.getNetworkOperatorName();

                        PhoneNumber = telMgr.getLine1Number();
                        imeiNumber = telMgr.getImei();
                        // }
                    }
                    catch (Exception ex)
                    {
                        ex.printStackTrace();
                    }




                }


                public static boolean hasPhoneStatePermission(Context context) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                        return (context.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED);
                    }

                    else
                        return true;
                }


                @Override
                public void onDestroy() {
                    Log.e(TAG, "onDestroy");
                    super.onDestroy();
                }

                public void stopLocationUpdates() {
                    LocationServices.FusedLocationApi.removeLocationUpdates(
                            mGoogleApiClient, locationListener);

                    if (mGoogleApiClient.isConnected())
                        mGoogleApiClient.disconnect();
                }


                @Override
                public void onConnectionFailed(ConnectionResult arg0) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onConnected(Bundle arg0) {
                    // TODO Auto-generated method stub
                    mLocationRequest = LocationRequest.create();
                    mLocationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                    mLocationRequest.setInterval(35000);
                    mLocationRequest.setFastestInterval(30000);
                    Log.e(TAG, "onConnected");
                    startLocationUpates();
                }
                private void startLocationUpates() {
                    try
                    {
                        LocationServices.FusedLocationApi.requestLocationUpdates(
                                mGoogleApiClient, mLocationRequest, locationListener);
                    }
                    catch (Exception ex)
                    {

                    }

                }


                @Override
                public void onConnectionSuspended(int arg0) {
                    // TODO Auto-generated method stub

                }

            }

            //creating the service class
            // public class LocationService extends HeadlessJsTaskService {
            //     @Nullable
            //     protected HeadlessJsTaskConfig getTaskConfig(Intent intent) {
            //         Bundle extras = intent.getExtras();
            //      //   WritableMap data = extras != null ? Arguments.fromBundle(extras) : null;
            //        // WritableMap data = extras != null ? Arguments.fromBundle(extras) : Arguments.createMap();
            //       //  data.putString("headlesstask", "bactoryinfoand carrior");
            //       return new HeadlessJsTaskConfig(
            //                 "LogLocation", //JS function to call
            //                 extras != null ? Arguments.fromBundle(extras) : null,
            //                 5000,
            //                 true);
            //     }
            // }