import { I18nManager, StyleSheet } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { DefaultTheme } from 'react-native-paper';
/*import this only one time in the app entry point, such as "app/index.js"*/

EStyleSheet.build({
    $sideNavWidth: 60,
    $dashboardNavWidth: 100,

    $primaryFontHeading: I18nManager.isRTL ? 'AraESNawarRegular' : 'Gibson',
    $primaryFontNormal: I18nManager.isRTL ? 'HelveticaNeueLTArabicRoman' : 'Gibson',

    $primaryWhite: '#FFFFFF',
    $primaryBorderColor: '#CFD0D3',
    $primaryDividerLightColor: '#F7F7FA',
    $primaryValidationBackGroundColor: '#f5dcdc',
    $primaryValidationChipColor: '#f1caca',
    $primaryDividerDarkColor: '#454F63',
    $primaryLightBorder: '#DFE6ED',
    $primaryBorderThin: StyleSheet.hairlineWidth,
    $primaryBorderThick: StyleSheet.hairlineWidth * 2,

    //main header
    $primaryHeaderColor: '#058DFC',

    //sidenav
    $selectedItemBackgroundColor: '#3D4257',

    //screen and components background colors
    $primaryLightBackground: '#F7F7FA',
    $primaryDarkBackground: '#2A2E43',
    $primaryMediumBackground: '#F4F8FC',
    $primarySelectedItem: '#3ACCE1',

    //Chip style
    $chipBackground: '#edeef0',

    //input controls
    $primaryLightInputBackground: '#FAFAFC',
    $primaryLightPlaceholderColor: '#959DAD',
    $primaryInvalidBorderColor: '#F55E64',
    $primaryDarkInputBackground: '#454F63',
    $primaryDarkPlaceholderColor: '#959DAD',

    //Push Notifcation
    $nofificationCounterBackground: '#F55E64',
    $nofificationCounterText: '#FFFFFF',
    $nofificationsUnreadItem: '#f6eeee',

    //buttons
    $primaryLightButtonBackground: '#3ACCE1',
    $primaryDarkButtonBackground: '#665EFF',
    $primaryDarkIconbuttonBackground: '#BBC1C9',
    $primaryYesButtonBackground: '#3ACCE1',
    $primaryNoButtonBackground: '#F23B6C',
    $primaryNotApplicableButtonBackground: '#78849E',
    $primaryDisabledButtonBackground: '#cccccc',

    //text
    $primaryLightTextColor: '#FFFFFF',
    $primaryMediumTextColor: '#959DAD',
    $primaryDarkTextColor: '#454F63',
    $primarySelectedTextColor: '#349EFB',
    $primaryErrorTextColor: '#FF0000',
    $primarySuccessTextColor: '#62b42c',
    $primaryMandatoryTextBackground: '#f382a0',
    $primaryTextXS: 12,
    $primaryTextXSM: 14,
    $primaryTextSM: 18,
    $primaryTextMD: 22,
    $primaryTextLG: 28,
    $primaryTextXL: 34,

    //tabs
    $primaryIndicatorColor: '#FFB900',

    $globalButtonHeight: 40,
    //$outline: 1,
});

export const theme = {
    ...DefaultTheme,
    roundness: 8,
    colors: {
        text: EStyleSheet.value('$primaryDarkTextColor'),
        placeholder: EStyleSheet.value('$primaryLightPlaceholderColor'),
    },
    fonts: {
        regular: EStyleSheet.value('$primaryFontNormal'),
        medium: EStyleSheet.value('$primaryFontNormal'),
        light: EStyleSheet.value('$primaryFontNormal'),
        thin: EStyleSheet.value('$primaryFontNormal'),
    },
};

export const dialogTheme = {
    ...DefaultTheme,
    roundness: 8,
    colors: {
        primary: EStyleSheet.value('$primaryDarkTextColor'),
        accent: EStyleSheet.value('$primaryMediumTextColor'),
        background: EStyleSheet.value('$primaryWhite'),
        surface: EStyleSheet.value('$primaryWhite'),
        text: EStyleSheet.value('$primaryDarkTextColor'),
        disabled: EStyleSheet.value('$primaryLightPlaceholderColor'),
        placeholder: EStyleSheet.value('$primaryLightPlaceholderColor'),
        //backdrop: EStyleSheet.value('$primaryDarkTextColor'),
    },
    fonts: {
        regular: EStyleSheet.value('$primaryFontNormal'),
        medium: EStyleSheet.value('$primaryFontNormal'),
        light: EStyleSheet.value('$primaryFontNormal'),
        thin: EStyleSheet.value('$primaryFontNormal'),
    },
};

console.log('Root extended stylesheet is ready.');
