import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text } from 'react-native';
import { localeProperty, strings } from 'app/config/i18n/i18n';
import { createForm, createReadOnlyView } from 'app/components/Form';
import styles from './styles';
import formConfigTemplate from './config';
import AppApi from 'app/api/real';
const api = new AppApi();

//Todo: Integrate with DED
class CompanyInfoForm extends Component {
    static propTypes = {
        formName: PropTypes.string,
        formTitle: PropTypes.string,
        onFormChange: PropTypes.func,
        onFieldChange: PropTypes.func,
        values: PropTypes.object,
    };

    state = { integrationData: { running: false } };
    constructor(props) {
        super(props);

        this.formConfig = {
            ...formConfigTemplate,
            name: props.formName,
            titleA: props.formTitle ? props.formTitle : formConfigTemplate.titleA,
            titleE: props.formTitle ? props.formTitle : formConfigTemplate.titleE,
            onInit: this.handleOnInit,
            editable: props.editable,
            readOnly: props.readOnly ? props.readOnly : formConfigTemplate.readOnly,
            validations: props.validations,
        };
        this.form = createForm(this.formConfig, props.values, this.handleFormChange, this.handleFieldChange);
    }

    handleOnInit = formProps => {
        this.formProps = formProps;
    };

    handleFormChange = (values, dispatch, props, previousValues) => {
        if (this.props.onFormChange) this.props.onFormChange(values, dispatch, props, previousValues, this.props);
    };

    handleFieldChange = async (event, newValue, previousValue, name) => {
        if (newValue === previousValue) return;
        if (name == 'tradeLicenseNumber') {
            this.setState({ integrationData: { running: true, message: strings('integrationProgressMessageDED') } });
            try {
                //todo: show loading spinner in companyName field
                this.formProps.change('phoneNumber', '');
                this.formProps.change('companyNameA', '');
                this.formProps.change('companyNameE', '');
                const result = await api.getCompanyProfile('CN-' + newValue);
                this.formProps.change('phoneNumber', result.phoneNumber || '');
                this.formProps.change('companyNameA', result.customerNameA || '');
                this.formProps.change('companyNameE', result.customerNameE || '');
                this.setState({ integrationData: { running: false, success: true, message: strings('integrationSuccessMessageDED') } });
                /*
                todo: hide the spinner and disable the companyName field because 
                      API call was a success, whatever name has been returned by
                      the API is the correct name
                */
            } catch (e) {
                if (!e.isCancel) {
                    this.formProps.change('phoneNumber', '');
                    this.formProps.change('companyNameA', '');
                    this.formProps.change('companyNameE', '');
                    this.setState({
                        integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageDED') },
                    });
                    /*
                todo: if license number is invalid, set error on licenseNumber
                      if it is network error, or exception on the server, then 
                      enable the company name field so user can enter value directly.
                */
                    console.log('Error in getCompanyProfile', { e });
                }
            }
        }
        //pass on to the host control
        if (this.props.onFieldChange) {
            this.props.onFieldChange(this.formProps, event, newValue, previousValue, name);
        }
    };

    render = () => {
        const TheForm = this.form;

        return (
            <TheForm
                formProps={this.props.formProps}
                values={this.props.values}
                editable={this.props.editable}
                integrationData={this.state.integrationData}
                validations={this.props.validations}
            />
        );
    };
}

export default CompanyInfoForm;
