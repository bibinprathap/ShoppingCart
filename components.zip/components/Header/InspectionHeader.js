import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, I18nManager } from 'react-native';
import { connect } from 'react-redux';
import { Button, Appbar, Text } from 'react-native-paper';
import { DrawerActions } from 'react-navigation-drawer';
import _ from 'lodash';
import { checkDuplicate } from 'app/actions/inspections';
import { DuplicateChecker } from 'app/components/DuplicateChecker';
import { subRoutesWithOwnHeader } from 'app/config/routs/inspection';
import { inspectionStackDefinition } from 'app/config/routs/defs';
import { inspectionsHelper } from 'app/api/helperServices';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';

class InspectionHeader extends Component {
    static propTypes = {
        navigation: PropTypes.object.isRequired,
        local: PropTypes.string,
        isRtl: PropTypes.bool,
        currentInspection: PropTypes.object,
        services: PropTypes.array,
    };

    /*Todo:  checkingDuplicate will come from store, and handleCheckDuplicate should dispatch an action*/
    //state = { checkingDuplicate: false };

    handleCheckDuplicate = () => {
        const { dispatch, navigation, currentInspection } = this.props;
        dispatch(checkDuplicate());
        //const { checkingDuplicate } = this.state;
        //this.setState({ checkingDuplicate: !checkingDuplicate });
    };

    constructor(props) {
        super(props);
    }

    goBack = () => {
        // if (this.props.navigation.state.index == 0) {
        //     this.props.navigation.navigate('main');
        // } else {
        //     this.props.navigation.pop();
        // }
        this.props.navigation.navigate(this.previousRouteName);
    };

    goForward = () => {
        this.props.navigation.navigate(this.nextRouteName);

        // if (!!this.nextRoute && !!this.nextRoute.key)
        //     this.props.navigation.push(this.nextRoute.key);
    };

    render() {
        /*
        Todo: Need a proper fix for this. Attachments screen is in nested stack of inspectionStackNavigator.
              We don't want to show two headers when attachments screen is visible.
        */
        //if (_.includes(subRoutesWithOwnHeader, this.props.scene.route.routeName)) return null;
        if (subRoutesWithOwnHeader.indexOf(this.props.scene.route.routeName) > -1) return null;
        //if(this.props.scene.route.routeName == 'attachments') return null;
        const { navigation, scene, currentInspection, services } = this.props;
        // let selectedService = _.find(services, { serviceId: currentInspection.inspection.service });
        const duplicateCheck = currentInspection.inspection.duplicateCheck || {};
        const adjustedRoutes = inspectionsHelper.getRoutes();
        const currentRouteName = this.props.scene.route.routeName;
        this.currentRouteIndex = _.findIndex(adjustedRoutes, {
            key: currentRouteName,
        });
        this.currentRoute = _.find(adjustedRoutes, {
            key: currentRouteName,
        });
        this.nextRoute = null;
        this.nextRouteName = null;
        this.previousRouteName = 'main';
        const totalRoutes = adjustedRoutes.length;
        if (this.currentRouteIndex < totalRoutes - 1) {
            this.nextRoute = adjustedRoutes[this.currentRouteIndex + 1];
            this.nextRouteName = this.nextRoute.key;
        }
        if (this.currentRouteIndex > 0) {
            const previousRoute = adjustedRoutes[this.currentRouteIndex - 1];
            if (!!previousRoute && !!previousRoute.key) this.previousRouteName = previousRoute.key;
        }

        // console.log(
        //     `InspectionHeader.render(${this.props.scene.route.routeName})
        //     currentRoute = ${!!this.currentRoute ? this.currentRoute.key : ''},
        //     currentRouteIndex = ${this.currentRouteIndex},
        //     nextRoute = ${this.nextRouteName},
        //     previousRoute = ${this.previousRouteName}`
        // );

        const title = scene.descriptor.options.title;
        const inspectionTitle = inspectionsHelper.getLongTitle(currentInspection, true, services);
        return (
            <Appbar style={styles.appBar}>
                <View style={styles.startContainer}>
                    <Appbar.BackAction onPress={this.goBack} color={styles.icon.color} />
                    <Appbar.Content
                        title={title}
                        subtitle={inspectionTitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                </View>
                <DuplicateChecker checkingDuplicate={duplicateCheck.checking} checkDuplicate={this.handleCheckDuplicate} />
                <View style={styles.endContainer}>
                    {!!this.nextRouteName && (
                        <Appbar.Action icon={I18nManager.isRTL ? 'arrow-back' : 'arrow-forward'} onPress={this.goForward} color={styles.icon.color} />
                    )}
                </View>
            </Appbar>
        );
    }
}

mapStateToProps = state => {
    const currentInspection = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        locale: state.settings.locale,
        isRtl: state.settings.isRtl,
        currentInspection,
        services: state.masterdata.services,
    };
};

export default connect(mapStateToProps)(InspectionHeader);
