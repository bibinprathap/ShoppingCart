import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableNativeFeedback, I18nManager } from 'react-native';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings, localeProperty, formatCurrency } from 'app/config/i18n/i18n';
import commonStyles from 'app/components/Preview/styles';
import { CustomAccordion } from 'app/components/CustomAccordion';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { ChecklistQuestionCameraComment } from '../ChecklistQuestionCameraComment';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload

class CheckListUnAssignedSummary extends Component {
    static propTypes = {
        items: PropTypes.any,
    };
    renderViolatorsTitle = props => {
        const { items } = props;
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading]}>
                    {strings('unAssignedViolations')} ({items ? items.length : 0})
                </Text>
            </View>
        );
    };
    handleAttachmentPressed = attachments => {
        this.props.navigation.navigate('attachments', {
            attachments: attachments,
            editable: this.props.editable,
        });
    };
    render() {
        const { items, validations } = this.props;

        return (
            <React.Fragment>
                <View style={[styles.violatorCardOuter, styles.errorBorder]}>
                    <CustomAccordion index="1" renderHeaderTitle={this.renderViolatorsTitle} items={items} expandedAtStart={true}>
                        {items.map(checklistItem => {
                            const {
                                attachments,
                                remarks,
                                violationAmount,
                                selectedPeriod,
                                selectedPeriodType,
                                selectedActionType,
                            } = checklistItem.item;
                            let finalVolationAmount = checklistItem.lawClause
                                ? inspectionsHelper.getViolationAmount({
                                      lawClauseIDs: [checklistItem.lawClause.clauseId],
                                      occurance: 1,
                                      discount: 0,
                                  })
                                : violationAmount;
                            return (
                                <ChecklistQuestionCameraComment
                                    iconClass="change-history"
                                    iconColor="#000000"
                                    remarks={remarks}
                                    attachments={attachments}
                                    validations={[' ']}
                                    secondLine={
                                        checklistItem.lawClause
                                            ? localeProperty(checklistItem.lawClause, 'description')
                                            : localeProperty(checklistItem.itemDef, 'question')
                                    }
                                    question={
                                        <View style={styles.violationAmountContainer}>
                                            {selectedActionType == 'violations' ? (
                                                <Text style={styles.violationAmount}>{formatCurrency(finalVolationAmount)}</Text>
                                            ) : selectedPeriodType == 'day' || selectedPeriodType == 'hour' ? (
                                                <>
                                                    <Icon name="access-time" size={25} style={styles.icon} />
                                                    <Text style={styles.violationAmount}>{selectedPeriod + ' ' + strings(selectedPeriodType)}</Text>
                                                </>
                                            ) : null}
                                        </View>
                                    }
                                />
                            );
                        })}
                        {validations.unAssignedItems ? (
                            <Text style={[commonStyles.ValidationMessageText, styles.violationSummaryHeadingContainer]}>
                                {validations.unAssignedItems}
                            </Text>
                        ) : null}

                        <View style={styles.violatorOuter} />
                    </CustomAccordion>
                </View>
            </React.Fragment>
        );
    }
}

export default CheckListUnAssignedSummary;
