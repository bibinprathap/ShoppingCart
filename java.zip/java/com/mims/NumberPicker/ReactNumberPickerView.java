package com.mims.NumberPicker;

import android.content.Context;
import android.widget.NumberPicker;

public class ReactNumberPickerView extends NumberPicker {

    public ReactNumberPickerView(Context context) {
        super(context);
        setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
    }
}