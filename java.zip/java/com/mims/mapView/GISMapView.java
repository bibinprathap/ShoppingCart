package com.mims.mapView;


import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import android.graphics.Color;

import java.util.Arrays;
import java.util.List;

import com.esri.arcgisruntime.geometry.Envelope;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.layers.ArcGISTiledLayer;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.Basemap;

import com.esri.arcgisruntime.mapping.view.MapView;
import com.esri.arcgisruntime.layers.WebTiledLayer;
import com.esri.arcgisruntime.loadable.LoadStatus;


public class GISMapView extends FrameLayout {

    private static final String TAG = "GISMapView";
    View rootView;
    private MapView mMapView;
    //Create points to add graphics to the map to allow a renderer to style them
    //These are in WGS84 coordinates (Long, Lat)
    Point oldFaithfullPoint = new Point(-110.828140, 44.460458, SpatialReferences.getWgs84());
    Point cascadeGeyserPoint = new Point(-110.829004, 44.462438, SpatialReferences.getWgs84());
    Point plumeGeyserPoint = new Point(-110.829381, 44.462735, SpatialReferences.getWgs84());
    //Use the farthest points to create an envelope to use for the map views visible area
    Envelope initialEnvelope = new Envelope(oldFaithfullPoint, plumeGeyserPoint);

    public   ArcGISMap getMap() {
        return mMapView.getMap();
    }


    public   void setMap() {
        // list of sub-domains
        List<String> subDomains = Arrays.asList("a", "b", "c", "d");

        // build the web tiled layer from stamen
        final WebTiledLayer webTiledLayer = new WebTiledLayer("https://stamen-tiles-{subdomain}.a.ssl.fastly.net/terrain/{level}/{col}/{row}.jpg", subDomains);
        webTiledLayer.loadAsync();
        webTiledLayer.addDoneLoadingListener(() -> {
            if (webTiledLayer.getLoadStatus() == LoadStatus.LOADED) {
            // use web tiled layer as Basemap
                ArcGISMap map = new ArcGISMap(new Basemap("https://david-galindo.maps.arcgis.com/home/item.html?id=fc75f65db9504175b2fb0e87b66672e5"));
                 ArcGISTiledLayer tiledLayer = new ArcGISTiledLayer("https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer");
                 map.getOperationalLayers().add(tiledLayer);
                mMapView.setMap(map);
                // custom attributes
                webTiledLayer.setAttribution("h");
            }
        });
 
    }

    public GISMapView(Context context) {

        super(context);
         rootView = inflate(context.getApplicationContext(),com.mims.R.layout.rnags_mapview,this);
        mMapView = rootView.findViewById(com.mims.R.id.agsMapView);
      //  mMapView= new MapView(context);
        // list of sub-domains
        List<String> subDomains = Arrays.asList("a", "b", "c", "d");

        // build the web tiled layer from stamen
        final WebTiledLayer webTiledLayer = new WebTiledLayer("https://stamen-tiles-{subdomain}.a.ssl.fastly.net/terrain/{level}/{col}/{row}.jpg", subDomains);
        webTiledLayer.loadAsync();
        webTiledLayer.addDoneLoadingListener(() -> {
            if (webTiledLayer.getLoadStatus() == LoadStatus.LOADED) {
                // use web tiled layer as Basemap
                ArcGISMap map = new ArcGISMap(new Basemap("https://david-galindo.maps.arcgis.com/home/item.html?id=fc75f65db9504175b2fb0e87b66672e5"));
                 ArcGISTiledLayer tiledLayer = new ArcGISTiledLayer("https://arcgis.sdi.abudhabi.ae/arcgis/rest/services/Pub/BaseMapEng_LightGray_GCS/MapServer");
                 map.getOperationalLayers().add(tiledLayer);
                mMapView.setMap(map);
                // custom attributes
                webTiledLayer.setAttribution("ss");
            }
        });
       // this.addView(mMapView,params);
      //  this.addView(button1,params);
    }

}
