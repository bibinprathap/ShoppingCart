package com.adm.mims.zebra;

import android.app.Activity;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.content.pm.PackageManager;
//import android.os.Bundle;
//import android.support.v4.app.ActivityCompat;
//import android.support.v4.content.ContextCompat;
import android.util.Log;
//import android.widget.Toast;
import com.facebook.react.bridge.*;
import com.facebook.react.modules.core.DeviceEventManagerModule;
//import org.json.JSONArray;
//import org.json.JSONObject;

import javax.annotation.Nullable;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

// Zebra sdk library
import com.zebra.sdk.comm.BluetoothConnection;
import com.zebra.sdk.comm.Connection;
import com.zebra.sdk.comm.ConnectionException;
import com.zebra.sdk.printer.PrinterLanguage;
import com.zebra.sdk.printer.PrinterStatus;
import com.zebra.sdk.printer.SGD;
import com.zebra.sdk.printer.ZebraPrinter;
import com.zebra.sdk.printer.ZebraPrinterFactory;
import com.zebra.sdk.printer.ZebraPrinterLanguageUnknownException;
import com.zebra.sdk.printer.ZebraPrinterLinkOs;


public class ZebraModule extends ReactContextBaseJavaModule {

  private static ReactApplicationContext reactContext = null;
  private static final String PRINTER_NOTIFICATION = "PRINTER_NOTIFICATION";

  //Zebra variables
  private Connection connection;
  private ZebraPrinter printer;

     public ZebraModule(ReactApplicationContext context) {
         super(context);
         reactContext = context;
     }

     @Override
     public String getName() {
         return "Zebra";
     }

     @Override
     public Map<String, Object> getConstants() {
         final Map<String, Object> constants = new HashMap<>();
         constants.put(PRINTER_NOTIFICATION, PRINTER_NOTIFICATION);
         return constants;
     }

     /**
      *  Notify event
      *
      * @param String eventCode
      *            the event code.
      * @param message
      *       the message.
      */
     private void notifyEvent(String eventCode, String message) {
       final WritableMap event = Arguments.createMap();
       event.putString(eventCode, message);
       emitDeviceEvent(event);
     }
     /**
      *  Notify event
      *
      * @param String eventCode
      *            the event code.
      * @param Boolean val
      *
      */
     private void notifyEventBoolean(String eventCode, Boolean val) {
       final WritableMap event = Arguments.createMap();
       event.putBoolean(eventCode, val);
       emitDeviceEvent(event);
     }

     private static void emitDeviceEvent(@Nullable WritableMap eventData) {
         reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(PRINTER_NOTIFICATION, eventData);
     }

     @ReactMethod
     public void print(String text) {
        if (printer != null) {
          if(text == null || text.isEmpty()){
            notifyEvent("ERROR", "Print content is empty");
            return;
          }
            byte[] configLabel = text.getBytes();

              try {
                ZebraPrinterLinkOs linkOsPrinter = ZebraPrinterFactory.createLinkOsPrinter(printer);
                PrinterStatus printerStatus = (linkOsPrinter != null) ? linkOsPrinter.getCurrentStatus() : printer.getCurrentStatus();

                if (printerStatus.isReadyToPrint) {
                    connection.write(configLabel);
                    notifyEventBoolean("PRINTING_START", true);
                } else if (printerStatus.isHeadOpen) {
                    notifyEventBoolean("PRINTER_HEAD_OPEN", true);
                } else if (printerStatus.isPaused) {
                    notifyEventBoolean("PRINTER_PAUSED", true);
                } else if (printerStatus.isPaperOut) {
                    notifyEventBoolean("PRINTER_NO_PAPER", true);
                }
                Sleeper.sleep(1500);
                if (connection instanceof BluetoothConnection) {
                    String friendlyName = ((BluetoothConnection) connection).getFriendlyName();
                    notifyEvent("PRINTER_NAME", friendlyName);
                    Sleeper.sleep(500);
                }
                notifyEventBoolean("PRINTING_ENDS", true);
            } catch (ConnectionException e) {
                notifyEvent("ERROR", e.getMessage());
            } finally {
                disconnect();
            }

        } else {
            disconnect();
        }
     }

     @ReactMethod
     public void connect(String printerId) {
       printer = getPrinter(printerId);
     }

     public ZebraPrinter getPrinter(String printerId) {
       notifyEventBoolean("CONNECTING", true);
       if(printerId == null || printerId.isEmpty()){
         notifyEvent("ERROR", "Printer id is empty");
         return null;
       }

        connection = null;
        connection = new BluetoothConnection(printerId);

        try {
            connection.open();
            notifyEventBoolean("CONNECTED", true);
        } catch (ConnectionException e) {
            notifyEventBoolean("CONNECT_ERROR", true);
            Sleeper.sleep(1000);
            disconnect();
        }

        ZebraPrinter printer = null;

        if (connection.isConnected()) {
            try {
                printer = ZebraPrinterFactory.getInstance(connection);
                String pl = SGD.GET("device.languages", connection);
                notifyEvent("PRINTER_LANGUAGE", pl);
            } catch (ConnectionException e) {
                notifyEvent("PRINTER_LANGUAGE_UNKNOWN", "");
                printer = null;
                Sleeper.sleep(1000);
                disconnect();
            } catch (ZebraPrinterLanguageUnknownException e) {
                notifyEvent("PRINTER_LANGUAGE_UNKNOWN", "");
                printer = null;
                Sleeper.sleep(1000);
                disconnect();
            }
        }

        return printer;
     }

     @ReactMethod
     public void disconnect() {
         try {
             notifyEventBoolean("DISCONNECTED", true);
             if (connection != null) {
                 connection.close();
             }
         } catch (ConnectionException e) {
            notifyEventBoolean("DISCONNECT_ERROR", true);
         } finally {
             // trigger some action if needed
         }
     }
  }
