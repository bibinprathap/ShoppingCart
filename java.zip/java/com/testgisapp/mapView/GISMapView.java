package com.testgisapp.mapView;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import java.io.File;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.esri.arcgisruntime.concurrent.Job;
import com.esri.arcgisruntime.geometry.Envelope;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.loadable.LoadStatus;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.mapping.view.MapView;
import com.esri.arcgisruntime.portal.Portal;
import com.esri.arcgisruntime.portal.PortalItem;
import com.esri.arcgisruntime.security.AuthenticationManager;
import com.esri.arcgisruntime.security.DefaultAuthenticationChallengeHandler;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.tasks.offlinemap.GenerateOfflineMapJob;
import com.esri.arcgisruntime.tasks.offlinemap.GenerateOfflineMapParameters;
import com.esri.arcgisruntime.tasks.offlinemap.GenerateOfflineMapResult;
import com.esri.arcgisruntime.tasks.offlinemap.OfflineMapTask;
import com.esri.arcgisruntime.mapping.view.DefaultMapViewOnTouchListener;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.mapping.view.MapView;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import android.view.MotionEvent;
import com.esri.arcgisruntime.mapping.view.IdentifyGraphicsOverlayResult;
import com.esri.arcgisruntime.concurrent.ListenableFuture;
import java.util.List;
import android.widget.TextView;
import com.esri.arcgisruntime.mapping.view.Callout;
import com.esri.arcgisruntime.geometry.SpatialReference;


public class GISMapView extends FrameLayout {

    private static final String TAG = "GISMapView";
    View rootView;
    private MapView mMapView;
    ArcGISMap mMap;

    private Button mTakeMapOfflineButton;
    private GraphicsOverlay mGraphicsOverlay;
    private Graphic mDownloadArea;
    private Callout mCallout;





    private static final int SCALE = 7000;

    public ArcGISMap getMap() {
        return mMapView.getMap();
    }


    public void setMap() {
        // list of sub-domains
        // super.onResume();
        // mMapView.resume();


    }

    public GISMapView(Context context) {

        super(context);
        rootView = inflate(context.getApplicationContext(), com.testgisapp.R.layout.rnags_mapview, this);
        mMapView = rootView.findViewById(com.testgisapp.R.id.agsMapView);



        //      LinearLayout layout = (LinearLayout) rootView.findViewById(com.testgisapp.R.id.llContainer);

        // //set the properties for button
        // Button btnTag = new Button(context);
        // btnTag.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        // btnTag.setText("Button");
        //   final int TOP_ID = 3;
        // btnTag.setId(TOP_ID);

        // //add button to the layout
        // layout.addView(btnTag);

       

 //requestWritePermission(context);

       
    // create a portal item with the itemId of the web map
    Portal portal = new Portal("https://www.arcgis.com", false);
    PortalItem portalItem = new PortalItem(portal, "acc027394bc84c2fb04d1ed317aac674");

    // create a map with the portal item
    ArcGISMap map = new ArcGISMap(portalItem);
    map.addDoneLoadingListener(() -> {
      if (map.getLoadStatus() == LoadStatus.LOADED) {

        // enable the map offline button only after the map is loaded
       // mTakeMapOfflineButton.setEnabled(true);

        // limit the map scale to the largest layer scale
        map.setMaxScale(map.getOperationalLayers().get(6).getMaxScale());
        map.setMinScale(map.getOperationalLayers().get(6).getMinScale());
      } else {
        String error = "Map failed to load: " + map.getLoadError().getMessage();
        Toast.makeText(context, error, Toast.LENGTH_LONG).show();
        Log.e(TAG, error);
      }
    });

    // set the map to the map view
    mMapView.setMap(map);

        // add listener to handle motion events, which only responds once a geodatabase is loaded
        mMapView.setOnTouchListener(
                new DefaultMapViewOnTouchListener(context, mMapView) {
                    @Override
                    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {

                        identifyGraphic(motionEvent,context);
                        return true;
                    }
                });



    // create a graphics overlay for the map view
  mGraphicsOverlay = new GraphicsOverlay();
    mMapView.getGraphicsOverlays().add(mGraphicsOverlay);

    // create a graphic to show a box around the extent we want to download
    // mDownloadArea = new Graphic();
    // mGraphicsOverlay.getGraphics().add(mDownloadArea);
    // SimpleLineSymbol simpleLineSymbol = new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, Color.RED, 2);
    // mDownloadArea.setSymbol(simpleLineSymbol);

    // update the download area box whenever the viewpoint changes
    // mMapView.addViewpointChangedListener(viewpointChangedEvent -> {
    //   if (map.getLoadStatus() == LoadStatus.LOADED) {
    //     // upper left corner of the area to take offline
    //     android.graphics.Point minScreenPoint = new android.graphics.Point(200, 200);
    //     // lower right corner of the downloaded area
    //     android.graphics.Point maxScreenPoint = new android.graphics.Point(mMapView.getWidth() - 200,
    //         mMapView.getHeight() - 200);
    //     // convert screen points to map points
    //     Point minPoint = mMapView.screenToLocation(minScreenPoint);
    //     Point maxPoint = mMapView.screenToLocation(maxScreenPoint);
    //     // use the points to define and return an envelope
    //     if (minPoint != null && maxPoint != null) {
    //       Envelope envelope = new Envelope(minPoint, maxPoint);
    //       mDownloadArea.setGeometry(envelope);
    //     }
    //   }
    // });
    // generateOfflineMap(context);
  }

    /**
     * Identifies the Graphic at the tapped point.
     *
     * @param motionEvent containing a tapped screen point
     */
    private void identifyGraphic(MotionEvent motionEvent,Context context) {
        // get the screen point
        android.graphics.Point screenPoint = new android.graphics.Point(Math.round(motionEvent.getX()),
                Math.round(motionEvent.getY()));
        // // from the graphics overlay, get graphics near the tapped location
        // final ListenableFuture<IdentifyGraphicsOverlayResult> identifyResultsFuture = mMapView
        //         .identifyGraphicsOverlayAsync(mGraphicsOverlay, screenPoint, 10, false);
        // identifyResultsFuture.addDoneListener(new Runnable() {
        //     @Override public void run() {
        //         try {
        //             IdentifyGraphicsOverlayResult identifyGraphicsOverlayResult = identifyResultsFuture.get();
        //             List<Graphic> graphics = identifyGraphicsOverlayResult.getGraphics();
        //             // if a graphic has been identified
        //            // if (graphics.size() > 0) {
        //                 //get the first graphic identified
        //                 Graphic identifiedGraphic = graphics.get(0);
        //                 showCallout(identifiedGraphic,context);
        //            // } else {
        //                 // if no graphic identified
        //                // mCallout.dismiss();
        //             //}
        //         } catch (Exception e) {
        //             Log.e(TAG, "Identify error: " + e.getMessage());
        //         }
        //     }
        // });

        Graphic resultLocGraphic =  new Graphic(new Point(Math.round(motionEvent.getX()),
                Math.round(motionEvent.getY()), 5000, SpatialReferences.getWgs84()));
        //new Graphic(new Point(-109.937516, 38.456714, 5000, SpatialReferences.getWgs84()));
        // add graphic to location layer
        mGraphicsOverlay.getGraphics().add(resultLocGraphic);
        // zoom map to result over 3 seconds
       // mMapView.setViewpointAsync(new Viewpoint(geocodeResult.getExtent()), 3);
        // set the graphics overlay to the map
       // mMapView.getGraphicsOverlays().add(mGraphicsOverlay);
        TextView parkText = rootView.findViewById(com.testgisapp.R.id.park_name);
        showCallout(resultLocGraphic,motionEvent,parkText,rootView,context);
    }

    /**
     * Shows the Graphic's attributes as a Callout.
     *
     * @param graphic containing attributes
     */
    private void showCallout(final Graphic graphic,MotionEvent motionEvent, TextView parkText,View rootView,Context context ) {
        // create a TextView for the Callout
        TextView calloutContent  = new TextView(context);
        calloutContent.setTextColor(Color.BLACK);
        // set the text of the Callout to graphic's attributes
        calloutContent.setText("test title" + "\n"
                + "test 2");
        parkText.setText("test title" + "\n"
                + "test 2");
      //  calloutContent.setText(graphic.getAttributes().get("PlaceName").toString() + "\n"
         //       + graphic.getAttributes().get("StAddr").toString());
        // get Callout
        mCallout = mMapView.getCallout();
        // set Callout options: animateCallout: true, recenterMap: false, animateRecenter: false
        mCallout.setShowOptions(new Callout.ShowOptions(true, false, false));
        mCallout.setContent(calloutContent);
        // set the leader position and show the callout
        // set the leader position and show the callout
      Point calloutLocation = new Point(Math.round(motionEvent.getX()),
              Math.round(motionEvent.getY()), 5000, SpatialReferences.getWgs84());
              //graphic.computeCalloutLocation(graphic.getGeometry().getExtent().getCenter(), mMapView);
      //   mCallout.setGeoElement(graphic, calloutLocation);
        Point center = new Point(-13671170, 5693633, SpatialReference.create(3857));
        com.esri.arcgisruntime.geometry.Point   mTappedPoint = new com.esri.arcgisruntime.geometry.Point((int) motionEvent.getX(), (int) motionEvent.getY());

        mCallout.setLocation(mMapView.screenToLocation(mTappedPoint));
        mCallout.show();
    }

  /**
   * Use the generate offline map job to generate an offline map.
   */
  private void generateOfflineMap(Context context) {

    // create a progress dialog to show download progress
    ProgressDialog progressDialog = new ProgressDialog(context);
    progressDialog.setTitle("Generate Offline Map Job");
    progressDialog.setMessage("Taking map offline...");
    progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
    progressDialog.setIndeterminate(false);
    progressDialog.setProgress(0);

      progressDialog.show();

      // delete any offline map already in the cache
      String tempDirectoryPath = context.getCacheDir() + File.separator + "offlineMap";
      deleteDirectory(new File(tempDirectoryPath));

      // specify the extent, min scale, and max scale as parameters
      double minScale = mMapView.getMapScale();
      double maxScale = mMapView.getMap().getMaxScale();
      // minScale must always be larger than maxScale
      if (minScale <= maxScale) {
          minScale = maxScale + 1;
      }
      android.graphics.Point minScreenPoint = new android.graphics.Point(200, 200);
      // lower right corner of the downloaded area
      android.graphics.Point maxScreenPoint = new android.graphics.Point(  200,
                200);
      // convert screen points to map points
     // Point minPoint = mMapView.screenToLocation(minScreenPoint);
     // Point maxPoint = mMapView.screenToLocation(maxScreenPoint);
      Point minPoint = new Point(-110.828140, 44.460458, SpatialReferences.getWgs84());
      Point maxPoint = new Point(-110.829004, 44.462438, SpatialReferences.getWgs84());
      //Point plumeGeyserPoint = new Point(-110.829381, 44.462735, SpatialReferences.getWgs84());
      Envelope envelope = new Envelope(minPoint, maxPoint);
      // use the points to define and return an envelope
      if (minPoint != null && maxPoint != null) {

          mDownloadArea.setGeometry(envelope);
      }
      GenerateOfflineMapParameters generateOfflineMapParameters = new GenerateOfflineMapParameters(
      envelope, minScale, maxScale);

      // create an offline map offlineMapTask with the map
      OfflineMapTask offlineMapTask = new OfflineMapTask(mMapView.getMap());

      // create an offline map job with the download directory path and parameters and start the job
      GenerateOfflineMapJob job = offlineMapTask.generateOfflineMap(generateOfflineMapParameters, tempDirectoryPath);

      // replace the current map with the result offline map when the job finishes
      job.addJobDoneListener(() -> {
          if (job.getStatus() == Job.Status.SUCCEEDED) {
              GenerateOfflineMapResult result = job.getResult();
              mMapView.setMap(result.getOfflineMap());
              mGraphicsOverlay.getGraphics().clear();
              mTakeMapOfflineButton.setEnabled(false);
              Toast.makeText(context, "Now displaying offline map.", Toast.LENGTH_LONG).show();
          } else {
              String error = "Error in generate offline map job: " + job.getError().getAdditionalMessage();
              Toast.makeText(context, error, Toast.LENGTH_LONG).show();
              Log.e(TAG, error);
          }
          progressDialog.dismiss();
      });

      // show the job's progress with the progress dialog
      job.addProgressChangedListener(() -> progressDialog.setProgress(job.getProgress()));

      // start the job
      job.start();

  }

  /**
   *
   */
  private void requestWritePermission(Context context) {
    // request write permission
    String[] reqPermission = { Manifest.permission.WRITE_EXTERNAL_STORAGE };
    int requestCode = 2;
    // for API level 23+ request permission at runtime
    if (ContextCompat.checkSelfPermission(context, reqPermission[0]) == PackageManager.PERMISSION_GRANTED) {
    //  generateOfflineMap(context);
    } else {
      // request permission
     // ActivityCompat.requestPermissions(context, reqPermission, requestCode);
    }
  }


    /**
     * Recursively deletes all files in the given directory.
     *
     * @param file to delete
     */
    private static void deleteDirectory(File file) {
        if (file.isDirectory())
            for (File subFile : file.listFiles()) {
                deleteDirectory(subFile);
            }
        if (!file.delete()) {
            Log.e(TAG, "Failed to delete file: " + file.getPath());
        }
    }
}
