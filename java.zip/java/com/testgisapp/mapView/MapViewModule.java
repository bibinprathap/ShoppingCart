package com.testgisapp.mapView;

import android.view.View;

import com.facebook.react.bridge.LifecycleEventListener;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;

import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.Basemap;

import com.esri.arcgisruntime.layers.ArcGISTiledLayer;


public class MapViewModule extends ViewGroupManager<GISMapView> implements LifecycleEventListener {

    private static final String TAG = "GISMapView";
    private boolean mScannerViewVisible;
    private GISMapView mMapView;

    @Override
    //getName is required to define the name of the module represented in JavaScript
    public String getName() {
        return TAG;
    }

    @Override
    public GISMapView createViewInstance(ThemedReactContext context) {
        context.addLifecycleEventListener(this);
        mMapView = new GISMapView(context);
        return mMapView;
    }

    @Override
    public void onHostResume() {

       // ArcGISMap map = new ArcGISMap();
         
            //if (mMapView.getMap() == null) {
                 mMapView.setMap();
             //}
    }

    @Override
    public void onHostPause() {
      //  mMapView.onPause();
    }

    @Override
    public void onHostDestroy() {

        //mMapView.stopCamera();
    }

    @Override
    public void addView(GISMapView parent, View child, int index) {
        parent.addView(child, index + 1);   // index 0 for camera preview reserved
    }

}


