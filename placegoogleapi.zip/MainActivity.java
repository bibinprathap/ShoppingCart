package com.mims;

import com.facebook.react.ReactActivity;
import com.facebook.react.ReactActivityDelegate;
import com.facebook.react.ReactRootView;
import com.swmansion.gesturehandler.react.RNGestureHandlerEnabledRootView;
import org.devio.rn.splashscreen.SplashScreen;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;
import com.facebook.react.modules.i18nmanager.I18nUtil;
import android.content.Intent;
import java.util.concurrent.TimeUnit;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

  import com.mims.uploader.FitPlaceWorker;
 

public class MainActivity extends ReactActivity {

 public static final int PERMISSION_REQ_CODE = 1234;

    public static PlacesClient placesClient;
    String[] perms = {  "android.permission.CAMERA"
    };
    private static final String W_TAG = "Periodic Worker";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // SplashScreen.show(this);  // here
        super.onCreate(savedInstanceState);

        Places.initialize(getApplicationContext(), "23333");
        placesClient = Places.createClient(this);
         checkPerms();
        I18nUtil sharedI18nUtilInstance = I18nUtil.getInstance();
        sharedI18nUtilInstance.allowRTL(getApplicationContext(), true);
       //PeriodicWorkRequest fireUploadBuilder =
           //    new PeriodicWorkRequest.Builder(FitPlaceWorker.class, 15, TimeUnit.MINUTES).build();
       // WorkManager.getInstance().enqueueUniquePeriodicWork(W_TAG, ExistingPeriodicWorkPolicy.KEEP, fireUploadBuilder);
        OneTimeWorkRequest fireUploadBuilder = new OneTimeWorkRequest.Builder(FitPlaceWorker.class).build();
        WorkManager.getInstance().enqueueUniqueWork(W_TAG, ExistingWorkPolicy.REPLACE, fireUploadBuilder);
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "mims";
    }

        public void checkPerms() {
        // Checking if device version > 22 and we need to use new permission model 
        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP_MR1) {
       
            for(String perm : perms){
                // Checking each persmission and if denied then requesting permissions
                if(checkSelfPermission(perm) == PackageManager.PERMISSION_DENIED){
                    requestPermissions(perms, PERMISSION_REQ_CODE);
                    break;
                }
            }
        }
        }

          // Window overlay permission intent result
 


    @Override
    protected ReactActivityDelegate createReactActivityDelegate() {
        return new ReactActivityDelegate(this, getMainComponentName()) {
            @Override
            protected ReactRootView createRootView() {
                return new RNGestureHandlerEnabledRootView(MainActivity.this);
            }
        };
    }
}
