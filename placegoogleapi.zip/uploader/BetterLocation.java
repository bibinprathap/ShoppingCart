package com.mims.uploader;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.util.Log;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.PlaceLikelihood;
import com.google.android.libraries.places.api.net.FindCurrentPlaceRequest;
import com.google.android.libraries.places.api.net.FindCurrentPlaceResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.ACCESS_WIFI_STATE;
import static com.mims.MainActivity.placesClient;


public class BetterLocation  {

    private List<Place.Field> placeList = new ArrayList<>();
    private static String TAG = "Location: ";
    public static Map<String, Object> places = new HashMap<>();
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE
    };

    public void findCurrentPlace(Context context ) {

        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
            findCurrentPlaceWithPermissions(context);
        }
        else {
          //  ActivityCompat.requestPermissions(activity, PERMISSIONS, PERMISSION_ALL);
        }
    }


    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE})
    public void findCurrentPlaceWithPermissions(Context context) {

        placeList.add(Place.Field.NAME);
        placeList.add(Place.Field.ADDRESS);
        placeList.add(Place.Field.LAT_LNG);
        placeList.add(Place.Field.TYPES);

        FindCurrentPlaceRequest currentPlaceRequest =
                FindCurrentPlaceRequest.builder(placeList).build();

        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {

            Task<FindCurrentPlaceResponse> currentPlaceTask =
                    placesClient.findCurrentPlace(currentPlaceRequest);

            currentPlaceTask.addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    places.clear();
                    FindCurrentPlaceResponse response = task.getResult();
                    assert response != null;
                    for (PlaceLikelihood placeLikelihood : response.getPlaceLikelihoods()) {
                        Log.d(TAG, "findCurrentPlace: "
                                + placeLikelihood.getPlace().getName() + "\n"
                                + placeLikelihood.getPlace().getAddress() + "\n"
                                + placeLikelihood.getPlace().getLatLng() + "\n"
                                + placeLikelihood.getPlace().getTypes() + "\n"
                                + placeLikelihood.getLikelihood());

                       // PlaceObj placeObj = new PlaceObj(
                         //       placeLikelihood.getPlace().getName(),
                         //       placeLikelihood.getPlace().getAddress(),
                           //     placeLikelihood.getPlace().getLatLng(),
                          //      placeLikelihood.getPlace().getTypes(),
                          //      placeLikelihood.getLikelihood());

                      //  places.put(placeObj.Name, placeObj);
                    }


                } else {
                    Exception exception = task.getException();
                    if (exception instanceof ApiException) {
                        ApiException apiException = (ApiException) exception;
                        Log.e(TAG, "findCurrentPlaceWithPermissions: " + apiException.getStatusCode() + apiException.getLocalizedMessage());
                    }
                }
            });
        }
    }

}