package com.mims.uploader;

import android.content.Context;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadServiceBroadcastReceiver;

/**
 * This implementation is empty on purpose, just to show how it's possible to
 * intercept all the upload events app-wise with a global broadcast receiver
 * registered in the manifest.
 *
 * @author Aleksandar Gotev
 */

public class UploadReceiver extends UploadServiceBroadcastReceiver {
    @Override
    public void onProgress(Context context, UploadInfo uploadInfo) {
        // your implementation
        // your implementation

        WritableMap params = Arguments.createMap();
        params.putString("id", uploadInfo.getUploadId());
        params.putInt("progress", uploadInfo.getProgressPercent()); // 0-100
        UploaderModule.sendEvent2("progress", params);

    }

    @Override
    public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
        // your implementation
        WritableMap params = Arguments.createMap();
        params.putString("id", uploadInfo.getUploadId());
        if (serverResponse != null) {
            params.putInt("responseCode", serverResponse.getHttpCode());
            params.putString("responseBody", serverResponse.getBodyAsString());
        }

        // Make sure we do not try to call getMessage() on a null object
        if (exception != null) {
            params.putString("error", exception.getMessage());
        } else {
            params.putString("error", "Unknown exception");
        }

        UploaderModule.sendEvent2("error", params);
        String failedUploads = UploaderModule.getSharedPreferencesString(UploaderModule.FAILEDUPLOADIDS);
        if (failedUploads.length() == 0)
            failedUploads = uploadInfo.getUploadId();
        else
            failedUploads = " " + uploadInfo.getUploadId();
        UploaderModule.setSharedPreferencesString(UploaderModule.FAILEDUPLOADIDS,
                UploaderModule.getSharedPreferencesString(UploaderModule.FAILEDUPLOADIDS) + " " + failedUploads);
    }

    @Override
    public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {
        // your implementation
        WritableMap params = Arguments.createMap();
        params.putString("id", uploadInfo.getUploadId());
        params.putInt("responseCode", serverResponse.getHttpCode());
            params.putString("responseBody", serverResponse.getBodyAsString());
        UploaderModule.sendEvent2("completed", params);
        String completedUploads = UploaderModule.getSharedPreferencesString(UploaderModule.COMPLETEDUPLOADIDS);
        if (completedUploads.length() == 0)
            completedUploads = uploadInfo.getUploadId();
        else
            completedUploads = " " + uploadInfo.getUploadId();

        String test =  serverResponse.getBodyAsString();
        UploaderModule.setSharedPreferencesString(UploaderModule.COMPLETEDUPLOADIDS,
                UploaderModule.getSharedPreferencesString(UploaderModule.COMPLETEDUPLOADIDS) + " " + completedUploads);
        UploaderModule.setSharedPreferencesString(uploadInfo.getUploadId(), serverResponse.getBodyAsString());
    }

    @Override
    public void onCancelled(Context context, UploadInfo uploadInfo) {
        WritableMap params = Arguments.createMap();
        params.putString("id", uploadInfo.getUploadId());
        params.putString("cancelled", "file Deleted Before Upload");
        UploaderModule.sendEvent2("cancelled", params);
        // your implementation
        String cancelledUploads = UploaderModule.getSharedPreferencesString(UploaderModule.CANCELLEDUPLOADIDS);
        if (cancelledUploads.length() == 0)
            cancelledUploads = uploadInfo.getUploadId();
        else
            cancelledUploads = " " + uploadInfo.getUploadId();
        UploaderModule.setSharedPreferencesString(UploaderModule.CANCELLEDUPLOADIDS,
                UploaderModule.getSharedPreferencesString(UploaderModule.CANCELLEDUPLOADIDS) + " " + cancelledUploads);
    }
}