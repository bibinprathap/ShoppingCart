## Issues

Along with a bug report, provide a functional example repository which
reproduces the bug you're experiencing. We've made this very easy by providing
a full-stack (React Native + Express.js) example app, which you can fork and
alter to reproduce your bug:

[ReactNativeBackgroundUploadExample](https://github.com/Vydia/ReactNativeBackgroundUploadExample)
