import App from './app/index';

//GLOBAL.XMLHttpRequest = GLOBAL.originalXMLHttpRequest || GLOBAL.XMLHttpRequest;

export default App;
// import React from 'react';
// import { View, Text, TouchableOpacity } from 'react-native';
// // import { RFImageList } from 'app/components/Form/InputComponents/RFImageList';

// setTimeout(doWork, 2000);
// function doWork() {
//     console.log('delayed work');
// }

// export default class App extends React.Component {
//     render() {
//         return (
//             <View style={{ flex: 1, alignContent: 'center', justifyContent: 'center' }}>
//                 <Text style={{ alignSelf: 'center' }}>123456</Text>
//             </View>
//         );
//     }
// }

// another test for task attachment
