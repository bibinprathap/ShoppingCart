var fs = require('fs');

function createIcomoonMap(icomoonPath, outputPath) {
    try {
        console.info('creating icomoon map from "', icomoonPath, '"');
        const icomoonSelectionJson = require(icomoonPath);
        if (icomoonSelectionJson.icons && icomoonSelectionJson.icons.length > 0) {
            const unicodeMap = { default: 0 };
            icomoonSelectionJson.icons.map((key, index) => {
                const item = icomoonSelectionJson.icons[index].properties;
                const { name, code } = item;
                //console.log({ name, code });
                unicodeMap[name] = code;
            });
            try {
                fs.writeFile(outputPath, JSON.stringify(unicodeMap, null, '\t'), function(err) {
                    if (err) {
                        throw err;
                    } else {
                        console.info('Map written to ', outputPath);
                    }
                });
            } catch (error) {
                console.error('Error while writing map to output.');
                throw error;
            }
        } else {
            console.info('No icons definition found.');
        }
        console.info('Done!');
    } catch (error) {
        console.error('Failed to create map.');
        throw error;
    }
}

createIcomoonMap(process.argv[2], process.argv[3]);
