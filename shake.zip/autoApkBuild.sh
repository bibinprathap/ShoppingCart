 read -p "UserName: " name
 read -s -p "Password: " password

 tf get -login:"$name,$password" -noprompt -collection:'http://10.20.13.89:8080/tfs/Net Application'  -nosummary $(pwd) -recursive &&
 npm version patch &&
PACKAGE_VERSION=$(cat package.json \
  | grep version \
  | head -1 \
  | awk -F: '{ print $2 }' \
  | sed 's/[",]//g' \
  | tr -d '[[:space:]]') &&
echo $PACKAGE_VERSION &&
tf checkin -login:"$name,$password" -noprompt -collection:'http://10.20.13.89:8080/tfs/Net Application'  $(pwd)'/package.json' -comment:patch_update_$PACKAGE_VERSION &&
Changeset=$( tf changeset   -login:"$name,$password" -collection:'http://10.20.13.89:8080/tfs/Net Application'  -latest \
  | grep Changeset \
  | head -1 \
  | awk -F: '{ print $2 }' \
  | sed 's/[",]//g' \
  | tr -d '[[:space:]]') &&
  echo $Changeset
cd android && ./gradlew assembleRelease && cd .. &&
mv $(pwd)'/android/app/build/outputs/apk/release/app-release.apk' $(pwd)'/android/app/build/outputs/apk/release/MIMS-release-'${PACKAGE_VERSION}'-'${Changeset}'.apk' 
# abc=$(pwd)'/package.json'${PACKAGE_VERSION}'-.apk'
# echo $abc
