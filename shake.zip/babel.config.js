module.exports = {
    presets: ['module:metro-react-native-babel-preset'],
    plugins: [
        [
            'module-resolver',
            {
                root: ['.'],
                alias: {
                    app: './app',
                    ThirdPartyModuleJS: './ThirdPartyModuleJS',
                },
            },
        ],
        //it was added in an attempt to solve the hotreloading, for functional components, but broke vector icons
        //ref: https://github.com/facebook/react-native/issues/22592#issuecomment-483934779
        // [
        //     '@babel/plugin-transform-modules-commonjs',
        //     {
        //         strictMode: false,
        //         allowTopLevelThis: true,
        //         loose: true,
        //     },
        // ],
    ],
};
