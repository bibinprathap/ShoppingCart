/**
 * @format
 */

console.disableYellowBox = true;

import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
//const badi = require('./src/app');
// import App from './src/app';

// import { getLocation } from 'app/api/helperServices/geolocation';
// import { updateLocationEvent } from 'app/actions/tracking';
//import { store, _state } from 'app/config/store';
// import { inspectionsHelper } from 'app/api/helperServices';
// import { saveNewInspection } from 'app/actions/inspections';

// AppRegistry.registerComponent(appName, () => App);

AppRegistry.registerComponent(appName, () => App);

// const LogLocation = async data => {
//     //debugger;
//     //console.warn(JSON.stringify(data));
//     const currentLocation = await getLocation();
//     // console.warn('location Change' + JSON.stringify(currentLocation));
//     store && store.dispatch(updateLocationEvent(currentLocation));
//     // if (_state && _state.inspections && _state.inspections.history) {
//     //     Object.getOwnPropertyNames(_state.inspections.history).map(ins => {
//     //         const inspection = _state.inspections.history[ins];
//     //         if (!inspection.saved && inspection.locallySaved && !inspectionsHelper.getPendingAttachementList(inspection.inspection)) {
//     //             store && store.dispatch(saveNewInspection(inspection.inspection));
//     //         }
//     //     });
//     // }
// };
// AppRegistry.registerHeadlessTask('LogLocation', () => LogLocation);
