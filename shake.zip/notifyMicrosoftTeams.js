const https = require('https');

const webHooks = {
    general:
        '/webhook/33619fea-3b88-4603-81ab-7e240fcf20ac@35e1a216-7c23-4035-a74d-313c6352fdee/TeamFoundationServer/c6c4dabf6b6b4180bd9ed91999340fa9/10b85554-fdce-464d-9533-5e807ef08cc1',
};

function notifyMicrosoftTeams(newVersion, creator) {
    try {
        const postData = JSON.stringify({
            sender: 'Visual Studio Team Services',
            summary: `New release by ${creator}`,
            title: null,
            text: null,
            sections: [
                {
                    title: null,
                    text: null,
                    markdown: true,
                    facts: [],
                    images: null,
                    activityTitle: `**RELEASE** | MIMS version ${newVersion} is ready to be published`,
                    activitySubtitle: 'Expect an update via SecureHub soon',
                    activityImage:
                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAzFBMVEUAgAD///8AfgAAewAAegAAggD8/vwAeAB9vX0AgwD4/Pj9//3y+fL2+fb3/PcAhQDu9+7c7twAiQDq9eri8OLQ59DA3cCEvIRpr2mAvYATiBPO5c6KwYrX69e32rff8N9SolKizaIskSy52bleqF6VyZWfzp/J48mw07Db6dt0tHQfhx9DmkOXxZe31rfL5csqlio4lThms2Zpqml/s39MoUwymjKbzJtTqFMYkRimy6aKvopRn1Fan1oxjzFut26JxYlxrHFCoUJqtWo10kMSAAANvElEQVR4nN2de3uiOBSHyQlgpdQr3lCsqFVqtaNtbUftdLvu9/9OC2pbLyEQSATn99c++0w1r4Tk5ORcJCRYqqbd3FjtwV2rcXV11Wq13t5sp90bVgz95uZG0zRV8AAkcR+t6mXj3mn8npbkTEaWZexK3iqzlVRavP6+cu6Nck7cMAQRakZzuBytXTaMQfIXAMYZWHRWj02rLGYoIgjLQ2fSnyoyle2AE8u4NBste5aAKcud8NZZPc/yGMLS7WGC+f4yqeqcB8SX0LBH7w9S6Gd3Sgn5jz+NnsZzTBwJr9tPH6YUme4bUnoYf97yGxYvQtX6pxRhavpQYvxq65zeSS6EWrk3lzEfui9IOV8fFngMjgOh3py8Al++jXC2/2ikgFCvrqbRl5YARqWztK6TJdTbNWF8G0ZpvvoV74WMRXhdfe7yWl38BMqsVkyKsFh/iL05hGNsxTADohPqV/kz4G0ZYWFHnqoRCdXyW0k+E9+GEa97EZ9jNELdGYtcX4iMSr0ZyZqLRGjVzDPzecLdSZTtMQJhzp6LXkDJgmy9eg7CyiibCN+G8WPFfE5mJdTsWVJ4G0TlnfUxMhIa9eQe4I7RZNwcmQjV6qsAC5sVEXeYbBwWQt0uJQ/oCk+HDPs/A6FRO4eNFkZ4sQx/dAxP+KufEj7Jexlrof0cYQk1Z5weQFfZfpMvYc7upgrQ1TjkthGOUL1LepM4FUzDIYYi1K9SsYYeCSSHF2Ghfs6DUniBZIc4bYQgvK2n8Ql6guxbsH0TTGjVkwbxF5irwI0xkLDYTxqDphCIQYRGXUmagiow3wLexQBCfZQ0QpAga8ch1EZpXWR+5K6o0QnVRvoBPUTq1k8j1AaXAOi9izRECqFqn83lG1MwG0Yi7KXO2PYX5djvT2h1kh42g5SG77boS1hO/T5xoLzvxYYfYW6S9JjZBCW/1caP0LmUVeZLsLCYCCvTCwOUJDwnv4pkwsL8MnbCA8kN4qtIJrwIW+ZE2XZowraZ9GAjCeYkFyOJsPx+cS/hVkqNME9JhK10Hwn9BQ+EeUogbF+QtXYk/H5qvZ0SGiny3rNrdRJPfUKoTbJJjzKGCAepE8Lm5c5RT7hzvO8fE+ZS6xwNKbADCKuXuo5+CRY6nXB94Y/QNd4+qYR2JukBxlfeoBDql3ekOBX8QyG8SxMgKPl8pMiB7tCXsDhLDyGYz5OlXZtGWRdGuh9higxSmPbKrhmtD0fszgbo9nwIKykKRlC+bOjC8pUd8V+dTDhJzyPEre9RqcW6wsgI3SqR0Jqn5hHC0/6bpDIHguCVTiBUbTGjjSCYHfnNrCe2xwjTJoHQ6KTFnIEH5/isrt19MCHiiXZK+JiaU1O2Rog/6PVZVgmYGieEenoOFeRrlmKDxT+GnRNCKy9sxGw63M32VKgxIMJaPSb8TE1UUMMvl+u2w/Ap2Doi1Eop2Srw2j9zvcHwKuKnI8J2So5NUKKEONssb6KSOyRMy8lXGfgDovYDwyfhwQFhQdiQ2QT1GwrhgOUZwvyAMCVRFyfGzIFUtmvpj+I+YScV6wyYJ8bMvnpdpk8z3/YIi2w2kTCRjJlvGYwxhPC8R/iWius0mFPn6ITRJoFx5YfwORWPkHRz9KMqc0ZgdvBNaKTiwlCp0RLTDfalAl7UL8I22yssRjCnJd6pdxE+8U/xizAV7os8JTbNnaMRol+2zgyPUP83BZN0zzNDkL6ONMTljrCZAh8b+ETD7PQZySLBL/qW0CnxHi+zoERNY2JfR7efOi9uCNVJ8iabsqQZM0ZUL2BpuCEsPydPWKeto1ot6kqIHzeEVuKvIcyoczR6KK+8ynmEzcQ9NCa16sVt9JwW3C97hNXEJ2mdto7mVtF3a8+pKCFtkrAPCro0gzvqOrr77HuXsJC0oxRojgtUiLbX75R5dAkN9tsrrsK/aYAoXnKn3FIldJ+sUQomtdJFL97Pj59cwmayfsQ8NdU17gSDV01Cy0QXGhjRnGtaI+4bVLqR1FaShBvL0V8Oi4OUKFmX1ESXUpM6Rzmk7WQqkvo7ScIarbyuHtke/VGmLWmx9pt4AkJI7/4c5WBOygNJS3A7pDvXLB7xS/hT0hbJVX1q0AD12OuoJ3yVICHMqHs9jzm6IbxJzIWhUNN3b/mESXqESZ0OZapzDXHaxDzChMxSvKbOUZvTsDzCZF5DyFMdF1zWUU8eYUIbPtVxodd5/e6JEQLVuaYyXWdTxZMQGMpFUhPouTrhuRECNsfjaeiobHNCu0jjmUbOixAv7KZlNSchHZvQod1mqzbHGEJOhHhW3awbavshFKJJda5ZPDOv+BDieeVrdKGu+TJvNEC+xzk++2F/L0nFCo6Pw2saILrj6jfiYtMcLvyVoL06wLlm8bWxONilcOySr8zpf6BQHRcFzi6Hzdki1jQ9AXR3sw71D0a0dfT6Lc5gCIp/PhwRClBXKIEh9KggVOUdnOURxjmHQZ1YYZuSuWEuaYAG9+p3HmEMPw30fTxJhl+9YRjRnGsq/yxrz08T3de2CxwjSSfnnMGY6lyLdZFGlmzH8Zeatv9gC0TjmfYXYnJaMm1JjV50rkPb2IzO6R/gEQ1QXQk4jGesOPcW1PESSkrClLrXV0WkC2A9xt2TQnclnSIqVAewPhNxFi9pMe4PlU/agNFJUK9Mqq3yIyFVf2DtEt5HNtvqQZXRy/vFmPCa2p1CTNUf/J8a4x4fZr8CCFHuJ43Dv9zYRpEDu+iS79Q4sRgQXMJf+/39rye0Sqo5QfXvNrEYmh39EphstO2r8FXDtk8tE++Ecw6w634TExXjw0mG96HKIw/xIPf4VEVBgebbmCjUjPGOK6PArijlTdudFdUBXOMHdaBdXFsxjndSqQe2gS208n718HbqiWo9tItNjBlfOgrspqEN8r4muqeysLJGu/hSNWbo3lVwwxD62/ok7GJhFyOMHmO6aq7itX91hAVlfcV5x66Hka3FaadpiLtm/47Vj5tvAdng6va+4neRRtBXvkXsnBnmHkx7YsrtZRzWd85M/LwnUGoRuxSLzGbZBiRxyl2DbNBRiqyCyHrMe7lr6Dn+pwWdh8niEzTjo+wEIZ45pMon+0RtiqwtdpBDesvB1ew+RdblRmwQ/UEeMJdcbjDvGBEHQiNdDnK5+eTjsyJWxNbiOMzHL3C5tXP3RYZ3MSe2qNFRTQXE59oOAv1vexJc4O+oLgbq8TF/GTaNquBSsMe1TbiFmSqtcN0Xy4LLFZ/Up0G8khIg2wo89SPvkkJwTORJjSFU5BVJG25FFT1HCXWidG6Nj8IgCi+pje2vr/qp11blZiKCeVpV+1Daitd3+Q2BUK/N/Vm5bU9gUqPwhVz2HgqvCDX30JLfuw8SdV/URed4gEmqm4gsno5nhdxOY6v/REft4hqp9iVCXCMhlIbvciO8ctpBi9J9Qr6J+b4eOEN4XXv4d++rD+oIc13hIF8j3mmIukjb+2bfOsLolmstaMg2SIjxsyYD9exbCxq98Z0/CqGUwBnKMT/41/NGOd5+k/7xUxTqXNuKWpOd/zLXObz6vV6Kr3SbPfxK0b0R8EFmxbXDWriaXQG9EdCQ928MXef7vc854qukBva3yHHvreruGhXvS9VCpRWpEQDj19mITiikz8ystnQcu3aODjb4JJzwhDAnoFcQQD6fzzLkRUX/phC9gpAh8kJPuEL0e7qsDqtHwoS4JGLftdRUZ2cUdMP1XUPldFSkZRfRk/lX9T/shO1/eKE9LCEfvoflZfYh9ame+Rf1kvVJTPXrB9y+tH7AeOoTzutHqKWiLm14QckvO/xv6cud9S0P+rf0VvcPrfMnFH49xFN+SXR0QtURfbvASzCmlBGhECLVvgxCmNJqUNAI0XXrEjZ+UKhFNqiEHKr6iRfQE8YCCJHO0rwmEQG9bF8g4S4hJL0CcxAQpBREiG7raUYEcxIUMxBIiIopforwMAmMMA8mROXUnhbBtIMDW0IQustNOhFBcUIECoYhRFrrHL5OVkGWvk2wELrWTfoMOJgGprAyECJ1mYZGLQcahwMMS4jUXkDZmfMKlDo1HS4CIUIV7nVHogvMVWDyKjshKq/EX2+GE1444QPKGQhRzlmkYtvAa2pVyRiESB2moE0i4OAM8siEniGeTXimuqZ2mBjkyITo2hmf4aqawtcPuUlEJnQPG43kdn+YvTHncrITurv/ezKPEfLPVH8FN0L3QNVK4jHCzA4sb8CLEOm93+e2xXF+1AyXycGFEKGCvThn5w+Q11W2JTQ2obv/f56tDTTAoh3p+cUjRMi46p5jyQFpdhfx+cUlROjX6EP0+wjKuEUtbSOWEOWqL12RjFiaT1iMUP6ECGnDyUwUI5Y6S4tWNfoshC6jZY+Bv0UOONt3mGxsYYReYGX1SZK5PkjIlBrNOAVFvsWFEHmQrQXmNVsB41c7xvJ5IF6Enn6Nxg9KXEoA5WH+GVgmLbx4ErpLa6/xpxs9kBQAsh9/WqznI7r4EroqtCcv7yZgVkpwF6vun5dBNbLx4iPuhK5yVm85Gpsgh8R04WRl2lktq7dxtwaCRBB6Kheb1Un9NS9nZMoC5LFlcGk8Wg6bt/GqTflKFKEnrWDc3z+untYlJZPJyK7wTu5/ev8nv1jXJ9V7o6zznpp7Ekm4lapq2s2NMXQGrdbVVo3Wnd1uGjc3mqYKZNvqf2Jd/FdBG3xvAAAAAElFTkSuQmCC',
                },
            ],
        });

        const options = {
            hostname: 'outlook.office.com',
            port: 443,
            path: webHooks.general,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': postData.length,
            },
        };

        const req = https.request(options, res => {
            console.log(`MS Teams notification sent, Status: ${res.statusCode}`);
            //console.log(`HEADERS: ${JSON.stringify(res.headers)}`);
            //res.setEncoding('utf8');
            //res.on('data', chunk => {
            //    console.log(`BODY: ${chunk}`);
            //});
            // res.on('end', () => {
            //     console.log('No more data in response.');
            // });
        });

        req.on('error', e => {
            console.error(`Failed to send MS Teams notification: ${e.message}`);
        });

        //console.log(postData);
        // Write data to request body
        req.write(postData);
        req.end();
    } catch (e) {
        console.error(`Failed to send MS Teams notification: ${e.message || e}`);
    }
}

//notifyMicrosoftTeams(process.argv[2], process.argv[3]);
notifyMicrosoftTeams(process.argv[2], process.argv[3]);
