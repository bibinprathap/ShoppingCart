import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, ActivityIndicator, Text, TouchableOpacity } from 'react-native';
import { Icon, Modal } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import moment from 'moment';
import EStyleSheet from 'react-native-extended-stylesheet';

const ActionButton = ({ title, icon, onPress }) => {
    return (
        <TouchableOpacity onPress={onPress}>
            <View style={styles.button}>
                <Icon type="MaterialCommunityIcons" name={icon} size={24} style={styles.buttonIcon} />
                <Text style={styles.buttonText}>{title}</Text>
            </View>
        </TouchableOpacity>
    );
};

const Loader = props => {
    const dateFormat = 'LLL';
    const { isLoading, isRunning, options, result } = props;
    if (!isLoading) return null;
    const handleOnRequestClose = () => {
        if (typeof options.onRequestClose === 'function') {
            options.onRequestClose(result);
        }
    };
    const handleOnRequestCancel = () => {
        if (isRunning && options.requestCancel) options.requestCancel();
    };
    const { id, maxTries, retryCount, autoClose, message, allowCancel } = options || {};
    const { success, error } = result || {};
    let closeButtonTitle = success === true ? 'close' : maxTries <= retryCount ? 'close' : 'cancel';
    const showRetryButton = isRunning === false && success === false && (maxTries == 0 || maxTries > retryCount) ? true : false;
    const showClosebutton = showRetryButton === true || (allowCancel == true && showRetryButton === false && autoClose === false) ? true : false;
    const hasButtons = showRetryButton || showClosebutton;

    handleRetry = () => {
        if (typeof options.run === 'function') options.run(options);
    };

    return (
        <Modal transparent={true} animationType={'none'} visible={isLoading} onRequestClose={handleOnRequestCancel}>
            <View style={styles.modalBackground}>
                <View style={styles.mainContainer}>
                    {isRunning && (
                        <View style={styles.activityIndicatorWrapper}>
                            <ActivityIndicator size="large" animating={true} />
                        </View>
                    )}
                    {message && (
                        <View style={styles.messageContainer}>
                            <Text style={styles.message}>{message}</Text>
                        </View>
                    )}
                    {error && (
                        <View style={styles.errorContainer}>
                            <Text style={styles.errorMessage}>{error}</Text>
                        </View>
                    )}
                    {hasButtons && (
                        <View style={styles.buttonsContainer}>
                            {showRetryButton && <ActionButton title={strings('tryAgain')} icon="replay" onPress={handleRetry} />}
                            {showClosebutton && <ActionButton title={strings(closeButtonTitle)} icon="close" onPress={handleOnRequestClose} />}
                        </View>
                    )}
                    <View>
                        <Text>{moment().format(dateFormat)}</Text>
                    </View>
                    {maxTries > 1 && (
                        <View>
                            <Text>
                                Try {retryCount} of {maxTries}
                            </Text>
                        </View>
                    )}
                </View>
            </View>
        </Modal>
    );
};

const styles = EStyleSheet.create({
    modalBackground: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#00000040',
    },
    mainContainer: {
        backgroundColor: '$primaryLightBackground',
        borderRadius: 10,
        //maxHeight: 200,
        //maxWidth: 400,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 15,
    },
    activityIndicatorWrapper: {
        marginVertical: 20,
        marginHorizontal: 40,
    },
    messageContainer: {
        maxWidth: 400,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    message: {
        margin: 10,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
        alignSelf: 'center',
        textAlign: 'center',
    },
    errorContainer: {
        maxWidth: 400,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    errorMessage: {
        margin: 5,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextSM',
        color: '$primaryErrorTextColor',
        alignSelf: 'center',
        textAlign: 'center',
    },
    buttonsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginVertical: 20,
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 5,
        width: 150,
        height: 50,
        borderRadius: 8,
        borderWidth: '$primaryBorderThick',
        borderColor: '$primaryMediumTextColor',
        backgroundColor: '$primaryMediumBackground',
    },
    buttonText: {
        color: '$primaryMediumTextColor',
    },
    buttonIcon: {
        color: '$primaryMediumTextColor',
        marginEnd: 10,
    },
});
mapStateToProps = state => {
    return {
        isLoading: state.loader.isLoading,
        isRunning: state.loader.isRunning,
        options: state.loader.options,
        result: state.loader.result,
    };
};

export default connect(mapStateToProps)(Loader);
