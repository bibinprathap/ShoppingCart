import alertsHelper from 'app/api/helperServices/alerts';
import AppApi from 'app/api/real';
import { throwMimsError } from 'app/api/helperServices/utils';
import {
    dashboardChartClearAll,
    inspectionsTabClearAll,
    tasksTabClearAll,
    inspectionCalClearAll,
    inspectionTaskCalClearAll,
    getchartData,
} from 'app/actions/generic';
import { loadLatestMasterdata } from 'app/actions/masterdata';
import _ from 'lodash';
export const AUTH_BEGIN = 'AUTH_BEGIN';
export const AUTH_FAILURE = 'AUTH_FAILURE';
export const AUTH_SUCESS = 'AUTH_SUCESS';
export const AUTH_LOGOUT = 'AUTH_LOGOUT';
export const AUTH_CANCEL_LOGIN = 'AUTH_CANCEL_LOGIN';

const api = new AppApi();
import { RNFileUploader } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';

export const authBegin = (loginType, remember, username, password, fcmToken) => {
    return async (dispatch) => {
        api.dispatch = dispatch;
        var tokenData, userData;
        dispatch({
            type: AUTH_BEGIN,
            loginType,
            remember,
        });
        if (loginType == 'uaePass') {
            try {
                debugger;
                const uaePassResult = await api.uaePassSso();
                tokenData = uaePassResult.tokenData;
                userData = uaePassResult.userData;
                //console.log('smartPassSso() response... tokenData:', tokenData, 'userData: ', userData);
                if (!tokenData) throwMimsError('Error in smartpass login. TokenData not found');
                if (!userData) throwMimsError('Error in smartpass login. UserData not found');
                if (tokenData.error) throwMimsError(tokenData.error);
                if (userData.error) throwMimsError(userData.error);
                const authCode = await api.smartHubSso(tokenData, userData, fcmToken);
                if (!authCode) throwMimsError('Error in smartpass login. AuthCode not found.');
                const profiles = await api.getPofiles();
                if (!profiles || (profiles && profiles.length == 0)) throwMimsError('Not allowed to use MIMS, no active profile.');
                const activeProfileUrlArgs = profiles[0].urlArgs;
                const activeProfile = await api.switchMimsRole(activeProfileUrlArgs);
                dispatch(authSuccess({ tokenData, userData, authCode: activeProfile.authCode, profiles, activeProfileUserId: activeProfile.userId }));
            } catch (error) {
                debugger;
                dispatch(authFailure(error, tokenData));
            }
        } else if (loginType == 'smartPass') {
            try {
                const smartPassResult = await api.smartPassSso();
                tokenData = smartPassResult.tokenData;
                userData = smartPassResult.userData;
                //console.log('smartPassSso() response... tokenData:', tokenData, 'userData: ', userData);
                if (!tokenData) throwMimsError('Error in smartpass login. TokenData not found');
                if (!userData) throwMimsError('Error in smartpass login. UserData not found');
                if (tokenData.error) throwMimsError(tokenData.error);
                if (userData.error) throwMimsError(userData.error);
                const authCode = await api.smartHubSso(tokenData, userData, fcmToken);
                if (!authCode) throwMimsError('Error in smartpass login. AuthCode not found.');
                const profiles = await api.getPofiles();
                if (!profiles || (profiles && profiles.length == 0)) throwMimsError('Not allowed to use MIMS, no active profile.');
                const activeProfileUrlArgs = profiles[0].urlArgs;
                const activeProfile = await api.switchMimsRole(activeProfileUrlArgs);
                dispatch(authSuccess({ tokenData, userData, authCode: activeProfile.authCode, profiles, activeProfileUserId: activeProfile.userId }));
            } catch (error) {
                dispatch(authFailure(error, tokenData));
            }
        } else if (loginType == 'basic') {
            try {
                let authCode = await api.basicLogin(username, password);
                if (!authCode) throwMimsError('Error in basic login. AuthCode not found.');
                let profiles = await api.getPofiles();
                if (!profiles || (profiles && profiles.length == 0)) throwMimsError('Not allowed to use MIMS, no active profile.');
                const activeProfileUrlArgs = profiles[0].urlArgs;
                const activeProfile = await api.switchMimsRole(activeProfileUrlArgs);
                dispatch(authSuccess({ authCode: activeProfile.authCode, profiles, activeProfileUserId: activeProfile.userId }));
            } catch (error) {
                dispatch(authFailure(error));
            }
        } else if (loginType == 'admin') {
            try {
                const smartPassResult = await api.mockSmartPassSso();
                tokenData = smartPassResult.tokenData;
                userData = smartPassResult.userData;

                if (!tokenData) throwMimsError('Error in smartpass login. TokenData not found');
                if (!userData) throwMimsError('Error in smartpass login. UserData not found');
                if (tokenData.error) throwMimsError(tokenData.error);
                if (userData.error) throwMimsError(userData.error);
                const authCode = await api.smartHubSso(tokenData, userData, fcmToken);
                if (!authCode) throwMimsError('Error in smartpass login. AuthCode not found.');
                const profiles = await api.getPofiles();
                if (!profiles || (profiles && profiles.length == 0)) throwMimsError('Not allowed to use MIMS, no active profile.');
                const activeProfileUrlArgs = profiles[0].urlArgs;
                const activeProfile = await api.switchMimsRole(activeProfileUrlArgs);
                dispatch(authSuccess({ tokenData, userData, authCode: activeProfile.authCode, profiles, activeProfileUserId: activeProfile.userId }));
            } catch (error) {
                dispatch(authFailure(error, tokenData));
            }
        }
    };
};

export const authSuccess = (data) => {
    const activeProfileIndex = _.findIndex(data.profiles, { applicationUserId: data.activeProfileUserId });

    try {
        const userArea = data.profiles[activeProfileIndex].userArea;

        const featureLayerData = inspectionsHelper.getFeatureLayerFromArea({ userArea });
        //   console.log('auth Sucsess featureLayerData', featureLayerData);

        const polygonData = !userArea
            ? []
            : userArea.reduce((total, area) => {
                  const sectors = area.sectors;

                  sectors.map((sector) => {
                      //  console.log('sector.geometry', sector.geometry);
                      total.push({
                          PolygonID: sector.sectorCommonNameE,
                          polygonFillColor: 0x8000ff00,
                          boundaryLineColor: 0x80ff0000,
                          lineWidth: 1,
                          coords: sector.geometry,
                          checkPoints: sector.geometry.map((g, index) => {
                              return { latitude: g.latitude, longitude: g.longitude, Id: index.toString() + sector.sectorId.toString() };
                          }),
                          sectorId: sector.sectorId,
                      });
                      return sector;
                  });
                  return total;
              }, []);

        //console.log('checkPoints', polygonData);
        // console.log('polygonData', polygonData);
        const formattedData = { polygons: polygonData };
        //console.log('authSuccess console formattedData', formattedData);
        RNFileUploader.geoCheck(JSON.stringify(formattedData), data.activeProfileUserId.toString(), false, JSON.stringify(featureLayerData));
    } catch (e) {
        console.log('geoCheck error', e);
    }
    return async (dispatch) => {
        dispatch(tasksTabClearAll());
        dispatch(inspectionsTabClearAll());
        dispatch(inspectionTaskCalClearAll());
        dispatch(inspectionCalClearAll());
        dispatch({ type: AUTH_SUCESS, data });
        // dispatch(loadLatestMasterdata(new Date())).then(() => {

        // });
        dispatch(dashboardChartClearAll());
        // dispatch(getchartData());
    };
};

export const authFailure = (error, tokenData) => async (dispatch, getState) => {
    if (!error.handled) {
        const errMessage = error.message || error.detail;
        const errDetail = error.detail || error.message;
        alertsHelper.show('error', errMessage, errDetail);
    }
    try {
        // if auth failed due to profile, we need to logout from smartpass
        const ignoreSmartHubLogout = !!error.isCancel;
        await processLogout(tokenData, ignoreSmartHubLogout);
    } catch (err) {
    } finally {
        dispatch({
            type: AUTH_FAILURE,
            error,
        });
    }
};

export const authLogout = (ignoreSmartHubLogout = false) => async (dispatch, getState) => {
    const state = getState();
    const { tokenData } = state.auth || {};
    try {
        RNFileUploader.removeSharedPrefs('geoCheckData', 'userId');
    } catch (error) {}

    if (!tokenData) {
        dispatch({
            type: AUTH_LOGOUT,
        });
        return;
    }
    try {
        await processLogout(tokenData, ignoreSmartHubLogout);
    } catch (error) {
    } finally {
        dispatch({
            type: AUTH_LOGOUT,
        });
    }

    // const state = getState();
    // const tokenData = state.auth && state.auth.tokenData;
    // if (!tokenData) return;
    // await processLogout(tokenData, ignoreSmartHubLogout);
    // try {
    //     RNFileUploader.removeSharedPrefs('geoCheckData', 'userId');
    // } catch (error) {
    //     //throw error;
    // } finally {
    //     const newState = getState();
    //     const newTokenData = newState.auth && newState.auth.tokenData;
    //     if (newTokenData && tokenData.access_token == newTokenData.access_token) {
    //         dispatch({
    //             type: AUTH_LOGOUT,
    //         });
    //     }
    // }
};

export const authCancel = () => async (dispatch, getState) => {
    //console.log('authCancel() started');
    const cancelResult = await api.cancelLogin();
    //console.log('authCancel() result: ', cancelResult);
    dispatch({
        type: AUTH_CANCEL_LOGIN,
    });
    return dispatch(authLogout(true));
    //return authLogout(true);
};

const processLogout = async (tokenData, ignoreSmartHubLogout = false) => {
    //console.log('processLogout() tokenData: ', tokenData, 'ignoreSmartHubLogout: ', ignoreSmartHubLogout);
    if (!ignoreSmartHubLogout) {
        try {
            await api.smartHubLogout();
        } catch (e) {}
    }
    if (tokenData) {
        try {
            await api.smartPassLogout(tokenData.id_token, tokenData.access_token);
        } catch (e) {}
    }
};
