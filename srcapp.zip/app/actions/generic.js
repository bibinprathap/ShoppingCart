import AppApi from 'app/api/real';
import { lookup } from 'app/api/helperServices';

export const DASHBOARD_CHART_LOADING = 'DASHBOARD_CHART_LOADING';
export const DASHBOARD_CHART_SUCCESS = 'DASHBOARD_CHART_SUCCESS';
export const DASHBOARD_CHART_FAILURE = 'DASHBOARD_CHART_FAILURE';
export const DASHBOARD_CHART_CLEARALL = 'DASHBOARD_CHART_CLEARALL';
export const GET_LIST = 'GET_LIST';
export const GET_LIST_SUCCESS = 'GET_LIST_SUCCESS';
export const GET_LIST_FAILURE = 'GET_LIST_FAILURE';
export const RESET_LISTS = 'RESET_LISTS';
export const SET_PREFERENCE = 'SET_PREFERENCE';
export const SET_STATUS = 'SET_STATUS';
export const GET_HISTORY_SUCCESS = 'GET_HISTORY_SUCCESS';
export const GET_HISTORY_FAILURE = 'GET_HISTORY_FAILURE';

export const LOG_API_ERRORS = 'LOG_API_ERRORS';
export const LOG_JS_ERRORS = 'LOG_JS_ERRORS';
export const LOG_CLEAR = 'LOG_CLEAR';
export const LOG_LIMIT = 'LOG_LIMIT';
export const LOG_LEVEL = 'LOG_LEVEL';

export const DASHBOARD_INSPECTIONS_TAB_CLEARALL = 'DASHBOARD_INSPECTIONS_TAB_CLEARALL';
export const DASHBOARD_INSPECTIONS_TAB_CHANGED = 'DASHBOARD_INSPECTIONS_TAB_CHANGED';
export const DASHBOARD_INSPECTIONS_TAB_LOADING = 'DASHBOARD_INSPECTIONS_TAB_LOADING';
export const DASHBOARD_INSPECTIONS_TAB_SUCCESS = 'DASHBOARD_INSPECTIONS_TAB_SUCCESS';
export const DASHBOARD_INSPECTIONS_TAB_FAILURE = 'DASHBOARD_INSPECTIONS_TAB_FAILURE';
export const DASHBOARD_INSPECTIONS_TAB_SELECT = 'DASHBOARD_INSPECTIONS_TAB_SELECT';

export const DASHBOARD_TASKS_TAB_CLEARALL = 'DASHBOARD_TASKS_TAB_CLEARALL';
export const DASHBOARD_TASKS_TAB_CHANGED = 'DASHBOARD_TASKS_TAB_CHANGED';
export const DASHBOARD_TASKS_TAB_LOADING = 'DASHBOARD_TASKS_TAB_LOADING';
export const DASHBOARD_TASKS_TAB_SUCCESS = 'DASHBOARD_TASKS_TAB_SUCCESS';
export const DASHBOARD_TASKS_TAB_FAILURE = 'DASHBOARD_TASKS_TAB_FAILURE';
export const DASHBOARD_TASKS_TAB_SELECT = 'DASHBOARD_TASKS_TAB_SELECT';
export const DASHBOARD_TASKS_SET_PENDING_REFRESH = 'DASHBOARD_TASKS_SET_PENDING_REFRESH';

export const DASHBOARD_INSPECTIONS_CAL_CLEARALL = 'DASHBOARD_INSPECTIONS_CAL_CLEARALL';
export const DASHBOARD_INSPECTIONS_CAL_LOADING = 'DASHBOARD_INSPECTIONS_CAL_LOADING';
export const DASHBOARD_INSPECTIONS_CAL_SUCCESS = 'DASHBOARD_INSPECTIONS_CAL_SUCCESS';
export const DASHBOARD_INSPECTIONS_CAL_FAILURE = 'DASHBOARD_INSPECTIONS_CAL_FAILURE';

export const DASHBOARD_TASK_CAL_CLEARALL = 'DASHBOARD_TASK_CAL_CLEARALL';
export const DASHBOARD_TASK_CAL_FAILURE = 'DASHBOARD_TASK_CAL_FAILURE';
export const DASHBOARD_TASK_CAL_SUCCESS = 'DASHBOARD_TASK_CAL_SUCCESS';
export const DASHBOARD_TASK_CAL_LOADING = 'DASHBOARD_TASK_CAL_LOADING';

const api = new AppApi();

export const defaultPageSize = 25;

export const logAPIErrors = (message, details) => ({
    type: LOG_API_ERRORS,
    message,
    details,
});

export const logJSErrors = (message, details) => ({
    type: LOG_JS_ERRORS,
    message,
    details,
});

export const clearLogs = logType => ({
    type: LOG_CLEAR,
    logType,
});

export const logSetLimit = (logType, limit) => ({
    type: LOG_LIMIT,
    logType,
    limit,
});

export const setLogLevel = logLevel => ({
    type: LOG_LEVEL,
    logLevel,
});

export const setPreference = payload => ({
    type: SET_PREFERENCE,
    payload,
});

export const setStatus = payload => ({
    type: SET_STATUS,
    payload,
});

export const getchartData = chartConst => {
    return async dispatch => {
        dispatch({
            type: DASHBOARD_CHART_LOADING,
            chartConst,
        });
        try {
            if (chartConst === undefined) {
                const chartType = await api.getDashboardChartTypes();
                let resultAll = [];

                for (i = 0; i < chartType.length; i++) {
                    const result = await api.getDashboardCharts(chartType[i]);
                    result !== undefined ? resultAll.push(result) : null;
                }
                //resultAll.push(...tempCharts);
                //debugger;
                //console.log('getchartData() resultAll: ', resultAll);
                //resultAll.push()
                dispatch(chartSuccess(resultAll, chartConst));
            } else {
                const result = await api.getDashboardCharts(chartConst);
                dispatch(chartSuccess(result, chartConst));
            }
        } catch (err) {
            //this.setState({ loading: false, error: err });
            dispatch(chartFailure(err, chartConst));
        }
    };
};

export const chartSuccess = (result, chartConst) => ({
    type: DASHBOARD_CHART_SUCCESS,
    chartConst,
    result,
});

export const chartFailure = (error, chartConst) => ({
    type: DASHBOARD_CHART_FAILURE,
    error,
    chartConst,
});

export const dashboardChartClearAll = () => async dispatch => {
    dispatch({
        type: DASHBOARD_CHART_CLEARALL,
    });
};

export const resetLists = params => ({
    type: RESET_LISTS,
    params,
});

export const getList = params => async dispatch => {
    try {
        const data = lookup.getList(params.fieldName, params.parentId, params.parentType);
        dispatch({
            type: GET_LIST,
            params,
        });

        dispatch(getListSuccess({ ...params, data: data || [] }));
    } catch (e) {
        dispatch(getListFailure({ ...params, data: [] }));
    }
};

export const getListSuccess = params => ({
    type: GET_LIST_SUCCESS,
    params,
});

export const getListFailure = params => ({
    type: GET_LIST_FAILURE,
    params,
});

/*dashboard tabbed list start*/
export const inspectionsTabClearAll = () => async dispatch => {
    dispatch({
        type: DASHBOARD_INSPECTIONS_TAB_CLEARALL,
    });
};

export const inspectionsTabChanged = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_INSPECTIONS_TAB_CHANGED,
        payload,
    });
};

export const inspectionsTabLoad = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_INSPECTIONS_TAB_LOADING,
        payload,
    });
    const { startDate, endDate, isOrderByDesc, fixedFilter } = payload;
    const pageSize = defaultPageSize;
    const pageNumber = payload.pageNumber || 0;
    try {
        const result = await api.searchInspection({ startDate, endDate, pageSize, pageNumber, isOrderByDesc, fixedFilter });
        const { items, ...rest } = result;
        dispatch({
            type: DASHBOARD_INSPECTIONS_TAB_SUCCESS,
            payload: { ...payload, items, ...rest },
        });
    } catch (error) {
        dispatch({
            type: DASHBOARD_INSPECTIONS_TAB_FAILURE,
            payload: { ...payload, error },
        });
    }
};

const incidentTasks = [
    {
        titleE: 'ABUDHABI WASTE MANGMENT CENTER',
        titleA: 'ABUDHABI WASTE MANGMENT CENTER',
        taskId: 3801,
        assignedDate: '2020-01-28T12:06:30',
        expectedStartDate: '2020-01-29T12:06:30',
        expectedEndDate: '2020-01-30T12:06:30',
        location: {
            locationAddressId: 110195,
            coords: {
                gpsTime: null,
                accuracy: 17.1310005187988,
                longitude: 54.3783161,
                latitude: 24.4874398,
                speed: null,
                heading: null,
                altitude: null,
            },
            address: {
                zoneId: 435,
                zoneNameA: 'جزيرة أبوظبي',
                zoneNameE: 'ABU DHABI ISLAND',
                sectorId: 4312,
                sectorNameA: 'شرق 11',
                sectorNameE: 'E11',
                plotGisId: 4251901,
                plotNumber: 'P1',
            },
        },
        inspectionTypeId: 1000,
        inspectionInstanceId: 7387,
        taskStatusConst: 'New',
        taskStatusNameE: 'New',
        taskStatusNameA: 'جديد',
        icon: {
            type: 'AdmIcon',
            name: 'wf-1154',
        },
        priority: 3,
        taskType: 'Incident',
        taskTypeNameE: 'Incident',
        taskTypeNameA: 'حادث',
        assignedToUserId: 1274,
        applicationNumber: '1039',
        createdApplicationNumber: '1040',
        refNumber: '20200128120519660',
        createdInspectionTypeDetail: {
            inspectionTypeId: 1000,
            titleE: 'SiteVisit',
            titleA: 'المشوهات',
            icon: {
                type: 'AdmIcon',
                name: 'wf-1154',
            },
            inspectionTypeCheckItems: [],
            inspectionTypeConst: 'SiteVisit',
            inspEntityId: 100,
            serviceDescE: 'Distortions Service',
            serviceDescA: 'المشوهات',
        },
        inspectionTypeDetail: {
            inspectionTypeId: 1000,
            titleE: 'Distortions',
            titleA: 'المشوهات',
            icon: {
                type: 'AdmIcon',
                name: 'wf-1154',
            },
            inspectionTypeCheckItems: [],
            workflowConst: 'MimsDistortion',
            inspEntityId: 1000,
            serviceDescE: 'Distortions Service',
            serviceDescA: 'المشوهات',
        },
        urlArgs: 'f1NnUNSfbvvspQ5Ci49fPaiAPd3NAwVqy00jZlBpofCyIk4firevyw%3D%3D',
    },
];

export const tasksTabLoad = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_TASKS_TAB_LOADING,
        payload,
    });
    const { startDate, endDate, isOrderByDesc, fixedFilter } = payload;
    const pageSize = defaultPageSize;
    const pageNumber = payload.pageNumber || 0;

    try {
        const result = await api.searchInspectionTask({ startDate, endDate, pageSize, pageNumber, isOrderByDesc, fixedFilter });
        const { items, ...rest } = result;
        dispatch({
            type: DASHBOARD_TASKS_TAB_SUCCESS,
            payload: { ...payload, items, ...rest },
        });

        //##################### should remove and uncomment above
        // dispatch({
        //     type: DASHBOARD_TASKS_TAB_SUCCESS,
        //     payload: { ...payload, items: [...incidentTasks] },
        // });
        //##################### should remove
    } catch (error) {
        dispatch({
            type: DASHBOARD_TASKS_TAB_FAILURE,
            payload: { ...payload, error },
        });
    }
};

export const tasksTabClearAll = () => async dispatch => {
    dispatch({
        type: DASHBOARD_TASKS_TAB_CLEARALL,
    });
};

export const tasksTabChanged = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_TASKS_TAB_CHANGED,
        payload,
    });
};

export const tasksSetPendingRefresh = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_TASKS_SET_PENDING_REFRESH,
        payload,
    });
};

/*dashboard tabbed list end*/

/*dashboard inspection calendar list start*/

export const inspectionsCalLoad = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_INSPECTIONS_CAL_LOADING,
        payload,
    });
    const { startDate, endDate, countOnly, groupType } = payload;
    const pageSize = defaultPageSize;
    const pageNumber = 0;
    try {
        const result = await api.searchInspection({ startDate, endDate, pageSize, pageNumber, countOnly, groupType });
        if (countOnly) {
            const { countByDate: items, ...rest } = result;
            dispatch({
                type: DASHBOARD_INSPECTIONS_CAL_SUCCESS,
                payload: { ...payload, items, ...rest },
            });
        } else {
            const { items: selectedDateData } = result;
            const dateSelected = startDate;
            dispatch({
                type: DASHBOARD_INSPECTIONS_CAL_SUCCESS,
                payload: { selectedDateData, dateSelected },
            });
        }
    } catch (error) {
        dispatch({
            type: DASHBOARD_INSPECTIONS_CAL_FAILURE,
            payload: { ...payload, error },
        });
    }
};

export const inspectionCalClearAll = () => async dispatch => {
    dispatch({
        type: DASHBOARD_INSPECTIONS_CAL_CLEARALL,
    });
};

/*dashboard calendar list end*/

/*dashboard task calendar list start*/

export const inspectionsTaskCalLoad = payload => async dispatch => {
    dispatch({
        type: DASHBOARD_TASK_CAL_LOADING,
        payload,
    });

    const { startDate, endDate, countOnly, groupType } = payload;
    const pageSize = defaultPageSize;
    const pageNumber = 0;
    try {
        const result = await api.searchInspectionTask({ startDate, endDate, pageSize, pageNumber, countOnly, groupType });
        if (countOnly) {
            const { countByDate: items, ...rest } = result;
            dispatch({
                type: DASHBOARD_TASK_CAL_SUCCESS,
                payload: { ...payload, items, ...rest },
            });
        } else {
            const { items: selectedDateData } = result;
            const dateSelected = startDate;
            dispatch({
                type: DASHBOARD_TASK_CAL_SUCCESS,
                payload: { selectedDateData, dateSelected },
            });
        }
    } catch (error) {
        dispatch({
            type: DASHBOARD_TASK_CAL_FAILURE,
            payload: { ...payload, error },
        });
    }
};

export const inspectionTaskCalClearAll = () => async dispatch => {
    dispatch({
        type: DASHBOARD_TASK_CAL_CLEARALL,
    });
};

const tempCharts = [
    {
        constant: 'tempChart1',
        type: 'bar',
        nameE: 'Temp chart 1',
        nameA: 'Temp chart 1',
        xAxisLabels: [
            {
                labelE: '1',
                labelA: '1',
                labelConst: '1',
            },
            {
                labelE: '2',
                labelA: '2',
                labelConst: '2',
            },
            {
                labelE: '3',
                labelA: '3',
                labelConst: '3',
            },
            {
                labelE: '4',
                labelA: '4',
                labelConst: '4',
            },
            {
                labelE: '5',
                labelA: '5',
                labelConst: '5',
            },
            {
                labelE: '6',
                labelA: '6',
                labelConst: '6',
            },
            {
                labelE: '7',
                labelA: '7',
                labelConst: '7',
            },
        ],
        datasets: [
            {
                //color: '#ff0000',
                //datasetConst: 'dataset1',
                dataSetNameE: 'Dataset1',
                dataSetNameA: 'Dataset1',
                data: [0, 1, 3, 5, 2, 2, 4],
            },
            {
                color: '#00ff00',
                datasetConst: 'dataset2',
                dataSetNameE: 'Dataset2',
                dataSetNameA: 'Dataset2',
                data: [1, 2, 3, 4, 5, 1, 3],
            },
        ],
        urlArgs: null,
    },
    {
        constant: 'tempChart2',
        type: 'pie',
        nameE: 'Temp Chart 2',
        nameA: 'Temp Chart 2',
        xAxisLabels: [
            {
                color: '#ff0000',
                labelConst: 'InProgress',
                labelE: 'InProgress',
                labelA: 'InProgress',
            },
            {
                color: '#00ff00',
                labelConst: 'New',
                labelE: 'New',
                labelA: 'New',
            },
        ],
        datasets: [
            {
                dataSetNameE: 'Tasks',
                dataSetNameA: 'مهام',
                data: [6, 5],
            },
        ],
        urlArgs: null,
    },
];
