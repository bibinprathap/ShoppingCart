import AppApi from 'app/api/real';
import { lookup } from 'app/api/helperServices';
import { updateSettings } from 'app/actions/settings';
const api = new AppApi();

export const MASTERDATA_LOADLATEST_STARTED = 'MASTERDATA_LOADLATEST_STARTED';
export const MASTERDATA_LOADLATEST_FAILURE = 'MASTERDATA_LOADLATEST_FAILURE';
export const MASTERDATA_LOADLATEST_SUCCESS = 'MASTERDATA_LOADLATEST_SUCCESS';
export const MASTERDATA_CLEAR = 'MASTERDATA_CLEAR';

const loadLatestInternal = lastUpdated => ({
    type: MASTERDATA_LOADLATEST_STARTED,
    lastUpdated,
});

export const masterdataLoaded = data => {
    return async dispatch => {
        dispatch(updateSettings(data.settings));
        dispatch({ type: MASTERDATA_LOADLATEST_SUCCESS, data });
    };
};

export const masterdataLoadFailed = error => ({
    type: MASTERDATA_LOADLATEST_FAILURE,
    error,
});

export const clearMasterdata = () => ({
    type: MASTERDATA_CLEAR,
});

export const loadLatestMasterdata = lastUpdated => {
    return async dispatch => {
        api.dispatch = dispatch;
        dispatch(loadLatestInternal(lastUpdated));
        try {
            const data = await api.loadMasterdata(lastUpdated);
            const newData = lookup.getMasterDataFromResponse(data);
            newData.settings = {
                allowVideoRecording: true,
                maxVideoDuration: 10,
                maxfilesize: 13,
                photoResolution: 13,
                camSettingsButton: true,
                enableImageCrop: true,
            };
            dispatch(masterdataLoaded(newData));
        } catch (error) {
            dispatch(masterdataLoadFailed(error));
        }
    };
};
