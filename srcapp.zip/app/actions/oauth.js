/*
//not in use for now

import axios from 'axios';
import { AsyncStorage } from 'react-native';
import * as types from '../constants/actionTypes';
import { OAUTH2_CREDENTIALS, setHeader, clearToken, USER_DATA } from '../utils/token';

import { apiUrl as smartPassUrl } from 'app/config/smartPass';

//const apiUrl = 'https://stage.smartpass.government.net.ae';

export const onLogout = () => (dispatch, getState) => {
    const { tokens } = getState().auth;

    dispatch({ type: types.ON_LOGOUT_REQUEST });
    axios
        .get(`${smartPassUrl}/secure/oauth2/connect/endSession?id_token_hint=${tokens ? tokens.id_token : ''}`)
        .then(response => {
            dispatch(onRevokeAccessToken());
        })
        .catch(error => {
            dispatch(onRevokeAccessToken());
        });
};

export const onRevokeAccessToken = () => (dispatch, getState) => {
    const { tokens } = getState().auth;

    axios
        .post(
            `${smartPassUrl}/secure/frrest/oauth2/token/${tokens ? tokens.access_token : ''}?_action=revokeTokens`,
            { client_id: 'adm' },
            { headers: { 'Accept-API-Version': 'protocol=1.0,resource=1.0' } }
        )
        .then(response => {
            dispatch({ type: types.ON_LOGOUT_SUCCESS });
            clearToken();
        })
        .catch(error => {
            dispatch({ type: types.ON_LOGOUT_SUCCESS });
            clearToken();
        });
};

export const requestAccessToken = payload => dispatch => {
    //alert(' inside requestAccessToken method');

    axios
        .post(
            `${smartPassUrl}/secure/oauth2/access_token?realm=/TRA&code=${payload.code}&redirect_uri=${
                payload.redirectUri
            }&grant_type=authorization_code`,
            {},
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'Basic YWRtOkMtQi1QcyRVM3c3XjhOTQ==',
                },
            }
        )
        .then(response => {
            // alert(response);
            AsyncStorage.multiSet([[OAUTH2_CREDENTIALS, JSON.stringify({ ...response.data, ...payload })]], error => {});
            setHeader(response.data.access_token);
            dispatch(storeToken({ ...response.data, ...payload }));
            dispatch(getUserInformation(response.data));
        })
        .catch(error => {
            alert(error.message);
        });
};

export const autoLogin = (payload, user) => dispatch => {
    dispatch({ type: types.ON_AUTO_LOGIN, payload, user });
};
export const storeToken = payload => dispatch => {
    dispatch({ type: types.ON_STORE_OAUTH2_CREDENTIALS, payload });
};

export const getUserInformation = ({ access_token }) => (dispatch, getState) => {
    axios
        .get(`${smartPassUrl}/secure/oauth2/userinfo?realm=/TRA`, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${access_token}`,
            },
        })
        .then(response => {
            AsyncStorage.multiSet([[USER_DATA, JSON.stringify(response.data)]], error => {});
            dispatch({ type: types.ON_LOGIN_SUCCESS, payload: response.data });
        })
        .catch(error => {
            alert(error.message);
        });
};
*/
