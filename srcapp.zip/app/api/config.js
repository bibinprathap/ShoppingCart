import smartPass from 'app/api/smartPass';
import uaePass from 'app/api/uaePass';

const defaultMapServer = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer';
const defaultFeatureServer = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer';

/*
        for emulator
        ============
        baseURL: 'http://172.18.196.122:30000/api',
        timeout: 60000,
            if you are running in dev, using IISExpress do the following:
                1) adjust baseURL for your machine IP
                2) npm install -g iisexpress-proxy
                3) if you are not using run.bat, cleanrun.bat or clearrun.bat,
                   then start iisxpress-proxy as shown below
                    iisexpress-proxy [iisexpress-port] to [new-port-to-listen-on]
                    * example: iisexpress-proxy 56035 to 30000
        for device - connected via USB
        ==============================
            - make sure iisexpress-proxy is not running
            - enable port forwarding in chrome dev tools.
                1) on host machine, open this url in chrome:   chrome://inspect/#devices
                2) click on "Port forwarding"
                   enter this-> 
                        port: 56035
                        IP address and port: localhost:56035
                    select check box "Enable port forwarding" and press Done
            

*/

const common = {
    mapServer: defaultMapServer,
    featureServer: defaultFeatureServer,
    smartPass: smartPass.staging,
    uaePass: uaePass.qa,
    timeout: 60000,
};
export default config = {
    production: {
        ...common,
        title: 'Production',
        baseURL: 'https://eformsuat3.adm.gov.ae/api', //Todo: replace with production url
        smartPass: smartPass.prod,
        uaePass: uaePass.prod,
    },
    test: {
        ...common,
        title: 'Test',
        baseURL: 'https://eformstest.adm.gov.ae/api',
    },
    uat: {
        ...common,
        title: 'UAT3',
        baseURL: 'https://eformsuat3.adm.gov.ae/api',
    },
    raheel: {
        ...common,
        title: 'Raheel',
        baseURL: 'http://172.18.128.94/api',
    },
    bibin: {
        ...common,
        title: 'Bibin',
        baseURL: 'http://172.18.128.146/api',
    },
    vyshakh: {
        ...common,
        title: 'Vyshakh',
        baseURL: 'http://172.18.128.102/api',
    },
    aizaz: {
        ...common,
        title: 'Aizaz',
        baseURL: 'http://172.18.128.21/api',
    },
    awais: {
        ...common,
        title: 'Awais',
        baseURL: 'http://172.18.128.110/api',
    },
    ejaz: {
        ...common,
        title: 'Ejaz',
        baseURL: 'http://172.18.128.128/api',
    },
    naqi: {
        ...common,
        title: 'Naqi',
        baseURL: 'http://172.18.128.39/api',
    },
    deepak: {
        ...common,
        title: 'Deepak',
        baseURL: 'http://172.18.59.25/api',
    },
    saleem: {
        ...common,
        title: 'Saleem',
        baseURL: 'http://172.18.128.60/api',
    },
};
