import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { RNVideoRecord } = NativeModules;

export default RNVideoRecord;
//
