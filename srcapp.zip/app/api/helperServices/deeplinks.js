import { NavigationActions } from 'react-navigation';
import { inspectionsHelper, alertsHelper, tasksHelper } from 'app/api/helperServices';
import { clearDeeplink } from 'app/actions/settings';
// TEST deeplink command:  adb shell am start -W -a android.intent.action.VIEW -d "adm://mims/search" com.mims

class DeeplinkHelper {
    static instance = null;
    static _createInstance() {
        return new DeeplinkHelper();
    }

    static getInstance() {
        if (!DeeplinkHelper.instance) {
            DeeplinkHelper.instance = DeeplinkHelper._createInstance();
            helper = DeeplinkHelper.instance;
        }
        return DeeplinkHelper.instance;
    }

    getTaskId = notification => {
        const { routeName, param1 } = this.getRouteAndParams(notification.deeplink);
        if (routeName == 'task' && param1) return param1;
    };

    getRouteAndParams = deeplink => {
        if (!deeplink) return {};

        const route = deeplink.replace(/.*?:\/\/mims\//g, '').split('/');
        let routeName = route && typeof route[0] !== 'undefined' ? route[0] : null;
        const param1 = routeName && typeof route[1] !== 'undefined' ? route[1] : null;
        const param2 = param1 && typeof route[2] !== 'undefined' ? route[2] : null;

        return { routeName, param1, param2 };
    };

    handleLink = ({ deeplink, loggedIn, dispatch, navigation }) => {
        try {
            if (deeplink && dispatch) {
                const { routeName, param1, param2 } = this.getRouteAndParams(deeplink);

                let routeParams = {};
                let navigate = loggedIn;
                switch (routeName) {
                    case 'search':
                    case 'task':
                        const taskId = param1;
                        if (taskId) {
                            tasksHelper.selectTask({ taskId });
                        }
                    case 'scheduledWork':
                        routeParams = {};
                        break;
                    case 'inspection':
                        if (param1) {
                            navigate = false;
                            inspectionsHelper.showInspection({
                                inspectionParams: {
                                    source: 'applicationNumber',
                                    applicationNumber: '185',
                                    workflowConst: 'MimsBuildingPenaltiesandGeneralAppearance',
                                },
                                navigation,
                            });
                        }
                        break;
                    default:
                        break;
                }

                if (loggedIn) {
                    dispatch(clearDeeplink());
                    if (routeName && navigate) {
                        return navigation.dispatch(
                            NavigationActions.navigate({
                                routeName,
                                params: routeParams,
                            })
                        );
                    }
                } else {
                    alertsHelper.show('warn', 'Please login', `Please login to continue`);
                    //do nothing for now
                }
            }
        } catch (error) {}
    };
}

export default DeeplinkHelper.getInstance();
