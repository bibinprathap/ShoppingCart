import React from 'react';
import moment from 'moment';
import { _ } from 'lodash';
import * as yup from 'yup';
import { NavigationActions } from 'react-navigation';
import { createSelector } from 'reselect';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { _state, store } from 'app/config/store';
import { ValidationHelper } from 'app/api/helperServices';
import { selectInspection } from 'app/actions/inspections';
import { AbandonedVehicleConfig, GeneralAppearanceVehicleConfig } from 'app/components';
import * as inspectionActions from 'app/actions/inspections';
import { setLoading, setLoaded } from 'app/actions/loader';
import { lookup } from 'app/api/helperServices';
import { showInspectionDialog } from 'app/actions/inspectionDialog';
import alertsHelper from 'app/api/helperServices/alerts';
import { getErrorMessageWithDetail, getFeatureServerUrl, getFeatureLayersIndex, getFeatureLayersColor } from 'app/api/helperServices/utils';
import { inspectionStackDefinition } from 'app/config/routs/defs';
import { getColor } from 'app/api/helperServices/utils';
import AppApi from 'app/api/real';
const api = new AppApi();

let _allInspectionRoutes = inspectionStackDefinition;

let helper = undefined;
const QUESTION_TYPES = { YesNo: 'YesNo', YesNoNa: 'YesNoNa', Checkbox: 'Checkbox' };
const CATEGORIES = { DISTORTION: 'DISTORTION', INFOREQUEST: 'INFOREQUEST', INSPECTION: 'INSPECTION' };

yup.addMethod(yup.array, 'pendingUploadValidation', function (args) {
    const { errorMessage, inspection } = args;
    return this.test('isUploaded', errorMessage, function (attachmentlist) {
        const { path, createError } = this;
        const { currentVisit } = InspectionsHelper.getInstance().getCurrentVisit(inspection);
        const { pendingUploadDocs } = _state.attachments;
        if (currentVisit && pendingUploadDocs && Object.keys(pendingUploadDocs).length > 0 && attachmentlist) {
            const pendingUploads = _.filter(pendingUploadDocs, (p) => p.inspInstanceId == currentVisit.inspectionId);
            if (pendingUploads && pendingUploads.length > 0) {
                return createError({
                    path,
                    message: strings('uploadPending', {
                        pending: pendingUploads.length,
                        total: attachmentlist.length,
                    }),
                });
            }
        }
        return true;
    });
});

yup.addMethod(yup.mixed, 'duplicateCheckValidation', function (args) {
    const { errorMessage, inspection } = args;
    return this.test('isDuplicate', errorMessage, function (val) {
        const { path, createError } = this;
        if (inspection && inspection.duplicateInspection && inspection.duplicateInspection.checking) {
            return createError({
                path,
                message: strings('duplicatechecking'),
            });
        } else if (
            inspection &&
            inspection.duplicateInspection &&
            inspection.duplicateInspection.error &&
            inspection.duplicateInspection.error.detail &&
            inspection.duplicateInspection.error.detail.length > 0
        ) {
            return createError({
                path,
                message: strings('errorDuplicateChecking'),
            });
        } else if (
            inspection &&
            inspection.duplicateInspection &&
            inspection.duplicateInspection.duplicateCandidates &&
            inspection.duplicateInspection.duplicateCandidates.length > 0
        ) {
            if (inspection.duplicates == undefined || inspection.duplicates.length != inspection.duplicateInspection.duplicateCandidates.length) {
                const message =
                    `${inspection.duplicates ? inspection.duplicates.length : 0} ` +
                    ' verified out of ' +
                    `${inspection.duplicateInspection.duplicateCandidates.length} ` +
                    strings('possibleduplicates') +
                    ',';

                return createError({
                    path,
                    message: message,
                });
            }
        }

        return true;
    });
});

const buildingPenaltiesFormconfig = {
    name: 'buildingPenaltiesForm',
    titleE: 'Building Penalties',
    titleA: 'بناء العقوبات',
    showFormTitle: true,
    readOnly: true,
    scope: 'visit',
    collapsible: true,
    showLabels: true,
    fields: [
        {
            name: 'fieldGroup2',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'checkItemNameE',
                    type: 'text',
                    labelE: 'Name (English)',
                    labelA: 'الاسم (الإنجليزية)',
                    placeholderE: 'Name (English)',
                    placeholderA: 'الاسم (الإنجليزية)',
                    validationRule: [],
                },
            ],
        },
        {
            name: 'fieldGroup3',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'checkItemNameA',
                    type: 'text',
                    labelE: 'Name (Arabic)',
                    labelA: 'الاسم (العربية)',
                    placeholderE: 'Name (Arabic)',
                    placeholderA: 'الاسم (العربية)',
                    validationRule: [],
                },
            ],
        },
        {
            name: 'fieldGroup4',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'remarks',
                    type: 'text',
                    labelE: 'Remarks',
                    labelA: 'ملاحظات',
                    placeholderE: 'Remarks',
                    placeholderA: 'ملاحظات',
                    maxLength: 200,
                    multiline: true,
                    mode: 'flat',
                    debounce: 500,
                    validationRule: [],
                },
            ],
        },
        {
            name: 'fieldGroup5',
            type: 'fieldGroup',
            fields: [
                {
                    name: 'attachments',
                    type: 'attachmentList',
                    labelE: 'Attachments',
                    labelA: 'مرفقات',
                    validationRule: [],
                },
            ],
        },
        {
            name: 'fieldGroup6',
            type: 'fieldGroup',
            fields: [
                {
                    type: 'picker',
                    name: 'selectedActionType',
                    defaultlyNotSelected: true,
                    labelE: 'Issue Type',
                    labelA: 'نوع القضية',
                    validationRule: [],
                },
                {
                    type: 'periodPicker',
                    name: 'duration',
                    labelE: 'Duration',
                    defaultValue: { selectedPeriod: 0, selectedPeriodType: 'day' },
                    labelA: 'المدة الزمنية',
                    showIf: ['selectedPeriod>0'],
                },
                {
                    name: 'amount',
                    type: 'text',
                    labelE: 'Amount',
                    labelA: 'كمية',
                    placeholderE: 'Amount',
                    placeholderA: 'كمية',
                    showIf: ['amount>0'],
                    validationRule: ['string', 'required'],
                },
            ],
        },
    ],
};

class InspectionsHelper {
    static instance = null;
    static _createInstance() {
        return new InspectionsHelper();
    }

    static getInstance() {
        if (!InspectionsHelper.instance) {
            InspectionsHelper.instance = InspectionsHelper._createInstance();
            helper = InspectionsHelper.instance;
        }
        return InspectionsHelper.instance;
    }
    beginInspection = (inspectionTypeDetail, navigation) => {
        const { inspEntityId } = inspectionTypeDetail || { inspEntityId: 1000 };
        if (inspEntityId === 1000 || inspEntityId === 1001) {
            const createdInspection = this.createNew({ inspectionTypeDetail });
            this.showInspection({ createdInspection, navigation });
        } else {
            const theEntity = _.find(_state.masterdata.entities, {
                inspEntityId: inspEntityId,
            }) || { inspEntityId: 'UNKNOWN', nameE: 'Unknown Entity', nameA: 'جهة مجهولة' };

            alertsHelper.show('warn', theEntity.inspEntityId, `${localeProperty(theEntity, 'inspEntityName')} is not implemented.`);
        }
    };
    createNew = ({ taskId, location, inspectionTypeDetail = {} }) => {
        const newState = store.getState();
        const createdDate = moment();
        const userId = newState.auth.activeProfileUserId;
        // const services = _state.masterdata.services;
        // if (!services.find(a => a.inspectionTypeId == inspectionTypeDetail.inspectionTypeId)) {
        //     alertsHelper.show('error', strings('permission'), strings('userdonothavepermission'));
        //     return null;
        // }
        const formattedDate = createdDate.format('YYYY-MM-DD HH:mm:ss');
        const refNumber = createdDate.format('YYYYMMDDHHmmssSSS');
        return {
            createdDate: formattedDate,
            refNumber,
            inspectionStatusConst: 'draft',
            taskId,
            location,
            inspectionTypeId: inspectionTypeDetail.inspectionTypeId, //to be removed, must use inspectionTypeDetail object to find it
            //workflowConst: inspectionTypeDetail.workflowConst, //to be removed, must use inspectionTypeDetail object to find it
            inspectionTypeDetail,
            visits: [
                {
                    visitDate: formattedDate,
                    visitedByUserId: userId,
                    locallySaved: false,
                    isLast: true,
                },
            ],
            createdByUserId: userId,
        };
    };

    getViolatorsObject = (violatorType) => {
        let violator = {
            idNumber: Math.floor(Math.random() * 100000000),
            Order: 1,
            violatorType: violatorType,
            violations: [],
        };
        if (violatorType == 'individual') violator.isPresent = false;

        return violator;
    };
    findDeselectedViolations = createSelector(
        [(state) => state.currentViolations, (state) => state.previousViolations],
        (currentViolations, previousViolations) => {
            var currentViolationsSize = currentViolations.length;
            var previousViolationsSize = previousViolations.length;
            // loop through previous Violations
            for (var j = 0; j < previousViolationsSize; j++) {
                // look for same thing in new Violations
                if (currentViolations.indexOf(previousViolations[j]) == -1) return previousViolations[j];
            }
            return null;
        }
    );
    getPreviouschecklistValues = (previousState, selectedVisitIndex) => {
        const state = previousState.inspections;
        return state.history[state.currentInspectionRef].inspection.visits[selectedVisitIndex].values;
    };
    getAllViolationsFromViolators = (violators) => {
        const allViolations = violators.reduce((allviolations, violator) => {
            if (violator.violations && violator.violations.length > 0) {
                violator.violations.map((vio) => {
                    allviolations.push(vio);
                });
            }
            return allviolations;
        }, []);
        return allViolations;
    };

    findUniqueEntitiesFromServices = createSelector([(state) => state.services], (services) => {
        return _.uniqBy(services, 'inspEntityId');
    });

    findUniqueEntitiesIdFromServices = createSelector([(state) => state.services], (services) => {
        const inspEntityIds = _.map(services, (service) => service.inspEntityId);
        return _.uniq(inspEntityIds);
    });

    findService = createSelector([(state) => state.services, (state) => state.inspectionTypeId], (services, inspectionTypeId) => {
        if (inspectionTypeId) {
            return _.find(services, {
                inspectionTypeId: inspectionTypeId,
            });
        }
        return undefined;
    });

    findSubServices = createSelector(
        [(state) => state.services, (state) => state.inspectionTypeId, (state) => state.inspEntityId],
        (services, inspectionTypeId, inspEntityId) => {
            let filteredServices;
            if (inspEntityId) {
                filteredServices = _.filter(services, (item) => {
                    return item.parentInspectionTypeId == inspectionTypeId && item.inspEntityId == inspEntityId;
                });
            } else {
                filteredServices = _.filter(services, (item) => {
                    return item.parentInspectionTypeId == inspectionTypeId;
                });
            }
            if (filteredServices && filteredServices.length == 0) return undefined;
            return filteredServices;
        }
    );

    findTopLevelParentService = createSelector([(state) => state.services, (state) => state.inspectionTypeId], (services, inspectionTypeId) => {
        const parentService = _.find(services, (item) => {
            return item.inspectionTypeId == inspectionTypeId;
        });
        if (parentService && parentService.parentInspectionTypeId !== undefined) {
            return this.findTopLevelParentService({ services, inspectionTypeId: parentService.parentInspectionTypeId });
        } else {
            return parentService;
        }
    });

    findTopLevelParentServiceTree = createSelector(
        [(state) => state.services, (state) => state.inspectionTypeId, (state) => state.servicesTree],
        (services, inspectionTypeId, servicesTree) => {
            const parentService = _.find(services, (item) => {
                return item.inspectionTypeId == inspectionTypeId;
            });
            servicesTree.push(parentService);
            if (parentService && parentService.parentInspectionTypeId !== undefined) {
                return this.findTopLevelParentServiceTree({ services, inspectionTypeId: parentService.parentInspectionTypeId, servicesTree });
            } else {
                return parentService;
            }
        }
    );

    getIsEditable = createSelector([(state) => state], (currentInspection) => {
        if (currentInspection.inspection.locallySaved == true) {
            const visitsLength = currentInspection.inspection.visits.length;
            if (visitsLength > 1 && !currentInspection.inspection.visits[visitsLength - 1].locallySaved) return true;
            else return false;
        } else return true;
    });

    getIsServiceEditable = createSelector([(state) => state], (currentInspection) => {
        if (currentInspection.inspection.inspectionId) return false;
        else return true;
    });

    validateAbandonedVehicle = async (validationState, inspection) => {
        const { impoundVehicleYardId } = validationState;

        let impoundVehicleYardIdRequired = false;
        if (inspection.inspectionTypeDetail.workflowConst !== 'MimsGeneralAppearanceForCars') {
            const yardState = this.getVehicleYardState({ impoundVehicleYardId, inspection });
            impoundVehicleYardIdRequired = yardState.impoundVehicleYardIdRequired;
        }
        const validationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        if (impoundVehicleYardIdRequired) {
            validationSchema.impoundVehicleYardId = yup.string().nullable().required();
        }

        let errorLogs = {};

        try {
            //     'AbandonedVehicle.runValidation() setTheState: ',
            //     setTheState,
            //     'validationState: ',
            //     validationState,
            //     'validationSchema: ',
            //     validationSchema
            // );
            await ValidationHelper.validate(validationState, yup.object().shape(validationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map((er) => {
                errorLogs[er] = errors[er];
            });
        }

        return errorLogs;
    };

    validateResUnitOccupancyInfo = async (validationState, inspection) => {
        const validationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        let errorLogs = {};
        try {
            await ValidationHelper.validate(validationState, yup.object().shape(validationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map((er) => {
                errorLogs[er] = errors[er];
            });
        }

        return errorLogs;
    };

    validateSiteVisitInfo = async (validationState, inspection) => {
        const validationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        let errorLogs = {};
        try {
            await ValidationHelper.validate(validationState, yup.object().shape(validationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map((er) => {
                errorLogs[er] = errors[er];
            });
        }

        return errorLogs;
    };

    validateFoodTruckAndOutdoorSeating = async (validationState, inspection) => {
        const attachmentRequredMessage = strings('attachments') + ' ' + strings('isRequired');
        const remarksRequiredMessage = strings('remarks') + ' ' + strings('isRequired');
        const validationSchema = {
            attachmentList: yup.array().required(attachmentRequredMessage).pendingUploadValidation({ errorMessage: 'Upload pending', inspection }),
            permitNumber: yup
                .string()
                .nullable()
                .test('permitNumber', 'Required', function (value) {
                    return value && validationState.contractDetails && validationState.contractDetails.permitNumber === value;
                })
                .required('Required'),
            remarks: yup.string().nullable().required(remarksRequiredMessage),
            selectedActionType: yup
                .string()
                .nullable()
                .test('selectedActionType', 'Required', function (value) {
                    const { isContractExpiringInDays, followsTermsOfContract } = validationState;
                    return validationState.permitNumber && !value && (isContractExpiringInDays < 0 || followsTermsOfContract === false)
                        ? false
                        : true;
                }),
        };

        let errorLogs = {};
        try {
            await ValidationHelper.validate(validationState, yup.object().shape(validationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map((er) => {
                errorLogs[er] = errors[er];
            });
        }

        return errorLogs;
    };

    validateNoisePollution = async (validationState, inspection) => {
        const attachmentRequredMessage = strings('attachments') + ' ' + strings('isRequired');
        const remarksRequiredMessage = strings('remarks') + ' ' + strings('isRequired');
        const validationSchema = {
            attachmentList: yup.array().required(attachmentRequredMessage),
            remarks: yup.string().required(remarksRequiredMessage),
        };
        let errorLogs = {};
        try {
            await ValidationHelper.validate(validationState, yup.object().shape(validationSchema));
        } catch (errors) {
            Object.getOwnPropertyNames(errors).map((er) => {
                errorLogs[er] = errors[er];
            });
        }

        return errorLogs;
    };

    getVehicleYardState = ({ selectedActionTypeConst, impoundVehicleYardId, inspection }) => {
        let actionTypeConst = selectedActionTypeConst;
        if (actionTypeConst === undefined) {
            const { currentVisitIndex, currentVisit } = this.getCurrentVisit(inspection);
            const currentVisitCheckListValues = currentVisit != undefined ? currentVisit.values : undefined;
            const violationItems = this.getViolationItems(currentVisitCheckListValues);
            if (violationItems && violationItems.length > 0) {
                actionTypeConst = violationItems[0].selectedActionTypeConst;
            }
        }
        let newImpoundVehicleYardId = impoundVehicleYardId;
        const impoundVehicleYardIdRequired = actionTypeConst && actionTypeConst.toLowerCase() === 'violation';
        if (!impoundVehicleYardIdRequired && typeof impoundVehicleYardId !== 'undefined') {
            newImpoundVehicleYardId = undefined;
        }
        return { impoundVehicleYardId: newImpoundVehicleYardId, impoundVehicleYardIdRequired };
    };

    validateDistrotionDetails = async ({ attachments, remarks, address, inspection, distortionType, agency }) => {
        const distrotionSchema = yup.object().shape({
            attachments: yup
                .array()
                .required(strings('emptyAttachmentValidation'))
                .pendingUploadValidation({ errorMessage: 'Upload pending', inspection }),
            remarks: yup.string().required(strings('remarksIsRequired')),
            address: yup.string().required(),
            distortionType: yup.string().required(),
            agency: yup.string().required(),
            isDuplicateChecked: yup.boolean().duplicateCheckValidation({ errorMessage: '', inspection }),
        });
        let errorLogs = {};
        try {
            await ValidationHelper.validate({ attachments, remarks, address, inspection, distortionType, agency }, distrotionSchema);
        } catch (errors) {
            errorLogs = errors;
        }
        return errorLogs;
    };

    validateInspectionDetails = async (validationFields, validateDuplicates) => {
        //{ generalRemarks, address, inspection, unAssignedItems, currentVisitIndex }

        let schema = {
            address: yup.string().required(),
        };

        if (validationFields.remarks) {
            schema.remarks = yup.string().required();
        }

        const inspectionSchema = yup.object().shape(schema);
        let errorLogs = {};
        try {
            await ValidationHelper.validate(validationFields, inspectionSchema, validateDuplicates);
        } catch (errors) {
            errorLogs = errors;
        }
        return errorLogs;
    };

    nextFrame = () => {
        return new Promise(function (resolve, reject) {
            requestAnimationFrame(function () {
                resolve();
            });
        });
    };

    getInspectionKey = (inspection) => {
       
        let inspectionKey = '';
        if (inspection.createdApplicationNumber && inspection.taskType == 'Incident') {
            inspectionKey = inspection.createdApplicationNumber;
        } else if (inspection.workflowApplicationNumber) {
            inspectionKey = inspection.workflowApplicationNumber;
        } else if (inspection.applicationNumber) {
            inspectionKey = inspection.applicationNumber;
        } else if (inspection.refNumber) {
            inspectionKey = inspection.refNumber;
        }
        return inspectionKey;
    };

    getInspectionKeyFromHistory = (inspection, history) => {
        //         1) inspection.workflowApplicationNumber
        // 2) inspection.applicationNumber
        // 3) inspection.refNumber
        debugger;
        let inspectionKey = '';
        if (inspection.workflowApplicationNumber && history[inspection.workflowApplicationNumber]) {
            inspectionKey = inspection.workflowApplicationNumber;
        } else if (inspection.createdApplicationNumber && history[inspection.createdApplicationNumber]) {
            inspectionKey = inspection.createdApplicationNumber;
        } else if (inspection.applicationNumber && history[inspection.applicationNumber]) {
            inspectionKey = inspection.applicationNumber;
        } else if (inspection.refNumber && history[inspection.refNumber]) {
            inspectionKey = inspection.refNumber;
        }
        return inspectionKey;
    };

    getApplicationNumber = (inspection) => {
        let applicationNumber = '';
        const { currentVisitIndex, currentVisit } = this.getCurrentVisit(inspection);
        if (currentVisit) {
            applicationNumber = currentVisit.applicationNumber;
        } else {
            throw '  last visit Not Found';
        }

        return applicationNumber;
    };

    getRootApplicationNumber = (inspection) => inspection.applicationNumber;

    getLongTitle = (_inspectionContainer, showRefNumber) => {
        const inspection = _inspectionContainer.inspection || _inspectionContainer;
        const allServices = _state.masterdata.services;
        const { inspectionTypeDetail } = inspection;
        const serviceDef = inspection.inspectionTypeDetail;
        let titleChain = '';

        if (serviceDef.inspectionTypeId) {
            if (typeof serviceDef === 'object' && serviceDef !== null) {
                titleChain = helper._getTitleChain(serviceDef, allServices);
            } else {
                titleChain = `Service Id: ${serviceDef}`;
            }
        }
        let applicationNumber = helper.getRootApplicationNumber(inspection);

        let refNumber = '';
        let title = '';
        if (applicationNumber) {
            refNumber = showRefNumber
                ? `${!!inspectionTypeDetail.inspectionTypeId ? ' - ' : ''}${strings('referenceNumberShort')} ${
                      applicationNumber || inspection.refNumber
                  }`
                : '';
            title = `${titleChain}${refNumber}`;
        } else {
            title = `${strings('new')} ${titleChain}`;
        }

        return title;
    };

    _getTitleChain = (selectedService, allServices, currentTitle) => {
        if (!selectedService) return currentTitle;
        else {
            const newTitle = `${localeProperty(selectedService, 'title')}${currentTitle ? ' - ' + currentTitle : ''}`;
            if (selectedService.parentInspectionTypeId !== undefined && allServices) {
                const parentService = _.find(allServices, {
                    inspectionTypeId: selectedService.parentInspectionTypeId,
                });
                return helper._getTitleChain(parentService, allServices, newTitle);
            } else return newTitle;
        }
    };

    getRoutes = () => {
        const state = _state;

        const currentInspectionContainer = _state.inspections.history[_state.inspections.currentInspectionRef];
        const currentInspection = currentInspectionContainer && currentInspectionContainer.inspection;
        if (!currentInspection) return [..._allInspectionRoutes.routes];
        return this.getRoutesSelector({ currentInspection, currentInspectionVersion: _state.inspections.currentInspectionVersion });
    };

    getRoutesSelector = createSelector(
        [(state) => state.currentInspection, (state) => state.currentInspectionVersion],
        (currentInspection, currentInspectionVersion) => {
            const { currentVisitIndex, currentVisit } = this.getCurrentVisit(currentInspection);

            let selectedService = currentInspection.inspectionTypeDetail;

            let adjustedRoutes = [..._allInspectionRoutes.routes];
            let selectedWorkflowConst = null;
            let inspEntityId = null;
            if (currentInspection.inspectionTypeDetail) inspEntityId = currentInspection.inspectionTypeDetail.inspEntityId;
            //first remove ViolationDetails screen if violatorType is unknown

            if (currentInspection.inspectionTypeDetail) selectedWorkflowConst = currentInspection.inspectionTypeDetail.workflowConst;
            const isCheckList = currentVisit && currentVisit.def && currentVisit.def.type == 'checklist';
            // if (selectedService && selectedService.violatorType == undefined && !isCheckList) {
            //     adjustedRoutes = _.filter(adjustedRoutes, route => route.key != 'violationDetails');
            // }

            if (selectedWorkflowConst == 'MimsDistortion' || selectedWorkflowConst == 'MimsPavementWorks') {
                adjustedRoutes = _.filter(adjustedRoutes, (route) => route.key != 'violationDetails');
                if (
                    !(
                        currentInspection.duplicateInspection &&
                        currentInspection.duplicateInspection.duplicateCandidates &&
                        currentInspection.duplicateInspection.duplicateCandidates.length > 0
                    )
                ) {
                    adjustedRoutes = _.filter(adjustedRoutes, (route) => route.key != 'duplicateCheck');
                }
            } else {
                adjustedRoutes = _.filter(adjustedRoutes, (route) => route.key != 'duplicateCheck');
                if (selectedWorkflowConst == 'MimsHealthInspection') {
                    // If there any additional check requred, add it here
                } else if (
                    selectedWorkflowConst == 'MimsAbandonedVehicles' ||
                    selectedWorkflowConst == 'MimsGeneralAppearanceForCars' ||
                    selectedWorkflowConst == 'MimsInformationRequestOnDemand'
                ) {
                    adjustedRoutes = _.filter(adjustedRoutes, (route) => route.key != 'violationDetails');
                } else {
                    const currentVisitCheckListValues = currentVisit ? currentVisit.values : undefined;
                    if (selectedService) {
                        const violationsOptions = this.getAllViolationsOptions({
                            selectedService: selectedService,
                            checklist: currentVisitCheckListValues,
                        });

                        if (!violationsOptions || (violationsOptions && violationsOptions.length <= 0)) {
                            //if there are no violations, remove the violationDetails route
                            adjustedRoutes = _.filter(adjustedRoutes, (route) => route.key != 'violationDetails');
                        }
                    }
                }
            }
            //currentVisit;
            return adjustedRoutes;
        }
    );

    adjustRoutesForService = (allRoutes, selectedService) => {
        //Todo: if selected inspection def has no violator type, remove violationDetails screen
        const adjustedRoutes =
            selectedService && selectedService.inspectionDef && selectedService.violatorType == undefined
                ? _.filter(allRoutes, (route) => route.key != 'violationDetails')
                : [...allRoutes];
        return adjustedRoutes;
    };

    findItemDef = createSelector([(state) => state.inspTypeCheckItemId, (state) => state.inspectionDef], (inspTypeCheckItemId, inspectionDef) => {
        if (!inspectionDef || !inspectionDef.checklistGroups) return;
        for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
            const grp = inspectionDef.checklistGroups[groupIndex];
            if (!grp.checklist) continue;
            const itemDef = grp.checklist.find((c) => c.inspTypeCheckItemId == inspTypeCheckItemId);
            if (itemDef) return { questionType: itemDef.questionType, itemDef };
        }
        return undefined;
    });

    findQuestionType = createSelector([(state) => state], (inspectionDef) => {
        let questionType;
        if (!inspectionDef || !inspectionDef.checklistGroups) return;
        for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
            const grp = inspectionDef.checklistGroups[groupIndex];
            if (!grp.checklist) continue;
            grp.checklist.forEach((c) => {
                questionType = c.questionType;
            });
            // questionType = grp.questionType;
            if (questionType) return questionType;
        }
        return questionType;
    });

    findItemDefFromLawClauses = createSelector([(state) => state.lawClauseKey, (state) => state.inspectionDef], (lawClauseKey, inspectionDef) => {
        if (!inspectionDef || !inspectionDef.checklistGroups) return;
        for (var groupIndex = 0; groupIndex < inspectionDef.checklistGroups.length; groupIndex++) {
            const grp = inspectionDef.checklistGroups[groupIndex];
            if (!grp.checklist) continue;
            const connectedChecklist = grp.checklist.filter((c) => {
                if (c.violationTypeIds) return c.violationTypeIds.filter((l) => l == lawClauseKey).length > 0;
                else return false;
            });
            const itemDef = connectedChecklist[0];
            if (itemDef) return { questionType: itemDef.questionType, itemDef };
        }
        return undefined;
    });

    getPendingAttachementList = (inspection, isFailed) => {
        const pendingUploads = [];
        Object.getOwnPropertyNames(_state.attachments.pendingUploadDocs).filter((doc) => {
            if (_state.attachments.pendingUploadDocs[doc].parentInspectionId == inspection.inspectionId) {
                pendingUploads.push(_state.attachments.pendingUploadDocs[doc]);
                return true;
            }
            return false;
        });
        const hasPendingAttachementToUpload = pendingUploads.length > 0;
        if (isFailed) return pendingUploads;
        else return hasPendingAttachementToUpload;
    };

    getGeneralPreviewFormTitle = createSelector([(state) => state], (inspectionDef) => {
        let formTitle = '';
        if (inspectionDef) {
            switch (inspectionDef.name) {
                case 'abandonedVehicleInfo':
                    formTitle = localeProperty(AbandonedVehicleConfig, 'title');
                    break;
                case 'generalAppearanceVehicleInfo':
                    formTitle = localeProperty(GeneralAppearanceVehicleConfig, 'title');
                    break;
                case 'resUnitOccupancySuspicion':
                case 'resUnitOccupancyWarrantApproved':
                case 'siteVisit':
                case 'foodTruckAndOutdoorSeating':
                case 'foodTruckAndOutdoorSeatingFollowUp':
                case 'noisePollution':
                case 'abandonedVehiclesFollowup':
                case 'buildingPenaltyFollowup':
                case 'engApprovalFollowup':
                case 'buildingPenaltCheckItemPreview':
                case 'moreInfoFollowup':
                case 'generalInfo':
                case 'distortionForm':
                case 'distrotionFollowup':
                case 'buildingPenaltiesForm':
                    formTitle = '';
                    break;
                default:
                    formTitle = 'unsupported form  ' + inspectionDef.name;
                    break;
            }
        }
        return formTitle;
        //localeProperty(inspectionDef, 'title');
    });

    getViolatorsAndViolations = createSelector(
        [
            (state) => state.visit,
            (state) => state.inspectionDef,
            (state) => state.violators,
            (state) => state.duplicateCandidates,
            (state) => state.currentInspectionVersion,
        ],
        (visit, inspectionDef, violators, duplicateCandidates, currentInspectionVersion) => {
            if (!visit || !inspectionDef) return;
            // if (inspectionDef.type != 'form') return;
            const violatorsAndViolations = [];
            const violatorViolations = {};
            if (visit.values)
                visit.values.forEach((item) => {
                    const { inspTypeCheckItemId } = item;
                    let resultObj = {
                        item: item,
                    };

                    if (item.violationTypeIds && item.violationTypeIds.length > 0) {
                        item.violationTypeIds.forEach((violationTypeId) => {
                            resultObj.lawClause = this.getLawClauseByClauseId(violationTypeId);
                        });
                    }

                    if (item.violatorId) {
                        if (typeof violatorViolations[item.violatorId] === 'undefined') violatorViolations[item.violatorId] = [resultObj];
                        else violatorViolations[item.violatorId].push(resultObj);
                    }
                });
            _.map(violatorViolations, (allViolations, violatorId) => {
                const violationItems = [],
                    noActionItems = [];
                if (allViolations) {
                    allViolations.map(({ item, lawClause, questionType, itemDef }) => {
                        const { checkItemId } = item;

                        let resultObj = {
                            item: {
                                ...item,
                                amount: item.reconciled ? item.reconciledAmount : item.amount,
                            },

                            lawClause: null,
                        };

                        if (item.violationTypeIds.length > 0) {
                            item.violationTypeIds.forEach((checkItemClauseId) => {
                                resultObj.lawClause = this.getLawClauseByClauseId(checkItemClauseId);
                            });
                        }

                        violationItems.push(resultObj);

                        const violator = _.find(violators, (v) => v.violatorId == violatorId);
                        const actionConst = helper.getViolationActionTypeConst({ item });
                        if (actionConst == 'noActionTypeSelected') noActionItems.push(resultObj);
                        violatorsAndViolations.push({
                            violatordetails: violator,
                            violationItems,
                            noActionItems,
                        });
                    });
                }
            });

            return { violatorsAndViolations };
        }
    );

    // classifyAwarenessViolationWarningItems = createSelector(
    //     [state => state.inspection, state => state.inspectionDef, state => state.violators, state => state.duplicateCandidates],
    //     (inspection, inspectionDef, violators, duplicateCandidates) => {
    //         if (!inspection || !inspectionDef) return;
    //         if (inspectionDef.type != 'form') return;
    //         const violatorItems = [];
    //         if (inspectionDef.def && inspectionDef.def.length > 0) {
    //             if (inspection.info && inspection.info[inspectionDef.def[0].name] && inspection.info[inspectionDef.def[0].name].issueType) {
    //                 const actionType = inspection.info[inspectionDef.def[0].name].issueType;
    //                 const selectedPeriod = inspection.info[inspectionDef.def[0].name].duration.selectedPeriod;
    //                 const selectedPeriodType = inspection.info[inspectionDef.def[0].name].duration.selectedPeriodType;
    //                 violators.forEach(v => {
    //                     const awarenessItems = [],
    //                         warningItems = [],
    //                         violationItems = [];
    //                     if (v.violations)
    //                         v.violations.map(key => {
    //                             const duplicate = duplicateCandidates.filter(d => d.lawClausesID == key);
    //                             const amount = this.getViolationAmount({ lawClauseIDs: [key], occurance: 1, discount: 0 });
    //                             const resultObj = {
    //                                 item: {
    //                                     amount,
    //                                     selectedPeriod: selectedPeriod,
    //                                     selectedPeriodType: selectedPeriodType,
    //                                     selectedActionType: actionType,
    //                                 },
    //                                 duplicate: duplicate,
    //                                 lawClause: this.getLawClauseByClauseId(key),
    //                             };
    //                             switch (actionType) {
    //                                 case '1':
    //                                     awarenessItems.push(resultObj);
    //                                     break;
    //                                 case '2':
    //                                     warningItems.push(resultObj);
    //                                     break;
    //                                 case '3':
    //                                     violationItems.push(resultObj);
    //                                     break;
    //                                 case '4':
    //                                     warningItems.push(resultObj);
    //                                     break;
    //                                 case '5':
    //                                     violationItems.push(resultObj);
    //                                     break;
    //                                 default:
    //                                 //unknown type, ignore for now
    //                             }
    //                             return key;
    //                         });
    //                     violatorItems.push({ violationDetails: v, awarenessItems, warningItems, violationItems });
    //                     return v;
    //                 });
    //                 return { violatorItems };
    //             }
    //         }
    //         return { violatorItems: [] };
    //     }
    // );

    classifyChecklistItems = createSelector(
        [(state) => state.items, (state) => state.inspectionDef, (state) => state.violators, (state) => state.duplicateCandidates],
        (items, inspectionDef, violators, duplicateCandidates) => {
            if (!items || !inspectionDef) return;
            if (inspectionDef.type != 'checklist') return;
            const complianceItems = [],
                unAssignedItems = [];
            let totalNumberOfAwareness = 0,
                totalViolationAmount = 0,
                totalNumberOfWarning = 0;

            const violatorViolations = {};
            items.forEach((item) => {
                let violationWithDef = item;
                const { checkItemId, inspTypeCheckItemId } = item;
                const { questionType, itemDef } = helper.findItemDef({ inspTypeCheckItemId, inspectionDef: inspectionDef.def[0] }) || {};
                if (itemDef) {
                    const result = helper.classifyChecklistItem({ questionType, item, itemDef, violators, inspTypeCheckItemId });
                    let resultObj = {
                        questionType: questionType,
                        item: item,
                        itemDef: itemDef,
                    };

                    if (resultObj.item.violationTypeIds && resultObj.item.violationTypeIds.length > 0) {
                        resultObj.item.violationTypeIds.forEach((checkItemId) => {
                            resultObj.lawClause = this.getLawClauseByClauseId(checkItemId);
                        });
                    }

                    if (item.violatorId) {
                        if (typeof violatorViolations[item.violatorId] === 'undefined') violatorViolations[item.violatorId] = [resultObj];
                        else violatorViolations[item.violatorId].push(resultObj);
                    }

                    const actionConst = item.selectedActionTypeConst && item.selectedActionTypeConst.toLowerCase();

                    let increasecount = 1;
                    if (item.violationTypeIds && item.violationTypeIds.length > 0) {
                        increasecount = item.violationTypeIds.length;
                    }
                    switch (actionConst) {
                        case 'awareness':
                            totalNumberOfAwareness = totalNumberOfAwareness + increasecount;
                            break;
                        case 'warning':
                            totalNumberOfWarning = totalNumberOfWarning + increasecount;
                            break;
                        case 'violation':
                            totalViolationAmount += item.reconciled ? item.reconciledAmount : item.amount || item.registeredAmount;
                            break;
                        default:
                        //unknown type, ignore for now
                    }
                    // calculate total

                    switch (result) {
                        case 'compliance':
                            complianceItems.push(resultObj);
                            break;
                        case 'unassigned':
                            if (resultObj.item.violationTypeIds && resultObj.item.violationTypeIds.length > 0) {
                                resultObj.item.violationTypeIds.forEach((checkItemId) => {
                                    let finalresultObj = { ...resultObj };
                                    finalresultObj.lawClause = this.getLawClauseByClauseId(checkItemId);
                                    unAssignedItems.push(finalresultObj);
                                });
                            } else {
                                unAssignedItems.push(resultObj);
                            }
                            break;
                        default:
                        //unknown type, ignore for now
                    }
                }
            });

            return {
                complianceItems,
                unAssignedItems,
                totalNumberOfAwareness,
                totalViolationAmount,
                totalNumberOfWarning,
            };
        }
    );
    getServeyChecklistItems = createSelector([(state) => state.items, (state) => state.inspectionDef], (items, inspectionDef) => {
        if (!inspectionDef) return;
        if (inspectionDef.type != 'checklist') return;
        const surveyItems = [];
        // items.forEach(item => {
        //     const { inspTypeCheckItemId } = item;
        //     const { questionType, itemDef } = helper.findItemDef({ inspTypeCheckItemId, inspectionDef: inspectionDef.def[0] }) || {};
        //     if (itemDef) {
        //         let resultObj = {
        //             questionType: questionType,
        //             item: item,
        //             itemDef: itemDef,
        //         };
        //         surveyItems.push(resultObj);
        //     }
        // });
        if (inspectionDef.def && inspectionDef.def[0]) {
            for (groupDef of inspectionDef.def[0].checklistGroups) {
                const checklistItems = groupDef.checklist.map((itemDef, index) => {
                    if (itemDef) {
                        let resultObj = {
                            questionType: itemDef.questionType,
                            item: items.find((i) => i.inspTypeCheckItemId == itemDef.inspTypeCheckItemId) || {},
                            itemDef: itemDef,
                        };
                        surveyItems.push(resultObj);
                    }
                });
            }
        }
        return surveyItems;
    });

    // checkQuestionType(def, typename) {
    //     let isOptionList = false;
    //     if (def && def[0]) {
    //         for (groupDef of def[0].checklistGroups) {
    //             if (!isOptionList) {
    //                 const checklistItems = groupDef.checklist.map((item, index) => {
    //                     isOptionList = item.questionType == typename;
    //                 });
    //             }
    //         }
    //     }
    //     return isOptionList;
    // }

    classifyChecklistItem = createSelector(
        [(state) => state.questionType, (state) => state.item, (state) => state.itemDef, (state) => state.violators, (state) => state.key],
        (questionType, item, itemDef, violators, key) => {
            if (helper.checklistItemIsCompliance({ questionType, item })) return 'compliance';
            if (!item.violatorId) return 'unassigned';
            //if (helper.checklistItemIsUnAssigned({ questionType, item, violators, key })) return 'unassigned';
        }
    );

    findViolationAction = createSelector(
        [(state) => state.violationActionTypes, (state) => state.selectedActionType],
        (violationActionTypes, selectedActionType) => {
            if (violationActionTypes && selectedActionType) {
                return _.find(violationActionTypes, (item) => item.id == selectedActionType);
            }
        }
    );

    getViolationActionTypeConst = createSelector([(state) => state.item], (item) => {
        if (item.violatorId && item.isEngineerReviewRequired) return 'engineeringReview';
        if (item.selectedActionTypeConst) return item.selectedActionTypeConst.toLowerCase();
        else return 'noActionTypeSelected';
    });

    classifyViolationsItem = createSelector([(state) => state.questionType, (state) => state.item], (questionType, item) => {
        const actionItem = helper.findViolationAction({
            violationActionTypes: item.violationActionTypes,
            selectedActionType: item.selectedActionType,
        });
        const violationTypeConst = (actionItem && actionItem.constant) || null;

        if (helper.checklistItemIsAwareness({ questionType, item, violationTypeConst })) return 'awareness';
        if (helper.checklistItemIsWarning({ questionType, item, violationTypeConst })) return 'warning';
        if (helper.checklistItemIsViolation({ questionType, item, violationTypeConst })) return 'violation';
        if (item.violatorId && item.isEngineerReviewRequired) return 'engineerreviewrequired';
    });
    // checklistItemIsUnAssigned = createSelector(
    //     [state => state.questionType, state => state.item, state => state.violators, state => state.key],
    //     (questionType, item, violators, key) => {
    //         const assignedViolator = violators.filter(v => {
    //             return (
    //                 v.violations &&
    //                 v.violations.filter(a => {
    //                     if (item.violationTypeIds) return item.violationTypeIds.filter(sl => sl == a).length > 0;
    //                     else return false;
    //                 }).length > 0
    //             );
    //         });
    //         //dummy evaluation
    //         switch (questionType) {
    //             case QUESTION_TYPES.YesNo:
    //                 return item.selectedOption == 'no' && assignedViolator.length == 0;
    //             case QUESTION_TYPES.Checkbox:
    //                 return item.selectedOption == true && assignedViolator.length == 0;
    //         }
    //         return false;
    //     }
    // );

    checklistItemIsCompliance = createSelector([(state) => state.questionType, (state) => state.item], (questionType, item) => {
        switch (questionType) {
            case QUESTION_TYPES.YesNo:
                return item.selectedOption.toLowerCase() == 'yes';
            case QUESTION_TYPES.YesNoNa:
                return item.selectedOption.toLowerCase() == 'yes' || item.selectedOption.toLowerCase() == 'na';
            case QUESTION_TYPES.Checkbox:
                return item.selectedOption == false || item.selectedOption == undefined || item.selectedOption == 'false';
        }
        return false;
    });

    checklistItemIsAwareness = createSelector(
        [(state) => state.questionType, (state) => state.item, (state) => state.violationTypeConst],
        (questionType, item, violationTypeConst) => {
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return violationTypeConst == 'awareness';
                case QUESTION_TYPES.YesNoNa:
                    return violationTypeConst == 'awareness';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && violationTypeConst == 'awareness';
            }
            return false;
        }
    );
    checklistItemIsWarning = createSelector(
        [(state) => state.questionType, (state) => state.item, (state) => state.violationTypeConst],
        (questionType, item, violationTypeConst) => {
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return violationTypeConst == 'warning';
                case QUESTION_TYPES.YesNoNa:
                    return violationTypeConst == 'warning';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && violationTypeConst == 'warning';
            }
            return false;
        }
    );
    checklistItemIsViolation = createSelector(
        [(state) => state.questionType, (state) => state.item, (state) => state.violationTypeConst],
        (questionType, item, violationTypeConst) => {
            switch (questionType) {
                case QUESTION_TYPES.YesNo:
                    return violationTypeConst == 'violation';
                case QUESTION_TYPES.YesNoNa:
                    return violationTypeConst == 'violation';
                case QUESTION_TYPES.Checkbox:
                    return item.selectedOption == true && violationTypeConst == 'violation';
            }
            return false;
        }
    );

    getViolatorHeading = createSelector(
        [(state) => state.text, (state) => state.violatorType, (state) => state.violatordetails],
        (text, violatorType, violatordetails) => {
            let violatorHeading = strings('new') + ' ' + text;
            if (violatorType == 'company') {
                const companyInfo = violatordetails['company'];
                if (violatordetails['company'] && localeProperty(companyInfo, 'companyName'))
                    violatorHeading = localeProperty(companyInfo, 'companyName');
            } else if (violatorType == 'building') {
                const buildingInfo = violatordetails['building'];
                if (violatordetails['building'] && buildingInfo.buildingName) violatorHeading = buildingInfo.buildingName;
            } else if (violatorType == 'individual') {
                const individualInfo = violatordetails['violator'];
                if (violatordetails['violator'] && (individualInfo.nameE || individualInfo.nameA))
                    violatorHeading = localeProperty(individualInfo, 'name');
            } else if (violatorType == 'plot') {
                const plotInfo = violatordetails['plot'];
                if (plotInfo && plotInfo.address) violatorHeading = plotInfo.address;
            }

            return violatorHeading;
        }
    );
    getDistinctViolatorstype = createSelector([(state) => state.checklist, (state) => state.def], (checklist, def) => {
        let ViolatorsType = [];
        checklist.forEach((checkItem) => {
            if (checkItem.selectedOption == 'no' || checkItem.selectedOption == true) {
                if (checkItem.violatorType && ViolatorsType.find((v) => v == checkItem.violatorType) == undefined) {
                    ViolatorsType.push(checkItem.violatorType);
                }
                if (checkItem.possibleViolatorTypes && checkItem.possibleViolatorTypes.length > 0) {
                    checkItem.possibleViolatorTypes.map((violatorType) => {
                        if (ViolatorsType.find((v) => v == violatorType) == undefined) {
                            ViolatorsType.push(violatorType);
                        }
                    });
                }
            }
        });
        return ViolatorsType;
    });

    getAllViolators = createSelector([(state) => state.violators, (state) => state.visit], (violators, visit) => {
        let allViolators = {};
        let assignedViolators = {};

        violators.forEach((violator) => {
            allViolators[violator.violatorId] = violator;
        });

        return allViolators;
    });

    getViolationItems = createSelector([(state) => state], (values) => {
        let violationItems = [];
        if (values && values.length > 0) {
            values.forEach((v) => {
                if (v.selectedOption == 'no' || v.selectedOption == true || v.selectedOption == 'fixedViolation') {
                    if (v.violationTypeIds && v.violationTypeIds.length > 0) {
                        const vTypes = this.getViolationTypes(v.violationTypeIds);
                        vTypes.forEach((vt) => {
                            if (!violationItems.find((existingViolationItem) => existingViolationItem.violationTypeId == vt.violationTypeId)) {
                                violationItems.push({ ...vt, ...v });
                            }
                        });
                    }
                }
            });
        }
        return violationItems;
    });

    getAllViolationsOptions = createSelector([(state) => state.selectedService, (state) => state.checklist], (selectedService, checklist) => {
        let ViolatorLawClausesOptions = [];
        if (selectedService.inspectionDef && selectedService.inspectionDef.type == 'checklist') {
            checklist.forEach((checkItem) => {
                if (checkItem.selectedOption == 'no' || checkItem.selectedOption == true) {
                    if (checkItem.violationTypeIds && checkItem.violationTypeIds.length > 0) {
                        const lawOptions = this.getViolationTypeOptions(checkItem.violationTypeIds);
                        lawOptions.forEach((o) => {
                            if (!ViolatorLawClausesOptions.find((l) => l.id == o.id)) {
                                ViolatorLawClausesOptions.push({ ...o, checkItem });
                            }
                        });
                    }
                }
            });
        } else if (checklist && checklist.length > 0) {
            checklist.forEach((checkItem) => {
                if (checkItem.violationTypeIds && checkItem.violationTypeIds.length > 0) {
                    const lawOptions = this.getViolationTypeOptions(checkItem.violationTypeIds);
                    lawOptions.forEach((o) => {
                        if (!ViolatorLawClausesOptions.find((l) => l.id == o.id)) {
                            ViolatorLawClausesOptions.push({ ...o, checkItem });
                        }
                    });
                }
            });
        }
        return ViolatorLawClausesOptions;
    });

    getRemainingViolationsForSelectOptions = (violationsOptions, violators, selectedItems) => {
        let filteredViolatorsOptions = [];
        const allAllocatedViolations = this.getAllViolationsFromViolators(violators);
        violationsOptions.map((v) => {
            if (allAllocatedViolations.indexOf(v.id) == -1) filteredViolatorsOptions.push(v);
            if (selectedItems && selectedItems.indexOf(v.id) > -1) filteredViolatorsOptions.push(v);
            return true;
        });
        return filteredViolatorsOptions;
    };

    getDistortionTypeOptions(pickerOptions) {
        const distortionTypesMaster = _state.masterdata.distortionTypes;
        distortionTypesMaster.map((distortionType) => {
            pickerOptions.push({
                labelE: distortionType.titleE,
                labelA: distortionType.titleA,
                value: distortionType.inspectionTypeId,
            });
        });
        return pickerOptions;
    }

    getDistortionTypeDefaultValue() {
        const distortionTypesMaster = _state.masterdata.distortionTypes;
        if (distortionTypesMaster.length > 0) {
            return distortionTypesMaster[0].inspectionTypeId;
        }
        return '';
    }
    getDistortionTypeTitle(distortionTypeId, agencyId) {
        return lookup.getLabel('distortionType', distortionTypeId, 'agency', agencyId);
    }
    getAgencyTitle(agencyId) {
        return lookup.getLabel('agency', agencyId);
    }
    getSlaLevelTitle(slaLevelsId, agencyId, distortionType) {
        let foundItem = {};
        if (slaLevelsId && agencyId && distortionType) {
            const parentfountItem = lookup.getAllLookup()['agency'].find((data) => data.id == agencyId);
            if (parentfountItem && parentfountItem['distortionType']) {
                foundItem = parentfountItem['distortionType']
                    .find((data) => data.id == distortionType)
                    ['slaLevels'].find((data) => data.id == slaLevelsId);
            }
        }
        return foundItem && Object.getOwnPropertyNames(foundItem).length ? localeProperty(foundItem, 'label') : '';
    }

    getPickerOptions(pickerName) {
        let pickerOptions = [];
        if (pickerName == 'distortionType') {
            this.getDistortionTypeOptions(pickerOptions);
        }
        return pickerOptions;
    }

    getViolationTypes = createSelector([(state) => state], (violationTypeIds) => {
        let vTypes = [];
        violationTypeIds.map((vtid) => {
            const vt = _state.masterdata.violationTypes.find((v) => v.violationTypeId == vtid);
            if (vt) {
                vTypes.push({
                    descriptionE: vt.descriptionE,
                    descriptionA: vt.descriptionA,
                    violationTypeId: vt.violationTypeId,
                });
            }
        });
        return vTypes;
    });

    getViolationTypeOptions = createSelector([(state) => state], (violationTypeIds) => {
        let lawClausesOptions = [];
        const lawClausesMaster = _state.masterdata.violationTypes;
        violationTypeIds.map((code) => {
            const masterLawClause = lawClausesMaster.find((law) => law.violationTypeId == code);
            if (masterLawClause) {
                const lawdescription = localeProperty(masterLawClause, 'description') || 'Unknown law';
                lawClausesOptions.push({
                    title: lawdescription,
                    id: code,
                    mandatoryAwarenes: masterLawClause.mandatoryAwarenes,
                    mandatoryWarning: masterLawClause.mandatoryWarning,
                    minimumNoOfAwareness: masterLawClause.minimumNoOfAwareness,
                    minimumNoOfWarning: masterLawClause.minimumNoOfWarning,
                });
            }
        });
        return lawClausesOptions;
    });

    getLawClauseByClauseId = createSelector([(state) => state], (lawClauseId) => {
        const lawClausesMaster = _state.masterdata.violationTypes;
        return lawClausesMaster.find((law) => law.violationTypeId == lawClauseId);
    });

    getNewViolationAmount = createSelector(
        [(state) => state.fineType, (state) => state.occuranceFine, (state) => state.masteroccurance],
        (fineType, occuranceFine, masteroccurance) => {
            let newAmount = 0;
            if (fineType == 'Fixed') {
                newAmount = occuranceFine.amount;
            } else if (fineType == 'Multiplier') {
                newAmount = masteroccurance.amount * occuranceFine.value;
            }
            return newAmount;
        }
    );
    getViolationAmount = createSelector(
        [(state) => state.lawClauseIDs, (state) => state.occurance, (state) => state.discount],
        (lawClauseIDs, occurance, discount) => {
            let violationamount = 0;
            const lawClausesMaster = _state.masterdata.violationTypes;
            lawClauseIDs.map((code) => {
                const masterLawClause = lawClausesMaster.find((law) => law.violationTypeId == code);
                if (masterLawClause) {
                    let occuranceFine = masterLawClause.fines.find((f) => f.occurance == occurance);
                    //{ occurance: -1, fineType: 'fixed', amount: 600 },
                    const masteroccurance = { occurance: -1, fineType: 'Fixed', amount: masterLawClause.baseFee };
                    let newAmount = 0;
                    if (!occuranceFine) {
                        let defaultoccurance = { occurance: 0, fineType: 'Fixed', amount: masterLawClause.maxFee };
                        if (!masterLawClause.maxFee) {
                            defaultoccurance = { occurance: 0, fineType: 'Multiplier', value: masterLawClause.maxFeeMultiple };
                        }
                        if (defaultoccurance)
                            newAmount = this.getNewViolationAmount({
                                fineType: defaultoccurance.fineType,
                                occuranceFine: defaultoccurance,
                                masteroccurance: masteroccurance,
                            });
                        else
                            newAmount = this.getNewViolationAmount({
                                fineType: masteroccurance.fineType,
                                occuranceFine: masteroccurance,
                                masteroccurance: masteroccurance,
                            });
                    } else {
                        occuranceFine = { ...occuranceFine, amount: occuranceFine.value };
                        newAmount = this.getNewViolationAmount({
                            fineType: occuranceFine.fineType,
                            occuranceFine: occuranceFine,
                            masteroccurance: masteroccurance,
                        });
                    }
                    violationamount = violationamount + newAmount;
                }
            });
            if (discount > 0) {
                const discoutedAmount = violationamount * (discount / 100);
                violationamount = violationamount - discoutedAmount;
            }
            return violationamount;
        }
    );
    getViolatorType = createSelector([(state) => state.violationTypeIDs], (violationTypeIDs) => {
        let violatorTypes = null;
        const lawClausesMaster = _state.masterdata.violationTypes;
        violationTypeIDs.map((code) => {
            const masterLawClause = lawClausesMaster.find((law) => law.violationTypeId == code);
            if (masterLawClause) {
                violatorTypes = masterLawClause.violatorTypes;
            }
        });

        return violatorTypes;
    });

    getServiceByInspTypeCheckItemId = createSelector([(state) => state.def, (state) => state.inspTypeCheckItemId], (def, inspTypeCheckItemId) => {
        for (var groupIndex = 0; groupIndex < def[0].checklistGroups.length; groupIndex++) {
            const groupDef = def[0].checklistGroups[groupIndex];
            const checklistItem = _.find(groupDef.checklist, { inspTypeCheckItemId: inspTypeCheckItemId });
            if (checklistItem) return checklistItem;
        }
        return undefined;
    });
    arrayUnique = (array) => {
        var a = array.concat();
        for (var i = 0; i < a.length; ++i) {
            for (var j = i + 1; j < a.length; ++j) {
                if (a[i] === a[j]) a.splice(j--, 1);
            }
        }
        return a;
    };

    getDistinctViolationsLawClause = createSelector(
        [(state) => state.def, (state) => state.checklist, (state) => state.violatorType],
        (def, checklist, violatorType) => {
            let violationsLawClause = [];
            checklist.forEach((checkItem) => {
                if (checkItem.selectedOption == 'no' || checkItem.selectedOption == true) {
                    // let selectedServiceviolatorType = this.getServiceviolatorType({ def, parentViolatorType, code });
                    if (checkItem.violatorType == violatorType) {
                        if (checkItem.violationTypeIds) {
                            violationsLawClause = this.arrayUnique(violationsLawClause.concat(checkItem.violationTypeIds));
                        }
                    }
                } else if (checkItem.selectedOption == true) {
                    violationsLawClause = this.arrayUnique(violationsLawClause.concat(checkItem.violationTypeIds));
                }
            });
            return violationsLawClause;
        }
    );

    getAllDistinctViolationsLawClause = createSelector([(state) => state], (checklist) => {
        let violationsLawClause = [];
        checklist.forEach((checkItem) => {
            if (checkItem.selectedOption == 'no' || checkItem.selectedOption == true) {
                if (checkItem.violationTypeIds) {
                    violationsLawClause = this.arrayUnique(violationsLawClause.concat(checkItem.violationTypeIds));
                }
            }
        });
        return violationsLawClause;
    });

    getAllDistinctViolatorsViolationsLawClause = createSelector([(state) => state], (inspection) => {
        let violationsLawClause = [];
        inspection.violators.map((violator) => {
            if (violator.violations) {
                violationsLawClause = this.arrayUnique(violationsLawClause.concat(violator.violations));
            }
        });
        return violationsLawClause;
    });

    getAllViolatorsWithValidDetails = createSelector([(state) => state], (inspection) => {
        let violatorsWithValidDetails = [];
        inspection.violators.map((violator) => {
            switch (violator.violatorType) {
                case 'company':
                    if (
                        violator.company &&
                        violator.company.tradeLicenseNumber &&
                        (violator.company.companyNameA || violator.company.companyNameE) &&
                        violator.company.phoneNumber
                    ) {
                        violatorsWithValidDetails.push(violator);
                    }
                    break;
                case 'building':
                    if (violator.building && violator.building.buildingNumber && violator.building.buildingName) {
                        violatorsWithValidDetails.push(violator);
                    }
                    break;
                case 'individual':
                    if (
                        violator.violator &&
                        (violator.violator.uaeId || violator.violator.emiratesId) &&
                        violator.violator.expiryDate &&
                        (violator.violator.nameA || violator.violator.nameE) &&
                        violator.violator.nationalityName &&
                        violator.violator.birthDate
                    ) {
                        violatorsWithValidDetails.push(violator);
                    }
                    break;
                default:
                    break;
            }
        });
        return violatorsWithValidDetails;
    });

    getCurrentVisit = (inspection) => {
        let currentVisitIndex = -1;
        let currentVisit = undefined;
        if (!!inspection && !!inspection.visits && !!inspection.visits.length > 0) {
            currentVisitIndex = _.findIndex(inspection.visits, (v) => !!v.isLast);
            if (currentVisitIndex == -1) currentVisitIndex = 0;
            //if (currentVisitIndex > -1) {
            currentVisit = inspection.visits[currentVisitIndex];
            //}
        }
        return { currentVisitIndex, currentVisit };
    };
    //Todo: remove this method. not needed
    canCreateInspectionRecord = createSelector([(state) => state.inspection, (state) => state.payload], (inspection, payload) => {
        if (!inspection) return { canCreateInspection: false, reason: 'Inspection Not Available', refNumber: payload.refNumber };
        if (!(inspection.location && inspection.location.coords)) {
            return { canCreateInspection: false, reason: 'Location coordinates not available', refNumber: payload.refNumber };
        }
        if (!(inspection.location && inspection.location.address)) {
            return { canCreateInspection: false, reason: 'Location address not available', refNumber: payload.refNumber };
        }
        if (inspection.inspectionId) {
            return { canCreateInspection: false, reason: 'Inspection Already created', refNumber: payload.refNumber };
        }
        return { canCreateInspection: true, reason: 'All Values are aviable for Create Inspection', refNumber: payload.refNumber };
    });

    canCheckCheckListDuplicate = createSelector(
        [(state) => state.inspectionContainer, (state) => state.currentInspectionRef],
        (inspectionContainer, currentInspectionRef) => {
            const { inspection } = inspectionContainer;
            const selectedVisitIndex = inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def;
            let violations;
            if (inspectionDefinition && (inspectionDefinition.type == 'checklist' || inspectionDefinition.type == 'form')) {
                if (!inspection.violators || inspection.violators.length == 0) {
                    return {
                        canCheckDuplicate: false,
                        reason: 'No violators Available For Duplicate Checking',
                        refNumber: currentInspectionRef,
                    };
                }
                if (inspectionDefinition.type == 'checklist') {
                    let ViolatorsType = this.getDistinctViolatorstype({
                        checklist: selectedVisitValues || [],
                        def: inspectionDefinition.def,
                    });
                    if (ViolatorsType.length == 0) {
                        return {
                            canCheckDuplicate: false,
                            reason: 'No Violations For Duplicate Checking',
                            refNumber: currentInspectionRef,
                        };
                    }
                    violations = this.getAllDistinctViolationsLawClause(selectedVisitValues);
                    if (violations.length == 0) {
                        return {
                            canCheckDuplicate: false,
                            reason: 'No Violations LawClause Available For Duplicate Checking',
                            refNumber: currentInspectionRef,
                        };
                    }
                }
                // const violatorsWithValidDetails = this.getAllViolatorsWithValidDetails(inspection);
                // if (violatorsWithValidDetails.length != inspection.violators.length)
                //     return {
                //         canCheckDuplicate: false,
                //         reason: 'Some Violators Do Not Have Valid Details',
                //         refNumber: currentInspectionRef,
                //     };

                const violatorsViolations = this.getAllDistinctViolatorsViolationsLawClause(inspection);
                if (violatorsViolations.length == 0) {
                    return {
                        canCheckDuplicate: false,
                        reason: 'No violators Violations LawClause Available For Duplicate Checking',
                        refNumber: currentInspectionRef,
                    };
                }
                if (inspectionDefinition.type == 'checklist' && violatorsViolations.length == violations.length && inspection.inspectionId) {
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
                }
                if (inspectionDefinition.type == 'form' && violatorsViolations.length > 0 && inspection.inspectionId) {
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
                }
            }
            return {
                canCheckDuplicate: false,
                reason: 'All Values Not Available for checking Duplicate',
                refNumber: currentInspectionRef,
            };
        }
    );
    canCheckDuplicate = (state, payload, actionName) => {
        const checkingState = state ? state : _state.inspections;
        const checkingPayload = payload ? payload : {};
        const inspectionContainer = checkingState.history[checkingState.currentInspectionRef];

        if (!(inspectionContainer && inspectionContainer.inspection))
            return { canCheckDuplicate: false, reason: 'Inspection Not Available', refNumber: checkingState.currentInspectionRef };

        if (actionName == 'addressChanged') {
            if (
                inspectionContainer &&
                inspectionContainer.inspection &&
                inspectionContainer.inspection.inspectionTypeDetail &&
                inspectionContainer.inspection.inspectionTypeDetail.inspectionTypeId
            ) {
                const selectedWorkflow = inspectionContainer.inspection && inspectionContainer.inspection.inspectionTypeDetail.workflowConst;
                if (selectedWorkflow == 'MimsDistortion' && inspectionContainer.inspection.inspectionId)
                    if (
                        inspectionContainer.inspection.visits.length == 1 &&
                        inspectionContainer.inspection.visits[0].distortionForm &&
                        inspectionContainer.inspection.visits[0].distortionForm.distortionType
                    )
                        return { canCheckDuplicate: true, reason: undefined, refNumber: checkingState.currentInspectionRef };

                if (selectedWorkflow == 'MimsPavementWorks' && inspectionContainer.inspection.inspectionId)
                    if (
                        inspectionContainer.inspection.visits.length == 1 &&
                        inspectionContainer.inspection.visits[0].foodTruckAndOutdoorSeating &&
                        inspectionContainer.inspection.visits[0].foodTruckAndOutdoorSeating.permitNumber
                    )
                        return { canCheckDuplicate: true, reason: undefined, refNumber: checkingState.currentInspectionRef };

                if (selectedWorkflow != 'MimsDistortion' && selectedWorkflow != 'MimsPavementWorks' && inspectionContainer.inspection.inspectionId) {
                    return this.canCheckCheckListDuplicate({ inspectionContainer, currentInspectionRef: checkingState.currentInspectionRef });
                }
            }
        } else if (actionName == undefined) {
            const canStartApiCall = this.canStartDuplicateCheck({ inspectionContainer, currentInspectionRef: checkingState.currentInspectionRef });
            if (canStartApiCall) return canStartApiCall;
        }
        return { canCheckDuplicate: false, reason: 'All Values Not Available for checking Duplicate', refNumber: checkingState.currentInspectionRef };
    };

    canStartDuplicateCheck = createSelector(
        [(state) => state.inspectionContainer, (state) => state.currentInspectionRef],
        (inspectionContainer, currentInspectionRef) => {
            const selectedService = inspectionContainer.inspection.inspectionTypeDetail;
            if (!selectedService) return { canCheckDuplicate: false, reason: 'Service Not Available', refNumber: currentInspectionRef };
            const selectedWorkflow = inspectionContainer.inspection.inspectionTypeDetail.workflowConst;

            if (selectedWorkflow == 'MimsDistortion' || selectedWorkflow == 'MimsPavementWorks') {
                if (!(inspectionContainer.inspection.location && inspectionContainer.inspection.location.coords)) {
                    return { canCheckDuplicate: false, reason: 'location Not Available', refNumber: currentInspectionRef };
                }
                if (
                    inspectionContainer &&
                    inspectionContainer.inspection &&
                    inspectionContainer.inspection.inspectionTypeDetail.inspectionTypeId &&
                    inspectionContainer.inspection.inspectionId
                )
                    return { canCheckDuplicate: true, reason: undefined, refNumber: currentInspectionRef };
            } else {
                return this.canCheckCheckListDuplicate({ inspectionContainer, currentInspectionRef: currentInspectionRef });
            }
            return null;
        }
    );
    getViolators = (inspectionContainer) => {
        if (inspectionContainer && inspectionContainer.inspection && inspectionContainer.inspection.violators) {
            return inspectionContainer.inspection.violators;
        }
    };

    getViolatorsByViolatorType = createSelector(
        [(state) => state.inspection, (state) => state.possibleViolatorTypes],
        (inspection, possibleViolatorTypes) => {
            if (inspection && inspection.violators) {
                return inspection.violators.filter((v) => possibleViolatorTypes.indexOf(v.violatorType) !== -1);
            }
        }
    );
    getFeatureLayerFromArea = createSelector([(state) => state.userArea], (userArea) => {
        const layersIndex = getFeatureLayersIndex();
        const layersColor = getFeatureLayersColor();

        if (userArea) {
            const featureLayerData = [];
            const zoneFeaturesArray = [];
            const sectorFeaturesArray = [];
            const plotFeaturesArray = [];
            const featureServerUrl = getFeatureServerUrl();
            userArea.map((zone) => {
                if (zone.sectors.length == 0) {
                    zoneFeaturesArray.push({
                        color: layersColor.zones,

                        fields: { MUNICIPALITY: zone.municipality, DISTRICTID: zone.zoneId },
                    });
                } else {
                    zone.sectors.map((sector) => {
                        console.log('sector', sector);
                        console.log('sector.PlotGisId && sector.PlotGisId.length > 0', sector.PlotGisId && sector.PlotGisId > 0);
                        if (sector.PlotGisId && sector.PlotGisId > 0) {
                            plotFeaturesArray.push({
                                color: getColor(sector.taskStatusConst, false),

                                fields: {
                                    PLOTID: sector.PlotGisId,
                                    MUNICIPALITYENG: zone.municipality,
                                    DISTRICTID: zone.zoneId,
                                    COMMUNITYID: sector.sectorId,
                                },
                            });
                        } else {
                            sectorFeaturesArray.push({
                                color: layersColor.sectors,

                                fields: { MUNICIPALITY: zone.municipality, DISTRICTID: zone.zoneId, COMMUNITYID: sector.sectorId },
                            });
                        }
                    });
                }
                return zone;
            });

            if (zoneFeaturesArray.length > 0) {
                featureLayerData.push({
                    layer: 'district',
                    features: zoneFeaturesArray,
                    url: `${featureServerUrl}/${layersIndex.zones}`,
                });
            }
            if (sectorFeaturesArray.length > 0) {
                featureLayerData.push({
                    layer: 'community',
                    url: `${featureServerUrl}/${layersIndex.sectors}`,
                    features: sectorFeaturesArray,
                });
            }
            if (plotFeaturesArray.length > 0) {
                featureLayerData.push({
                    layer: 'plots',
                    url: `${featureServerUrl}/${layersIndex.plots}`,
                    features: plotFeaturesArray,
                });
            }
            return featureLayerData;
        }
        return [];
    });

    getDuplicateCheckRequestModel = (state, payload, refNumber) => {
        const checkingState = state ? state : _state.inspections;
        const checkingPayload = payload ? payload : {};
        const inspectionContainer = checkingState.history[checkingState.currentInspectionRef];
        return { ...inspectionContainer.inspection };
    }; //Todo: create the model to be sent to api

    getInspectionHistoryForLoggedInUser = createSelector([(state) => state.userId, (state) => state.allHistory], (userId, allHistory) => {
        let currentUserHistory = {};

        Object.keys(allHistory).map((key) => {
            const theInspectionContainer = allHistory[key];
            if (theInspectionContainer && theInspectionContainer.inspection && theInspectionContainer.inspection.createdByUserId === userId) {
                currentUserHistory[key] = theInspectionContainer;
            }
        });

        return _.orderBy(currentUserHistory, [(obj) => new moment(obj.inspection.createdDate)], ['desc']);
    });

    showInspection = async ({
        createdInspection,
        navigation,
        inspectionParams,
        onSuccess,
        gotoInspStack = false,
        showDialog = false,
        includeDraftVisit,
    }) => {
        const isShallow = false;
        let inspectionContainer = undefined;
        let inspection = undefined;
        if (createdInspection) {
            inspection = createdInspection;
            //uncommentbellowline for test
            //inspection.visits[1].def.def[0].name = 'resUnitOccupancyWarrantApproved';
            //inspection.visits[1].def.def[0].name = 'foodTruckAndOutdoorSeatingFollowUp';
        } else {
            const source = inspectionParams.source || 'applicationNumber';
            let applicationNumberToSearchFor, workflowConstToUse, inspectionTypeIdToUse;
            if (source === 'applicationNumber') {
                applicationNumberToSearchFor = inspectionParams.applicationNumber || inspectionParams.createdApplicationNumber;
                workflowConstToUse = inspectionParams.createdWorkflowConst || inspectionParams.workflowConst;
                inspectionTypeIdToUse = inspectionParams.inspectionTypeId || inspectionParams.createdInspectionTypeId;
            } else {
                applicationNumberToSearchFor = inspectionParams.createdApplicationNumber || inspectionParams.applicationNumber;
                workflowConstToUse = inspectionParams.createdWorkflowConst || inspectionParams.workflowConst;
                inspectionTypeIdToUse = inspectionParams.createdInspectionTypeId || inspectionParams.inspectionTypeId;
            }

            inspectionContainer = _state.inspections.history[this.getInspectionKey(inspectionParams)] || null;
            if (inspectionContainer) {
                //found in history, select it (set the currentInspectionRef to this one)
                //store.dispatch(inspectionActions.selectInspection(applicationNumberToSearchFor));
                await store.dispatch(selectInspection(inspectionContainer));
                inspection = inspectionContainer.inspection;
            } else {
                //not available locally, get from server
                try {
                    store.dispatch(setLoading({ options: { message: 'Loading inspection...' } }));
                    inspection = await api.getInspectionDetails({
                        workflowConst: workflowConstToUse,
                        workflowInstanceId: inspectionParams.workflowInstanceId,
                        applicationNumber: applicationNumberToSearchFor,
                        isShallow,
                        inspectionTypeId: inspectionTypeIdToUse,
                        workflowApplicationNumber: inspectionParams.workflowApplicationNumber,
                        includeDraftVisit,
                    });
                    //uncommentbellowline for test
                    //inspection.visits[1].def.def[0].name = 'resUnitOccupancyWarrantApproved';
                    //inspection.visits[1].def.def[0].name = 'foodTruckAndOutdoorSeatingFollowUp';
                } catch (e) {
                    alertsHelper.show('error', strings('failedToLoadInspectionDetails'), getErrorMessageWithDetail(e));
                } finally {
                    store.dispatch(setLoaded());
                }
            }
        }
        if (inspection) {
            //we have the inspection, either got from local store or loaded from server
            const { currentVisitIndex, currentVisit } = this.getCurrentVisit(inspection);

            if (!currentVisit) throw 'Current visit Not Found';
            let inspStatus = (inspection.inspectionStatusConst && inspection.inspectionStatusConst.toLowerCase()) || 'draft';
            let currentVisitStatus =
                (currentVisit && currentVisit.inspectionStatusConst && currentVisit.inspectionStatusConst.toLowerCase()) || 'draft';
            let saved = inspStatus === 'draft' || currentVisitStatus === 'draft' ? false : true;

            if (!inspectionContainer) {
                //wrap into the container, the inspection is loaded from server
                inspectionContainer = { status: inspStatus, saved, locallySaved: currentVisit.locallySaved || false, logs: [], inspection };
            }
            if (currentVisitStatus === 'draft') {
                await store.dispatch(selectInspection(inspectionContainer));
            }
            const { inspectionTypeConst = '' } = inspection.inspectionTypeDetail || {};
            if (inspectionTypeConst.toLowerCase() !== 'mimssitevisit' && ((!showDialog && gotoInspStack) || inspStatus === 'draft')) {
                if (navigation.navigate) {
                    return navigation.navigate('inspection');
                } else {
                    return navigation.dispatch(
                        NavigationActions.navigate({
                            routeName: 'inspection',
                            params: {},
                        })
                    );
                }
            } else {
                let inspectionDialogPayload =
                    currentVisitStatus === 'draft'
                        ? {
                              title: inspStatus === 'draft' ? strings('performInspection') : strings('followup'),
                              refNumber: this.getInspectionKey(inspection),
                              inspection: null,
                          }
                        : {
                              title: strings('inspectionDetails'),
                              refNumber: undefined,
                              inspection: inspectionContainer,
                          };

                store.dispatch(showInspectionDialog(inspectionDialogPayload));
            }
        }

        if (onSuccess) onSuccess();
    };

    getCheckListServiceByCode = (def, checkItemId) => {
        for (var groupIndex = 0; groupIndex < def.checklistGroups.length; groupIndex++) {
            const groupDef = def.checklistGroups[groupIndex];
            const checklistItem = _.find(groupDef.checklist, { checkItemId: checkItemId });
            if (checklistItem) return checklistItem;
        }
        return {};
    };

    getMimsInspectionModelFromResponse = ({ visits, ...params }, locallySaved = true) => {
        const visitsData = [];
        visits.forEach(({ ...visit }) => {
            visitsData.push({
                ...visit,
                locallySaved: locallySaved,
            });
        });

        return { ...params, visits: visitsData };
    };

    getStartAndConfirmInspectionRequestModel = ({ visits, violators, inspectionTypeDetail, duplicateInspection, ...params }) => {
        const visitsModel = [];
        visits.forEach(({ def, ...visit }) => {
            const valuesModel = [];
            if (visit.values) {
                visit.values.forEach((checkItem) => {
                    //const { duplicateInspection, attachments, violationActionTypes, ...visitValues } = checkItem;
                    const { violationActionTypes, duplicateInspection, ...visitValues } = checkItem;
                    let newvisitValues = { ...visitValues };
                    valuesModel.push({
                        ...newvisitValues,
                        selectedPeriod: newvisitValues.selectedPeriod || 0,
                    });
                });
            }
            visitsModel.push({ ...visit, values: valuesModel, generalInfo: visit.generalInfo || { remarks: null } });
        });
        let lastVisit = visitsModel.find((v) => v.isLast == true);
        if (!lastVisit && visitsModel.length > 0) {
            visitsModel[visitsModel.length - 1].isLast = true;
            lastVisit = visitsModel[visitsModel.length - 1];
            lastVisit.isLast = true;
        }
        if (!lastVisit.inspectionId) lastVisit.inspectionId = params.inspectionId;
        const violatorsModel = [];
        if (violators && violators.length > 0) {
            violators.forEach(({ detail, ...violator }) => violatorsModel.push({ ...violator, isPresent: !!violator.isPresent }));
            // need to remove detail from violator object. otherwise start and confirm will fail
            //violators.forEach(({ detail, ...violator }) => violatorsModel.push({ ...violator, isReconciled: !!violator['signature'] }));
        }

        let isDuplicateChecked = false;
        if (duplicateInspection) {
            if (params.duplicates && params.duplicates.length == duplicateInspection.duplicateCandidates.length) isDuplicateChecked = true;
        }
        return {
            ...params,
            inspectionTypeId: inspectionTypeDetail.inspectionTypeId,
            inspectionTypeDetail,
            isDuplicateChecked,
            visits: visitsModel,
            violators: violatorsModel,
        };
    };
}
export default InspectionsHelper.getInstance();
