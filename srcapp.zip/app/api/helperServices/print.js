import { strings, localeProperty } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import moment from 'moment';
import { store } from 'app/config/store';
import { inspectionsHelper, lookup, liquidEngine, zebra } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { setStatus } from 'app/actions/generic';
import { testTemplate } from 'app/api/mockData';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';

import { NativeModules, NativeEventEmitter, Platform } from 'react-native';
const { Zebra } = NativeModules;
const ZebraEmitter = Platform.OS === 'android' ? new NativeEventEmitter(Zebra) : {};

const companyViolatorFields = ['companyName', 'tradeLicenseNumber'];
const individualViolatorFields = ['nameA', 'nameE', 'emiratesId'];
const abandonedVehicleInfoFields = ['emirate', 'plateNumber'];

let helper = null;
let zebraListener = null;
class PrintHelper {
    static instance = null;
    static _createInstance() {
        return new PrintHelper();
    }

    static getInstance() {
        if (!PrintHelper.instance) {
            PrintHelper.instance = PrintHelper._createInstance();
            helper = PrintHelper.instance;
            helper.listenPrinterEvents();
        }
        return PrintHelper.instance;
    }

    listenPrinterEvents = () => {
        zebraListener = zebra.addListener(res => {
            switch (res.eventCode) {
                case 'CONNECTED':
                    store.dispatch(setStatus({ isPrinterConnected: true, isPrinting: true }));
                    break;

                case 'PRINTING_START':
                    store.dispatch(setStatus({ isPrinting: true }));
                    break;

                case 'PRINTING_ENDS':
                    store.dispatch(setStatus({ isPrinting: false }));
                    break;

                case 'PRINTER_NO_PAPER':
                    store.dispatch(setStatus({ isPrinting: false }));
                    break;

                case 'DISCONNECTED':
                    store.dispatch(setStatus({ isPrinterConnected: false, isPrinting: false }));
                    break;

                case 'CONNECT_ERROR':
                    store.dispatch(setStatus({ isPrinting: false, isPrinterConnected: false }));
                    break;
            }
        });
    };

    removeListener = () => {
        if (zebraListener) {
            zebraListener.remove();
        }
    };

    getTranslation = key => {
        const secondLastChar = key.substr(-2, 1);
        const lastChar = key.substr(-1);
        if ((lastChar === 'E' || lastChar === 'A') && secondLastChar === secondLastChar.toLowerCase()) {
            const locale = lastChar === 'A' ? 'ar' : 'en';
            return strings(key.slice(0, -1), { locale });
        } else {
            return strings(key);
        }
    };

    getViolationTitle = (item, currentTitle) => {
        let selectedActionType = currentTitle;
        if (!selectedActionType) {
            selectedActionType = item.selectedActionType;
        } else if (item.selectedActionType === 'violations') {
            selectedActionType = item.selectedActionType;
        } else if (item.selectedActionType === 'warning' && selectedActionType !== 'violations') {
            selectedActionType = item.selectedActionType;
        } else if (item.selectedActionType === 'awareness' && selectedActionType !== 'violations' && selectedActionType !== 'warning') {
            selectedActionType = item.selectedActionType;
        }
        return selectedActionType;
    };

    getInspectionChecklistParams = params => {
        const { violationItems, violatordetails, currentVisitData, inspection } = params;
        const { generalInfo, visitDate, def, applicationNumber } = currentVisitData;

        const address = (inspection.location && inspection.location.address) || {};
        let registeredAmount = 0;
        const printParams = {
            applicationNumber,
            isWarning: 1,
            id: inspection.inspectionId,
            inspectorCode: '8888',
            referenceNumber: inspection.refNumber,
            muncipalCenterName_ar: 'مركز البلد',
            muncipalCenterName_en: 'Muncipal CenterName en',
            zoneSecPlot: 'المنطقة' + address.zoneNameA + '،القطاع' + address.sectorNameA + '،القطعة' + address.plotNumber,
            violations: [],
            registeredAmount: '0',
            note: `${generalInfo.remarks}`,
            idReceived: 'YES',
        };

        const questionType = inspectionsHelper.findQuestionType(def && def.def[0]);

        let selectedActionType = '';

        violationItems.forEach(violation => {
            const { item } = violation;
            selectedActionType = helper.getViolationTitle(item, selectedActionType);
            if (item.violationTypeIds && item.violationTypeIds.length) {
                item.violationTypeIds.forEach(lawClauseId => {
                    if (violation.lawClause && violation.lawClause.violationTypeId === lawClauseId) {
                        printParams.violations.push(violation.lawClause.descriptionA);
                        printParams.violations.push(violation.lawClause.descriptionE);
                    }
                });
            }

            if ((questionType === 'Checkbox' && item.selectedOption === true) || (questionType !== 'Checkbox' && item.selectedOption === 'no')) {
                registeredAmount += item.registeredAmount;
                printParams.violations.push(`AED ${item.registeredAmount}`);
            }
        });
        if (selectedActionType) {
            printParams.selectedActionTypeA = strings(selectedActionType, { locale: 'ar' });
            printParams.selectedActionTypeE = strings(selectedActionType, { locale: 'en' });
        }

        if (violatordetails) {
            printParams.violatorDetailsList = [];
            if (visitDate) {
                printParams.visitDate = moment(visitDate).format('M/D/YYYY h:m:s a');
            }
            const { violatorType, company, violator } = violatordetails;
            printParams.idReceived = violator.signature ? 'YES' : 'NO';
            switch (violatorType) {
                case 'company':
                    Object.keys(company).map(function(key) {
                        if (companyViolatorFields.indexOf(key) !== -1) {
                            printParams.violatorDetailsList.push(helper.getTranslation(key) + ':' + company[key]);
                        }
                    });
                    break;
                case 'individual':
                    Object.keys(violator).map(function(key) {
                        if (individualViolatorFields.indexOf(key) !== -1) {
                            printParams.violatorDetailsList.push(helper.getTranslation(key) + ':' + violator[key]);
                        }
                    });
                    break;
                default:
                    break;
            }
        }
        return printParams;
    };

    getInspectionParams = params => {
        const { inspection, currentVisitData, inspectorCode } = params;
        const { applicationNumber } = currentVisitData;
        const visit = inspection && inspection.visits && inspection.visits[0];
        if (!visit) {
            return {};
        }

        const { violators } = inspection;
        const { abandonedVehicleInfo } = inspection.info;
        const { generalInfo } = visit;
        const visitDate = moment(visit.values.visitDate).format('M/D/YYYY h:m:s a');
        const address = (inspection.location && inspection.location.address) || {};
        let registeredAmount = 0;
        const printParams = {
            applicationNumber,
            referenceNumber: inspection.refNumber,
            isWarning: 1,
            id: inspection.inspectionId,
            inspectorCode,
            visitDate: visitDate,
            muncipalCenterName_ar: 'مركز البلد',
            muncipalCenterName_en: 'Muncipal CenterName en',
            zoneSecPlot: 'المنطقة' + address.zoneNameA + '،القطاع' + address.sectorNameA + '،القطعة' + address.plotNumber,
            violations: [],
            violatorDetailsList: [],
            registeredAmount: '0',
            note: `${generalInfo.remarks}`,
            idReceived: 'NO',
        };

        const violatordetails = violators[0];
        if (violatordetails) {
            const { violatorType, company, violator, violations } = violatordetails;

            violations.forEach(violationId => {
                const lawClause = inspectionsHelper.getLawClauseByClauseId(violationId);
                if (lawClause) {
                    printParams.violations.push(lawClause.descriptionA);
                    printParams.violations.push(lawClause.descriptionE);

                    if (lawClause.fines[0].value) {
                        printParams.violations.push(`AED ${lawClause.fines[0].value}`);
                        registeredAmount += lawClause.fines[0].value;
                    }
                }
            });

            printParams.idReceived = violatordetails.signature ? 'YES' : 'NO';
            printParams.registeredAmount = registeredAmount;

            switch (violatorType) {
                case 'company':
                    Object.keys(company).map(function(key) {
                        if (companyViolatorFields.indexOf(key) !== -1) {
                            printParams.violatorDetailsList.push(getTranslation(key) + ':' + company[key]);
                        }
                    });
                    break;
                case 'individual':
                    Object.keys(violator).map(function(key) {
                        if (individualViolatorFields.indexOf(key) !== -1) {
                            printParams.violatorDetailsList.push(getTranslation(key) + ':' + violator[key]);
                        }
                    });
                    break;
                default:
                    break;
            }

            if (abandonedVehicleInfo) {
                Object.keys(abandonedVehicleInfo).map(function(key) {
                    if (abandonedVehicleInfoFields.indexOf(key) !== -1) {
                        let value = abandonedVehicleInfo[key];
                        if (key === 'emirate') {
                            value = lookup.getLabel(key, value);
                        }
                        printParams.violatorDetailsList.push(getTranslation(key) + ':' + value);
                    }
                });
            }
        }
        return printParams;
    };

    getParsedTemplate = async (receiptTemplate, serviceWorkflowConst, params) => {
        try {
            let printParams = null;
            switch (serviceWorkflowConst) {
                case 'INSPECTION_CHECKLIST':
                    printParams = helper.getInspectionChecklistParams(params);
                    break;
                case 'MimsBuildingPenaltiesandGeneralAppearance':
                case 'MimsGeneralAppearanceForCars':
                case 'MimsOccupancyLaw':
                case 'MimsInspectionPlanImplementation':
                case 'MimsAbandonedVehicles':
                case 'MimsInformationRequestOnDemand':
                case 'MimsInspectionPlanApproval':
                    printParams = helper.getInspectionParams(params);
                    break;
            }
            if (printParams) {
                return liquidEngine.parseAndRender(receiptTemplate, printParams);
            }
        } catch (error) {
            throw error;
        }
    };

    print = async (printerAddress, serviceWorkflowConst, params) => {
        let status = (store.getState().generic && store.getState().generic.status) || {};
        let selectedPrinter = store.getState().settings.selectedPrinter || {};
        if (!printerAddress) return;

        try {
            store.dispatch(setStatus({ isPrinting: true }));

            const receiptTemplate = store.getState().masterdata && store.getState().masterdata.printTemplate;
            if (!receiptTemplate) {
                alertsHelper.show('error', 'Printer', 'Template not found');
                store.dispatch(setStatus({ isPrinting: false }));
                return;
            }

            const blockingTaskOptions = {
                id: 'printing',
                message: strings('printing'),
                autoClose: true,
                autoRetry: false,
                maxTries: 5,
                runner: async (options, updateOptions) => {
                    try {
                        const zplInvoiceTemplate = await helper.getParsedTemplate(receiptTemplate, serviceWorkflowConst, params);
                    } catch (error) {
                        updateOptions({ ...options, maxTries: 1, autoClose: false });
                        throw ` ${getErrorMessageWithDetail(error)}`;
                    }

                    const finalResult = await new Promise(async (resolve, reject) => {
                        updateOptions({ ...options, message: `Connecting to ${selectedPrinter.name}` });
                        zebra
                            .connect(printerAddress)
                            .then(isConnected => resolve())
                            .catch(error => reject(`Failed to connect`));
                    })
                        .then(() => {
                            updateOptions({ ...options, message: strings('printing') });
                            //zplInvoiceTemplate or testTemplate
                            zebra
                                .print(testTemplate)
                                .then(success => {
                                    resolve();
                                })
                                .catch(error => reject('Print error'));
                        })
                        .catch(error => {
                            throw getErrorMessageWithDetail(error);
                        });

                    return finalResult;
                },
            };

            try {
                const result = await runBlockingTask(blockingTaskOptions);
            } catch (error) {}
        } catch (e) {
            alertsHelper.show('error', 'Printer', 'Print error');
            helper.currentData = null;
            store.dispatch(setStatus({ isPrinting: false }));
        }
        return;
    };
}

export default PrintHelper.getInstance();
