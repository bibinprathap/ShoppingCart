import { I18nManager } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import moment from 'moment';
import { _state, store } from 'app/config/store';
import { setLoading, setLoaded } from 'app/actions/loader';
import { createIconSetFromIcoMoon } from 'react-native-vector-icons';
import createError from 'app/api/helperServices/errors';
import admIconIcomoonConfig from 'app/api/iconMaps/admIconSelection.json';
import admIconMap from 'app/api/iconMaps/admIconMap.json';
import envConfig from 'app/api/config';
const defaultSeparator = I18nManager.isRTL ? '،' : ',';
const defaultOptions = { includeHeadings: true, separator: defaultSeparator, headingSeparator: ':', addSpacesAfterSeparators: true };

const defaultColor = '#454F63';
const palette = ['#009900', '#cc00ff', '#0066ff', '#ff0000', '#07575b', '#ffbb00', '#0000ff', '#ff420e', '#763626', '#aebd38'];
const statusAndTypePalette = {
    draft: '#959DAD',
    new: '#349EFB',
    inprogress: '#3ACCE1',
    completed: '#62b42c',
    overdue: '#F23B6C',
    infollowup: '#FFB900',
    gray: '#F7F7FA',
    green: '#62b42c',
    dataset1: '#000000', //for testing
    dataset2: '#00ff00', //for testing
};

export function randomColor() {
    return ('#' + ((Math.random() * 0xffffff) << 0).toString(16) + '000000').slice(0, 7);
}

export function getColor(indexOrCode, random = true) {
    let color;
    if (isNaN(indexOrCode)) color = getStatusOrTypeColor(indexOrCode, random);
    else {
        if (indexOrCode) {
            color = palette[indexOrCode];
        }
    }

    if (!color) {
        if (random) color = randomColor();
        else color = defaultColor;
    }
    return color;
}

function getStatusOrTypeColor(status, random) {
    //if (!isNaN(status)) return getColor(status); //its a number, return the color from indexed palette
    let color;
    if (status) {
        color = statusAndTypePalette[status.toLowerCase()];
    }
    if (!color) {
        if (random) color = randomColor();
        else color = statusAndTypePalette['default'];
    }
    return color;
}

function getComonChartData(chartData, svgType = 'fill') {
    //console.log('transforming ', localeProperty(rawData, 'name'), ' rawData: ', rawData);
    const mainData = [];
    const datasets = chartData.datasets || [];
    for (var datasetIndex in datasets) {
        const dataset = datasets[datasetIndex];
        const { color, datasetConst } = dataset;
        if (dataset && dataset != null) {
            //console.log('transforming datasetIndex: ', datasetIndex, 'dataset: ', dataset, 'chartData: ', chartData);
            const transformedDataSet = { data: dataset.data || [], svg: { [svgType]: color ? color : getColor(datasetConst || datasetIndex) } };

            mainData.push(transformedDataSet);
        }
    }
    return mainData;
}

export function getBarChartData(chartData) {
    const data = getComonChartData(chartData, 'fill');
    const xAxisData = getXAxisData(chartData);
    const yAxisData = getYAxesData(chartData);
    //console.log('getBarChartData() data: ', data, 'xAxisData: ', xAxisData, 'yAxisData: ', yAxisData, 'raw chartData: ', chartData);
    return { data, xAxisData, yAxisData };
}

export function getLineChartData(chartData) {
    const data = getComonChartData(chartData, 'stroke');
    const xAxisData = getXAxisData(chartData);
    const yAxisData = getYAxesData(chartData);
    //console.log('getLineChartData() data: ', data, 'xAxisData: ', xAxisData, 'yAxisData: ', yAxisData, 'raw chartData: ', chartData);
    return { data, xAxisData, yAxisData };
}

export function getPieChartData(chartData) {
    const firstDataSet = (chartData.datasets || [])[0]; //we only care about first dataset in piechart
    let pieData = [];
    //console.log('transforming firstDataSet: ', firstDataSet, 'chartData: ', chartData);
    if (firstDataSet && firstDataSet.data) {
        pieData = firstDataSet.data.map((value, index) => {
            const label = (chartData.xAxisLabels || [])[index] || {};
            const { color, labelConst } = label;
            return {
                value: value || 0,
                svg: { fill: color ? color : getColor(labelConst || index) },
                key: `pie-${index}`,
            };
        });
    }
    return pieData;
}

export function getXAxisData(chartData) {
    const { xAxisLabels = [] } = chartData;
    const xAxisData = xAxisLabels.map((lbl, index) => {
        let translatedItem = localeProperty(lbl, 'label');
        if (!translatedItem) translatedItem = lbl.label;
        if (!translatedItem) translatedItem = index;
        return translatedItem;
    });

    //console.log('getXAxesData() xAxisData: ', xAxisData, 'chartData: ', chartData);
    return xAxisData;
}

export function getYAxesData(chartData) {
    const datasets = chartData.datasets || [];
    const AllValues = datasets.map(ds => ds.data || []).reduce((a, b) => a.concat(b));
    const yMax = Math.max(...AllValues) || 0;
    const yMin = Math.min(...AllValues) || 0;
    const yAxisData = [yMin, yMax];
    //console.log('getYAxesData() yAxisData: ', yAxisData);
    return yAxisData;
}

export function getAdmIconSet() {
    return createIconSetFromIcoMoon(admIconIcomoonConfig, 'admIcon', 'adm-icon.ttf');
}

export function getIconUnicode(type, name) {
    let code = 0;
    switch (type) {
        case 'AdmIcon':
            code = admIconMap[name] || admIconMap['default'];
            break;
        default:
            break;
    }
    return code;
}

export function getErrorMessageWithDetail(e) {
    let combinedMessage = '';
    if (!!e) {
        if (typeof e === 'object') {
            const msg = e.message || '';
            const dtl = e.detail || '';
            const separator = msg !== '' && dtl !== '' ? ', ' : '';
            combinedMessage = `${msg}${separator}${dtl}`;
        } else combinedMessage = e;
    }
    return combinedMessage;
}
export function throwMimsError(msg, e) {
    var concatenatedMessage = e ? `${msg}. ${getErrorMessageWithDetail(e)}` : msg;
    throw createError(new Error(concatenatedMessage));
}

export const groupItemsByDate = (items, dateField, order = 'desc') => {
    const format = 'YYYYMMDD';
    const getDateSring = dt => {
        const currentDate = moment();
        const currentDateFormated = currentDate.format(format);
        if (dt === currentDate.format(format)) return strings('today');
        else if (dt === currentDate.add(1, 'days').format(format)) return strings('tomorrow');
        else if (dt === currentDate.subtract(1, 'days').format(format)) return strings('yesterday');
        else if (moment(dt, format).diff(currentDateFormated, 'days') < 1) return strings('older');
        else if (moment(dt, format).diff(currentDateFormated, 'days') > 1) return strings('later');
        return dt;
    };

    const sortedArray = _.orderBy(
        items,
        item => {
            return moment(item[dateField]).format(format);
        },
        [order]
    );

    const groupedTasks = _.groupBy(sortedArray, item => {
        const dt = moment(item[dateField]).format(format);
        return getDateSring(dt);
    });

    const priorityKey = strings('today');
    if (typeof groupedTasks[priorityKey] !== 'undefined') {
        const { [priorityKey]: priorityTask, ...otherTasks } = groupedTasks;
        return { [priorityKey]: priorityTask, ...otherTasks };
    }
    return groupedTasks;
};

export function objectToQueryString(obj) {
    const queryString = Object.keys(obj)
        .filter(key => {
            return obj[key] !== undefined;
        })
        .map(key => {
            if (obj[key] !== undefined) return key + '=' + obj[key];
        })
        .join('&');
    return queryString;
}

export function objectToGisFilter(obj) {
    const arr = Object.keys(obj)
        .filter(key => {
            return obj[key] !== undefined;
        })
        .map(key => {
            let formattedVal = obj[key];
            const typeOfVal = typeof formattedVal;
            switch (typeOfVal) {
                case 'object':
                    formattedVal = formattedVal.toString();
                    break;
                case 'string':
                    formattedVal = `'${obj[key]}'`;
                    break;
                case 'boolean':
                case 'number':
                //do nothing
            }
            return key + '=' + formattedVal;
        });
    //.join(' and ');
    if (arr && arr.length > 0) return arr.join(' and ');
}

export function getEnvironmentConfig(env) {
    const _env = env || _state.settings.environment || 'development';

    return envConfig[_env];
}

export function getFeatureServerUrl(env) {
    const _envConfig = getEnvironmentConfig(env);
    if (_envConfig) return _envConfig.featureServer;
}

export function getFeatureLayersIndex(env) {
    return {
        zones: 2,
        sectors: 1,
        plots: 5,
    };
}

export function getFeatureLayersColor(env) {
    return {
        zones: 0xffff0000,
        sectors: 0xff00ff00,
        plots: 0xff0000ff,
    };
}

export function getMapServerUrl(env) {
    const _envConfig = getEnvironmentConfig(env);
    if (_envConfig) return _envConfig.mapServer;
}

export function formatAddress(address, options) {
    /*
        This does the following:
            - replaces multiple consecutive white spacesd with just one. example: 'a  b' -> 'a b'
            - gets rid of leading or trailing shite spaces. example ' ab ' -> 'ab'
            - includes the Zone/Sector/Plot headings if needed
            - adds the desired separator between values when more than one parts of the address are available. example: zone, sector, plot
            - returns 'emptyAddress' message when none of the address parts are available
            - uses arabic/english headings depending upon current language
    */
    if (!address) return strings('emptyAddress');
    const appliedOptions = { ...defaultOptions, ...options };
    const { includeHeadings, separator, headingSeparator, addSpacesAfterSeparators } = appliedOptions;
    let _separator = addSpacesAfterSeparators ? `${separator} ` : separator;
    const _headingSeparator = addSpacesAfterSeparators ? `${headingSeparator} ` : headingSeparator;
    let zoneHeading = '',
        sectorHeading = '',
        plotHeading = '',
        streetHeading = '';
    if (includeHeadings) {
        zoneHeading = `${strings('zone')}${_headingSeparator}`;
        sectorHeading = `${strings('sector')}${_headingSeparator}`;
        streetHeading = `${strings('street')}${_headingSeparator}`;
        plotHeading = `${strings('plot')}${_headingSeparator}`;
    }
    //String(address.zone)
    const trimmedZone = !!address.zoneId || !!address.zoneNameE ? (localeProperty(address, 'zoneName') || '').replace(/\s\s+/g, ' ').trim() : '';
    //String(address.sector)
    const trimmedSector =
        !!address.sectorId || !!address.sectorNameE ? (localeProperty(address, 'sectorName') || '').replace(/\s\s+/g, ' ').trim() : '';
    const trimmedStreet = !!address.street
        ? String(address.street)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';
    //String(address.plot)
    const trimmedPlot = !!address.plotNumber
        ? String(address.plotNumber || address.plotGisId)
              .replace(/\s\s+/g, ' ')
              .trim()
        : '';

    const formattedZone = !!trimmedZone ? `${zoneHeading}${trimmedZone}${_separator}` : '';
    const formattedSector = !!trimmedSector ? `${sectorHeading}${trimmedSector}${_separator}` : '';
    const formattedStreet = !!trimmedStreet ? `${streetHeading}${trimmedStreet}${_separator}` : '';
    const formattedPlot = !!trimmedPlot ? `${plotHeading}${trimmedPlot}${_separator}` : '';
    const formattedAddress = `${formattedZone}${formattedSector}${formattedStreet}${formattedPlot}`;
    const endsWithRegex = new RegExp(`${_separator}$`);
    return !!formattedAddress ? String(formattedAddress).replace(endsWithRegex, '') : strings('emptyAddress');
}

export async function runBlockingTask(options) {
    const defaultOptions = { maxTries: 1, autoClose: true, autoRetry: false, retryCount: 1 };
    const mergedOptions = { ...defaultOptions, ...options };
    const { id, runner, maxTries } = mergedOptions;
    delete mergedOptions.runner; //don't put runner in the store
    let success = false;
    //let retryCount = 0;
    let data = undefined;
    let error = undefined;
    let result = undefined;
    let originalError = undefined;

    return new Promise((resolve, reject) => {
        const hideLoaderAndReturn = result => {
            const payload = { result, isRunning: false };
            Promise.resolve(store.dispatch(setLoaded(payload))).then(() => {
                //wait for setLoaded action to finish, and then proceed, to ensure the loading model is gone
                if (result.success) resolve(result.data);
                else reject(result.error);
            });
        };

        const setResult = (options, result, isRunning = false) => {
            const payload = { options, result, isRunning };
            store.dispatch(setLoading(payload));
        };
        mergedOptions.onRequestClose = hideLoaderAndReturn;

        const run = async mergedOptions => {
            let opt = { ...mergedOptions, retryCount: mergedOptions.retryCount + 1 };

            const payload = { options: opt, isRunning: true, result: undefined };
            // payload.isRunning = true;
            // payload.result = undefined;

            const updateOptions = newOptions => {
                opt = { ...opt, ...newOptions };
            };

            Promise.resolve(store.dispatch(setLoading(payload)))
                .then(() => {
                    return runner(opt, updateOptions);
                })
                .then(d => {
                    data = d;
                    success = true;
                    originalError = undefined;
                    error = undefined;
                })
                .catch(e => {
                    data = undefined;
                    success = false;
                    originalError = e;
                    error = getErrorMessageWithDetail(e);
                })
                .finally(() => {
                    const r = { data, success, error, originalError };

                    if (!!r.success) {
                        if (!!opt.autoClose) {
                            hideLoaderAndReturn(r);
                        } else {
                            setResult(opt, r);
                        }
                    } else {
                        if (opt.retryCount >= opt.maxTries) {
                            if (!!opt.autoClose) {
                                hideLoaderAndReturn(r);
                            } else {
                                setResult(opt, r);
                            }
                        } else {
                            setResult(opt, r);
                            // if (!!opt.autoRetry) {
                            //     run(opt); //run again
                            // }
                        }
                    }
                });
        };

        if (typeof runner !== 'function') {
            result = { success: true };
            hideLoaderAndReturn(result);
        } else {
            mergedOptions.run = run;
            run(mergedOptions); //run it first time
        }
    });
}
