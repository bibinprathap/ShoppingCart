export default [
    {
        const: 'tasksByStatus',
        type: 'pie',
        nameE: "Today's Tasks by Status",
        nameA: 'مهام اليوم حسب الحالة',
        xAxisLabels: [
            { labelE: 'New', labelA: 'جديد', labelConst: 'NEW' },
            { labelE: 'In Progress', labelA: 'في تقدم', labelConst: 'INPROGRESS' },
            { labelE: 'Completed', labelA: 'منجز', labelConst: 'COMPLETED' },
            { labelE: 'Overdue', labelA: 'متأخر', labelConst: 'OVERDUE' },
            { labelE: 'infollowup', labelA: 'متأخر', labelConst: 'infollowup' },
        ],
        datasets: [
            {
                dataSetNameE: 'Tasks',
                dataSetNameA: 'مهام',
                data: [10, 5, 15, 2, 25],
            },
        ],
    },
    {
        const: 'tasksByCompletedStatus',
        type: 'line',
        nameE: 'Tasks Completed in Last 7 days',
        nameA: 'المهام المنجزة في آخر 7 أيام',
        xAxisLabels: [
            { labelE: 'Jan-1', labelA: 'يناير-1', labelConst: 'Jan-1' },
            { labelE: 'Jan-2', labelA: 'يناير-2', labelConst: 'Jan-2' },
            { labelE: 'Jan-3', labelA: 'يناير-3', labelConst: 'Jan-3' },
            { labelE: 'Jan-4', labelA: 'يناير-4', labelConst: 'Jan-4' },
            { labelE: 'Jan-5', labelA: 'يناير-5', labelConst: 'Jan-5' },
        ],
        datasets: [
            {
                dataSetNameE: 'Completed Tasks',
                dataSetNameA: 'المهام المنجزة',
                data: [4, 3, 8, 5, 25],
            },

            {
                dataSetNameE: 'Completed Tasks222',
                dataSetNameA: 'المهام المنجز22222ة',
                data: [3, 4, 6, 7, 25],
            },
        ],
    },
    {
        const: 'inspectionsByType',
        type: 'bar',
        nameE: 'Inspection by Type Last 7 days',
        nameA: 'عملياتليومالمهام المنجز  حسب النوع',
        xAxisLabels: [
            { labelE: 'Jan-21', labelA: '2يناير-1', labelConst: 'Jan-21' },
            { labelE: 'Jan-22', labelA: '2يناير-2', labelConst: 'Jan-22' },
            { labelE: 'Jan-23', labelA: '2يناير-3', labelConst: 'Jan-23' },
            { labelE: 'Jan-24', labelA: '2يناير-4', labelConst: 'Jan-24' },
            { labelE: 'Jan-25', labelA: '2يناير-5', labelConst: 'Jan-25' },
        ],
        datasets: [
            {
                dataSetNameE: 'Distortions',
                dataSetNameA: 'المشوهات',
                data: [14, 20, 16, 20, 25],
            },
            {
                dataSetNameE: 'Abandoned Vehicles',
                dataSetNameA: 'مركبات مهجورة',
                data: [15, 25, 16, 20, 25],
            },
            {
                dataSetNameE: 'Abandoned house',
                dataSetNameA: 'مركبات مهجورة',
                data: [55, 5, 86, 30, 25],
            },
        ],
    },
];
