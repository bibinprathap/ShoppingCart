export default entities = [
    {
        inspEntityId: 12825,
        inspEntityNameE: 'General Authority of Islamic Affairs & Endowments - Awqaf',
        inspEntityNameA: 'الهيئة العامة للشؤون الاسلامية والأوقاف',
    },
    {
        inspEntityId: 1,
        inspEntityNameE: 'Abu Dhabi Agriculture & Food Safety Authority',
        inspEntityNameA: 'هيئة أبوظبي للزراعة والسلامة الغذائية',
    },
    {
        inspEntityId: 52896,
        inspEntityNameE: 'Abu Dhabi Sewerage Services Company',
        inspEntityNameA: 'شركة أبوظبي لخدمات الصرف الصحي',
    },
    {
        inspEntityId: 2,
        inspEntityNameE: 'Environment Agency - Abu Dhabi',
        inspEntityNameA: 'هيئة البيئة - أبوظبي',
    },
    {
        inspEntityId: 3,
        inspEntityNameE: 'Integrated Transport Center',
        inspEntityNameA: 'مركز النقل المتكامل',
    },
    {
        inspEntityId: 17310,
        inspEntityNameE: 'Abu Dhabi Distribution Co.',
        inspEntityNameA: 'شركة أبوظبي للتوزيع',
    },
    {
        inspEntityId: 1000,
        inspEntityNameE: 'Abu Dhabi City Municipality',
        inspEntityNameA: 'بلدية مدينة أبوظبي',
    },
    {
        inspEntityId: 1001,
        inspEntityNameE: 'Tadweer',
        inspEntityNameA: 'تدوير',
    },
];
