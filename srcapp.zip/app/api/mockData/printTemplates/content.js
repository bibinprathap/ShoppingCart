export default `^FX ************* Content starts here *************
{% assign currentHeight = probableNoOfLinesForAddress | times: 30 | plus: currentHeight, labelheight -%}
^FX ************* Arabic title *************
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolationType_ar}}
^FS
^FX ************* English title *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolationType_en}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* List all violations here *************
{% for violation in violations -%}
{% assign violationLineHeight = violation | getHeight: lineCharHeight_en, maxCharactersPerLine -%}
{% assign isVoilationArabic = violation | isProbablyArabic -%}
{% if isVoilationArabic == true -%}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{violationLineHeight}}^FD
{{violation}}
^FS
{% endif -%}
{% if isVoilationArabic == false -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^TBN,500,{{violationLineHeight}}^FD
{{violation}}
^FS
{% endif -%}
{% assign currentHeight = currentHeight | plus: violationLineHeight -%}
{% endfor =%}
^FX ************* End of violations *************
^FX ************* Violation Amount *************
{% assign currentHeight = currentHeight | plus: 20 %}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolationAmount_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolationAmount_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,22,20,TT0003M_^CI17^F8^FD
{{registeredAmount}} AED
^FS
^FO27,{{currentHeight}}^A@N,22,20,TT0003M_^CI17^F8^FD
{{registeredAmount}} AED
^FS
^FO525,{{currentHeight}},2^A@N,20,26,TT0003M_^CI17^F8^FD
{% assign amountArabic = registeredAmount | englishToArabicNumberConversion -%}
{{amountArabic}} درهم
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Violator Details starts here *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolatorDetails_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolatorDetails_ar}}
^FS
{% assign currentHeight = currentHeight | plus: 36 -%}
{% for violatorDetails in violatorDetailsList -%}
{% assign detailsSplit = violatorDetails | split : ":" -%}
{% if detailsSplit.size > 0 -%}
{% assign isArabic = detailsSplit[0] | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign detailsLineHeight = detailsSplit[0] | getHeight: lineCharHeight_ar, 27 -%}
^FO525,{{currentHeight}},2^A@N,20,25,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign detailsLineHeight = detailsSplit[0] | getHeight: lineCharHeight_en, 27 -%}
^FO25,{{currentHeight}}^A@N,20,22,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{{detailsSplit[0]}} :
{% assign currentHeight = currentHeight | plus: detailsLineHeight -%}
^FS
^FX ************* Violator Details - Entered Values *************
{% assign isArabic = detailsSplit[1] | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign detailsLineHeight =  detailsSplit[1] | getHeight: lineCharHeight_ar, 27 -%}
^FO525,{{currentHeight}},2^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign detailsLineHeight =  detailsSplit[1] | getHeight: lineCharHeight_en, 27 -%}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{{detailsSplit[1]}}
{% assign currentHeight = currentHeight | plus: detailsLineHeight -%}
^FS
{% endif -%}
{% endfor -%}
^FX ************* Violator Details Ends here *************
^FX ************* Notes starts here *************
{% if notesArray.size > 0 -%}
{% assign currentHeight = currentHeight | plus : 20 -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleNote_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleNote_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
{% for note in notesArray -%}
{% assign isArabic = note | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign noteLineHeight =  note | getHeight: lineCharHeight_ar, 40 -%}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{noteLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign noteLineHeight =  note | getHeight: lineCharHeight_en, 40 -%}
^FO25,{{currentHeight}},^A@N,25,25,TT0003M_^CI17^F8^TBN,500,{{noteLineHeight}}^FD
{% endif -%}
{% assign currentHeight = currentHeight | plus: noteLineHeight, 5 -%}
{{note}}
^FS
{% endfor -%}
{% endif -%}
^FX ************* Notes Ends here *************
^FX ************* ID details *************
{% assign currentHeight = currentHeight | plus: 20 -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleIDRecieved_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleIDRecieved_ar}}
^FS
^FX ************* English ID details *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{idReceived}}
^FS
^FX ************* Arabic ID details *************
^FO525,{{currentHeight}},2^A@N,20,26,TT0003M_^CI17^F8^FD
{% if idReceived == "YES" -%}
نعم
{% endif -%}
{% if idReceived != "YES" -%}
لا
{% endif -%}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Inspector code *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleInspectorCode_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleInspectorCode_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* English Inspector Code *************
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{inspectorCode}}
^FS
^FX ************* Arabic Inspector Code *************
^FO525,{{currentHeight}},^FPR,3,2^A@N,20,26,TT0003M_^CI17^F8^FD
{% assign inspectorCodeArabic = inspectorCode | englishToArabicNumberConversion -%}
{{inspectorCodeArabic}}
^FS`;
