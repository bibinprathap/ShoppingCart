export default `^FX ************* Starts here *************
{% assign titleMuncipalityofAbuDhabiCity_ar = "دائرة التخطيط العمراني والبلديات" -%}
{% assign titleMuncipalityofAbuDhabiCity_en = "DEPARTMENT OF URBAN PLANNING" -%}
{% assign titleMuncipalityofAbuDhabiCity_line2_en = "AND MUNICIPALITIES" -%}
{% assign titleMuncipalCenter_ar = "مركز البلدية" -%}
{% assign titleMuncipalCenter_en = "Municipal Center" -%}
{% assign titleDateTime_ar = "التاريخ/ الوقت" -%}
{% assign titleDateTime_en = "Date/Time" -%}
{% assign titleZoneSectorPlot_ar = "المنطقة/الحوض/رقم القطعة" -%}
{% assign titleZoneSectorPlot_en = "Zone/Sector/Plot" -%}
{% assign titleViolationType_ar = "نوع المخالفة" -%}
{% assign titleViolationType_en = "Violation Type" -%}
{% assign titleViolationAmount_ar = "قيمة المخالفة" -%}
{% assign titleViolationAmount_en = "Violation Amount" -%}
{% assign titleViolatorDetails_ar = "بيانات المخالف" -%}
{% assign titleViolatorDetails_en = "Violator Details" -%}
{% assign titleNote_ar = "الملاحظات" -%}
{% assign titleNote_en = "Note" -%}
{% assign titleIDRecieved_ar = "قبول التصالح" -%}
{% assign titleIDRecieved_en = "Accept Reconciliation Law" -%}
{% assign titleInspectorCode_ar = "قبول التصالح" -%}
{% assign titleInspectorCode_en = "Inspector Code" -%}
{% assign labelLength = 450 -%}
{% assign labelheight = 45 -%}
{% assign maxCharactersPerLine = 47 -%}
{% assign headerHeight = 250 -%}
{% assign fBufferHeight = 1.10 -%}
{% assign lineCharHeight_en = 40 -%}
{% assign lineCharHeight_ar = 50 -%}
{% assign probableNoOfLinesForViolations = violations | getProbableNoOfLinesForViolations: fBufferHeight, maxCharactersPerLine -%}
{% assign probableNoOfLinesForAddress = zoneSecPlot | getLines: maxCharactersPerLine -%}
{% assign probableNoOfLinesForNote = note | getProbableNoOfLinesForNote: maxCharactersPerLine, fBufferHeight -%}
{% assign probableNoOfLinesForViolatorDetails = violatorDetailsList | getProbableNoOfLinesForViolatorDetails: maxCharactersPerLine -%}
{% assign notesArray = note | getNoteArray -%}
{% assign labelLengthCalulated = probableNoOfLinesForViolations | plus: probableNoOfLinesForNote, probableNoOfLinesForAddress, probableNoOfLinesForViolatorDetails | times: lineCharHeight_ar | times: fBufferHeight -%}
{% assign labelLength = labelLength | plus: labelLengthCalulated -%}
{% if labelLength < 1600 -%}
  {% assign labelLength = 1600 -%}
{% endif -%}
^XA^POI^MNV^LL{{labelLength | ceil}}^XZ^XA^JUS^XZ
^FX ************* Header *************
^XA^PA0,1,1,1
^FO25,0^TBN,500,50^A@N,46,46,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_ar}}
^FS
^FO80,60^FB500,1,0,J,2^A@N,28,28,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_en}}
^FS
^FO65,95^FB500,1,0,R,2^A@N,28,28,TT0003M_^CI17^F8^FD
{{titleMuncipalityofAbuDhabiCity_line2_en}}
^FS
^FX ************* Violation Title *************
^FO220,120^TBN,500,50^A@N,40,40,TT0003M_^CI17^F8^FD
{{selectedActionTypeA}}
^FS
^FO25,160^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^FD
{{selectedActionTypeE}}
^FS
^FX ************* Reference Number *************
^FO25,185^FB500,1,100,C,2^A@N,30,30,TT0003M_^CI17^F8^FD
{{referenceNumber}}
^FS
^FX ************* Header ends here *************
^FX ************* Line  *************
^FO25,215^GB500,1,3^FS
^FX ************* Second section with all info details *************
^FO25,{{headerHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleMuncipalCenter_en}}
^FS
^FO525,{{headerHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleMuncipalCenter_ar}}
^FS
{% assign currentHeight = headerHeight | plus: labelheight -%}
^FX ************* English MuncipalCenterName *************
^FO25,{{ currentHeight }}^A@N,20,20,TT0003M_^CI17^F8^FD
{{muncipalCenterName_en}}
^FS
^FX ************* Arabic MuncipalCenterName *************
^FO525,{{ currentHeight }},2^A@N,30,30,TT0003M_^CI17^F8^FD
{{muncipalCenterName_ar}}
^FS
^FX ************* Date and Time Title *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleDateTime_en}}
^FS
^FO525,{{currentHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleDateTime_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* English Date Time *************
^FO165,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{visitDate}}
^FS
^FX ************* Zone, Sector, Plot *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Plot details in Arabic *************
^FO525,{{currentHeight}},2^A@N,35,35,TT0003M_^CI17^F8^FD
{{titleZoneSectorPlot_ar}}
^FS
^FX ************* Plot details in English *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleZoneSectorPlot_en}}
^FS
^FX ************* Address section *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
{% assign isPlotDetailsInArabic = zoneSecPlot | isProbablyArabic %}
^FX ************* Plot section starts here *************
{% if zoneSecPlot.size > 0 and isPlotDetailsInArabic == true %}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine}}^FD
{{zoneSecPlot}}
^FS
{% endif -%}
{% if zoneSecPlot.size > 0 and isPlotDetailsInArabic == false - %}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine}}^FD
{{zoneSecPlot}}
^FS
{% endif -%}
^FX ************* Plot section ends here *************
{% assign currentHeight = zoneSecPlot | getHeight: lineCharHeight_en, maxCharactersPerLine | plus: currentHeight -%}
^FX ************* currentHeight multiply with 30 *************
{% assign currentHeight = probableNoOfLinesForAddress | times: 30 | plus: currentHeight, labelheight -%}
^FX ************* Arabic title *************
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolationType_ar}}
^FS
^FX ************* English title *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolationType_en}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* List all violations here *************
{% for violation in violations -%}
{% assign violationLineHeight = violation | getHeight: lineCharHeight_en, maxCharactersPerLine -%}
{% assign isVoilationArabic = violation | isProbablyArabic -%}
{% if isVoilationArabic == true -%}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{violationLineHeight}}^FD
{{violation}}
^FS
{% endif -%}
{% if isVoilationArabic == false -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^TBN,500,{{violationLineHeight}}^FD
{{violation}}
^FS
{% endif -%}
{% assign currentHeight = currentHeight | plus: violationLineHeight -%}
{% endfor =%}
^FX ************* End of violations *************
^FX ************* Violation Amount *************
{% assign currentHeight = currentHeight | plus: 20 %}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolationAmount_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolationAmount_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,22,20,TT0003M_^CI17^F8^FD
{{registeredAmount}} AED
^FS
^FO27,{{currentHeight}}^A@N,22,20,TT0003M_^CI17^F8^FD
{{registeredAmount}} AED
^FS
^FO525,{{currentHeight}},2^A@N,20,26,TT0003M_^CI17^F8^FD
{% assign amountArabic = registeredAmount | englishToArabicNumberConversion -%}
{{amountArabic}} درهم
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Violator Details starts here *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleViolatorDetails_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleViolatorDetails_ar}}
^FS
{% assign currentHeight = currentHeight | plus: 36 -%}
{% for violatorDetails in violatorDetailsList -%}
{% assign detailsSplit = violatorDetails | split : ":" -%}
{% if detailsSplit.size > 0 -%}
{% assign isArabic = detailsSplit[0] | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign detailsLineHeight = detailsSplit[0] | getHeight: lineCharHeight_ar, 27 -%}
^FO525,{{currentHeight}},2^A@N,20,25,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign detailsLineHeight = detailsSplit[0] | getHeight: lineCharHeight_en, 27 -%}
^FO25,{{currentHeight}}^A@N,20,22,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{{detailsSplit[0]}} :
{% assign currentHeight = currentHeight | plus: detailsLineHeight -%}
^FS
^FX ************* Violator Details - Entered Values *************
{% assign isArabic = detailsSplit[1] | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign detailsLineHeight =  detailsSplit[1] | getHeight: lineCharHeight_ar, 27 -%}
^FO525,{{currentHeight}},2^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign detailsLineHeight =  detailsSplit[1] | getHeight: lineCharHeight_en, 27 -%}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^TBN,500,{{detailsLineHeight}}^FD
{% endif -%}
{{detailsSplit[1]}}
{% assign currentHeight = currentHeight | plus: detailsLineHeight -%}
^FS
{% endif -%}
{% endfor -%}
^FX ************* Violator Details Ends here *************
^FX ************* Notes starts here *************
{% if notesArray.size > 0 -%}
{% assign currentHeight = currentHeight | plus : 20 -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleNote_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleNote_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
{% for note in notesArray -%}
{% assign isArabic = note | isProbablyArabic -%}
{% if isArabic == true -%}
{% assign noteLineHeight =  note | getHeight: lineCharHeight_ar, 40 -%}
^FO525,{{currentHeight}},2^A@N,30,30,TT0003M_^CI17^F8^TBN,500,{{noteLineHeight}}^FD
{% endif -%}
{% if isArabic == false -%}
{% assign noteLineHeight =  note | getHeight: lineCharHeight_en, 40 -%}
^FO25,{{currentHeight}},^A@N,25,25,TT0003M_^CI17^F8^TBN,500,{{noteLineHeight}}^FD
{% endif -%}
{% assign currentHeight = currentHeight | plus: noteLineHeight, 5 -%}
{{note}}
^FS
{% endfor -%}
{% endif -%}
^FX ************* Notes Ends here *************
^FX ************* ID details *************
{% assign currentHeight = currentHeight | plus: 20 -%}
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleIDRecieved_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleIDRecieved_ar}}
^FS
^FX ************* English ID details *************
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{idReceived}}
^FS
^FX ************* Arabic ID details *************
^FO525,{{currentHeight}},2^A@N,20,26,TT0003M_^CI17^F8^FD
{% if idReceived == "YES" -%}
نعم
{% endif -%}
{% if idReceived != "YES" -%}
لا
{% endif -%}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* Inspector code *************
^FO25,{{currentHeight}}^A@N,25,25,TT0003M_^CI17^F8^FD
{{titleInspectorCode_en}}
^FS
^FO525,{{currentHeight}},2^A@N,25,35,TT0003M_^CI17^F8^FD
{{titleInspectorCode_ar}}
^FS
{% assign currentHeight = currentHeight | plus: labelheight -%}
^FX ************* English Inspector Code *************
^FO25,{{currentHeight}}^A@N,20,20,TT0003M_^CI17^F8^FD
{{inspectorCode}}
^FS
^FX ************* Arabic Inspector Code *************
^FO525,{{currentHeight}},^FPR,3,2^A@N,20,26,TT0003M_^CI17^F8^FD
{% assign inspectorCodeArabic = inspectorCode | englishToArabicNumberConversion -%}
{{inspectorCodeArabic}}
^FS
^XZ
`;
