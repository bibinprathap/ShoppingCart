import moment from 'moment';
import { violationTypes } from 'app/api/mockData';
import { authorize, uaepassAuthorize } from 'ThirdPartyModuleJS/RNAppAuth';
import envConfig from './config';
import pinch from 'react-native-pinch';
import DeviceInfo from 'react-native-device-info';
import axios from 'axios';
import MockApi, {
    duplicateMock,
    checkListDuplicateMock,
    getPlotOwnerDetails,
    duplicateListMock,
    inspectionDetailsMock,
    simpleCustomerModels,
} from './mock';

import {
    printTemplateHeader,
    printTemplateContent,
    printTemplateFooter,
    simpleCustomerCompanyModels,
    simplePersonCompanyModels,
    simpleMixCompanyModels,
} from 'app/api/mockData';

import { objectToGisFilter, objectToQueryString, throwMimsError } from 'app/api/helperServices/utils';
import RestApi from './restApi';
import gisMapping from 'app/api/gisMapping';
import { _ } from 'lodash';
import createError from 'app/api/helperServices/errors';
import { store } from 'app/config/store';

const isEmulator = DeviceInfo.isEmulator();

const mockApi = new MockApi();

const layersEnum = { municipality: 3, zone: 2, sector: 1, plot: 0, address: 5 };
const defaultGISOptions = {
    outFields: '*',
    returnGeometry: false,
};

const mapGISFields = (layer, direction, params) => {
    var mappedObj = {};
    const mapping = gisMapping[layer];
    for (var i = 0; i < mapping.length; i++) {
        const fromKey = direction === 'in' ? mapping[i][0] : mapping[i][1];
        const toKey = direction === 'in' ? mapping[i][1] : mapping[i][0];
        //const mappingElement = mapping[i];
        if (typeof params[fromKey] !== 'undefined') {
            mappedObj[toKey] = params[fromKey];
        }
    }

    return mappedObj;
};

export const replaceFieldNames = (layer, direction, fields) => {
    const fieldsSplit = (fields && fields.split(',')) || [];
    const mapping = gisMapping[layer];
    const mappedFields = fieldsSplit.map((f) => {
        if (direction === 'in') {
            const mappingElement = _.find(mapping, (pair) => {
                return pair[0] == f;
            });
            if (mappingElement) return mappingElement[1];
        } else {
            const mappingElement = _.find(mapping, (pair) => {
                return pair[1] == f;
            });
            if (mappingElement) return mappingElement[0];
        }
    });
    return mappedFields.filter((f) => f !== undefined).join(',');
};

const getGisQuery = (dynamicFilter, layer, options) => {
    let mergedOptions = { ...defaultGISOptions, ...options };
    const fixedFilter = { ...mergedOptions.filter };
    delete mergedOptions.filter;
    const mergedFilter = { ...dynamicFilter, ...fixedFilter };
    const gisFilter = objectToGisFilter(mergedFilter);

    gisFilter;

    mergedOptions = {
        ...mergedOptions,
        outFields: replaceFieldNames(layer, 'out', mergedOptions.outFields) || '*',
        orderByFields: replaceFieldNames(layer, 'out', mergedOptions.orderByFields),
    };
    const queryObj = {
        f: 'json',
        where: gisFilter || '1=1',
        ...mergedOptions,
    };

    const query = objectToQueryString(queryObj);
    const url = `${layer}/query?${query}`;
    return url;
};

const mapGisResult = (layer, result) => {
    if (result && result.data && result.data.features) {
        return result.data.features.map((f) => {
            const mappedData = { ...mapGISFields(layer, 'in', f.attributes) };
            if (f.geometry && f.geometry.rings && f.geometry.rings.length > 0) {
                mappedData['geometry'] = f.geometry.rings[0].map((p) => {
                    return {
                        latitude: p[1],
                        longitude: p[0],
                    };
                });
            }
            return mappedData;
        });
    }
    return null;
};

export default class AppApi {
    // getZones = async ({ zoneId, municipalityId, options } = {}) => {
    //     const dynamicFilter = { districtId: zoneId, municipalityName: municipalityId };
    //     const url = getGisQuery(dynamicFilter, layersEnum.zone, options);
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         return mapGisResult(layersEnum.zone, result);
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };
    getZones = async (params = {}) => {
        const restApi = new RestApi({ controller: 'GIS' });
        try {
            const response = await restApi.post({
                url: 'GetZones',
                body: params,
                cancelable: true,
                showAlerts: false,
            });

            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getPlanDetails = async (params = {}) => {
        const restApi = new RestApi({ controller: 'MIMS' });
        try {
            const response = await restApi.post({
                url: 'GetPlanDetails',
                body: params,
                cancelable: true,
                showAlerts: false,
            });
            //  console.log('getPlanDetails', response.data.result.tasks);
            return response.data.result.tasks;
        } catch (error) {
            throw error;
        }
    };

    // getSectors = async ({ zoneId, sectorGisId, municipalityId, options } = {}) => {
    //     const dynamicFilter = { districtId: zoneId, communityId: sectorGisId, municipality: municipalityId };
    //     const url = getGisQuery(dynamicFilter, layersEnum.sector, options);
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         return mapGisResult(layersEnum.sector, result);
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };
    getSectors = async (params = {}) => {
        const restApi = new RestApi({ controller: 'GIS' });
        try {
            const response = await restApi.post({
                url: 'GetSectors',
                body: params,
                cancelable: true,
                showAlerts: false,
            });

            return response.data.result;
        } catch (error) {
            throw error;
        }
    };
    // getPlots = async ({ zoneId, sectorGisId, plotGisId, plotNumber, options } = {}) => {
    //     const dynamicFilter = { districtId: zoneId, communityId: sectorGisId, plotGisId, plotNumber };
    //     const url = getGisQuery(dynamicFilter, layersEnum.plot, options);
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         return mapGisResult(layersEnum.plot, result);
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };
    getPlots = async (params) => {
        const restApi = new RestApi({ controller: 'GIS' });
        try {
            const response = await restApi.post({
                url: 'GetPlots',
                body: { ...params, ReturnGeometry: params.ReturnGeometry === true },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    // getPlotsCustom = async (zoneId, sectorGisId, plotNumbers) => {
    //     const plotClause = plotNumbers.map(p => 'plotNumber=' + `'${p}'`).join(' or ');
    //     const url = `/0/query?where=1=1 and communityId=${sectorGisId} and districtId=${zoneId} and (${plotClause})&outFields=*&returnGeometry=true&f=json&orderByFields=plotnumber`;
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         return mapGisResult(layersEnum.plot, result);
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };
    // getAddress = async coords => {
    //     const query = `query?where=&geometry=%7B%22x%22%3A${coords.longitude}%2C%22y%22%3A+${
    //         coords.latitude
    //     }%7D&geometryType=esriGeometryPoint&outFields=*&returnGeometry=false&f=json`;
    //     let url = `/${layersEnum.address}/` + query;
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         const addressWithGeometry = mapGisResult(layersEnum.address, result);
    //         if (addressWithGeometry.length > 0) {
    //             let { geometry: _, ...address } = addressWithGeometry[0];
    //             // delete addressWithGeometry.geometry;
    //             return address;

    //             //return delayedResult(true, address, 5000);
    //         } else {
    //             url = `/${layersEnum.sector}/` + query;
    //             const sectorResult = await restApi.get({ url });
    //             const sectorAddress = mapGisResult(6, sectorResult);
    //             if (sectorAddress.length > 0) {
    //                 let { geometry: _, ...sectoraddress } = sectorAddress[0];
    //                 // delete addressWithGeometry.geometry;

    //                 return sectoraddress;

    //                 //return delayedResult(true, sectoraddress, 5000);
    //             }
    //             return null;
    //         }
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };

    getAddress = async (coords) => {
        const restApi = new RestApi({ controller: 'GIS' });
        try {
            const response = await restApi.post({
                url: 'GetAddress',
                body: { x: coords.longitude, y: coords.latitude },
                cancelable: true,
                showAlerts: false,
            });
            if (response.data.result.length > 0) {
                return response.data.result[0];
            } else {
                return null;
            }
        } catch (error) {
            throw error;
        }
    };

    // getPlotsDataGIS = async plotGisIds => {
    //     //, =%2C
    //     //' =%27
    //     const query = `query?where=plotGisId+in+%28${plotGisIds
    //         .map(p => '%27' + p + '%27')
    //         .join('%2C')}%29&geometryType=esriGeometryPoint&outFields=*&f=json`;
    //     let url = `/${layersEnum.address}/` + query;
    //     const restApi = new RestApi({ endpoint: 'mapServer' });
    //     try {
    //         const result = await restApi.get({ url });
    //         const addressWithGeometry = mapGisResult(layersEnum.address, result);

    //         return addressWithGeometry;
    //     } catch (err) {
    //         throw createError(err);
    //     }
    // };
    getPlotsDataByGISID = async (plotGisId) => {
        let plotGisIds = typeof plotGisId !== 'object' ? [plotGisId] : plotGisId;
        const query = `query?where=GISID+in+%28${plotGisIds.map((p) => '%27' + p + '%27').join('%2C')}%29&returnGeometry=false&outFields=*&f=json`;
        let url = `/${layersEnum.address}/` + query;
        const restApi = new RestApi({ endpoint: 'mapServer' });
        try {
            const result = await restApi.get({ url });
            const addressWithGeometry = mapGisResult(layersEnum.address, result);

            return addressWithGeometry;
        } catch (err) {
            throw createError(err);
        }
    };

    addSSL = (config) => {
        let newConfig = { ...config };
        if (!isEmulator) {
            //do not add sslPinning for Emulator
        } else {
            newConfig.sslPinning = {
                cert: 'DMAROOTCA',
            };
        }
        return newConfig;
    };

    getJsonFromResponse = (response) => {
        if (response && response.bodyString) return JSON.parse(response.bodyString);
        else return response;
    };

    parseGender = (gender) => {
        if (!gender) return;
        switch (gender.toLowerCase()) {
            case 'male':
                return 1;
            case 'female':
                return 2;
            default:
                return;
        }
    };

    mockSmartPassSso = async () => {
        return await mockApi.smartPassSso();
    };

    smartPassSso = async () => {
        const state = store.getState();
        const env = state.settings.environment || 'test';
        const currentEnvConfig = envConfig[env];
        let tokenUrl, tokenRequestConfg;
        try {
            const response = await authorize(currentEnvConfig.smartPass.config);
            tokenUrl = `${currentEnvConfig.smartPass.baseUrl}/secure/oauth2/access_token?realm=/TRA&code=${response.code}&redirect_uri=ae.abudhabi.dma.dev.singlewindow://msServices_ADM&grant_type=authorization_code`;
            //Todo: extract this logic into a helper
            tokenRequestConfg = this.addSSL({
                method: 'post',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'Basic YWRtOkMtQi1QcyRVM3c3XjhOTQ==',
                },
                timeoutInterval: 20000,
            });
        } catch (error) {
            //console.log('SmartPass failure to initiate authorization. error: ', error);
            //throw error;
            throwMimsError('Failed to initiate SmartPass authorization. ', error);
        }
        try {
            const tokenResponse = await pinch.fetch(tokenUrl, tokenRequestConfg);
            const tokenData = this.getJsonFromResponse(tokenResponse);
            const access_token = tokenData.access_token;
            const userInfoUrl = `${currentEnvConfig.smartPass.baseUrl}/secure/oauth2/userinfo?realm=/TRA`;

            //Todo: extract this logic into a helper
            const userInfoRequestConfig = this.addSSL({
                method: 'get',
                headers: {
                    accept: 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: `Bearer ${access_token}`,
                },
                timeoutInterval: 20000,
            });

            const userInfoResponse = await pinch.fetch(userInfoUrl, userInfoRequestConfig);
            const userData = this.getJsonFromResponse(userInfoResponse);
            return { tokenData, userData };
        } catch (error) {
            // console.log('smartPassSso failure acquiring token. error: ', error);
            // throw error;
            throwMimsError('Failed to acquire SmartPass auth token.', error);
        }
    };

    uaePassSso = async () => {
        debugger;
        const state = store.getState();
        const env = state.settings.environment || 'test';
        const currentEnvConfig = envConfig[env];
        let tokenUrl, tokenRequestConfg;
        try {
            debugger;
            const response = await uaepassAuthorize(currentEnvConfig.uaePass);
            tokenUrl = `${currentEnvConfig.uaePass.tokenEndpoint}?realm=/TRA&code=${response.code}&redirect_uri=ae.abudhabi.dma.dev.singlewindow://msServices_ADM&grant_type=authorization_code`;
            //Todo: extract this logic into a helper
            tokenRequestConfg = this.addSSL({
                method: 'post',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'Basic YWRtOkMtQi1QcyRVM3c3XjhOTQ==',
                },
            });
        } catch (error) {
            debugger;
            //console.log('UAEpass failure to initiate authorization. error: ', error);
            //throw error;
            throwMimsError('Failed to initiate UAEPASS authorization. ', error);
        }
        try {
            const tokenResponse = await pinch.fetch(tokenUrl, tokenRequestConfg);
            const tokenData = this.getJsonFromResponse(tokenResponse);
            const access_token = tokenData.access_token;
            const userInfoUrl = `${currentEnvConfig.uaePass.userInfoEndpoint}`;

            //Todo: extract this logic into a helper
            const userInfoRequestConfig = this.addSSL({
                method: 'get',
                headers: {
                    accept: 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: `Bearer ${access_token}`,
                },
            });

            const userInfoResponse = await pinch.fetch(userInfoUrl, userInfoRequestConfig);
            const userData = this.getJsonFromResponse(userInfoResponse);
            return { tokenData, userData };
        } catch (error) {
            // console.log('smartPassSso failure acquiring token. error: ', error);
            // throw error;
            throwMimsError('Failed to acquire UAEPASS auth token.', error);
        }
    };

    smartHubSso = async (tokenData, userData, fcmToken) => {
        const state = store.getState();
        const { locale = 'en' } = state.settings;
        const deviceLang = locale.indexOf('ar') > -1 ? 'ar' : 'en';

        /*
        Todo: from ssoUserProfileModel remove the following for golive,
              these values are temporarily for working with unverified SmartPass accounts during development
            * idnNotVerified
            * `${userData.firstnameEN} ${userData.lastnameEN}`
        */
        const ssoUserProfileModel = {
            userType: userData.userType,
            uuid: userData.uuid,
            //Todo: remove the idnNotVerified in next line, it is
            nationalNumber: userData.idn || userData.idnNotVerified,
            idCardExpiryDate: userData.idCardExpiryDate,
            customerNameA: userData.fullnameAR || `${userData.firstnameAR} ${userData.lastnameAR}`,
            customerNameE: userData.fullnameEN || `${userData.firstnameEN} ${userData.lastnameEN}`,
            gender: this.parseGender(userData.gender),
            email: userData.email,
            mobile: userData.mobile,
            //deviceId: DeviceInfo.getDeviceId(),
            deviceId: fcmToken,
            osversion: DeviceInfo.getSystemVersion(),
            deviceLang: deviceLang,
            sourceSystem: 'MIMSMobile',
        };
        /* SmartHub Login*/
        const restApi = new RestApi({ controller: 'User', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'SsoLogin',
                body: ssoUserProfileModel,
                cancelable: true,
                showAlerts: false,
            });
            if (smartHubResponse.data.success) return smartHubResponse.data.result;
            else throw smartHubResponse.data.error;
        } catch (error) {
            //if SmartHub login fails, we must logout from SmartPass as well,
            //otherwise when user hits SmartPass login button next time, it doesn't ask for credentials
            if (tokenData) {
                this.smartPassLogout(tokenData.id_token, tokenData.access_token);
            }
            throw error;
        }
    };

    basicLogin = async (username, password) => {
        const restApi = new RestApi({ controller: 'Account', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'Login',
                body: { username, password },
            });
            let authCode;
            if (smartHubResponse.data.success) {
                //RJ: When there are more than one 'set-cookie' headers, this will not work due to a bug in fetch.
                //Todo: Try this solution to workaround the set-cookie issu: https://github.com/facebook/react-native/issues/18837#issuecomment-398779994
                const cookies = smartHubResponse.headers['set-cookie'];

                for (let cookie of cookies) {
                    if (cookie) {
                        /*
                        sample success cookie
                        .ASPXAUTH=3F916A22E63376725925AB22166FEEFD0A6DA361A79B9ED302F2D97EFF6158C258A18902212285714223FD6B0A0F80264F17625F1E91C6D6764720139DAF7EB88010A28898FB1BA8E5BE50689A3648F45240E8A71A1AF84BA6BDBB37E1D1941B2F0DDF2E860640BCE0024778694974E1B8E1AFC98F511353E18FDB4617238D5F4D02B21C6CEE83633F2ED144BA951EDB2785864B; expires=Sun, 05-May-2019 19:59:59 GMT; path=/
                        */
                        var matches = cookie.match(/(.ASPXAUTH=)(\w+);/i);
                        if (matches && matches.length >= 3 && matches[2] && matches[2].length > 0) {
                            authCode = matches[2];
                        }
                    }
                }
                if (authCode) {
                    return authCode;
                } else {
                    throw Error('SmartHub did not return authcode');
                }
            } else throw smartHubResponse.data.error;
        } catch (error) {
            throw createError(error);
        }
    };

    getPofiles = async () => {
        const restApi = new RestApi({ controller: 'Profiles', dispatch: this.dispatch, secure: false });
        try {
            let smartHubResponse = await restApi.post({
                url: 'GetMimsProfiles',
                cancelable: true,
                showAlerts: false,
            });
            if (smartHubResponse.data.success) {
                const profiles = smartHubResponse.data.result;

                return profiles;
            }
        } catch (error) {
            throw error;
        }
    };

    switchMimsRole = async (urlArgs) => {
        const restApi = new RestApi({ controller: 'Profiles', dispatch: this.dispatch, secure: true });
        try {
            let smartHubResponse = await restApi.post({
                //url: `SwitchMimsRole?args=${urlArgs}`,
                url: 'SwitchMimsRole',
                body: { value: urlArgs },
                cancelable: true,
                showAlerts: false,
            });
            if (smartHubResponse.data.success) {
                const activeProfile = smartHubResponse.data.result;
                return activeProfile;
            }
        } catch (error) {
            throw error;
        }
    };

    getCompanyProfile = async (violator) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'GetCompanyViolator',
                body: violator,
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getVehicleProfile = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'GetVehicleViolator',
                body: {
                    plateSource: params.plateSource,
                    plateNumber: params.plateNumber,
                    chassisNumber: params.chassisNumber,
                    plateKind: params.plateKind,
                    plateColor: params.plateColor,
                },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getVehiclePlateKinds = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'GetVehiclePlateKinds',
                body: params,
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getVehiclePlateColors = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'GetVehiclePlateColors',
                body: params,
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    createVehicleProfile = async (violator) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'CreateVehicleViolator',
                body: violator,
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getPersonProfile = async (emiratesId) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: 'GetPersonViolator',
                body: { NationalNumber: emiratesId },
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getInspection = async (inspectionRef) => {
        return mockApi.getInspection(inspectionRef);

        // const restApi = new RestApi({ controller: 'Inspection' });
        // try {
        //     let response = await restApi.post({
        //         url: 'getInspection',
        //         body: { ref: inspectionRef },
        //         cancelable: true,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };

    search = async (searchKey, filter) => {
        return mockApi.search(searchKey, filter);

        // const restApi = new RestApi({ controller: 'Search' });
        // try {
        //     let response = await restApi.post({
        //         url: 'search',
        //         body: { searchKey, filter },
        //         cancelable: true,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };

    getLocation = async (filter) => {
        //https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query?where=MUNICIPALITYNAME='ADM'&outFields=NAMEENGLISH&returnGeometry=false&f=json
        //https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query?where=NAMEENGLISH='AL BATEEN'&outFields=*&returnGeometry=false&f=json
        //?where=NAMEENGLISH='AL BATEEN'&outFields=*&returnGeometry=false&f=json

        const url = 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/MapServer/2/query';
        let params = {
            outFields: '*',
            returnGeometry: false,
            f: 'json',
        };

        if (filter) {
            params = { ...params, ...filter };
        }

        try {
            const response = await axios.get(url, { params });
            return response.data;
        } catch (error) {
            throw error;
        }
    };

    deleteUploadedDocument = async (token) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            let response = await restApi.post({
                url: `Delete?MIMSDocumentId=${token}`,
                cancelable: false,
                showAlerts: false,
            });
            return response.data;
        } catch (error) {
            throw error;
        }
    };

    // Get printer template
    getPrintTemplate = async (licenseNo) => {
        const restApi = new RestApi({ controller: 'Profiles' });
        try {
            let response = await restApi.post({
                url: 'getPrintTemplate',
                body: {},
                cancelable: true,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    smartHubLogout = async () => {
        const restApi = new RestApi({ controller: 'User' });
        try {
            let response = await restApi.post({
                url: 'ssoLogout',
                body: {},
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };
    smartPassLogout = async (id_token, access_token) => {
        const state = store.getState();
        const env = state.settings.environment || 'test';
        const currentEnvConfig = envConfig[env];
        let endSessionUrl, endSessionConfig, revokeTokensUrl, revokeTokensConfig;
        try {
            endSessionUrl = `${currentEnvConfig.smartPass.baseUrl}/secure/oauth2/connect/endSession?id_token_hint=${id_token}`;
            //Todo: extract this logic into a helper
            endSessionConfig = this.addSSL({
                method: 'get',
                headers: {
                    Authorization: `Bearer ${access_token}`,
                },
            });
        } catch (error) {
            throw error;
        }
        const endSessionResponse = await pinch.fetch(endSessionUrl, endSessionConfig);

        try {
            revokeTokensUrl = `${currentEnvConfig.smartPass.baseUrl}/secure/frrest/oauth2/token/${access_token}?_action=revokeTokens`;
            //Todo: extract this logic into a helper

            revokeTokensConfig = this.addSSL({
                method: 'post',
                body: '{ "client_id": "adm" }',
                headers: {
                    'Accept-API-Version': 'protocol=1.0,resource=1.0',
                    'Content-Type': 'application/json',
                },
            });
        } catch (error) {
            throw error;
        }

        const revokeTokensResponse = await pinch.fetch(revokeTokensUrl, revokeTokensConfig);
    };

    cancelLogin = async () => {
        //console.log('api.cancelLogin()');
        RestApi.cancelRequest({ endpoint: 'smarthub', controller: 'User', url: 'SsoLogin', messasge: 'Login cancelled by user.' });
        RestApi.cancelRequest({ endpoint: 'smarthub', controller: 'Profiles', url: 'GetMimsProfiles', messasge: 'Login cancelled by user.' });
        RestApi.cancelRequest({ endpoint: 'smarthub', controller: 'Profiles', url: 'SwitchMimsRole', messasge: 'Login cancelled by user.' });
        return 'requested to cancell all auth api tokens...';

        // const userRestApi = new RestApi({ controller: 'User' }); //User/SsoLogin
        // const profilesRestApi = new RestApi({ controller: 'Profiles' }); //Profiles/GetMimsProfiles,   Profiles/SwitchMimsRole
    };

    checkDuplicate = async (duplicateCheckRequestModel) => {
        const restApi = new RestApi({ controller: 'MimsDistortion' });
        try {
            const response = await restApi.post({
                url: 'GetDuplicates',
                body: duplicateCheckRequestModel,
                cancelable: true,
                showAlerts: false,
            });
            // return [];
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getInspectionDetails = async ({
        workflowConst,
        workflowInstanceId,
        applicationNumber,
        IsShallow,
        inspectionTypeId,
        workflowApplicationNumber,
        includeDraftVisit = true,
    }) => {
        let controller = workflowConst || 'Inspection';
        //if (controller.toLowerCase().startsWith('mims')) controller = controller.substring(4);
        const restApi = new RestApi({ controller });

        try {
            const response = await restApi.post({
                url: 'GetInspectionDetails',
                body: {
                    workflowInstanceId,
                    applicationNumber,
                    IsShallow,
                    inspectionTypeId,
                    workflowApplicationNumber,
                    includeDraftVisit,
                },
                cancelable: true,
                showAlerts: false,
            });
            // return inspectionDetailsMocknew;
            //{ ...inspectionDetailsMock, applicationNumber };
            // return { ...inspectionDetailsMock, applicationNumber };
            // if (duplicateCheckRequestModel.selectedWorkflowConst == 'MimsDistortion') return duplicateListMock;
            // else if (duplicateCheckRequestModel.selectedWorkflowConst != 'MimsDistortion') return checkListDuplicateMock;
            // else return duplicateMock;
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    loadMasterdata = async (lastUpdated) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'LoadMasterData',
                body: { lastUpdated: lastUpdated },
                cancelable: false,
                showAlerts: true,
            });
            //Todo: remove violationTypes below when LoadMasterdata API returns correct structure and data of violationTypes
            const { result } = response.data;
            //const newservices = [...result.services];
            //   services: newservices,

            return {
                ...result,
                mockViolationTypes: violationTypes,
                //printTemplate: `${printTemplateHeader}\n${printTemplateContent}\n${printTemplateFooter}`,
            };
            //return  response.data;
        } catch (error) {
            throw error;
        }
    };

    createInspectionRecord = async (createInspectionModel) => {
        //uncomment to test health inspection
        /*
        return {
            inspectionId: 7993,
            refNumber: '20200211091122403',
            service: 1003,
            inspectionTypeId: 1003,
            createdByUserId: 1274,
            createdDate: '2020-02-11T09:11:35',
            location: {
                locationAddressId: 135410,
                coords: {
                    gpsTime: null,
                    accuracy: 17.7080001831055,
                    longitude: 54.3783471,
                    latitude: 24.4874388,
                    speed: null,
                    heading: null,
                    altitude: null,
                },
                address: {
                    zoneId: 435,
                    zoneNameA: 'جزيرة أبوظبي',
                    zoneNameE: 'ABU DHABI ISLAND',
                    sectorId: 4312,
                    sectorNameA: 'شرق 11',
                    sectorNameE: 'E11',
                    plotGisId: 4251901,
                    plotNumber: 'P1',
                },
            },
            visits: [
                {
                    type: null,
                    assignedToUserId: null,
                    taskId: null,
                    duedate: null,
                    applicationNumber: '1545',
                    workflowApplicationNumber: null,
                    inspectionId: 7993,
                    location: {
                        locationAddressId: 135410,
                        coords: {
                            gpsTime: null,
                            accuracy: 17.7080001831055,
                            longitude: 54.3783471,
                            latitude: 24.4874388,
                            speed: null,
                            heading: null,
                            altitude: null,
                        },
                        address: {
                            zoneId: 435,
                            zoneNameA: 'جزيرة أبوظبي',
                            zoneNameE: 'ABU DHABI ISLAND',
                            sectorId: 4312,
                            sectorNameA: 'شرق 11',
                            sectorNameE: 'E11',
                            plotGisId: 4251901,
                            plotNumber: 'P1',
                        },
                    },
                    visitDate: '2020-02-11T09:11:22',
                    isLast: true,
                    values: [],
                    visitedByUserId: 1274,
                    def: {
                        type: 'checklist',
                        typeId: 0,
                        def: [
                            {
                                showFormTitle: false,
                                collapsible: false,
                                showLabels: false,
                                checklistGroups: [
                                    {
                                        code: '1000',
                                        titleE: 'General Group',
                                        titleA: 'المجموعة العامة',
                                        checklist: [
                                            {
                                                code: '1010',
                                                inspTypeCheckItemId: 1029,
                                                checkItemId: 1010,
                                                questionE:
                                                    'There is a temporary fence in accordance with the requirements and before starting work\n',
                                                questionA: 'يوجد سور مؤقت مطابق للاشتراطات وقبل البدء بالإعمال\n',
                                                violationTypeIds: [1002],
                                                questionType: 'YesNo',
                                                isMandatory: false,
                                                isAttachementMandatory: false,
                                                isRemarkMandatory: false,
                                            },
                                            {
                                                code: '1071',
                                                inspTypeCheckItemId: 1052,
                                                checkItemId: 1071,
                                                questionE: 'The absence of a tent or caravan is not licensed\n',
                                                questionA: 'عدم وجود خيمة  او كرافان تو ما في حكمهم غير مرخصة \n',
                                                violationTypeIds: [1074, 1025],
                                                questionType: 'YesNo',
                                                isMandatory: false,
                                                isAttachementMandatory: false,
                                                isRemarkMandatory: false,
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                    generalInfo: null,
                    distortionForm: null,
                    siteVisit: null,
                    resUnitOccupancySuspicion: null,
                    buildingPenaltiesForm: null,
                    abandonedVehicleInfo: null,
                    generalAppearanceVehicleInfo: null,
                    warrantDocs: null,
                    followupForm: null,
                    moreInfo: null,
                    steps: null,
                },
            ],
            violators: [],
            inspectionTypeDetail: {
                inspectionTypeId: 1003,
                parentInspectionTypeId: 1002,
                titleE: 'Health inspection',
                titleA: 'التفتيش الصحي',
                icon: {
                    type: 'AdmIcon',
                    name: 'wf-1149',
                },
                inspectionTypeCheckItems: [],
                workflowConst: 'MimsHealthInspection',
                inspEntityId: 1000,
                serviceDescE: 'Health inspection',
                serviceDescA: 'التفتيش الصحي',
            },
        };*/

        const { inspectionTypeDetail } = createInspectionModel;
        const controller = (inspectionTypeDetail && inspectionTypeDetail.workflowConst) || 'Inspection';
        const restApi = new RestApi({ controller });
        try {
            const response = await restApi.post({
                url: 'CreateInspectionRecord',
                body: createInspectionModel,
                cancelable: false,
                showAlerts: false,
            });

            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    cancelInspection = async (cancelInspectionModel) => {
        const { inspectionTypeDetail } = cancelInspectionModel;
        const controller = (inspectionTypeDetail && inspectionTypeDetail.workflowConst) || 'Inspection';
        const restApi = new RestApi({ controller });
        try {
            const response = await restApi.post({
                url: 'CancelInspection',
                body: cancelInspectionModel,
                cancelable: false,
                showAlerts: false,
            });

            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    createInspection = async (params) => {
        const { inspectionTypeDetail = {} } = params;
        const controller = inspectionTypeDetail.workflowConst || 'Inspection';
        const restApi = new RestApi({ controller });

        try {
            const response = await restApi.post({
                url: 'StartAndConfirmInspection',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getInitialTasks = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'GetMyTasks',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getTaskDetails = async (taskId) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'GetTaskDetails',
                body: { taskId },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    beginTask = async ({ taskId, inspectionTypeId, workflowConst }) => {
        const controller = workflowConst || 'Inspection';
        const restApi = new RestApi({ controller });
        try {
            const response = await restApi.post({
                url: 'BeginTask',
                body: { taskId, inspectionTypeId },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getActionTypes = async (params) => {
        const controller = params.workflowConst || 'Inspection';
        const restApi = new RestApi({ controller });
        try {
            const response = await restApi.post({
                url: 'GetViolationActionTypes',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            const result = response.data.result;
            if (result.violationActionTypes) {
                const mappedActionTypes = result.violationActionTypes.map((item) => {
                    return { ...item, constant: item.constant.toLowerCase() };
                });
                return {
                    ...result,
                    violationActionTypes: mappedActionTypes,
                };
                // duplicateInspections: [],
            } else return result;
        } catch (error) {
            throw error;
        }
    };

    getViolationActionTypes = async (params) => {
        if (params.workflowConst == 'MimsHealthInspection') {
            return {
                violationActionTypes: [
                    {
                        type: 'ActionType',
                        id: '1001',
                        parentId: null,
                        constant: 'warning',
                        labelE: 'Warning',
                        labelA: 'انذار',
                        amount: 0,
                        reconciledAmount: 0,
                        defaultPeriod: {
                            periodType: 'day',
                            periodValue: 3,
                        },
                        maxPeriod: {
                            periodType: 'hour',
                            periodValue: 300,
                        },
                    },
                    {
                        type: 'ActionType',
                        id: '1002',
                        parentId: null,
                        constant: 'violation',
                        labelE: 'Violation',
                        labelA: 'مخالفة',
                        amount: 500,
                        reconciledAmount: 250,
                        defaultPeriod: {
                            periodType: 'hour',
                            periodValue: 60,
                        },
                        maxPeriod: {
                            periodType: 'hour',
                            periodValue: 300,
                        },
                    },
                ],
                duplicateInspections: [],
                urlArgs: null,
            };
        }

        const controller = params.workflowConst || 'Inspection';
        const restApi = new RestApi({ controller });
        try {
            const response = await restApi.post({
                url: 'GetViolationActionTypes',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            const result = response.data.result;
            if (result.violationActionTypes) {
                const mappedActionTypes = result.violationActionTypes.map((item) => {
                    return { ...item, constant: item.constant.toLowerCase() };
                });
                return {
                    ...result,
                    violationActionTypes: mappedActionTypes,
                };
                // duplicateInspections: [],
            } else return result;
        } catch (error) {
            throw error;
        }
    };

    getFoodTruckContract = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'GetFoodTruckContract',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result || [];
        } catch (error) {
            throw error;
        }
    };
    getBuildingInfo = async (params, tempGetOnlyOne) => {
        const testResult = [
            {
                buildingNumber: 'ABC-234234',
                buildingNameE: 'ABC building',
                buildingNameA: 'بناء ABC',
                buildingType: { type: 'buildingType', id: '2', labelE: 'Residential', labelA: ' سكني', parentId: '' },
            },
            {
                buildingNumber: 'xyz-234234',
                buildingNameE: 'xyz building',
                buildingNameA: 'بناء ABC',
                buildingType: { type: 'buildingType', id: '1', labelE: 'Building', labelA: ' سكني', parentId: '' },
            },
        ];

        if (tempGetOnlyOne) {
            return [testResult[0]];
        }
        return testResult;

        // const restApi = new RestApi({ controller: 'DummyMims' });
        // try {
        //     const response = await restApi.post({
        //         url: 'GetBuildingInfo',
        //         body: params,
        //         cancelable: false,
        //         showAlerts: false,
        //     });
        //     if (response.data.result.length > 0 && tempGetOnlyOne) {
        //         const firstResult = response.data.result[0];
        //         return [firstResult];
        //     } else {
        //         //Todo: remove the delay
        //         return response.data.result;
        //         //return delayedResult(true, response.data.result, 1000);
        //     }
        // } catch (error) {
        //     throw error;
        // }
    };

    getCustomerFromMEPS = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'GetViolatorsFromMEPS ',
                body: params,
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getCustomerFromELMS = async (params) => {
        const restApi = new RestApi({ controller: 'Inspection' });
        try {
            const response = await restApi.post({
                url: 'GetViolatorsFromELMS',
                body: params,
                cancelable: false,
                showAlerts: false,
            });

            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    // getTaskDetails = taskid => mockApi.getTaskDetails(taskid);
    trackingLocationUpdate = async (data) => {
        return { TrackingLocationUpdate: 'dummy success', ...data };
        // const restApi = new RestApi({ controller: 'DummyMims' });
        // try {
        //     let response = await restApi.post({
        //         url: 'TrackingLocationUpdate',
        //         body: data,
        //         cancelable: false,
        //         showAlerts: false,
        //     });
        //     return response.data.result;
        // } catch (error) {
        //     throw error;
        // }
    };
    /* mock api calls */
    //getInitialTasks = userData => mockApi.getInitialTasks(userData);
    adminLogin = (username, password, success = true) => mockApi.adminLogin(username, password, success);
    //  checkDuplicate = (duplicateCheckRequestModel, success = true) => mockApi.checkDuplicate(duplicateCheckRequestModel, success);
    //   loadMasterdata = lastUpdated => mockApi.loadMasterdata(lastUpdated);
    //createInspectionRecord = createInspectionModel => mockApi.createInspectionRecord(createInspectionModel);
    // createInspection = params => mockApi.createInspection(params);
    getPlotOwnerDetails = (plotGisId) => mockApi.getPlotOwnerDetails(plotGisId);
    //getDashboardCharts = (chartId, PrevchartData) => mockApi.getDashboardCharts(chartId, PrevchartData);
    createFollowup = (params) => mockApi.createFollowup(params);
    getBuildingDetails = (params) => mockApi.getBuildingDetails(params);
    getInspectorPlanStatus = async (inspectoruserId) => {
        return mockApi.getInspectorPlanStatus(inspectoruserId);
    };

    getInspectionsPlotsData = async (plotGisIds) => {
        return mockApi.getInspectionsPlotsData(plotGisIds);
    };
    getBuildingDetails = (params) => mockApi.getBuildingDetails(params);
    //   getAddress = coords => mockApi.getAddress(coords);

    // getDashboardCharts = async (startdate, enddata, chartType, chartId, PrevchartData, loadAll) => {
    //     try {
    //         if (!loadAll) {
    //             const newDashboardCharts = PrevchartData;
    //             const restApi = new RestApi({ controller: 'Inspection' });
    //             const response = await restApi.post({
    //                 url: 'getChart',
    //                 body: { startdate, enddata, chartType },
    //                 cancelable: true,
    //                 showAlerts: false,
    //             });
    //             //newDashboardCharts[chartId] = response.data.result;
    //             return response.data.result;
    //             //return this.delayedResult(true, newDashboardCharts);
    //         } else {
    //             const restApi = new RestApi({ controller: 'Inspection' });
    //             const response = await restApi.post({
    //                 url: 'getChart',
    //                 body: { startdate, enddata, chartType },
    //                 cancelable: true,
    //                 showAlerts: false,
    //             });

    //             return response.data.result;
    //         }
    //     } catch (error) {
    //         throw error;
    //     }
    // };

    searchInspection = async (props) => {
        try {
            const restApi = new RestApi({ controller: 'Inspection' });
            const { fixedFilter, ...restProps } = props;
            const searchParams = { ...restProps, ...fixedFilter };
            const response = await restApi.post({
                url: 'SearchInspection',
                body: { ...searchParams },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };
    searchInspectionTask = async (props) => {
        try {
            const restApi = new RestApi({ controller: 'Inspection' });
            const { fixedFilter, ...restProps } = props;
            const searchParams = { ...restProps, ...fixedFilter };
            const response = await restApi.post({
                url: 'SearchInspectionTask',
                body: { ...searchParams },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    // getInspectionHistory = async (startdate, enddata, pageSize) => {
    //     try {
    //         const restApi = new RestApi({ controller: 'Inspection' });
    //         const response = await restApi.post({
    //             url: 'SearchInspection',
    //             body: { startdate, enddata, pageSize },
    //             cancelable: true,
    //             showAlerts: false,
    //         });
    //         return response.data.result;
    //     } catch (error) {
    //         throw error;
    //     }
    // };

    getDashboardChartTypes = async () => {
        try {
            const restApi = new RestApi({ controller: 'Inspection' });
            const response = await restApi.post({
                url: 'GetDashboardChartsType',
                body: {},
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };

    getDashboardCharts = async (inspectionChartType) => {
        try {
            const restApi = new RestApi({ controller: 'Inspection' });
            const response = await restApi.post({
                url: 'GetDashboardCharts',
                body: { inspectionChartType },
                cancelable: false,
                showAlerts: false,
            });
            return response.data.result;
        } catch (error) {
            throw error;
        }
    };
}

delayedResult = (success, data, latency) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (success) resolve(data);
            else reject(data);
        }, latency || this.latency);
    });
};
