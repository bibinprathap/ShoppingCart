import axios from 'axios';
import envConfig from './config';
import alertsHelper from 'app/api/helperServices/alerts';
import createError from 'app/api/helperServices/errors';
import { _state, store } from 'app/config/store';

export default class RestApi {
    static cancelTokens = {};
    constructor({ controller, dispatch = null, secure = true, endpoint = 'smarthub' }) {
        //if (!dispatch || dispatch == null) throw Error(`Dispatch cannot be null. controller: ${controller}`);

        //const env = 'test';
        //const env = 'development';
        const env = _state.settings.environment || 'test';

        this.header = {
            'Content-Type': 'application/json',
            Accept: '*/*',
        };
        this.controller = controller || '';
        this.dispatch = dispatch;
        this.secure = secure;
        this.envConfig = envConfig[env];
        this.endpoint = endpoint;
    }

    get = ({ url, parameters, body, headers, isFormData, showAlerts, cancelable }) => {
        return this.restApi('GET', url, parameters, body, headers, isFormData, showAlerts, cancelable);
    };

    post = ({ url, parameters, body, headers, isFormData, showAlerts, cancelable }) => {
        return this.restApi('POST', url, parameters, body, headers, isFormData, showAlerts, cancelable);
    };

    static cancelRequest = ({ endpoint = 'smarthub', controller = '', url, message }) => {
        const env = _state.settings.environment || 'test';
        const requestUrl = RestApi.parseUrl(endpoint, envConfig[env], controller, url);
        const previousToken = RestApi.cancelTokens[requestUrl];

        if (previousToken && typeof previousToken.cancel === 'function') {
            previousToken.cancel(`Request canceled [${requestUrl}].${message ? message : ''}}`);
            previousToken.isCancelled = true;
            RestApi.cancelTokens[requestUrl] = previousToken;
        }
    };

    restApi = (method = 'GET', url = '', parameters = {}, body = {}, headers = {}, isFormData = false, showAlerts = true, cancelable = false) => {
        if (!url) url = '';
        if (!parameters) parameters = {};
        if (!headers) headers = {};
        //let requestUrl = this.gis === true ? url : this.parseUrl(url, parameters);
        let requestUrl = RestApi.parseUrl(this.endpoint, this.envConfig, this.controller, url, parameters);

        // if (isFormData) {
        //     //set correct Content-Type in the headers
        // }

        const defaultHeaders = {
            'Content-Type': 'application/json',
            //'Access-Control-Allow-Origin': '*',
        };
        const requestConfig = {
            url: requestUrl,
            method: method,
            headers: { ...defaultHeaders, ...headers },
            data: typeof body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
            //body: JSON.stringify(body),
            timeout: this.envConfig.timeout || 0, //doesn't always work. need to fix this
            withCredentials: true,
            //todo: add token if it is secure call
        };

        if (cancelable) {
            RestApi.cancelRequest({ endpoint: this.endpoint, url: requestUrl, message: 'One request allowed per url' });

            const newTokenSource = axios.CancelToken.source();
            newTokenSource.isCancelled = false;
            RestApi.cancelTokens[requestUrl] = newTokenSource;
            requestConfig.cancelToken = newTokenSource.token;
        }
        return this.sendRequest(requestConfig, showAlerts);
        //return this.fetchRequest(requestConfig, showAlerts);
    };

    fetchRequest = (requestConfig, showAlerts) => {
        //Todo:  dispatch --> this.dispatch(ajax-call-counter-increment-action)

        return (
            fetch(requestConfig.url, requestConfig)
                //.request(requestConfig)
                .then(response => this.parseFetchResponse(response, requestConfig))
                .catch(error => {
                    //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
                    console.log('restApi fetch error: ', { error });

                    let errorToThrow = createError(error);
                    errorToThrow.isCancel = axios.isCancel(error);

                    if (showAlerts && errorToThrow) {
                        alertsHelper.show('error', errorToThrow.message, errorToThrow.detail);
                        errorToThrow.handled = true;
                    }
                    throw errorToThrow;
                })
        );
    };

    parseFetchResponse = (response, requestConfig) =>
        response.text().then(text => {
            let data;
            try {
                data = JSON.parse(text);
            } catch (err) {
                data = text;
            }

            delete RestApi.cancelTokens[requestConfig.url];
            //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
            //return response;

            return {
                statusText: response.statusText,
                status: response.status,
                ok: response.ok,
                body: data,
            };
        });

    sendRequest = (requestConfig, showAlerts) => {
        //Todo:  dispatch --> this.dispatch(ajax-call-counter-increment-action)
        console.log('restApi axios request: ', requestConfig);
        axios.defaults.withCredentials = true;
        axios.defaults.timeout = requestConfig.timeout;
        const logLevel = store.getState().generic.logs.logLevel || 'error';
        return axios
            .request(requestConfig)
            .then(response => {
                const cancelToken = RestApi.cancelTokens[requestConfig.url];
                console.log('restApi axios success... url:', requestConfig.url, 'response:', response);
                if (cancelToken && cancelToken.isCancelled) {
                    //Should never come here, but just in case...
                    console.warn('restApi axios success - request was cancelled');
                    throw 'isCancel';
                }
                //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
                this.handleArcGisError(response);
                delete RestApi.cancelTokens[requestConfig.url];
                if (logLevel === 'debug') {
                    const logAction = {
                        type: 'LOG_API_ERRORS',
                        message: '',
                        details: { response },
                    };
                    store.dispatch(logAction);
                }

                return response;
            })
            .catch(error => {
                //Todo:  dispatch --> this.dispatch(ajax-call-counter-decrement-action)
                console.log('restApi axios error: ', { error });
                let errorToThrow = createError(error);
                errorToThrow.isCancel = error === 'isCancell' || axios.isCancel(error);

                let errorMessage = errorToThrow.detail || errorToThrow.message;
                if (showAlerts && errorToThrow) {
                    alertsHelper.show('error', errorToThrow.message, errorMessage);
                    errorToThrow.handled = true;
                }

                const logAction = {
                    type: 'LOG_API_ERRORS',
                    message: errorMessage,
                    details: { response: error && error.response },
                };
                store.dispatch(logAction);

                throw errorToThrow;
            });
    };

    handleArcGisError = response => {
        if (this.endpoint === 'mapServer' && response.data && response.data.error) {
            const arcGisErrorMessage = response.data.error.message;
            let arcGisErrorDetail =
                response.data.error.details && response.data.error.details.length > 0 ? response.data.error.details.join(',') : '';
            if (response.data.error.infos && response.data.error.infos.length > 0) {
                const mappedInfos = response.data.error.infos.map(i => i.description);
                const allInfos = mappedInfos.join(', ');
                if (allInfos) {
                    arcGisErrorDetail = (arcGisErrorDetail ? ', ' : '') + allInfos;
                }
            }
            const formattedArcGisError = {
                message: arcGisErrorMessage || 'Unknown ArcGis error.',
                detail: arcGisErrorDetail,
                status: response.data.error.code,
            };
            throw formattedArcGisError;
        }
    };
    static parseUrl = (endpoint = 'smarthub', envConfig = {}, controller = '', url = '', parameters) => {
        if (url.toLowerCase().startsWith('http')) return url;
        const regex = /:(\w+)\/?/g;

        let m;

        while ((m = regex.exec(url)) !== null) {
            // This is necessary to avoid infinite loops with zero-width matches
            if (m.index === regex.lastIndex) {
                regex.lastIndex++;
            }

            // The result can be accessed through the `m`-variable.
            m.forEach(match => {
                if (parameters[match]) {
                    url = url.replace(`:${match}`, parameters[match]);
                    delete parameters[match];
                }
            });
        }

        let prefix = url.lastIndexOf('?') > 0 ? '&' : '?';

        for (let propName in parameters) {
            url = url.concat(`${prefix}${propName}=${parameters[propName]}`);
            if (prefix === '?') {
                prefix = '&';
            }
        }
        let parsedUrl = '';
        if (endpoint == 'smarthub') {
            if (url.startsWith('//')) {
                parsedUrl = `${envConfig.baseURL}/${url.slice(2)}`;
            } else {
                if (url.startsWith('/')) {
                    url = url.slice(1);
                }
                if (url.startsWith('?')) {
                    parsedUrl = `${envConfig.baseURL}/${controller}${url}`;
                } else {
                    parsedUrl = `${envConfig.baseURL}/${controller}/${url}`;
                }
            }
        } else if (endpoint == 'mapServer') {
            parsedUrl = `${envConfig.mapServer}/${url}`;
        }

        return parsedUrl;
    };
}
export { envConfig };
