const baseUrlQa = 'https://qa-id.uaepass.ae';
const baseUrlProd = 'https://id.uaepass.ae';
const authorizationEndpoint = '/trustedx-authserver/oauth/main-as';
const tokenEndpoint = '/trustedx-authserver/oauth/main-as/token';
const userInfoEndpoint = '/trustedx-resources/openid/v1/users/me';
const config = {
    redirectUrl: 'https://eformstest.adm.gov.ae/UaePassCallBack',
    clientId: 'dpm_smarthub_stage',
    additionalParameters: {
        acr_values: 'urn:safelayer:tws:policies:authentication:level:low',
        ui_locales: 'en',
    },
    secret: 'QCDJfJBS5d8ptN9j',
    callback_url: 'https://eformstest.adm.gov.ae/UaePassCallBack',
    response_type: 'code',
    scopes: ['urn:uae:digitalid:profile'],
    acr_values: 'urn:safelayer:tws:policies:authentication:level:low',
    ui_locales: 'en',
};
export default {
    qa: {
        ...config,
        baseUrl: baseUrlQa,
        authorizationEndpoint: `${baseUrlQa}${authorizationEndpoint}`,
        tokenEndpoint: `${baseUrlQa}${tokenEndpoint}`,
        userInfoEndpoint: `${baseUrlQa}${userInfoEndpoint}`,
        serviceConfiguration: {
            authorizationEndpoint: `${baseUrlQa}${authorizationEndpoint}`,
            tokenEndpoint: `${baseUrlQa}${authorizationEndpoint}`,
        },
    },
    prod: {
        ...config,
        baseUrl: baseUrlProd,
        authorizationEndpoint: `${baseUrlProd}${authorizationEndpoint}`,
        tokenEndpoint: `${baseUrlProd}${tokenEndpoint}`,
        userInfoEndpoint: `${baseUrlProd}${userInfoEndpoint}`,
        serviceConfiguration: {
            authorizationEndpoint: `${baseUrlQa}${authorizationEndpoint}`,
            tokenEndpoint: `${baseUrlQa}${authorizationEndpoint}`,
        },
    },
};
