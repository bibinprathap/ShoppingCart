import React, { memo, Component, useState } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import styles from './styles';
import Menu from './Menu';
import Caption from './Caption';
import CallOut from './CallOut';
import InspectorCurrentLocation from './InspectorCurrentLocation';
import InspectionLocation from './InspectionLocation';
import { getFeatureServerUrl, getFeatureLayersIndex } from 'app/api/helperServices/utils';
import { getLocation } from 'app/api/helperServices/geolocation';
import ArcGISMapView from '../../../ThirdPartyModuleJS/AGSMapView';
import { setPreference } from 'app/actions/generic';
import SearchMenu from './SearchMenu';
import { formatAddress } from 'app/api/helperServices/utils';
const defaultBaseMap = 'STREETS';
const defaultPointGraphics = [
    { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
    { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    { graphicId: 'inspectorPoint', graphic: Image.resolveAssetSource(require('app/images/inspPin.png')) },
];
class ADMGISMapView extends Component {
    //const calloutRenderer;
    constructor(props) {
        super(props);
        this.state = {
            showCallOut: false,
            basemap: props.basemap || defaultBaseMap,
            layers: this.createLayersUrls(props.layers),
            callOutData: undefined,
            layout: { width: 0, height: 0 },
            coordsInitialized: props.coords != undefined,
        };
        this.locationChanged = this.locationChanged.bind(this);
    }
    componentDidUpdate(prevProps, prevState) {
        if (prevProps.coords == undefined && this.state.coordsInitialized == false && this.props.coords != undefined) {
            this.setState({ coordsInitialized: true }, () => {
                this.focusInspectionLocation();
            });
        }
    }
    componentDidMount() {
        if (!this.props.preference.mapInitialized) {
            setTimeout(() => {
                if (!this.props.preference.mapInitialized) this.props.dispatch(setPreference({ mapInitialized: true }));
            }, 8000);
        }
    }
    // setshowCallOut = val => {
    //     this.setState({ showCallOut: val });
    // };
    // setcallOutData = data => {
    //     this.setState({ callOutData: data });
    // };
    setlayout = layout => {
        this.setState({ layout: layout });
    };
    setBasemap = basemap => {
        this.setState({ basemap: basemap });
    };
    setLayers = layers => {
        this.setState({ layers: layers });
    };

    getInspectorCurrentLocation = async () => {
        const currentLocation = await getLocation();
        currentLocation.graphicId = 'inspectorPoint';
        currentLocation.referenceId = 'referenceId';
        const inspectorCurrentLocationData = currentLocation && {
            pointGraphics: defaultPointGraphics,
            referenceId: 'InspectorCurrentLocation',
            points: [currentLocation],
        };
        if (this.mapView) {
            this.mapView.setInspectorLocation(inspectorCurrentLocationData);
        }
    };
    focusInspectionLocation = () => {
        const props = this.props;
        if (this.mapView) {
            this.mapView.recenterMap([props.coords]);
        }
    };
    onSingleTap = event => {
        const props = this.props;
        let wasVisible = this.menu && this.menu.hideMenu();
        if (wasVisible) return;
        const points = event.nativeEvent;
        console.log('ADMGISMapView onSingleTap', points);
        if (!points.mapPoint) {
            return;
        }
        //const calloutRenderer = this.props.renderCallout();
        // commented below to move the single tap and opening the callout to the host component
        // if (typeof points.data !== 'undefined' && points.data != null) {
        //     this.setshowCallOut(true);
        //     this.setcallOutData(points);
        // } else if (typeof points.appNumber !== 'undefined' && points.appNumber != null) {
        //     this.setshowCallOut(true);
        //     this.setcallOutData(points);
        // } else {
        //     this.setshowCallOut(false);
        // }
        if (props.onSingleTap) {
            const showCallOut = props.onSingleTap(points);
            // console.log('showCallOut 0', showCallOut);
            if (!((typeof showCallOut === 'object' || typeof showCallOut === 'function') && typeof showCallOut.then === 'function')) {
                // console.log('showCallOut 1', showCallOut);
                this.setState({ showCallOut: !!showCallOut, callOutData: points });
            }
            // console.log('showCallOut 3', showCallOut);
        }
        // const calloutRenderer = props.renderCallout && props.renderCallout(points);
        // if (calloutRenderer) {
        //     <CallOut layoutData={this.state.layout} calloutRenderer={calloutRenderer} />;
        // }
        // console.log('calloutRenderer', calloutRenderer);
    };
    createLayersUrls = layers => {
        if (!layers) return;
        const featureServerUrl = getFeatureServerUrl();
        const layersIndex = getFeatureLayersIndex();
        return layers.map(l => `${featureServerUrl}/${layersIndex[l]}`);
    };
    handleSelectlayers = layers => {
        const layersWithUrl = this.createLayersUrls(layers);
        this.setLayers(layersWithUrl);
    };
    handleBaseMap = basemap => {
        this.setBasemap(basemap);
    };
    handleLayout = event => {
        var { x, y, width, height } = event.nativeEvent.layout;
        this.setlayout({ width: width, height: height });
    };
    locationChanged = coords => {
        this.mapView.recenterMap([coords]);
        this.props.onSingleTap && this.props.onSingleTap({ mapPoint: coords });
    };
    render() {
        const props = this.props;
        // const calloutRenderer = this.props.renderCallout();
        const {
            polygonsData,
            renderData,
            renderStaticData,
            coords,
            placeMarks,
            markersReferenceId,
            showMenu,
            showSearchMenu,
            // showInspectorCurrentLocation,
            showInspectionLocation,
            routeData,
            address,
            noAddress,
            renderCallout,
            pointGraphics,
        } = props;
        const mergedPointGraphics = pointGraphics ? [...pointGraphics, ...defaultPointGraphics] : [...defaultPointGraphics];
        const markersData = placeMarks && {
            pointGraphics: mergedPointGraphics,
            referenceId: markersReferenceId || 'defaultId',
            points: [...placeMarks],
        };
        //24.46272/54.34341 24.4611 ,54.3477
        //  const coords = [{ x: 24.4608299, y: 54.3609183 }];
        const { layers, basemap, layout, showCallOut, callOutData } = this.state;
        //  console.log('this.props.renderCallout', this.props.renderCallout);
        let caption = '';
        if (address) {
            caption = formatAddress(address);
        }
        if (noAddress) {
            caption = noAddress;
        }
        console.log('ADMGisMapView.render() state: ', this.state);
        return (
            <View
                style={[styles.container, props.preference.mapInitialized ? { marginBottom: 0 } : { marginBottom: 1 }]}
                onLayout={event => {
                    this.handleLayout(event);
                }}
            >
                <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ width: '100%', height: '100%' }}
                    initialMapCenter={[coords]}
                    recenterIfGraphicTapped={true}
                    // pointGraphics={mergedPointGraphics}
                    layersData={layers}
                    baseMapType={basemap}
                    markersData={markersData}
                    polygonsData={polygonsData}
                    renderData={renderData}
                    renderStaticData={renderStaticData}
                    routeData={routeData}
                    onSingleTap={this.onSingleTap}
                />
                {/* {showInspectorCurrentLocation ? <InspectorCurrentLocation onGetCurrentLocation={this.getInspectorCurrentLocation} /> : null} */}
                <View style={styles.menuWrapper}>
                    <InspectorCurrentLocation onGetCurrentLocation={this.getInspectorCurrentLocation} />
                    {showInspectionLocation ? <InspectionLocation onGetInspectionLocation={this.focusInspectionLocation} /> : null}
                    {showMenu && (
                        <Menu
                            selectedLayers={this.props.layers}
                            selectedBasemap={basemap}
                            onLayersChange={this.handleSelectlayers}
                            onBaseMapChange={this.handleBaseMap}
                            ref={menu => {
                                this.menu = menu;
                            }}
                        />
                    )}
                    {showSearchMenu ? <SearchMenu locationChanged={this.locationChanged} address={address} /> : null}
                </View>
                {(caption && <Caption menu={showMenu} label={caption} />) || null}
                {showCallOut && <CallOut data={callOutData} layoutData={layout} renderCallout={renderCallout} />}
            </View>
        );
    }
}
const mapStateToProps = state => {
    return {
        preference: state.generic.preference,
    };
};
export default connect(mapStateToProps)(ADMGISMapView);
