import React, { Component } from 'react';
import { View, PixelRatio, TouchableOpacity } from 'react-native';
import styles from './styles';
// import { Text } from 'react-native-paper';
// import { StatusChip } from 'app/components';
// import { inspectionsHelper, tasksHelper } from 'app/api/helperServices';
// import { TaskDetailsDialog } from 'app/screens';
export default class CallOut extends Component {
    state = { width: 0, height: 0 };
    handleLayout = event => {
        var { width, height } = event.nativeEvent.layout;

        this.setState({ width: width, height: height });
    };
    // handlePress = () => {
    //     console.log('handlePress callout ', this.props.data.taskId);
    //     if (typeof this.props.data.taskId !== 'undefined' && this.props.data.taskId != null) {
    //         const itemObj = { taskId: this.props.data.taskId };
    //         tasksHelper.selectTask(itemObj, this.props.navigation);
    //     }
    // };
    render() {
        const { layoutData, data, renderCallout } = this.props;

        const callOutWidth = this.state.width;
        const callOutHeight = this.state.height;
        const pixelRatio = PixelRatio.get();
        let left = data.screenPoint.x / pixelRatio;
        let top = data.screenPoint.y / pixelRatio;

        left = layoutData.width - left > callOutWidth ? left : layoutData.width - callOutWidth - 10;
        top = layoutData.height - top > callOutHeight ? top : layoutData.height - callOutHeight - 30;
        // const left = PixelRatio.roundToNearestPixel(data.screenPoint.x) / pixelRatio;
        //const top = PixelRatio.roundToNearestPixel(data.screenPoint.y) / pixelRatio;

        // //Object.
        // let Heading = data.appNumber ? data.title + ' - ' + data.appNumber : null;
        // let Details = data.serviceDesc ? data.serviceDesc : null;
        // let polyData = data.data ? data.data : null;
        // let Status = data.inspectionStatus ? data.inspectionStatus : null;
        // let TaskId = data.taskId ? 'Task ID - ' + data.taskId : null;

        return (
            <View
                style={[styles.callOutContainer, { left, top }]}
                onLayout={event => {
                    this.handleLayout(event);
                }}
            >
                {typeof renderCallout === 'function' ? renderCallout(data) : null}
                {/* <TouchableOpacity onPress={this.handlePress} style={styles.container}>
                    {data.heading && <Text style={styles.itemMediumText}>{data.heading}</Text>}
                    {data.taskID && <Text style={styles.itemSmallText}>{data.taskID}</Text>}
                    {data.details && <Text style={styles.itemSmallText}>{data.details}</Text>}
                </TouchableOpacity>
                {data.status && <StatusChip statusConst={data.status} />}
                {/* translatedStatus={Status}
                <TaskDetailsDialog /> */}
            </View>
        );
    }
}
