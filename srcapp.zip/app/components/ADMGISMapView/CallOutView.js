import React, { Component } from 'react';
import { View, PixelRatio, TouchableOpacity } from 'react-native';
import styles from './styles';
import { Text } from 'react-native-paper';
import { StatusChip } from 'app/components';
import { inspectionsHelper, tasksHelper } from 'app/api/helperServices';
import { TaskDetailsDialog } from 'app/screens';
export default class CallOutView extends Component {
    render() {
        return (
            <View>
                <TouchableOpacity>
                    <Text>abc</Text>
                </TouchableOpacity>
            </View>
        );
    }
}
