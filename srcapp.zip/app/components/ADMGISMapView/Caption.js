import React, { Component } from 'react';
import { View, TouchableOpacity, Image } from 'react-native';
import styles from './styles';
import { Text, Button, Checkbox } from 'react-native-paper';
export default class Caption extends Component {
    render() {
        const { menu, label } = this.props;
        if (!label) return null;
        return (
            <View style={menu == true ? styles.captionContainer : styles.captionContainerNoMenu}>
                <TouchableOpacity>
                    <Text style={styles.labelText}>{label}</Text>
                </TouchableOpacity>
            </View>
        );
    }
}
