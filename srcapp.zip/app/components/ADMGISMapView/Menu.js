import React, { Component } from 'react';
import { View, TouchableOpacity, Image } from 'react-native';
import styles from './styles';
import { Text, Button, Checkbox } from 'react-native-paper';
import { Icon } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import images from 'app/images';

export default class Menu extends Component {
    Basemaps = [
        { name: 'streets', value: 'STREETS', title: strings('streets') },
        { name: 'imagery', value: 'IMAGERY', title: strings('imagery') },
        { name: 'darkGray', value: 'DARK_GRAY', title: strings('darkGray') },
    ];
    Layers = [
        {
            name: 'plots',
            title: strings('plots'),
            // value: 0,
            // url: 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/0',
            selected: false,
        },
        {
            name: 'sectors',
            title: strings('sectors'),
            // value: 1,
            // url: 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/1',
            selected: false,
        },
        {
            name: 'zones',
            title: strings('zones'),
            // value: 2,
            // url: 'https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/2',
            selected: false,
        },
    ];

    constructor(props) {
        super(props);
        const { selectedLayers, selectedBasemap } = this.props;
        if (selectedLayers) {
            for (let i = 0; i < this.Layers.length; i++) {
                if (selectedLayers.indexOf(this.Layers[i].name) != -1) {
                    this.Layers[i].selected = true;
                }
            }
        }
        this.state = {
            menuVisible: false,
            selectedLayers: selectedLayers || [],
            selectedBasemap: selectedBasemap, // || 'STREETS',
        };
    }

    handleLayerSelection = layer => {
        const { onLayersChange } = this.props;
        layer.selected = !layer.selected;
        const selectedLayers = this.Layers.filter(l => l.selected).map(l => l.name);
        this.setState({ selectedLayers });

        onLayersChange && onLayersChange(selectedLayers);

        /*
        const selectedLayers = [...this.state.selectedLayers];
        if (selectedLayers.indexOf(layer.url) != -1) {

            // selectedLayers.

            selectedLayers.splice(selectedLayers.indexOf(layer.url), 1);

            // delete selectedLayers[selectedLayers.indexOf(layer.url)];
        } else selectedLayers.push(layer.url);

        this.setState({ selectedLayers });
        this.props.onLayersChange(selectedLayers);
        */
    };

    hideMenu = () => {
        if (this.state.menuVisible) {
            this.setState({ menuVisible: false });
            return true;
        } else return false;
    };

    handleMenuPress = () => {
        this.setState({ menuVisible: !this.state.menuVisible });
    };

    handleBasemapSelection = basemap => {
        this.setState({ selectedBasemap: basemap.value });
        this.props.onBaseMapChange(basemap.value);
    };

    render() {
        const { menuVisible } = this.state;
        if (!menuVisible) {
            return (
                <TouchableOpacity style={styles.menuIconContainer} onPress={this.handleMenuPress}>
                    <Icon type="MaterialCommunityIcons" name="layers-outline" style={styles.layerIcon} size={28} />
                </TouchableOpacity>
            );
        } else {
            return (
                <View style={styles.containerTop}>
                    <View>
                        <Text style={styles.titleText}>{strings('mapType')}</Text>

                        <View style={{ flexDirection: 'row', margin: 5 }}>
                            {this.Basemaps.map(basemap => {
                                //     `creating basemap menu item...`,
                                //     basemap,
                                //     `selected (${this.state.selectedBasemap}): `,
                                //     this.state.selectedBasemap == basemap.value ? 'true' : 'false'
                                // );
                                return (
                                    <TouchableOpacity onPress={() => this.handleBasemapSelection(basemap)}>
                                        <Image
                                            source={images[basemap.name].content}
                                            style={[
                                                styles.imageStyle,
                                                this.state.selectedBasemap == basemap.value ? styles.imageStyleSelected : null,
                                            ]}
                                        />
                                        <Text
                                            style={[styles.imageText, this.state.selectedBasemap == basemap.value ? styles.imageTextSelected : null]}
                                        >
                                            {basemap.title}
                                        </Text>
                                    </TouchableOpacity>
                                );
                            })}
                        </View>
                        <Text style={styles.titleText}>{strings('layers')}</Text>
                        <View style={styles.layerView}>
                            {this.Layers.map((layer, i) => (
                                <TouchableOpacity
                                    onPress={() => this.handleLayerSelection(layer)}
                                    key={i}
                                    // style={[styles.layerTouch, { borderColor: layer.selected ? '#349EFB' : '#F7F7FA' }]}
                                    style={[styles.layerTouch, layer.selected ? styles.layerTouchSelected : null]}
                                >
                                    <Text style={styles.layerText}>{layer.title}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                </View>
            );
        }
    }
}
