import React, { Component } from 'react';
import { View, Text, ScrollView, I18nManager, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import * as Animatable from 'react-native-animatable';
import { _ } from 'lodash';
import { Icon, Modal } from 'app/components';
//import { TouchableOpacity } from 'react-native-gesture-handler';
import { AddressSearch } from 'app/components/AddressSearch';

const municipalityList = [
    {
        id: 1000,
        name: I18nManager.isRTL ? 'بلدية مدينة أبوظبي' : 'Abu Dhabi City Municipality',
    },
    {
        id: 1001,
        name: 'AAM',
    },
    {
        id: 1002,
        name: 'WRM',
    },
];

class SearchMenu extends Component {
    constructor(props) {
        super(props);
        this.state = { modalVisible: false };
    }
    addressSearchRef;

    hideMenu = () => {
        if (this.state.modalVisible) {
            const isAllHidden = this.addressSearchRef.hideAll();
            if (isAllHidden) {
                this.setState({ modalVisible: false });
            }
        } else return false;
    };

    render() {
        const isRTL = I18nManager.isRTL;
        const { modalVisible } = this.state;
        let selectedMunicipality = {
            id: 1000,
            name: isRTL ? 'بلدية مدينة أبوظبي' : 'Abu Dhabi City Municipality',
        };
        const { address } = this.props;

        if (address && address.municipalityId) selectedMunicipality = _.find(municipalityList, item => item.id == address.municipalityId);

        return (
            <View>
                <TouchableOpacity onPress={() => this.setState({ modalVisible: true })} style={styles.buttonWrapper}>
                    <Icon type="MaterialCommunityIcons" name="magnify" size={28} style={styles.icon} />
                </TouchableOpacity>
                <Modal transparent={true} visible={modalVisible} animationType={'none'} onRequestClose={() => this.setState({ modalVisible: false })}>
                    <TouchableWithoutFeedback onPress={this.hideMenu}>
                        <View style={{ position: 'absolute', width: '100%', height: '100%', backgroundColor: '#000', opacity: 0.4 }} />
                    </TouchableWithoutFeedback>
                    <Animatable.View animation="slideInRight" style={{ alignSelf: 'center', width: 350, height: 600, position: 'absolute', top: 50 }}>
                        <View style={styles.opacityInner} />
                        <AddressSearch
                            height={350}
                            address={address}
                            onSelectCoords={item => {
                                if (this.props.locationChanged && item.latitude) {
                                    this.setState({ modalVisible: false }, () => {
                                        this.props.locationChanged({ latitude: parseFloat(item.latitude), longitude: parseFloat(item.longitude) });
                                    });
                                }
                            }}
                            selectedMunicipality={selectedMunicipality}
                            ref={ref => {
                                this.addressSearchRef = ref;
                            }}
                        />
                        <TouchableOpacity onPress={() => this.setState({ modalVisible: false })} style={styles.closeButton}>
                            <Icon type="MaterialCommunityIcons" name="close" size={20} />
                        </TouchableOpacity>
                    </Animatable.View>
                    {/* <TouchableOpacity onPress={() => this.setState({ modalVisible: false })} style={[styles.buttonWrapper, { top: 190 }]}>
                    <Icon type="MaterialCommunityIcons" name="magnify" size={20} style={styles.icon} />
                </TouchableOpacity> */}
                </Modal>
            </View>
        );
    }
}
const styles = EStyleSheet.create({
    buttonWrapper: {
        backgroundColor: '$primaryHeaderColor',
        height: 40,
        width: 40,
        borderRadius: 7,
        justifyContent: 'center',
        alignItems: 'center',
        margin: 5,
    },
    opacityInner: {
        flex: 1,
        position: 'absolute',
        left: 0,
        top: 0,
        opacity: 0.7,
        backgroundColor: '$primaryWhite',
        width: 350,
        height: 350,
        borderWidth: 1,
        borderColor: '$primaryBorderColor',
        borderRadius: 10,
        marginTop: 20,
    },
    icon: {
        color: '$primaryWhite',
        fontWeight: 'bold',
    },
    closeButton: {
        position: 'absolute',
        backgroundColor: '$primaryWhite',
        opacity: 0.8,
        width: 30,
        height: 30,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 2,
        margin: 5,
        top: 5,
        right: -10,
        borderWidth: 1,
        borderColor: '$primaryBorderColor',
        borderRadius: 15,
    },
});

export default SearchMenu;
