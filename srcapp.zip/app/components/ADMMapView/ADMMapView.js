import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, Dimensions, StyleSheet, Button } from 'react-native';
import styles from './styles';
import MapView from 'react-native-maps';

class ADMMapView extends Component {
    static propTypes = {
        onCoordinateschanged: PropTypes.func,
    };

    state = {
        focusedLocation: {
            latitude: 24.486775,
            longitude: 54.378501,
            latitudeDelta: 0.009,
            longitudeDelta: (Dimensions.get('window').width / Dimensions.get('window').height) * 0.009,
        },

        container: {
            flex: 1,
            paddingTop: 1,
        },
    };

    pickLocationHandler = event => {
        const coords = event.nativeEvent.coordinate;
        //alert('cords '+coords.latitude +'***' +coords.longitude );
        this.map.animateToRegion({
            ...this.state.focusedLocation,
            latitude: coords.latitude - 0.002,
            longitude: coords.longitude,
        });
        this.setState(
            {
                focusedLocation: {
                    ...this.state.focusedLocation,
                    latitude: coords.latitude,
                    longitude: coords.longitude,
                },
            },
            () => {
                if (!!this.props.onCoordinateschanged) {
                    this.props.onCoordinateschanged(coords);
                }
            }
        );
    };

    //_onMapReady=()=>this.setState({ paddingTop: 0 })

    // componentWillMount() {
    //  setTimeout(()=>this.setState({container: {width: "100%",alignItems: "center", paddingTop: 0}}),500);
    //  //setTimeout(()=>this.forceUpdate() , 1000);
    // }

    render() {
        // let marker = null;

        // if (this.state.locationChosen) {
        //   marker = <MapView.Marker coordinate={this.state.focusedLocation} />;
        // }

        return (
            <View style={this.state.container}>
                <MapView
                    initialRegion={this.state.focusedLocation}
                    style={styles.map}
                    // pitchEnabled={false}
                    // rotateEnabled={false}
                    // scrollEnabled={false}
                    // zoomEnabled={false}
                    // toolbarEnabled={false}
                    onPress={this.pickLocationHandler}
                    showsUserLocation={true}
                    showsMyLocationButton={true}
                    onMapReady={() => this.setState({ container: { flex: 1, paddingTop: 0 } })}
                    ref={ref => (this.map = ref)}
                >
                    <MapView.Marker coordinate={this.state.focusedLocation} />
                </MapView>
            </View>
        );
    }
}

export default ADMMapView;
