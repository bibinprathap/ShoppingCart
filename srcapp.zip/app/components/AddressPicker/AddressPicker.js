import React, { Component } from 'react';
import { View, Picker, Text, TouchableOpacity } from 'react-native';
import { Button, IconButton } from 'react-native-paper';
import styles from './styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Selector, Icon } from 'app/components';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { _ } from 'lodash';
import { search, setAddress } from 'app/actions/search';

import AppApi from 'app/api/real';
const api = new AppApi();
import { I18nManager } from 'react-native';

const municipalities = [
    {
        id: 1000,
        nameA: 'بلدية مدينة أبوظبي',
        nameE: 'Abu Dhabi City Municipality',
    },
    {
        id: 1001,
        nameA: 'AAM',
        nameE: 'AAM',
    },
    {
        id: 1002,
        nameA: 'WRM',
        nameE: 'WRM',
    },
];

class AddressPicker extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectorType: null,
            selectedZone: null,
            selectedSector: null,
            selectedPlot: null,
            dataSource: [],
            dataSourceTemp: [],
            isLoading: false,
            searchFieldName: null,
            municipalityId: '1000',
        };
        this.onMunicipalitySelect = this.onMunicipalitySelect.bind(this);
    }

    selectAddressBtnPress = (selectorType) => {
        this.setState({ selectorType, isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleZonePressed = () => {
        this.setState({ selectorType: 'zone', isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleSectorPressed = () => {
        if (!this.state.selectedZone) return;
        this.setState({ selectorType: 'sector', isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handlePlotPressed = () => {
        if (!this.state.selectedSector) return;
        this.setState({ selectorType: 'plot', isLoading: true }, () => {
            this.handleLocationSearch('');
        });
    };

    handleLocationSearch = async (searchKey) => {
        try {
            let result = null;
            let orderBy = null;
            const { selectedZone, selectedSector, selectorType, municipalityId } = this.state;
            const isRTL = I18nManager.isRTL;
            switch (selectorType) {
                case 'zone':
                    orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';

                    result = await api.getZones({
                        municipalityId,
                        OrderByField: isRTL ? 'zoneNameA' : 'zoneNameE',
                        options: { orderByFields: orderBy, outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'zoneNameA' : 'zoneNameE',
                    });

                case 'sector':
                    if (!selectedZone) return null;
                    orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';

                    result = await api.getSectors({
                        municipalityId,
                        OrderByField: isRTL ? 'sectorNameA' : 'sectorNameE',
                        zoneIds: [selectedZone.zoneId],
                    });
                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: isRTL ? 'sectorNameA' : 'sectorNameE',
                    });
                case 'plot':
                    if (!selectedZone || !selectedSector) return null;

                    result = await api.getPlots({
                        municipalityId,
                        sectorIds: [selectedSector.sectorId],
                        zoneIds: [selectedZone.zoneId],
                        OrderByField: 'plotNumber',
                    });

                    return this.setState({
                        dataSource: result && result.length > 0 ? result : [],
                        dataSourceTemp: result && result.length > 0 ? result : [],
                        isLoading: false,
                        searchFieldName: 'plotNumber',
                    });

                default:
                    break;
            }
            this.setState({ isLoading: false });
        } catch (e) {
            this.setState({ isLoading: false });
        }
    };
    onMunicipalitySelect = (municipalityId) => {
        this.setState({
            municipalityId,
            selectedZone: null,
            selectorType: null,
            selectedSector: null,
            selectedPlot: null,
            searchFieldName: null,
            dataSource: [],
            dataSourceTemp: [],
            isLoading: false,
        });
    };

    onLocationSelect = (item) => {
        switch (this.state.selectorType) {
            case 'zone':
                this.setState({
                    selectedZone: item || null,
                    selectorType: null,
                    selectedSector: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'sector':
                this.setState({
                    selectedSector: item || null,
                    selectorType: null,
                    selectedPlot: null,
                    searchFieldName: null,
                    dataSource: [],
                    dataSourceTemp: [],
                    isLoading: false,
                });
                break;
            case 'plot':
                this.setState(
                    {
                        selectedPlot: item || null,
                        selectorType: null,
                        searchFieldName: null,
                        dataSource: [],
                        dataSourceTemp: [],
                        isLoading: false,
                    },
                    () => {
                        if (item && this.state.selectedZone && this.state.selectedSector) {
                            this.handleSearch();
                        }
                    }
                );

                break;
            default:
                this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false });
                break;
        }
    };

    handleSearch = () => {
        this.props.handleSearch({
            ...this.props.search.filter,
            zone: this.state.selectedZone,
            sector: this.state.selectedSector,
            plot: this.state.selectedPlot,
        });
        this.props.actions.setAddress({
            zone: this.state.selectedZone,
            sector: this.state.selectedSector,
            plot: this.state.selectedPlot,
        });
    };

    mapItem = (item) => {
        switch (this.state.selectorType) {
            case 'zone':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'zoneName') };
            case 'sector':
                return { ...item, id: item['objectId'], label: localeProperty(item, 'sectorName') };
            case 'plot':
                return { ...item, id: item['objectId'], label: item['plotNumber'] };
            default:
                return null;
        }
    };

    searchKeyUpdate = (searchKey) => {
        if (this.state.dataSourceTemp && this.state.dataSourceTemp.length > 0) {
            const filterdDataSource = _.filter(this.state.dataSourceTemp, (item) => {
                let value = item[this.state.searchFieldName].toLowerCase();
                return value.indexOf(searchKey.toLowerCase()) > -1;
            });
            this.setState({ dataSource: filterdDataSource });
        }
    };

    render() {
        return (
            <View style={{ flex: 1, flexDirection: 'column' }}>
                {this.state.selectorType && (
                    <Selector
                        placeholder={strings('searchByName')}
                        isLoading={this.state.isLoading}
                        onSelect={this.onLocationSelect}
                        source={this.state.dataSource}
                        mapItem={this.mapItem}
                        searchKeyUpdate={this.searchKeyUpdate}
                        handleSearch={(searchKey) => this.handleLocationSearch(searchKey)}
                        onRequestClose={() => this.setState({ selectorType: null, dataSource: [], dataSourceTemp: [], isLoading: false })}
                        headerTitle={strings('select')}
                    />
                )}
                <View style={styles.buttonWrapper}>
                    <Picker selectedValue={this.state.municipalityId} style={{ height: 50, width: 335 }} onValueChange={this.onMunicipalitySelect}>
                        {municipalities.map((m) => {
                            return <Picker.Item label={localeProperty(m, 'name')} value={m.id} style={styles.pickerItem} />;
                        })}
                    </Picker>

                    {/* <Button style={[styles.optionBtn, styles.locationButton]} onPress={null}>
                        <Icon type="MaterialCommunityIcons" name="map-marker" size={22} />
                    </Button> */}
                    {/* <IconButton
                        style={{ alignSelf: 'flex-end' }}
                        icon="search"
                        size={20}
                        onPress={this.props.handleSearch.bind(this, {
                            ...this.props.search.filter,
                            zone: this.state.selectedZone,
                            sector: this.state.selectedSector,
                            plot: this.state.selectedPlot,
                        })}
                    /> */}
                    {/* <View style={{ flexDirection: 'column', flex: 1 }}>
                        <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('zone')}>
                            {(this.state.selectedZone && localeProperty(this.state.selectedZone, 'zoneName')) || strings('zone')}
                        </Button>
                        <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('sector')}>
                            {(this.state.selectedZone && localeProperty(this.state.selectedSector, 'sectorName')) || strings('sector')}
                        </Button>
                        <Button style={styles.optionBtn} onPress={() => this.selectAddressBtnPress('plot')}>
                            {(this.state.selectedPlot && this.state.selectedPlot.plotNumber) || strings('plot')}
                        </Button>
                    </View> */}
                </View>

                <View style={{ flexDirection: 'row', marginLeft: -180 }}>
                    <TouchableOpacity style={[styles.optionBtn, { flex: 2 }]} onPress={this.handleZonePressed}>
                        <Text style={styles.optionBtnText}>
                            {(this.state.selectedZone && localeProperty(this.state.selectedZone, 'zoneName')) || strings('zone')}
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.optionBtn, { flex: 1 }]} onPress={this.handleSectorPressed}>
                        <Text style={[styles.optionBtnText, !this.state.selectedZone && styles.optionBtnTextDisabled]}>
                            {(this.state.selectedZone && localeProperty(this.state.selectedSector, 'sectorName')) || strings('sector')}
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.optionBtn, { flex: 1 }]} onPress={this.handlePlotPressed}>
                        <Text style={[styles.optionBtnText, !this.state.selectedSector && styles.optionBtnTextDisabled]}>
                            {(this.state.selectedPlot && this.state.selectedPlot.plotNumber) || strings('plot')}
                        </Text>
                    </TouchableOpacity>
                    <View>
                        <IconButton icon="search" size={20} style={styles.searchIcon} onPress={this.handleSearch} disabled={!this.state.selectedZone || !this.state.selectedSector} />
                    </View>
                </View>
            </View>
        );
    }
}

mapStateToProps = (state) => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
                search,
                setAddress,
            },
            dispatch
        ),
        dispatch,
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AddressPicker);
