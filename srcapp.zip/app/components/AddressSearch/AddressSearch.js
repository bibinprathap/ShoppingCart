import React, { Component, Fragment } from 'react';
import { ScrollView, View, Text } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import SearchableDropdown from 'app/components/Common/SearchableDropDown';
import { Loader } from 'app/components';
import AppApi from 'app/api/real';
const api = new AppApi();
import { I18nManager } from 'react-native';
import { _ } from 'lodash';
import { search, setAddress } from 'app/actions/search';
import { strings, localeProperty } from 'app/config/i18n/i18n';
const municipalityList = [
    {
        id: 1000,
        name: I18nManager.isRTL ? 'بلدية مدينة أبوظبي' : 'Abu Dhabi City Municipality',
    },
    {
        id: 1001,
        name: 'AAM',
    },
    {
        id: 1002,
        name: 'WRM',
    },
];

class AddressSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedZone: null,
            selectedSector: null,
            selectedPlot: null,
            dataSourceMuncipaities: municipalityList,
            dataSourceZones: [],
            dataSourceSectors: [],
            dataSourcePlots: [],
            isLoadingZones: false,
            isLoadingSectors: false,
            isLoadingPlots: false,
            selectedMunicipality: props.selectedMunicipality || null,
        };
        this.onMunicipalitySelect = this.onMunicipalitySelect.bind(this);
    }

    munDropdownRef;
    zoneDropdownRef;
    secDropdownRef;
    plotDropdownRef;

    componentDidMount() {
        this.init();
    }

    init = async () => {
        try {
            const { selectedMunicipality, address } = this.props;
            const municipalityId = selectedMunicipality && selectedMunicipality.id;
            if (municipalityId) {
                this.getZones(municipalityId, address);
            }
        } catch (e) {
            console.log('Location address search error', e);
        }
    };

    getZones = async (municipalityId, address) => {
        try {
            const { isRTL } = I18nManager;
            let dataSourceZones = [];
            let selectedZone = null;
            let orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';
            this.setState({ isLoadingZones: true });
            let result = await api.getZones({
                municipalityId,
                orderByField: orderBy,
                options: { outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
            });
            if (result && result.length > 0) {
                dataSourceZones = result.map(res => {
                    if (address && address.zoneId == res.zoneId) {
                        selectedZone = { ...res, id: res.objectId, name: localeProperty(res, 'zoneName') };
                        this.getSectors(municipalityId, selectedZone, address);
                    }
                    return { ...res, id: res.objectId, name: localeProperty(res, 'zoneName') };
                });
            }
            this.setState({ dataSourceZones, selectedZone, isLoadingZones: false });
        } catch (e) {
            console.log('Location getZones error', e);
            this.setState({ isLoadingZones: false });
        }
    };

    getSectors = async (municipalityId, selectedZone, address) => {
        try {
            if (!municipalityId || !selectedZone) return;
            const { isRTL } = I18nManager;
            let dataSourceSectors = [];
            let selectedSector = null;
            let orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';
            this.setState({ isLoadingSectors: true });
            let result = await api.getSectors({
                municipalityId,
                zoneIds: [selectedZone.zoneId],
                orderByField: orderBy,
                options: { outFields: 'objectId,sectorId,sectorNameA,sectorNameE' },
            });

            if (result && result.length > 0) {
                dataSourceSectors = result.map(res => {
                    if (address && address.sectorId == res.sectorId) {
                        selectedSector = { ...res, id: res.objectId, name: localeProperty(res, 'sectorName') };
                        this.getPlots(municipalityId, selectedZone, selectedSector, address);
                    }
                    return { ...res, id: res.objectId, name: localeProperty(res, 'sectorName') };
                });
            }
            this.setState({ dataSourceSectors, selectedSector, isLoadingSectors: false });
        } catch (e) {
            console.log('Location getSectors error', e);
            this.setState({ isLoadingSectors: false });
        }
    };

    getPlots = async (municipalityId, selectedZone, selectedSector, address) => {
        try {
            if (!municipalityId || !selectedZone || !selectedSector) return;
            let dataSourcePlots = [];
            let selectedPlot = null;
            this.setState({ isLoadingPlots: true });
            let result = await api.getPlots({
                municipalityId,
                sectorIds: [selectedSector.sectorId],
                zoneIds: [selectedZone.zoneId],
                orderByField: 'plotNumber',
            });

            if (result && result.length > 0)
                dataSourcePlots = result.map(res => {
                    if (address && address.plotNumber == res.plotNumber) {
                        selectedPlot = { ...res, id: res.objectId, name: res.plotNumber };
                    }
                    return { ...res, id: res.objectId, name: res.plotNumber };
                });

            this.setState({ dataSourcePlots, selectedPlot, isLoadingPlots: false });
        } catch (e) {
            console.log('Location getPlots error', e);
            this.setState({ isLoadingPlots: false });
        }
    };

    onMunicipalitySelect = selectedMunicipality => {
        this.setState(
            {
                selectedMunicipality,
                selectedZone: null,
                selectedSector: null,
                selectedPlot: null,
                dataSourceZones: [],
                dataSourceSectors: [],
                dataSourcePlots: [],
                isLoading: false,
            },
            () => {
                this.handleLocationSearch('zone');
            }
        );
    };

    handleLocationSearch = async selectorType => {
        try {
            const isRTL = I18nManager.isRTL;
            let result = null;
            let orderBy = null;
            const { selectedZone, selectedSector, selectedMunicipality } = this.state;
            const municipalityId = selectedMunicipality && selectedMunicipality.id;
            if (!municipalityId) return null;
            switch (selectorType) {
                case 'zone':
                    orderBy = isRTL ? 'zoneNameA' : 'zoneNameE';
                    let dataSourceZones = [];
                    this.setState({
                        isLoadingZones: true,
                        selectedZone: null,
                        selectedSector: null,
                        selectedPlot: null,
                        dataSourceZones: [],
                        dataSourceSectors: [],
                        dataSourcePlots: [],
                    });
                    result = await api.getZones({
                        municipalityId,
                        options: { orderByFields: orderBy, outFields: 'objectId,zoneId,zoneNameA,zoneNameE' },
                    });
                    if (result && result.length > 0)
                        dataSourceZones = result.map(res => {
                            return { ...res, id: res.objectId, name: localeProperty(res, 'zoneName') };
                        });
                    return this.setState({
                        dataSourceZones,
                        isLoadingZones: false,
                    });

                case 'sector':
                    if (!selectedZone) return null;
                    orderBy = isRTL ? 'sectorNameA' : 'sectorNameE';
                    let dataSourceSectors = [];
                    this.setState({
                        isLoadingSectors: true,
                        selectedSector: null,
                        selectedPlot: null,
                        dataSourceSectors: [],
                        dataSourcePlots: [],
                    });

                    result = await api.getSectors({
                        municipalityId,
                        zoneIds: [selectedZone.zoneId],
                    });
                    if (result && result.length > 0)
                        dataSourceSectors = result.map(res => {
                            return { ...res, id: res.objectId, name: localeProperty(res, 'sectorName') };
                        });

                    return this.setState({
                        dataSourceSectors,
                        isLoadingSectors: false,
                    });
                case 'plot':
                    if (!selectedZone || !selectedSector) return null;
                    let dataSourcePlots = [];
                    this.setState({
                        isLoadingPlots: true,
                        selectedPlot: null,
                        dataSourcePlots: [],
                    });
                    result = await api.getPlots({
                        municipalityId,
                        sectorIds: [selectedSector.sectorId],
                        zoneIds: [selectedZone.zoneId],
                        orderByFields: 'plotNumber',
                    });

                    if (result && result.length > 0)
                        dataSourcePlots = result.map(res => {
                            return { ...res, id: res.objectId, name: res.plotNumber };
                        });

                    return this.setState({
                        dataSourcePlots,
                        isLoadingPlots: false,
                    });

                default:
                    break;
            }
            this.setState({ isLoadingZones: false, isLoadingSectors: false, isLoadingPlots: false });
        } catch (e) {
            this.setState({ isLoadingZones: false, isLoadingSectors: false, isLoadingPlots: false });
        }
    };

    hideAll = () => {
        return !(
            this.munDropdownRef.hideList() ||
            this.zoneDropdownRef.hideList() ||
            this.secDropdownRef.hideList() ||
            this.plotDropdownRef.hideList()
        );
    };

    render() {
        const muncipalityLabel = strings('municipality');
        const zoneLabel = strings('zone');
        const sectorLabel = strings('sector');
        const plotLabel = strings('plot');

        const isLoading = this.state.isLoadingZones || this.state.isLoadingSectors || this.state.isLoadingPlots;
        const {
            selectedMunicipality,
            selectedZone,
            selectedSector,
            selectedPlot,
            dataSourceMuncipaities,
            dataSourceZones,
            dataSourceSectors,
            dataSourcePlots,
        } = this.state;

        return (
            <View style={styles.container}>
                <Text style={[styles.label, { position: 'absolute', top: 40, left: 8 }]}>{muncipalityLabel}</Text>
                <SearchableDropdown
                    onItemSelect={item => {
                        this.onMunicipalitySelect(item);
                    }}
                    containerStyle={{ position: 'absolute', left: 10, padding: 5, width: 330, height: 300, top: 55 }}
                    itemStyle={styles.itemStyle}
                    itemTextStyle={styles.itemTextStyle}
                    itemsContainerStyle={styles.itemsContainerStyle}
                    items={dataSourceMuncipaities}
                    selectedItem={selectedMunicipality || null}
                    resetValue={false}
                    textInputProps={{
                        placeholder: muncipalityLabel,
                        underlineColorAndroid: 'transparent',
                        style: styles.textInput,
                    }}
                    listProps={{
                        nestedScrollEnabled: true,
                    }}
                    ref={ref => {
                        this.munDropdownRef = ref;
                    }}
                    onFocus={() => {
                        this.zoneDropdownRef.hideList();
                        this.secDropdownRef.hideList();
                        this.plotDropdownRef.hideList();
                    }}
                />
                <Text style={[styles.label, { position: 'absolute', top: 120, left: 8 }]}>{zoneLabel}</Text>
                <SearchableDropdown
                    onItemSelect={item => {
                        this.setState({ selectedZone: item }, () => {
                            this.handleLocationSearch('sector');
                        });
                    }}
                    containerStyle={{ position: 'absolute', top: 135, left: 10, padding: 5, width: 330, height: 300 }}
                    itemStyle={styles.itemStyle}
                    itemTextStyle={styles.itemTextStyle}
                    itemsContainerStyle={styles.itemsContainerStyle}
                    items={dataSourceZones}
                    selectedItem={selectedZone || null}
                    resetValue={false}
                    textInputProps={{
                        placeholder: zoneLabel,
                        underlineColorAndroid: 'transparent',
                        style: styles.textInput,
                    }}
                    listProps={{
                        nestedScrollEnabled: true,
                    }}
                    ref={ref => {
                        this.zoneDropdownRef = ref;
                    }}
                    onFocus={() => {
                        this.munDropdownRef.hideList();
                        this.secDropdownRef.hideList();
                        this.plotDropdownRef.hideList();
                    }}
                />
                <Text style={[styles.label, { position: 'absolute', top: 200, left: 8 }]}>{sectorLabel}</Text>
                <SearchableDropdown
                    onItemSelect={item => {
                        this.setState({ selectedSector: item }, () => {
                            this.handleLocationSearch('plot');
                        });
                    }}
                    containerStyle={{ position: 'absolute', top: 215, left: 10, padding: 5, width: 330, height: 300 }}
                    itemStyle={styles.itemStyle}
                    itemTextStyle={styles.itemTextStyle}
                    itemsContainerStyle={styles.itemsContainerStyle}
                    items={dataSourceSectors}
                    selectedItem={selectedSector || null}
                    resetValue={false}
                    textInputProps={{
                        placeholder: sectorLabel,
                        underlineColorAndroid: 'transparent',
                        style: styles.textInput,
                    }}
                    listProps={{
                        nestedScrollEnabled: true,
                    }}
                    ref={ref => {
                        this.secDropdownRef = ref;
                    }}
                    onFocus={() => {
                        this.munDropdownRef.hideList();
                        this.zoneDropdownRef.hideList();
                        this.plotDropdownRef.hideList();
                    }}
                />
                <Text style={[styles.label, { position: 'absolute', top: 280, left: 8 }]}>{plotLabel}</Text>
                <SearchableDropdown
                    onItemSelect={item => {
                        this.setState({ selectedPlot: item });
                        if (this.props.onSelectCoords) this.props.onSelectCoords(item);
                    }}
                    containerStyle={{ position: 'absolute', top: 295, left: 10, padding: 5, width: 330, height: 300 }}
                    itemStyle={styles.itemStyle}
                    itemTextStyle={styles.itemTextStyle}
                    itemsContainerStyle={styles.itemsContainerStyle}
                    items={dataSourcePlots}
                    selectedItem={selectedPlot || null}
                    resetValue={false}
                    textInputProps={{
                        placeholder: plotLabel,
                        underlineColorAndroid: 'transparent',
                        style: styles.textInput,
                    }}
                    listProps={{
                        nestedScrollEnabled: true,
                    }}
                    ref={ref => {
                        this.plotDropdownRef = ref;
                    }}
                    onFocus={() => {
                        this.munDropdownRef.hideList();
                        this.zoneDropdownRef.hideList();
                        this.secDropdownRef.hideList();
                    }}
                />
                {isLoading && (
                    <View style={[styles.loaderWrapper, { height: (this.props.height || 350) - 20 }]}>
                        <Loader loading={true} sprinnerSize={30} />
                    </View>
                )}
            </View>
        );
    }
}

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
    },
    itemStyle: {
        padding: 10,
        backgroundColor: '$primaryLightBackground',
        borderColor: '$primaryBorderColor',
        borderWidth: 1,
        borderRadius: 5,
    },
    textInput: {
        borderWidth: 1,
        borderColor: '$primaryBorderColor',
        borderRadius: 5,
        backgroundColor: '$primaryWhite',
        marginBottom: 3,
        paddingLeft: 10,
        fontFamily: '$primaryFontNormal',
        elevation: 1,
    },
    label: {
        marginLeft: 10,
        fontSize: 14,
        color: '$primaryDarkTextColor',
        fontFamily: '$primaryFontNormal',
        elevation: 1,
        zIndex: 1,
    },
    itemTextStyle: {
        fontSize: 14,
        color: '$primaryDarkTextColor',
        fontFamily: '$primaryFontNormal',
        elevation: 1,
        zIndex: 2,
    },
    loaderWrapper: {
        position: 'absolute',
        backgroundColor: '$primaryWhite',
        opacity: 0.6,
        margin: 10,
        marginTop: 30,
        width: '100%',
    },
    itemsContainerStyle: {
        zIndex: 10,
        elevation: 10,
    },
});

export default AddressSearch;
