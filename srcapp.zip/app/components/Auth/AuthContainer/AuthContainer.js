import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    StatusBar,
    Image,
    KeyboardAvoidingView,
    TouchableWithoutFeedback,
    Keyboard,
    Platform,
    Animated,
    Easing,
    I18nManager,
} from 'react-native';
import { Surface, Button, Divider, TouchableRipple, List, Text, Icon } from 'react-native-paper';
import { strings, setLocale } from 'app/config/i18n/i18n';
import { initLanguage } from 'app/actions/settings';
import { persistor } from 'app/config/store';
import styles from './styles';
import { CheckBoxWithLabel, HeaderGeneric, Modal, CancelLogin } from 'app/components';
import { Settings } from 'app/screens';
import images from 'app/images';
import DeviceInfo from 'react-native-device-info';
import I18n from 'i18n-js';

const ANIMATION_DURATION = 200;

class AuthContainer extends Component {
    static propTypes = {
        children: PropTypes.any,
        remember: PropTypes.bool,
        loggingIn: PropTypes.bool,
        onBeginLogin: PropTypes.func.isRequired,
        username: PropTypes.string,
        password: PropTypes.string,
    };

    constructor(props) {
        super(props);
        this.state = {
            remember: props.remember || false,
            settingsModalVisible: false,
        };
        this.largeScale = 1;
        this.smallScale = 0.7;
        this.largeTopTranslate = 0;
        this.smallTopTranslate = -60;
        this.largeTopTranslateInputContainer = 0;
        this.smallTopTranslateInputContainer = -100;
        this.topTranslate = new Animated.Value(this.largeTopTranslate);
        this.topTranslateInputContainer = new Animated.Value(this.largeTopTranslateInputContainer);
        this.logoScale = new Animated.Value(this.largeScale);
    }

    componentDidMount() {
        const name = Platform.OS === 'ios' ? 'Will' : 'Did';
        this.keyboardWillShowListener = Keyboard.addListener(`keyboard${name}Show`, this.keyboardWillShow);
        this.keyboardWillHideListener = Keyboard.addListener(`keyboard${name}Hide`, this.keyboardWillHide);
    }
    componentWillUnmount() {
        this.keyboardWillShowListener.remove();
        this.keyboardWillHideListener.remove();
    }

    keyboardWillShow = () => {
        Animated.parallel([
            Animated.timing(this.logoScale, {
                toValue: this.smallScale,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
            Animated.timing(this.topTranslate, {
                toValue: this.smallTopTranslate,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
            Animated.timing(this.topTranslateInputContainer, {
                toValue: this.smallTopTranslateInputContainer,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
        ]).start();
    };

    keyboardWillHide = () => {
        Animated.parallel([
            Animated.timing(this.logoScale, {
                toValue: this.largeScale,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
            Animated.timing(this.topTranslate, {
                toValue: this.largeTopTranslate,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
            Animated.timing(this.topTranslateInputContainer, {
                toValue: this.largeTopTranslateInputContainer,
                duration: ANIMATION_DURATION,
                easing: Easing.linear,
                useNativeDriver: true,
            }),
        ]).start();
    };

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };

    onLoginPress = () => {
        const { username, password } = this.props;
        this.props.onBeginLogin(this.state.remember, username, password);
    };

    handleLanguageSwitch = () => {
        const newLocale = I18nManager.isRTL ? 'en-US' : 'ar-AE';
        this.props.dispatch(initLanguage(newLocale));
        persistor.flush().then(() => {
            setLocale(newLocale);
        });
    };

    render() {
        const { children, loggingIn, translatedLogin, isSmartPass } = this.props;
        const logoContainerStyles = [
            styles.logoContainer,
            {
                transform: [{ scale: this.logoScale }, { translateY: this.topTranslate }],
            },
        ]; //, { height: this.logoHeight }];
        //const logoStyles = [styles.logo, { height: this.logoHeight, width: this.logoWidth }];
        const logoStyles = [
            styles.logo,
            {
                transform: [{ scale: this.logoScale }, { translateY: this.topTranslate }],
            },
        ];
        //const logoStyles = [styles.logo];

        return (
            <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                <View style={styles.container}>
                    <StatusBar translucent={false} hidden={false} barStyle="default" backgroundColor={styles.statusBar.backgroundColor} />
                    <KeyboardAvoidingView behavior="padding">
                        <Animated.View style={logoContainerStyles}>
                            <Animated.Image source={images.logo.content} style={logoStyles} resizeMode="contain" />
                        </Animated.View>
                        <Animated.View style={{ transform: [{ translateY: this.topTranslateInputContainer }] }}>
                            <Surface style={styles.surface}>
                                {children}
                                {!isSmartPass && (
                                    <View>
                                        <CheckBoxWithLabel
                                            label={strings('rememberMe')}
                                            value={this.state.remember}
                                            onValueChange={(val) => this.setState({ remember: val })}
                                            disabled={loggingIn}
                                            labelStyle={styles.checkboxLabel}
                                            color={styles.checkbox.color}
                                            uncheckedColor={styles.checkbox.color}
                                        />
                                        <Button
                                            style={styles.button}
                                            mode="contained"
                                            dark={true}
                                            onPress={this.onLoginPress}
                                            disabled={loggingIn}
                                            loading={loggingIn}
                                        >
                                            {translatedLogin}
                                        </Button>
                                    </View>
                                )}
                                <View>
                                    <Divider />
                                    <View style={styles.languageContainer}>
                                        <Button
                                            mode="contained"
                                            style={styles.languangeButton}
                                            disabled={loggingIn || !I18nManager.isRTL}
                                            onPress={() => this.handleLanguageSwitch()}
                                        >
                                            English
                                        </Button>
                                        <Button
                                            mode="contained"
                                            style={styles.languangeButton}
                                            disabled={loggingIn || I18nManager.isRTL}
                                            onPress={() => this.handleLanguageSwitch()}
                                        >
                                            العربية
                                        </Button>
                                    </View>
                                </View>
                            </Surface>
                        </Animated.View>
                    </KeyboardAvoidingView>
                    {!loggingIn && (
                        <View style={{ marginTop: -20 }}>
                            <Button
                                mode="contained"
                                dark={true}
                                style={styles.button}
                                icon="settings"
                                onPress={this.toggleSettingsDialog}
                                disabled={loggingIn}
                            >
                                {strings('settings')}
                            </Button>
                            <Modal
                                animationType="slide"
                                transparent={false}
                                visible={this.state.settingsModalVisible}
                                onRequestClose={this.toggleSettingsDialog}
                            >
                                <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                                <Settings {...this.props} dialogMode={true} requestClose={this.toggleSettingsDialog} />
                            </Modal>
                        </View>
                    )}
                    {loggingIn && <CancelLogin />}
                    <Text style={styles.text}>Version : {DeviceInfo.getVersion()}</Text>
                </View>
            </TouchableWithoutFeedback>
        );
    }
}

export default AuthContainer;
