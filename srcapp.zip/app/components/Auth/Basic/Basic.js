import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { TextInput, Headline } from 'react-native-paper';
import styles from './styles';
import { strings } from 'app/config/i18n/i18n';
import { AuthContainer } from 'app/components';

class Basic extends Component {
    static propTypes = {
        isAdmin: PropTypes.bool,
        username: PropTypes.string,
        password: PropTypes.string,
        remember: PropTypes.bool,
        loginType: PropTypes.string,
        authStarted: PropTypes.bool,
    };

    constructor(props) {

        super(props);
        this.state = {
            username: props.username || 'personuser',
            password: props.password || '123',
        };
    }

    render() {
        const translatedLogin = this.props.isAdmin ? strings('adminLogin') : strings('login');
        const { loggingIn } = this.props;
        const textInputTheme = { colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color } };
        //const textInputTheme = { roundness: 10 };
        return (
            <AuthContainer translatedLogin={translatedLogin} {...this.props} username={this.state.username} password={this.state.password}>
                <Headline style={styles.heading}>{translatedLogin}</Headline>
                <TextInput
                    style={styles.input}
                    label={strings('username')}
                    //placeholder={strings('username')}
                    value={this.state.username}
                    onChangeText={username => this.setState({ username })}
                    autoCorrect={false}
                    autoCapitalize="none"
                    disabled={loggingIn}
                    theme={textInputTheme}
                    mode="flat"
                />
                <TextInput
                    style={styles.input}
                    label={strings('password')}
                    //placeholder={strings('password')}
                    value={this.state.password}
                    onChangeText={password => this.setState({ password })}
                    autoCorrect={false}
                    autoCapitalize="none"
                    secureTextEntry={true}
                    disabled={loggingIn}
                    theme={textInputTheme}
                    mode="flat"
                />
            </AuthContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        username: state.auth.currentUser ? state.auth.currentUser.username : null,
        password: state.auth.currentUser ? state.auth.currentUser.password : null,
        remember: state.auth.remember,
        loggingIn: state.auth.loggingIn,
        loggedIn: state.auth.loggedIn,
        loginType: state.auth.loginType,
        authStarted: state.auth.authStarted,
    };
};

export default connect(mapStateToProps)(Basic);
