import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    button: {
        backgroundColor: '$primaryDarkButtonBackground',
        marginHorizontal: 10,
        marginVertical: 20,
        paddingVertical: 6,
    },
});
