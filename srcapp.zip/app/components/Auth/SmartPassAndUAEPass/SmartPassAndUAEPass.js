import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Button, Text, Divider } from 'react-native-paper';
import { View, TouchableHighlight, ActivityIndicator, Image, Animated } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Icon, AuthContainer, IconButton } from 'app/components';
import images from 'app/images';
import styles from './styles';

//Todo: change this to a helper service, this doesn't need to be a component
class SmartPassAndUAEPass extends Component {
    static propTypes = {
        loggingIn: PropTypes.bool,
        onBeginLogin: PropTypes.any,
    };
    render() {
        const { loggingIn } = this.props;
        const uaepassbuttonStyle = loggingIn ? styles.uaepassbuttondisable : styles.uaepassbutton;
        return (
            <AuthContainer isSmartPassorUAEPass={true} {...this.props}>
                <TouchableHighlight
                    style={uaepassbuttonStyle}
                    disabled={loggingIn}
                    onPress={() => {
                        this.props.onBeginLogin('smartPass', false);
                    }}
                    underlayColor="#fff"
                >
                    <View style={{ flexDirection: 'row' }}>
                        {loggingIn && <ActivityIndicator size="small" style={{ paddingEnd: 10, marginTop: -10 }} color="gray" />}
                        <View style={{ justifyContent: 'center', height: 20, width: 30 }}>
                            <Image
                                source={images.SmartPass_LoginButtonEn.content}
                                style={{ marginStart: -250, height: 30, wdth: 30 }}
                                resizeMode="contain"
                            />
                        </View>
                        <Text style={styles.buttonText}>{strings('smartPassLogin')}</Text>
                    </View>
                </TouchableHighlight>

                <View style={{ flexDirection: 'row' }}>
                    <Divider style={[styles.divider, {marginEnd: 10, marginStart: 50}]} />
                    <Text style={[styles.loginWith, { textAlignVertical: 'center' }]}>{strings('or')}</Text>
                    <Divider style={[styles.divider, {marginStart: 10, marginEnd: 50}]} />
                </View>
                <TouchableHighlight
                    style={uaepassbuttonStyle}
                    disabled={loggingIn}
                    onPress={() => {
                        //this.props.onBeginLogin('uaePass', false);
                    }}
                    underlayColor="#fff"
                >
                    <View style={{ flexDirection: 'row' }}>
                        {loggingIn && <ActivityIndicator size="small" style={{ paddingEnd: 10, marginTop: -10 }} color="gray" />}
                        <Text style={styles.buttonText}>{strings('loginWith')}</Text>
                        <View style={{ justifyContent: 'center', height: 20, width: 30 }}>
                            <Image
                                source={images.UAEPass_LoginButtonEn.content}
                                style={{ marginStart: -240, height: 30, wdth: 30 }}
                                resizeMode="contain"
                            />
                        </View>
                        {/* <Icon type="MaterialCommunityIcons" size={32} name="facebook" color="#fff" style={styles.icon}></Icon> */}
                        <Text style={styles.buttonText}>{strings('uaepass')} - [NOT IMPLEMENTED YET]</Text>
                    </View>
                </TouchableHighlight>
            </AuthContainer>
        );
    }
}

mapStateToProps = state => {
    return {
        loggingIn: state.auth.loggingIn,
    };
};

export default connect(mapStateToProps)(SmartPassAndUAEPass);
