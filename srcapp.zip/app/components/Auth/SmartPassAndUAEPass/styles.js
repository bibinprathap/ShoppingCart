import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    button: {
        backgroundColor: '$primaryDarkButtonBackground',
        marginHorizontal: 10,
        marginVertical: 20,
        paddingVertical: 6,
    },
    uaepassbutton: {
        marginHorizontal: 10,
        marginVertical: 20,
        paddingVertical: 20,
        backgroundColor: '$primaryDarkButtonBackground',
        borderRadius: 10,
        borderWidth: 1,
        justifyContent: 'center',
        flexDirection: 'row',
    },
    icon: {
        color: '#fff',
    },
    uaepassbuttondisable: {
        backgroundColor: '$primaryDisabledButtonBackground',
        marginHorizontal: 10,
        marginVertical: 20,
        paddingVertical: 20,
        borderRadius: 10,
        borderWidth: 1,
        justifyContent: 'center',
        flexDirection: 'row',
    },
    buttonText: {
        fontSize: '$primaryTextXS',
        color: '$primaryWhite',
    },
    linetext: {
        marginTop: -5,
    },
    divider: {
        flex: 1,
        height: 0,
        borderColor: 'white',
        borderBottomWidth: 0.5,
        marginVertical: 15,
        borderColor: '$primaryDividerDarkColor'
    },
    loginWith: {
        fontSize: '$primaryTextXS',
        color: '$primaryWhite',
        fontWeight: 'bold',
    },
});
