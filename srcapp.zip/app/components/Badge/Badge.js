import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';

export default memo(function(props) {
    propTypes = {
        size: PropTypes.number,
    };

    defaultProps = {
        size: 20,
    };
    const { children, size, containerStyle, textStyle } = props;
    const containerStyles = [
        styles.defaultContainer,
        {
            height: size,
            borderRadius: size / 2,
            right: -3,
            top: -5,
        },
        containerStyle ? containerStyle : null,
    ];
    const textStyles = [styles.defaultText, { fontSize: size / 1.3, lineHeight: size, marginHorizontal: 3 }, textStyle ? textStyle : null];

    return (
        <View style={containerStyles}>
            <Text numberOfLines={1} style={textStyles}>
                {children}
            </Text>
        </View>
    );
});
