import React from 'react';
import { View } from 'react-native';
import { AttachmentAndRemarks, Icon, CheckBoxWithLabel, ViolatorIcon } from 'app/components';
import { localeProperty } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

const initValues = {
    violatorId: null,
    selectedActionTypeConst: null,
    amount: 0,
    selectedPeriod: null,
    selectedActionType: null,
};

class Check extends React.PureComponent {
    constructor(props) {
        super(props);
        const selectedOption = props.val ? props.val.selectedOption : undefined;
        const attachments = props.val ? props.val.attachments : undefined;
        const remarks = props.val ? props.val.remarks : undefined;
        const violationTypeIds = props ? props.violationTypeIds : [];
        const violatorType = props.val && props.val.violatorType ? props.val.violatorType : null;
        const possibleViolatorTypes = props.val && props.val.possibleViolatorTypes ? props.val.possibleViolatorTypes : null;

        this.state = {
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            possibleViolatorTypes,
            violatorType,
        };
    }
    getCurrentValObject = () => {
        //Todo: decide where to get the attachments and remarks from? props or state
        const { selectedOption, attachments, remarks, violationTypeIds, possibleViolatorTypes, violatorType } = this.state;
        const { val } = this.props;

        let oldValues = {};
        if (val && _.isEqual(_.sortBy(violationTypeIds), _.sortBy(val.violationTypeIds || []))) {
            oldValues = this.props.val;
        }

        if (this.props.val && selectedOption != this.props.val.selectedOption) {
            oldValues = { ...initValues };
        }

        return {
            val: {
                ...oldValues,
                checkItemId: this.props.checkItemId,
                inspTypeCheckItemId: this.props.inspTypeCheckItemId,
                selectedOption,
                attachments,
                remarks,
                violationTypeIds,
                possibleViolatorTypes,
                violatorType,
            },
        };
    };

    optionSelected = (option) => {
        const previousSelectedOption = this.state.selectedOption;
        let newState = { selectedOption: option };
        if (option === false) {
            newState = { ...initValues, ...newState };
            newState.violationTypeIds = [];
            newState.possibleViolatorTypes = null;
            newState.violatorType = null;
        } else if (option === true) {
            const { violationTypeIds, checkItemId } = this.props;
            let values = [];
            let possibleViolatorTypes = null;
            let violatorType = null;
            const items = inspectionsHelper.getViolationTypeOptions(violationTypeIds, checkItemId);
            values = items.map((I) => I.id);
            //registeredAmount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
            violatorType = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
            possibleViolatorTypes = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
            violatorType = possibleViolatorTypes[0];
            newState.violationTypeIds = values;
            newState.possibleViolatorTypes = possibleViolatorTypes;
            newState.violatorType = violatorType;
        }
        this.setState(newState, () => {
            if (this.props.onValuechanged && previousSelectedOption !== this.state.selectedOption) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };

    handleOnAttachmentChanged = (attachments) => {
        this.setState({ attachments: attachments }, () => {
            if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(this.getCurrentValObject());
        });
    };

    handleOnRemarksChanged = (newRemarks) => {
        this.setState({ remarks: newRemarks }, () => {
            if (this.props.onRemarksChanged) this.props.onRemarksChanged(this.getCurrentValObject());
        });
    };
    render() {
        const question = this.props.question || 'Unknown question';
        //const selectedOption = this.props.val ? props.val.selectedOption : undefined;
        //const code = this.props.code;
        const { selectedOption, attachments, remarks, possibleViolatorTypes } = this.state;
        const { editable, inspTypeCheckItemId } = this.props;
        const currentLawClauses = inspectionsHelper.getLawClauseByClauseId(this.props.violationTypeIds[0]);
        let lawdescription = '';
        if (currentLawClauses) {
            lawdescription = localeProperty(currentLawClauses, 'description') || 'Unknown law';
        }

        return (
            <View style={styles.container}>
                <View style={[styles.optionsAndOtherControlsContainer, { minHeight: 83 }]}>
                    {possibleViolatorTypes && possibleViolatorTypes.length > 0
                        ? possibleViolatorTypes.map((violatorType, i) => (
                              <ViolatorIcon
                                  key={violatorType}
                                  violatorType={violatorType}
                                  size={24}
                                  style={{ position: 'absolute', top: -4, right: 30 * i }}
                              />
                          ))
                        : null}
                    <View
                        style={[
                            styles.optionsContainer,
                            styles.labelContainer,
                            { flex: 4, marginLeft: 5, alignItems: 'center', justifyContent: 'flex-start', alignSelf: 'center' },
                        ]}
                    >
                        {this.props.isMandatory ? (
                            <Icon
                                type="MaterialCommunityIcons"
                                name="flag-triangle"
                                style={{ color: '#FF0000', position: 'absolute', top: -16, left: -5 }}
                                size={24}
                            />
                        ) : null}
                        <CheckBoxWithLabel
                            label={lawdescription}
                            value={selectedOption}
                            onValueChange={(val) => this.optionSelected(val)}
                            disabled={!editable}
                            labelStyle={styles.questionText}
                            color={styles.checkbox.color}
                            uncheckedColor={styles.checkbox.color}
                        />
                    </View>
                    <View style={{ flex: 2 }}>
                        <AttachmentAndRemarks
                            inspTypeCheckItemId={inspTypeCheckItemId}
                            editable={editable}
                            attachments={attachments}
                            remarks={remarks}
                            style={styles.attachmentsAndRemarksContainer}
                            onAttachmentChanged={this.handleOnAttachmentChanged}
                            onRemarksChanged={this.handleOnRemarksChanged}
                        />
                    </View>
                </View>
            </View>
        );
    }
}

export default Check;
