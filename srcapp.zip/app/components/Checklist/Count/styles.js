import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        //marginVertical: 10
        //borderWidth: 1
    },
    questionContainer: {
        flex: 1,
        //flexGrow: 3,
        flexDirection: 'row',
        alignSelf: I18nManager.isRTL ? 'flex-start' : 'flex-end',
        justifyContent: I18nManager.isRTL ? 'flex-start' : 'flex-end',
        alignItems: 'center',
        paddingStart: 10,
        marginBottom: 10,
    },
    questionText: {
        flex: 1,
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        // textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    countAndOtherControlsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },

    typePicker: {
        // flex: 1,
    },
    countContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginEnd: 5,
    },
    countButtonContainer: {
        flex: 1,
        borderRadius: 5,
        marginEnd: 5,
    },
    touchWrapper: {
        flex: 1,
    },
    attachmentsAndRemarksContainer: {
        flex: 1,
    },
    numberPicker: { height: 70, width: 70 },

    labelContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        paddingHorizontal: 5,
    },
    actionPeriod: {
        flex: 2,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'center',
        borderWidth: 0.251173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
    },
});
