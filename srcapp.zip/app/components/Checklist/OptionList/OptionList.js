import React, { Component } from 'react';
import { View, Picker } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { _ } from 'lodash';
import { AttachmentAndRemarks, Icon, LawclauseList, ViolatorIcon } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

const initValues = {
    violatorId: null,
    selectedActionTypeConst: null,
    amount: 0,
    selectedPeriod: null,
    selectedActionType: null,
};

class OptionList extends Component {
    constructor(props) {
        super(props);
        const selectedOption = props.val ? props.val.selectedOption : undefined;
        const attachments = props.val ? props.val.attachments : undefined;
        const remarks = props.val ? props.val.remarks : undefined;
        const violationTypeIds = props.val ? [props.val.violationTypeIds[0]] : [];

        let showViolationActions = true;

        this.state = {
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            optionChanged: false,
        };
        this.handleFieldChange = this.handleFieldChange.bind(this);
    }
    getCurrentValObject = () => {
        //Todo: decide where to get the attachments and remarks from? props or state
        const { selectedOption, attachments, remarks, violationTypeIds } = this.state;
        const { val } = this.props;
        let oldValues = {};
        if (val && _.isEqual(_.sortBy(violationTypeIds), _.sortBy(val.violationTypeIds || []))) {
            oldValues = this.props.val;
        }

        if (this.props.val && selectedOption != this.props.val.selectedOption) {
            oldValues = { ...initValues };
        }

        return {
            val: {
                ...oldValues,
                checkItemId: this.props.checkItemId,
                inspTypeCheckItemId: this.props.inspTypeCheckItemId,
                selectedOption,
                attachments,
                remarks,
                violationTypeIds,
            },
        };
    };
    shouldComponentUpdate(nextProps, nextState) {
        return !(this.state.selectedPeriod != nextState.selectedPeriod) && !(this.state === nextState);
        // shallowEqual(this.props, nextProps, this.state, nextState);
    }

    handleLawClausePickerChange = (values, items) => {
        const previousSelectedLawClause = this.state.violationTypeIds;
        //const amount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
        this.setState(
            {
                violationTypeIds: values,
            },
            () => {
                if (this.props.onValuechanged && previousSelectedLawClause !== this.state.violationTypeIds) {
                    this.props.onValuechanged(this.getCurrentValObject());
                }
            }
        );
    };
    handleOnAttachmentChanged = attachments => {
        this.setState({ attachments: attachments }, () => {
            if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(this.getCurrentValObject());
        });
    };

    handleOnRemarksChanged = newRemarks => {
        this.setState({ remarks: newRemarks }, () => {
            if (this.props.onRemarksChanged) this.props.onRemarksChanged(this.getCurrentValObject());
        });
    };
    handleFieldChange = async (name, value) => {
        const violationTypesOptions = inspectionsHelper.getViolationTypeOptions(this.props.violationTypeIds || [], this.props.checkItemId);
        this.handleLawClausePickerChange([value], violationTypesOptions);
    };
    render() {
        const question = this.props.question || 'Unknown question';
        const { selectedOption, attachments, remarks, violationTypeIds, showViolationActions } = this.state;
        const { editable, inspTypeCheckItemId, checkItemId } = this.props;
        const violationTypesOptions = inspectionsHelper.getViolationTypeOptions(this.props.violationTypeIds || [], checkItemId);
        return (
            <View style={styles.container}>
                <View style={styles.questionContainer}>
                    <Text style={styles.questionText}>{question}</Text>
                </View>

                <View style={styles.violationsActionSelectionContainer}>
                    {(violationTypesOptions || []).length > 0 ? (
                        <>
                            <View style={styles.OptionListContainer}>
                                <Picker
                                    selectedValue={(violationTypeIds || []).length > 0 ? violationTypeIds[0] : ''}
                                    key={`rate${(violationTypesOptions || []).length}`}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'impoundVehicleYardId')}
                                >
                                    {(violationTypeIds || []).length == 0 ? (
                                        <Picker.Item key={4422} label={strings('pleaseselect') + ' ' + strings('option')} value={''} />
                                    ) : null}
                                    {(violationTypesOptions || []) &&
                                        (violationTypesOptions || []).map((v, i) => {
                                            return <Picker.Item key={i} label={v.title || 'Unknown Type'} value={v.id} />;
                                        })}
                                </Picker>
                            </View>
                        </>
                    ) : null}
                    <View style={styles.optionsAndOtherControlsContainer}>
                        <AttachmentAndRemarks
                            editable={editable}
                            attachments={attachments}
                            remarks={remarks}
                            inspTypeCheckItemId={inspTypeCheckItemId}
                            style={styles.attachmentsAndRemarksContainer}
                            onAttachmentChanged={this.handleOnAttachmentChanged}
                            onRemarksChanged={this.handleOnRemarksChanged}
                        />
                    </View>
                </View>
            </View>
        );
    }
}

export default OptionList;
