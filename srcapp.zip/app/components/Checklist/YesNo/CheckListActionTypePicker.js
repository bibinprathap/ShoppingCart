import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Picker, View } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Icon } from 'app/components';
import styles from './styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload

class CheckListActionTypePicker extends Component {
    static propTypes = {
        items: PropTypes.any,
    };

    render() {
        const { actionTypeoptions, selectedActionType, editable, handleChangeActions } = this.props;
        if (editable) {
            return (
                <Picker selectedValue={selectedActionType} style={styles.actionPicker} enabled={editable} onValueChange={handleChangeActions}>
                    {actionTypeoptions.map((v, i) => {
                        return <Picker.Item key={i} label={strings(v)} value={v} />;
                    })}
                </Picker>
            );
        } else {
            let iconClass = 'minus-circle-outline';
            let iconColor = '#FF0000';
            switch (selectedActionType) {
                case 'awareness':
                    iconClass = 'information';
                    iconColor = '#3ACCE1';
                    break;
                case 'warning':
                    iconClass = 'alert';
                    iconColor = '#ffc107';
                    break;
                default:
                //unknown type, ignore for now
            }
            return (
                <View
                    style={{
                        flex: 3,
                        marginHorizontal: 10,
                        justifyContent: 'space-between',

                        alignItems: 'flex-end',
                    }}
                >
                    <Icon
                        type="MaterialCommunityIcons"
                        name={iconClass}
                        size={25}
                        style={[
                            styles.icon,
                            {
                                color: iconColor,
                                justifyContent: 'space-between',

                                alignItems: 'flex-end',
                            },
                        ]}
                    />
                </View>
            );
        }
    }
}

export default CheckListActionTypePicker;
