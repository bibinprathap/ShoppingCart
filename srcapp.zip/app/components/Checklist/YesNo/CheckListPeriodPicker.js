import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { Picker, View, Text } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Icon, PeriodPicker } from 'app/components';
import styles from './styles';
//Todo: move it to styles.js when screen is complete. its here for hot-reload

export default memo(function(props) {
    const { periodTypeOptions, selectedPeriodType, editable, selectedPeriod, handlePeriodNumberPickerChange, handleChangePeriodType } = props;
    if (editable) {
        return (
            <PeriodPicker
                periodTypeOptions={periodTypeOptions}
                selectedPeriodType={selectedPeriodType}
                selectedPeriod={selectedPeriod}
                editable={true}
                handlePeriodNumberPickerChange={handlePeriodNumberPickerChange}
                handleChangePeriodType={handleChangePeriodType}
            />
        );
    } else {
        return (
            <View style={styles.violationAmountContainer}>
                <Icon type="MaterialCommunityIcons" name="clock-outline" size={25} style={styles.icon} />
                {selectedPeriodType == 'day' || selectedPeriodType == 'hour' ? (
                    <Text style={styles.pickerViolationAmount}>{selectedPeriod + ' ' + strings(selectedPeriodType)}</Text>
                ) : null}
            </View>
        );
    }
});
