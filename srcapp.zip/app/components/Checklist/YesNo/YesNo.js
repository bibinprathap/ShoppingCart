import React, { Component } from 'react';
import { View } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import { _ } from 'lodash';
import { AttachmentAndRemarks, Icon, LawclauseList, ViolatorIcon } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';

const initValues = {
    violatorId: null,
    selectedActionTypeConst: null,
    amount: 0,
    selectedPeriod: null,
    selectedActionType: null,
};

class YesNo extends Component {
    constructor(props) {
        super(props);
        const selectedOption = props.val ? props.val.selectedOption : undefined;
        const attachments = props.val ? props.val.attachments : undefined;
        const remarks = props.val ? props.val.remarks : undefined;
        const violationTypeIds = props.val ? [props.val.violationTypeIds[0]] : [];
        const possibleViolatorTypes = props.val && props.val.possibleViolatorTypes ? props.val.possibleViolatorTypes : null;
        const violatorType = props.val && props.val.violatorType ? props.val.violatorType : null;

        let showViolationActions = false;
        if (!props.showAllCheckItem && selectedOption == 'no') {
            showViolationActions = true;
        }
        this.state = {
            showViolationActions,
            selectedOption,
            attachments,
            remarks,
            violationTypeIds,
            possibleViolatorTypes,
            violatorType,
            optionChanged: false,
        };
    }
    getCurrentValObject = () => {
        //Todo: decide where to get the attachments and remarks from? props or state
        const { selectedOption, attachments, remarks, violationTypeIds, possibleViolatorTypes, violatorType } = this.state;
        const { val } = this.props;
        let oldValues = {};
        if (val && _.isEqual(_.sortBy(violationTypeIds), _.sortBy(val.violationTypeIds || []))) {
            oldValues = this.props.val;
        }

        if (this.props.val && selectedOption != this.props.val.selectedOption) {
            oldValues = { ...initValues };
        }

        return {
            val: {
                ...oldValues,
                checkItemId: this.props.checkItemId,
                inspTypeCheckItemId: this.props.inspTypeCheckItemId,
                selectedOption,
                attachments,
                remarks,
                violationTypeIds,
                possibleViolatorTypes,
                violatorType,
            },
        };
    };
    shouldComponentUpdate(nextProps, nextState) {
        return !(this.state.selectedPeriod != nextState.selectedPeriod) && !(this.state === nextState);
        // shallowEqual(this.props, nextProps, this.state, nextState);
    }
    optionSelected = (option) => {
        const previousSelectedOption = this.state.selectedOption;
        let newState = { selectedOption: option, showViolationActions: option === 'no' };
        if (option.toLowerCase() === 'yes' || option.toLowerCase() === 'na') {
            newState = { ...initValues, ...newState };
            newState.violationTypeIds = [];
            newState.possibleViolatorTypes = null;
            newState.violatorType = null;
        } else if (option.toLowerCase() === 'no') {
            const { violationTypeIds, checkItemId } = this.props;
            if (violationTypeIds.length == 0) {
                newState = { ...initValues, ...{ selectedOption: option, showViolationActions: false } };
                newState.violationTypeIds = [];
                newState.possibleViolatorTypes = null;
                newState.violatorType = null;
            } else {
                let values = [];
                let possibleViolatorTypes = null;
                let violatorType = null;
                const items = inspectionsHelper.getViolationTypeOptions(violationTypeIds, checkItemId);
                values = [items.map((I) => I.id)[0]];
                //amount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
                possibleViolatorTypes = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
                violatorType = possibleViolatorTypes[0];
                newState.violationTypeIds = values;
                newState.possibleViolatorTypes = possibleViolatorTypes;
                newState.violatorType = violatorType;
            }
        }
        this.setState(newState, () => {
            if (this.props.onValuechanged && previousSelectedOption !== this.state.selectedOption) {
                this.props.onValuechanged(this.getCurrentValObject());
            }
        });
    };
    handleLawClausePickerChange = (values, items) => {
        const previousSelectedLawClause = this.state.violationTypeIds;
        //const amount = inspectionsHelper.getViolationAmount({ lawClauseIDs: values, occurance: 1, discount: 0 });
        const possibleViolatorTypes = inspectionsHelper.getViolatorType({ violationTypeIDs: values });
        const violatorType = possibleViolatorTypes[0];
        this.setState(
            {
                violationTypeIds: values,
                possibleViolatorTypes: possibleViolatorTypes,
                violatorType,
            },
            () => {
                if (this.props.onValuechanged && previousSelectedLawClause !== this.state.violationTypeIds) {
                    this.props.onValuechanged(this.getCurrentValObject());
                }
            }
        );
    };
    handleOnAttachmentChanged = (attachments) => {
        this.setState({ attachments: attachments }, () => {
            if (this.props.onAttachmentChanged) this.props.onAttachmentChanged(this.getCurrentValObject());
        });
    };

    handleOnRemarksChanged = (newRemarks) => {
        this.setState({ remarks: newRemarks }, () => {
            if (this.props.onRemarksChanged) this.props.onRemarksChanged(this.getCurrentValObject());
        });
    };
    render() {
        const question = this.props.question || 'Unknown question';
        const { selectedOption, attachments, remarks, violationTypeIds, possibleViolatorTypes, showViolationActions } = this.state;
        const { editable, inspTypeCheckItemId, checkItemId, hasNA } = this.props;
        const violationTypesOptions = inspectionsHelper.getViolationTypeOptions(this.props.violationTypeIds, checkItemId);
        const newSelectedOption = (selectedOption || '').toLowerCase();
        return (
            <View style={styles.container}>
                <View style={styles.questionContainer}>
                    <Text style={styles.questionText}>{question}</Text>
                    {possibleViolatorTypes && possibleViolatorTypes.length > 0
                        ? possibleViolatorTypes.map((violatorType) => <ViolatorIcon key={violatorType} violatorType={violatorType} size={24} />)
                        : null}
                </View>
                <View style={styles.optionsAndOtherControlsContainer}>
                    <View style={styles.optionsContainer}>
                        {this.props.isMandatory ? (
                            <Icon type="MaterialCommunityIcons" name="flag-triangle" style={{ color: '#FF0000' }} size={24} />
                        ) : null}
                        <View style={styles.optionButtonContainer}>
                            <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('yes')} style={styles.touchWrapper}>
                                <Text
                                    style={[
                                        styles.optionButton,
                                        newSelectedOption === 'yes' ? [styles.optionButtonSelected, styles.optionButtonSelectedYes] : null,
                                    ]}
                                    numberOfLines={1}
                                >
                                    {strings('yes')}
                                </Text>
                            </TouchableRipple>
                        </View>
                        <View style={styles.optionButtonContainer}>
                            <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('no')} style={styles.touchWrapper}>
                                <Text
                                    style={[
                                        styles.optionButton,
                                        newSelectedOption === 'no' ? [styles.optionButtonSelected, styles.optionButtonSelectedNo] : null,
                                    ]}
                                    numberOfLines={1}
                                >
                                    {strings('no')}
                                </Text>
                            </TouchableRipple>
                        </View>
                        {hasNA && (
                            <View style={styles.optionButtonContainer}>
                                <TouchableRipple disabled={!editable} onPress={() => this.optionSelected('na')} style={styles.touchWrapper}>
                                    <Text
                                        style={[
                                            styles.optionButton,
                                            newSelectedOption === 'na' ? [styles.optionButtonSelected, styles.optionButtonSelectedNa] : null,
                                        ]}
                                        numberOfLines={1}
                                    >
                                        {strings('notApplicable')}
                                    </Text>
                                </TouchableRipple>
                            </View>
                        )}
                    </View>
                    <AttachmentAndRemarks
                        editable={editable}
                        attachments={attachments}
                        remarks={remarks}
                        inspTypeCheckItemId={inspTypeCheckItemId}
                        style={styles.attachmentsAndRemarksContainer}
                        onAttachmentChanged={this.handleOnAttachmentChanged}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                </View>
                {showViolationActions && (violationTypesOptions || []).length > 0 ? (
                    <View style={styles.violationsActionSelectionContainer}>
                        <View style={styles.questionContainer}>
                            <LawclauseList
                                multiSelect={false}
                                editable={(violationTypesOptions || []).length == 1 ? false : editable}
                                violationTypeIds={violationTypesOptions || []}
                                selectedItems={violationTypeIds || []}
                                onValueChange={(itemValue) => this.handleLawClausePickerChange(itemValue, violationTypesOptions)}
                            />
                        </View>
                    </View>
                ) : null}
            </View>
        );
    }
}

export default YesNo;
