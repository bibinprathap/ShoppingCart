import React from 'react';
import { View, Text, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import { Icon } from 'app/components';
import { I18nManager } from 'react-native';
const isRTL = I18nManager.isRTL;

import EStyleSheet from 'react-native-extended-stylesheet';
const styles = EStyleSheet.create({
    content: {
        flexDirection: 'row',
        alignItems: 'center',
        flexWrap: 'wrap',
        backgroundColor: '$chipBackground',
        borderRadius: 16,
        marginRight: 10,
        marginBottom: 5,
        paddingVertical: 4,
        paddingHorizontal: 8,
        borderWidth: 1,
        borderColor: '$primaryLightBorder',
    },
    chipTextStyle: {
        fontSize: '$primaryTextXS',
        fontFamily: '$primaryFontHeading',
        color: '$primaryDarkTextColor',
        paddingRight: isRTL ? 0 : 14,
        paddingLeft: isRTL ? 14 : 0,
    },
    iconButtons: {
        position: 'absolute',
        right: 2,
    },
});

export default ({ children, onPress, editable, onClose, multiSelect }) => {
    return (
        <TouchableOpacity onPress={onPress || null} disabled={!editable}>
            <View style={styles.content}>
                <Text style={styles.chipTextStyle} numberOfLines={1}>
                    {children || null}
                </Text>
                <View style={styles.iconButtons}>
                    {editable && onPress && !multiSelect && <Icon type="MaterialCommunityIcons" name="chevron-down" size={24} />}
                    {editable && onClose && multiSelect && (
                        <TouchableWithoutFeedback onPress={() => onClose()}>
                            <Icon type="MaterialCommunityIcons" name="close-circle" size={20} />
                        </TouchableWithoutFeedback>
                    )}
                </View>
            </View>
        </TouchableOpacity>
    );
};
