import styles from './styles';
import CustomAccordion from './CustomAccordionSimple';

export { styles, CustomAccordion };
