import React from 'react';
import { Text, View, ActivityIndicator } from 'react-native';
import { Agenda } from 'react-native-calendars';
import moment from 'moment';
import _ from 'lodash';
import EStyleSheet from 'react-native-extended-stylesheet';
import AppApi from 'app/api/real';
import { strings, localeProperty } from 'app/config/i18n/i18n';
const api = new AppApi();

class DashboardCalendarView extends React.PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            newInspectionObject: {},
            newTaskObject: {},
            inspectionItems: {},
            taskItems: {},
        };
    }

    render() {
        const { sourceType } = this.props;
        const { newInspectionObject, newTaskObject, taskItems, inspectionItems } = this.state;
        let newDaysObject;
        let items;
        let pastScrollRange;
        let futureScrollRange;
        let maxDate;

        let minDate;
        if (sourceType === 'history') {
            newDaysObject = newInspectionObject;
            items = inspectionItems;
            pastScrollRange = 3;
            futureScrollRange = 1;
            maxDate = new Date();
            minDate = moment(new Date())
                .subtract(3, 'month')
                .endOf('day')
                .format('YYYY-MM-DD');
        } else {
            newDaysObject = newTaskObject;
            items = taskItems;
            pastScrollRange = 1;
            futureScrollRange = 3;
            minDate = new Date();
            maxDate = moment(new Date())
                .add(3, 'month')
                .endOf('day')
                .format('YYYY-MM-DD');
        }
        return (
            <Agenda
                items={items}
                loadItemsForMonth={this.loadItems.bind(this)}
                onDayPress={this.onDayPress.bind(this)}
                selected={new Date()}
                renderItem={this.renderItem}
                renderEmptyData={this.renderEmptyData.bind(this)}
                rowHasChanged={this.rowHasChanged.bind(this)}
                //dayLoading={true}
                topDay={new Date()}
                pastScrollRange={pastScrollRange}
                futureScrollRange={futureScrollRange}
                markingType={'custom'}
                markedDates={newDaysObject}
                maxDate={maxDate}
                minDate={minDate}
                hideKnob={false}
                theme={{
                    'stylesheet.calendar.header': { week: { marginTop: 2, flexDirection: 'row', justifyContent: 'space-between' } },
                }}
            />
        );
    }

    loadItems(day) {
        const nextDays = [];
        const { calendarViewData, sourceType } = this.props;
        calendarViewData.forEach(key => {
            nextDays.push(moment(key.date).format('YYYY-MM-DD'));
        });

        const newDaysObject = {};

        nextDays.forEach(date => {
            newDaysObject[date] = {
                customStyles: {
                    container: {
                        borderWidth: 2,
                        borderColor: '#E65044',
                        justifyContent: 'center',
                        borderRadius: 17,
                    },
                    text: {
                        marginTop: 0,
                        fontWeight: 'bold',
                    },
                },
            };
        });
        sourceType === 'history'
            ? this.setState({
                  newInspectionObject: newDaysObject,
              })
            : this.setState({
                  newTaskObject: newDaysObject,
              });
    }

    onDayPress = async day => {
        dateSelected = day.dateString;

        startDate = moment(dateSelected)
            .startOf('day')
            .format('YYYY-MM-DD HH:mm:ss');
        endDate = moment(dateSelected)
            .endOf('day')
            .format('YYYY-MM-DD HH:mm:ss');
        const sourceType = this.props.sourceType;
        try {
            const result =
                sourceType === 'history'
                    ? await api.searchInspection({ startDate: startDate, endDate: endDate, pageSize: 100, pageNumber: 0 })
                    : await api.searchInspectionTask({ startDate: startDate, endDate: endDate, pageSize: 100, pageNumber: 0 });

            const calendarData = sourceType === 'history' ? result.inspectionVModel : result.taskVModel;

            const historyContent = [];
            if (calendarData.length < 1 || calendarData == undefined) {
                historyContent.push({ itemDateOnly: moment(dateSelected).format('YYYY-MM-DD') });
            } else {
                calendarData.forEach(item => {
                    const handleItemOnPress = () => this.handleItemOnPress(item);
                    historyContent.push(
                        sourceType === 'history'
                            ? {
                                  itemDate: moment(item.createdDate).format('YYYY-MM-DD HH:mm:ss'),
                                  itemDateOnly: moment(item.createdDate).format('YYYY-MM-DD'),
                                  statusCode: item.inspectionStatusE,
                                  translatedStatus: localeProperty(item, 'inspectionStatus'),
                                  location: item.location,
                                  icon: item.inspectionTypeDetail.icon,
                                  applicationNumber: item.applicationNumber,
                                  title: localeProperty(item.inspectionTypeDetail, 'title'),
                                  description: localeProperty(item.inspectionTypeDetail, 'serviceDesc'),
                                  onPress: handleItemOnPress,
                              }
                            : {
                                  itemDate: moment(item.expectedStartDate).format('YYYY-MM-DD HH:mm:ss'),
                                  itemDateOnly: moment(item.expectedStartDate).format('YYYY-MM-DD'),
                                  statusCode: item.status,
                                  //translatedStatus: localeProperty(item, 'status'),
                                  location: item.location,
                                  icon: item.icon,
                                  applicationNumber: item.applicationNumber,
                                  title: localeProperty(item.inspectionTypeDetail, 'title'),
                                  description: localeProperty(item, 'title'),
                                  onPress: handleItemOnPress,
                              }
                    );
                });
            }

            (groups = ['itemDateOnly']),
                (grouped = historyContent.reduce((r, o) => {
                    // groups.reduce((group, key, i, { length }) => group[o[key]]);
                    groups.reduce((group, key, i, { length }) => (group[o[key]] = group[o[key]] || (i + 1 === length ? [] : {})), r).push(o);

                    return r;
                }, {}));

            sourceType === 'history'
                ? this.setState({
                      inspectionItems: grouped,
                  })
                : this.setState({
                      taskItems: grouped,
                  });
        } catch (error) {}
    };

    handleItemOnPress = item => {
        const { onItemPress } = this.props;
        if (typeof onItemPress === 'function') onItemPress(item);
    };

    renderItem(item) {
        if (item.location === undefined) {
            return (
                <View style={styles.noItemsContainer}>
                    <Text style={styles.itemMediumText}>{strings('noRecordsToDisplay')}</Text>
                </View>
            );
        } else {
            return <Text>work in progress</Text>;
            //return <TabbedListViewItem item={item} />;
        }
    }

    renderEmptyData() {
        const { sourceType } = this.props;
        const loadingItems =
            (sourceType === 'history' && this.state.inspectionItems === null) || (sourceType === 'tasks' && this.state.taskItems === null) ? (
                <View style={styles.noItemsContainer}>
                    <Text style={styles.itemMediumText}>Select Date to display</Text>
                </View>
            ) : (
                <View style={{ alignItems: 'center', justifyContent: 'center', margin: 20 }}>
                    <ActivityIndicator />
                </View>
            );

        return (
            <View style={styles.emptyItem}>
                <View style={styles.noItemsContainer}>
                    <Text style={styles.itemMediumText}>{strings('selectDateToViewRecords')}</Text>
                </View>
            </View>
        );
    }
    rowHasChanged(r1, r2) {
        return r1.name !== r2.name;
    }

    timeToString(time) {
        const date = new Date(time);
        return date.toISOString().split('T')[0];
    }
}

export default DashboardCalendarView;

const styles = EStyleSheet.create({
    itemContainer: {
        marginHorizontal: 5,
        marginVertical: 10,
        justifyContent: 'flex-end',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },

    noItemsContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },
});
