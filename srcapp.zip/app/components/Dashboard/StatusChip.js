import React from 'react';
import { strings } from 'app/config/i18n/i18n';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { getColor } from 'app/api/helperServices/utils';
import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

const StatusChip = props => {
    const { statusConst = '', translatedStatus, overdueHours } = props;
    const lowerCaseStatusConst = statusConst.toLowerCase();
    const styles = createStyleSheet(lowerCaseStatusConst);
    let extraInfo;
    if (lowerCaseStatusConst === 'overdue') {
        const overdueDays = overdueHours > 0 ? Math.trunc(overdueHours / 24) : 0;
        const overdueUnit = overdueHours < 1 ? '' : overdueHours <= 1 ? 'hour' : overdueHours < 24 ? 'hours' : overdueHours >= 48 ? 'days' : 'day';
        //console.log('overdueHours: ', overdueHours, 'overdueDays: ', overdueDays, 'overdueUnit: ', overdueUnit);
        extraInfo = `${overdueDays || overdueHours} ${strings(overdueUnit)}`;
    }
    return (
        <View style={styles.container}>
            <Text style={styles.textSmall} numberOfLines={1}>
                {translatedStatus ? translatedStatus : strings(lowerCaseStatusConst)}
            </Text>
            {extraInfo && (
                <Text style={styles.textSmaller} numberOfLines={1}>
                    {extraInfo}
                </Text>
            )}
        </View>
    );
};
export default StatusChip;

function createStyleSheet(statusConst) {
    return EStyleSheet.create({
        container: {
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 10,
            height: 30,
            maxWidth: 120,
            minWidth: 80,
            backgroundColor: getColor(statusConst, false),
            //marginHorizontal: 15,
        },
        textSmall: {
            fontSize: '$primaryTextXXS',
            color: '$primaryWhite',
            paddingHorizontal: 5,
            alignSelf: 'center',
            //textAlign: I18nManager.isRTL ? 'right' : 'left',
            textAlign: 'center',
            textAlignVertical: 'center',
        },
        textSmaller: {
            fontSize: '$primaryTextXXXS',
            color: '$primaryWhite',
            paddingHorizontal: 5,
            alignSelf: 'center',
            //textAlign: I18nManager.isRTL ? 'right' : 'left',
            textAlign: 'center',
            textAlignVertical: 'center',
        },
    });
}
