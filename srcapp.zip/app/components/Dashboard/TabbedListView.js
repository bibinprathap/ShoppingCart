import React, { Component, memo } from 'react';
import { View, TouchableOpacity, I18nManager, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { SearchResultListView, Icon } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { TabView } from 'react-native-tab-view';
import Animated from 'react-native-reanimated';

const RenderTabContent = memo((props) => {
    const { itemKey, sourceType, tabbedListViewData = {}, onItemPress, onLoadNextPage, onRefresh, refreshing } = props;
    const selectedTabData = tabbedListViewData && tabbedListViewData[itemKey];
    if (!selectedTabData) return null;
    let hasError = !!selectedTabData.error;
    if (hasError) {
        return (
            <View style={styles.errorContainer}>
                <Text style={[styles.itemSmallText, styles.errorText]}>{selectedTabData.error}</Text>
            </View>
        );
    }
    const { items, loading } = selectedTabData;
    return (
        <SearchResultListView
            sourceType={sourceType}
            items={items}
            loading={loading}
            onItemPress={onItemPress}
            onLoadNextPage={onLoadNextPage}
            onRefresh={onRefresh}
            refreshing={refreshing}
        />
    );
});

const RenderTabBar = memo((props) => {
    const { tabbedListViewData = {}, selectedTab } = props;
    const inputRange = props.navigationState.routes.map((x, i) => i);
    const primaryBorderThin = EStyleSheet.value('$primaryBorderThin');
    const primarySelectedTextColor = EStyleSheet.value('$primarySelectedTextColor');
    const primaryIndicatorColor = EStyleSheet.value('$primaryIndicatorColor');
    const primaryBorderColor = EStyleSheet.value('$primaryBorderColor');
    return (
        <View style={styles.headersContainer}>
            <ScrollView horizontal={true} contentContainerStyle={styles.scrollInner} showsHorizontalScrollIndicator={false}>
                {props.navigationState.routes.map((route, index) => {
                    const key = route.key;
                    const selected = key === selectedTab;
                    const selectedTabData = tabbedListViewData[key];
                    const { totalCount = 0, items, isOrderByDesc } = selectedTabData || {};
                    const sortOrderIcon = !isOrderByDesc ? 'sort-ascending' : 'sort-descending';
                    const formattedCount = items ? `(${totalCount})` : '(?)';

                    const borderBottomColor = selected ? primaryIndicatorColor : primaryBorderColor;

                    const activeOpacity = Animated.interpolate(props.position, {
                        inputRange,
                        outputRange: inputRange.map((i) => (i === index ? 1 : 0)),
                    });
                    const inactiveOpacity = Animated.interpolate(props.position, {
                        inputRange,
                        outputRange: inputRange.map((i) => (i === index ? 0 : 1)),
                    });

                    return (
                        <Animated.View style={[styles.headerItemContainer, { borderBottomColor }]} key={`${key}_${index}`}>
                            <TouchableOpacity onPress={() => props.handleHeaderItemPress(key)} style={styles.tabNameWrapper}>
                                <View style={styles.tabNameAndCount}>
                                    <Animated.Text style={[styles.headerItemText, { opacity: inactiveOpacity }]}>{strings(key)}</Animated.Text>
                                    <Animated.Text
                                        style={[
                                            styles.headerItemText,
                                            styles.activeItem,
                                            { color: primarySelectedTextColor, opacity: activeOpacity },
                                        ]}
                                    >
                                        {strings(key)}
                                    </Animated.Text>
                                    <Animated.View style={[styles.headerItemTextSmallWrapper, { opacity: inactiveOpacity }]}>
                                        <Text style={[styles.headerItemTextSmall]}>{formattedCount}</Text>
                                    </Animated.View>
                                    <Animated.View style={[styles.headerItemTextSmallWrapper, styles.activeItem, { opacity: activeOpacity }]}>
                                        <Text style={[styles.headerItemTextSmall, { color: primarySelectedTextColor }]}>{formattedCount}</Text>
                                    </Animated.View>
                                </View>
                                <View style={styles.sortIconWrapper}>
                                    <Animated.View style={[styles.item, { opacity: inactiveOpacity }]}>
                                        <Icon type="MaterialCommunityIcons" name={sortOrderIcon} size={18} color={styles.headerItemText.color} />
                                    </Animated.View>
                                    <Animated.View style={[styles.item, styles.activeItem, { opacity: activeOpacity }]}>
                                        <Icon type="MaterialCommunityIcons" name={sortOrderIcon} size={18} color={primarySelectedTextColor} />
                                    </Animated.View>
                                </View>
                            </TouchableOpacity>
                            <Animated.View
                                style={{
                                    elevation: 2,
                                    position: 'absolute',
                                    bottom: 0,
                                    width: '100%',
                                    backgroundColor: primaryIndicatorColor,
                                    height: primaryBorderThin,
                                    opacity: activeOpacity,
                                }}
                            />
                        </Animated.View>
                    );
                })}
            </ScrollView>
        </View>
    );
});

class TabbedListView extends Component {
    constructor(props) {
        super(props);
        const { selectedTab } = props;
        if (typeof selectedTab === 'undefined') {
            selectedTab = this.getFirstTabKey();
            this.handleOnSelectedTabChanged(selectedTab);
        }
        this.borderWidth = new Animated.Value(1);
    }

    componentDidMount = () => {
        this.checkSelectedTabData(true);
    };

    componentDidUpdate = () => {
        this.checkSelectedTabData();
    };

    getSortedTabKeys = (tabbedListViewData) => {
        if (tabbedListViewData) {
            const keys = [];
            Object.keys(tabbedListViewData).map((key) => {
                if (tabbedListViewData.hasOwnProperty(key)) {
                    keys.push({ key, order: tabbedListViewData[key].order || 0 });
                }
            });
            const sortedKeys = _.sortBy(keys, function (item) {
                return item.order;
            });
            return sortedKeys.map((item) => item.key);
        } else return [];
    };

    getFirstTabKey = () => {
        const { tabbedListViewData = {} } = props;
        const sortedKeys = this.getSortedTabKeys(tabbedListViewData);
        return sortedKeys && sortedKeys.length > 0 ? sortedKeys[0] : undefined;
    };

    handleOnSelectedTabChanged = (selectedTab) => {
        const { onSelectedTabChanged } = this.props;
        if (typeof onSelectedTabChanged === 'function') onSelectedTabChanged(selectedTab);
    };
    checkSelectedTabData = (forceLoad = false) => {
        const { tabbedListViewData, loadTabData, selectedTab } = this.props;
        if (forceLoad) {
            loadTabData({ reset: true });
            return;
        }
        const selectedTabData = tabbedListViewData[selectedTab];
        if (typeof selectedTabData === 'undefined') {
            //previous selected tab may not be valid when source is changed, having different tabs
            selectedTab = this.getFirstTabKey();
            if (selectedTab) {
                this.handleOnSelectedTabChanged(selectedTab);
            }
        } else {
            if (
                selectedTabData.hasPendingRefresh == true ||
                (typeof selectedTabData.items === 'undefined' && selectedTabData.loading !== true && !selectedTabData.error)
            ) {
                if (typeof loadTabData === 'function') {
                    loadTabData({ reset: true });
                }
            } else {
                return; //nothing to do, there is no tab
            }
        }
    };

    handleHeaderItemPress = (key) => {
        const { selectedTab, onSortOrderChanged } = this.props;
        if (selectedTab === key && typeof onSortOrderChanged === 'function') {
            onSortOrderChanged();
        } else {
            this.handleOnSelectedTabChanged(key);
        }
    };

    handleIndexChange = (index, navState) => {
        const { routes } = navState;
        if (routes && routes[index]) {
            const { selectedTab, onSortOrderChanged } = this.props;
            const key = routes[index].key;
            if (selectedTab === key) {
                if (typeof onSortOrderChanged === 'function') onSortOrderChanged();
            } else {
                this.handleOnSelectedTabChanged(key);
            }
        }
    };

    getNavState = () => {
        const { selectedTab, tabbedListViewData = {} } = this.props;
        const sortedKeys = this.getSortedTabKeys(tabbedListViewData);
        let index = 0;
        const routes = sortedKeys.map((key, idx) => {
            index = selectedTab == key ? idx : index;
            return { key: key, title: key };
        });
        return { index, routes };
    };

    renderScene = ({ route }) => {
        return <RenderTabContent itemKey={route.key} {...this.props} />;
    };

    render() {
        const { selectedTab } = this.props;
        if (typeof selectedTab === 'undefined') return;
        const navState = this.getNavState();
        return (
            <View style={styles.container}>
                <TabView
                    navigationState={navState}
                    renderScene={this.renderScene}
                    renderTabBar={(props) => (
                        <RenderTabBar
                            handleHeaderItemPress={this.handleHeaderItemPress}
                            {...props}
                            tabbedListViewData={this.props.tabbedListViewData}
                            selectedTab={this.props.selectedTab}
                        />
                    )}
                    onIndexChange={(index) => this.handleIndexChange(index, navState)}
                />
            </View>
        );
    }
}

export default TabbedListView;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        overflow: 'hidden',
    },
    headersContainer: {
        minHeight: 40,
        maxHeight: 40,
        paddingBottom: 1,
        overflow: 'hidden',
    },
    scrollInner: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        flexGrow: 1,
    },
    errorContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        margin: 20,
    },
    itemSmallText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
    errorText: {
        color: '$primaryErrorTextColor',
        textAlign: 'center',
    },
    headerItemContainer: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        backgroundColor: '$primaryWhite',
        justifyContent: 'center',
    },
    headerItemContainerSelected: {
        borderBottomColor: '$primaryIndicatorColor',
        borderBottomWidth: '$primaryBorderThick',
    },
    headerItemText: {
        flex: 1,
        color: '$primaryMediumTextColor',
        fontSize: I18nManager.isRTL ? '$primaryTextXS' : '$primaryTextSM',
        textAlignVertical: 'center',
    },
    headerItemTextSmallWrapper: {
        minWidth: 30,
        justifyContent: 'center',
        paddingHorizontal: 3,
        alignItems: 'flex-end',
    },
    headerItemTextSmall: {
        color: '$primaryMediumTextColor',
        fontSize: '$primaryTextXXS',
    },
    tabNameWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 5,
    },
    tabNameAndCount: {
        flex: 1,
        height: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    item: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    activeItem: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
    },
    sortIconWrapper: {
        width: 20,
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
