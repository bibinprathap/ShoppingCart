import React, { Component } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import { ADMGISMapView, HeaderGeneric, Modal, StatusChip } from 'app/components';
import { TaskDetailsDialog } from 'app/screens';
import { getIconUnicode } from 'app/api/helperServices/utils';
import { inspectionsHelper, tasksHelper } from 'app/api/helperServices';
import AppApi from 'app/api/real';
import EStyleSheet from 'react-native-extended-stylesheet';
import { shallowEqual } from 'app/api/helperServices';
const api = new AppApi();
export default class TasksMapView extends Component {
    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    handleOnSingleTap = points => {
        if (points && points !== null) {
            if (points.sourceType == 'tasks' || points.sourceType == 'history') {
                return true; //we want to show callout
            }
        }
        return false; //no callout needed
    };

    handlePress = callOutData => {
        //  console.log('handlePress callout TaskMapView', callOutData);

        if (typeof callOutData.taskId !== 'undefined' && callOutData.taskId != null) {
            const itemObj = { taskId: callOutData.taskId };
            tasksHelper.selectTask(itemObj, this.props.navigation);
        }
    };
    handleRenderCallout = callOutData => {
        //console.log('handleRenderCallout', callOutData);
        if (typeof callOutData === 'undefined') return null;
        if (callOutData.sourceType == 'tasks') {
            let heading = callOutData.taskId ? callOutData.title + ' - ' + callOutData.taskId : null;
            return (
                <View style={styles.viewContainer}>
                    <TouchableOpacity onPress={() => this.handlePress(callOutData)} style={styles.container}>
                        {heading && <Text style={styles.itemMediumText}>{heading}</Text>}
                        {callOutData.appNumber && <Text style={styles.itemSmallText}>App No - {callOutData.appNumber}</Text>}
                        {callOutData.serviceDesc && <Text style={styles.itemSmallText}>{callOutData.serviceDesc}</Text>}
                        {callOutData.inspectionStatus && <StatusChip statusConst={callOutData.inspectionStatus} />}
                    </TouchableOpacity>
                    <TaskDetailsDialog />
                </View>
            );
        } else if (callOutData.sourceType == 'history') {
            let heading = callOutData.appNumber ? callOutData.title + ' - ' + callOutData.appNumber : null;
            return (
                <View style={styles.viewContainer}>
                    <TouchableOpacity style={styles.container}>
                        {heading && <Text style={styles.itemMediumText}>{heading}</Text>}
                        {callOutData.serviceDesc && <Text style={styles.itemSmallText}>{callOutData.serviceDesc}</Text>}
                        {callOutData.inspectionStatus && <StatusChip statusConst={callOutData.inspectionStatus} />}
                    </TouchableOpacity>
                </View>
            );
        } else {
            return (
                <View style={styles.viewContainer}>
                    <Text>This is unknown callout</Text>
                </View>
            );
        }
    };
    render() {
        const { isShowing, tasksData, sourceType } = this.props;
        //const { layout, showCallOut, callOutData } = this.state;
        const dailogTitle = sourceType == 'tasks' ? strings('tasksMapView') : strings('historyMapView');
        if (!isShowing) return null;
        else {
            let coordsData = [];

            if (typeof tasksData !== 'undefined') {
                tasksData.map(item => {
                    const icon = sourceType == 'tasks' ? item.icon : item.inspectionTypeDetail.icon;
                    if (typeof item.location !== 'undefined' && typeof icon !== 'undefined') {
                        const code = getIconUnicode(
                            sourceType == 'tasks' ? item.icon.type : item.inspectionTypeDetail.icon.type,
                            sourceType == 'tasks' ? item.icon.name : item.inspectionTypeDetail.icon.name
                        );
                        const newTaskData = {
                            referenceId: sourceType == 'tasks' ? item.taskId.toString() : item.applicationNumber.toString(),
                            latitude: item.location.coords.latitude,
                            longitude: item.location.coords.longitude,
                            graphicId: sourceType == 'tasks' ? item.icon.name : item.inspectionTypeDetail.icon.name,
                            graphicType: sourceType == 'tasks' ? item.icon.type : item.inspectionTypeDetail.icon.type,
                            graphicUnicode: code,
                            rotation: 0,
                            attributes: {
                                inspectionStatus: sourceType == 'tasks' ? item.taskStatusConst : item.inspectionStatusConst,
                                sourceType: sourceType,
                                // inspectionStatus: 'In Progress',
                                title: item.inspectionTypeDetail.titleE,
                                serviceDesc: item.inspectionTypeDetail.serviceDescE,
                            },
                        };
                        if (item.applicationNumber) newTaskData.attributes.appNumber = item.applicationNumber;
                        if (item.taskId) newTaskData.attributes.taskId = item.taskId.toString();
                        coordsData.push(newTaskData);
                    }
                });
            }
            const taskMapData = {
                referenceId: 'MapRoutes',
                enableRoute: false,
                points: coordsData,
            };

            console.log('taskMapData', taskMapData);
            return (
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric backAction={this.handleOnRequestClose} title={dailogTitle} />
                    <ADMGISMapView
                        routeData={taskMapData}
                        showMenu={true}
                        onSingleTap={this.handleOnSingleTap}
                        renderCallout={this.handleRenderCallout}
                    />
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({
    viewContainer: {
        flex: 1,
        alignItems: 'center',
    },
    container: {
        flex: 1,
        paddingTop: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    itemSmallText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryMediumTextColor',
    },
});
