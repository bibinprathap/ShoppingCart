import BarChart from './BarChart';

export { BarChart };
