import React, { Component } from 'react';
import { View, Image } from 'react-native';
//import ArcGISMapView from 'ThirdPartyModuleJS/AGSMapView';
import ADMGISMapView from '../ADMGISMapView/ADMGISMapView';
import styles from './styles';
class DashboardMapView extends Component {
    defaultPointGraphics = [
        { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
        { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    ];
    render() {
        const { inspection } = this.props;

        const coords = inspection.location.coords;
        const pointGraphics = this.defaultPointGraphics;



        const placeMarkData = coords && [
            {
                ...coords,
                rotation: 0,
                referenceId: 'selectedLocation',
                graphicId: 'personPoint',
            },
        ];
        return (
            <View style={[styles.smallmapItem]}>
                {/* <ArcGISMapView
                    ref={mapView => (this.mapView = mapView)}
                    style={{ width: '100%', height: '100%' }}
                    initialMapCenter={[coords]}
                    recenterIfGraphicTapped={true}
                    markersData={markersData}
                    // layersData={['https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/0']}
                    // baseMapType={'LIGHT_GRAY'}
                /> */}
                <ADMGISMapView coords={coords} placeMarks={placeMarkData} showMenu={true} />
            </View>
        );
    }
}

export default DashboardMapView;
