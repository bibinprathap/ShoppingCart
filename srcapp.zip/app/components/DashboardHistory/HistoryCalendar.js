import React, { Component } from 'react';
import { Text, View, ActivityIndicator } from 'react-native';
import { Agenda } from 'react-native-calendars';
import { connect } from 'react-redux';
import { inspectionsHelper } from 'app/api/helperServices';
import moment from 'moment';
import _ from 'lodash';
import { getInspectionHistory } from 'app/actions/generic';
import { strings } from 'app/config/i18n/i18n';
import { Icon } from 'app/components';
import styles from './styles';
class HistoryCalendar extends Component {
    constructor(props) {
        super(props);
        const { history } = props;
        this.state = {
            items: {},
            history,
            loading: true,
            newDaysObject: {},
        };
    }

    componentDidMount = async () => {
        this.props.dispatch(getInspectionHistory(new Date(Date.now() - 864e5 * 30), new Date(), 99));

        // this.interval = setInterval(() => {
        //     this.setState({
        //         loading: false,
        //     });
        // }, 2000);
    };

    componentWillUnmount() {
        // clearInterval(this.interval);
    }

    render() {
        const { newDaysObject } = this.state;

        if (this.state.loading) {
            const themeStlye = 'dark' ? styles.containerDark : styles.containerLight;
            const spinnerStyles = [styles.container, themeStlye];
            return (
                //first stage spinner
                <View style={spinnerStyles}>
                    <Text>Loading History View...</Text>
                    <ActivityIndicator size={'large'} />
                </View>
            );
        }

        return (
            <Agenda
                // style={{
                //     backgroundColor: '$primaryWhite',
                //     flex: 1,
                //     justifyContent: 'center',
                //     //alignItems: 'center',
                // }}
                items={this.state.items}
                loadItemsForMonth={this.loadItems.bind(this)}
                selected={new Date()}
                renderItem={this.renderItem}
                renderEmptyData={this.renderEmptyData.bind(this)}
                rowHasChanged={this.rowHasChanged.bind(this)}
                dayLoading={true}
                pastScrollRange={2}
                futureScrollRange={1}
                markingType={'custom'}
                markedDates={newDaysObject}
                maxDate={new Date()}
                //theme={this.getTheme()}
                hideKnob={false}
                onRefresh={() => this.refreshed()}
                refreshing={false}
                refreshControl={null}
                theme={{
                    'stylesheet.calendar.header': { week: { marginTop: 0, flexDirection: 'row', justifyContent: 'space-between' } },

                    selectedDayBackgroundColor: 'yellow',
                }}
            />
        );
    }

    refreshed() {
        this.loadItems();
    }
    loadItems(day) {
        // setTimeout(() => {
        const dataMap = [];
        const { history, inspectionHistoryData } = this.props;
        const nextDays = [];
        const nextDaysLocal = [];

        const historyData = inspectionHistoryData.inspectionVModel;
        history.forEach(inspectionContainer => {
            nextDaysLocal.push(moment(inspectionContainer.inspection.createdDate).format('YYYY-MM-DD'));
            dataMap.push({
                createdDate: moment(inspectionContainer.inspection.createdDate).format('YYYY-MM-DD'),
                refNumber: inspectionContainer.inspection.refNumber,
                servicesTitle: inspectionsHelper.getLongTitle(inspectionContainer, false),
                // inspection: { inspection },
                titleRefNumber: inspectionContainer.inspection.refNumber || inspectionContainer.inspection.applicationNumber,
            });
        });

        historyData.forEach(key => {
            nextDays.push(moment(key.createdDate).format('YYYY-MM-DD'));

            dataMap.push({
                createdDate: moment(key.createdDate).format('YYYY-MM-DD'),
                refNumber: key.applicationNumber,
                inspectionId: key.inspectionId,
                workflowInstanceId: key.workflowInstanceId,
            });
        });

        const markedDatesLocal = [...new Set(nextDaysLocal)];
        const markedDates = [...new Set(nextDays)];

        (groups = ['createdDate']),
            (grouped = dataMap.reduce((r, o) => {
                //groups.reduce((group, key, i, { length }) => (group[o[key]]
                groups.reduce((group, key, i, { length }) => (group[o[key]] = group[o[key]] || (i + 1 === length ? [] : {})), r).push(o);

                return r;
            }, {}));

        const newDaysObject = {};

        markedDates.forEach(day => {
            newDaysObject[day] = {
                customStyles: {
                    container: {
                        backgroundColor: '#9CDCA3',
                    },
                    text: {
                        color: 'white',
                        fontWeight: 'bold',
                    },
                },
            };
        });

        markedDatesLocal.forEach(day => {
            newDaysObject[day] = {
                customStyles: {
                    container: {
                        backgroundColor: '#F47D3B',
                    },
                    text: {
                        color: 'white',
                        fontWeight: 'bold',
                    },
                },
            };
        });

        this.setState({
            items: grouped,
            newDaysObject: newDaysObject,
        });
        // }, 2000);
    }

    renderItem(item) {
        return (
            <View style={[styles.item]}>
                <View>
                    {!!item.servicesTitle && <Text style={styles.servicesTitle}>{item.servicesTitle}</Text>}
                    <Text style={styles.refNumber} numberOfLines={1}>
                        {strings('referenceNumberShort')} - {item.titleRefNumber || item.refNumber}
                    </Text>
                    {/* <Text style={styles.createdDate}>{moment(item.createdDate).fromNow()}</Text> */}
                    <Text>Date Created : {item.createdDate}</Text>
                </View>
            </View>
        );
    }

    renderEmptyData() {
        return (
            <View style={styles.emptyItem}>
                <Icon type="MaterialCommunityIcons" name={'block'} size={24} color={'blue'} />
                <Text style={styles.emptyItemText}>No Inspection Created</Text>
            </View>
        );
    }
    rowHasChanged(r1, r2) {
        return r1.name !== r2.name;
    }

    timeToString(time) {
        const date = new Date(time);
        return date.toISOString().split('T')[0];
    }
}

mapStateToProps = state => {
    const history = inspectionsHelper.getInspectionHistoryForLoggedInUser({
        userId: state.auth.activeProfileUserId,
        allHistory: state.inspections.history,
    });
    return {
        history: history || {},
        inspectionHistoryData: state.generic.inspectionHistory.results,
    };
};

export default connect(mapStateToProps)(HistoryCalendar);
