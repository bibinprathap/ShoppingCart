import React from 'react';
import { View, TouchableOpacity, Linking } from 'react-native';
import styles from './styles';
import { Icon } from 'app/components';
import { formatAddress } from 'app/api/helperServices/utils';

import DashboardMapView from './DashboardMapView';

class InspectionLocation extends React.PureComponent {
    // defaultPointGraphics = [
    //     { graphicId: 'normalPoint', graphic: Image.resolveAssetSource(require('app/images/normalpoint.png')) },
    //     { graphicId: 'personPoint', graphic: Image.resolveAssetSource(require('app/images/personpoint.png')) },
    // ];
    constructor(props) {
        super(props);
        this.state = {
            modalVisible: false,
            showMap: false,
        };
        this.handleShowMap = this.handleShowMap.bind(this);
        this.handleHideMap = this.handleHideMap.bind(this);
        this.handleShowGoogleMap = this.handleShowGoogleMap.bind(this);
    }
    handleShowMap() {
        this.setState({ showMap: true });
    }
    handleHideMap() {
        this.setState({ showMap: false });
    }

    handleShowGoogleMap() {
        const { inspection } = this.props;
        const coords = inspection && inspection.location && inspection.location.coords;
        const address = (inspection && inspection.location && inspection.location.address) || {};

        const formattedAddress = formatAddress(address);

        const latLng = `${coords.latitude},${coords.longitude}`;
        const label = formattedAddress;

        Linking.openURL(`geo:0,0?q=${latLng}(${label})`);

        // this.setState({ modalVisible: true });
    }
    toggleLocationDialog = () => {
        this.setState({ modalVisible: !this.state.modalVisible });
    };
    render() {
        const { showMap } = this.state;
        const { inspection } = this.props;
        // const coords = inspection && inspection.location && inspection.location.coords;
        // const pointGraphics = this.defaultPointGraphics;
        // const markersData = {
        //     pointGraphics: pointGraphics,
        //     referenceId: 'defaultId',
        //     points: [{ ...coords, rotation: 0, referenceId: 'selectedLocation', graphicId: 'personPoint' }],
        // };

        if (showMap)
            return (
                <>
                    <View
                        style={[
                            {
                                position: 'absolute',

                                zIndex: 999,

                                top: 4,
                                right: this.props.keepRight ? 35 : 0,
                                padding: 5,
                                flex: 1,
                            },
                        ]}
                    >
                        <TouchableOpacity onPress={this.handleHideMap}>
                            <View style={styles.buttonView}>
                                <Icon type="MaterialCommunityIcons" name="map-marker-off" style={styles.button} />
                            </View>
                        </TouchableOpacity>
                    </View>
                    <View style={[styles.smallmapItem, { height: 200, width: '100%' }]}>
                        <View
                            style={[
                                {
                                    position: 'absolute',
                                    flexDirection: 'row',
                                    zIndex: 999,
                                    right: 0,
                                    top: 0,
                                    padding: 5,
                                },
                            ]}
                        >
                            <TouchableOpacity onPress={this.handleShowGoogleMap} style={{ marginHorizontal: 10 }}>
                                <View style={styles.buttonView}>
                                    <Icon type="MaterialCommunityIcons" name="google-maps" style={styles.button} />
                                </View>
                            </TouchableOpacity>
                        </View>
                        {/* <ArcGISMapView
                            ref={mapView => (this.mapView = mapView)}
                            style={{ width: '100%', height: '100%' }}
                            initialMapCenter={[coords]}
                            recenterIfGraphicTapped={true}
                            markersData={markersData}
                            // layersData={['https://onwani.abudhabi.ae/arcgis/rest/services/MSSI/ADMINBOUNDARIES/FeatureServer/0']}
                            // baseMapType={'LIGHT_GRAY'}
                        /> */}

                        <DashboardMapView inspection={inspection} />
                    </View>
                </>
            );
        else
            return (
                <View
                    style={[
                        {
                            position: 'absolute',

                            zIndex: 999,

                            top: 4,
                            right: this.props.keepRight ? 35 : 0,
                            padding: 5,
                            flex: 1,
                        },
                    ]}
                >
                    <TouchableOpacity onPress={this.handleShowMap} style={styles.touchWrapper}>
                        <View style={styles.buttonView}>
                            <Icon type="MaterialCommunityIcons" name="map-marker" style={styles.button} />
                        </View>
                    </TouchableOpacity>
                </View>
            );
    }
}

export default InspectionLocation;
