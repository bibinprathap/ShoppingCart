import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { Icon } from 'app/components';
import { strings } from 'app/config/i18n/i18n';

export default function({ checkingDuplicate, checkDuplicate }) {
    //return <AnimatableIcon name={'content-copy'} size={30} color="white" animation="pulse" easing="ease-out" iterationCount="infinite" />;
    //const [animating, setAnimationState] = useState(checkingDuplicate);

    handleOnPress = () => {
        setTimeout(() => {
            if (checkDuplicate) checkDuplicate();
        });
    };

    return (
        <TouchableOpacity onPress={this.handleOnPress}>
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    borderWidth: 1,
                    borderColor: 'white',
                    borderRadius: 4,
                    padding: 2,
                }}
            >
                <Text numberOfLines={2} style={{ fontSize: 12, color: 'white', marginHorizontal: 2 }}>
                    {checkingDuplicate ? strings('checkingDuplicate') : strings('checkDuplicate')}
                </Text>
                <Icon type="MaterialCommunityIcons" name={'content-copy'} size={20} color="white" />
            </View>
        </TouchableOpacity>
    );
}
