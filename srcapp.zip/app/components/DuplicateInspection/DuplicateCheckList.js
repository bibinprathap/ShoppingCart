import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, I18nManager } from 'react-native';
import { Button, List, TouchableRipple, Divider, Text } from 'react-native-paper';
import { IconButton } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import images from 'app/images';
import styles from './styles';

export default memo(function(props) {
    const { key, item, inspection, handleViewReview, optionSelected, duplicates, inspectionTypeId } = props;
    const rowStyles = [styles.row];
    const titleStyles = [styles.title];
    const descriptionStyles = [styles.descriptionTitle];
    const iconStyle = [];
    if (inspection && item.applicationNumber == inspection.applicationNumber) {
        rowStyles.push(styles.rowSelected);
        titleStyles.push(styles.titleSelected);
        descriptionStyles.push(styles.titleSelected);
        iconStyle.push(styles.iconSelected);
    }

    const handleViewDetailsClick = () => handleViewReview(item, inspectionTypeId);
    const optionSelectedNoclick = () => {
        if (item.applicationNumber != (inspection || {}).applicationNumber) handleViewReview(item, inspectionTypeId);
        optionSelected({ inspection: item, option: false });
    };
    const optionSelectedYesclick = () => {
        if (item.applicationNumber != (inspection || {}).applicationNumber) handleViewReview(item, inspectionTypeId);
        optionSelected({ inspection: item, option: true });
    };

    const ActionButton = ({ buttonText, ...props }) => {
        if (buttonText) {
            return (
                <IconButton type="MaterialCommunityIcons" {...props}>
                    <Text style={styles.buttonText}>{buttonText}</Text>
                </IconButton>
            );
        }
        return (
            <Button {...props}>
                <Text style={styles.buttonText}>{buttonText}</Text>
            </Button>
        );
    };

    let yesBorderColor = {};
    let noBorderColor = {};
    let yesicon = '';
    let noicon = '';
    let buttonBackgroundColor = '#cccccc';
    if (inspection && item.applicationNumber == inspection.applicationNumber) buttonBackgroundColor = '#007AFF';
    if (duplicates) {
        const currentDuplicate = duplicates.find(d => d.applicationNumber == item.applicationNumber);
        if (currentDuplicate) {
            if (currentDuplicate.isDuplicate) {
                yesBorderColor = { borderColor: '#FFB900', borderWidth: 3 };
                yesicon = 'check';
            } else {
                noBorderColor = { borderColor: '#FFB900', borderWidth: 3 };
                noicon = 'close';
            }
        }
    }

    return (
        <View key={key}>
            <TouchableRipple onPress={handleViewDetailsClick}>
                <View>
                    <List.Item
                        style={rowStyles}
                        title={
                            <Text style={styles.listItemTitle}>
                                {strings('referenceNumberShort')}: {item.workflowApplicationNumber || item.applicationNumber}
                            </Text>
                        }
                        // description={() => (
                        //     <Text style={styles.listItemDescription}>
                        //         {strings('address')}: {item.location && item.location.address ? item.location.address.zone : ''}{' '}
                        //         {item.info && item.info.generalInfo ? ', ' + strings('remarks') + ' : ' + item.info.generalInfo.remarks : ''}
                        //     </Text>
                        // )}
                        titleStyle={titleStyles}
                        descriptionStyle={descriptionStyles}
                        left={props => <List.Icon {...props} style={styles.iconSelected} icon={images.review.content} />}
                        right={props => (
                            <View style={{ width: 250, marginTop: 11, flexDirection: 'row' }}>
                                <View
                                    style={{
                                        height: 32,
                                        width: 110,
                                        borderRadius: 5,

                                        justifyContent: 'center',
                                        alignItems: 'center',
                                    }}
                                >
                                    <ActionButton
                                        style={[styles.actionButton, yesBorderColor]}
                                        name={yesicon}
                                        borderRadius={25}
                                        backgroundColor={buttonBackgroundColor}
                                        onPress={optionSelectedYesclick}
                                        buttonText={strings('isDuplicate')}
                                    />
                                </View>

                                <View
                                    style={{
                                        height: 32,
                                        width: 115,
                                        marginStart: 10,
                                        borderRadius: 5,

                                        justifyContent: 'center',
                                        alignItems: 'center',
                                    }}
                                >
                                    <ActionButton
                                        style={[styles.actionButton, noBorderColor]}
                                        name={noicon}
                                        borderRadius={25}
                                        backgroundColor={buttonBackgroundColor}
                                        onPress={optionSelectedNoclick}
                                        buttonText={strings('notDuplicate')}
                                    />
                                </View>
                            </View>
                        )}
                    />
                </View>
            </TouchableRipple>
            <Divider />
        </View>
    );
});
