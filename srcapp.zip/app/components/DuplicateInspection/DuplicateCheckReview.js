import React, { memo, Component } from 'react';
import { View, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { InspectionView } from 'app/components';

export default memo(function(props) {
    const { inspection, isSubmitable } = props;
    return (
        <View style={{ flex: 1, margin: 10, padding: 10, borderWidth: 1, borderColor: '#ccc', borderRadius: 5 }}>
            <View style={{ flex: 1, minHeight: 30, flexDirection: 'row', margin: 5 }}>
                <Text style={styles.heading}>{strings('duplicateInspectionDetails')}</Text>
                <Text style={[styles.heading, styles.mutedText, { margin: 4, paddingLeft: 10 }]}>
                    {strings('referenceNumberShort') + ' : ' + inspection.applicationNumber}
                </Text>
            </View>
            <View
                style={{
                    borderRadius: 8,
                    paddingVertical: 10,
                    minHeight: 430,
                    borderRadius: 8,
                }}
            >
                <ScrollView style={{ flex: 1 }}>
                    {inspection && (
                        <InspectionView
                            inspection={{ inspection: inspection }}
                            isSubmitable={isSubmitable}
                            taskdetails={{}}
                            errorLogs={{}}
                            isReadOnlyVisit={true}
                            showInspCommonFieldsAtTop={true}
                        />
                    )}
                </ScrollView>
            </View>
        </View>
    );
});
