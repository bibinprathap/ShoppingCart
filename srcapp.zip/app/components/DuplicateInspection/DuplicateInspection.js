import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ScrollView } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { _ } from 'lodash';
import { _state } from 'app/config/store';
import styles from './styles';
import { inspectionsHelper } from 'app/api/helperServices';
import { setDuplicate, getInspectionDetails } from 'app/actions/inspections';
import DuplicateCheckList from './DuplicateCheckList';
import DuplicateCheckReview from './DuplicateCheckReview';
import { shallowEqual } from 'app/api/helperServices';
import { setLoading, setLoaded } from 'app/actions/loader';
import { store } from 'app/config/store';
import alertsHelper from 'app/api/helperServices/alerts';

class DuplicateInspection extends Component {
    constructor() {
        super();
        this.state = {
            showDetails: false,
            errorMessage: '',
        };
        this.handleViewReview = this.handleViewReview.bind(this);
        this.optionSelected = this.optionSelected.bind(this);
    }
    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    componentDidMount() {
        const { duplicateInspection, inspection } = this.props;
        const { inspectionApplicationNumber } = this.state;
        if (
            duplicateInspection &&
            duplicateInspection.duplicateCandidates &&
            duplicateInspection.duplicateCandidates.length > 0 &&
            inspectionApplicationNumber == undefined
        )
            this.handleViewReview(duplicateInspection.duplicateCandidates[0], inspection.inspectionTypeDetail.inspectionTypeId);
    }

    handleViewReview(item, inspectionTypeId) {
        const { isChecklist, violationItem, inspection } = this.props;
        this.setState({ showDetails: false, errorMessage: '' });
        store.dispatch(setLoading({ options: { message: 'Loading duplicate inspection details...' } }));
        try {
            const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);

            store
                .dispatch(
                    getInspectionDetails({
                        workflowConst: inspection.inspectionTypeDetail && inspection.inspectionTypeDetail.workflowConst,
                        workflowInstanceId: item.workflowInstanceId,
                        applicationNumber: item.applicationNumber,
                        workflowApplicationNumber: item.workflowApplicationNumber,
                        IsShallow: false,
                        inspectionTypeId,
                        isChecklist,
                        currentVisitIndex,
                        inspTypeCheckItemId: violationItem && violationItem.item.inspTypeCheckItemId,
                        includeDraftVisit: false,
                    })
                )
                .then(() => {
                    const { duplicateInspection } = this.props;
                    const { duplicateCandidates } = duplicateInspection;
                    store.dispatch(setLoaded());
                    const inspection = duplicateCandidates.find((i) => i.applicationNumber == item.applicationNumber).inspection;

                    if (inspection) {
                        let selectedWorkflowConst = inspection.inspectionTypeDetail.workflowConst;
                        this.setState({
                            showDetails: true,
                            selectedWorkflowConst: selectedWorkflowConst,
                            inspectionApplicationNumber: item.applicationNumber,
                        });
                    } else {
                        this.setState({ errorMessage: strings('inspectionDetailsNotFound') });
                    }
                });
        } catch (error) {
            store.dispatch(setLoaded());
            alertsHelper.show('error', 'Loading duplicate inspection details failed', error.detail);
        }
    }

    optionSelected = ({ option, inspection }) => {
        this.props.optionSelected({ option, inspection });
    };

    render() {
        const { duplicateInspection, editable, duplicatesDecision } = this.props;
        if (!(duplicateInspection && duplicateInspection.duplicateCandidates)) return null;
        const { duplicateCandidates } = duplicateInspection;

        const { showDetails, selectedWorkflowConst, inspectionApplicationNumber, errorMessage } = this.state;
        const duplicateCandidatesCount = duplicateCandidates.length;

        let inspection;
        if (inspectionApplicationNumber) {
            const dupInspection = duplicateCandidates.find((i) => i.applicationNumber == inspectionApplicationNumber);
            if (dupInspection) inspection = dupInspection.inspection;
        }

        const duplicateContents = duplicateCandidates.map((item, index) => {
            return (
                <DuplicateCheckList
                    key={index}
                    inspection={inspection}
                    duplicates={duplicatesDecision}
                    inspectionTypeId={this.props.inspection.inspectionTypeDetail.inspectionTypeId}
                    optionSelected={this.optionSelected}
                    item={item}
                    handleViewReview={this.handleViewReview}
                />
            );
        });

        return (
            <View style={styles.container}>
                <View style={styles.possibleCandidatesCountText}>
                    {duplicateCandidatesCount == 1 && <Text>{strings('possibleDuplicatesSingle')}</Text>}
                    {duplicateCandidatesCount > 1 && <Text>{strings('possibleDuplicatesMultiple', { count: duplicateCandidatesCount })}</Text>}
                </View>
                <ScrollView style={{ maxHeight: 250 }}>{duplicateContents}</ScrollView>
                {(errorMessage && (
                    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={styles.label}>{errorMessage}</Text>
                    </View>
                )) ||
                    null}
                {showDetails && inspection ? (
                    <DuplicateCheckReview editable={editable} inspection={inspection} selectedWorkflowConst={selectedWorkflowConst} />
                ) : null}
            </View>
        );
    }
}

export default DuplicateInspection;
