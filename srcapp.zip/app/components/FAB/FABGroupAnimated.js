import React, { Component } from 'react';
import { View, StyleSheet, Animated, TouchableWithoutFeedback, StatusBar, SafeAreaView, TouchableOpacity, Easing } from 'react-native';
import { polyfill } from 'react-lifecycles-compat';
import color from 'color';
import { _ } from 'lodash';
import { Text, Card, ActivityIndicatorm, Surface, CrossFadeIcon, DefaultTheme, withTheme } from 'react-native-paper';
import FAB from './FAB';
import { strings, localeProperty } from 'app/config/i18n/i18n';

const maxWidth = 600;
const iconWrapperWidth = 30;
const startingXPos = 70;
const startingYPos = 75;
class FABGroupAnimated extends React.Component {
    static displayName = 'FAB.Group';

    static getDerivedStateFromProps(nextProps, prevState) {
        return {
            animations: nextProps.actions.map((_, i) => prevState.animations[i] || new Animated.Value(nextProps.open ? 1 : 0)),
        };
    }

    constructor(props) {
        super(props);
        this.state = {
            backdrop: new Animated.Value(0),
            animations: [],
            selectedServices: [],
        };

        this.init();
    }

    init() {
        this.buttonWrapperRef = [];
        this.buttonAnimatedValue = {};
        this.currentXPosition = startingXPos;
        this.currentYPosition = startingYPos;
    }

    componentDidUpdate(prevProps, prevState) {
        if (!this.props.open && prevProps.open) {
            this.init();
            this.setState({ selectedServices: [] });
        }

        if (this.props.open === prevProps.open) {
            if (!_.isEqual(this.props.actions, prevProps.actions)) {
                const newAnimations = this.props.actions.map((_, i) => new Animated.Value(0));

                this.setState({ animations: newAnimations }, () => {
                    Animated.parallel([
                        Animated.stagger(
                            25,
                            newAnimations
                                .map(animation =>
                                    Animated.timing(animation, {
                                        toValue: 1,
                                        duration: 150,
                                        useNativeDriver: true,
                                    })
                                )
                                .reverse()
                        ),
                    ]).start();
                });
            }

            return;
        }

        if (this.props.open) {
            Animated.parallel([
                Animated.timing(this.state.backdrop, {
                    toValue: 1,
                    duration: 250,
                    useNativeDriver: true,
                }),
                Animated.stagger(
                    25,
                    this.state.animations
                        .map(animation =>
                            Animated.timing(animation, {
                                toValue: 1,
                                duration: 150,
                                useNativeDriver: true,
                            })
                        )
                        .reverse()
                ),
            ]).start();
        } else {
            Animated.parallel([
                Animated.timing(this.state.backdrop, {
                    toValue: 0,
                    duration: 200,
                    useNativeDriver: true,
                }),
                ...this.state.animations.map(animation =>
                    Animated.timing(animation, {
                        toValue: 0,
                        duration: 150,
                        useNativeDriver: true,
                    })
                ),
            ]).start();
        }
    }

    _close = () => {
        if (this.props.open) {
            this.props.onStateChange({ open: false });
            this.setState({ selectedServices: [] });
            this.init();
        }
    };

    _toggle = () => {
        if (this.props.open) {
            this.init();
            this.setState({ selectedServices: [] });
        }
        this.props.onStateChange({ open: !this.props.open });
    };

    moveSelected = (item, pos) => {
        let key = item.data.titleE || item.data.inspEntityNameE;
        const { selectedServices } = this.state;
        this.buttonAnimatedValue[key] = new Animated.ValueXY();

        this.buttonWrapperRef[key].measure((fx, fy, width, height, px, py) => {
            const y = parseInt(py - 52); //const x = parseInt(px - width);
            const x = parseInt(px);
            this.buttonAnimatedValue[key] = new Animated.ValueXY({ x, y });
            this.setState(
                {
                    selectedServices: [...selectedServices, { ...item, width: width + iconWrapperWidth }],
                },
                () => {
                    if (this.currentXPosition + width > maxWidth) {
                        this.currentXPosition = startingXPos;
                        this.currentYPosition = this.currentYPosition + startingYPos;
                    }
                    Animated.spring(this.buttonAnimatedValue[key], {
                        toValue: { x: this.currentXPosition, y: this.currentYPosition },
                        tension: 20,
                    }).start();

                    this.currentXPosition = this.currentXPosition + width + iconWrapperWidth;
                    item.onPress(item.data);
                }
            );
        });
    };

    render() {
        const { large, small, actions, icon, open, onPress, accessibilityLabel, theme, style, backdropColor, fabStyle, visible, label } = this.props;
        const { colors } = theme;

        const labelColor = theme.dark
            ? colors.text
            : color(colors.text)
                  //.fade(0.54)
                  .rgb()
                  .string();
        const backdropOpacity = open
            ? this.state.backdrop.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0, 1, 1],
              })
            : this.state.backdrop;

        const opacities = this.state.animations;
        const scales = opacities.map(opacity =>
            open
                ? opacity.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.8, 1],
                  })
                : 1
        );
        const actionsContainerMargin = large ? 70 : small ? 40 : 56;
        const actionsContainerStyle = { marginBottom: actionsContainerMargin };
        return (
            <View pointerEvents="box-none" style={[styles.container, style]}>
                {open ? <StatusBar barStyle="light-content" /> : null}
                <TouchableWithoutFeedback onPress={this._close}>
                    <Animated.View
                        pointerEvents={open ? 'auto' : 'none'}
                        style={[
                            styles.backdrop,
                            {
                                opacity: backdropOpacity,
                                backgroundColor: backdropColor ? backdropColor : colors.backdrop,
                            },
                        ]}
                    />
                </TouchableWithoutFeedback>
                <SafeAreaView pointerEvents="box-none" style={styles.safeArea}>
                    {this.state.selectedServices.map((it, pos) => {
                        let key = it.data.titleE || it.data.inspEntityNameE;
                        let label = it.data.titleE ? localeProperty(it.data, 'title') : localeProperty(it.data, 'inspEntityName');
                        return (
                            <Animated.View key={key} style={[styles.selectedButtonWrapper, this.buttonAnimatedValue[key].getLayout()]}>
                                <TouchableOpacity
                                    style={styles.selectedButton}
                                    onPress={() => {
                                        if (pos > 0) {
                                            const preMenu = this.state.selectedServices[pos - 1];
                                            it.onPress(preMenu.data);
                                            for (let j = pos; j < this.state.selectedServices.length; j++)
                                                this.currentXPosition -= this.state.selectedServices[j].width;

                                            this.setState({ selectedServices: this.state.selectedServices.slice(0, pos) });
                                        } else {
                                            this.setState({ selectedServices: [] }, () => {
                                                this.init();
                                                this.props.onStateChange({ open: true });
                                            });
                                        }
                                        // it.onPress();
                                    }}
                                >
                                    {it.icon ? <View style={styles.iconWrapper}>{it.icon()}</View> : null}
                                    <Text style={styles.selectedButtonLabel}>{label}</Text>
                                </TouchableOpacity>
                            </Animated.View>
                        );
                    })}

                    <View pointerEvents={open ? 'box-none' : 'none'} style={actionsContainerStyle}>
                        {actions.map((it, i) => {
                            let label = it.data.titleE ? localeProperty(it.data, 'title') : localeProperty(it.data, 'inspEntityName');

                            return (
                                <View
                                    key={label} // eslint-disable-line react/no-array-index-key
                                    style={styles.item}
                                    pointerEvents="box-none"
                                >
                                    {label && (
                                        <Card
                                            style={[
                                                styles.label,
                                                {
                                                    transform: [{ scale: scales[i] }],
                                                    opacity: opacities[i],
                                                },
                                                it.labelStyle,
                                            ]}
                                            accessibilityLabel={it.accessibilityLabel !== 'undefined' ? it.accessibilityLabel : label}
                                            accessibilityTraits="button"
                                            accessibilityComponentType="button"
                                            accessibilityRole="button"
                                        >
                                            <TouchableOpacity
                                                onPress={() => {
                                                    this.moveSelected(it, i);
                                                    //it.onPress(it.data);
                                                    //this._close();
                                                }}
                                                ref={buttonWrapperRef => {
                                                    const key = it.data.titleE || it.data.inspEntityNameE;
                                                    this.buttonWrapperRef[key] = buttonWrapperRef;
                                                }}
                                                style={{
                                                    paddingHorizontal: 12,
                                                    justifyContent: 'center',
                                                    height: 54,
                                                }}
                                            >
                                                <Text style={{ color: labelColor, aligSelf: 'center' }}>{label}</Text>
                                            </TouchableOpacity>
                                        </Card>
                                    )}
                                    <FAB
                                        large={large}
                                        small={small}
                                        icon={it.icon()}
                                        color={it.color}
                                        style={[
                                            {
                                                transform: [{ scale: scales[i] }],
                                                opacity: opacities[i],
                                                backgroundColor: theme.colors.surface,
                                            },
                                            styles.defaultItemFabStyle,
                                            it.style,
                                            //it.actionItemStyle,
                                        ]}
                                        onPress={() => {
                                            this.moveSelected(it, i);
                                            //it.onPress(it.data);
                                            //this._close();
                                            //<AnimateView x={100} y={10} buttonText="First" width={100} />
                                        }}
                                        accessibilityLabel={typeof it.accessibilityLabel !== 'undefined' ? it.accessibilityLabel : it.label}
                                        accessibilityTraits="button"
                                        accessibilityComponentType="button"
                                        accessibilityRole="button"
                                    />
                                </View>
                            );
                        })}
                    </View>
                    <FAB
                        onPress={() => {
                            onPress && onPress();
                            this._toggle();
                        }}
                        large={large}
                        small={small}
                        icon={icon}
                        label={label}
                        color={this.props.color}
                        accessibilityLabel={accessibilityLabel}
                        accessibilityTraits="button"
                        accessibilityComponentType="button"
                        accessibilityRole="button"
                        style={[styles.fab, fabStyle]}
                        visible={visible}
                    />
                </SafeAreaView>
            </View>
        );
    }
}

polyfill(FABGroupAnimated);

export default withTheme(FABGroupAnimated);

const styles = StyleSheet.create({
    safeArea: {
        flex: 1,
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'flex-end',
    },
    fab: {
        // marginHorizontal: 16,
        // marginBottom: 16,
        // marginTop: 0,
    },
    backdrop: {
        ...StyleSheet.absoluteFillObject,
    },
    iconWrapper: {
        backgroundColor: '#fff',
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 5,
    },
    label: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginVertical: 8,
        marginHorizontal: 16,
        elevation: 2,
        backgroundColor: '#FFFFFF',
    },
    item: {
        //marginHorizontal: 24,
        marginBottom: 16,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    defaultItemFabStyle: {
        backgroundColor: '#FFFFFF',
    },
    selectedButtonWrapper: {
        position: 'absolute',
        backgroundColor: '#058DFC',
        borderRadius: 10,
        marginTop: 10,
    },
    selectedButton: {
        paddingVertical: 15,
        paddingHorizontal: 10,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    selectedButtonLabel: {
        color: '#fff',
    },
});
