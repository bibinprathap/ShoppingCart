import React, { Component } from 'react';
import { View, StyleSheet, Animated, TouchableWithoutFeedback, StatusBar, SafeAreaView, TouchableOpacity, Easing } from 'react-native';
import { polyfill } from 'react-lifecycles-compat';
import color from 'color';
import { _ } from 'lodash';
import { Text, Card, ActivityIndicatorm, Surface, CrossFadeIcon, DefaultTheme, withTheme } from 'react-native-paper';
import FAB from './FAB';
import EStyleSheet from 'react-native-extended-stylesheet';
import Popover from 'react-native-popover-view';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Icon } from 'app/components';

const maxWidth = 570; // 560;
const iconWrapperWidth = 35;
const startingXPos = 70;
const startingYPos = 75;
class FABGroupAnimatedButton extends React.Component {
    static displayName = 'FAB.Group';

    static getDerivedStateFromProps(nextProps, prevState) {
        return {
            animations: nextProps.actions.map((_, i) => prevState.animations[i] || new Animated.Value(nextProps.open ? 1 : 0)),
        };
    }

    constructor(props) {
        super(props);
        this.state = {
            backdrop: new Animated.Value(0),
            animations: [],
            selectedServices: [],
            isVisible: false,
            popoverDesc: null,
            key: null,
        };

        this.init();
    }
    touchable;

    init() {
        this.buttonWrapperRef = [];
        this.infoRef = [];
        this.buttonAnimatedValue = {};
        this.currentXPosition = startingXPos;
        this.currentYPosition = startingYPos;
    }

    componentDidUpdate(prevProps, prevState) {
        if (!this.props.open && prevProps.open) {
            this.init();
            this.setState({ selectedServices: [] });
        }

        if (this.props.open === prevProps.open) {
            if (!_.isEqual(this.props.actions, prevProps.actions)) {
                const newAnimations = this.props.actions.map((_, i) => new Animated.Value(0));

                this.setState({ animations: newAnimations }, () => {
                    Animated.parallel([
                        Animated.stagger(
                            25,
                            newAnimations
                                .map(animation =>
                                    Animated.timing(animation, {
                                        toValue: 1,
                                        duration: 150,
                                        useNativeDriver: true,
                                    })
                                )
                                .reverse()
                        ),
                    ]).start();
                });
            }

            return;
        }

        if (this.props.open) {
            Animated.parallel([
                Animated.timing(this.state.backdrop, {
                    toValue: 1,
                    duration: 250,
                    useNativeDriver: true,
                }),
                Animated.stagger(
                    25,
                    this.state.animations
                        .map(animation =>
                            Animated.timing(animation, {
                                toValue: 1,
                                duration: 150,
                                useNativeDriver: true,
                            })
                        )
                        .reverse()
                ),
            ]).start();
        } else {
            Animated.parallel([
                Animated.timing(this.state.backdrop, {
                    toValue: 0,
                    duration: 200,
                    useNativeDriver: true,
                }),
                ...this.state.animations.map(animation =>
                    Animated.timing(animation, {
                        toValue: 0,
                        duration: 150,
                        useNativeDriver: true,
                    })
                ),
            ]).start();
        }
    }

    _close = () => {
        if (this.props.open) {
            this.props.onStateChange({ open: false });
            this.setState({ selectedServices: [] });
            this.init();
        }
    };

    _toggle = () => {
        if (this.props.open) {
            this.init();
            this.setState({ selectedServices: [] });
        }
        this.props.onStateChange({ open: !this.props.open });
    };

    moveSelected = (item, pos) => {
        let key = item.data.titleE || item.data.inspEntityNameE;
        const { selectedServices } = this.state;
        this.buttonAnimatedValue[key] = new Animated.ValueXY();

        this.buttonWrapperRef[key].measure((fx, fy, width, height, px, py) => {
            const y = parseInt(py - 52); //const x = parseInt(px - width);
            const x = parseInt(px);
            this.buttonAnimatedValue[key] = new Animated.ValueXY({ x, y });
            this.setState(
                {
                    selectedServices: [...selectedServices, { ...item, width: width + iconWrapperWidth }],
                },
                () => {
                    if (this.currentXPosition + width > maxWidth) {
                        this.currentXPosition = startingXPos;
                        this.currentYPosition = this.currentYPosition + startingYPos;
                    }
                    Animated.spring(this.buttonAnimatedValue[key], {
                        toValue: { x: this.currentXPosition, y: this.currentYPosition },
                        tension: 20,
                    }).start();

                    this.currentXPosition = this.currentXPosition + width + iconWrapperWidth;
                    item.onPress(item.data);
                }
            );
        });
    };

    showServiceDesc = (data, key) => {
        const desc = localeProperty(data, 'serviceDesc');
        this.setState({ isVisible: true, popoverDesc: desc, key });
    };

    closePopover = () => {
        this.setState({ isVisible: false, popoverDesc: null, key: null });
    };

    render() {
        const { large, small, actions, icon, open, onPress, accessibilityLabel, theme, style, backdropColor, fabStyle, visible, label } = this.props;
        const { colors } = theme;

        const labelColor = theme.dark
            ? colors.text
            : color(colors.text)
                  //.fade(0.54)
                  .rgb()
                  .string();
        const backdropOpacity = open
            ? this.state.backdrop.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0, 1, 1],
              })
            : this.state.backdrop;

        const opacities = this.state.animations;
        const scales = opacities.map(opacity =>
            open
                ? opacity.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.8, 1],
                  })
                : 1
        );

        const isEntity = (actions && actions.length > 0 && actions[0].isEntity) || false;
        const actionsContainerMargin = large ? 70 : small ? 40 : 56;
        return (
            <View pointerEvents="box-none" style={[styles.container, style]}>
                {open ? <StatusBar barStyle="light-content" /> : null}
                <TouchableWithoutFeedback onPress={this._close}>
                    <Animated.View
                        pointerEvents={open ? 'auto' : 'none'}
                        style={[
                            styles.backdrop,
                            {
                                opacity: backdropOpacity,
                                backgroundColor: backdropColor ? backdropColor : colors.backdrop,
                            },
                        ]}
                    />
                </TouchableWithoutFeedback>
                <SafeAreaView pointerEvents="box-none" style={styles.safeArea}>
                    {this.state.selectedServices.map((it, pos) => {
                        let key = it.data.titleE || it.data.inspEntityNameE;
                        let label = it.data.titleE ? localeProperty(it.data, 'title') : localeProperty(it.data, 'inspEntityName');
                        return (
                            <Animated.View key={key} style={[styles.selectedButtonWrapper, this.buttonAnimatedValue[key].getLayout()]}>
                                <TouchableOpacity
                                    style={styles.selectedButton}
                                    onPress={() => {
                                        if (pos > 0) {
                                            const preMenu = this.state.selectedServices[pos - 1];
                                            it.onPress(preMenu.data);
                                            for (let j = pos; j < this.state.selectedServices.length; j++)
                                                this.currentXPosition -= this.state.selectedServices[j].width;

                                            this.setState({ selectedServices: this.state.selectedServices.slice(0, pos) });
                                        } else {
                                            this.setState({ selectedServices: [] }, () => {
                                                this.init();
                                                this.props.onStateChange({ open: true });
                                            });
                                        }
                                    }}
                                >
                                    {it.icon ? <View style={styles.iconWrapper}>{it.icon()}</View> : null}
                                    <Text style={styles.selectedButtonLabel}>{label}</Text>
                                </TouchableOpacity>
                            </Animated.View>
                        );
                    })}

                    <View
                        pointerEvents={open ? 'box-none' : 'none'}
                        style={[isEntity ? styles.actionsContainer : styles.actionsContainerSub, { marginBottom: actionsContainerMargin }]}
                    >
                        {this.state.key && this.infoRef[this.state.key] && (
                            <Popover isVisible={this.state.isVisible} fromView={this.infoRef[this.state.key]} onRequestClose={this.closePopover}>
                                <View style={styles.popoverContainer}>
                                    <Text style={styles.popoverText}>{this.state.popoverDesc}</Text>
                                </View>
                            </Popover>
                        )}
                        {actions.map((it, i) => {
                            let label = it.data.titleE ? localeProperty(it.data, 'title') : localeProperty(it.data, 'inspEntityName');

                            return (
                                <View key={label} style={isEntity ? styles.item : styles.subItem} pointerEvents="box-none">
                                    {label && (
                                        <Animated.View
                                            style={[
                                                isEntity ? styles.fabMenWrapper : styles.fabSubMenWrapper,
                                                {
                                                    transform: [{ scale: scales[i] }],
                                                    opacity: opacities[i],
                                                },
                                                it.labelStyle,
                                            ]}
                                            accessibilityLabel={it.accessibilityLabel !== 'undefined' ? it.accessibilityLabel : label}
                                            accessibilityTraits="button"
                                            accessibilityComponentType="button"
                                            accessibilityRole="button"
                                        >
                                            {!isEntity && it.data.serviceDescE && (
                                                <TouchableOpacity
                                                    onPress={() => this.showServiceDesc(it.data, it.data.titleE || it.data.inspEntityNameE)}
                                                    ref={infoRef => {
                                                        this.infoRef[it.data.titleE || it.data.inspEntityNameE] = infoRef;
                                                    }}
                                                    style={{
                                                        color: '#fff',
                                                        right: 0,
                                                        top: 0,
                                                        position: 'absolute',
                                                        padding: 5,
                                                        zIndex: 2,
                                                    }}
                                                >
                                                    <Icon
                                                        type="MaterialCommunityIcons"
                                                        name="alert-circle-outline"
                                                        size={24}
                                                        style={styles.infoIcon}
                                                    />
                                                </TouchableOpacity>
                                            )}
                                            <TouchableOpacity
                                                onPress={() => {
                                                    this.moveSelected(it, i);
                                                    //this._close();
                                                }}
                                                ref={buttonWrapperRef => {
                                                    const key = it.data.titleE || it.data.inspEntityNameE;
                                                    this.buttonWrapperRef[key] = buttonWrapperRef;
                                                }}
                                                style={{
                                                    paddingVertical: 20,
                                                    paddingHorizontal: 10,
                                                    justifyContent: 'center',
                                                    alignItems: 'center',
                                                    zIndex: 1,
                                                }}
                                            >
                                                {!isEntity && it.icon ? (
                                                    <View style={isEntity ? styles.iconWrapper : styles.iconWrapperSub}>
                                                        {it.icon({ size: 28, color: '#fff' })}
                                                    </View>
                                                ) : null}
                                                <Text style={[{ color: labelColor }, isEntity ? styles.label : styles.labelSub]}>{label}</Text>
                                            </TouchableOpacity>
                                        </Animated.View>
                                    )}
                                    {isEntity && (
                                        <FAB
                                            large={large}
                                            small={small}
                                            icon={it.icon()}
                                            color={it.color}
                                            style={[
                                                {
                                                    transform: [{ scale: scales[i] }],
                                                    opacity: opacities[i],
                                                    backgroundColor: theme.colors.surface,
                                                },
                                                styles.defaultItemFabStyle,
                                                it.style,
                                            ]}
                                            onPress={() => {
                                                this.moveSelected(it, i);
                                            }}
                                            accessibilityLabel={typeof it.accessibilityLabel !== 'undefined' ? it.accessibilityLabel : it.label}
                                            accessibilityTraits="button"
                                            accessibilityComponentType="button"
                                            accessibilityRole="button"
                                        />
                                    )}
                                </View>
                            );
                        })}
                    </View>
                    <FAB
                        onPress={() => {
                            onPress && onPress();
                            this._toggle();
                        }}
                        large={large}
                        small={small}
                        icon={icon}
                        label={label}
                        color={this.props.color}
                        accessibilityLabel={accessibilityLabel}
                        accessibilityTraits="button"
                        accessibilityComponentType="button"
                        accessibilityRole="button"
                        style={[styles.fab, fabStyle]}
                        visible={visible}
                    />
                </SafeAreaView>
            </View>
        );
    }
}

polyfill(FABGroupAnimatedButton);

export default withTheme(FABGroupAnimatedButton);

const styles = EStyleSheet.create({
    popoverContainer: {
        padding: 10,
        borderRadius: 10,
    },
    popoverText: {
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
    infoIcon: {
        color: '$primaryWhite',
    },
    safeArea: {
        flex: 1,
        alignItems: 'flex-end',
        justifyContent: 'flex-end',
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'flex-end',
    },
    label: {
        textAlign: 'center',
        fontSize: 15,
        fontFamily: '$primaryFontNormal',
    },
    labelSub: {
        textAlign: 'center',
        fontSize: 18,
        fontFamily: '$primaryFontNormal',
        color: '$primaryWhite',
    },
    selectedButtonLabel: {
        color: '$primaryWhite',
        fontSize: 15,
    },
    fab: {
        // marginHorizontal: 16,
        // marginBottom: 16,
        // marginTop: 0,
    },
    backdrop: {
        ...StyleSheet.absoluteFillObject,
    },
    iconWrapper: {
        backgroundColor: '$primaryWhite',
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 5,
    },
    iconWrapperSub: {
        width: 40,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
    },
    fabMenWrapper: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 5,
        marginVertical: 8,
        marginHorizontal: 16,
        elevation: 2,
        backgroundColor: '$primaryWhite',
    },
    fabSubMenWrapper: {
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        marginVertical: 10,
        marginHorizontal: 10,
        elevation: 2,
        backgroundColor: '$primaryDarkBackground',
        width: 145,
        height: 120,
        elevation: 2,
    },
    item: {
        marginBottom: 16,
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    subItem: {},
    defaultItemFabStyle: {
        backgroundColor: '$primaryWhite',
    },
    selectedButtonWrapper: {
        position: 'absolute',
        backgroundColor: '$primarySelectedTextColor',
        borderRadius: 10,
        marginTop: 10,
        paddingRight: 5,
    },
    selectedButton: {
        paddingVertical: 15,
        paddingHorizontal: 10,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionsContainer: {
        marginBottom: 56,
    },
    actionsContainerSub: {
        marginBottom: 56,
        flexWrap: 'wrap',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        flexDirection: 'row',
    },
});
