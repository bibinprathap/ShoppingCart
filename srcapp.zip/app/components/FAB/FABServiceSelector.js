import * as React from 'react';
import { View, Animated, TouchableWithoutFeedback, StatusBar, SafeAreaView, TouchableOpacity, Image, BackHandler } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import { Text, Card, ActivityIndicatorm, Surface, CrossFadeIcon, DefaultTheme, withTheme } from 'react-native-paper';
import { Icon, FABGroup, FABGroupAnimated } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { selectService } from 'app/actions/inspections';
import images from 'app/images';
import FABGroupAnimatedButton from './FABGroupAnimatedButton';

class FABServiceSelector extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            fabIsOpen: false,
            FABGroupActions: this.initFABGroupActions(),
        };
        this.initFABGroupActions = this.initFABGroupActions.bind(this);
        this.selectEntityService = this.selectEntityService.bind(this);
        this.getMappedFABActions = this.getMappedFABActions.bind(this);
        this.newInspectionEntityPressed = this.newInspectionEntityPressed.bind(this);
    }

    backHandler;

    componentDidMount() {
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', this.handleBackPress);
    }

    componentWillUnmount() {
        this.backHandler.remove();
    }

    handleBackPress = () => {
        const { navigation } = this.props;
        if (navigation.state.routeName === 'dashboard') {
            if (this.state.fabIsOpen) {
                this.setState({ fabIsOpen: false });
                return true;
            }
        }
    };

    initFABGroupActions = () => {
        const { entities } = this.props;
        //const uniqueEntities = inspectionsHelper.findUniqueEntitiesIdFromServices({ services: this.props.services });
        const imageNameMap = { 12825: 'AWQAF', 1: 'ADAFSA', 52896: 'ADSSC', 2: 'EA', 3: 'ITC', 17310: 'ADDC', 1000: 'ADM', 1001: 'TADWEER' };
        const filteredEntities = [];
        entities.map((entity, index) => {
            //uncomment below line for getting entites from service
            //if (uniqueEntities.indexOf(entity.inspEntityId) == -1) return;

            const logoKey = `${imageNameMap[entity.inspEntityId]}Logo`;
            const entityImage = images.entities[logoKey] || {};
            const defaultHeight = 40;
            const defaultWidth = 40;
            const logoStyle = {
                width: entityImage.width || defaultWidth,
                height: entityImage.height || defaultHeight,
            };

            filteredEntities.push({
                isEntity: true,
                key: entity.inspEntityId,
                icon: props => <Image source={entityImage.content} style={logoStyle} {...props} />,
                data: entity,
                onPress: this.newInspectionEntityPressed,
            });
        });

        if (filteredEntities.length === 1) {
            const services = inspectionsHelper.findSubServices({ services: this.props.services, inspEntityId: filteredEntities[0].inspEntityId });
            if (services) {
                const FABGroupActions = this.getMappedFABActions(services);
                this.setState({ FABGroupActions });
                return FABGroupActions;
            }
        }

        return filteredEntities;
    };

    selectEntityService = service => {
        const { navigation, dispatch, services } = this.props;
        const subServices = inspectionsHelper.findSubServices({
            services,
            inspEntityId: service.inspEntityId,
            inspectionTypeId: service.inspectionTypeId,
        });
        if (subServices) {
            this.setState({ FABGroupActions: this.getMappedFABActions(subServices) });
        } else {
            inspectionsHelper.beginInspection({ inspEntityId: service.inspEntityId }, navigation);
            dispatch(selectService(service));
        }
    };

    getMappedFABActions = services => {
        return services.map((service, index) => {
            return {
                key: `${service.inspectionTypeId}`,
                data: service,
                onPress: this.selectEntityService,
                inspEntityId: service.inspEntityId,
                titleE: service.titleE,
                titleA: service.titleA,
                serviceDescE: service.serviceDescE,
                serviceDescA: service.serviceDescA,
                icon: service.icon ? props => <Icon {...service.icon} size={26} {...props} /> : null,
            };
        });
    };

    newInspectionEntityPressed = entity => {
        const { navigation } = this.props;
        const services = inspectionsHelper.findSubServices({ services: this.props.services, inspEntityId: entity.inspEntityId });
        if (services) {
            this.setState({ FABGroupActions: this.getMappedFABActions(services) });
        } else {
            inspectionsHelper.beginInspection({ inspEntityId: entity.inspEntityId }, navigation);
            this.setState({ fabIsOpen: false });
        }
        //console.log('newInspectionEntityPressed(), entity: ', entity);
    };

    render() {
        const newInspectionIcon = <Image source={images.new.content} resizeMode="contain" style={styles.fabNewInspectionIcon} />;
        if (!this.state.FABGroupActions || this.state.FABGroupActions.length === 0) return null;

        return (
            <FABGroupAnimatedButton
                large
                open={this.state.fabIsOpen}
                icon={newInspectionIcon}
                style={styles.fabGroupStyle}
                backdropColor="#2A2E4388"
                fabStyle={styles.fabGroupMainIcon}
                color="red"
                actions={this.state.FABGroupActions}
                onStateChange={({ open }) => this.setState({ fabIsOpen: open, FABGroupActions: this.initFABGroupActions() })}
                onPress={data => {
                    if (this.state.fabIsOpen) {
                    }
                }}
            />
        );
    }
}

const styles = EStyleSheet.create({
    fabNewInspectionIcon: {
        width: 30,
        height: 30,
        tintColor: '$primaryWhite',
    },
    fabGroupStyle: {
        position: 'absolute',
        paddingEnd: 35,
        paddingBottom: 25,
        right: 0,
        bottom: 0,
    },
    fabGroupMainIcon: {
        position: 'absolute',
        backgroundColor: '$primaryDarkBackground',
        right: 0,
        bottom: 0,
    },
});

export default FABServiceSelector;
