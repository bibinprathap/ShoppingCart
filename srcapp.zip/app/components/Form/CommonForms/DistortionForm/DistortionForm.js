import React, { Component } from 'react';
import { View, Picker, TextInput } from 'react-native';
import AppApi from 'app/api/real';
import { strings } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { connect } from 'react-redux';
import { AttachmentListWithDialog } from 'app/screens';
import { localeProperty } from 'app/config/i18n/i18n';
import { infoChanged } from 'app/actions/inspections';
import { checkDuplicate } from 'app/actions/inspections';
import styles from './styles';

const api = new AppApi();

const emptyDistrotionState = {
    agency: '',
    distortionType: '',
    distortionLevelLkdId: '',
    remarks: '',
    //attachmentList: [],
};

class DistortionForm extends Component {
    constructor(props) {
        super(props);
        const { attachmentList = [], rest } = emptyDistrotionState;
        this.state = { ...rest, attachmentList, ...props.values };
        this.handleAgencyChange = this.handleAgencyChange.bind(this);
        this.getSLAlevelOptions = this.getSLAlevelOptions.bind(this);
    }

    getDistrotionStateForEditMode = violator => {
        const newState = { ...violator };
        if (!newState.integrationData) newState.integrationData = { success };
        return newState;
    };

    updateDistrotionState = newState => {
        const { dispatch } = this.props;
        this.setState(newState, () => {
            const { agency, distortionType, distortionLevelLkdId, attachmentList, remarks } = this.state;
            const stateToStore = { agency, distortionType, distortionLevelLkdId, remarks, attachmentList };
            dispatch(infoChanged('distortionForm', stateToStore, 0));
        });
    };
    getSLAlevelOptions(value) {
        const { agencyoptions } = this.props;
        const { agency } = this.state;
        // const newState = {};
        const distortiontypeOptions = (agencyoptions.find(c => c.id == agency) || {}).distortionType || [];
        return (distortiontypeOptions.find(c => c.id == value) || {}).slaLevels || [];
    }

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateDistrotionState(newState);
        if (name == 'distortionType' && value) {
            //debugger;
            const distortionLevelOptions = this.getSLAlevelOptions(value);
            if (distortionLevelOptions.length > 0) {
                newState['distortionLevelLkdId'] = distortionLevelOptions[0].id;
                this.updateDistrotionState(newState);
            }

            setTimeout(() => {
                this.props.dispatch(checkDuplicate());
            }, 300);
        }
    };

    handleAgencyChange = async value => {
        const name = 'agency';
        const newState = {};
        newState[name] = value;
        newState['distortionType'] = '';
        this.updateDistrotionState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateDistrotionState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateDistrotionState(newState);
    };

    render = () => {
        const { agencyoptions } = this.props;
        const { agency, distortionType, distortionLevelLkdId, attachmentList = [], remarks } = this.state;

        const editable = true;

        const distortiontypeOptions = (agencyoptions.find(c => c.id == agency) || {}).distortionType || [];
        const distortionLevelOptions = (distortiontypeOptions.find(c => c.id == distortionType) || {}).slaLevels || [];

        const textInputTheme = {
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };

        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('agency')}</Text>
                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                            <Picker
                                selectedValue={agency}
                                key={`agency_${agencyoptions.length}`}
                                enabled={editable}
                                style={styles.picker}
                                onValueChange={this.handleAgencyChange}
                            >
                                <Picker.Item key="notselected" label={strings('pleaseselect') + ' ' + strings('agency')} value="" />
                                {agencyoptions &&
                                    agencyoptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                </View>
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('distortiontype')}</Text>
                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                            <Picker
                                selectedValue={distortionType}
                                key={`distortiontype_${distortiontypeOptions.length}`}
                                enabled={editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'distortionType')}
                            >
                                <Picker.Item key="notselected" label={strings('pleaseselect') + ' ' + strings('distortiontype')} value="" />
                                {distortiontypeOptions &&
                                    distortiontypeOptions.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                </View>

                {distortionLevelOptions.length > 0 ? (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <Text style={styles.label}> {strings('distortionLevelLkdId')}</Text>
                            <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                <Picker
                                    selectedValue={distortionLevelLkdId}
                                    key={`slaLevels_${distortionLevelOptions.length}`}
                                    enabled={editable}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'distortionLevelLkdId')}
                                >
                                    {distortionLevelOptions &&
                                        distortionLevelOptions.map((v, i) => {
                                            return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                        })}
                                </Picker>
                            </View>
                        </View>
                    </View>
                ) : null}
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={[styles.fieldContainer]}>
                            <TextInput
                                style={styles.input}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                theme={textInputTheme}
                                value={remarks}
                                editable={editable}
                                placeholder={strings('remarks')}
                                placeholderStyle={{ color: '#000000' }}
                                multiline
                            />
                        </View>
                    </View>
                </View>

                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer}>
                            <AttachmentListWithDialog
                                editable={editable}
                                onAdd={this.handleOnAddAttachment}
                                onRemove={this.handleOnRemoveAttachment}
                                attachments={attachmentList}
                            />
                        </View>
                    </View>
                </View>
            </View>
        );
    };
}
const mapStateToProps = (state, ownProps) => {
    const { dataLookups } = state.masterdata;
    return {
        agencyoptions: dataLookups.agency,
    };
};

export default connect(mapStateToProps)(DistortionForm);
