import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager } from 'react-native';
import AppApi from 'app/api/real';
import { connect } from 'react-redux';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import styles from './styles';
import { Icon, AttachmentList, Switch, commonStyles, Loader, Modal, ReconciliationPreview } from 'app/components';
import { Attachments } from 'app/screens';

import { ValidationHelper } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import { infoChanged, getViolationActionTypes, addViolatorSignature, TASK_STARTED } from 'app/actions/inspections';
import * as yup from 'yup';
import { ViolationActionReview } from 'app/components/Preview/ViolationItemReview';
import ViolationList from 'app/screens/inspection/ViolationDetails/ViolationList';

const api = new AppApi();

const emptyEngineerReviewApproved = {
    registeredAmount: '',
    selectedPeriod: '',
    selectedPeriodType: 'day',
    isResolved: false,
    isPresent: false,
    reconciled: false,
    remarks: '',
    followupAction: '',
    attachmentList: [],
    attachmentModalVisible: false,
    selectedAttachment: null,
    errorLogs: {},
    violationActionTypes: [],
    signature: null,
};

class EngineerReviewApproved extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ...emptyEngineerReviewApproved,
            ...props.initialValue,
            violationActionTypes: props.actionTypeOptions,
            reconciliationDialogVisible: false,
        };

        this.updateEngineerReviewApprovedState = this.updateEngineerReviewApprovedState.bind(this);
        this.handleOnAdd = this.handleOnAdd.bind(this);
        this.handleAttachmentRemoved = this.handleAttachmentRemoved.bind(this);
        this.handleThumbnailPressed = this.handleThumbnailPressed.bind(this);
        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleActionChange = this.handleActionChange.bind(this);
        this.handleReconciliation = this.handleReconciliation.bind(this);
        this.isSubmitable = this.isSubmitable.bind(this);
    }
    handleOnViolatorSelected = async (newValue, currentVisitIndex, inspection) => {
        await this.props.dispatch(
            getViolationActionTypes({
                workflowConst: inspection.inspectionTypeDetail && inspection.inspectionTypeDetail.workflowConst,
                inspViolationTypeId: newValue.violationTypeIds[0],
                violator: inspection.violators[0],
                currentVisitIndex,
                inspTypeCheckItemId: newValue.inspTypeCheckItemId,
                inspInstanceId: inspection.inspectionId,
                location: inspection.location,
            })
        );
    };
    componentDidMount() {
        const { inspection, visitIndex, readOnly } = this.props;
        if (!readOnly) {
            // const { visitIndex } = inspectionsHelper.getCurrentVisit(inspection);
            const currentVisitCheckListValues = visitIndex != undefined ? inspection.visits[visitIndex].values : undefined;

            const violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);
            if (violationItems.length == 0) {
                const buildingPenaltiesForm = inspection.visits[0].buildingPenaltiesForm;
                const newValue = {
                    violationTypeIds: buildingPenaltiesForm.violationTypeIds,
                    inspTypeCheckItemId: buildingPenaltiesForm.inspTypeCheckItemId,
                    checkItemId: buildingPenaltiesForm.checkItemId,
                    checkItemNameA: buildingPenaltiesForm.checkItemNameA,
                    checkItemNameE: buildingPenaltiesForm.checkItemNameE,
                    inspViolationTypeNameA: buildingPenaltiesForm.inspViolationTypeNameA,
                    inspViolationTypeNameE: buildingPenaltiesForm.inspViolationTypeNameE,
                    selectedOption: buildingPenaltiesForm.selectedOption,
                    violatorId: buildingPenaltiesForm.violatorId,
                };
                this.props.dispatch(infoChanged('values', [newValue], visitIndex));
                this.handleOnViolatorSelected(newValue, visitIndex, inspection);
            }
            if (this.isSubmitable) this.isSubmitable();
        }
    }
    resetViolatorState = () => {
        this.updateEngineerReviewApprovedState(emptyEngineerReviewApproved);
    };

    updateEngineerReviewApprovedState = async newState => {
        let formValue = { ...this.state, ...newState };
        if (formValue.followupAction == 0) {
            formValue = { ...formValue, followupAction: '' };
        }
        const { actionTypeOptions } = this.props;
        const followupValidationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        if (formValue.isResolved == null || formValue.isResolved == false) {
            // followupValidationSchema.selectedPeriodType = yup.string().required();
            followupValidationSchema.followupAction = yup.string().required();
            const actionItem = inspectionsHelper.findViolationAction({
                violationActionTypes: actionTypeOptions,
                selectedActionType: formValue.followupAction,
            });
            if (actionItem && actionItem.constant == 'warning') {
                followupValidationSchema.selectedPeriodType = yup.string().required();
                followupValidationSchema.selectedPeriod = yup.number().required();
            }
        }

        let errorLogs = {};

        try {
            await ValidationHelper.validate(formValue, yup.object().shape(followupValidationSchema));
        } catch (errors) {
            //            return;
            Object.getOwnPropertyNames(errors).map(er => {
                errorLogs[er] = errors[er];
            });
        }

        newState.errorLogs = errorLogs;

        this.setState(newState, () => {
            const { visitIndex } = this.props;

            const {
                registeredAmount,
                selectedPeriod,
                selectedPeriodType,
                isResolved,
                isPresent,
                reconciled,
                remarks,
                followupAction,
                attachmentList,
                violationActionTypes,
                signature,
            } = this.state;

            const newFollowupFormvalue = {
                registeredAmount,
                selectedPeriod,
                selectedPeriodType,
                isResolved,
                isPresent,
                reconciled,
                remarks,
                followupAction,
                attachmentList,
                violationActionTypes,
                signature,
            };
            this.props.dispatch(infoChanged('followupForm', newFollowupFormvalue, visitIndex));
            this.isSubmitable();
            if (newState.signature) {
                const { dispatch, inspection } = this.props;
                dispatch(addViolatorSignature({ violatorId: inspection.violators[0].violatorId, attachment: newState.signature }));
            }
            // await dispatch(updateViolation(params, visitIndex, inspTypeCheckItemId, reset));
        });
    };
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleOnAdd = newAttachment => {
        const { attachmentList } = this.state;
        const newAttachmentsArray = attachmentList ? attachmentList.slice() : [];
        newAttachmentsArray.push(newAttachment);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateEngineerReviewApprovedState(newState);
    };
    handleAttachmentRemoved = doc => {
        const { attachmentList } = this.state;
        const currentAttachments = attachmentList;
        const newAttachmentsArray = _.without(currentAttachments, doc);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateEngineerReviewApprovedState(newState);
    };
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleCameraPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateEngineerReviewApprovedState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );
    isSubmitable = async () => {
        const { errorLogs, attachmentList, remarks } = this.state;
        const isAllowedToSave =
            (!errorLogs || (errorLogs && Object.getOwnPropertyNames(errorLogs).length == 0)) &&
            attachmentList &&
            attachmentList.length > 0 &&
            remarks &&
            remarks.length > 0;
        if (this.props.isSubmitable) this.props.isSubmitable({ isAllowedToSave });
    };

    handleActionChange = callProps => {
        const { params, inspTypeCheckItemId, reset } = callProps;
        if (reset) {
            this.updateEngineerReviewApprovedState({
                registeredAmount: params.amount != undefined ? params.amount : this.state.registeredAmount,
                followupAction: params.selectedActionType != undefined ? params.selectedActionType : this.state.followupAction,
                selectedPeriod: params.selectedPeriod != undefined ? params.selectedPeriod : this.state.selectedPeriod,
                selectedPeriodType: params.selectedPeriodType != undefined ? params.selectedPeriodType : this.state.selectedPeriodType,
                actionDetails: params,
            });
        } else {
            this.updateEngineerReviewApprovedState(params);
        }
    };
    handleonReconciled = async params => {
        if (params.attachment) {
            this.updateEngineerReviewApprovedState({
                reconciled: params.reconciled,
                signature: params.attachment,
            });
        } else {
            this.updateEngineerReviewApprovedState({
                reconciled: params.reconciled,
            });
        }
    };
    handleReconciliation = () => {
        this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible }, () => {
            if (!this.state.reconciliationDialogVisible) this.setState({ reconciliationDialogVisible: !this.state.reconciliationDialogVisible });
        });
    };

    render = () => {
        const {
            registeredAmount,
            selectedPeriod,
            selectedPeriodType,
            isResolved,
            isPresent,
            remarks,
            followupAction,
            violationActionTypes,
            attachmentList,
            errorLogs,
            reconciled,
        } = this.state;

        const customFieldContainerStyles = [styles.fieldContainerShadowed, styles.customFieldRowContainer, { padding: 10 }];
        const { visitIndex, actionTypeOptions, violator, violation, editable, inspection, readOnly } = this.props;
        let actionItem = inspectionsHelper.findViolationAction({
            violationActionTypes: actionTypeOptions,
            selectedActionType: followupAction,
        });
        let violationItems = [];
        const newInspection = { ...inspection };
        let actionItemDetails = {};
        if (readOnly) {
            const newFollowupForm = inspection.visits[visitIndex].followupForm;
            actionItem = inspectionsHelper.findViolationAction({
                violationActionTypes: actionTypeOptions,
                selectedActionType: newFollowupForm.followupAction,
            });
            const buildingPenaltiesForm = inspection.visits[0].buildingPenaltiesForm;
            const newValue = {
                violationTypeIds: buildingPenaltiesForm.violationTypeIds,
                inspTypeCheckItemId: buildingPenaltiesForm.inspTypeCheckItemId,
                checkItemId: buildingPenaltiesForm.checkItemId,
                checkItemNameA: buildingPenaltiesForm.checkItemNameA,
                checkItemNameE: buildingPenaltiesForm.checkItemNameE,
                inspViolationTypeNameA: buildingPenaltiesForm.inspViolationTypeNameA,
                inspViolationTypeNameE: buildingPenaltiesForm.inspViolationTypeNameE,
                selectedOption: buildingPenaltiesForm.selectedOption,
                violatorId: buildingPenaltiesForm.violatorId,
            };

            let currentVisitCheckListValues =
                visitIndex != undefined
                    ? [
                          {
                              ...newValue,
                              selectedActionTypeConst: actionItem.constant,
                              reconciled: newFollowupForm.reconciled,
                              isPresent: newFollowupForm.isPresent,
                              //   isPresent: true,
                              //   reconciled: true,
                          },
                      ]
                    : undefined;
            violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);
            newInspection.violators[0].isPresent = newFollowupForm.isPresent;

            actionItemDetails = {
                registeredAmount: newFollowupForm.registeredAmount,

                selectedPeriod: newFollowupForm.selectedPeriod,
                selectedPeriodType: newFollowupForm.selectedPeriodType,
            };
        } else {
            let { currentVisitIndex, currentVisit } = inspectionsHelper.getCurrentVisit(inspection);
            let currentVisitCheckListValues = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex].values : undefined;
            violationItems = inspectionsHelper.getViolationItems(currentVisitCheckListValues);
            newInspection.violators[0].isPresent = this.state.isPresent;
        }
        // const isAllowedToSave = Object.getOwnPropertyNames(errorLogs).length == 0 && (attachmentList || '').length > 0 && (remarks || '').length > 0;
        //const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonPositive : styles.buttonPositiveDisabled;
        //const saveTextstyle = isAllowedToSave && editable == true ? styles.buttonText : styles.buttonTextPositiveDisabled;

        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={customFieldContainerStyles}>
                        <Switch
                            editable={editable}
                            onChange={this.handleFieldChange.bind(this, 'isResolved')}
                            value={isResolved}
                            label={strings('isItResolved')}
                            iconProps={{ name: 'shield-check', type: 'MaterialCommunityIcons', size: 24 }}
                        />
                    </View>
                </View>

                {!isResolved ? (
                    <>
                        <View style={styles.fieldrow}>
                            <View style={customFieldContainerStyles}>
                                <Switch
                                    editable={editable}
                                    onChange={this.handleFieldChange.bind(this, 'isPresent')}
                                    value={isPresent}
                                    label={strings('violatorIsPresent')}
                                    iconProps={{ name: 'face', type: 'MaterialCommunityIcons', size: 24 }}
                                />
                            </View>
                        </View>
                        <ViolationList
                            dispatch={() => {}}
                            inspection={newInspection}
                            hideEditAndDelete={true}
                            editable={editable}
                            violationItems={violationItems.map(v => {
                                if (readOnly) return v;
                                else
                                    return {
                                        ...v,
                                        ...this.state.actionDetails,
                                        isPresent: this.state.isPresent,
                                        selectedActionTypeConst: actionItem ? actionItem.constant : v.selectedActionTypeConst,
                                        registeredAmount: registeredAmount,
                                        selectedActionType: followupAction,
                                        reconciled,
                                        selectedPeriod,
                                        selectedPeriodType,
                                    };
                            })}
                            onActionChange={this.handleActionChange}
                            onReconciled={this.handleonReconciled}
                        />
                        {this.state.reconciliationDialogVisible ? (
                            <ReconciliationPreview
                                readOnly={true}
                                currentInspectionVersion={1}
                                violatorId={newInspection.violators[0].violatorId}
                                values={{ reconciled: !!newInspection.violators[0].signature, signature: newInspection.violators[0].signature }}
                                dispatch={() => {}}
                                navigation={this.props.navigation}
                            />
                        ) : null}
                        {readOnly && newInspection.violators[0].signature ? (
                            <TouchableNativeFeedback onPress={(e, props) => this.handleReconciliation(newInspection.violators[0], 1)}>
                                <View style={styles.violatorInfoClickArea}>
                                    <Icon type="AdmIcon" name="wf-1210" size={25} style={[styles.icon, styles.iconActive]} />
                                </View>
                            </TouchableNativeFeedback>
                        ) : null}
                        {actionItem && readOnly ? (
                            <View style={styles.ViolationActionContainer}>
                                <ViolationActionReview
                                    selectedActionTypeConst={actionItem.constant}
                                    registeredAmount={registeredAmount}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                ></ViolationActionReview>
                            </View>
                        ) : null}
                    </>
                ) : null}
                {errorLogs.followupAction ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('actionType') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {errorLogs.selectedPeriod ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('selectedPeriod') + ' ' + strings('isRequired')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer} />
                    </View>
                </View>

                <View style={styles.fieldContainerAttachement}>
                    <Modal
                        animationType="slide"
                        transparent={false}
                        visible={this.state.attachmentModalVisible}
                        onRequestClose={this.toggleAttachmentDialog}
                    >
                        <Attachments
                            attachments={attachmentList}
                            onAdd={this.handleOnAdd}
                            onRemove={this.handleAttachmentRemoved}
                            onClose={this.handleOnClose}
                            selectedAttachment={this.state.selectedAttachment}
                            editable={editable}
                            attachmentModalVisible={this.state.attachmentModalVisible}
                        />
                    </Modal>
                    {!attachmentList || !attachmentList.length ? (
                        <View
                            style={[
                                styles.outerContainerNoAttachment,
                                { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, marginHorizontal: 12 },
                            ]}
                        >
                            {editable ? <View style={[styles.fieldContainerAttachement, { flex: 1 }]}>{this.renderAddPictureButton()}</View> : null}
                        </View>
                    ) : (
                        <View style={[styles.outerContainerNoAttachment]}>
                            <View
                                style={[
                                    styles.outerContainerWithAttachment,

                                    { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, marginHorizontal: 12 },
                                ]}
                            >
                                <AttachmentList attachments={attachmentList} editable={editable} onPress={this.handleThumbnailPressed} />
                                {editable ? <View style={styles.buttonWithAttachmentsContainer}>{this.renderAddPictureButton()}</View> : null}
                            </View>
                        </View>
                    )}
                </View>
                {errorLogs.attachmentList ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={[styles.fieldContainer]}>
                            <TextInput
                                style={styles.input}
                                placeholder={strings('newRemarks')}
                                value={remarks}
                                editable={editable}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                autoCorrect={false}
                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                autoCapitalize="sentences"
                                //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                autoFocus={false}
                                multiline={true}
                                textAlignVertical={'top'}
                            />
                        </View>
                    </View>
                </View>
                {errorLogs.remarks ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {/* {!readOnly ? (
                    <View style={[styles.summaryContainer]}>
                        <View style={styles.summaryItem}>
                            <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="content-save"
                                    borderRadius={25}
                                    disabled={!(isAllowedToSave && editable)}
                                    style={[styles.button, saveButtonstyle]}
                                    onPress={this.handleSave}
                                >
                                    <Text style={saveTextstyle}>{strings('save')}</Text>
                                </IconButton>
                            </Loader>
                        </View>
                    </View>
                ) : null} */}
            </View>
        );
    };
}

export default EngineerReviewApproved;
