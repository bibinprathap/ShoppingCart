import React, { Component } from 'react';
import { View, TextInput, TouchableOpacity, Picker, I18nManager, Image } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import moment from 'moment';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Switch, commonStyles, Icon, IntegrationFeedback, SimpleItemInfo, SimpleViolatorInfo } from 'app/components';
import { infoChanged, getActionTypes, checkDuplicate, inspectionViolatorAdded } from 'app/actions/inspections';
import { AttachmentListWithDialog } from 'app/screens';
import { lookup } from 'app/api/helperServices';
import { ItemSelectorDialog, ImageDialog, ViolationActionTypes as ViolationActionTypesComponent } from 'app/screens';
import { inspectionsHelper } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { store } from 'app/config/store';
import serverEnvConfig from 'app/api/config';
// import { ViolationActionReview } from 'app/components/Preview/ViolationItemReview';
import { ViolationItemReview } from 'app/components/Preview/ViolationItemReview';
const api = new AppApi();

const inspectionFields = {
    tradeLicenseNumber: '',
    permitNumber: null,
    remarks: null,
    attachmentList: [],
    violationActionTypes: [],
    expiryDate: null,
    contractDetails: null,
    violatorId: null,
    followsTermsOfContract: true,
    searchType: 'tradeLicenseNumber',
    selectedActionType: null,
    selectedPeriod: null,
    selectedPeriodType: null,
    isContractExpiringInDays: null,
    amount: 0,
};

const displayFields = [
    'municipalityName',
    'districtName',
    'community',
    'permitTypeName',
    'permitNumber',
    'stopNumber',
    'rentContractStartDate',
    'rentContractEndDate',
];

const searchOption = ['permitNumber', 'tradeLicenseNumber'];

class FoodTruckAndOutdoor extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitStateValues(props);
        this.searchContractOrTradeLicense = this.searchContractOrTradeLicense.bind(this);
        this.renderCustomActions = this.renderCustomActions.bind(this);
        this.removeContractDetails = this.removeContractDetails.bind(this);
        this.handleActionTypes = this.handleActionTypes.bind(this);
        this.handleOnAddAttachment = this.handleOnAddAttachment.bind(this);
        this.handleOnRemoveAttachment = this.handleOnRemoveAttachment.bind(this);
    }

    getInitStateValues = props => {
        return {
            ...inspectionFields,
            permitNumber: props.permitNumber,

            attachmentModalVisible: false,
            integrationData: {},
            showDialog: false,
            showImageDialog: false,
            customerWithMultipleContacts: null,
            attachmentList: [],
            loadingActions: false,
            errorLogs: {},
            ...(props.values || {}),
        };
    };

    searchFieldRef;

    updateState = async newState => {
        return this.setState(newState, () => {
            const { visitIndex } = this.props;
            const stateValuesTobeUpdated = _.pick(this.state, Object.keys(inspectionFields));
            this.props.dispatch(infoChanged('foodTruckAndOutdoorSeating', stateValuesTobeUpdated, visitIndex));
        });
    };

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = { violationActionTypes: (this.props.values && this.props.values.violationActionTypes) || [] };
        const { searchType, contractDetails, permitNumber, violatorId } = this.state;
        if (name == 'searchType' && value !== searchType) {
            newState['integrationData'] = {};
            newState['permitNumber'] = null;
            newState['tradeLicenseNumber'] = null;
        }
        if (name == 'permitNumber' || name == 'tradeLicenseNumber') newState['integrationData'] = {};

        if (name === 'followsTermsOfContract' && violatorId) {
            const violator = this.props.inspection.violators && _.find(this.props.inspection.violators, v => v.violatorId == violatorId);
            this.handleActionTypes({ value, permitNumber, contractDetails, violator });
        }

        if (name === 'followsTermsOfContract' && value === true) {
            newState['selectedActionType'] = null;
            newState['selectedPeriod'] = null;
            newState['selectedPeriodType'] = null;
            newState['violationActionTypes'] = [];
        }

        if (
            (contractDetails && name == 'permitNumber' && value != contractDetails.permitNumber) ||
            (contractDetails && name == 'tradeLicenseNumber' && value != contractDetails.tradeLicenseNumber)
        ) {
            newState['integrationData'] = {};
            newState['contractDetails'] = null;
        }

        newState[name] = value;
        this.updateState(newState);
    };

    // shouldComponentUpdate(nextProps, nextState) {
    //     return shallowEqual(this.props, nextProps, this.state, nextState);
    // }

    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };

    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateState(newState);
    };

    handleActionTypes = async ({ followsTermsOfContract, permitNumber, contractDetails, violator }) => {
        const { inspection, visitIndex } = this.props;
        const isContractExpiringInDays = this.getContractExpiringInDays(contractDetails.rentContractEndDate);
        if ((violator && permitNumber && isContractExpiringInDays < 0) || !followsTermsOfContract || !permitNumber) {
            this.setState({ loadingActions: true });
            await this.props
                .dispatch(
                    getActionTypes({
                        workflowConst: inspection.inspectionTypeDetail.workflowConst,
                        currentVisitIndex: visitIndex || 0,
                        formName: 'foodTruckAndOutdoorSeating',
                        inspInstanceId: inspection.inspectionId,
                        violatorId: violator.violatorId,
                        violatorType: violator.violatorType,
                        followsTermsOfContract,
                        permitNumber,
                        location: inspection.location,
                    })
                )
                .then(() => {
                    this.setState({ loadingActions: false });
                });
        }
    };

    searchContractOrTradeLicense = async () => {
        const { searchType, permitNumber, tradeLicenseNumber, followsTermsOfContract } = this.state;
        const { inspection, visitIndex } = this.props;
        let integrationData = { running: true, message: strings('verifying') };
        let newState = { integrationData };
        this.updateState(newState);
        try {
            let params = { inspectionInstanceId: inspection.inspectionId, location: inspection.location };
            searchType === 'permitNumber' ? (params.contractNumber = permitNumber || null) : (params.tradeLicenseNumber = tradeLicenseNumber || null);
            const result = await api.getFoodTruckContract(params);
            integrationData = { running: false, success: true, message: strings('integrationSuccessMessageContract') };
            const { contracts, customer } = result || {};
            if (contracts && contracts.length === 1) {
                const contract = contracts[0];
                contract.rentContractStartDate = moment(contract.rentContractStartDate).format('YYYY-MM-DD');
                contract.rentContractEndDate = moment(contract.rentContractEndDate).format('YYYY-MM-DD');
                const permitNumber = contract && contract.permitNumber;
                const isContractExpiringInDays = this.getContractExpiringInDays(contract.rentContractEndDate);
                newState = {
                    contractDetails: contract,
                    violatorId: result.customer && result.customer.violatorId,
                    customerWithMultipleContacts: null,
                    integrationData,
                    permitNumber,
                    isContractExpiringInDays,
                };
                this.handleActionTypes({ followsTermsOfContract, permitNumber, contractDetails: contract, violator: customer });
                this.props.dispatch(inspectionViolatorAdded({ violator: customer, reset: true }));
            } else if (contracts && contracts.length > 1) {
                const mappedContract = _.map(contracts, contract => {
                    contract.rentContractStartDate = moment(contract.rentContractStartDate).format('YYYY-MM-DD');
                    contract.rentContractEndDate = moment(contract.rentContractEndDate).format('YYYY-MM-DD');
                    return contract;
                });
                result.contracts = mappedContract;

                newState = {
                    integrationData,
                    showDialog: true,
                    violatorId: null,
                    customerWithMultipleContacts: result,
                };
            } else {
                integrationData = { running: false };
                newState = { integrationData, showDialog: false };
                alertsHelper.show('warn', strings('noResults'), strings('noResults'));
            }
        } catch (e) {
            if (!e.isCancel) {
                integrationData = { running: false, success: false, error: e, message: strings('integrationErrorMessageContract') };
                newState = {
                    integrationData,
                };
            }
        } finally {
            this.updateState(newState);
        }
    };

    handleDialogOnRequestClose = contractDetails => {
        this.setState({ showDialog: false });
        const { customerWithMultipleContacts, followsTermsOfContract } = this.state;
        if (!contractDetails || !customerWithMultipleContacts) return;
        const permitNumber = contractDetails.permitNumber;
        const isContractExpiringInDays = this.getContractExpiringInDays(contractDetails.rentContractEndDate);

        this.updateState({
            contractDetails: contractDetails,
            violatorId: customerWithMultipleContacts.customer.violatorId,
            permitNumber,
            isContractExpiringInDays,
            integrationData: {},
        });
        this.handleActionTypes({ followsTermsOfContract, permitNumber, contractDetails, violator: customerWithMultipleContacts.customer });
        this.props.dispatch(inspectionViolatorAdded({ violator: customerWithMultipleContacts.customer, reset: true }));
    };

    handleImageDialogOnRequestClose = item => {
        this.setState({ showImageDialog: false });
    };

    removeContractDetails = item => {
        this.updateState({
            contractDetails: null,
            violatorId: null,
            customerWithMultipleContacts: null,
            tradeLicenseNumber: null,
            permitNumber: null,
            integrationData: {},
            selectedActionType: null,
            violationActionTypes: [],
            selectedPeriod: null,
            selectedPeriodType: null,
            amount: 0,
        });
    };

    showZoomableImage = currentImageSource => {
        this.setState({ showImageDialog: true, currentImageSource });
    };

    getContractImagePath = imageURL => {
        const env = store.getState().settings.environment;
        let baseURL = serverEnvConfig[env].baseURL;
        return baseURL.replace('/api', `/${imageURL}`);
    };

    renderCustomActions = ({ item }) => {
        const { editable } = this.props;
        return (
            <View>
                {editable && (
                    <TouchableOpacity style={styles.removeIconWrapper} onPress={this.removeContractDetails}>
                        <Icon type="MaterialCommunityIcons" name={'close-circle'} size={24} />
                    </TouchableOpacity>
                )}
                {item.imageURL && (
                    <TouchableOpacity onPress={() => this.showZoomableImage({ uri: this.getContractImagePath(item.imageURL) })}>
                        <Image source={{ uri: this.getContractImagePath(item.imageURL) }} style={styles.contractImage} />
                    </TouchableOpacity>
                )}
            </View>
        );
    };

    handleActionChange = callProps => {
        const { params, reset } = callProps;
        this.updateState({
            amount: params.amount != undefined ? params.amount : this.state.amount,
            selectedActionType: params.selectedActionType != undefined ? params.selectedActionType : this.state.selectedActionType,
            selectedPeriod: params.selectedPeriod != undefined ? params.selectedPeriod : this.state.selectedPeriod,
            selectedPeriodType: params.selectedPeriodType != undefined ? params.selectedPeriodType : this.state.selectedPeriodType,
            violationActionTypes: (this.props.values && this.props.values.violationActionTypes) || [],
        });
    };

    getContractExpiringInDays = dt => {
        if (!dt) return null;
        return moment(dt, 'YYYY-MM-DD').diff(moment(), 'days');
    };

    render() {
        const { dispatch, inspection, formName, readOnly, editable, currentInspectionVersion, values, visitValues } = this.props;
        const { integrationData, showDialog, showImageDialog, customerWithMultipleContacts, currentImageSource } = this.state;
        const {} = this.state;

        let { violationActionTypes, selectedActionType, selectedPeriod, selectedPeriodType, amount, registeredAmount, selectedActionTypeConst } =
            values || {};

        debugger;
        const actionItem =
            selectedActionType &&
            inspectionsHelper.findViolationAction({
                violationActionTypes,
                selectedActionType,
            });

        const actionItemConstant = (actionItem && actionItem.constant) || selectedActionTypeConst || null;
        const displaySource = this.props.readOnly ? this.props.values : this.state;
        const {
            attachmentList,
            remarks,
            followsTermsOfContract,
            isContractExpiringInDays,
            violatorId,
            contractDetails,
            permitNumber,
            tradeLicenseNumber,
            searchType,
        } = displaySource || {};
        let errorLogs = this.props.errorLogs || {};

        const isSearching = integrationData.running == true;
        const searchVal = searchType == 'tradeLicenseNumber' ? tradeLicenseNumber : permitNumber;
        const isSearchDisabled = isSearching || !searchVal || !searchVal.length || !editable;
        //const searchButtonstyle = isSearchDisabled ? styles.buttonDisabled : styles.buttonActive;
        const searchButtonstyle = styles.buttonActive;

        const readOnlyRtlStyles = I18nManager.isRTL
            ? { textAlign: 'right', alignSelf: 'flex-start' }
            : { textAlign: 'left', alignSelf: 'flex-start' };

        const service = inspection.inspectionTypeDetail;
        const violator = violatorId && inspection.violators && _.find(inspection.violators, v => v.violatorId == violatorId);
        const showViolationActionTypes = !followsTermsOfContract || isContractExpiringInDays < 0 || (readOnly && actionItemConstant);
        const errorlogiolationItemReview = {};
        if (errorLogs.attachmentList) errorlogiolationItemReview.attachement = errorLogs.attachmentList;
        if (errorLogs.remarks) errorlogiolationItemReview.remark = errorLogs.remarks;
        const errorlogiolationItemReviewArray = errorLogs.attachmentList || errorLogs.remarks ? [errorlogiolationItemReview] : [];
        return (
            <View style={styles.contentContainer} key={{ formName }} key={this.props.key}>
                <ItemSelectorDialog
                    isVisible={showDialog}
                    items={customerWithMultipleContacts && customerWithMultipleContacts.contracts}
                    onRequestClose={this.handleDialogOnRequestClose}
                    displayFields={displayFields}
                    detailedDisplayFields={displayFields}
                    title={strings('select')}
                />
                <ImageDialog
                    isVisible={showImageDialog}
                    source={currentImageSource}
                    onRequestClose={this.handleImageDialogOnRequestClose}
                    title={strings('back')}
                />
                <View style={styles.titleContainer}>
                    <TouchableOpacity
                        onPress={() => searchType === 'tradeLicenseNumber' && !readOnly && this.updateState({ tradeLicenseNumber: 'CN-2518654' })}
                    >
                        <Text style={[commonStyles.generalHeading]}>
                            {inspection.inspectionTypeDetail && localeProperty(inspection.inspectionTypeDetail, 'title')}
                        </Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.field}>
                    <View style={styles.fieldrow}>
                        {!readOnly && (
                            <View style={styles.fieldContainerPicker}>
                                <Picker
                                    selectedValue={searchType}
                                    itemStyle={styles.pickerItem}
                                    enabled={editable}
                                    onValueChange={this.handleFieldChange.bind(this, 'searchType')}
                                >
                                    {searchOption &&
                                        searchOption.map((v, i) => {
                                            return <Picker.Item label={strings(v) || 'Unknown Type'} value={v} />;
                                        })}
                                </Picker>
                            </View>
                        )}
                        {readOnly ? (
                            <View style={styles.fieldrow}>
                                <Text style={styles.label}>{strings('permitNumber')}</Text>
                                <Text style={[styles.label, styles.highlight]}>
                                    {searchType == 'tradeLicenseNumber' ? tradeLicenseNumber : permitNumber}
                                </Text>
                            </View>
                        ) : (
                            <View style={styles.fieldContainer}>
                                <TextInput
                                    style={styles.input}
                                    placeholder={strings(searchType)}
                                    value={searchType == 'tradeLicenseNumber' ? tradeLicenseNumber : permitNumber}
                                    editable={editable}
                                    onChangeText={this.handleFieldChange.bind(this, searchType)}
                                    autoCorrect={false}
                                    direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                    autoCapitalize="sentences"
                                    multiline={true}
                                    textAlignVertical={'top'}
                                />
                                <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                    {integrationData && <IntegrationFeedback integrationData={integrationData} />}
                                </View>
                                <TouchableOpacity
                                    onPress={!isSearching && this.searchContractOrTradeLicense}
                                    style={[styles.buttonSearch, searchButtonstyle]}
                                >
                                    <Icon type="MaterialCommunityIcons" name="magnify" size={25} />
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                    {readOnly && errorLogs.permitNumber && (
                        <Text style={[commonStyles.ValidationMessageText, styles.error]}>
                            {strings('permitNumber') + ' ' + strings('isRequired')}
                        </Text>
                    )}
                </View>
                {contractDetails && violator && (
                    <View style={styles.field}>
                        <View style={styles.field}>
                            <View style={styles.contractInfoWrapper}>
                                <SimpleItemInfo
                                    item={contractDetails}
                                    displayFields={displayFields}
                                    hideDetailsButton={true}
                                    customActions={this.renderCustomActions}
                                />
                            </View>
                            {contractDetails && typeof isContractExpiringInDays == 'number' && isContractExpiringInDays < 0 && (
                                <View style={styles.field}>
                                    <Text style={styles.errorLabel}>
                                        {strings('LicenseExpiredOn')}
                                        {` `}
                                        {moment(contractDetails.rentContractEndDate).format('YYYY-MM-DD')}
                                    </Text>
                                </View>
                            )}
                        </View>
                        <SimpleViolatorInfo violator={violator} editable={false} />
                    </View>
                )}
                {/* {(actionItemConstant === 'violation' && amount && amount > 0 && (
                    <View style={[styles.field, { paddingRight: 3, alignItems: 'flex-end' }]}>
                        <Text style={[styles.label, styles.highlight]}>
                            {strings('amount')}
                            {formatCurrency(amount)}
                        </Text>
                    </View>
                )) ||
                    null} */}
                {/* {(actionItemConstant === 'warning' && selectedPeriodType && (
                    <View style={styles.selectedPeriodContainer}>
                        <Icon type="MaterialCommunityIcons" name="clock-outline" size={25} style={styles.icon} />
                        <Text style={styles.selectedPeriod}>{selectedPeriod + ' ' + strings(selectedPeriodType)}</Text>
                    </View>
                )) ||
                    null} */}
                <View style={styles.field}>
                    <View style={styles.fieldrow}>
                        <View style={[styles.fieldContainer, { padding: 8 }]}>
                            <Switch
                                containerStyle={{ marginHorizontal: 0 }}
                                editable={editable}
                                onChange={this.handleFieldChange.bind(this, 'followsTermsOfContract')}
                                value={followsTermsOfContract}
                                renderLabel={() => <Text style={styles.label}> {strings('followsTermsOfContract')}</Text>}
                            />
                        </View>
                    </View>
                </View>

                {errorLogs.selectedActionType ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('actionType') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {showViolationActionTypes && violator && (
                    <View style={styles.actionItemContainer}>
                        {actionItemConstant && readOnly ? (
                            <View style={styles.ViolationActionContainer}>
                                <ViolationItemReview
                                    editable={false}
                                    selectedActionTypeConst={actionItemConstant}
                                    attachments={attachmentList}
                                    remarks={remarks}
                                    errorLogs={errorlogiolationItemReviewArray}
                                    currentInspectionVersion={currentInspectionVersion}
                                    inspection={inspection}
                                    dispatch={this.props.dispatch}
                                    amount={amount || (visitValues || {}).registeredAmount}
                                    selectedPeriod={selectedPeriod}
                                    selectedPeriodType={selectedPeriodType}
                                />
                            </View>
                        ) : (
                            <>
                                {this.state.loadingActions || (violationActionTypes && violationActionTypes.length > 0) ? (
                                    <ViolationActionTypesComponent
                                        onActionChange={this.handleActionChange}
                                        editable={editable}
                                        violationActionTypesLoading={this.state.loadingActions}
                                        violationActionTypesSuccess={true}
                                        violationActionTypes={violationActionTypes}
                                        currentVisitIndex={0}
                                        selectedActionType={selectedActionType}
                                        selectedPeriod={parseInt(selectedPeriod || 0)}
                                        selectedPeriodType={selectedPeriodType}
                                    />
                                ) : (
                                    <View style={styles.loadingMsgContainer}>
                                        {readOnly ? (
                                            <Text style={styles.labelError}>{strings('noActionTypeSelected')}</Text>
                                        ) : (
                                            <Text style={styles.labelError}>{strings('loadingViolationActionsError')}</Text>
                                        )}
                                    </View>
                                )}

                                {readOnly && amount > 0 && (
                                    <View style={[styles.field, { paddingRight: 3, alignItems: 'flex-end' }]}>
                                        <Text style={[styles.label, styles.highlight]}>
                                            {strings('amount')}
                                            {formatCurrency(amount)}
                                        </Text>
                                    </View>
                                )}
                            </>
                        )}
                    </View>
                )}
                {readOnly ? null : (
                    <>
                        <View style={styles.field}>
                            <Text style={styles.label}> {strings('remarks')}</Text>

                            <View style={styles.fieldrow}>
                                <View style={styles.fieldContainer}>
                                    <TextInput
                                        style={styles.input}
                                        placeholder={strings('remarks')}
                                        value={remarks}
                                        editable={editable}
                                        onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                        autoCorrect={false}
                                        direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                        autoCapitalize="sentences"
                                        autoFocus={false}
                                        multiline={true}
                                        textAlignVertical={'top'}
                                    />
                                </View>
                            </View>
                            {errorLogs.remarks ? <Text style={[commonStyles.ValidationMessageText, styles.error]}>{errorLogs.remarks}</Text> : null}
                        </View>
                        <View style={styles.field}>
                            <Text style={styles.label}> {strings('attachments')}</Text>
                            <View style={styles.fieldrow}>
                                <View style={[styles.fieldContainer, styles.fieldContainerWhite]}>
                                    <AttachmentListWithDialog
                                        editable={editable}
                                        onAdd={this.handleOnAddAttachment}
                                        onRemove={this.handleOnRemoveAttachment}
                                        attachments={attachmentList}
                                    />
                                </View>
                            </View>
                            {errorLogs.attachmentList && (
                                <Text style={[commonStyles.ValidationMessageText, styles.error]}>{errorLogs.attachmentList}</Text>
                            )}
                        </View>
                    </>
                )}
            </View>
        );
    }
}
export default FoodTruckAndOutdoor;
