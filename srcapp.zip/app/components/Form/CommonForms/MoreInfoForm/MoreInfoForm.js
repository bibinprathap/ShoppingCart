import React, { Component } from 'react';
import { View, TextInput, TouchableNativeFeedback, Picker, I18nManager } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Icon, IconButton, AttachmentList, Switch, commonStyles, Loader, Modal } from 'app/components';
import { Attachments, ViolationActionTypes } from 'app/screens';
import { infoChanged, saveNewInspection } from 'app/actions/inspections';
import { ValidationHelper, lookup } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { TASK_STARTED } from 'app/actions/inspections';
import * as yup from 'yup';
import { tasksTabLoad } from 'app/actions/generic';

const api = new AppApi();

const emptyFollowUpForm = {
    remarks: '',
    attachmentList: [],
    attachmentModalVisible: false,
    selectedAttachment: null,
    errorLogs: {},
};

class MoreInfoForm extends Component {
    constructor(props) {
        super(props);
        this.state = { ...emptyFollowUpForm, ...props.initialValue };
        this.isSubmitable = this.isSubmitable.bind(this);
    }
    updateFollowupState = async newState => {
        let formValue = { ...this.state, ...newState };
        const followupValidationSchema = {
            attachmentList: yup.array().required(),
            remarks: yup.string().required(),
        };
        let errorLogs = {};
        try {
            await ValidationHelper.validate(formValue, yup.object().shape(followupValidationSchema));
        } catch (errors) {
            //            return;
            Object.getOwnPropertyNames(errors).map(er => {
                errorLogs[er] = errors[er];
            });
        }
        newState.errorLogs = errorLogs;
        this.setState(newState, () => {
            const { visitIndex } = this.props;
            this.props.dispatch(infoChanged('followupForm', this.state, visitIndex));
            this.isSubmitable();
        });
    };
    componentDidMount() {
        if (this.isSubmitable) this.isSubmitable();
    }
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    handleOnAdd = newAttachment => {
        const { attachmentList } = this.state;
        const newAttachmentsArray = attachmentList ? attachmentList.slice() : [];
        newAttachmentsArray.push(newAttachment);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleAttachmentRemoved = doc => {
        const { attachmentList } = this.state;
        const currentAttachments = attachmentList;
        const newAttachmentsArray = _.without(currentAttachments, doc);
        const newState = { attachmentList: newAttachmentsArray };
        this.updateFollowupState(newState);
    };
    handleThumbnailPressed = doc => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleCameraPressed = () => {
        this.setState({
            attachmentModalVisible: true,
        });
    };

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateFollowupState(newState);
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }
    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };
    renderAddPictureButton = () => (
        <View style={styles.buttonContainer}>
            <TouchableNativeFeedback onPress={this.handleCameraPressed}>
                <View style={{ flex: 1 }}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </View>
            </TouchableNativeFeedback>
        </View>
    );

    isSubmitable = async () => {
        const { errorLogs, attachmentList, remarks } = this.state;
        const isAllowedToSave =
            (!errorLogs || (errorLogs && Object.getOwnPropertyNames(errorLogs).length == 0)) &&
            attachmentList &&
            attachmentList.length > 0 &&
            remarks &&
            remarks.length > 0;
        if (this.props.isSubmitable) this.props.isSubmitable({ isAllowedToSave });
    };

    render = () => {
        const { remarks, attachmentList, errorLogs } = this.state;
        const { editable, inspection, readOnly } = this.props;
        //   const isAllowedToSave = Object.getOwnPropertyNames(errorLogs).length == 0 && (attachmentList || '').length > 0 && (remarks || '').length > 0;
        // const saveButtonstyle = isAllowedToSave && editable == true ? styles.buttonPositive : styles.buttonPositiveDisabled;
        //  const saveTextstyle = isAllowedToSave && editable == true ? styles.buttonText : styles.buttonTextPositiveDisabled;
        return (
            <View style={styles.container}>
                <View style={styles.fieldrow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.label}> {strings('attachments')}</Text>
                        <View style={styles.fieldContainer} />
                    </View>
                </View>

                <View style={styles.fieldContainerAttachement}>
                    <Modal
                        animationType="slide"
                        transparent={false}
                        visible={this.state.attachmentModalVisible}
                        onRequestClose={this.toggleAttachmentDialog}
                    >
                        <Attachments
                            attachments={attachmentList}
                            onAdd={this.handleOnAdd}
                            onRemove={this.handleAttachmentRemoved}
                            onClose={this.handleOnClose}
                            selectedAttachment={this.state.selectedAttachment}
                            editable={editable}
                            attachmentModalVisible={this.state.attachmentModalVisible}
                        />
                    </Modal>
                    {!attachmentList || !attachmentList.length ? (
                        <View style={[styles.outerContainerNoAttachment, { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, margin: 12 }]}>
                            {editable ? (
                                <View style={[styles.fieldContainerAttachement, { flex: 1, borderRadius: 4 }]}>{this.renderAddPictureButton()}</View>
                            ) : null}
                        </View>
                    ) : (
                        <View style={[styles.outerContainerNoAttachment]}>
                            <View
                                style={[
                                    styles.outerContainerWithAttachment,

                                    { backgroundColor: '#ffffff', elevation: 1, borderRadius: 4, marginHorizontal: 12, paddingVertical: 5 },
                                ]}
                            >
                                <AttachmentList attachments={attachmentList} editable={editable} onPress={this.handleThumbnailPressed} />
                                {editable ? <View style={styles.buttonWithAttachmentsContainer}>{this.renderAddPictureButton()}</View> : null}
                            </View>
                        </View>
                    )}
                </View>

                {errorLogs.attachmentList ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('emptyAttachmentValidation')}</Text>
                ) : null}

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <Text style={styles.label}> {strings('remarks')}</Text>
                        <View style={[styles.fieldContainer]}>
                            <TextInput
                                style={styles.input}
                                placeholder={strings('newRemarks')}
                                value={remarks}
                                editable={editable}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                autoCorrect={false}
                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                autoCapitalize="sentences"
                                //onSubmitEditing={this.handleNewRemarksButtonOnPress}
                                autoFocus={false}
                                multiline={true}
                                textAlignVertical={'top'}
                            />
                        </View>
                    </View>
                </View>
                {errorLogs.remarks ? (
                    <Text style={[commonStyles.ValidationMessageText, styles.error]}>{strings('remarks') + ' ' + strings('isRequired')}</Text>
                ) : null}
                {/* {!readOnly ? (
                    <View style={[styles.summaryContainer]}>
                        <View style={styles.summaryItem}>
                            <Loader loading={inspection.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>
                                <IconButton
                                    type="MaterialCommunityIcons"
                                    name="content-save"
                                    borderRadius={25}
                                    disabled={!(isAllowedToSave && editable)}
                                    style={[styles.button, saveButtonstyle]}
                                    onPress={this.handleSave}
                                >
                                    <Text style={saveTextstyle}>{strings('save')}</Text>
                                </IconButton>
                            </Loader>
                        </View>
                    </View>
                ) : null} */}
            </View>
        );
    };
}
export default MoreInfoForm;
