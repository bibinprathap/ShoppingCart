import React, { Component } from 'react';
import { View, TextInput, TouchableOpacity, Picker, I18nManager, Image } from 'react-native';
import AppApi from 'app/api/real';
import { strings, formatCurrency } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import moment from 'moment';
import { Path } from 'react-native-svg-charts';
import { _ } from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import { Switch, commonStyles, Icon, IntegrationFeedback, SimpleItemInfo, SimpleViolatorInfo, LineChart } from 'app/components';
import { infoChanged, getActionTypes, checkDuplicate, inspectionViolatorAdded } from 'app/actions/inspections';
import { AttachmentListWithDialog } from 'app/screens';
import { lookup } from 'app/api/helperServices';
import { ItemSelectorDialog, ImageDialog, ViolationActionTypes as ViolationActionTypesComponent } from 'app/screens';
import { inspectionsHelper } from 'app/api/helperServices';
import alertsHelper from 'app/api/helperServices/alerts';
import { ClipPath, Defs, Rect, Line } from 'react-native-svg';
import { RNFileUploader } from 'app/api/helperServices';

const api = new AppApi();
const inspectionFields = {
    dbLevel: '',
    remarks: null,
    attachmentList: [],
    violatorId: null,
    selectedActionType: null,
    violationActionTypes: [],
    selectedPeriod: null,
    selectedPeriodType: null,
    registeredAmount: 0,
    minDecibel: 0,
    maxDecibel: 0,
    avgDecibel: 0,
    currentDBLevel: 0,
    seconds: 0,
    recordingSeconds: 0,
};

const recordSoundSecondsMax = 150;
const DBLevelLimit = 70;
const chartDataInitial = {
    type: 'line',
    xAxisLabels: Array(recordSoundSecondsMax)
        .fill()
        .map((v, i) => {
            return { labelE: i, labelA: i };
        }),
    datasets: [
        {
            color: '#F7F7FA',
            data: Array(recordSoundSecondsMax)
                .fill()
                .map((v, i) => {
                    return 150;
                }),
        },
        {
            color: '#62b42c',
            data: Array(recordSoundSecondsMax)
                .fill()
                .map((v, i) => {
                    return 10;
                }),
        },
        {
            color: '#F7F7FA',
            data: Array(recordSoundSecondsMax)
                .fill()
                .map((v, i) => {
                    return 1;
                }),
        },
    ],
};

const Clips = ({ x, y, width, indexToClipFrom }) => {
    return (
        <Defs key={'clips'}>
            <ClipPath id="clip-path-1">
                <Rect x={'0'} y={'0'} width={x(indexToClipFrom) - 2} height={'100%'} />
            </ClipPath>
            <ClipPath id="clip-path-2">
                <Rect x={'0'} y={'0'} width={x(indexToClipFrom) - 2} height={y(DBLevelLimit)} />
            </ClipPath>
        </Defs>
    );
};

const HorizontalLine = ({ y }) => (
    <Line key={'zero-axis'} x1={'0%'} x2={'100%'} y1={y(DBLevelLimit)} y2={y(DBLevelLimit)} stroke={'red'} strokeDasharray={[6, 3]} strokeWidth={1} />
);

const RedLine = ({ lines }) => {
    return <Path key={'line-1'} d={lines[1]} stroke={'red'} fill={'none'} clipPath={'url(#clip-path-2)'} />;
};

let audioListener = null;
class NoisePollution extends Component {
    constructor(props) {
        super(props);

        this.state = {
            ...inspectionFields,
            attachmentModalVisible: false,
            showDialog: false,
            showImageDialog: false,
            errorLogs: {},
            ...(props.values || {}),
            chartData: chartDataInitial,
            seconds: -1,
            recordBarPercentage: 0,
            recording: false,
            minDecibel: 0,
            maxDecibel: 0,
            avgDecibel: 0,
            currentDBLevel: 0,
            recordingSeconds: 0,
        };
        this.renderCustomActions = this.renderCustomActions.bind(this);
        this.recordStarts = this.recordStarts.bind(this);
        this.setrecording = this.setrecording.bind(this);
    }

    updateState = async newState => {
        return this.setState(newState, () => {
            const { visitIndex } = this.props;
            const stateValuesTobeUpdated = _.pick(this.state, Object.keys(inspectionFields));
            this.props.dispatch(infoChanged('noisePollution', stateValuesTobeUpdated, visitIndex));
        });
    };

    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: !this.state.attachmentModalVisible,
        });
    };
    setrecording = (recording, calibration) => {
        const newDbLevel = parseFloat(recording.DBLEVEL) + calibration;
        const newMinDbLevel = parseFloat(recording.MINDBLEVEL) + calibration;
        const newMaxDbLevel = parseFloat(recording.MAXDBLEVEL) + calibration;
        const newAvgDbLevel = (parseFloat(newMinDbLevel) + parseFloat(newMaxDbLevel)) / 2;

        let dataTop = this.state.chartData.datasets[0];
        let dataMiddle = this.state.chartData.datasets[1];
        let dataBottom = this.state.chartData.datasets[2];
        dataMiddle.data[this.state.seconds + 1] = parseInt(newDbLevel);
        this.setState({
            seconds: this.state.seconds + 1,
            recordBarPercentage: (this.state.seconds / recordSoundSecondsMax) * 97,
            chartData: {
                ...this.state.chartData,
                datasets: [{ ...dataTop }, { ...dataMiddle }, { ...dataBottom }],
            },
            minDecibel: parseFloat(newMinDbLevel).toFixed(2),
            maxDecibel: parseFloat(newMaxDbLevel).toFixed(2),
            avgDecibel: parseFloat(newAvgDbLevel).toFixed(2),
            recordingSeconds: parseFloat((200 * recording.Count) / 1000).toFixed(2),
            currentDBLevel: parseFloat(newDbLevel).toFixed(2),
        });
    };
    componentDidMount() {
        const { calibration } = this.props;
        audioListener = RNFileUploader.addListener('audiorecording', '', data => {
            if (data.Count >= recordSoundSecondsMax) {
                this.recordStops();
            }
            if (data.recording) {
                this.setrecording(data, calibration || 0);
            }
        });
    }

    handleFieldChange = async (name, value) => {
        const newState = {};
        newState[name] = value;
        this.updateState(newState);
    };

    // shouldComponentUpdate(nextProps, nextState) {
    //     return shallowEqual(this.props, nextProps, this.state, nextState);
    // }

    handleOnClose = () => {
        this.setState({ attachmentModalVisible: false });
    };

    handleOnAddAttachment = attachment => {
        const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        this.updateState(newState);
    };

    handleOnRemoveAttachment = attachment => {
        const modifiedattachmentList = [...this.state.attachmentList];
        let index;
        modifiedattachmentList.forEach((item, i) => {
            if (item == attachment) {
                index = i;
                return;
            }
        });
        modifiedattachmentList.splice(index, 1);
        const newState = { attachmentList: modifiedattachmentList };
        this.updateState(newState);
    };

    handleImageDialogOnRequestClose = item => {
        this.setState({ showImageDialog: false });
    };

    removeContractDetails = item => {
        this.updateState({
            violatorId: null,
            selectedActionType: null,
            violationActionTypes: [],
            selectedPeriod: null,
            selectedPeriodType: null,
            registeredAmount: 0,
        });
    };

    showZoomableImage = currentImageSource => {
        this.setState({ showImageDialog: true, currentImageSource });
    };

    renderCustomActions = ({ item }) => {
        const { editable } = this.props;
        return (
            <View>
                {editable && (
                    <TouchableOpacity style={styles.removeIconWrapper} onPress={this.removeContractDetails}>
                        <Icon type="MaterialCommunityIcons" name={'close-circle'} size={24} />
                    </TouchableOpacity>
                )}
            </View>
        );
    };

    handleOnViolatorSelected = async (newValue, currentVisitIndex, inspection) => {
        await this.props.dispatch(
            getViolationActionTypes({
                workflowConst: inspection.inspectionTypeDetail && inspection.inspectionTypeDetail.workflowConst,
                inspViolationTypeId: newValue.violationTypeIds[0],
                violator: inspection.violators[0],
                currentVisitIndex,
                inspTypeCheckItemId: newValue.inspTypeCheckItemId,
                inspInstanceId: inspection.inspectionId,
                location: inspection.location,
            })
        );
    };

    handleActionChange = callProps => {
        const { params, reset } = callProps;
        this.updateState({
            registeredAmount: params.amount != undefined ? params.amount : this.state.registeredAmount,
            selectedActionType: params.selectedActionType != undefined ? params.selectedActionType : this.state.selectedActionType,
            selectedPeriod: params.selectedPeriod != undefined ? params.selectedPeriod : this.state.selectedPeriod,
            selectedPeriodType: params.selectedPeriodType != undefined ? params.selectedPeriodType : this.state.selectedPeriodType,
            violationActionTypes: (this.props.values && this.props.values.violationActionTypes) || [],
        });
    };

    recordStarts = () => {
        this.setState({
            recordBarPercentage: 0,
            recording: true,
            seconds: -1,
            chartData: chartDataInitial,
        });
        RNFileUploader.StartRecording('200');
    };

    recordStops = () => {
        RNFileUploader.StopRecording('200');
        this.setState({
            recording: false,
        });
    };

    resetRecord = () => {
        RNFileUploader.StopRecording('200');
        this.setState(
            {
                recording: false,
            },
            () => {
                this.recordStarts();
            }
        );
    };

    componentWillUnmount() {
        if (this.timer) clearInterval(this.timer);
        if (audioListener) {
            audioListener.remove();
        }
        this.recordStops();
    }

    render() {
        const { dispatch, inspection, formName, readOnly, editable, currentInspectionVersion, values } = this.props;
        const {
            showDialog,
            remarks,
            violatorId,
            chartData,
            recordBarPercentage,
            seconds,
            recording,
            minDecibel,
            avgDecibel,
            maxDecibel,
            currentDBLevel,
            recordingSeconds,
        } = this.state;

        let { violationActionTypes, selectedActionType, selectedPeriod, selectedPeriodType, registeredAmount } = values || {};
        const actionItem =
            selectedActionType &&
            inspectionsHelper.findViolationAction({
                violationActionTypes,
                selectedActionType,
            });
        const displaySource = this.props.readOnly ? this.props.values : this.state;
        const { attachmentList } = displaySource || {};
        let errorLogs = this.props.errorLogs || {};

        const readOnlyRtlStyles = I18nManager.isRTL
            ? { textAlign: 'right', alignSelf: 'flex-start' }
            : { textAlign: 'left', alignSelf: 'flex-start' };

        const violator = violatorId && inspection.violators && _.find(inspection.violators, v => v.violatorId == violatorId);
        return (
            <View style={styles.contentContainer} key={{ formName }} key={this.props.key}>
                {seconds > 0 && (
                    <View style={styles.field}>
                        <Text style={styles.label}>{strings('dbLevel')}</Text>
                        <View style={styles.chartWrapper}>
                            <View style={{ padding: 10, paddingBottom: 20 }}>
                                <LineChart
                                    lineChartProps={{
                                        svg: {
                                            clipPath: 'url(#clip-path-1)',
                                            strokeWidth: 2,
                                        },
                                    }}
                                    chartData={chartData}
                                    height={300}
                                    hideCircle
                                    hideXaxis={true}
                                >
                                    <Clips indexToClipFrom={seconds} />
                                    {seconds > 0 && <HorizontalLine />}
                                    <RedLine />
                                </LineChart>
                            </View>
                        </View>
                    </View>
                )}
                {seconds == -1 && (
                    <View style={styles.field}>
                        <TouchableOpacity onPress={recording == false ? this.recordStarts : this.recordStops} style={styles.recordButtonBig}>
                            <Icon type="MaterialCommunityIcons" name={recording == false ? 'record' : 'stop'} size={26} color={'red'} />
                        </TouchableOpacity>
                    </View>
                )}

                <View style={styles.field}>
                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                        <Text style={styles.info}>Min: {minDecibel}</Text>
                        <Text style={styles.info}>Avg: {avgDecibel}</Text>
                        <Text style={styles.info}>Max: {maxDecibel}</Text>
                        <Text style={styles.info}>DB Level: {currentDBLevel}</Text>
                        <Text style={styles.info}>Seconds: {parseFloat(recordingSeconds || 0).toFixed(0)}</Text>
                        {seconds > 0 && (
                            <TouchableOpacity onPress={recording == false ? this.recordStarts : this.recordStops} style={styles.recordButton}>
                                <Icon type="MaterialCommunityIcons" name={recording == false ? 'record' : 'stop'} size={16} color={'red'} />
                            </TouchableOpacity>
                        )}
                        {seconds > 0 && recording == false && (
                            <TouchableOpacity onPress={this.resetRecord} style={styles.recordButton}>
                                <Icon type="MaterialCommunityIcons" name={'refresh'} size={16} color={'black'} />
                            </TouchableOpacity>
                        )}
                    </View>
                </View>

                {/* <View style={styles.field}>
                    <Text style={styles.label}> {strings('startRecording')}</Text>
                    <View style={{ flexDirection: 'row', marginTop: 5 }}>
                        <TouchableOpacity onPress={recording == false ? this.recordStarts : this.recordStops} style={styles.recordButton}>
                            <Icon type="MaterialCommunityIcons" name={recording == false ? 'record' : 'stop'} size={16} color={'red'} />
                        </TouchableOpacity>
                        <View style={[styles.recordBar, { width: `${recordBarPercentage}%` }]}></View>
                    </View>
                </View> */}

                {violator && (
                    <View style={styles.field}>
                        <SimpleViolatorInfo violator={violator} editable={false} />
                    </View>
                )}

                <View style={styles.field}>
                    <Text style={styles.label}> {strings('remarks')}</Text>
                    <View style={styles.fieldrow}>
                        <View style={styles.fieldContainer}>
                            <TextInput
                                style={styles.input}
                                placeholder={strings('remarks')}
                                value={editable ? remarks : values && values.remarks}
                                editable={editable}
                                onChangeText={this.handleFieldChange.bind(this, 'remarks')}
                                autoCorrect={false}
                                direction={I18nManager.isRTL ? 'rtl' : 'ltr'}
                                autoCapitalize="sentences"
                                autoFocus={false}
                                multiline={true}
                                textAlignVertical={'top'}
                            />
                        </View>
                    </View>
                    {errorLogs.remarks ? <Text style={[commonStyles.ValidationMessageText, styles.error]}>{errorLogs.remarks}</Text> : null}
                </View>
                <View style={styles.field}>
                    <Text style={styles.label}> {strings('attachments')}</Text>
                    <View style={styles.fieldrow}>
                        <View style={[styles.fieldContainer, styles.fieldContainerWhite]}>
                            <AttachmentListWithDialog
                                editable={editable}
                                onAdd={this.handleOnAddAttachment}
                                onRemove={this.handleOnRemoveAttachment}
                                attachments={attachmentList}
                            />
                        </View>
                    </View>
                    {errorLogs.attachmentList && <Text style={[commonStyles.ValidationMessageText, styles.error]}>{errorLogs.attachmentList}</Text>}
                </View>
            </View>
        );
    }
}
export default NoisePollution;
