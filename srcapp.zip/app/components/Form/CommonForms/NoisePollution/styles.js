import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';
export default EStyleSheet.create({
    contentContainer: {
        flex: 1,
        padding: 10,
        borderRadius: 10,
    },
    titleContainer: {
        width: '100%',
    },
    field: {
        flexDirection: 'column',
        marginVertical: 10,
    },
    fieldrow: {
        flexDirection: 'row',
        justifyContent: 'center',
        justifyContent: 'flex-start',
    },
    fieldContainer: {
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        justifyContent: 'center',
        marginTop: 5,
        borderRadius: 5,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        flex: 1,
    },
    highlight: {
        fontWeight: 'bold',
    },
    fieldContainerWhite: {
        backgroundColor: '$primaryWhite',
    },
    input: {
        flex: 1,
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',
        alignItems: 'flex-start',
        borderRadius: 4,
        elevation: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        padding: 10,
        height: 45,
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
    },
    errorLabel: {
        fontSize: '$primaryTextXS',
        color: 'red',
    },
    error: {
        margin: 5,
    },
    infoWrapper: {
        backgroundColor: '$primaryWhite',
    },
    removeIconWrapper: {
        margin: 5,
        padding: 5,
        alignItems: 'flex-end',
    },
    attachmentWrapper: {
        backgroundColor: '$primaryWhite',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 5,
    },
    valueReadOnlyText: {
        fontSize: 12,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        color: '$primaryDarkTextColor',
    },
    icon: {
        color: '$primaryDividerDarkColor',
        alignSelf: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        margin: 0,
        padding: 0,
        paddingRight: 5,
    },
    chartWrapper: {
        backgroundColor: '$primaryMediumBackground',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        marginVertical: 10,
    },
    recordButton: {
        padding: 10,
        borderRadius: 5,
        borderColor: '$primaryDarktBorder',
        elevation: 1,
        marginRight: 5,
    },
    recordBar: {
        margin: 1,
        backgroundColor: '$primarySuccessColor',
        width: 0,
        height: '20%',
        borderRadius: 2,
        alignSelf: 'center',
    },
    info: {
        padding: 5,
        backgroundColor: '#CFD0D3',
        borderRadius: 5,
        marginRight: 5,
        alignSelf: 'center',
    },
    recordButtonBig: {
        margin: 20,
        padding: 10,
        borderRadius: 5,
        borderColor: '$primaryDarktBorder',
        elevation: 1,
        alignSelf: 'center',
    },
});
