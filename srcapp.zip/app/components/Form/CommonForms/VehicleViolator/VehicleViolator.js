import React, { Component } from 'react';
import { View, TextInput, Picker, TouchableOpacity, I18nManager } from 'react-native';
import { connect } from 'react-redux';
import AppApi from 'app/api/real';
import { strings } from 'app/config/i18n/i18n';
import { shallowEqual } from 'app/api/helperServices';
import { Text } from 'react-native-paper';
import { IconButton, IntegrationFeedback, Switch, Loader } from 'app/components';
import styles from './styles';
import { localeProperty } from 'app/config/i18n/i18n';
import { ValidationHelper } from 'app/api/helperServices';
import * as yup from 'yup';
const api = new AppApi();
/*
TEST plate Number
Source - Abudhabi
Kind - private
Color - thirteen category
Plate number 65049
*/

class VehicleViolator extends Component {
    constructor(props) {
        super(props);
        const { mode, violator } = props;

        if (mode === 'new') {
            this.state = { ...this.getEmptyState() };
        } else {
            this.state = { ...this.getStateFromExistingViolator(violator) };
        }

        this.searchVehicleProfile = this.searchVehicleProfile.bind(this);
        this.checkStateisValid = this.checkStateisValid.bind(this);
    }

    loadTestData = () => {
        this.setState(
            {
                isManualEntry: true,
                plateNumber: '123456',
                plateKind: '1014',
                plateColor: '1013',
                color: '1015',
                make: '1016',
                vehicleDesc: 'test',
                isPlateNoObtainable: false,
            },
            () => this.checkStateisValid(this.state)
        );
    };

    getEmptyState = (preserveSearchParams, searchOn, disableInitalAPiCall) => {
        const newState = {
            violatorType: 'vehicle',
            isManualEntry: false,
            isPlateNoObtainable: true,
            ADPCode: '',
            plateSource: '',
            plateNumber: '',
            titleE: '',
            registeredPhoneNumber: '',
            titleA: '',
            integrationData: undefined,
            detail: undefined,
            make: '',
            model: '',
            color: '',
            plateDescription: '',
            chassisNumber: '',
            plateKind: '',
            plateColor: '',
            vehicleDesc: '',
            mandatoryFields: ['plateSource', 'plateNumber', 'plateKind', 'plateColor', 'make', 'model', 'color'],
            plateKindOptions: [],
            plateColorOptions: [],
            isPlateKindLoading: this.state ? this.state.isPlateKindLoading : false,
            isPlateColorLoading: this.state ? this.state.isPlateColorLoading : false,
        };
        if (
            preserveSearchParams &&
            this.state &&
            this.state.isPlateNoObtainable &&
            (searchOn === 'searchByPlateNo' || searchOn === 'searchByChassis')
        ) {
            newState.plateKind = this.state.plateKind;
            newState.plateColor = this.state.plateColor;
            newState.chassisNumber = searchOn === 'searchByPlateNo' ? '' : this.state.chassisNumber;
            newState.plateNumber = this.state.plateNumber;

            newState.ADPCode = this.state.ADPCode;
            newState.plateSource = this.state.plateSource;
            newState.plateKindOptions = this.state.plateKindOptions;
            newState.plateColorOptions = this.state.plateColorOptions;
        }

        if (preserveSearchParams && this.state && !this.state.isPlateNoObtainable) {
            newState.chassisNumber = this.state.chassisNumber;
        }
        if (this.props.vehiclePlateSource && this.props.vehiclePlateSource.length > 0 && !preserveSearchParams && !searchOn) {
            const currentSource = this.props.vehiclePlateSource[0];
            newState.plateSource = currentSource.id;
            newState.ADPCode = currentSource.ADPCode;
            if (!disableInitalAPiCall) this.getVehiclePlateKinds({ plateSource: currentSource.id });
        }

        return newState;
    };

    getStateFromExistingViolator = (violator, searchOn) => {
        //Todo: shouldn't need to check for null, if the API stops serializing null values
        const newState = { ...this.getEmptyState(true, searchOn, true), ...violator };
        const detail = newState.detail || {};
        newState.detail = detail;

        newState.plateNumber = detail.plateNumber || newState.plateNumber;
        newState.make = detail.vehicleMakeLkdId || newState.make;
        newState.model = detail.vehicleModelLkdId || newState.model;
        newState.color = detail.vehicleColorLkdId || newState.color;
        newState.plateDescription = detail.plateDescription || newState.plateDescription;
        newState.chassisNumber = detail.chassisNumber || newState.chassisNumber;
        newState.vehicleDesc = detail.vehicleDesc || newState.vehicleDesc;
        newState.isManualEntry = newState.isManualEntry || newState.isManualEntry;
        newState.violatorType = 'vehicle';

        if (!searchOn) {
            newState.plateSource = detail.plateColorLkdId || newState.plateSource;
            newState.plateKind = detail.plateKindLkdId || newState.plateKind;
            newState.plateColor = detail.plateColorLkdId || newState.plateColor;

            if (newState.plateSource) {
                const currentSource = this.props.vehiclePlateSource.find((s) => s.id == newState.plateSource) || {};
                newState.ADPCode = currentSource && currentSource.ADPCode;
                this.getVehiclePlateKinds({ plateSource: newState.plateSource });
            }

            this.getVehiclePlateColors({ plateSource: newState.plateSource, plateKind: newState.plateKind });
        }

        return newState;
    };

    checkStateisValid = async (newState) => {
        newState.mandatoryFields = [];
        if (newState.isPlateNoObtainable) {
            newState.mandatoryFields.push('plateNumber');
            if (newState.ADPCode && !newState.isManualEntry) {
                newState.mandatoryFields.push('plateKind', 'plateColor', 'make', 'model', 'color');
            } else if (newState.ADPCode && newState.isManualEntry) {
                newState.mandatoryFields.push('plateKind', 'plateColor', 'vehicleDesc');
            } else {
                newState.mandatoryFields.push('vehicleDesc');
            }
        } else {
            newState.mandatoryFields.push('vehicleDesc');
        }

        const vehicleValidationSchema = {};
        newState.mandatoryFields.map((f) => {
            vehicleValidationSchema[f] = yup.string().required();
            return f;
        });

        try {
            await ValidationHelper.validate(newState, yup.object().shape(vehicleValidationSchema));
            this.props.isValidViolator(true, this.state);
            return;
        } catch (errors) {
            this.props.isValidViolator(false, this.state);
            return;
        }
    };
    getVehiclePlateKinds = async ({ plateSource }) => {
        try {
            if (!plateSource) return;
            let result = await api.getVehiclePlateKinds({ plateSource });
            this.setState({ plateKindOptions: result, isPlateKindLoading: false });
        } catch (e) {
            console.log('Location getVehiclePlateKinds error', e);
            this.setState({ plateKindOptions: [], isPlateKindLoading: false });
        }
    };

    getVehiclePlateColors = async ({ plateSource, plateKind }) => {
        try {
            if (!plateSource || !plateKind) return;
            let result = await api.getVehiclePlateColors({ plateSource, plateKind });
            this.setState({ plateColorOptions: result, isPlateColorLoading: false });
        } catch (e) {
            console.log('getVehiclePlateColors error', e);
            this.setState({ plateColorOptions: [], isPlateColorLoading: false });
        }
    };

    handleFieldChange = async (name, value) => {
        let newState = { ...this.state, [name]: value };

        if (name == 'isPlateNoObtainable') {
            newState = { ...this.getEmptyState(), [name]: value };
        }

        if (name == 'plateSource') {
            const currentSource = this.props.vehiclePlateSource.find((s) => s.id == value) || {};
            newState.ADPCode = (currentSource && currentSource.ADPCode) || '';
            //newState.ADPCode = '';
            newState.plateSource = value;
            newState.plateKind = '';
            newState.plateColor = '';
            newState.chassisNumber = '';
            newState.plateNumber = '';
            newState.vehicleDesc = '';
            newState.make = '';
            newState.color = '';

            newState.isPlateKindLoading = currentSource && currentSource.id ? true : false;
            this.getVehiclePlateKinds({ plateSource: currentSource && currentSource.id });
        }

        if (name == 'plateKind' && newState.plateSource && value) {
            newState.plateColor = '';
            newState.plateKind = value;
            newState.isPlateColorLoading = true;
            this.getVehiclePlateColors({ plateSource: newState.plateSource, plateKind: value });
        }

        if (name == 'make') {
            newState.model = '';
            newState.color = '';
        }

        newState = this.removeIntegrationSuccess(newState, name, value); //data is no more verified as user has changed something

        //console.log('handleFieldChange() name:', name, 'value: ', value, ' newState: ', newState);
        this.updateState(newState);
    };

    removeIntegrationSuccess = (newState, name, value) => {
        if (newState.integrationData && newState.integrationData.success) {
            if (name == 'plateKind' || name == 'plateColor' || name == 'chassisNumber' || name == 'plateNumber') {
                newState = { ...this.getEmptyState(true), ['isPlateNoObtainable']: this.state.isPlateNoObtainable };
            } else {
                newState = { ...newState, integrationData: undefined };
            }

            newState[name] = value;
            return newState;
        } else return newState;
    };

    updateState = (newState) => {
        newState.isManualEntry = this.getManualEntryFlag(newState);
        this.setState(newState, () => {
            this.checkStateisValid(this.state);
        });
    };

    getManualEntryFlag = (values) => {
        let integrationFailure = false;

        if (values.integrationData && !values.integrationData.running && !values.integrationData.success) {
            integrationFailure = true;
        }

        return integrationFailure || !values.ADPCode;
    };

    searchVehicleProfile = async (searchOn, isPlateNoObtainable) => {
        const { integrationData } = this.state;

        const isSearching = integrationData && integrationData.running == true;
        let newState = {};
        if (isSearching) return;

        newState = {
            ...this.getEmptyState(true, searchOn),
            ['isPlateNoObtainable']: isPlateNoObtainable,
            integrationData: { running: true, message: strings('integrationProgressMessageADP') },
        };
        this.updateState(newState);

        try {
            const result = await api.getVehicleProfile(newState);
            // didnt get what below code do
            // if (result.detail.nationalityId == 0) result.detail.nationalityId = this.state.country;
            newState = {
                ...this.getStateFromExistingViolator(result, searchOn),
                ['isPlateNoObtainable']: isPlateNoObtainable,
                integrationData: { running: false, success: true, message: strings('integrationSuccessMessageADP') },
            };
            this.updateState(newState);
        } catch (e) {
            newState = {
                ...this.getEmptyState(true, searchOn),
                ['isPlateNoObtainable']: isPlateNoObtainable,
                integrationData: { running: false, success: false, error: e, message: strings('integrationErrorMessageADP') },
            };
            this.updateState(newState);
        }
    };

    shouldComponentUpdate(nextProps, nextState) {
        return shallowEqual(this.props, nextProps, this.state, nextState);
    }

    render = () => {
        const {
            isPlateNoObtainable,
            plateNumber,
            titleE,
            registeredPhoneNumber,
            titleA,
            integrationData,
            ADPCode,
            make,
            model,
            color,
            chassisNumber,
            plateDescription,
            isManualEntry,
            plateKind,
            plateColor,
            vehicleDesc,
            mandatoryFields,
            plateKindOptions,
            plateColorOptions,
            plateSource,
            isPlateKindLoading,
            isPlateColorLoading,
        } = this.state;

        const { mode, makeOptions, colorOptions, vehiclePlateSource } = this.props;
        const validationStyles = styles.invalid;
        const textInputTheme = {
            //roundness: styles.input.borderRadius,
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        const isSearching = (integrationData && integrationData.running == true) || false;
        const editable = mode === 'new' && !isSearching;
        //const hasIntegrationSuccess = (integrationData && integrationData.success == true) || false;

        const cansearch = plateNumber && plateKind && plateColor;
        const chassissearch = chassisNumber.length > 0;
        const searchButtonstyle = mode === 'new' && !isSearching && cansearch ? styles.buttonPositive : styles.buttonPositiveDisabled;
        const searchChassisButtonstyle = mode === 'new' && !isSearching && chassissearch ? styles.buttonPositive : styles.buttonPositiveDisabled;

        const modelOptions = (makeOptions.find((c) => c.id == make) || {}).VehicleModel || [];

        const ismakeModelvisible = (isManualEntry && editable) || !isPlateNoObtainable || (integrationData && integrationData.success);
        const ismakeModelvisibleEditable = (isManualEntry && editable) || !isPlateNoObtainable;

        const isPlateKindPlateColorPhNoVisible = isPlateNoObtainable || (integrationData && integrationData.success);

        return (
            <View style={styles.containerWithOutBorder}>
                <View style={styles.fieldrow}>
                    <View
                        style={[
                            styles.labelContainer,
                            styles.labelContainerColumnEnd,
                            { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
                        ]}
                    >
                        <View style={[styles.fieldContainer]}>
                            <Switch
                                editable={editable}
                                onChange={this.handleFieldChange.bind(this, 'isPlateNoObtainable')}
                                value={isPlateNoObtainable}
                                label={strings('isPlateNoObtainable')}
                                iconProps={{ name: 'alpha-r-circle-outline', type: 'MaterialCommunityIcons', size: 24 }}
                            />
                        </View>
                    </View>
                </View>

                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        <View style={{ flexDirection: 'row' }}>
                            <TouchableOpacity onPress={() => this.loadTestData()}>
                                <Text style={styles.label}> {strings('source')}</Text>
                            </TouchableOpacity>
                            {mandatoryFields.includes('plateSource') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>
                        <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                            <Picker
                                selectedValue={plateSource}
                                key={`source_${vehiclePlateSource.length}`}
                                enabled={editable}
                                style={styles.picker}
                                onValueChange={this.handleFieldChange.bind(this, 'plateSource')}
                            >
                                {vehiclePlateSource &&
                                    vehiclePlateSource.map((v, i) => {
                                        return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Source'} value={v.id} />;
                                    })}
                            </Picker>
                        </View>
                    </View>
                    <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                        {/* {emiratesOptions.length > 0 ? (
                            <>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.label}> {strings('emirate')}</Text>
                                    {mandatoryFields.includes('emirate') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                </View>

                                <View style={[styles.fieldContainer, styles.fieldContainerPicker]}>
                                    <Picker
                                        selectedValue={emirate}
                                        key={`emirate${emiratesOptions.length}`}
                                        enabled={editable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'emirate')}
                                    >
                                        {emiratesOptions &&
                                            emiratesOptions.map((v, i) => {
                                                return <Picker.Item key={i} label={localeProperty(v, 'label') || 'Unknown Type'} value={v.id} />;
                                            })}
                                    </Picker>
                                </View>
                            </>
                        ) : null} */}
                    </View>
                </View>

                {(ADPCode && isPlateKindPlateColorPhNoVisible && (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateKind')}</Text>
                                {mandatoryFields.includes('plateKind') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>
                            <View style={isPlateNoObtainable ? [styles.fieldContainer, styles.fieldContainerPicker] : [styles.fieldContainer]}>
                                <Picker
                                    selectedValue={plateKind}
                                    key={`plateKind${plateKindOptions.length}`}
                                    enabled={isPlateNoObtainable && editable}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'plateKind')}
                                >
                                    <Picker.Item key={4422} label={strings('pleaseselect') + ' ' + strings('plateKind')} value={''} />
                                    {plateKindOptions &&
                                        plateKindOptions.map((v, i) => {
                                            return (
                                                <Picker.Item
                                                    key={i}
                                                    label={localeProperty(v, 'lookupDetailName') || 'Unknown Type'}
                                                    value={v.vehiclePlateKindLkdId}
                                                />
                                            );
                                        })}
                                </Picker>
                                {isPlateKindLoading && <Loader loading={true} size={20} spinnerStyle={styles.spinner} />}
                            </View>
                        </View>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateColor')}</Text>
                                {mandatoryFields.includes('plateColor') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>
                            <View style={isPlateNoObtainable ? [styles.fieldContainer, styles.fieldContainerPicker] : [styles.fieldContainer]}>
                                <Picker
                                    selectedValue={plateColor}
                                    key={`plateColor${plateColorOptions.length}`}
                                    enabled={isPlateNoObtainable && editable}
                                    style={styles.picker}
                                    onValueChange={this.handleFieldChange.bind(this, 'plateColor')}
                                >
                                    <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('plateColor')} value={''} />
                                    {plateColorOptions &&
                                        plateColorOptions.map((v, i) => {
                                            return (
                                                <Picker.Item
                                                    key={i}
                                                    label={localeProperty(v, 'lookupDetailName') || 'Unknown Type'}
                                                    value={v.vehiclePlateColorLkdId}
                                                />
                                            );
                                        })}
                                </Picker>
                                {isPlateColorLoading && <Loader loading={true} size={20} spinnerStyle={styles.spinner} />}
                            </View>
                        </View>
                    </View>
                )) ||
                    null}
                <View style={styles.fieldrow}>
                    <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.label}> {strings('chassisNumber')}</Text>
                            {mandatoryFields.includes('chassisNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                        </View>
                        <View style={styles.fieldContainer}>
                            <TextInput
                                style={[styles.input, editable ? null : styles.inputDisabled]}
                                onChangeText={this.handleFieldChange.bind(this, 'chassisNumber')}
                                theme={textInputTheme}
                                value={chassisNumber}
                                editable={editable}
                                placeholder={strings('chassisNumber')}
                                placeholderStyle={{ color: '#000000' }}
                                textAlignVertical={'center'}
                                textAlign={I18nManager.isRTL ? 'right' : 'left'}
                            />
                            <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                {(integrationData && chassisNumber && <IntegrationFeedback integrationData={integrationData} />) || null}
                            </View>
                            {ADPCode ? (
                                <View>
                                    <IconButton
                                        type="MaterialCommunityIcons"
                                        name="magnify"
                                        disabled={isSearching || !chassissearch || mode !== 'new'}
                                        style={[styles.buttonSearch, searchChassisButtonstyle]}
                                        onPress={this.searchVehicleProfile.bind(this, 'searchByChassis', isPlateNoObtainable)}
                                    />
                                </View>
                            ) : null}
                        </View>
                    </View>
                    {isPlateNoObtainable ? (
                        <View style={[styles.labelContainer, styles.labelContainerColumnStart]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('numberPlate')}</Text>
                                {mandatoryFields.includes('plateNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={styles.fieldContainer}>
                                <TextInput
                                    style={styles.input}
                                    onChangeText={this.handleFieldChange.bind(this, 'plateNumber')}
                                    theme={textInputTheme}
                                    value={plateNumber}
                                    editable={editable}
                                    placeholder={strings('numberPlate')}
                                    placeholderStyle={{ color: '#000000' }}
                                    textAlignVertical={'center'}
                                    textAlign={I18nManager.isRTL ? 'right' : 'left'}
                                    keyboardType={'numeric'}
                                />
                                <View style={{ position: 'absolute', right: 55, top: 13, elevation: 1 }}>
                                    {(integrationData && plateNumber && <IntegrationFeedback integrationData={integrationData} />) || null}
                                </View>
                                {ADPCode ? (
                                    <View>
                                        <IconButton
                                            type="MaterialCommunityIcons"
                                            name="magnify"
                                            disabled={isSearching || !cansearch || mode !== 'new'}
                                            style={[styles.buttonSearch, searchButtonstyle]}
                                            onPress={this.searchVehicleProfile.bind(this, 'searchByPlateNo', isPlateNoObtainable)}
                                        />
                                    </View>
                                ) : null}
                            </View>
                        </View>
                    ) : plateNumber ? (
                        <View style={(styles.labelContainer, styles.labelContainerColumnEnd)}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('plateNumber')}</Text>
                                {mandatoryFields.includes('plateNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                                <Text style={styles.inputDisabled}> {plateNumber}</Text>
                            </View>
                        </View>
                    ) : null}
                </View>
                {((isManualEntry || !isPlateNoObtainable) && (
                    <View style={styles.fieldrow}>
                        <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.label}> {strings('vehicleDesc')}</Text>
                                {mandatoryFields.includes('vehicleDesc') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                            </View>

                            <View style={[styles.fieldContainer]}>
                                <TextInput
                                    style={styles.input}
                                    onChangeText={this.handleFieldChange.bind(this, 'vehicleDesc')}
                                    theme={textInputTheme}
                                    value={vehicleDesc}
                                    editable={editable}
                                    placeholder={strings('vehicleDesc')}
                                    placeholderStyle={{ color: '#000000' }}
                                    textAlignVertical={'center'}
                                />
                            </View>
                        </View>
                    </View>
                )) ||
                    null}
                {ismakeModelvisible ? (
                    <>
                        <View style={styles.fieldrow}>
                            <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.label}> {strings('make')}</Text>
                                    {mandatoryFields.includes('make') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                </View>
                                <View
                                    style={[
                                        styles.fieldContainer,
                                        ismakeModelvisibleEditable ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled,
                                    ]}
                                >
                                    <Picker
                                        selectedValue={(make && parseInt(make)) || ''}
                                        key={`make_${makeOptions.length}`}
                                        enabled={ismakeModelvisibleEditable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'make')}
                                    >
                                        <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('make')} value={''} />
                                        {makeOptions &&
                                            makeOptions.map((v, i) => {
                                                return (
                                                    <Picker.Item
                                                        key={i}
                                                        label={localeProperty(v, 'label') || 'Unknown Type'}
                                                        value={parseInt(v.id)}
                                                    />
                                                );
                                            })}
                                    </Picker>
                                </View>
                            </View>
                            <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.label}> {strings('model')}</Text>
                                    {mandatoryFields.includes('model') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                </View>

                                <View
                                    style={[
                                        styles.fieldContainer,
                                        ismakeModelvisibleEditable ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled,
                                    ]}
                                >
                                    <Picker
                                        selectedValue={(model && parseInt(model)) || ''}
                                        key={`model${modelOptions.length}`}
                                        enabled={ismakeModelvisibleEditable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'model')}
                                    >
                                        <Picker.Item key={2222} label={strings('pleaseselect') + ' ' + strings('model')} value={''} />
                                        {modelOptions &&
                                            modelOptions.map((v, i) => {
                                                return (
                                                    <Picker.Item
                                                        key={i}
                                                        label={localeProperty(v, 'label') || 'Unknown Type'}
                                                        value={parseInt(v.id)}
                                                    />
                                                );
                                            })}
                                    </Picker>
                                </View>
                            </View>
                        </View>
                        <View style={styles.fieldrow}>
                            <View style={[styles.labelContainer, styles.labelContainerColumnEnd]}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text style={styles.label}> {strings('color')}</Text>
                                    {mandatoryFields.includes('color') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                </View>

                                <View
                                    style={[
                                        styles.fieldContainer,
                                        ismakeModelvisibleEditable ? styles.fieldContainerPicker : styles.fieldContainerPickerDisabled,
                                    ]}
                                >
                                    <Picker
                                        selectedValue={(color && parseInt(color)) || ''}
                                        key={`color${colorOptions.length}`}
                                        enabled={ismakeModelvisibleEditable}
                                        style={styles.picker}
                                        onValueChange={this.handleFieldChange.bind(this, 'color')}
                                    >
                                        <Picker.Item key={24422} label={strings('pleaseselect') + ' ' + strings('color')} value={''} />
                                        {colorOptions &&
                                            colorOptions.map((v, i) => {
                                                return (
                                                    <Picker.Item
                                                        key={i}
                                                        label={localeProperty(v, 'label') || 'Unknown Type'}
                                                        value={parseInt(v.id)}
                                                    />
                                                );
                                            })}
                                    </Picker>
                                </View>
                            </View>
                            {(ADPCode && !isManualEntry && isPlateKindPlateColorPhNoVisible && (
                                <View style={(styles.labelContainer, styles.labelContainerColumnEnd)}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Text style={styles.label}> {strings('registeredPhoneNumberFull')}</Text>
                                        {mandatoryFields.includes('registeredPhoneNumber') && <Text style={{ color: 'red', marginLeft: 4 }}>*</Text>}
                                    </View>

                                    <View style={[styles.fieldContainer, { marginEnd: 5 }]}>
                                        <Text style={styles.inputDisabled}> {registeredPhoneNumber}</Text>
                                    </View>
                                </View>
                            )) ||
                                null}
                        </View>
                    </>
                ) : null}
            </View>
        );
    };
}
const mapStateToProps = (state, ownProps) => {
    const { dataLookups } = state.masterdata;
    return {
        //countryOptions: ownProps.countryOptions || dataLookups.country,
        makeOptions: ownProps.makeOptions || dataLookups.VehicleMake,
        colorOptions: ownProps.colorOptions || dataLookups.VehicleColor,
        vehiclePlateSource: dataLookups.VehiclePlateSource,
    };
};

export default connect(mapStateToProps)(VehicleViolator);
