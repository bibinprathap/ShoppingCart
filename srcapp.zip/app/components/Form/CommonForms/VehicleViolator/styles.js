import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';
export default EStyleSheet.create({
    contentContainer: {
        flex: 1,
        elevation: 2,
        marginVertical: 20,
        marginHorizontal: 5,
        borderRadius: 10,
    },
    formContainer: {
        backgroundColor: '$primaryLightBackground',
    },
    maskedInput: {
        textAlignVertical: 'center',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        paddingTop: 20,
    },
    input: {
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,
        height: 50,
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    inputDisabled: {
        color: '$primaryDarkTextColor',

        fontSize: 12,

        alignItems: 'flex-start',
        // marginStart: 10,
        paddingTop: 10,
        height: 50,
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        borderRadius: 4,
        elevation: 1,
    },
    placeholder: {
        color: '$primaryDarkPlaceholderColor',
    },
    labelContainer: {
        flex: 1,
        // flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        // marginHorizontal: 10,
        alignSelf: 'flex-start',
    },
    labelContainerColumnStart: {
        flex: 4,
        marginStart: 5,
    },
    labelContainerColumnEnd: {
        flex: 4,
        marginEnd: 5,
    },
    label: {
        fontSize: '$primaryTextXXS',
        color: '$primaryDarkTextColor',
        // maxWidth: 100,
        // minWidth: 120,
        justifyContent: 'flex-start',
    },
    button: {
        height: 50,

        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
    buttonSearch: {
        height: 50,

        justifyContent: 'center',
        alignItems: 'center',
    },

    buttonText: {
        fontSize: '$primaryTextMD',
        color: '$primaryWhite',
    },
    container: {
        flex: 1,
        borderWidth: '$primaryBorderThin',
        borderRadius: 4,
        borderColor: '$primaryMediumTextColor',
        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingHorizontal: 8,
    },
    containerWithOutBorder: {
        flex: 1,

        paddingVertical: 10,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingHorizontal: 8,
    },
    titleContainer: {
        flex: 1,
    },
    title: {
        fontSize: '$primaryTextLG',
        color: '$primaryDarkTextColor',
        marginStart: 10,
        alignSelf: 'flex-start',
    },
    fieldContainer: {
        flex: 1,
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        // marginHorizontal: 10,
        marginTop: 5,
    },
    fieldContainerAttachement: {
        backgroundColor: '$primaryLightBackground',
    },
    fieldContainerPicker: {
        height: 45,
        backgroundColor: '#ffffff',
        elevation: 1,
        borderRadius: 4,
    },
    fieldContainerPickerDisabled: {
        height: 45,

        elevation: 2,
        borderRadius: 4,
    },
    fieldrow: { flex: 1, flexDirection: 'row', marginVertical: 10 },
    picker: {
        height: 50,
        width: '100%',
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-start',
        color: '$primaryDarkTextColor',

        borderRadius: 4,
        elevation: 1,
    },
    outerContainerNoAttachment: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 10,
    },
    outerContainerWithAttachment: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonWithAttachmentsContainer: {
        flex: 1,
        maxWidth: 70,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    buttonContainer: {
        borderColor: '$primaryBorderColor',
        borderWidth: '$primaryBorderThin',
        padding: 5,
        borderRadius: 10,
    },
    emptyAttachmentListMessage: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
    spinner: {
        position: 'absolute',
        elevation: 1,
        backgroundColor: '$primaryWhite',
        right: 10,
        top: 10,
        padding: 5,
    },
});
