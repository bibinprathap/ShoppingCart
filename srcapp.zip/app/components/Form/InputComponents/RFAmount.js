import React, { memo } from 'react';
import { View } from 'react-native';
import { formatCurrency } from 'app/config/i18n/i18n';
import { IconAndLabel } from 'app/components';

export default memo(function(props) {
    const { input, meta, ...otherProps } = props;
    return (
        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginHorizontal: 10, minHeight: 55 }}>
            <IconAndLabel
                label={formatCurrency(input.value)}
                iconStyle={{ color: otherProps.iconColor }}
                icon={otherProps.icon}
                iconType={otherProps.iconType}
            />
        </View>
    );
});
