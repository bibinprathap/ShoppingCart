import React from 'react';
import PropTypes from 'prop-types';
import { View, Picker } from 'react-native';
import { Button, Text } from 'react-native-paper';
import { formStyles as styles, commonStyles } from 'app/components';
import { strings } from 'app/config/i18n/i18n';
import { connect } from 'react-redux';

class RFChildPicker extends React.Component {
    static propTypes = {
        input: PropTypes.shape({
            onChange: PropTypes.func.isRequired,
            value: PropTypes.string,
        }).isRequired,
    };

    handleValueChange = (val, idx) => {
        this.props.input.onChange(val, idx);
    };

    render() {
        const { options, input, meta, editable, formState, cascadingParent, validationerror, ...otherProps } = this.props;
        const { fieldHeight } = otherProps;
        const validationStyles = meta.touched && !meta.active ? (meta.valid ? {} : styles.invalid) : null;
        const errorStyle = meta.touched && meta.error ? styles.invalid : {};
        return (
            <View style={[{ flex: 1 }, validationStyles, { height: fieldHeight || 45 }, errorStyle]}>
                <Picker
                    selectedValue={input.value}
                    key={`${otherProps.labelE}_${options.length}`}
                    enabled={editable}
                    style={styles.picker}
                    onValueChange={this.handleValueChange}
                >
                    {options &&
                        options.map((v, i) => {
                            return <Picker.Item key={i} label={strings(v) || 'Unknown Type'} value={v} />;
                        })}
                </Picker>
                {validationerror && <Text style={[commonStyles.ValidationMessageText, { marginStart: 10 }]}>{validationerror}</Text>}
            </View>
        );
    }
}

const mapStateToProps = state => {
    return {
        formState: state.generic.form || {},
    };
};

export default connect(mapStateToProps)(RFChildPicker);
