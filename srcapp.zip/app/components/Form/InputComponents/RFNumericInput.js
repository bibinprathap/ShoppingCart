import React, { memo } from 'react';
import { NumericInput } from 'app/components';

export default memo(function(props) {
    const { input, meta, ...otherProps } = props;
    return (
        <NumericInput
            value={input.value || 0}
            initValue={input.value || 0}
            totalWidth={120}
            minValue={0}
            totalHeight={40}
            onChange={input.onChange}
        />
    );
});
