import React from 'react';
import { View, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import EStyleSheet from 'react-native-extended-stylesheet';
import * as Animatable from 'react-native-animatable';
import alertsHelper from 'app/api/helperServices/alerts';

const styles = EStyleSheet.create({
    running: { color: '$primaryMediumTextColor' },
    success: { color: '$primarySuccessColor' },
    error: { color: '$primaryErrorTextColor' },
});

const AnimatableIcon = Animatable.createAnimatableComponent(Icon);

export default function({ integrationData }) {
    if (!integrationData) return null;

    let alertType;
    let alertTitle;

    showAlert = () => {
        const msg = !!integrationData.error ? `${integrationData.message} [${integrationData.error.detail}]` : integrationData.message;
        alertsHelper.show(alertType, alertTitle, msg);
    };

    handleIconRef = ref => {
        this.icon = ref;
    };

    let showIcon = false;
    let iconProps = { size: 16, iterationCount: 1, easing: 'linear' };
    if (integrationData.running === true) {
        alertType = 'info';
        alertTitle = 'Working...';
        showIcon = true;
        iconProps = {
            ...iconProps,
            type: 'MaterialCommunityIcons',
            name: 'settings',
            color: styles.running.color,
            animation: 'rotate',
            iterationCount: 'infinite',
        };
    } else {
        if (integrationData.success === true) {
            alertType = 'success';
            alertTitle = 'Verified data';
            showIcon = true;
            iconProps = {
                ...iconProps,
                type: 'MaterialCommunityIcons',
                name: 'shield-check',
                color: styles.success.color,
                animation: 'fadeIn',
            };
        } else if (integrationData.success === false) {
            //show error only if explicit false value is provided
            alertType = 'error';
            alertTitle = 'Error';
            showIcon = true;
            iconProps = {
                ...iconProps,
                type: 'MaterialCommunityIcons',
                name: 'alert-circle-outline',
                color: styles.error.color,
                animation: 'bounce',
            };
        }
    }
    if (!showIcon) return null;

    return (
        <TouchableOpacity onPress={this.showAlert}>
            <View
                style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: 2,
                }}
            >
                <AnimatableIcon ref={this.handleIconRef} {...iconProps} useNativeDriver />
            </View>
        </TouchableOpacity>
    );
}
