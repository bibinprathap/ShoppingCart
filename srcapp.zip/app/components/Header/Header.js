import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TouchableOpacity, Image } from 'react-native';
import { Text, Appbar } from 'react-native-paper';
import { DrawerActions } from 'react-navigation-drawer';
import * as Animatable from 'react-native-animatable';
import { withNavigation } from 'react-navigation';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import { inspectionsHelper } from 'app/api/helperServices';
//import { createNewInspection } from 'app/actions/inspections';
import { authLogout } from 'app/actions/auth';
import { setLoading, setLoaded } from 'app/actions/loader';
import styles from './styles';
import images from 'app/images';
import { mainStackDefinition } from 'app/config/routs/defs';
import { NavigationActions } from 'react-navigation';
import { EntitySelectionDialog } from 'app/screens';
import alertsHelper from 'app/api/helperServices/alerts';
import { strings } from 'app/config/i18n/i18n';
import { Icon } from 'app/components';
import I18n from 'i18n-js';

class Header extends Component {
    state = {
        entitySelectionDialogShowing: false,
    };
    static propTypes = {
        navigation: PropTypes.object.isRequired,
        activeProfile: PropTypes.object,
    };

    constructor(props) {
        super(props);
    }
    handleViewRef = ref => (this.view = ref);

    componentDidUpdate(prevProps, prevState, snapshot) {
        const { notifications } = this.props;
        const unreadCount = notifications.unreadCount || 0;
        if (unreadCount > 0 && prevProps.notifications.unreadCount != unreadCount && this.view && unreadCount > prevProps.notifications.unreadCount) {
            this.view.bounce(1000);
        }
    }

    goBack = () => {
        // this.props.navigation.goBack('main');

        this.props.navigation.dispatch(NavigationActions.back());

        //  navigate('main');
    };

    toggleDrawer = () => {
        this.props.navigation.dispatch(DrawerActions.toggleDrawer());
    };

    beginInspection = selectedEntity => {
        const { navigation } = this.props;
        const inspectionTypeDetail = { inspEntityId: selectedEntity };
        const createdInspection = inspectionsHelper.createNew({ inspectionTypeDetail });
        inspectionsHelper.showInspection({ createdInspection, navigation });
    };

    handleOnBeginInspectionPress = () => {
        //this.beginInspection();
        this.setState({ entitySelectionDialogShowing: true });
    };

    hideEntitySelectionDialog = () => {
        this.setState({ entitySelectionDialogShowing: false });
    };

    handleOnEntityDialotRequestClose = () => {
        this.hideEntitySelectionDialog();
    };

    handleOnEntitySelected = selectedEntity => {
        const { navigation } = this.props;
        this.hideEntitySelectionDialog();
        inspectionsHelper.beginInspection({ inspEntityId: selectedEntity }, navigation);
    };

    navigateToNotifications = () => {
        this.props.navigation.navigate('notifications');
    };

    handleOnLogoutPress = () => {
        const { dispatch, navigation } = this.props;
        dispatch(setLoading({ options: { message: 'Signing out...' } }));
        Promise.resolve(dispatch(authLogout()))
            .then(() => {
                navigation.navigate('auth');
                dispatch(setLoaded());
            })
            .catch(() => {
                //handle error?
                navigation.navigate('auth');
                dispatch(setLoaded());
            });
    };

    render() {
        const { navigation, scene, loggedIn, activeProfile, notifications, selectedDashboardTab } = this.props;
        const unreadCount = notifications.unreadCount || 0;
        const { routeName, key } = navigation.state.routes[navigation.state.index];
        const { entitySelectionDialogShowing } = this.state;

        this.currentRoutedef = _.find(mainStackDefinition.routes, {
            key: key,
        });

        let title = this.currentRoutedef.title; //scene.descriptor.options.title;
        let subtitle = this.currentRoutedef.subtitle; //scene.descriptor.options.subtitle;
        let fullName = !activeProfile ? 'Unknown' : I18n.locale.indexOf('ar') > -1 ? activeProfile.displayNameA : activeProfile.displayNameE;
        if (key === 'dashboard') {
            //subtitle = `${subtitle} - ${strings(selectedDashboardTab)}`;
            title = `${title} - ${strings(selectedDashboardTab)}`;
        }
        while (fullName.indexOf(',,') > -1) fullName = fullName.replace(/,,/g, ',');
        fullName = fullName.replace(/,/g, ' ');
        //title = `${title}  -  ${fullName}`;
        //Todo: Add elevation to the appbar

        return (
            <Appbar style={styles.appBar}>
                {navigation.state.index > 0 && <Appbar.BackAction onPress={this.goBack} />}
                <View style={styles.startContainer}>
                    {/* <Appbar.Action icon={images.menu.content} onPress={this.toggleDrawer} color={styles.icon.color} /> */}
                    <Appbar.Content
                        title={title}
                        subtitle={subtitle}
                        titleStyle={styles.contentTitle}
                        subtitleStyle={styles.contentSubtitle}
                        style={styles.contentContainer}
                    />
                </View>
                {key !== 'profile' && (
                    <>
                        <View style={styles.endContainer}>
                            <Appbar.Action icon={images.notification.content} color={styles.icon.color} onPress={this.navigateToNotifications} />
                            {unreadCount > 0 && (
                                <TouchableOpacity onPress={this.navigateToNotifications} style={styles.notificationUnread}>
                                    <Animatable.View ref={this.handleViewRef}>
                                        <Text style={styles.notificationUnreadCount}>{unreadCount}</Text>
                                    </Animatable.View>
                                </TouchableOpacity>
                            )}
                            {/* <Appbar.Action icon={images.new.content} onPress={this.handleOnBeginInspectionPress} color={styles.icon.color} /> */}
                        </View>
                        <EntitySelectionDialog
                            isShowing={entitySelectionDialogShowing}
                            onRequestClose={this.handleOnEntityDialotRequestClose}
                            onEntitySelected={this.handleOnEntitySelected}
                        />
                    </>
                )}
                {key === 'profile' && (
                    <View style={styles.endContainer}>
                        <TouchableOpacity onPress={this.handleOnLogoutPress}>
                            <Icon name="logout" type="MaterialCommunityIcons" style={styles.icon} />
                        </TouchableOpacity>
                    </View>
                )}
            </Appbar>
        );
    }
}

mapStateToProps = state => {
    const allProfiles = state.auth.profiles;
    const activeProfileUserId = state.auth.activeProfileUserId;
    const activeProfile = allProfiles && activeProfileUserId ? _.find(allProfiles, { applicationUserId: activeProfileUserId }) : undefined;
    return {
        loggedIn: state.auth.loggedIn,
        activeProfile: activeProfile,
        notifications: state.notifications,
        selectedDashboardTab: state.settings.selectedDashboardTab || 'tasks',
    };
};

export default connect(mapStateToProps)(Header);
