import React from 'react';
import { View } from 'react-native';
import { Appbar } from 'react-native-paper';
import styles from './styles';
import { checkDuplicate } from 'app/actions/inspections';
import { DuplicateCheckButton } from 'app/components';

const InspectionHeader = props => {
    backAction = () => {
        if (props.backAction) {
            props.backAction();
        } else if (props.navigation) {
            props.navigation.pop();
        }
        return null;
    };

    handleCheckDuplicate = () => {
        const { dispatch } = props;
        dispatch(checkDuplicate());
    };

    return (
        <Appbar style={styles.appBar}>
            <View style={styles.containerGeneric}>
                <Appbar.Action onPress={this.backAction} color={styles.icon.color} icon="home" />
                {(props.title && (
                    <Appbar.Content
                        title={props.title}
                        titleStyle={styles.contentTitle}
                        style={styles.contentContainer}
                        subtitle={props.subTitle || null}
                        subtitleStyle={styles.contentSubtitle}
                    />
                )) ||
                    null}
            </View>
        </Appbar>
    );
};

export default InspectionHeader;
