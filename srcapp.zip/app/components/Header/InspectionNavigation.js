import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, I18nManager, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { Appbar, Text } from 'react-native-paper';
import _ from 'lodash';
import { inspectionStackDefinition } from 'app/config/routs/defs';
import { inspectionsHelper } from 'app/api/helperServices';
import { strings } from 'app/config/i18n/i18n';
import styles from './styles';
import { Icon, createRotatable } from 'app/components';

import { setPreference } from 'app/actions/generic';

class InspectionNavigation extends Component {
    static propTypes = {
        navigation: PropTypes.object.isRequired,
        local: PropTypes.string,

        currentInspection: PropTypes.object,
        services: PropTypes.array,
    };

    constructor(props) {
        super(props);

        this.state = { slideIcon: props.preference.inspectionSideNavigation ? 'chevron-double-down' : 'chevron-double-up' };
    }

    iconAnimate = createRotatable(Icon);

    goBack = () => {
        this.props.navigation.navigate(this.previousRouteName);
    };

    goForward = () => {
        this.props.navigation.navigate(this.nextRouteName);
    };

    handleSideNav = () => {
        const { dispatch, preference } = this.props;
        dispatch(setPreference({ inspectionSideNavigation: !preference.inspectionSideNavigation }));
    };

    render() {
        const { navigation, scene, currentInspection, services, currentInspectionVersion } = this.props;
        const { routeName, key } = navigation.state.routes[navigation.state.index];

        if (routeName == 'attachments') return null;

        const adjustedRoutes = inspectionsHelper.getRoutes();
        this.currentRouteIndex = _.findIndex(adjustedRoutes, {
            key: key,
        });
        this.currentRoute = _.find(adjustedRoutes, {
            key: key,
        });

        this.currentRoutedef = _.find(inspectionStackDefinition.routes, {
            key: key,
        });

        this.nextRoute = null;
        this.nextRouteName = null;
        this.nextRouteTitle = null;
        this.previousRouteTitle = strings('dashboard');

        this.previousRouteName = 'main';
        const totalRoutes = adjustedRoutes.length;
        if (this.currentRouteIndex < totalRoutes - 1) {
            this.nextRoute = adjustedRoutes[this.currentRouteIndex + 1];
            this.nextRouteName = this.nextRoute.key;
            const nextRouteDef = _.find(inspectionStackDefinition.routes, {
                key: this.nextRouteName,
            });
            this.nextRouteTitle = nextRouteDef.title || '';
        }
        if (this.currentRouteIndex > 0) {
            const previousRoute = adjustedRoutes[this.currentRouteIndex - 1];
            if (!!previousRoute && !!previousRoute.key) this.previousRouteName = previousRoute.key;

            const prevousRouteDef = _.find(inspectionStackDefinition.routes, {
                key: this.previousRouteName,
            });
            this.previousRouteTitle = prevousRouteDef.title || strings('dashboard');
        }

        const RotatableIcon = this.iconAnimate;

        return (
            <Appbar style={styles.appBarInspection}>
                <RotatableIcon
                    type="MaterialCommunityIcons"
                    name={this.state.slideIcon}
                    style={styles.appBarInspectionIcon}
                    onRotatablePress={this.handleSideNav}
                    containerStyle={[styles.appBarInspectionBtnContainer, { width: 50 }]}
                />
                <TouchableOpacity style={styles.appBarInspectionBtnContainer} onPress={this.goBack}>
                    <Icon
                        type="MaterialCommunityIcons"
                        name={I18nManager.isRTL ? 'chevron-right' : 'chevron-left'}
                        style={styles.appBarInspectionIcon}
                    />
                    {this.previousRouteTitle && <Text style={styles.appBarInspectionTitle}>{this.previousRouteTitle}</Text>}
                </TouchableOpacity>
                {!!this.nextRouteName && (
                    <TouchableOpacity style={styles.appBarInspectionBtnContainer} onPress={this.goForward}>
                        {this.nextRouteTitle && <Text style={styles.appBarInspectionTitle}>{this.nextRouteTitle}</Text>}
                        <Icon
                            type="MaterialCommunityIcons"
                            name={I18nManager.isRTL ? 'chevron-left' : 'chevron-right'}
                            style={styles.appBarInspectionIcon}
                        />
                    </TouchableOpacity>
                )}
            </Appbar>
        );
    }
}

mapStateToProps = state => {
    const currentInspection = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        currentInspection,
        services: state.masterdata.services,
        preference: state.generic.preference,
        currentInspectionVersion: state.inspections.currentInspectionVersion,
    };
};

export default connect(mapStateToProps)(InspectionNavigation);
