import React, { Component } from 'react';
import { I18nManager, Dimensions } from 'react-native';
import { View, Text, SafeAreaView, TouchableWithoutFeedback, ScrollView } from 'react-native';
import { ScrollViewWithIndicator } from 'app/components';
import styles from './styles';

const NavigationTab = props => {
    const { screenProps, navigation } = props;
    const routes = navigation.state.routes;
    if (routes.length < 2) return null;
    else
        return (
            <SafeAreaView>
                <View style={styles.containerrow}>
                    <ScrollViewWithIndicator showsHorizontalScrollIndicator={false}>
                        {routes.map((route, index) => {
                            const focused = navigation.state.index === index;
                            const headerItemContainerStyles = [styles.headerItemContainer, focused ? styles.headerItemContainerSelected : null];
                            const headerItemTextStyles = [styles.headerItemText, focused ? styles.headerItemTextSelected : null];
                            const title = route.params && route.params.tabTitle;
                            const tabSubTitle = route.params && route.params.tabSubTitle;
                            return (
                                <TouchableWithoutFeedback key={route.routeName} onPress={() => navigation.navigate(route.routeName)}>
                                    <View
                                        style={[
                                            headerItemContainerStyles,
                                            {
                                                // flex: index / routes.length,
                                            },
                                        ]}
                                        key={`${route.routeName}_${index}`}
                                    >
                                        <Text style={headerItemTextStyles}>{title}</Text>
                                        {tabSubTitle && <Text style={[headerItemTextStyles, styles.tabSubTitle]}>{tabSubTitle}</Text>}
                                    </View>
                                </TouchableWithoutFeedback>
                            );
                        })}
                    </ScrollViewWithIndicator>
                </View>
            </SafeAreaView>
        );
};

export default NavigationTab;
