import React, { Component } from 'react';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { getAdmIconSet, getIconUnicode } from 'app/api/helperServices/utils';
const AdmIcon = getAdmIconSet();

const defaultAdmIcon = 'wf-1000';

class Icon extends Component {
    render() {
        const { type, ...props } = this.props;
        switch (type) {
            case 'MaterialCommunityIcons':
                return <MaterialCommunityIcons {...props} />;
            case 'AdmIcon':
                return <AdmIcon {...props} />;
            default:
                return <AdmIcon name={defaultAdmIcon} {...props} />;
        }
    }
}

class IconButton extends Component {
    render() {
        const { type, children, ...props } = this.props;
        switch (type) {
            case 'MaterialCommunityIcons':
                return <MaterialCommunityIcons.Button {...props}>{children}</MaterialCommunityIcons.Button>;
            case 'AdmIcon':
                return <AdmIcon.Button {...props}>{children}</AdmIcon.Button>;
            default:
                return (
                    <AdmIcon.Button name={defaultAdmIcon} {...props}>
                        {children}
                    </AdmIcon.Button>
                );
        }
    }
}
export { Icon, IconButton };
