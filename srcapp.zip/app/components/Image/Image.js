import React, { Component } from 'react';
import { ActivityIndicator, View, TouchableOpacity, Text, I18nManager, TouchableHighlight } from 'react-native';
import FastImage from 'react-native-fast-image';
import EStyleSheet from 'react-native-extended-stylesheet';
import { connect } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import * as Animatable from 'react-native-animatable';
import { attachmentsHelper } from 'app/api/helperServices';
//import { Placeholder, PlaceholderMedia, ShineOverlay } from 'rn-placeholder';

import moment from 'moment';
const AnimatableIcon = Animatable.createAnimatableComponent(Icon);
const styles = EStyleSheet.create({
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        width: '100%',
        height: '100%',
    },
    animatedContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
        position: 'absolute',
        width: '100%',
        height: '100%',
        color: '#FFFFFF',
    },
    zoomableAnimatedContainer: {
        position: 'absolute',
        top: 5,
        left: 700,
        color: '#FFFFFF',
    },
});

class Image extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isLoading: false,
            isError: false,
        };
        this.handleOnLoadEnd = this.handleOnLoadEnd.bind(this);
        this.handleOnLoadStart = this.handleOnLoadStart.bind(this);
        this.handleOnLoad = this.handleOnLoad.bind(this);
    }
    setIsLoading = loading => {
        this.setState({ isLoading: loading });
    };

    handleOnError = error => {
        this.setState({ isError: true });
    };

    handleOnLoad = () => {
        this.setState({ isError: false });
    };

    handleOnLoadEnd = () => {
        this.setIsLoading(false);
    };

    handleOnLoadStart = () => {
        this.setIsLoading(true);
    };

    render() {
        let imageObj = this.props.metadata;
        if (imageObj && (!imageObj.width || !imageObj.height)) {
            imageObj = attachmentsHelper.getCommonImageProperties(imageObj);
        }

        let { location } = imageObj;
        let { coords } = location || {};
        let { latitude, longitude, time } = coords || {};
        const { editable, hideDelete } = this.props;
        const { isLoading, isError } = this.state;
        let imageTime = time && moment(time).format('YYYY-MM-DD HH:mm:ss');
        const { mobileReferenceNumber, path, uploading, error } = this.props.metadata;
        const pendingUpload = this.props.pendingUploadDocs[mobileReferenceNumber];
        let attachmenturi = path;
        let attachmentuploading = uploading;
        let attachmentuploaded = true;
        let attachmenterror = error;
        if (pendingUpload) {
            attachmentuploading = pendingUpload.uploading;
            attachmentuploaded = pendingUpload.uploaded;
            attachmenterror = pendingUpload.error;
        } else {
            const doc = attachmentsHelper.verifyImageProperties(imageObj);
            if (doc && doc.path) {
                attachmenturi = doc.path;
            }
        }

        const handleRef = ref => (this.theImage = ref);

        let iconSize = null;
        let brokenImage = null;
        if (!isLoading && isError) {
            const defaultStyle = { width: 70, height: 70 };
            const { style = [{ ...defaultStyle }] } = this.props;
            let flattenedStyles = {};
            if (Array.isArray(style)) {
                for (var i = 0; i < style.length; i++) {
                    flattenedStyles = { ...flattenedStyles, ...style[i] };
                }
            } else {
                flattenedStyles = { ...defaultStyle };
            }
            iconSize = flattenedStyles.height;
            brokenImage = (
                <View style={{ marginTop: -iconSize }}>
                    <Icon type="MaterialCommunityIcons" name="image-broken-variant" size={iconSize} />
                </View>
            );
        }

        return (
            <>
                <FastImage
                    ref={handleRef}
                    onLoadStart={this.handleOnLoadStart}
                    onLoadEnd={this.handleOnLoadEnd}
                    onError={this.handleOnError}
                    onLoad={this.handleOnLoad}
                    {...{
                        ...this.props,
                        source: {
                            uri: attachmenturi,
                            uploading: attachmentuploading,
                            uploaded: attachmentuploaded,
                            error: attachmenterror,
                            priority: FastImage.priority.normal,
                            headers: { '.ASPXAUTH': this.props.authCode },
                        },
                    }}
                />
                {brokenImage}
                {!isLoading && !isError && (latitude || longitude || time) && (
                    <View style={tempStyles.coordsContainer}>
                        {latitude && (
                            <Animatable.Text
                                style={tempStyles.coordsText}
                                animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                                duration={300}
                                useNativeDriver
                            >
                                Latitude: {latitude}
                            </Animatable.Text>
                        )}
                        {longitude && (
                            <Animatable.Text
                                style={tempStyles.coordsText}
                                animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                                duration={300}
                                useNativeDriver
                            >
                                Longitude: {longitude}
                            </Animatable.Text>
                        )}
                        {imageTime && (
                            <Animatable.Text
                                style={tempStyles.coordsText}
                                animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                                duration={300}
                                useNativeDriver
                            >
                                Time: {imageTime}
                            </Animatable.Text>
                        )}
                    </View>
                )}
                {isLoading && (
                    <View style={styles.loaderContainer}>
                        <ActivityIndicator size="small" animating color={EStyleSheet.value('$primarySelectedItem')} />
                        {/* <Placeholder
                            Animation={ShineOverlay}
                            style={{
                                marginVertical: 6,
                                marginHorizontal: 2,
                                borderRadius: 4,
                            }}
                        >
                            <PlaceholderMedia
                                style={[
                                    {
                                        width: 100,
                                        height: 100,
                                        marginTop: 0,
                                    },
                                ]}
                            />
                        </Placeholder> */}
                    </View>
                )}
                {!isLoading && attachmentuploading && (
                    <View style={this.props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer}>
                        <AnimatableIcon
                            type="MaterialCommunityIcons"
                            name={'cloud'}
                            size={this.props.isZoomable ? 30 : 14}
                            duration={1000}
                            delay={0}
                            animation={{
                                0: {
                                    color: 'rgba(0,0,0,0.6)',
                                },
                                0.5: {
                                    color: 'rgba(169,169,169, 0.5)',
                                },
                                1: {
                                    color: 'rgba(0,0,0,0.6)',
                                },
                            }}
                            iterationCount="infinite"
                            style={{ position: 'absolute', top: 0, left: 0, paddingLeft: this.props.isZoomable ? 0 : 5 }}
                        />

                        <AnimatableIcon
                            ref={ref => (this.icon = ref)}
                            type="MaterialCommunityIcons"
                            name={'chevron-up'}
                            size={this.props.isZoomable ? 15 : 7}
                            color="white"
                            animation={{
                                0: { translateY: 0, opacity: 1 },
                                0.5: { translateY: this.props.isZoomable ? -6 : -3, opacity: 1 },
                                1: {
                                    translateY: this.props.isZoomable ? -12 : -6,
                                    opacity: 0,
                                },
                            }}
                            duration={1000}
                            delay={0}
                            easing={t => Math.pow(t, 1.7)}
                            iterationCount="infinite"
                            style={{ position: 'absolute', top: this.props.isZoomable ? 12 : 5, left: this.props.isZoomable ? 7 : 8 }}
                            useNativeDriver
                        />
                    </View>
                )}
                {!isLoading && attachmentuploaded && (
                    <View style={[this.props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer, { paddingLeft: 3 }]}>
                        <Icon
                            type="MaterialCommunityIcons"
                            name="cloud-check"
                            color="#ffffff"
                            size={this.props.isZoomable ? 30 : 14}
                            style={[styles.remarkTickMarkIcon]}
                        />
                    </View>
                )}
                {!this.props.isZoomable && !isLoading && attachmenterror && (
                    <View style={[this.props.isZoomable ? styles.zoomableAnimatedContainer : styles.animatedContainer, { paddingLeft: 3 }]}>
                        <Icon
                            type="MaterialCommunityIcons"
                            name="cloud-off-outline"
                            color="#ff0000"
                            size={this.props.isZoomable ? 30 : 14}
                            style={[styles.remarkTickMarkIcon]}
                        />
                    </View>
                )}
            </>
        );
    }
}

mapStateToProps = state => {
    return {
        pendingUploadDocs: state.attachments.pendingUploadDocs || {},
        authCode: state.auth.authCode,
    };
};

export default connect(mapStateToProps)(Image);

const tempStyles = EStyleSheet.create({
    coordsContainer: {
        backgroundColor: '$primaryDarkBackground',
        position: 'absolute',
        left: 250,
        top: 20,
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 5,
        opacity: 0.5,
    },
    coordsText: {
        textAlign: 'left',
        textAlignVertical: 'center',
        color: '$primaryWhite',
        opacity: 1,
        paddingVertical: 1,
        fontSize: '$primaryTextXXS',
    },
});
