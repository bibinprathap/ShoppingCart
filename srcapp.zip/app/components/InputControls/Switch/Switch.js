import React from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Switch as PaperSwitch, Text } from 'react-native-paper';
import { strings } from 'app/config/i18n/i18n';
import { IconAndLabel } from 'app/components';
import styles from './styles';

class Switch extends React.Component {
    static propTypes = {
        onChange: PropTypes.func,
        value: PropTypes.any,
        label: PropTypes.string,
        showHint: PropTypes.bool,
        iconProps: PropTypes.any,
        renderLabel: PropTypes.func,
    };

    render() {
        const { renderLabel, onChange, value, label, showHint = true, iconProps, editable, containerStyle, positiveHint, negativeHint } = this.props;
        const { ...switchProps } = this.props;
        let hint = '';
        if (!!value) {
            hint = positiveHint ? positiveHint : strings('yes');
        } else {
            hint = negativeHint ? negativeHint : strings('no');
        }

        const container = containerStyle ? [styles.container, containerStyle] : styles.container;

        return (
            <View style={container}>
                {!!renderLabel && renderLabel(switchProps)}
                {!renderLabel && <IconAndLabel label={label} iconProps={iconProps} />}
                <View style={styles.switchContainer}>
                    {!!showHint && !!hint && <Text>{hint}</Text>}
                    <PaperSwitch
                        disabled={!editable}
                        value={value}
                        onValueChange={onChange}
                        color={!!value ? styles.enabled.color : styles.disabled.color}
                    />
                </View>
            </View>
        );
    }
}

export default Switch;
