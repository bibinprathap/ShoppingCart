import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginHorizontal: 10,
        //minHeight: 60,
    },
    switchContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    enabled: {
        color: '$primaryYesButtonBackground',
    },
    disabled: {
        color: '$primaryDarkPlaceholderColor',
    },
});
