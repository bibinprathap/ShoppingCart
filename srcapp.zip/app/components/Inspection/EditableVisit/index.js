import React, { Component } from 'react';
import { View, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import styles from './styles';
import {
    valueChanged,
    infoChanged,
    addBusinessEntityTocheckItems,
    infoViolatorChanged,
    removeBusinessEntityFromcheckItems,
} from 'app/actions/inspections';
import {
    InspectionDetail,
    GeneralInfoForm,
    DistortionForm,
    DynamicForm,
    ResUnitOccupancyForm,
    FoodTruckAndOutdoor,
    FoodTruckAndOutdoorFollowUp,
    NoisePollution,
    AbandonedVehicleForm,
    GeneralAppearanceVehicleForm,
    FollowupForm,
    ViolationsFollowup,
    EngineerReviewApproved,
    MoreInfoForm,
    ResUnitOccupancyWarrantApprovedForm,
    IconButton,
    SiteVisit,
} from 'app/components';

import { strings } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { _state } from 'app/config/store';
import { shallowEqual } from 'app/api/helperServices';
import BusinessEntityList from 'app/screens/inspection/BusinessEntity/BusinessEntityList';

import { saveNewInspection, cancelInspection } from 'app/actions/inspections';
import { tasksTabLoad } from 'app/actions/generic';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { inspectionDialogPendingTabReload } from 'app/actions/inspectionDialog';

const EditableVisitContent = props => {
    const {
        visit,
        visitIndex,
        refNumber,
        inspection,
        backAction,
        dispatch,
        currentInspectionVersion,
        pendingUploadDocs,
        handleBusinessEntitySelected,
        handleOnViolatorEdited,
        handleOnViolatorRemoved,
        handleValueChange,
        handleAttachmentChange,
        handleVisitInfoChange,
        handleInfoChange,
        isSubmitable,
        onInit,
        calibration,
    } = props;
    const editable = inspectionsHelper.getIsEditable({ inspection });
    const { inspectionTypeDetail } = inspection;
    const selectedVisit = visit;
    const selectedVisitValues = visit.values;
    const inspectionDefinition = visit.def;
    let content = null;
    if (inspectionDefinition) {
        if (inspectionDefinition.type === 'checklist') {
            let currentViolator;
            let currentVisit;
            let existingViolators;
            if (inspectionTypeDetail && (inspectionTypeDetail.inspEntityId != 1000 || inspectionTypeDetail.workflowConst == 'MimsHealthInspection')) {
                currentVisit = inspectionsHelper.getCurrentVisit(inspection).currentVisit;
                existingViolators = inspectionsHelper.getAllViolators({ violators: inspection.violators || [], visit: currentVisit });
                if (existingViolators) {
                    const existingViolatorArray = Object.getOwnPropertyNames(existingViolators);
                    if (existingViolatorArray.length > 0) currentViolator = existingViolators[existingViolatorArray[0]];
                }
            }
            content = (
                <View style={[styles.contentContainer, styles.checklistContainer]}>
                    {inspectionTypeDetail &&
                        (inspectionTypeDetail.inspEntityId != 1000 || inspectionTypeDetail.workflowConst == 'MimsHealthInspection') && (
                            <ScrollView style={{ maxHeight: 150 }}>
                                <BusinessEntityList
                                    dispatch={dispatch}
                                    inspection={inspection}
                                    violator={currentViolator}
                                    editable={editable}
                                    existingViolators={existingViolators}
                                    onViolatorSelected={handleBusinessEntitySelected}
                                    onViolatorEdited={handleOnViolatorEdited}
                                    onViolatorRemoved={handleOnViolatorRemoved}
                                    buttonTitle={
                                        inspectionTypeDetail.workflowConst == 'MimsHealthInspection' ? strings('violator') : strings('establishment')
                                    }
                                />
                            </ScrollView>
                        )}
                    <InspectionDetail
                        def={inspectionDefinition.def}
                        values={selectedVisitValues}
                        editable={editable}
                        showAllCheckItem={
                            (inspectionTypeDetail && inspectionTypeDetail.inspEntityId != 1000) ||
                            (inspectionTypeDetail && inspectionTypeDetail.workflowConst == 'MimsHealthInspection') ||
                            (inspectionTypeDetail &&
                                inspectionTypeDetail.inspEntityId == 1000 &&
                                inspectionTypeDetail.workflowConst == 'MimsInformationRequestOnDemand')
                        }
                        onValuechanged={handleValueChange}
                        onAttachmentChanged={handleAttachmentChange}
                        onInit={onInit}
                    />
                </View>
            );
        } else if (inspectionDefinition.type === 'form') {
            content = (
                <FormComponents
                    inspectionDefinition={inspectionDefinition}
                    selectedVisit={selectedVisit}
                    inspection={inspection}
                    handleVisitInfoChange={handleVisitInfoChange}
                    handleInfoChange={handleInfoChange}
                    editable={editable}
                    currentInspectionVersion={currentInspectionVersion}
                    backAction={backAction}
                    dispatch={dispatch}
                    visitIndex={visitIndex}
                    refNumber={refNumber}
                    dataLookups={props.dataLookups}
                    pendingUploadDocs={pendingUploadDocs}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                    calibration={calibration}
                />
            );
        } else {
            //can there be any other kind of inspection?
            content = (
                <View style={[styles.contentContainer, styles.unknownInspectionContainer]}>
                    <Text>{strings('unknownInspectionDef')}</Text>
                </View>
            );
        }
    }
    return content;
};

const FixedForm = ({
    name,
    key,
    title,
    onFormChange,
    initialValues,
    editable,
    currentInspectionVersion,
    dispatch,
    dataLookups,
    inspection,
    visitIndex,
    pendingUploadDocs,
    isSubmitable,
    onInit,
    calibration,
}) => {
    switch (name) {
        case 'generalInfo':
            return (
                <GeneralInfoForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{ remar22222ks: { editable: true } }}
                    onInit={onInit}
                />
            );
        case 'distortionForm':
            return (
                <DistortionForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    dispatch={dispatch}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                    pendingUploadDocs={pendingUploadDocs}
                    onInit={onInit}
                />
            );
        case 'generalAppearanceVehicleInfo':
            return (
                <GeneralAppearanceVehicleForm
                    key={key}
                    formName={name}
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].abandonedVehicleInfo}
                    onFormChange={onFormChange}
                    // needValidation={false}
                    currentInspectionVersion={currentInspectionVersion}
                    onInit={onInit}
                />
            );
        case 'siteVisit':
            return (
                <SiteVisit
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    initialValue={initialValues}
                    inspection={inspection}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                    dispatch={dispatch}
                    visitIndex={visitIndex}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        case 'foodTruckAndOutdoorSeating':
            return (
                <FoodTruckAndOutdoor
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    inspection={inspection}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                    dispatch={dispatch}
                    visitIndex={visitIndex}
                    onInit={onInit}
                />
            );
        case 'foodTruckAndOutdoorSeatingFollowUp':
            return (
                <FoodTruckAndOutdoorFollowUp
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violationActionTypes={inspection.visits[visitIndex].followupForm.violationActionTypes || []}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );

        case 'noisePollution':
            return (
                <NoisePollution
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    values={initialValues}
                    inspection={inspection}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    formProps={{}}
                    dispatch={dispatch}
                    visitIndex={visitIndex}
                    onInit={onInit}
                    calibration={calibration}
                />
            );
        case 'resUnitOccupancySuspicion':
            return (
                <ResUnitOccupancyForm
                    formName={name}
                    key={key}
                    formTitle={title}
                    onFormChange={onFormChange}
                    initialValues={initialValues}
                    currentInspectionVersion={currentInspectionVersion}
                    editable={editable}
                    buildingTypeOptions={dataLookups.buildingType}
                    formProps={{}}
                    dispatch={dispatch}
                    visitIndex={visitIndex}
                    onInit={onInit}
                />
            );
        case 'abandonedVehicleInfo':
            return (
                <AbandonedVehicleForm
                    key={key}
                    formName={name}
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].abandonedVehicleInfo}
                    onFormChange={onFormChange}
                    // needValidation={false}
                    currentInspectionVersion={currentInspectionVersion}
                    onInit={onInit}
                />
            );

        case 'abandonedVehiclesFollowup':
            return (
                <ViolationsFollowup
                    yardOptions={(dataLookups || {}).vehicleYard}
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    actionTypeOptions={
                        inspection.visits[visitIndex].followupForm ? inspection.visits[visitIndex].followupForm.violationActionTypes || [] : []
                    }
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        case 'moreInfoFollowup':
            return (
                <MoreInfoForm
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        case 'resUnitOccupancyWarrantApproved':
            return (
                <ResUnitOccupancyWarrantApprovedForm
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        case 'distrotionFollowup':
            return (
                <FollowupForm
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        case 'buildingPenaltyFollowup':
        case 'generalAppearanceVehicleInfo':
            return (
                <ViolationsFollowup
                    hideYard={true}
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    actionTypeOptions={
                        inspection.visits[visitIndex].followupForm ? inspection.visits[visitIndex].followupForm.violationActionTypes || [] : []
                    }
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );
        // case 'buildingPenaltyFollowup':
        case 'engApprovalFollowup':
            return (
                <EngineerReviewApproved
                    hideYard={true}
                    visitIndex={visitIndex}
                    dispatch={dispatch}
                    editable={editable}
                    inspection={inspection}
                    actionTypeOptions={
                        inspection.visits[visitIndex].followupForm ? inspection.visits[visitIndex].followupForm.violationActionTypes || [] : []
                    }
                    initialValue={inspection.visits[visitIndex].followupForm}
                    violator={{}}
                    violation={{ checkItem: { inspTypeCheckItemId: 0 } }}
                    isSubmitable={isSubmitable}
                    onInit={onInit}
                />
            );

        default:
            return <Text>{`Invalid fixed form name:${name}`}</Text>;
    }
};

const FormComponents = ({
    inspectionDefinition,
    selectedVisit,
    inspection,
    handleVisitInfoChange,
    handleInfoChange,
    editable,
    currentInspectionVersion,
    backAction,
    dispatch,
    visitIndex,
    refNumber,
    dataLookups,
    pendingUploadDocs,
    isSubmitable,
    onInit,
    calibration,
}) => {
    let theForms = null;
    if (inspectionDefinition && inspectionDefinition.type === 'form') {
        theForms = inspectionDefinition.def.map((formDef, index) => {
            let TheFormComponent = undefined;
            const theKey = `${formDef.name}_${index}`;
            const formChangeHandler = formDef.scope == 'visit' ? handleVisitInfoChange : handleInfoChange;
            const initialValues =
                formDef.scope == 'visit' ? selectedVisit && selectedVisit[formDef.name] : inspection.info && inspection.info[formDef.name];

            if (formDef.formType == 'fixed') {
                return (
                    <FixedForm
                        name={formDef.name}
                        key={theKey}
                        onFormChange={formChangeHandler}
                        initialValues={initialValues}
                        editable={editable}
                        currentInspectionVersion={currentInspectionVersion}
                        dispatch={dispatch}
                        visitIndex={visitIndex}
                        dataLookups={dataLookups}
                        inspection={inspection}
                        pendingUploadDocs={pendingUploadDocs}
                        isSubmitable={isSubmitable}
                        onInit={onInit}
                        calibration={calibration}
                    />
                );
            } else {
                return (
                    <DynamicForm
                        key={theKey}
                        formDef={{ ...formDef, editable: editable }}
                        initialValues={initialValues}
                        values={initialValues}
                        formChangeHandler={formChangeHandler}
                        currentInspectionVersion={currentInspectionVersion}
                        formProps={{ attachmentList: { editable: true } }}
                        onInit={onInit}
                    />
                );
            }
        });
    }
    return (
        <View style={[styles.contentContainer, styles.formContainer]}>
            <ScrollView style={{ flex: 1 }}>{theForms}</ScrollView>
        </View>
    );
};

export default class EditableVisit extends Component {
    constructor(props) {
        super(props);
        this.handleVisitInfoChange = this.handleVisitInfoChange.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.isSubmitable = this.isSubmitable.bind(this);
        this.state = { isAllowedToSave: false, errorLogs: {}, initOptions: { isAllowedToCancel: false, cancelHandler: undefined } };
    }

    isSubmitable = params => {
        const { isAllowedToSave, err } = params;
        if (isAllowedToSave != this.state.isAllowedToSave || JSON.stringify(this.state.errorLogs) != JSON.stringify(err))
            this.setState({ isAllowedToSave, errorLogs: err });
    };

    shouldComponentUpdate(nextProps, nextState) {
        let shouldUpdate = shallowEqual(this.props, nextProps, this.state, nextState); //for now always rerender
        //if (shouldUpdate) this.preRender(nextProps);
        return shouldUpdate;
    }

    handleInfoChange = (values, dispatch, props, previousValues) => {
        this.props.dispatch(infoChanged(props.form, values));
    };

    handleVisitInfoChange = async (values, dispatch, props, previousValues) => {
        const { visitIndex } = this.props;
        this.props.dispatch(infoChanged(props.form, values, visitIndex));
    };

    handleValueChange = newValues => {
        const { visitIndex } = this.props;
        this.props.dispatch(infoChanged('values', newValues, visitIndex));
    };

    handleAttachmentChange = newValues => {
        /*
            for now we dispatch valueChanged action which will take care of saving the updated attachments to the store
            we may want to change this in future, to trigger upload in the background even before user saves their work
        */
        this.props.dispatch(
            valueChanged({
                visitIndex: this.props.visitIndex,
                newValues: newValues,
            })
        );
    };

    handleBusinessEntitySelected = async callProps => {
        const { selectedViolator, changed } = callProps;
        const { dispatch, inspection } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        if (changed) {
            await dispatch(infoViolatorChanged({ baseInfo: { ...selectedViolator } }));
        }

        // Adding violator for MimsHealthInspection handled in violationItem
        if (inspection.inspectionTypeDetail.workflowConst != 'MimsHealthInspection') {
            await dispatch(
                addBusinessEntityTocheckItems({
                    currentVisitIndex,
                    violator: selectedViolator,
                })
            );
        }
    };
    handleOnViolatorEdited = async callProps => {
        const { editedViolator, inspTypeCheckItemId, changed, violationTypeId } = callProps;
        const { dispatch, inspection, onViolatorSelected, onActionChange } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        if (changed) {
            await dispatch(infoViolatorChanged({ baseInfo: { ...editedViolator, isPresent: editedViolator.isPresent } }));
        }
    };

    handleOnViolatorRemoved = async () => {
        const { dispatch, inspection } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        await dispatch(removeBusinessEntityFromcheckItems({ currentVisitIndex }));
    };

    handleSave = async () => {
        const { isAllowedToSave } = this.state;
        const { dispatch, inspection, navigation } = this.props;
        if (isAllowedToSave) {
            let PendingAttachements = [];
            const blockingTaskOptions = {
                id: 'saveInspection',
                message: strings('savingInspection'),
                autoClose: true,
                autoRetry: false,
                allowCancel: false,
                maxTries: 5,
                requestCancel: () => {
                    // cancelRequested = true;
                },
                runner: async (options, updateOptions) => {
                    let coords = null;
                    try {
                        PendingAttachements = inspectionsHelper.getPendingAttachementList(inspection, true);
                        if (PendingAttachements.length == 0) {
                            let newinspection = {};
                            const setnewInspection = data => {
                                newinspection = data;
                            };
                            await dispatch(saveNewInspection(inspection, true, null, setnewInspection));

                            // const { selectedTab, tabs } = tasksTabs;
                            // const payload = {
                            //     tabKey: selectedTab,
                            //     startDate: tabs[selectedTab].startDate,
                            //     endDate: tabs[selectedTab].endDate,
                            //     reset: true,
                            //     isOrderByDesc: tabs[selectedTab].isOrderByDesc,
                            // };
                            // dispatch(tasksTabLoad(payload));

                            updateOptions({ ...options, maxTries: 0, autoClose: true });
                            return newinspection; //saved inspection from store
                        }
                        updateOptions({ ...options, maxTries: 0, message: `Waiting to Finish ` + PendingAttachements.length + ` Upload` });
                        throw `Waiting to Finish ` + PendingAttachements.length + ` Upload`;
                        return; //saved inspection from store
                        //  throw `Waiting to Finish Upload`;
                    } catch (error) {
                        updateOptions({ ...options, maxTries: 0, autoClose: false });
                        throw ` ${getErrorMessageWithDetail(error)}`;
                    }
                },
            };
            try {
                const result = await runBlockingTask(blockingTaskOptions);
                if (!result) return;
                dispatch(inspectionDialogPendingTabReload());
                inspectionsHelper.showInspection({ navigation, createdInspection: result });
            } catch (error) {
                console.log('error', error);
            }
        }
    };

    handleCancel = async () => {
        const { inspection, dispatch, navigation } = this.props;
        const { initOptions } = this.state;
        const { cancelHandler } = initOptions;
        if (typeof cancelHandler === 'function') {
            const data = await cancelHandler();
            if (data.allowCancel) {
                const blockingTaskOptions = {
                    id: 'cancelInspection',
                    message: strings('cancelingInspection'),
                    autoClose: true,
                    autoRetry: false,
                    allowCancel: false,
                    maxTries: 5,
                    requestCancel: () => {
                        // cancelRequested = true;
                    },
                    runner: async (options, updateOptions) => {
                        let coords = null;
                        try {
                            let newinspection = {};
                            const setnewInspection = data => {
                                newinspection = data;
                            };
                            await dispatch(
                                cancelInspection(
                                    { inspectionId: inspection.inspectionId, remarks: data.cancelData.remarks },
                                    navigation,
                                    setnewInspection
                                )
                            );
                            updateOptions({ ...options, maxTries: 0, autoClose: true });
                            return newinspection; //saved inspection from store
                        } catch (error) {
                            updateOptions({ ...options, maxTries: 0, autoClose: false });
                            throw ` ${getErrorMessageWithDetail(error)}`;
                        }
                    },
                };
                try {
                    const result = await runBlockingTask(blockingTaskOptions);
                    if (!result) return;
                } catch (error) {
                    console.log('error', error);
                }
            }
        }
    };
    onInit = initOptions => {
        //console.log('onInit() initOptions: ', initOptions);
        if (initOptions) {
            this.setState({ initOptions });
        }
    };

    render() {
        const { isAllowedToSave, errorLogs, initOptions } = this.state;
        const { showSaveButton, calibration } = this.props;
        //console.log('EditableVisit.render()');
        return (
            <>
                <View style={{ flex: 1 }}>
                    <EditableVisitContent
                        {...this.props}
                        handleBusinessEntitySelected={this.handleBusinessEntitySelected}
                        handleOnViolatorEdited={this.handleOnViolatorEdited}
                        handleOnViolatorRemoved={this.handleOnViolatorRemoved}
                        handleValueChange={this.handleValueChange}
                        handleAttachmentChange={this.handleAttachmentChange}
                        handleVisitInfoChange={this.handleVisitInfoChange}
                        handleInfoChange={this.handleInfoChange}
                        isSubmitable={this.isSubmitable}
                        onInit={this.onInit}
                        calibration={calibration}
                    />
                </View>
                {showSaveButton ? (
                    <View style={styles.actionButtonsContainer}>
                        {/* <Loader loading={inspections.creatingFlag} spinnerStyle={{ marginBottom: 20 }}>  */}
                        <IconButton
                            type="MaterialCommunityIcons"
                            name="content-save"
                            borderRadius={25}
                            disabled={!isAllowedToSave}
                            style={[styles.button, isAllowedToSave ? styles.buttonPositive : styles.buttonPositiveDisabled]}
                            onPress={this.handleSave}
                        >
                            <Text style={[isAllowedToSave ? styles.buttonText : styles.buttonTextPositiveDisabled]}>{strings('save')}</Text>
                        </IconButton>
                        {initOptions && initOptions.isAllowedToCancel && (
                            <IconButton
                                type="MaterialCommunityIcons"
                                name="close"
                                borderRadius={25}
                                style={[styles.button]}
                                onPress={this.handleCancel}
                            >
                                <Text style={[styles.buttonText]}>{strings('cancel')}</Text>
                            </IconButton>
                        )}

                        {/* </Loader>    */}
                    </View>
                ) : null}
            </>
        );
    }
}
