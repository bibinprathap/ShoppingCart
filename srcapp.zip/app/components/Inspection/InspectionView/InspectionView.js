import React, { memo, Component } from 'react';
import { View, Text, Dimensions, I18nManager, ScrollView, Animated, Easing } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { NavigationTab, VisitView } from 'app/components';
import { createAppContainer } from 'react-navigation';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import InspectionViewCommonFields from './InspectionViewCommonFields';
import moment from 'moment';
const currentLocale = I18nManager.isRTL ? 'ar' : 'en';
const InspectionView = memo(props => {
    const InspectionStackDefinition = {
        routes: [],
        initialRoute: 'currentVisit',
    };
    const inspectionContainer = props.inspection;
    const { inspection } = inspectionContainer;
    inspection.visits.map((v, i) => {
        const visitId = inspection.visits.length - 1 == i ? 'currentVisit' : 'visit' + (i + 1);
        const currentVisitStatus = v.inspectionStatusConst ? v.inspectionStatusConst.toLowerCase() : 'draft';
        const isReadOnlyVisit = v.locallySaved == true || currentVisitStatus !== 'draft' || props.isReadOnlyVisit;

        let tabName = localeProperty(v, 'visitName');
        if (!tabName) tabName = `[Visit ${i + 1}]`;
        const tabSubTitle = v.visitDate ? moment(v.visitDate).format('DD-MMM-YYYY hh:mm A') : null;
        //let tabName = strings(visitId);

        InspectionStackDefinition.routes.push({
            key: visitId,
            screen: ({ navigation }) => (
                <VisitView
                    showInspCommonFieldsAtTop={props.showInspCommonFieldsAtTop}
                    visit={v}
                    visitIndex={i}
                    showSaveButton={true}
                    dispatch={props.dispatch}
                    refNumber={inspection.refNumber}
                    inspection={inspection}
                    currentInspectionVersion={props.currentInspectionVersion}
                    thumbnailSize="extralarge"
                    errorLogs={{}}
                    dataLookups={props.dataLookups}
                    isReadOnlyVisit={isReadOnlyVisit}
                />
            ),
            //Todo: check if we are using this  headerTitle anywhere? if not, remove it
            params: { followupreview: true, headerTitle: tabName, tabTitle: tabName, tabSubTitle, inspection },
            title: tabName,
            icon: 'serviceSelection',
            iconType: 'custom',
        });
    });
    const routeConfig = {};
    InspectionStackDefinition.routes.map(item => {
        routeConfig[item.key] = {
            screen: item.screen,
            title: item.title,
            subtitle: item.subtitle,
            params: { tabTitle: item.params.tabTitle, tabSubTitle: item.params.tabSubTitle, inspection },
            navigationOptions: ({ navigation }) => ({
                title: item.title,
                subtitle: item.subtitle,
            }),
            tabBarOptions: {
                scrollEnabled: true,
            },
        };
    });
    const InspectionStackNavigator = createAppContainer(
        createMaterialTopTabNavigator(routeConfig, {
            initialRouteName: InspectionStackDefinition.initialRoute,
            swipeEnabled: true,
            animationEnabled: true,
            lazy: true,
            tabBarPosition: 'top',
            transitionConfig: () => ({
                transitionSpec: {
                    duration: 0,
                },
            }),

            defaultNavigationOptions: {
                tabBarComponent: props => {
                    return <NavigationTab {...props} />;
                },
            },
        })
    );

    return (
        <View style={{ flex: 1 }}>
            <InspectionViewCommonFields inspection={inspection} />
            <InspectionStackNavigator screenProps={InspectionStackDefinition.routes} />
        </View>
    );
});
export default InspectionView;
