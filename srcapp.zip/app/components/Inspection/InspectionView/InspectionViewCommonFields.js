import React, { memo, Component } from 'react';
import { View, Text } from 'react-native';
import { _ } from 'lodash';
import commonStyles from 'app/components/Preview/styles';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { StatusChip } from 'app/components';
import { RemarkAndAddressPreview } from 'app/components/Preview/RemarkAndAddressPreview';
import EStyleSheet from 'react-native-extended-stylesheet';
import { inspectionsHelper } from 'app/api/helperServices';

const InspectionViewCommonFields = memo(({ inspection }) => {
    if (!inspection || !inspection.visits) return null;

    const address = inspection && inspection.location && inspection.location.address;
    const coords = inspection && inspection.location && inspection.location.coords;

    const applicationNumber = inspection.visits[0].applicationNumber;
    //if there are any awareness, warning or violation item, they have their own IssueNumber, the headr issuenumber in that case is not used anywhere
    let issueNumber = inspection.workflowApplicationNumber || inspection.visits[0].workflowApplicationNumber;
    // if (violatorsAndViolations && violatorsAndViolations.length > 0) {
    //     if (violatorsAndViolations.length == 1) {
    //         const itemWithIssueNumber = _.find(inspection.visits[0].values, item => {
    //             if (item.workflowApplicationNumber == issueNumber) return item;
    //         });
    //         if (!itemWithIssueNumber) {

    //                 // if the single values item (issue) has a different issue number than the first visit issue number
    //                 // then don't show the issue number at the header level as it has no meaning for the inspector or violator.
    //                 // This happens in building penalties and general appearance

    //             issueNumber = undefined;
    //         }
    //     } else {
    //         //if there are more than one values items, then it building penalties and general appearance case, header level issue number has no meaning
    //         issueNumber = undefined;
    //     }
    // }

    let applicationAndIssuNumberHeader =
        applicationNumber || issueNumber ? (
            <>
                <View style={styles.applicationNumberWrapper}>
                    <View style={styles.applicationNumberInner}>
                        <Text style={[commonStyles.generalHeading, commonStyles.mutedText, { textAlign: 'left' }]}>
                            {strings('applicationNumber')}
                        </Text>
                        <Text
                            style={[
                                commonStyles.generalText,
                                !applicationNumber ? commonStyles.mutedText : null,
                                { textAlign: 'left', marginStart: 5 },
                            ]}
                        >
                            {applicationNumber || strings('notAvailable')}
                        </Text>
                    </View>
                    <View>
                        <StatusChip
                            statusConst={inspection.inspectionStatusConst}
                            translatedStatus={localeProperty(inspection, 'inspectionStatus')}
                        />
                    </View>
                    <View style={styles.issueNumberWrapper}>
                        <Text style={[commonStyles.generalHeading, commonStyles.mutedText, { textAlign: 'right', marginEnd: 10 }]}>
                            {strings('issueNumber')}
                        </Text>
                        <Text style={[commonStyles.generalText, !issueNumber ? commonStyles.mutedText : null, { textAlign: 'right' }]}>
                            {issueNumber || strings('notAvailable')}
                        </Text>
                    </View>
                </View>
            </>
        ) : null;

    const inspectionTitle = inspectionsHelper.getLongTitle(inspection, false);

    return (
        <View style={styles.wrapper}>
            <View style={styles.wrapperInner}>
                <Text style={styles.inspectionTitle}>{inspectionTitle}</Text>
                <View style={styles.titleWrapper}>{applicationAndIssuNumberHeader}</View>
                <View style={{ marginTop: 10 }} />
                <RemarkAndAddressPreview hideAddressTitle address={address} coords={coords} errorLogs={{}} hideRemark={true} headingmuted={true} />
            </View>
            <View style={styles.shadowLine}>
                <View style={styles.hideTopShadow} />
            </View>
        </View>
    );
});

const styles = EStyleSheet.create({
    wrapper: {},
    titleWrapper: {
        paddingHorizontal: 5,
        borderTopWidth: '$primaryBorderThin',
        borderTopColor: '$primaryLightBorder',
    },
    inspectionTitle: {
        paddingHorizontal: 10,
        paddingVertical: 5,
        fontSize: '$primaryTextMD',
        color: '$primaryDarkTextColor',
    },
    applicationNumberWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 5,
        marginVertical: 10,
    },
    applicationNumberInner: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-start',
    },
    issueNumberWrapper: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    wrapperInner: {
        padding: 5,
        paddingBottom: 8,
        backgroundColor: '$primaryWhite',
        // elevation: 2,
        // shadowOffset: { width: 5, height: 5 },
        // shadowColor: '$primaryBorderColor',
        // shadowOpacity: 0.5,
        // shadowRadius: 5,
    },
    hideTopShadow: {
        backgroundColor: '$primaryWhite',
        marginTop: -3,
        height: 3,
        width: '100%',
    },
    shadowLine: {
        height: 1,
        elevation: 2,
        paddingBottom: 1,
        elevation: 3,
        shadowOffset: { width: 5, height: 5 },
        shadowColor: '$primaryBorderColor',
        backgroundColor: '$primaryBorderColor',
        shadowOpacity: 0.5,
        shadowRadius: 5,
    },
});

export default InspectionViewCommonFields;
