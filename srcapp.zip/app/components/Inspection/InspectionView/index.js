import InspectionView from './InspectionView';
import InspectionViewCommonFields from './InspectionViewCommonFields';

export { InspectionView, InspectionViewCommonFields };
