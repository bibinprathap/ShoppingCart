import React, { memo } from 'react';
import { View } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Divider } from 'react-native-paper';
import { DistrotionPreview, ViolationPreview, commonStyles } from 'app/components';

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
});

export default memo(function(props) {
    const { inspection, errorLogs = {} } = props;
    const { workflowConst } = inspection.inspectionTypeDetail;
    const needValidation = true;
    return (
        <View style={styles.container}>
            {workflowConst === 'MimsDistortion' ? (
                <DistrotionPreview {...props} needValidation={needValidation} />
            ) : (
                <ViolationPreview {...props} needValidation={needValidation} />
            )}
            {errorLogs.common && Object.getOwnPropertyNames(errorLogs.common).length > 0 && <Divider style={commonStyles.divider} />}
        </View>
    );
});
