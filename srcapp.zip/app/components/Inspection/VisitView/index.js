import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { EditableVisit, ReadOnlyVisit } from 'app/components';

export default class VisitView extends Component {
    render() {
        if (this.props.isReadOnlyVisit) return <ReadOnlyVisit {...this.props} />;
        else return <EditableVisit {...this.props} />;
    }
}
