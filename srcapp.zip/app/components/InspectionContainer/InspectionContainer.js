import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import * as Animatable from 'react-native-animatable';
import EStyleSheet from 'react-native-extended-stylesheet';
import styles from './styles';
import { BaseContainer, InspectionHeader } from 'app/components';
import { SideNav } from 'app/components';
import { inspectionStackDefinition, mainStackDefinition } from 'app/config/routs/defs';
import { inspectionsHelper } from 'app/api/helperServices';

class InspectionContainer extends Component {
    static propTypes = {
        currentInspectionVersion: PropTypes.any,
        currentInspectionContainer: PropTypes.object,
    };

    constructor(props) {
        super(props);
        this.backAction = this.backAction.bind(this);
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.view && prevProps.preference.inspectionSideNavigation !== this.props.preference.inspectionSideNavigation) {
            if (this.props.preference.inspectionSideNavigation) {
                this.showSideNav();
            } else {
                this.hideSideNav();
            }
        }
    }
    componentDidMount() {
        if (!this.props.preference.inspectionSideNavigation) {
            this.view.slideOutLeft(0);
            this.view.transitionTo({ width: 0 }, 0);
        }
    }

    hideSideNav = (milSec = 300) => {
        if (this.view) {
            this.view.slideOutLeft(milSec);
            this.view.transitionTo({ width: 0 }, milSec);
        }
    };

    showSideNav = (milSec = 400) => {
        if (this.view) {
            this.view.slideInLeft(milSec);
            const sideNavWidth = EStyleSheet.value('$sideNavWidth');
            this.view.transitionTo({ width: sideNavWidth }, milSec);
        }
    };

    handleSideViewRef = ref => (this.view = ref);

    backAction = () => {
        this.props.navigation.navigate('dashboard');
    };

    handleSideNavOnPress = item => {
        this.props.navigation.navigate(item.key);
    };

    render() {
        const { children, currentInspectionContainer, dispatch, preference } = this.props;
        const currentRouteName = this.props.navigation.state.routeName;
        const adjustedRoutes = inspectionsHelper.getRoutes();
        // this.breadCrumbs = adjustedRoutes.map(item => {
        //     return {
        //         key: item.key,
        //         title: item.title,
        //         selected: item.key === currentRouteName,
        //     };
        // });

        this.sidenavRoutes = [{ ...mainStackDefinition.routes[0], displayInSideNav: true }];
        this.sidenavRoutes = this.sidenavRoutes.concat(adjustedRoutes);

        const currentRoutedef = _.find(inspectionStackDefinition.routes, {
            key: currentRouteName,
        });

        const inspectionTitle = inspectionsHelper.getLongTitle(currentInspectionContainer, true);
        return (
            <BaseContainer {...this.props}>
                <InspectionHeader
                    title={(currentRoutedef && currentRoutedef.title) || null}
                    subTitle={inspectionTitle || null}
                    backAction={this.backAction}
                    dispatch={dispatch}
                    duplicateInspection={currentInspectionContainer.inspection.duplicateInspection || {}}
                />
                <View style={styles.container}>
                    <Animatable.View ref={this.handleSideViewRef} style={styles.animateViewcontainer}>
                        <View style={styles.sideNavContainer}>
                            <SideNav routes={this.sidenavRoutes} onPress={this.handleSideNavOnPress} currentRouteName={currentRouteName} />
                        </View>
                    </Animatable.View>
                    <View style={styles.contentsContainer}>{children}</View>
                </View>
            </BaseContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;

    if (!currentInspectionContainer) return;

    const mappedProps = {
        currentInspectionVersion: state.inspections.currentInspectionVersion,
        currentInspectionContainer: currentInspectionContainer,
        preference: state.generic.preference,
    };
    return mappedProps;
};

export default connect(mapStateToProps)(InspectionContainer);
