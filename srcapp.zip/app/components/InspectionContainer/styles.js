import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: '$primaryLightBackground',
    },
    animateViewcontainer: {
        backgroundColor: '$primaryLightBackground',
    },
    sideNavContainer: {
        borderColor: '$primaryBorderColor',
        borderEndWidth: '$primaryBorderThin',
        backgroundColor: '$primaryDarkBackground',
    },
    contentsContainer: {
        flex: 1,
        backgroundColor: '$primaryWhite',
    },
});
