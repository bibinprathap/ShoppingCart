import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, I18nManager } from 'react-native';
import { connect } from 'react-redux';
import _ from 'lodash';
import { localeProperty } from 'app/config/i18n/i18n';
import { CustomAccordion, YesNo, Check, Count, OptionList } from 'app/components';
import { Timeline } from 'app/components';
import * as Animatable from 'react-native-animatable';
import styles from './styles';

class InspectionDetail extends Component {
    static propTypes = {
        def: PropTypes.array,
        values: PropTypes.array,
        onValuechanged: PropTypes.func,
        onAttachmentChanged: PropTypes.func,
    };

    constructor(props) {
        super(props);
    }

    componentDidUpdate(prevProps) {
        if (!_.isEqual(this.props.values, prevProps.values)) {
            this.setState({
                currentValues: !!this.props.values ? this.props.values : [],
            });
        }
    }

    updateStateAndCallback = (data, callback) => {
        const currentValues = !!this.props.values ? this.props.values : [];
        let values = [...currentValues];
        let itemIndex = _.findIndex(values, (item) => item.inspTypeCheckItemId === data.val.inspTypeCheckItemId);
        if (itemIndex === -1) {
            values.push(data.val);
        } else {
            values.splice(itemIndex, 1, data.val);
            // if (data.val.selectedOption == false) {
            //     values.splice(itemIndex, 1);
            // } else {

            // }
        }

        //this.setState({ currentValues: values }, () => callback && callback(values));

        if (callback) {
            callback(values);
        }
    };

    handleValueChange = (data) => {
        this.updateStateAndCallback(data, this.props.onValuechanged);
    };

    handleAttachmentChange = (data) => {
        this.updateStateAndCallback(data, this.props.onAttachmentChanged);
    };

    handleOnRemarksChanged = (data) => {
        this.updateStateAndCallback(data, this.props.onAttachmentChanged);
    };

    getChecklistGroups(props) {
        const { def, values, editable, showAllCheckItem } = props;
        const groups = [];
        //const checklistItems = [];
        let isFirst = true;
        let groupIndex = 0;
        if (def && def[0]) {
            for (groupDef of def[0].checklistGroups) {
                const checklistItems = groupDef.checklist.map((item, index) => {
                    if (!showAllCheckItem && item.violationTypeIds && item.violationTypeIds.length == 0) {
                        return; //don't show checkitems that have no associated violation type
                    }

                    const selection = _.find(values, { inspTypeCheckItemId: item.inspTypeCheckItemId });
                    const checklistItemInstance = this.getChecklistItemInstance(item.questionType, item, selection, editable, showAllCheckItem);
                    //
                    return (
                        <Animatable.View
                            key={item.inspTypeCheckItemId}
                            animation={I18nManager.isRTL ? 'fadeInLeft' : 'fadeInRight'}
                            duration={400}
                            useNativeDriver={true}
                            easing="ease-out"
                            delay={index * 100}
                        >
                            <View style={styles.checklistSingleItemContainer}>{checklistItemInstance}</View>
                            {/* {index < groupDef.checklist.length - 1 && <Divider style={{ marginHorizontal: 20 }} />} */}
                        </Animatable.View>
                    );
                });
                const group = (
                    <CustomAccordion
                        key={`${groupIndex}`}
                        title={localeProperty(groupDef, 'title')}
                        expandedAtStart={isFirst}
                        //expandedAtStart={true}
                    >
                        <View style={styles.checklistItemsContainer}>{checklistItems}</View>
                    </CustomAccordion>
                );
                groups.push({ key: `${groupIndex}`, instance: group });
                isFirst = false;
                groupIndex++;
            }
        }
        return groups;
    }

    getChecklistItemInstance = (questionType, item, value, editable, showAllCheckItem) => {
        switch (questionType) {
            case 'YesNo':
                const question = localeProperty(item, 'question') || 'Unknown question';
                return (
                    <YesNo
                        question={question}
                        editable={editable}
                        checkItemId={item.checkItemId}
                        inspTypeCheckItemId={item.inspTypeCheckItemId}
                        isMandatory={item.isMandatory}
                        violationTypeIds={item.violationTypeIds || []}
                        val={value}
                        hasNA={false}
                        showAllCheckItem={showAllCheckItem}
                        //  violatorType={violatorType}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            case 'YesNoNa':
                const questionNa = localeProperty(item, 'question') || 'Unknown question';
                return (
                    <YesNo
                        question={questionNa}
                        editable={editable}
                        hasNA={true}
                        checkItemId={item.checkItemId}
                        inspTypeCheckItemId={item.inspTypeCheckItemId}
                        isMandatory={item.isMandatory}
                        violationTypeIds={item.violationTypeIds || []}
                        val={value}
                        showAllCheckItem={showAllCheckItem}
                        //  violatorType={violatorType}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            case 'Count':
                const countQuestion = localeProperty(item, 'question') || 'Unknown question';
                return (
                    <Count
                        question={countQuestion}
                        editable={editable}
                        checkItemId={item.checkItemId}
                        inspTypeCheckItemId={item.inspTypeCheckItemId}
                        isMandatory={item.isMandatory}
                        val={value}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            case 'OptionList':
                const optionListQuestion = localeProperty(item, 'question') || 'Unknown question';
                return (
                    <OptionList
                        question={optionListQuestion}
                        editable={editable}
                        checkItemId={item.checkItemId}
                        inspTypeCheckItemId={item.inspTypeCheckItemId}
                        violationTypeIds={item.violationTypeIds}
                        isMandatory={item.isMandatory}
                        val={value}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );

            case 'Checkbox':
                return (
                    <Check
                        editable={editable}
                        checkItemId={item.checkItemId}
                        inspTypeCheckItemId={item.inspTypeCheckItemId}
                        isMandatory={item.isMandatory}
                        violationTypeIds={item.violationTypeIds || []}
                        val={value}
                        showAllCheckItem={showAllCheckItem}
                        onValuechanged={this.handleValueChange}
                        onAttachmentChanged={this.handleAttachmentChange}
                        onRemarksChanged={this.handleOnRemarksChanged}
                    />
                );
            default:
                return null;
        }
    };

    keyExtractor = (item, index) => {
        return item.key;
    };
    renderChecklistGroup = ({ item, index, separators }) => {
        return item.instance;
    };

    render() {
        const { def, editable } = this.props;
        const groups = this.getChecklistGroups(this.props);
        return <Timeline editable={editable} data={groups} keyExtractor={this.keyExtractor} renderItem={this.renderChecklistGroup} />;
    }
}

mapStateToProps = (state) => {
    return {
        currentInspectionVersion: state.inspections.currentInspectionVersion,
    };
};

export default connect(mapStateToProps)(InspectionDetail);
