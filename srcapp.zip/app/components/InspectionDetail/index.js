import styles from './styles';
import InspectionDetail from './InspectionDetail';

export { styles, InspectionDetail };
