import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Text, ActivityIndicator, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import ADMGISMapView from '../ADMGISMapView/ADMGISMapView';
import styles from './styles';
import AppApi from 'app/api/real';
import { inspectionsHelper, tasksHelper } from 'app/api/helperServices';
import { TaskDetailsDialog } from 'app/screens';
const api = new AppApi();

class InspectionPlanView extends Component {
    state = {
        loading: false,
    };
    constructor(props) {
        super(props);
    }

    async componentDidMount() {
        // console.log('this.props.toDayTasks', this.props.toDayTasks);InProgress"Completed"
        const planTasks = await api.getPlanDetails();

        console.log('planTasks', planTasks);
        let featureLayerData = [];
        let tasksMapping = {};
        if (planTasks.length > 0) {
            const sectorts = [];
            planTasks.map(task => {
                if (task.location && task.location.address && task.location.address.plotGisId) {
                    sectorts.push({ ...task.location.address, PlotGisId: task.location.address.plotGisId, taskStatusConst: task.taskStatusConst });
                    tasksMapping[
                        task.location.address.municipality +
                            '_' +
                            task.location.address.zoneId +
                            '_' +
                            task.location.address.sectorId +
                            '_' +
                            task.location.address.plotGisId
                    ] = task.taskId;
                }
            });
            function onlyUnique(value, index, self) {
                return self.indexOf(value) === index;
            }
            const zone = sectorts
                .map(s => s.zoneId)
                .filter(onlyUnique)
                .map(z => {
                    return { zoneId: z, municipality: 'ADM', sectors: sectorts.filter(s => s.zoneId == z) };
                });
            featureLayerData = inspectionsHelper.getFeatureLayerFromArea({ userArea: zone });
            console.log('featureLayerData', featureLayerData);
        }
        this.setState({ loading: true, featureLayerData: featureLayerData, tasksMapping: tasksMapping });
        try {
            const smartHubData = await api.getInspectorPlanStatus(this.props.activeProfileUserId);
            const plotGisIds = smartHubData.plots.map(item => item.plotGisId);

            const plotsGeometries = await api.getPlots({
                municipalityId: '1000',
                orderByFields: 'plotNumber',
                plotGisIds,
                ReturnGeometry: true,
            });

            const polygonData = plotGisIds.map(plot => {
                const plotDataSmartHub = _.find(smartHubData.plots, { plotGisId: plot });

                const plotDataGeometry = _.find(plotsGeometries, { plotGisId: plot });
                if (plotDataGeometry) {
                    const plotTitle = plotDataSmartHub.plotTitle;
                    let fillColor;
                    if (plotDataSmartHub.status == 'done') fillColor = 0x8000ff00;
                    else if (plotDataSmartHub.status == 'inprogress') fillColor = 0x800000ff;
                    else fillColor = 0x80ff0000;
                    const lineColor = fillColor;
                    const lineWidth = 1;

                    return {
                        data: { id: plotTitle, type: 'plot' },
                        PolygonID: plotTitle,
                        polygonFillColor: fillColor,
                        boundaryLineColor: lineColor,
                        lineWidth: lineWidth,
                        coords: plotDataGeometry.geometry,
                    };
                }
                // else {

                //     return null;
                // }
            });
            const formattedData = { polygons: polygonData };
            //this.setState({ inspectorPlotStatusData: formattedData, loading: false });

            this.setState({ inspectorPlotStatusData: formattedData, loading: false });
        } catch (error) {
            throw error;
        }
    }
    render() {
        if (this.state.loading)
            return (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator />
                </View>
            );

        return (
            <View style={styles.container}>
                <ADMGISMapView renderData={JSON.stringify(this.state.featureLayerData)} showMenu={true} onSingleTap={this.handleOnSingleTap} />
                <TaskDetailsDialog />
            </View>
        );
    }

    handleOnSingleTap = points => {
        if (!points) {
            return;
        }
        console.log('InspectionPlanViewSingleTap', points);

        if (typeof points.PLOTID !== 'undefined' && points.PLOTID != null) {
            const tasksMapping = this.state.tasksMapping;
            const taskID = tasksMapping[points.MUNICIPALITYENG + '_' + points.DISTRICTID + '_' + points.COMMUNITYID + '_' + points.PLOTID];
            const itemObj = { taskId: taskID };
            tasksHelper.selectTask(itemObj, this.props.navigation);
        }
    };
}

const mapStateToProps = state => {
    //console.log('mapStateToProps', state.generic.tasksTabs.tabs.tomorrow.items);
    return {
        activeProfileUserId: state.auth.activeProfileUserId,
        preference: state.generic.preference,
        // toDayTasks: state.generic.tasksTabs.tabs.tomorrow.items,
    };
};

export default connect(mapStateToProps)(InspectionPlanView);
