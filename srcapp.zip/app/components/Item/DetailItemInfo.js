import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

export default function DetailItemInfo({ item }) {
    const { detail } = item || {};
    const detailFields = !detail
        ? null
        : Object.keys(detail).map(key => {
              return (
                  <View style={styles.rowContainer}>
                      <View style={styles.cellContainer}>
                          <Text style={styles.cellTextBold}>{key}</Text>
                          <Text style={styles.cellText}>{detail[key]}</Text>
                      </View>
                  </View>
              );
          });
    return (
        <View style={{ padding: 10 }}>
            <View>
                <Text style={{ fontSize: 22, color: 'red' }}>Todo: Improve formatting in this screen Violator </Text>
            </View>
            <ScrollView>{detailFields}</ScrollView>
        </View>
    );
}

const styles = EStyleSheet.create({
    rowContainer: {
        borderStyle: 'solid',
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        minHeight: 40,
    },
    rowContent: {
        flex: 1,
        flexDirection: 'row',
    },
    cellContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    cellTextBold: {
        fontWeight: 'bold',
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 200,
    },
    cellText: {
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 300,
    },
});
