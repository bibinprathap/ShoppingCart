import DetailItemInfo from './DetailItemInfo';
import SimpleItemInfo from './SimpleItemInfo';

export { SimpleItemInfo, DetailItemInfo };
