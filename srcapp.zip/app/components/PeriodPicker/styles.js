import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    periodTypePicker: {
        height: 50,
        width: 100,
        minWidth: 100,
        marginLeft: 5,
        justifyContent: 'flex-end',
        alignSelf: 'flex-end',
        textAlign: 'right',
    },
    actionPeriod: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignSelf: 'center',
        alignItems: 'center',
        borderWidth: 0.251173,
        borderRadius: 4,
        borderColor: '$primaryBorderColor',
        marginHorizontal: 5,
        marginVertical: 5,
        paddingLeft: 5,
    },
    container: {
        borderWidth: 0.5,
        borderRadius: 4,
        flexDirection: 'row',
        overflow: 'hidden',
        width: 150,
    },
    buttonLeft: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 2,
        borderBottomRightRadius: 0,
        borderTopRightRadius: 0,
    },
    buttonRight: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 2,
        borderBottomLeftRadius: 0,
        borderTopLeftRadius: 0,
    },
    buttonRounded: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 999,
    },
    buttonText: {
        color: 'white',
        textAlign: 'center',
    },
    numberText: {
        textAlign: 'center',
        justifyContent: 'center',
    },
});
