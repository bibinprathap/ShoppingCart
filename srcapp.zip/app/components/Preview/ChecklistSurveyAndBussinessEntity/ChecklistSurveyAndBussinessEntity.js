import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { View } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { commonStyles } from 'app/components';
import ChecklistSurveyQuestionCameraComment from './ChecklistSurveyQuestionCameraComment';
import ChecklistOptionListQuestionCameraComment from './ChecklistOptionListQuestionCameraComment';
import SimpleViolatorInfo from 'app/components/Violator/SimpleViolatorInfo';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';

//Todo: move it to styles.js when screen is complete. its here for hot-reload
export default memo(function(props) {
    const { items, violator, errorLogs, isSurveyFromADM, isOptionList, def } = props;
    renderSureyTitle = props => {
        const { items } = props;
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading, commonStyles.mutedText]}>
                    {strings('surveySummaryHeading')} ({items ? items.length : 0})
                </Text>
            </View>
        );
    };
    renderViolatorsTitle = props => {
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading, commonStyles.mutedText]}>{strings('establishment')}</Text>
            </View>
        );
    };

    return (
        <React.Fragment>
            <View style={styles.violatorCardOuter}>
                {!isSurveyFromADM && violator && violator.violatorId && renderViolatorsTitle(props)}
                {!isSurveyFromADM && violator && violator.violatorId && (
                    <SimpleViolatorInfo key={violator.violatorId} violator={violator} editable={false} />
                )}
                {!isSurveyFromADM && <Divider style={commonStyles.divider} />}
                {renderSureyTitle(props)}
                <View style={styles.checklistItemsContainer}>
                    {items.map((checklistItem, idx) => {
                        const { attachments, remarks, selectedOption, selectedCount, checkItemId, violationTypeIds } = checklistItem.item;
                        const selectedViolationTypesOptions = inspectionsHelper.getViolationTypeOptions(violationTypeIds || [], checkItemId);
                        const checkItemValidation = (errorLogs[(violator || {}).violatorId] || {})[checkItemId] || {};
                        if (checklistItem.questionType == 'OptionList') {
                            return (
                                <View style={styles.checklistSingleItemContainer}>
                                    <ChecklistOptionListQuestionCameraComment
                                        checklistItem={checklistItem}
                                        key={idx.toString()}
                                        remarks={remarks}
                                        attachments={attachments}
                                        errorLogs={checkItemValidation}
                                        question={localeProperty(checklistItem.itemDef, 'question')}
                                        secondLine={selectedViolationTypesOptions.length > 0 ? selectedViolationTypesOptions[0].title : null}
                                    />
                                </View>
                            );
                        } else
                            return (
                                <View style={styles.checklistSingleItemContainer}>
                                    <ChecklistSurveyQuestionCameraComment
                                        checklistItem={checklistItem}
                                        key={idx.toString()}
                                        selectedOption={selectedOption}
                                        selectedCount={selectedCount}
                                        remarks={remarks}
                                        attachments={attachments}
                                        errorLogs={checkItemValidation}
                                        secondLine={localeProperty(checklistItem.itemDef, 'question')}
                                    />
                                </View>
                            );
                    })}
                </View>
            </View>
        </React.Fragment>
    );
});
