import React, { memo, Component, useState } from 'react';
import { View, ScrollView } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Text, Divider } from 'react-native-paper';
import { commonStyles } from 'app/components';
import styles from './styles';

export default memo(function(props) {
    const { errorLogs, visit } = props;
    return (
        <View>
            {errorLogs.common
                ? Object.getOwnPropertyNames(errorLogs.common).map(e => {
                      return (
                          <Text style={[commonStyles.ValidationMessageText, styles.scrollContainer, { paddingStart: 22 }]}>
                              {errorLogs.common[e]}
                          </Text>
                      );
                  })
                : null}
            {errorLogs.isDuplicateChecked && (
                <Text style={[commonStyles.ValidationMessageText, styles.scrollContainer, { paddingStart: 22 }]}>{errorLogs.isDuplicateChecked}</Text>
            )}
            {errorLogs.common && Object.getOwnPropertyNames(errorLogs.common).length > 0 && <Divider style={commonStyles.divider} />}
            {errorLogs.notTouchedCheckList && errorLogs.notTouchedCheckList.length > 0 ? (
                <>
                    <Text style={commonStyles.ValidationMessageText}>{strings('followingCheckListsAreMandtory')}</Text>
                    <View style={styles.bulletcolumn}>
                        {errorLogs.notTouchedCheckList.map(q => (
                            <View style={styles.bulletrow}>
                                <View style={styles.bullet}>
                                    <Text>{'\u2022' + ' '}</Text>
                                </View>
                                <View style={styles.bulletText}>
                                    <Text style={[commonStyles.ValidationMessageText, { marginHorizontal: 10 }]}>{q}</Text>
                                </View>
                            </View>
                        ))}
                    </View>
                </>
            ) : null}
        </View>
    );
});
