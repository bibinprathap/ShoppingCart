import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {},
    divider: {
        width: '100%',
        marginVertical: 10,
    },
    scrollContainer: {
        paddingStart: 10,
    },
    remarkContainer: {
        flex: 1,
        justifyContent: 'flex-start',
        alignSelf: 'flex-end',
        alignItems: 'flex-start',
        fontWeight: 'bold',
        fontSize: 18,
        backgroundColor: '#a7a9ac',
        color: '#ffffff',

        borderRadius: 5,

        elevation: 2,
        marginLeft: 0,
        width: '90%',
    },
    stepContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'flex-start',
    },
    remarkText: {
        flex: 1,
        fontSize: '$primaryTextXXS',

        marginVertical: 5,
        color: '#ffffff',
        marginHorizontal: 3,
        textAlign: I18nManager.isRTL ? 'left' : 'right',
    },
    timelineText: {
        fontSize: '$primaryTextXXS',

        marginVertical: 2,

        textAlign: I18nManager.isRTL ? 'left' : 'right',
    },
    mutedText: {
        fontSize: 12,
        color: '$primaryMediumTextColor',
    },
    bulletcolumn: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        flex: 1,
    },
    bulletrow: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        flexWrap: 'wrap',
        flex: 1,
    },
    bullet: {
        width: 10,
    },
    bulletText: {
        flex: 1,
    },
});
