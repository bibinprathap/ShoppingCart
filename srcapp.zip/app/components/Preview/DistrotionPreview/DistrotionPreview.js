import React, { Component } from 'react';
import { View, Text } from 'react-native';
import GeneralPreview from '../GeneralPreview/GeneralPreview';
import { InspectionViewCommonFields } from '/app/components';

export default class DistrotionPreview extends Component {
    render() {
        const showInspCommonFieldsAtTop = !!this.props.showInspCommonFieldsAtTop;
        return (
            <View style={{ flex: 1 }}>
                {!showInspCommonFieldsAtTop && <InspectionViewCommonFields inspection={this.props.inspection} />}
                <GeneralPreview {...this.props}></GeneralPreview>
            </View>
        );
    }
}
