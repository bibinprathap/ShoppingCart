import React, { memo, Component, useState } from 'react';
import { View, ScrollView } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { Text, Divider, TouchableRipple } from 'react-native-paper';
import { Icon, Modal, HeaderGeneric, ADMGISMapView, commonStyles, LocationAndGoogleMaps } from 'app/components';
import { formatAddress } from 'app/api/helperServices/utils';
import styles from './styles';

export default memo(function(props) {
    const [modalVisible, toggleLocationDialog] = useState(false);
    const { generalRemarks, address, errorLogs, coords, headingmuted, hideRemark, hideAddressTitle } = props;
    const placeMarkData = coords && [
        {
            ...coords,
            rotation: 0,
            referenceId: 'selectedLocation',
            graphicId: 'personPoint',
        },
    ];
    const formattedAddress = formatAddress(address);
    return (
        <View style={styles.scrollContainer}>
            <View style={styles.addressContainer}>
                <View style={{ flex: 1 }}>
                    {!hideAddressTitle && (
                        <Text style={headingmuted ? [commonStyles.generalText, commonStyles.mutedText] : commonStyles.generalHeading}>
                            {strings('address')}
                        </Text>
                    )}
                    <Text style={commonStyles.generalText}>{formattedAddress}</Text>
                    <Text style={styles.coordsText}>
                        {coords
                            ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                            : strings('latitudeAndLongitude')}
                    </Text>
                </View>
                <View style={styles.addressIconContainer}>
                    <LocationAndGoogleMaps location={{ coords, address }} />
                </View>
            </View>
            {errorLogs.address ? (
                <View>
                    <Text style={commonStyles.ValidationMessageText}>{strings('emptyAddressValidation')}</Text>
                </View>
            ) : null}
            {hideRemark ? null : (
                <>
                    <Divider style={commonStyles.divider} />
                    <View style={styles.remarksContainer}>
                        <Text style={headingmuted ? [commonStyles.generalText, commonStyles.mutedText] : commonStyles.generalHeading}>
                            {strings('remarks')}
                        </Text>
                        <Text style={[commonStyles.generalText, !generalRemarks ? commonStyles.mutedText : null]}>
                            {generalRemarks || strings('emptyRemarksList')}
                        </Text>
                        {errorLogs.generalRemarks ? (
                            <Text style={commonStyles.ValidationMessageText}>{strings('emptyRemarksValidation')}</Text>
                        ) : null}
                    </View>
                </>
            )}
        </View>
    );
});
