import React, { memo, Component, useState } from 'react';
import { View, ScrollView } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { Text } from 'react-native-paper';
import moment from 'moment';
import { Timeline, commonStyles } from 'app/components';
import styles from './styles';

export default memo(function(props) {
    const timelineContent = [];
    let addDays = function(days) {
        var date = new Date();
        date.setDate(date.getDate() + days);
        return date;
    };
    const steps = props.steps || [];

    // [
    //     {
    //         titleE: 'START',
    //         titleA: 'بداية',
    //         comments: 'STARTED REMARK STARTED REMARKSTARTED REMARKSTARTED REMARKSTARTED REMARK',
    //         createdDate: addDays(0),
    //     },
    //     {
    //         titleE: 'CONFIRM',
    //         titleA: 'بداية',
    //         comments: 'CONFIRMED  REMARK CONFIRMED  REMARKCONFIRMED  REMARKCONFIRMED  REMARKCONFIRMED  REMARK',
    //         createdDate: addDays(2),
    //     },
    //     { titleE: 'DUPLICATE REVIEW', titleA: 'مراجعة مزدوجة', comments: 'DUPLICATE REVIEW REMARK', createdDate: addDays(3) },
    //     { titleE: 'SUPERVISOR REVIEW', titleA: 'مراجعة المشرف', comments: 'SUPERVISOR REVIEW REMARK', createdDate: addDays(4) },
    // ];
    steps.map((s, i) => {
        timelineContent.push(
            <View>
                <View style={styles.stepContainer}>
                    <Text style={[styles.timelineText, { flex: i % 2 == 0 ? 1 : 0, alignSelf: i % 2 == 0 ? 'flex-end' : 'flex-start' }]}>
                        {localeProperty(s, 'title')}
                    </Text>
                    <Text style={[styles.mutedText, { flex: 0, alignSelf: i % 2 == 0 ? 'flex-end' : 'flex-start' }]}>
                        @ {moment(s.createdDate).format('M/D/YYYY h:m:s a')}
                    </Text>
                </View>
                <View style={[styles.remarkContainer, { alignSelf: i % 2 == 0 ? 'flex-end' : 'flex-start' }]}>
                    <Text style={[styles.remarkText, { alignSelf: i % 2 == 0 ? 'flex-end' : 'flex-start' }]}>
                        {s.comments ? '" ' + s.comments + ' "' : null}
                    </Text>
                </View>
            </View>
        );
        return s;
    });
    return (
        <View style={styles.scrollContainer}>
            {/* <View style={styles.remarksContainer}>
                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('actions')}</Text>
            </View> */}
            <Timeline data={timelineContent} twoSide={true} renderItem={({ item }) => item} />
        </View>
    );
});
