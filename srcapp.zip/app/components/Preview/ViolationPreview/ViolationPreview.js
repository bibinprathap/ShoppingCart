import React, { Component } from 'react';
import { View } from 'react-native';
import * as yup from 'yup';
import { strings, localeProperty } from 'app/config/i18n/i18n';

import { ValidationHelper } from 'app/api/helperServices';
import { inspectionsHelper } from 'app/api/helperServices';
import HeaderCounts from '../InspectionPreview/HeaderCounts';
import GeneralPreview from '../GeneralPreview/GeneralPreview';
import { InspectionViewCommonFields } from '/app/components';

export default class ViolationPreview extends Component {
    getValidationShape = ConfigTemplate => {
        const validationSchemaShape = {};
        ConfigTemplate.fields.map(item => {
            if (item.type === 'fieldGroup') {
                if (item.fields) {
                    item.fields.map(fieldConfig => {
                        const { name, validationRule } = fieldConfig;
                        if (validationRule) validationSchemaShape[name] = ValidationHelper.getValidationRule(validationRule);
                    });
                }
            }
        });
        return validationSchemaShape;
    };
    validateInspection = async (values, errorLogs) => {
        const res = await new Promise((resolve, reject) => {
            const { inspection, unAssignedItems, currentVisitIndex, currentVisitData } = values;
            const selectedVisitIndex = currentVisitIndex;
            //inspection.visits.length - 1;
            const selectedVisit = inspection.visits && inspection.visits[selectedVisitIndex];
            const selectedVisitValues = selectedVisit && selectedVisit.values;
            const inspectionDefinition = selectedVisit && selectedVisit.def.def[0];
            let duplicateCandidates = [];
            let violators = [];
            let duplicates = [];
            if (inspection && inspection.duplicateInspection) {
                duplicateCandidates = inspection.duplicateInspection.duplicateCandidates;
                duplicates = inspection.duplicates || [];
            }
            const { inspectionTypeDetail } = inspection;
            const showAllCheckItem = inspectionTypeDetail && inspectionTypeDetail.inspEntityId != 1000;

            // const currentVisitData = unAssignedItems;

            // let unAssignedViolationTypes = [];
            if (currentVisitData && currentVisitData.values && currentVisitData.values.length > 0) {
                // currentVisitData.values.forEach(item => {
                //     if (!item.violatorId) unAssignedViolationTypes.push(item);
                // });

                if (unAssignedItems && unAssignedItems.length > 0) {
                    errorLogs.unAssignedItems = strings('thereis') + unAssignedItems.length + ' ' + strings('unAssignedItems');
                }
            }
            const isAbandonedVehicleForm = inspectionDefinition && inspectionDefinition.name == 'abandonedVehicleInfo';
            if (currentVisitData.def.type == 'form') {
                currentVisitData.def.def.map(async (form, index) => {
                    let values = {};
                    if (form.scope == 'visit') {
                        values = inspection.visits[currentVisitIndex || 0][form.name];
                    } else if (inspection.info) {
                        values = inspection.info[form.name];
                    }
                    if (form.formType == 'fixed') {
                        //get fixed form in readOnly mode
                        switch (form.name) {
                            case 'abandonedVehicleInfo':
                            case 'generalAppearanceVehicleInfo':
                                try {
                                    if (inspection.visits[0].values.length == 0) {
                                        errorLogs.commonFormError = {
                                            novehicle: strings('noViolationTypeAdded'),
                                        };
                                    }

                                    if (!inspection.visits[0].values[0].violatorId) {
                                        errorLogs.commonFormError = {
                                            novehicle: strings('noViolatorAdded'),
                                        };
                                    }
                                } catch (e) {}
                                // const actionTypeOptions = selectedVisit.followupForm ? selectedVisit.followupForm.violationActionTypes || [] : [];
                                const generalAppearanceErrorLogs = await inspectionsHelper.validateAbandonedVehicle(values || {}, inspection);
                                Object.getOwnPropertyNames(generalAppearanceErrorLogs).map(er => {
                                    errorLogs[er] = generalAppearanceErrorLogs[er];
                                });
                                if (form.name == 'generalAppearanceVehicleInfo') return resolve();
                                // const abandonedVehicleValidationSchema = yup.object().shape(this.getValidationShape(AbandonedVehicleConfig));
                                // try {
                                //     await ValidationHelper.validate(values, abandonedVehicleValidationSchema);
                                //     return resolve();
                                // } catch (errors) {
                                //     errorLogs[form.name] = errors;
                                //     return resolve();
                                //     // Object.getOwnPropertyNames(errors).map(er => {
                                //     //     errorLogs[er] = errors[er];
                                //     // });
                                // }
                                break;
                            // case 'generalAppearanceVehicleInfo':
                            //     const generalAppearanceVehicleValidationSchema = yup
                            //         .object()
                            //         .shape(this.getValidationShape(GeneralAppearanceVehicleConfig));
                            //     try {
                            //         await ValidationHelper.validate(values, generalAppearanceVehicleValidationSchema);
                            //         return resolve();
                            //     } catch (errors) {
                            //         errorLogs[form.name] = errors;
                            //         return resolve();
                            //         // Object.getOwnPropertyNames(errors).map(er => {
                            //         //     errorLogs[er] = errors[er];
                            //         // });
                            //     }
                            //     break;
                            case 'resUnitOccupancySuspicion':
                                const validateResUnitOccupancyInfoErrorLogs = await inspectionsHelper.validateResUnitOccupancyInfo(
                                    values || {},
                                    inspection
                                );
                                Object.getOwnPropertyNames(validateResUnitOccupancyInfoErrorLogs).map(er => {
                                    if (!errorLogs[form.name]) errorLogs[form.name] = {};
                                    errorLogs[form.name][er] = validateResUnitOccupancyInfoErrorLogs[er];
                                });
                                return resolve();

                                // const ResUnitOccupancySchema = yup.object().shape(this.getValidationShape(ResUnitOccupancyConfig));
                                // try {
                                //     await ValidationHelper.validate(values, ResUnitOccupancySchema);
                                //     return resolve();
                                // } catch (errors) {
                                //     errorLogs[form.name] = errors;
                                //     return resolve();
                                //     // Object.getOwnPropertyNames(errors).map(er => {
                                //     //     errorLogs[er] = errors[er];
                                //     // });
                                // }
                                break;
                            case 'siteVisit':
                                const validatesiteVisitInfoErrorLogs = await inspectionsHelper.validateSiteVisitInfo(values || {}, inspection);
                                Object.getOwnPropertyNames(validatesiteVisitInfoErrorLogs).map(er => {
                                    if (!errorLogs[form.name]) errorLogs[form.name] = {};
                                    errorLogs[form.name][er] = validatesiteVisitInfoErrorLogs[er];
                                });
                                return resolve();

                            case 'foodTruckAndOutdoorSeating':
                                const validateFoodTruckAndOutdoorSeatingErrorlogs = await inspectionsHelper.validateFoodTruckAndOutdoorSeating(
                                    values || {},
                                    inspection
                                );
                                Object.getOwnPropertyNames(validateFoodTruckAndOutdoorSeatingErrorlogs).map(er => {
                                    if (!errorLogs[form.name]) errorLogs[form.name] = {};
                                    errorLogs[form.name][er] = validateFoodTruckAndOutdoorSeatingErrorlogs[er];
                                });
                                return resolve();

                            case 'noisePollution':
                                const noisePollutionErrorlogs = await inspectionsHelper.validateNoisePollution(values || {}, inspection);
                                Object.getOwnPropertyNames(noisePollutionErrorlogs).map(er => {
                                    if (!errorLogs[form.name]) errorLogs[form.name] = {};
                                    errorLogs[form.name][er] = noisePollutionErrorlogs[er];
                                });
                                return resolve();

                            default:
                                break;
                        }

                        if (isAbandonedVehicleForm) {
                            const checklistValue = inspection.visits[0].values[0];
                            let { violatorId } = checklistValue;

                            (checklistValue.violationTypeIds || []).map(law => {
                                const possibleDuplicates = (checklistValue.duplicateInspection || {}).duplicateCandidates || [];
                                const decidedDuplicates = checklistValue.duplicates || [];

                                if (possibleDuplicates.length > 0 && decidedDuplicates) {
                                    // currentDuplicates = decidedDuplicates.filter(item => item.lawClausesID == law);
                                    if (decidedDuplicates.length != possibleDuplicates.length) {
                                        if (errorLogs[violatorId]) {
                                            if (!errorLogs[violatorId][law])
                                                errorLogs[violatorId][law] = [
                                                    {
                                                        duplicate:
                                                            `${possibleDuplicates.length - decidedDuplicates.length} ` +
                                                            strings('notverifiedduplicates'),
                                                    },
                                                ];
                                            else
                                                errorLogs[violatorId][law].push({
                                                    duplicate:
                                                        `${possibleDuplicates.length - decidedDuplicates.length} ` + strings('notverifiedduplicates'),
                                                });
                                        } else {
                                            errorLogs[violatorId] = {
                                                [law]: [
                                                    {
                                                        duplicate:
                                                            `${possibleDuplicates.length - decidedDuplicates.length} ` +
                                                            strings('notverifiedduplicates'),
                                                    },
                                                ],
                                            };
                                        }
                                    }
                                }
                            });
                            if (errorLogs.length > 0) return reject();
                            return resolve();
                        } else {
                            if (inspection && inspection.duplicateInspection && inspection.duplicateInspection.checking) {
                                errorLogs.duplicate = (errorLogs.duplicate || '') + strings('duplicatechecking');
                                return reject();
                            } else if (inspection && inspection.duplicateInspection && inspection.duplicateInspection.error != undefined) {
                                return resolve();
                            } else if (
                                inspection &&
                                inspection.duplicateInspection &&
                                inspection.duplicateInspection.duplicateCandidates.length > 0
                            ) {
                                if (inspection.duplicate == undefined) {
                                    errorLogs.duplicate =
                                        (errorLogs.duplicate || '') +
                                        strings('thereare') +
                                        `${inspection.duplicateInspection.duplicateCandidates.length} ` +
                                        strings('possibleduplicates');
                                    return reject();
                                } else {
                                    return resolve();
                                }
                            }
                        }
                        //  return resolve();
                    }
                });
            } else if (inspectionDefinition) {
                const notfilledCheckList = [];
                for (grp of inspectionDefinition.checklistGroups) {
                    if (!grp.checklist) continue;
                    grp.checklist.forEach(checkItem => {
                        const checklistValue = (selectedVisitValues || []).find(selectedItem => selectedItem.checkItemId == checkItem.checkItemId);
                        if (checklistValue) {
                            if (showAllCheckItem || checkItem.violationTypeIds.length > 0) {
                                // if (checklistValue.selectedOption == 'no' || checklistValue.selectedOption == true) {

                                let { violatorId } = checklistValue;
                                if (showAllCheckItem && inspection.violators.length > 0) violatorId = inspection.violators[0].violatorId;
                                if (violatorId) {
                                    const violationTypeIdscheckItemId = checkItem.violationTypeIds[0] || checkItem.checkItemId;
                                    if (checkItem.isAttachementMandatory && (!checklistValue.attachments || checklistValue.attachments.length == 0)) {
                                        if (errorLogs[violatorId]) {
                                            if (!errorLogs[violatorId][violationTypeIdscheckItemId])
                                                errorLogs[violatorId][violationTypeIdscheckItemId] = [
                                                    { attachement: strings('attachementIsRequired') },
                                                ];
                                            else
                                                errorLogs[violatorId][violationTypeIdscheckItemId].push({
                                                    attachement: strings('attachementIsRequired'),
                                                });
                                        } else {
                                            errorLogs[violatorId] = {
                                                [violationTypeIdscheckItemId]: [{ attachement: strings('attachementIsRequired') }],
                                            };
                                        }
                                    }
                                    if (checkItem.isRemarkMandatory && (!checklistValue.remarks || checklistValue.remarks.length == 0)) {
                                        if (errorLogs[violatorId]) {
                                            if (!errorLogs[violatorId][violationTypeIdscheckItemId])
                                                errorLogs[violatorId][violationTypeIdscheckItemId] = [{ remark: strings('remarksIsRequired') }];
                                            else errorLogs[violatorId][violationTypeIdscheckItemId].push({ remark: strings('remarksIsRequired') });
                                        } else {
                                            errorLogs[violatorId] = {
                                                [violationTypeIdscheckItemId]: [{ remark: strings('remarksIsRequired') }],
                                            };
                                        }
                                    }
                                    (checklistValue.violationTypeIds || []).map(law => {
                                        const possibleDuplicates = (checklistValue.duplicateInspection || {}).duplicateCandidates || [];
                                        const decidedDuplicates = checklistValue.duplicates || [];

                                        // duplicateCandidates.duplicates
                                        //     ? duplicateCandidates.duplicates.filter(d => d.lawClausesID == law)
                                        //     : [];
                                        if (possibleDuplicates.length > 0 && decidedDuplicates) {
                                            // currentDuplicates = decidedDuplicates.filter(item => item.lawClausesID == law);
                                            if (decidedDuplicates.length != possibleDuplicates.length) {
                                                if (errorLogs[violatorId]) {
                                                    if (!errorLogs[violatorId][law])
                                                        errorLogs[violatorId][law] = [
                                                            {
                                                                duplicate:
                                                                    `${possibleDuplicates.length - decidedDuplicates.length} ` +
                                                                    strings('notverifiedduplicates'),
                                                            },
                                                        ];
                                                    else
                                                        errorLogs[violatorId][law].push({
                                                            duplicate:
                                                                `${possibleDuplicates.length - decidedDuplicates.length} ` +
                                                                strings('notverifiedduplicates'),
                                                        });
                                                } else {
                                                    errorLogs[violatorId] = {
                                                        [law]: [
                                                            {
                                                                duplicate:
                                                                    `${possibleDuplicates.length - decidedDuplicates.length} ` +
                                                                    strings('notverifiedduplicates'),
                                                            },
                                                        ],
                                                    };
                                                }
                                            }
                                        }
                                    });
                                } else {
                                    if (
                                        checklistValue.selectedOption != 'na' &&
                                        checkItem.isAttachementMandatory &&
                                        (!checklistValue.attachments || checklistValue.attachments.length == 0)
                                    ) {
                                        if (!errorLogs[checkItem.checkItemId])
                                            errorLogs[checkItem.checkItemId] = [{ attachement: strings('attachementIsRequired') }];
                                        else
                                            errorLogs[checkItem.checkItemId].push({
                                                attachement: strings('attachementIsRequired'),
                                            });
                                    }
                                    if (
                                        checklistValue.selectedOption != 'na' &&
                                        checkItem.isRemarkMandatory &&
                                        (!checklistValue.remarks || checklistValue.remarks.length == 0)
                                    ) {
                                        if (!errorLogs[checkItem.checkItemId])
                                            errorLogs[checkItem.checkItemId] = [{ remark: strings('remarksIsRequired') }];
                                        else errorLogs[checkItem.checkItemId].push({ remark: strings('remarksIsRequired') });
                                    }
                                }

                                if (
                                    !showAllCheckItem &&
                                    (checklistValue.selectedOption == 'no' || checklistValue.selectedOption == true) &&
                                    checklistValue.violationTypeIds.length == 0
                                ) {
                                    if (!errorLogs[checkItem.checkItemId]) errorLogs[checkItem.checkItemId] = [strings('lawClauseIsRequired')];
                                    else errorLogs[checkItem.checkItemId].push(strings('lawClauseIsRequired'));
                                }
                                let hasValidationlogs =
                                    Object.getOwnPropertyNames(errorLogs).filter(c => c != 'common').length +
                                        Object.getOwnPropertyNames(errorLogs.common || {}).length >
                                    0;
                                if (hasValidationlogs) {
                                    return resolve();
                                }
                            }
                            // }
                        } else {
                            if (checkItem.isMandatory) {
                                notfilledCheckList.push(checkItem);
                            }
                        }
                    });
                }
                if (notfilledCheckList.length > 0) {
                    errorLogs.notTouchedCheckList = notfilledCheckList.map(n => localeProperty(n, 'question'));
                }
                return resolve();
            } else {
                return resolve();
            }
            // return resolve();
        });
    };

    render() {
        const { visit, inspection, visitIndex, needValidation, isSubmitable, currentInspectionVersion } = this.props;
        let currentVisitIndex = visitIndex;
        const currentVisitData = visit;
        const generalInfo = currentVisitData && currentVisitData.generalInfo;
        const remarks = (generalInfo || { remarks: '.' }).remarks;
        const address = inspection && inspection.location && inspection.location.address;
        const coords = inspection && inspection.location && inspection.location.coords;
        const { inspectionTypeDetail } = inspection || {};
        let validateViolator = true;
        let serveyItems = [];
        let currentViolator;
        const isSurveyFromOtherEntity = inspectionTypeDetail && inspectionTypeDetail.inspEntityId != 1000;
        const isSurveyFromADM =
            inspectionTypeDetail &&
            inspectionTypeDetail.inspEntityId == 1000 &&
            inspectionTypeDetail.workflowConst == 'MimsInformationRequestOnDemand';
        const isSurvey = isSurveyFromOtherEntity || isSurveyFromADM;
        if (isSurvey) {
            validateViolator = false;
            serveyItems =
                inspectionsHelper.getServeyChecklistItems({
                    items: currentVisitData.values || [],
                    inspectionDef: currentVisitData.def,
                }) || {};
            if (inspection.violators && inspection.violators.length > 0) currentViolator = inspection.violators[0];
        }

        const violators = inspection.violators || [];
        const { complianceItems, unAssignedItems, totalNumberOfAwareness, totalViolationAmount, totalNumberOfWarning } = !validateViolator
            ? {}
            : inspectionsHelper.classifyChecklistItems({
                  items: currentVisitData.values,
                  inspectionDef: currentVisitData.def,
                  violators,
              }) || {};

        const { violatorsAndViolations } = !validateViolator
            ? {}
            : inspectionsHelper.getViolatorsAndViolations({
                  visit: currentVisitData,
                  inspectionDef: currentVisitData.def,
                  violators,
                  currentInspectionVersion,
              }) || {};
        let unAssignedViolationTypes = unAssignedItems;
        const commonError = {};
        const noactions = (violatorsAndViolations || []).reduce((total, e) => total + e.noActionItems.length, 0);
        if (noactions > 0) {
            commonError.noAction = strings('noActionTypeSelected') + ' ' + strings('for') + ' ' + noactions + ' ' + strings('Item');
        }
        if (needValidation) {
            // && !isSurveyFromADM
            // if (isSurvey && violators.length == 0) {
            //     commonError.businessEntity = strings('establishment') + ' ' + strings('isRequired');
            // }
            if (unAssignedViolationTypes && unAssignedViolationTypes.length > 0) {
                commonError.unAssignedViolation = '';
            }
            inspectionsHelper
                .validateInspectionDetails(
                    { remarks, address: coords, inspection, currentVisitIndex, currentVisitData, unAssignedItems },
                    this.validateInspection
                )
                .then(err => {
                    if (err.commonFormError) {
                        Object.getOwnPropertyNames(err.commonFormError).map(c => {
                            commonError[c] = err.commonFormError[c];
                        });
                    }
                    const totalerr = { ...err, common: commonError };
                    let hasValidationlogs = Object.getOwnPropertyNames(err).length + Object.getOwnPropertyNames(commonError).length == 0;
                    if (isSubmitable) isSubmitable(hasValidationlogs, totalerr);
                });
        }
        const showInspCommonFieldsAtTop = !!this.props.showInspCommonFieldsAtTop;
        return (
            <View style={{ flex: 1, padding: 5, marginBottom: 15 }}>
                {!showInspCommonFieldsAtTop && <InspectionViewCommonFields inspection={inspection} />}
                {totalNumberOfAwareness || totalNumberOfWarning || totalViolationAmount ? (
                    <HeaderCounts
                        totalNumberOfAwareness={totalNumberOfAwareness}
                        totalNumberOfWarning={totalNumberOfWarning}
                        totalViolationAmount={totalViolationAmount}
                    />
                ) : null}

                <GeneralPreview
                    unAssignedViolationTypes={unAssignedViolationTypes}
                    violatorsAndViolations={violatorsAndViolations}
                    complianceItems={complianceItems}
                    serveyItems={serveyItems}
                    isSurveyFromADM={isSurveyFromADM}
                    currentViolator={currentViolator}
                    {...this.props}
                ></GeneralPreview>
            </View>
        );
    }
}
