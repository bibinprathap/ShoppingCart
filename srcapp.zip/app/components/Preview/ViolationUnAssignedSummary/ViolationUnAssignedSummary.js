import React, { memo } from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-paper';
import { strings, localeProperty, formatCurrency } from 'app/config/i18n/i18n';
import { commonStyles, Icon, CustomAccordion } from 'app/components';
import { ViolationItemReview } from '../ViolationItemReview';
import { inspectionsHelper } from 'app/api/helperServices';
import styles from './styles';
export default memo(function(props) {
    const renderViolatorsTitle = () => {
        const { items } = props;
        return (
            <View style={styles.violationHeadingContainer}>
                <Text style={[commonStyles.generalHeading, styles.accordionHeading]}>
                    {strings('unAssignedViolations')} ({items ? items.length : 0})
                </Text>
            </View>
        );
    };
    const { items, errorLogs } = props;
    return (
        <React.Fragment>
            <View style={[styles.violatorCardOuter, styles.errorBorder]}>
                <CustomAccordion index="1" renderHeaderTitle={renderViolatorsTitle} items={items} expandedAtStart={true}>
                    {items.map((violationItem, idx) => {
                        if (!violationItem.item) return null;
                        const { attachments, remarks, amount, selectedPeriod, selectedPeriodType } = violationItem.item;
                        let finalVolationAmount = violationItem.lawClause
                            ? inspectionsHelper.getViolationAmount({
                                  lawClauseIDs: [violationItem.lawClause.violationTypeId],
                                  occurance: 1,
                                  discount: 0,
                              })
                            : amount;
                        return (
                            <ViolationItemReview
                                key={idx.toString()}
                                violationItem={violationItem}
                                selectedActionTypeConst="unassigned"
                                attachments={attachments}
                                remarks={remarks}
                                violationDescription={
                                    violationItem.lawClause
                                        ? localeProperty(violationItem.lawClause, 'description')
                                        : localeProperty(violationItem.itemDef, 'question')
                                }
                                errorLogs={[' ']}
                                duplicateInspection={violationItem.item.duplicateInspection}
                                dispatch={props.dispatch}
                                selectedPeriod={selectedPeriod}
                                selectedPeriodType={selectedPeriodType}
                                amount={finalVolationAmount}
                            />
                        );
                    })}
                    {errorLogs.unAssignedItems ? (
                        <Text style={[commonStyles.ValidationMessageText, styles.violationSummaryHeadingContainer]}>{errorLogs.unAssignedItems}</Text>
                    ) : null}

                    <View style={styles.violatorOuter} />
                </CustomAccordion>
            </View>
        </React.Fragment>
    );
});
