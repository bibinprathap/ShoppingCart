//common styles for Preview components
import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    divider: {
        //width: '100%',
        marginVertical: 6,
    },
    generalHeading: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        justifyContent: 'flex-end',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    generalText: {
        fontSize: '$primaryTextSM',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
        textAlignVertical: 'center',
    },
    generalTextMD: {
        fontSize: '$primaryTextMD',
    },
    generalTextXXS: {
        fontSize: '$primaryTextXXS',
    },
    ValidationMessageText: {
        fontSize: '$primaryTextXXS',
        color: '$primaryErrorTextColor',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    mutedText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    itemIconContainer: {
        margin: 5,
        borderRadius: 5,
        backgroundColor: '$primaryHeaderColor',
        justifyContent: 'center',
        alignItems: 'center',
        width: 30,
        height: 30,
    },
    itemIcon: {
        fontSize: 25,
        justifyContent: 'center',
        alignItems: 'center',
        color: '$primaryWhite',
    },
    linkText: {
        color: '$primaryHeaderColor',
    },
    itemRow: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginTop: 10,
        minHeight: 40,
    },
    itemRowStretched: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    line: {
        borderBottomColor: '#F0EDEC',
        borderBottomWidth: 1,
        paddingVertical: 4,
    },
});
