import React, { Component } from 'react';
import { ScrollView, View, Text, TouchableOpacity } from 'react-native';
import { Icon } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import * as Animatable from 'react-native-animatable';

class ScrollViewWithIndicator extends Component {
    constructor(props) {
        super(props);
        this.state = {
            scrollViewWidth: 0,
            currentXOffset: 0,
            hideLeftArrow: true,
            hideRightArrow: true,
            layoutWidth: 0,
        };
        this.onContentSizeChange = this.onContentSizeChange.bind(this);
    }

    onContentSizeChange(w, h) {
        this.setState({ scrollViewWidth: w });
    }

    handleScroll = event => {
        const newXOffset = event.nativeEvent.contentOffset.x;
        const { layoutMeasurement } = event.nativeEvent;
        const { scrollViewWidth } = this.state;
        this.setState({ currentXOffset: newXOffset });

        if (scrollViewWidth > this.state.layoutWidth) {
            if (newXOffset === 0) {
                this.setState({ hideLeftArrow: true });
            } else {
                this.setState({ hideLeftArrow: false });
            }

            if (parseInt(layoutMeasurement.width + newXOffset) >= parseInt(scrollViewWidth)) {
                this.setState({ hideRightArrow: true });
            } else {
                this.setState({ hideRightArrow: false });
            }
        }
    };

    leftArrow = () => {
        const eachItemOffset = this.state.scrollViewWidth / 5;
        const currentXOffset = this.state.currentXOffset - eachItemOffset;
        this.refs.scrollView.scrollTo({ x: currentXOffset, y: 0, animated: true });
    };

    rightArrow = () => {
        const eachItemOffset = this.state.scrollViewWidth / 5;
        const currentXOffset = this.state.currentXOffset + eachItemOffset;
        this.refs.scrollView.scrollTo({ x: currentXOffset, y: 0, animated: true });
    };

    render() {
        const { hideLeftArrow, hideRightArrow } = this.state;
        const { children, ...otherProps } = this.props;
        return (
            <View
                onLayout={event => {
                    let { width } = event.nativeEvent.layout;
                    if (this.state.scrollViewWidth > width) {
                        this.setState({ hideRightArrow: false, layoutWidth: width });
                        return;
                    }
                    this.setState({ layoutWidth: width });
                }}
                style={styles.container}
            >
                <ScrollView
                    {...(otherProps || {})}
                    horizontal
                    ref="scrollView"
                    onContentSizeChange={this.onContentSizeChange}
                    onScroll={this.handleScroll}
                >
                    {children || null}
                </ScrollView>
                {!hideLeftArrow && (
                    <Animatable.View animation="fadeInLeft" style={styles.leftIconWrapper}>
                        <TouchableOpacity onPress={this.leftArrow}>
                            <Icon type="MaterialCommunityIcons" name="chevron-left" style={styles.iconStyle} />
                        </TouchableOpacity>
                    </Animatable.View>
                )}
                {!hideRightArrow && (
                    <Animatable.View animation="fadeInRight" style={styles.rightIconWrapper}>
                        <TouchableOpacity onPress={this.rightArrow}>
                            <Icon type="MaterialCommunityIcons" name="chevron-right" style={styles.iconStyle} />
                        </TouchableOpacity>
                    </Animatable.View>
                )}
            </View>
        );
    }
}

const styles = EStyleSheet.create({
    container: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'center',
    },
    leftIconWrapper: {
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        alignItems: 'flex-start',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F7F7FA',
        position: 'absolute',
        left: 0,
    },
    rightIconWrapper: {
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        alignItems: 'flex-end',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F7F7FA',
        position: 'absolute',
        right: 0,
    },
    iconStyle: {
        fontSize: 24,
        margin: 5,
        color: '#555',
        alignSelf: 'center',
    },
});

export default ScrollViewWithIndicator;
