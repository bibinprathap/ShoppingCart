import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, TextInput, Picker, TouchableOpacity } from 'react-native';
import { IconButton, Button } from 'react-native-paper';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import moment from 'moment';
import { strings } from 'app/config/i18n/i18n';
import DatePicker from 'react-native-datepicker';
import styles from './styles';
import Breadcrumb from './Breadcrumb';
import { NetWorkStatus } from 'app/screens';
import { withNavigation } from 'react-navigation';
import { setSearchKey, setFilter, search, resetSearch, setSearchDate, setAddress } from 'app/actions/search';
import { AddressPicker } from 'app/components';

import { Text } from 'react-native-paper';

class SearchBar extends Component {
    static propTypes = {
        breadCrumbs: PropTypes.array,
    };

    constructor(props) {
        super(props);
        this.state = { searchKey: props.search.searchKey, fromDate: props.search.searchFromDate, toDate: props.search.searchToDate };
    }

    // componentDidUpdate(prevProps, prevState) {
    //     if (this.props.search.searchKey != this.state.searchKey) {
    //         this.setState({ searchKey: this.props.search.searchKey });
    //     }
    // }

    handleSearch = () => {
        const { search, navigation, actions } = this.props;
        if (search.isLoading) return;
        const routeName = (navigation && navigation.state.routeName) || null;
        if (routeName !== 'search') {
            if (this.state.searchKey) actions.search(this.state.searchKey, search.filter);
            return navigation.navigate('search');
        }
        actions.search(this.state.searchKey, search.filter);
    };

    updateSearchKey = (searchKey) => {
        this.setState({ searchKey });
        this.props.actions.setSearchKey(searchKey);
        if (!searchKey) {
            this.props.actions.resetSearch();
        }
    };
    setFromDateBetween = (fromDate) => {
        this.setState({ fromDate });
        this.props.actions.setSearchDate({ fromDate, toDate: this.state.toDate });
    };
    setToDateBetween = (toDate) => {
        this.setState({ toDate });
        this.props.actions.setSearchDate({ fromDate: this.state.fromDate, toDate });
    };

    onValueChange = (type, itemIndex) => {
        this.setState({ searchKey: '' });
        this.props.actions.setFilter({ type });
    };

    render() {
        const { breadCrumbs, navigation, search, actions, handleSearch, SearchBar } = this.props;
        const routeName = (navigation && navigation.state.routeName) || null;

        const filterTypeInput =
            this.props.search.filter && (this.props.search.filter.type === 'address' || this.props.search.filter.type === 'betweendate');
        const { fromDate, toDate, searchKey } = this.state;
        const fromDatemoment = moment(fromDate, 'LL', true);
        const formattedfromDateValue = fromDatemoment.isValid() ? fromDatemoment.format('LL') : fromDate;
        const toDatemoment = moment(toDate, 'LL', true);
        const formattedtoDateValue = toDatemoment.isValid() ? toDatemoment.format('LL') : toDate;
        const textInputTheme = {
            colors: { text: styles.input.color, placeholder: styles.placeholder.color, primary: styles.placeholder.color },
        };
        return (
            <View style={styles.container}>
                {routeName !== 'search' ? (
                    <NetWorkStatus />
                ) : (
                    // <Breadcrumb breadCrumbs={breadCrumbs} />
                    <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
                        <Picker selectedValue={search.filter.type} style={{ height: 50, width: 180 }} onValueChange={this.onValueChange}>
                            <Picker.Item label={strings('applicationNumber')} value="referenceNumber" style={styles.pickerItem} />
                            <Picker.Item label={strings('issueNumber')} value="workflowApplicationNumber" style={styles.pickerItem} />
                            <Picker.Item label={strings('emiratesId')} value="emiratesID" style={styles.pickerItem} />
                            <Picker.Item label={strings('address')} value="address" style={styles.pickerItem} />
                            <Picker.Item label={strings('phoneNumber')} value="phone" style={styles.pickerItem} />
                            <Picker.Item label={strings('nearby')} value="nearby" style={styles.pickerItem} />
                            <Picker.Item label={strings('betweendate')} value="betweendate" style={styles.pickerItem} />
                        </Picker>
                        {search.filter && search.filter.type === 'address' && <AddressPicker actions={actions} handleSearch={handleSearch} />}
                        {search.filter && search.filter.type === 'betweendate' && (
                            <View style={{ flex: 1, flexDirection: 'row' }}>
                                <View style={{ flex: 1, height: 55, flexDirection: 'row' }}>
                                    <Text style={[styles.label, { paddingVertical: 14 }]}> {strings('fromdate')} </Text>
                                    <DatePicker
                                        style={{ width: 120 }}
                                        date={fromDate}
                                        mode="date"
                                        placeholder="select date"
                                        format="YYYY-MM-DD"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        customStyles={{
                                            dateIcon: {
                                                width: 0,
                                                height: 0,
                                            },
                                            dateInput: {
                                                marginLeft: 10,
                                            },
                                            // ... You can check the source to find the other keys.
                                        }}
                                        onDateChange={this.setFromDateBetween}
                                    />
                                </View>
                                <View style={{ flex: 1, height: 55, flexDirection: 'row' }}>
                                    <Text style={[styles.label, { paddingVertical: 14 }]}> {strings('todate')} </Text>
                                    <DatePicker
                                        style={{ width: 120 }}
                                        date={toDate}
                                        mode="date"
                                        placeholder="select date"
                                        format="YYYY-MM-DD"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        customStyles={{
                                            dateIcon: {
                                                width: 0,
                                                height: 0,
                                            },
                                            dateInput: {
                                                marginLeft: 10,
                                            },
                                            // ... You can check the source to find the other keys.
                                        }}
                                        onDateChange={this.setToDateBetween}
                                    />
                                </View>
                            </View>
                        )}
                    </View>
                )}
                {!filterTypeInput && (
                    <TextInput
                        style={[styles.textInput]}
                        autoCorrect={false}
                        value={searchKey}
                        onChangeText={this.updateSearchKey}
                        autoCapitalize="none"
                    />
                )}
                {this.props.search.filter && this.props.search.filter.type != 'address' && (
                    <IconButton
                        disabled={!searchKey}
                        icon="search"
                        size={20}
                        style={styles.searchIcon}
                        onPress={handleSearch.bind(this, this.state)}
                    />
                )}
            </View>
        );
    }
}

mapStateToProps = (state) => {
    return {
        search: state.search || {},
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(
            {
                setSearchKey,
                setAddress,
                setFilter,
                search,
                resetSearch,
                setSearchDate,
            },
            dispatch
        ),
        dispatch,
    };
};

const connectedNotifications = connect(mapStateToProps, mapDispatchToProps)(SearchBar);

export default withNavigation(connectedNotifications);
