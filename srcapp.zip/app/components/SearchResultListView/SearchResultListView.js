import React, { Component } from 'react';
import { View, FlatList, ActivityIndicator } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { SearchResultListViewItem, Icon } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import SearchResultPlaceholder from './SearchResultPlaceholder';
import { strings } from 'app/config/i18n/i18n';

class SearchResultListView extends Component {
    constructor(props) {
        super(props);
        this.onEndReachedCalledDuringMomentum = true;
    }
    renderItem = ({ item, index, separators }) => {
        const { sourceType, onItemPress } = this.props;
        return <SearchResultListViewItem sourceType={sourceType} item={item} onItemPress={onItemPress} />;
    };

    keyExtractor = (item, index) => {
        //Todo: remove index from teh key, applicationNumber should be unique, but search api is returning duplicate records
        return `${item.applicationNumber}_${index}`;
    };

    renderSeparator = (highlighted) => {
        return <Divider />;
    };

    render() {
        const { items, loading, onLoadNextPage, onRefresh, refreshing = false, errorMessage } = this.props;
        if (!items || loading === true) {
            return (
                <View style={styles.container}>
                    {[...new Array(10).fill({})].map((e, i) => (
                        <SearchResultPlaceholder key={i} />
                    ))}
                </View>
            );
        }
        return (
            <View style={styles.container}>
                {loading !== true && items && items.length === 0 && (
                    <View style={styles.centerContentWrapper}>
                        {!errorMessage && <Text style={styles.itemMediumText}>{strings('noRecordsToDisplay')}</Text>}
                        {errorMessage && (
                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 10 }}>
                                <Icon type="MaterialCommunityIcons" name="alert" size={20} style={styles.errorIcon} />
                                <Text style={styles.error}>{errorMessage}</Text>
                            </View>
                        )}
                    </View>
                )}
                {items && items.length > 0 && (
                    <FlatList
                        data={items}
                        renderItem={this.renderItem}
                        keyExtractor={this.keyExtractor}
                        ItemSeparatorComponent={this.renderSeparator}
                        initialNumToRender={6}
                        onEndReachedThreshold={0.5}
                        onEndReached={() => {
                            if (!this.onEndReachedCalledDuringMomentum) onLoadNextPage();
                        }}
                        onRefresh={onRefresh}
                        refreshing={refreshing}
                        onMomentumScrollBegin={() => {
                            this.onEndReachedCalledDuringMomentum = false;
                        }}
                    />
                )}
            </View>
        );
    }
}

export default SearchResultListView;

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'transparent',
    },
    centerContentWrapper: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    itemMediumText: {
        fontSize: '$primaryTextSM',
        color: '$primaryMediumTextColor',
    },
    error: {
        color: '$primaryErrorTextColor',
        fontSize: '$primaryTextXS',
    },
    errorIcon: {
        marginRight: 5,
        color: '$primaryErrorTextColor',
    },
});
