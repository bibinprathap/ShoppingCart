import React from 'react';
import { View } from 'react-native';
import { Placeholder, PlaceholderMedia, PlaceholderLine, ShineOverlay } from 'rn-placeholder';

const SearchResultPlaceholder = () => (
    <Placeholder
        Animation={ShineOverlay}
        style={{
            marginVertical: 6,
            marginHorizontal: 2,
            borderRadius: 4,
        }}
    >
        <View style={{ flex: 1, flexDirection: 'row' }}>
            <View style={{ flex: 1, alignSelf: 'flex-start', maxWidth: 225, minWidth: 225, width: 225 }}>
                <PlaceholderLine style={{ marginLeft: 5 }} width={50} />
            </View>

            <View style={{ flex: 1, flexDirection: 'row' }}>
                <PlaceholderMedia
                    style={[
                        {
                            width: 40,
                            height: 20,
                            marginLeft: 20,
                            marginTop: 0,
                        },
                    ]}
                />

                <PlaceholderMedia
                    style={[
                        {
                            width: 20,
                            height: 20,
                            marginLeft: 200,
                            marginTop: 0,
                        },
                    ]}
                />
                <PlaceholderMedia
                    style={[
                        {
                            width: 20,
                            height: 20,
                            marginLeft: 2,
                            marginTop: 0,
                        },
                    ]}
                />
            </View>
        </View>
        <View style={{ flexDirection: 'row' }}>
            <View style={styles.itemIconContainer}>
                <PlaceholderMedia
                    style={[
                        {
                            width: 20,
                            height: 20,
                            marginTop: 20,
                        },
                    ]}
                />
            </View>
            <View style={{ flex: 1 }}>
                <PlaceholderLine style={{ marginTop: 20 }} width={225} />
                <PlaceholderLine width={50} />
            </View>
        </View>
    </Placeholder>
);

export default SearchResultPlaceholder;
