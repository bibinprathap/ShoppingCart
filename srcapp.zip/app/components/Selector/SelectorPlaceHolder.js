import React from 'react';
import { View } from 'react-native';
import { Placeholder, PlaceholderMedia, PlaceholderLine, ShineOverlay } from 'rn-placeholder';

const SelectorPlaceHolder = () => (
    <Placeholder
        Animation={ShineOverlay}
        style={{
            marginVertical: 6,
            marginHorizontal: 2,
            borderRadius: 4,
        }}
    >
        <View style={{ flexDirection: 'row' }}>
            <View style={{ flex: 1 }}>
                <PlaceholderLine style={{ marginTop: 20 }} width={225} />
            </View>
        </View>
    </Placeholder>
);

export default SelectorPlaceHolder;
