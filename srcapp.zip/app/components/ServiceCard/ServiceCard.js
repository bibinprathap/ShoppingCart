import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, I18nManager, TouchableOpacity } from 'react-native';
import { Text, TouchableRipple } from 'react-native-paper';
import Popover from 'react-native-popover-view';
import { localeProperty } from 'app/config/i18n/i18n';
import styles from './styles';
import images from 'app/images';
import { Icon } from 'app/components';

class ServiceCard extends React.PureComponent {
    static propTypes = {
        serviceDefinition: PropTypes.object,
        selected: PropTypes.bool,
        onPress: PropTypes.func,
    };

    constructor() {
        super();
        this.state = { isVisible: false, popoverDesc: null };
    }
    touchable;

    handleOnPress = () => {
        if (this.props.onPress) this.props.onPress(this.props.serviceDefinition);
    };

    showServiceDesc = () => {
        const desc = localeProperty(this.props.serviceDefinition, 'serviceDesc');
        this.setState({ isVisible: true, popoverDesc: desc });
    };

    closePopover = () => {
        this.setState({ isVisible: false });
    };
    render() {
        const { serviceDefinition, selected } = this.props;
        let styleClassName = I18nManager.isRTL ? 'titleSM' : 'titleMD';
        /*
        //below is a very dirty and poor solution adjust the fontsize based on text length.
        //android doesn't support adjustsFontSizeToFit, a better solution can be made with some R&D
        //for now live with it

        let titleLength = serviceDefinition.title.length;
        if (titleLength <= 15)
            styleClassName = 'titleLG';
        else if (titleLength <= 20)
            styleClassName = 'titleMD';
        else styleClassName = 'titleSM';
        */
        const infoStyles = [styles.info];
        const titleStyles = [styles.title, styles[styleClassName], { textAlign: 'center' }];
        const containerStyles = [styles.container, selected ? styles.selected : null];
        const desc = localeProperty(this.props.serviceDefinition, 'serviceDesc');
        const titleColor = styles.title.color; //for unknown reason, using the styles.title directly messes up the alignment of the parent view
        return (
            <View>
                <Popover isVisible={this.state.isVisible} fromView={this.touchable} onRequestClose={this.closePopover}>
                    <View style={styles.popoverContainer}>
                        <Text style={styles.popoverText}>{this.state.popoverDesc}</Text>
                    </View>
                </Popover>
                <TouchableRipple onPress={this.handleOnPress}>
                    <View style={containerStyles}>
                        {desc && (
                            <View>
                                <TouchableOpacity ref={ref => (this.touchable = ref)} onPress={this.showServiceDesc} style={styles.infoTouch}>
                                    <Icon type="MaterialCommunityIcons" name="alert-circle-outline" size={24} style={styles.infoIcon} />
                                </TouchableOpacity>
                            </View>
                        )}
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                            <Icon {...serviceDefinition.icon} style={styles.icon} />
                            <Text
                                adjustsFontSizeToFit={true}
                                minimumFontScale={0.1}
                                //style={titleStyles}
                                //style={[styles[styleClassName], styles.title, { textAlign: 'center' }]}
                                style={[styles[styleClassName], { textAlign: 'center', color: titleColor }]}
                            >
                                {localeProperty(serviceDefinition, 'title')}
                            </Text>
                        </View>
                    </View>
                </TouchableRipple>
            </View>
        );
    }
}

export default ServiceCard;
