import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {
        backgroundColor: 'rgba(255, 255, 255, .5)',
    },
    icon: {
        color: '$primaryWhite',
    },
    selectServiceMessage: {
        fontSize: '$primaryTextMD',
        backgroundColor: 'transparent',
        alignSelf: 'flex-start',
        marginStart: 10,
    },
    horizontalView: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-end',
    },
    cateogyrText: {
        color: '$primaryWhite',
    },
    subServicesContainer: {
        flex: 1,
        //marginTop: 10,
        //marginBottom: 10,
        paddingVertical: 5,
        paddingHorizontal: 10,
        backgroundColor: '$primaryDarkBackground',
        color: '$primaryWhite',
        height: 120,
    },
    subServicesContainerWithNoSubServices: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    noSubServiceText: {
        color: '$primaryMediumTextColor',
        fontSize: '$primaryTextMD',
        textAlign: 'center',
    },
    selectedSericesView: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginBottom: 100,
        width: '100%',
    },
    selectedSericesContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        marginBottom: 100,
        width: '100%',
        paddingHorizontal: 7,
    },
    selectedSericesClip: {
        backgroundColor: '$primarySelectedItem',
        color: '$primaryLightTextColor',
        padding: 3,
    },
    breadcrumbArrow: {
        marginStart: -5,
        transform: [{ rotate: I18nManager.isRTL ? '180deg' : '0deg' }],
    },
});
