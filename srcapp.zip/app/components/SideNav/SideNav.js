import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, Image, ScrollView, TouchableOpacity } from 'react-native';
import { Text } from 'react-native-paper';
import { Icon, createRotatable, HeaderGeneric, Modal } from 'app/components';
import { withNavigation } from 'react-navigation';
import styles from './styles';
import images from 'app/images';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';
import { Settings } from 'app/screens';
import { dashboardNavChanged } from 'app/actions/settings';
// import { setLoading, setLoaded } from 'app/actions/loader';
// import { authLogout } from 'app/actions/auth';
class SideNav extends Component {
    static propTypes = {
        routes: PropTypes.array,
        currentRouteName: PropTypes.string,
        onPress: PropTypes.func,
        userData: PropTypes.object,
    };

    constructor(props) {
        super(props);
        this.renderRoutes = this.renderRoutes.bind(this);
        this.state = { settingsModalVisible: false };
    }
    rotatableIcon = createRotatable(Icon);

    toggleSettingsDialog = () => {
        this.setState({ settingsModalVisible: !this.state.settingsModalVisible });
    };

    handleAvatarOnPress = () => {
        this.handleOnPress('profile');
    };

    renderRoutes(routes) {
        const { navigation } = this.props;
        const currentRouteName = navigation.state.routeName;
        return routes.map(item => {
            const handleOnPress = () => {
                setImmediate(() => {
                    this.handleOnPress(item.key);
                });
            };
            let { displayInSideNav = true } = item;
            if (!displayInSideNav) {
                return null;
            }
            const selected = (currentRouteName && currentRouteName === item.key) || this.props.selectedDashboardTab === item.key;
            let routeItemContainerStyles = [styles.routeItemContainer];

            if (selected) routeItemContainerStyles.push(styles.routeItemContainerSelected);
            return (
                <TouchableOpacity key={item.key} onPress={handleOnPress}>
                    <View style={routeItemContainerStyles}>
                        <Icon {...item.icon} size={45} style={styles.routeItemIcon} />
                        {item.menuTitle && <Text style={{ color: 'white' }}>{item.menuTitle}</Text>}
                    </View>
                </TouchableOpacity>
            );
        });
    }
    handleOnPress = menuItemKey => {
        const { dispatch, navigation } = this.props;
        const currentRouteName = navigation.state.routeName;
        switch (menuItemKey) {
            case 'tasks':
            case 'history':
            case 'inspectionPlan':
                if (currentRouteName !== 'dashboard') {
                    navigation.navigate('dashboard');
                }
                dispatch(dashboardNavChanged({ selectedDashboardTab: menuItemKey }));
                return;
            case 'settings':
                this.toggleSettingsDialog();
                return;
            // case 'logout':
            //     dispatch(setLoading({ options: { message: 'Signing out...' } }));
            //     Promise.resolve(dispatch(authLogout()))
            //         .then(() => {

            //             navigation.navigate('auth');
            //             dispatch(setLoaded());
            //         })
            //         .catch(() => {
            //             navigation.navigate('auth');
            //             dispatch(setLoaded());
            //         });
            //     return;
            default:
                this.props.navigation.navigate(menuItemKey);
        }

        // setImmediate(() => {
        //     if (this.props.onPress && typeof this.props.onPress === 'function') this.props.onPress(item);
        // });
    };

    render() {
        const { routes, userData } = this.props;
        const avatarStyles = [styles.avatar, { width: 56, height: 56, borderRadius: 28 }];
        const routeItems = !routes ? null : this.renderRoutes(routes);
        return (
            <View>
                <Modal animationType="slide" transparent={false} visible={this.state.settingsModalVisible} onRequestClose={this.toggleSettingsDialog}>
                    <HeaderGeneric backAction={this.toggleSettingsDialog} title={strings('settings')} />
                    <Settings requestClose={this.toggleSettingsDialog} />
                </Modal>
                <View style={{ flexDirection: 'row', height: '100%' }}>
                    <View style={[styles.sideNavOuterContainer, { zIndex: 100 }]}>
                        <ScrollView>
                            <View style={styles.sideNavInnerContainer}>
                                <View style={[styles.avatarContainer, {}]}>
                                    <TouchableOpacity onPress={this.handleAvatarOnPress}>
                                        {!!userData && <Image source={{ uri: `data:image/jpg;base64,${userData.photo}` }} style={avatarStyles} />}
                                        {!userData && <Image source={images.avatar.content} style={avatarStyles} />}
                                    </TouchableOpacity>
                                </View>
                                {routeItems}
                            </View>
                        </ScrollView>
                    </View>
                </View>
            </View>
        );
    }
}

mapStateToProps = state => {
    return {
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(withNavigation(SideNav));
