import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    $avatarPadding: 20,
    $avatarWidth: '$sideNavWidth - $avatarPadding',
    $avatarHeight: '$avatarWidth',
    $avatarContainerHeight: '$sideNavWidth',

    $routeItemHeight: 100,

    sideNavOuterContainer: {
        backgroundColor: '$primaryDarkBackground',
        width: 60,
    },
    sideNavInnerContainer: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'flex-start',
        //backgroundColor: '$primaryDarkBackground'
    },
    avatarContainer: {
        // width: '$avatarContainerHeight',
        // minWidth: '$avatarContainerHeight',
        // maxWidth: '$avatarContainerHeight',
        justifyContent: 'center',
        alignItems: 'center',
        //paddingVertical: '$avatarPadding',
        paddingVertical: 20,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryDividerDarkColor',
    },
    avatar: {
        // width: '$avatarWidth',
        // height: '$avatarWidth',
        borderRadius: 10,
    },
    routeItemContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        height: '$routeItemHeight',
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryDividerDarkColor',
        width: '$sideNavWidth',
    },
    routeItemContainerSelected: {
        backgroundColor: '$selectedItemBackgroundColor',
    },
    routeItemIcon: {
        color: '$primaryWhite',
    },
    menuToggleArrow: {
        color: '$primaryWhite',
    },
    dashboardNavContainer: {
        //flex: 1,
        flexDirection: 'column',
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        backgroundColor: '$primaryWhite',
    },
    dashboardNavItem: {
        width: '100%',
        height: 75,
        backgroundColor: '$primaryWhite',
    },
    dashboardNavItemActive: {
        backgroundColor: '$primaryHeaderColor',
    },
    dashboardNavItemTouchableContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start',
        marginStart: 20,
    },
    dashboardNavItemTitle: {
        color: '$primaryDarkTextColor',
        fontSize: '$primaryTextSM',
    },
    dashboardNavItemActiveTitle: {
        color: '$primaryLightTextColor',
    },
    dashboardNavItemDescription: {
        color: '$primaryDarkTextColor',
        fontSize: '$primaryTextXXS',
    },
    dashboardNavItemActiveDescription: {
        color: '$primaryLightTextColor',
    },
});
