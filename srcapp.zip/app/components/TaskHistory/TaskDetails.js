import React from 'react';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { View, TouchableOpacity, ScrollView } from 'react-native';
import { Text, Divider } from 'react-native-paper';
import { AttachmentList, LocationAndGoogleMaps, commonStyles, Loader, Icon, IconButton, StatusChip, TaskType } from 'app/components';
import { formatAddress } from 'app/api/helperServices/utils';
import { tasksHelper } from 'app/api/helperServices';
import { AttachmentListWithDialog } from 'app/screens';
import styles2 from './styles';
import moment from 'moment';
import DateChip from './DateChip';

const Taskdetails = props => {
    const dateFormat = 'LLL';
    //const followupButtonstyle = props.taskdetails.status == 'new' ? styles2.buttonPositive : styles2.buttonPositiveDisabled;
    //const startButtonstyle = !props.taskdetails.applicationNumber ? styles2.buttonPositive : styles2.buttonPositiveDisabled;
    const { taskdetails, canPerformTask, canRequestClose } = props;
    const startButtonstyle = [styles2.button, canPerformTask ? styles2.buttonPositive : styles2.buttonPositiveDisabled];
    const closeButtonStyle = [styles2.button, styles2.buttonRequestClose];
    const { inspectionTypeDetail = {}, location = {} } = taskdetails;
    const { address, coords } = location;
    const formattedAddress = formatAddress(address);
    const { icon: inspectionTypeIcon = {} } = inspectionTypeDetail;

    const handleApplicationNumber = () => {
        if (props.onShowInspection) props.onShowInspection('applicationNumber');
    };

    const handleIssueNumberPress = () => {
        if (props.onShowInspection) props.onShowInspection('issueNumber');
    };

    const secondaryStatusConst = taskdetails.overdueHours && taskdetails.overdueHours > 0 ? 'overdue' : undefined;
    const otherProps = { overdueHours: taskdetails.overdueHours };

    const taskTypeProps = {
        taskTypeConst: taskdetails.taskType && taskdetails.taskType.toLowerCase(),
        taskTypeNameE: taskdetails.taskTypeNameE,
        taskTypeNameA: taskdetails.taskTypeNameA,
    };
    const applicationNumberToShow = taskdetails.applicationNumber || taskdetails.createdApplicationNumber;
    let issueNumberToShow =
        taskTypeProps.taskTypeConst != 'incident' && taskTypeProps.taskTypeConst != 'ondemand' && taskdetails.workflowApplicationNumber;
    const incidentNumberToShow = taskTypeProps.taskTypeConst !== 'incident' ? null : taskdetails.workflowApplicationNumber;
    const onDemandNumberToShow = taskTypeProps.taskTypeConst !== 'ondemand' ? null : taskdetails.workflowApplicationNumber;
    return (
        <>
            <ScrollView style={{ flex: 1, marginHorizontal: 10 }} contentContainerStyle={styles2.scrollContainer}>
                <View style={{ flex: 1, flexDirection: 'column' }}>
                    <View>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText, commonStyles.generalTextXXS]}>
                            {moment(taskdetails.assignedDate).format(dateFormat)}
                        </Text>
                        <Text style={[commonStyles.generalText, commonStyles.generalTextMD]}>{localeProperty(taskdetails, 'title')}</Text>
                        <Text style={commonStyles.generalText}>{taskdetails.remarks}</Text>
                    </View>
                    <View style={commonStyles.line} />
                    <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('taskNumber')}</Text>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
                            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={[commonStyles.generalText]} textAlignVertical="center">
                                    {taskdetails.taskId}
                                </Text>
                            </View>
                            <TaskType {...taskTypeProps} />
                        </View>
                    </View>
                    <View style={commonStyles.line} />
                    <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('status')}</Text>
                        <StatusChip statusConst={taskdetails.taskStatusConst} translatedStatus={localeProperty(taskdetails, 'taskStatusName')} />
                        {secondaryStatusConst && <StatusChip statusConst={secondaryStatusConst} {...otherProps} />}
                    </View>
                    <View style={commonStyles.line} />
                    <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('inspectionType')}</Text>
                        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
                            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={[commonStyles.generalText]} textAlignVertical="center">
                                    {localeProperty(inspectionTypeDetail, 'title')}
                                </Text>
                            </View>
                            <View style={commonStyles.itemIconContainer}>
                                <Icon {...inspectionTypeIcon} size={commonStyles.itemIcon.fontSize} style={commonStyles.itemIcon} />
                            </View>
                        </View>
                    </View>
                    {applicationNumberToShow && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText, { marginTop: 7 }]}>
                                    {strings('applicationNumber')}
                                </Text>
                                <TouchableOpacity onPress={handleApplicationNumber} style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
                                    <Text style={[commonStyles.generalText, commonStyles.linkText, { marginTop: 7 }]}>{applicationNumberToShow}</Text>
                                    <View style={commonStyles.itemIconContainer}>
                                        <Icon
                                            type="MaterialCommunityIcons"
                                            name="magnify"
                                            size={commonStyles.itemIcon.fontSize}
                                            style={commonStyles.itemIcon}
                                        />
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </>
                    )}
                    {issueNumberToShow && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched, { alignItems: 'center' }]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText, { marginTop: 7 }]}>{strings('issueNumber')}</Text>
                                <TouchableOpacity onPress={handleIssueNumberPress} style={{ flexDirection: 'row', justifyContent: 'flex-end' }}>
                                    <Text style={[commonStyles.generalText, commonStyles.linkText, { marginTop: 7 }]}>{issueNumberToShow}</Text>
                                    <View style={commonStyles.itemIconContainer}>
                                        <Icon
                                            type="MaterialCommunityIcons"
                                            name="magnify"
                                            size={commonStyles.itemIcon.fontSize}
                                            style={commonStyles.itemIcon}
                                        />
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </>
                    )}
                    {incidentNumberToShow && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched, { alignItems: 'center' }]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText, { marginTop: 7 }]}>
                                    {localeProperty(taskdetails, 'taskTypeName')}
                                </Text>
                                <Text style={[commonStyles.generalText, { marginTop: 7 }]}>{incidentNumberToShow}</Text>
                            </View>
                        </>
                    )}
                    {onDemandNumberToShow && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched, { alignItems: 'center' }]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText, { marginTop: 7 }]}>{strings('requestforInfo')}</Text>
                                <Text style={[commonStyles.generalText, { marginTop: 7 }]}>{onDemandNumberToShow}</Text>
                            </View>
                        </>
                    )}
                    <View style={commonStyles.line} />
                    <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('dueBetween')}</Text>
                        <View style={{ flexDirection: 'row' }}>
                            <DateChip date={moment(taskdetails.expectedStartDate).format(dateFormat)} />
                            <Text style={{ marginHorizontal: 10 }}>&</Text>
                            <DateChip date={moment(taskdetails.expectedEndDate).format(dateFormat)} />
                        </View>
                    </View>
                    {taskdetails.actualStartDate && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('startedDate')}</Text>
                                <DateChip date={moment(taskdetails.actualStartDate).format(dateFormat)} />
                            </View>
                        </>
                    )}
                    {taskdetails.actualEndDate && (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched]}>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('completedDate')}</Text>
                                <DateChip date={moment(taskdetails.actualEndDate).format(dateFormat)} />
                            </View>
                        </>
                    )}
                    {props.taskdetails.attachments && props.taskdetails.attachments.length > 0 ? (
                        <>
                            <View style={commonStyles.line} />
                            <View style={[styles2.attachmentsContainer, { flexDirection: 'row' }]}>
                                <View style={[styles2.attachmentsContainer]}>
                                    <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('attachments')}</Text>
                                    <AttachmentListWithDialog
                                        editable={false}
                                        style={styles2.attachmentContainer}
                                        attachments={props.taskdetails.attachments}
                                    />
                                </View>
                            </View>
                        </>
                    ) : null}
                    <View style={commonStyles.line} />
                    <View style={{ justifyContent: 'flex-start', marginTop: 20 }}>
                        <Text style={[commonStyles.generalText, commonStyles.mutedText]}>{strings('address')}</Text>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <View style={{ justifyContent: 'flex-start', flexDirection: 'column' }}>
                                <Text style={commonStyles.generalText}>{formattedAddress}</Text>
                                <Text style={[commonStyles.generalText, commonStyles.mutedText, commonStyles.generalTextXXS]}>
                                    {coords
                                        ? strings('latitude') + ':' + coords.latitude + '  ' + strings('longitude') + ':' + coords.longitude
                                        : strings('latitudeAndLongitude')}
                                </Text>
                            </View>
                            <LocationAndGoogleMaps location={location} />
                        </View>
                    </View>
                    <View style={commonStyles.line} />
                </View>
            </ScrollView>
            <View style={[commonStyles.itemRow, commonStyles.itemRowStretched, { margin: 40 }]}>
                <Loader loading={false} spinnerStyle={{ marginBottom: 20 }}>
                    <IconButton
                        type="MaterialCommunityIcons"
                        name={'play-circle'}
                        borderRadius={25}
                        style={startButtonstyle}
                        onPress={props.onStartClick}
                        disabled={!canPerformTask}
                    >
                        <Text style={styles2.buttonText}>{strings('performTask')}</Text>
                    </IconButton>
                </Loader>
                {canRequestClose && (
                    <IconButton
                        type="MaterialCommunityIcons"
                        name={'close'}
                        borderRadius={25}
                        style={closeButtonStyle}
                        onPress={props.onShowSiteVisit}
                    >
                        <Text style={styles2.buttonText}>{strings('requestClose')}</Text>
                    </IconButton>
                )}
                <IconButton type="MaterialCommunityIcons" name="arrow-left" borderRadius={25} style={styles2.button} onPress={props.onBackClick}>
                    <Text style={styles2.buttonText}>{strings('back')}</Text>
                </IconButton>
            </View>
        </>
    );
};

export default Taskdetails;
