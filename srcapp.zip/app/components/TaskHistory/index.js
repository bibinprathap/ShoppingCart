import styles from './styles';
import TaskDetails from './TaskDetails';

export { styles, TaskDetails };
