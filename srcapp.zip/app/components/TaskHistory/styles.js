import EStyleSheet from 'react-native-extended-stylesheet';
import { I18nManager } from 'react-native';

export default EStyleSheet.create({
    container: {},
    historyItem: {
        flex: 1,
        marginVertical: 10,
        marginHorizontal: 5,
        paddingVertical: 10,
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
    },
    scrollContainer: {
        padding: 10,
    },
    touchWrapper: { flex: 1 },
    createdDate: { fontSize: '$primaryTextXXS', fontFamily: '$primaryFontNormal' },
    servicesTitle: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    refNumber: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    refNumbersmall: {
        fontSize: '$primaryTextXXS',
        fontFamily: '$primaryFontNormal',
        alignSelf: 'flex-start',
        textAlign: I18nManager.isRTL ? 'right' : 'left',
    },
    refNumbersmallTo: {},
    lableReadOnly: {
        fontSize: '$primaryTextXXS',
        fontFamily: '$primaryFontNormal',
        color: '$primaryMediumTextColor',
    },

    valueReadOnlyText: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        color: '$primaryDarkTextColor',
    },
    remarksContainer: {
        width: '100%',
        marginHorizontal: 10,
        minHeight: 35,
        alignItems: 'center',
    },
    summaryItem: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    button: {
        width: 200,
        height: 50,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 10,
    },
    buttonPositive: {
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonRequestClose: {
        backgroundColor: '$primaryDarkIconbuttonBackground',
    },
    buttonText: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        color: '$primaryWhite',
    },
    historyHeading: {
        marginHorizontal: 10,
        marginVertical: 10,
    },
    selectedSericesClip: {
        backgroundColor: '$primaryMediumTextColor',
        color: '$primaryLightTextColor',
        padding: 0,
        margin: 0,
    },
    attachmentContainer: {
        marginHorizontal: 10,
    },
    attachmentsContainer: {
        width: '100%',

        minHeight: 35,
        alignItems: 'center',
    },
    groupTitleWrapper: {
        backgroundColor: '$primaryLightBackground',
        borderRadius: 5,
        borderColor: '$primaryLightBorder',
        borderWidth: '$primaryBorderThin',
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 5,
        marginHorizontal: 2,
    },
    groupTitle: {
        flex: 1,
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
        fontFamily: '$primaryFontNormal',
    },
    buttonPositiveDisabled: {
        backgroundColor: '$primaryDisabledButtonBackground',
    },
});
