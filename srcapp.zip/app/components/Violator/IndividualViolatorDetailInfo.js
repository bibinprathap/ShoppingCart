import React from 'react';
import { View, Text, SafeAreaView, ScrollView, I18nManager } from 'react-native';
import { ViolatorIcon, ViolatorLabel } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import moment from 'moment';

export default function IndividualViolatorDetailInfo({ violator, onDetailLoaded }) {
    debugger;
    const { violatorType, detail, idNumber, registeredPhoneNumber, violatorPhoneNumber } = violator || {};
    const {
        identificationExpiryDate,
        moiUnifiedNumber,
        passportExpiryDate,
        passportIssueDate,
        passportIssuePlace,
        passportNumber,
        birthDate,
        birthPlace,
        maritalStatusConst,
        landLine,
        familyBookIssueDate,
        familyBookIssuePlace,
        familyBookNumber,
        familyPageNumber,
        familyBookCityConst,
        nonLocalNationalNumber,
        deathDate,
        gender,
        addressBuildingNumber,
        email,
        fax,
        pobox,
        website,
        familyName,
        familyStatus,
        familyNumber,
        workPhoneNumber,
        homePhoneNumber,
    } = detail;
    const getFormatedDate = date => {
        return date ? moment(date).format('LL') : '';
    };

    return (
        <SafeAreaView style={{ margin: 10 }}>
            <View style={styles.violatorContent}>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="idLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{idNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('identificationExpiryDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(identificationExpiryDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <ViolatorLabel key={violatorType} violatorType={violatorType} labelName="nationalityLabel" />
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'nationalityName')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('registeredPhoneNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{registeredPhoneNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('occupation')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'occupation')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('emirateName')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'emirateName')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyBookCity')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyBookCityConst}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyBookIssueDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(familyBookIssueDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyBookIssuePlace')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyBookIssuePlace}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyBookNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyBookNumber}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyPageNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyPageNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('moiUnifiedNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{moiUnifiedNumber}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('passportExpiryDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(passportExpiryDate)}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('passportIssueDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(passportIssueDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('passportIssuePlace')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{passportIssuePlace}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('passportNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{passportNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('nonLocalNationalNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{nonLocalNationalNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('birthDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(birthDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('birthPlace')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{birthPlace}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('deathDate')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{getFormatedDate(deathDate)}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('gender')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{gender == 1 ? strings('male') : strings('female')}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('maritalStatusConst')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{maritalStatusConst}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('address')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'address')}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('addressBuildingNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{addressBuildingNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('addressCity')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'addressCityName')}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('fax')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{fax}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('landLine')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{landLine}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('pobox')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{pobox}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('website')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{website}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('sponsorName')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'sponsorName')}</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyName')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyName}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('spouseName')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{localeProperty(violator.detail, 'spouseName')}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyStatus')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyStatus}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('familyNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{familyNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('workPhoneNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{workPhoneNumber}</Text>
                        </View>
                    </View>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('homePhoneNumber')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{homePhoneNumber}</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.otherDetailContainer}>
                    <View style={styles.otherDetailItem}>
                        <View style={styles.idLabel}>
                            <Text style={[styles.headingText, styles.mutedText]}>{strings('email')}</Text>
                        </View>
                        <View>
                            <Text style={styles.valueText}>{email}</Text>
                        </View>
                    </View>
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = EStyleSheet.create({
    rowContainer: {
        borderStyle: 'solid',
        borderBottomWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
        minHeight: 40,
    },
    rowContent: {
        flex: 1,
        flexDirection: 'row',
    },
    cellContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    containerrow: {
        flexDirection: 'row',
        alignContent: 'center',
        width: '100%',
        paddingHorizontal: 16,
        justifyContent: 'center',
    },
    cellTextBold: {
        fontWeight: 'bold',
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 200,
    },
    cellText: {
        flexWrap: 'wrap',
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
        padding: 5,
        width: 300,
    },
    violatorItem: {
        flexDirection: 'row',
        justifyContent: 'center',
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        borderRadius: 8,
        padding: 2,
    },
    icon: { margin: 5 },
    violatorContent: {
        flex: 1,
        flexDirection: 'column',
        padding: 10,
        //justifyContent: 'center',
    },
    titleAndIdContainer: {
        //flex: 1,
        flexDirection: 'row',
        marginBottom: 5,
    },
    titleContainer: {
        //flex: 1,
    },
    idContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    idLabel: { marginRight: 10 },
    otherDetailContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 6,
    },
    otherDetailItem: {
        flex: 1,

        alignItems: 'flex-start',
    },
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    titleText: {
        fontSize: '$primaryTextSM',
    },
    normalText: {
        fontSize: '$primaryTextSM',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
    valueText: {
        fontSize: '$primaryTextSM',
    },
    activeIcon: {
        color: '$primaryHeaderColor',
    },
});
