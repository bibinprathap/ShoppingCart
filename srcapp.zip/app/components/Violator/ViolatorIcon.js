import React from 'react';
import { Icon } from 'app/components';

export default props => {
    let iconName = '';
    const { violatorType, ...otherProps } = props;
    switch (violatorType) {
        case 'individual':
            iconName = 'face';
            break;
        case 'company':
            iconName = 'account-group';
            break;
        case 'plot':
            iconName = 'crop-landscape';
            break;
        case 'building':
            iconName = 'city';
            break;
        case 'vehicle':
            iconName = 'car';
            break;
    }

    if (!violatorType || !iconName) {
        return <Icon type="MaterialCommunityIcons" name="face" size={24} {...otherProps} />;
    }

    return <Icon type="MaterialCommunityIcons" name={iconName} size={24} {...otherProps} />;
};
