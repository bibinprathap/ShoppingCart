import React from 'react';
import { Text } from 'react-native-paper';
import EStyleSheet from 'react-native-extended-stylesheet';
import { strings } from 'app/config/i18n/i18n';

const violatorConf = {
    company: {
        iconName: 'account-group',
        titleLabel: 'company',
        idLabel: 'tradeLicenseNumber',
        nationalityLabel: 'country',
    },
    vehicle: {
        iconName: 'car',
        titleLabel: 'Vehicle',
        idLabel: 'plateNumber',
        nationalityLabel: 'country',
    },
    individual: {
        iconName: 'face',
        titleLabel: 'fullName',
        idLabel: 'emiratesId',
        nationalityLabel: 'nationality',
    },
    building: {
        iconName: 'home-city-outline',
        titleLabel: 'building',
        idLabel: 'buildingNumber',
        nationalityLabel: 'building',
    },
};

export default props => {
    const { violatorType, labelName } = props;
    let idLabel = violatorConf[violatorType][labelName];
    return <Text style={[styles.headingText, styles.mutedText]}>{strings(idLabel)}</Text>;
};

const styles = EStyleSheet.create({
    mutedText: {
        color: '$primaryMediumTextColor',
    },
    headingText: {
        fontSize: '$primaryTextXXS',
    },
});
