import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import alertsHelper from 'app/api/helperServices/alerts';
import { ViolatorSelectorDialog } from 'app/screens';
import { Icon } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import AppApi from 'app/api/real';
const api = new AppApi();

const sourceIcons = {
    MEPS: 'business',
    ELMS: 'map',
};

class ViolatorSelector extends Component {
    constructor(props) {
        super(props);
        this.state = {
            source: props.source,
            violators: props.violators,
            availableViolators: undefined,
        };
    }

    handleOnViolatorSelected = selectedViolator => {
        const { onViolatorSelected } = this.props;
        if (typeof onViolatorSelected === 'function') {
            onViolatorSelected(selectedViolator);
        }
    };

    selectSingle = async () => {
        let apiCall = undefined;
        const { source, location, onViolatorSelected, existingViolators, violatorType } = this.props;
        switch (source) {
            case 'MEPS':
                apiCall = () => api.getCustomerFromMEPS({ location, violatorType });
                break;
            case 'ELMS':
                apiCall = () => api.getCustomerFromELMS({ location, violatorType });
                break;
            case 'EXISTING':
                apiCall = () => {
                    if (existingViolators && existingViolators.length > 0) return existingViolators;
                    else return [];
                };
                break;
            default:
                throw `Unknown source [${source}] passed to ViolatorSelector`;
        }

        const blockingTaskOptions = {
            id: `getCustomerFrom${source}`,
            message: `Fetching violators from ${source}`,
            autoClose: true,
            autoRetry: false,
            maxTries: 1,
            runner: async (options, updateOptions) => {
                try {
                    return await apiCall();
                } catch (error) {
                    const newOptions = { ...options, maxTries: 1, autoClose: false, allowCancel: true };
                    updateOptions(newOptions);
                    throw `${getErrorMessageWithDetail(error)}`;
                }
            },
        };

        try {
            const result = await runBlockingTask(blockingTaskOptions);
            if (result && result.length > 0) {
                if (result && result.length == 1) {
                    this.handleOnViolatorSelected(result[0]);
                } else {
                    this.setState({ availableViolators: result, showDialog: true });
                }
            } else {
                //throw `Fetching violators from ${source}. ${getErrorMessageWithDetail(error)}`;
                alertsHelper.show('warn', 'No records found', `No records found in ${source}`);
            }
        } catch (error) {}
    };

    handleDialogOnRequestClose = selectedViolator => {
        this.setState({ showDialog: false });
        this.handleOnViolatorSelected(selectedViolator);
    };

    render() {
        const { source, showButton, renderButton } = this.props;
        const { showDialog, availableViolators } = this.state;
        const iconName = sourceIcons[source] || 'replay';
        let buttonContent = null;

        if (!!showButton) {
            if (typeof renderButton === 'function') {
                buttonContent = renderButton({ ...this.state });
            } else {
                const buttonTitle = source;
                //  strings('getFromSource', { source });
                buttonContent = (
                    <View style={styles.buttonsContainer}>
                        <TouchableOpacity style={{ flex: 1 }} onPress={this.selectSingle}>
                            <View style={styles.button}>
                                <Icon type="MaterialCommunityIcons" name={iconName} size={24} style={styles.buttonIcon} />
                                <Text style={styles.buttonText}>{buttonTitle}</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                );
            }
        }
        return (
            <>
                <ViolatorSelectorDialog
                    isShowing={showDialog}
                    availableViolators={availableViolators}
                    onRequestClose={this.handleDialogOnRequestClose}
                />
                {buttonContent}
            </>
        );
    }
}
export default ViolatorSelector;

const styles = EStyleSheet.create({
    buttonsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        //margin: 5,
        flex: 1,
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginHorizontal: 5,
        // width: 175,
        height: 50,
        borderRadius: 8,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryMediumTextColor',
        backgroundColor: '$primaryMediumBackground',
    },
    buttonText: {
        color: '$primaryMediumTextColor',
    },
    buttonIcon: {
        color: '$primaryMediumTextColor',
        marginEnd: 10,
    },
});
