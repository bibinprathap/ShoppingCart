import { createStackNavigator } from 'react-navigation-stack';
import { Login } from 'app/screens';

const AuthNavigator = createStackNavigator(
    {
        login: { screen: Login },
    },
    {
        headerMode: 'none',
    }
);

export default AuthNavigator;
