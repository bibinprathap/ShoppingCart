import { I18nManager } from 'react-native';
import { strings } from 'app/config/i18n/i18n';

/*main stack screens*/
import Dashboard from 'app/screens/main/Dashboard';
import Search from 'app/screens/main/Search';
import Notifications from 'app/screens/main/Notifications';
//import ScheduledWork from 'app/screens/main/ScheduledWork';
//import Settings from 'app/screens/main/Settings';
import Profile from 'app/screens/main/Profile';

/*inspection stack screen*/
import { ServiceSelection } from 'app/screens/inspection/ServiceSelection';
import { Checklist } from 'app/screens/inspection/Checklist';
import { ViolationDetails } from 'app/screens/inspection/ViolationDetails';
import { DuplicateCheckScreen } from 'app/screens/inspection/DuplicateCheckScreen';
import { Review } from 'app/screens/inspection/Review';

//import { IdScan } from 'app/screens/idScan';

const currentLocale = I18nManager.isRTL ? 'ar' : 'en';
/*
    when navigators are created, I18nManager.isRTL shows correct setting,
    but somehow I18n doesn't seem to be initialized, and it I18n.t returns wrong resource.
    so we force it to return the correct one by passing in the locale
*/
const appTitleTranslated = strings('appTitle', { locale: currentLocale });
export const mainStackDefinition = {
    routes: [
        {
            key: 'dashboard',
            screen: Dashboard, //IdScan
            title: appTitleTranslated,
            subtitle: strings('dashboard', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wf-1168' },
            displayInSideNav: false,
            displayInDrawer: true,
        },
        {
            key: 'tasks',
            screen: null,
            title: strings('tasks', { locale: currentLocale }),
            menuTitle: strings('tasksMenuTitle', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'script-text-outline' },
        },
        {
            key: 'history',
            screen: null,
            title: strings('history', { locale: currentLocale }),
            menuTitle: strings('historyMenuTitle', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'history' },
        },
        {
            key: 'inspectionPlan',
            screen: null,
            title: strings('inspectionPlan', { locale: currentLocale }),
            menuTitle: strings('inspectionPlanMenuTitle', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'map-clock-outline' },
        },
        {
            key: 'search',
            screen: Search,
            title: appTitleTranslated,
            subtitle: strings('search', { locale: currentLocale }),
            menuTitle: strings('searchMenuTitle', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'magnify' },
            displayInDrawer: true,
        },
        {
            key: 'notifications',
            screen: Notifications,
            title: strings('notifications', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'bell-outline' },
            displayInSideNav: false,
            displayInDrawer: true,
        },
        {
            key: 'settings',
            screen: null,
            title: strings('settings', { locale: currentLocale }),
            menuTitle: strings('settingsMenuTitle', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'cogs' },
        },
        {
            key: 'profile',
            screen: Profile,
            title: strings('profile', { locale: currentLocale }),
            icon: { type: 'MaterialCommunityIcons', name: 'face-outline' },
            displayInSideNav: false,
            displayInDrawer: true,
        },
        // {
        //     key: 'logout',
        //     screen: null,
        //     title: strings('logout', { locale: currentLocale }),
        //     menuTitle: strings('logoutMenuTitle', { locale: currentLocale }),
        //     icon: { type: 'MaterialCommunityIcons', name: 'logout' },
        //     displayInDrawer: true,
        // },
    ],
    initialRoute: 'dashboard',
};

export const inspectionStackDefinition = {
    routes: [
        {
            key: 'serviceSelection',
            screen: ServiceSelection,
            title: strings('serviceSelection', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wf-1045' },
        },
        {
            key: 'checklist',
            screen: Checklist,
            title: strings('performInspection', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wf-1000' },
        },
        {
            key: 'violationDetails',
            screen: ViolationDetails,
            title: strings('violations', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wg-1001' },
        },
        {
            key: 'duplicateCheck',
            screen: DuplicateCheckScreen,
            title: strings('confirmDuplicates', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wf-1073' },
        },
        {
            key: 'review',
            screen: Review,
            title: strings('review', { locale: currentLocale }),
            icon: { type: 'AdmIcon', name: 'wf-1182' },
        },
    ],
    initialRoute: 'serviceSelection',
};
