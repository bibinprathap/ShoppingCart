import React from 'react';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { InspectionNavigation } from 'app/components';

import { inspectionStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

inspectionStackDefinition.routes.map(item => {
    routeConfig[item.key] = {
        screen: item.screen,
        title: item.title,
        subtitle: item.subtitle,
        navigationOptions: ({ navigation }) => ({
            title: item.title,
            subtitle: item.subtitle,
        }),
    };
});

export const InspectionStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: inspectionStackDefinition.initialRoute,
    swipeEnabled: false,
    animationEnabled: true,
    lazy: true,
    tabBarPosition: 'bottom',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 750,
            easing: Easing.out(Easing.poly(4)),
            timing: Animated.timing,
            useNativeDriver: true,
        },
    }),

    defaultNavigationOptions: {
        tabBarComponent: props => <InspectionNavigation {...props} />,
    },
});

export default InspectionStackNavigator;
