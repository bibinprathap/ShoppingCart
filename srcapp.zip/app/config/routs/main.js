import React from 'react';
import { I18nManager } from 'react-native';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { widthPercentageToDP } from 'react-native-responsive-screen';
import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import { DrawerMenu } from 'app/screens';
import { Header } from 'app/components';
import { mainStackDefinition } from 'app/config/routs/defs';

const routeConfig = {};

mainStackDefinition.routes.map(item => {
    if (!!item.screen) {
        routeConfig[item.key] = {
            screen: item.screen,
            navigationOptions: ({ navigation }) => ({
                title: item.title,
                subtitle: item.subtitle,
            }),
        };
    }
});

export const MainStackNavigator = createMaterialTopTabNavigator(routeConfig, {
    initialRouteName: 'dashboard',
    swipeEnabled: false,
    animationEnabled: true,
    lazy: true,
    tabBarPosition: 'top',
    transitionConfig: () => ({
        transitionSpec: {
            duration: 750,
            easing: Easing.out(Easing.poly(4)),
            timing: Animated.timing,
            useNativeDriver: true,
        },
    }),
    defaultNavigationOptions: {
        tabBarComponent: props => <Header {...props} />,
    },
});

// create and configure drawer parent navigator for main app
const AppNavigator = createDrawerNavigator(
    {
        Home: { screen: MainStackNavigator },
    },
    {
        contentComponent: DrawerMenu,
        drawerWidth: widthPercentageToDP('40%'),
        initialRouteName: 'Home',
        drawerPosition: I18nManager.isRTL ? 'right' : 'left',
    }
);

//export default createAppContainer(MainStackNavigator);
//export default createAppContainer(AppNavigator);
export default AppNavigator;
