import React from 'react';
import { StatusBar, BackHandler } from 'react-native';
import { Provider } from 'react-redux';
import moment from 'moment';
import configureStore from './config/store';
import { Provider as PaperProvider } from 'react-native-paper';
import { setGlobalHandler } from './config/globalExceptionHandler';
import SwitchNavigator from './config/routs';
import { setLocale } from './config/i18n/i18n';
import { setDeeplink } from './actions/settings';
import { addNotification, updateFCMToken, fcmInitialize, markNotificationAsRead } from './actions/notifications';
import { appStateChange } from './actions/tracking';
import { theme } from './styles';
import DropdownAlert from 'react-native-dropdownalert';
import alertsHelper from 'app/api/helperServices/alerts';
import firebase from 'app/api/helperServices/rnFirebaseNative';
import { inspectionsHelper, printHelper } from 'app/api/helperServices';
import { _ } from 'lodash';
import NetInfo from '@react-native-community/netinfo';
import { startBackgroundLocationTracking, stopBackgroundLocationTracking, cancelAllBackgroundJobs } from 'app/api/helperServices/geolocation';
import { attachmentsHelper } from 'app/api/helperServices';
//import notificationsHelper from 'app/api/helperServices/notifications';

import SplashScreen from 'react-native-splash-screen';
import { View, Text, YellowBox, Linking, Platform, AppState } from 'react-native';

import { RNFileUploader, deeplinkHelper, RNVideoRecord } from 'app/api/helperServices';
import envConfig from 'app/api/config';
import { _state, store } from 'app/config/store';

import AppApi from 'app/api/real';
import { locationEvent, updateLocationEvent, geoUpdateEvent } from 'app/actions/tracking';
import Loader from './Loader';
import { InspectionDialog } from 'app/screens';
import { inspectionAddLogs, saveNewInspection, inspectionUpdate } from 'app/actions/inspections';
import { authCancel } from 'app/actions/auth';
import { setLoaded } from 'app/actions/loader';
import { hideInspectionDialog } from 'app/actions/inspectionDialog';
import { uploadedImageAttachment, uploadErrorImageAttachment } from 'app/actions/attachments';
import environments from 'app/api/config';
import { inspectionsTabClearAll, tasksTabClearAll, tasksSetPendingRefresh, tasksTabLoad } from './actions/generic';
import { updateSettings } from 'app/actions/settings';
const api = new AppApi();

//import { ScrollView, View, Text } from 'react-native';
const env = envConfig;

let _globalStore = undefined;
let uploaderListener = undefined;
setGlobalHandler();

let storeHydrationResult = configureStore(() => {
    _globalStore = storeHydrationResult.store; //storeHydrationTimer will pick up this value and proceed to rendering the <App/> first time
    _globalStore.dispatch(appStateChange('unknown'));
    _globalStore.dispatch(inspectionUpdate({ prop: 'creatingFlag', value: false }));
    //Appp will be set to active when root react component updated after store hydration,
    //otherwise, in background job case when application had been terminated, the appState will remain 'terminated'
    startBackgroundLocationTracking();

    const store = _globalStore;
    if (!store) return null;
    const storedState = store.getState();
    const { settings } = storedState;

    attachmentsHelper.checkUploadIdInSharedPreferences().then(() => {});
    const selectedEnvConfig = environments[settings.environment];

    RNVideoRecord.setConfiguration(
        settings.maxVideoDuration,
        settings.maxfilesize,
        settings.allowVideoRecording,
        settings.photoResolution,
        settings.camSettingsButton,
        settings.enableImageCrop
    );
    RNFileUploader.setTriggerIntervalCount(
        settings.triggerInterval,
        selectedEnvConfig.baseURL + '/MIMSPublic/DeviceLogging',
        settings.soundDecibelGraphInterval
    );
    uploaderListener = RNFileUploader.addListener('progress', '', data => {
        const newstoredState = store.getState();
        const newEnvironment = newstoredState.settings.environment;
        //if (data.geofencing) alertsHelper.show('warn', 'Geofencing', data);

        //this.handleProgress(+data.progress);

        // this will be executed every 15 minit
        // even when app is the the background
        const { settings, auth } = _state;
        let useruuid = null;
        let authCodetemp = null;
        if (auth) {
            const { userData, authCode } = auth;
            if (userData) {
                useruuid = userData.uuid;
                authCodetemp = authCode;
            }
        }
        console.log('uploadfailedtest', data);
        if (data.triggername && data.triggername == 'locationChange') {
            if (_state && _state.inspections && _state.inspections.history) {
                Object.getOwnPropertyNames(_state.inspections.history).map(ins => {
                    const inspection = _state.inspections.history[ins];
                    if (!inspection.saved && inspection.locallySaved && !inspectionsHelper.getPendingAttachementList(inspection.inspection)) {
                        store && store.dispatch(saveNewInspection(inspection.inspection));
                    }
                });
            }

            store && store.dispatch(geoUpdateEvent(data.geoCheck));

            const { settings, auth } = _state;
            //delete upload
            attachmentsHelper.checkUploadIdInSharedPreferences(useruuid).then(() => {
                const pendingUploads = attachmentsHelper.getPendingUploadAttachement(env);
                _.map(pendingUploads, p => {
                    if (p.mobileReferenceNumber) RNFileUploader.cancelUpload(p.mobileReferenceNumber);

                    if (useruuid) attachmentsHelper.startUpload(p, newEnvironment, authCodetemp, useruuid, 'InspectionPhoto');
                });
            });
            console.log('locationChange', data);
            const appState = data.appState || 'Unknown';
            const newdata = {
                appState: appState,
                userId: _state && _state.auth && _state.auth.activeProfileUserId,
                deviceInfo: {
                    deviceId: data.deviceId,
                    deviceUniqueId: data.uniqueId,
                    serialNumber: data.serialNumber,
                    phoneNumber: data.phoneNumber,
                    osName: data.systemName,
                    osVersion: data.systemVersion,
                    carrier: data.carrier,
                    batteryLevel: data.batteryLevel,
                    ipAddress: data.ipAddress,
                    latitude: data.latitude,
                    longitude: data.longitude,
                    //geoCheck: data.geoCheck,
                },
            };

            store && store.dispatch(locationEvent(newdata));
        } else if (data.triggername && data.triggername == 'checkpointEvent') {
            console.log('checkpointEvent', data);

            let ids = data.ids;
            ids = ids.replace(/[\])}[{(]/g, '');
            const idarray = ids.split(',');
            console.log('checkPointEvent', idarray);
        }
        // else if (data.currentLocation && data.currentLocation == 'Locationevery15minit') {
        //     const appState = (_state && _state.tracking && _state.tracking.appState) || 'terminated';
        //     const newdata = {
        //         appState: appState,
        //         userId: _state && _state.auth && _state.auth.activeProfileUserId,
        //         deviceInfo: {
        //             deviceId: data.deviceId,
        //             deviceUniqueId: data.uniqueId,
        //             serialNumber: data.serialNumber,
        //             phoneNumber: data.phoneNumber,
        //             osName: data.systemName,
        //             osVersion: data.systemVersion,
        //             carrier: data.carrier,
        //             batteryLevel: data.batteryLevel,
        //             ipAddress: data.ipAddress,
        //             //geoCheck: data.geoCheck,
        //         },
        //     };

        //     store && store.dispatch(locationEvent(newdata));
        //     store && store.dispatch(geoUpdateEvent(data.geoCheck));
        // } else if (data.PeriodicLocationUpdates && data.PeriodicLocationUpdates == 'PeriodicLocationUpdates') {
        //     const location = {
        //         time: data.timestamp,
        //         latitude: data.latitude,
        //         longitude: data.longitude,
        //         altitude: data.altitude,
        //         accuracy: data.accuracy,
        //         heading: data.heading,
        //         speed: data.speed,
        //         //geoCheck: data.geoCheck,
        //     };

        //     store && store.dispatch(updateLocationEvent(location));
        //     store && store.dispatch(geoUpdateEvent(data.geoCheck));
        // }
        else if (data.responseCode && data.responseCode == 200) {
            //RNFileUploader.getString('CompletedUploadIds').then(completeduploadids => {

            //   if (completeduploadids.indexOf(uploadId) > -1)
            //    RNFileUploader.setString('CompletedUploadIds', completeduploadids.replace(uploadId, '').trim());
            //  RNFileUploader.getString(uploadId).then(responce => {

            //   if (completeduploadids.indexOf(uploadId) > -1)
            //    RNFileUploader.setString('CompletedUploadIds', completeduploadids.replace(uploadId, '').trim());
            //  });
            //   });
            const envConfigtemp = env[newEnvironment];
            const result = JSON.parse(data.responseBody).result;
            const path = `${envConfigtemp.baseURL}/Inspection/Download?MIMSDocumentId=${data.mobileReferenceNumber}&DocumentId=${result.documentId}`;

            // if (envConfigtemp.baseURL.indexOf('https://') > -1 && path.indexOf('https://') == -1) {
            //     path = path.replace('http://', 'https://');
            // }
            store &&
                store.dispatch(
                    uploadedImageAttachment({
                        mobileReferenceNumber: data.mobileReferenceNumber,
                        uploading: false,
                        uploaded: true,
                        createdDate: new Date(),
                        createdBy: useruuid,
                        uploadedDate: new Date(),
                        fileName: data.mobileReferenceNumber,
                        path: path,
                        deleteToken: result.deleteToken,
                        documentId: result.documentId,
                    })
                );
            const currentDoc = _state.attachments.pendingUploadDocs[data.mobileReferenceNumber];
            if (currentDoc) {
                const inspection = _state.inspections.history[currentDoc.refNumber];
                if (inspection) {
                    if (!inspection.saved && inspection.locallySaved && !inspectionsHelper.getPendingAttachementList(inspection.inspection)) {
                        store && store.dispatch(saveNewInspection(inspection.inspection));
                    }
                }
            }

            store &&
                store.dispatch(
                    inspectionAddLogs({
                        documentid: data.mobileReferenceNumber,
                        inspectionId: data.mobileReferenceNumber,
                        date: new Date(),
                        message: 'Uploaded Successfully',
                        success: true,
                    })
                );
        } else if (data.error || (data.responseCode && data.responseCode != 200)) {
            store &&
                store.dispatch(
                    uploadErrorImageAttachment({
                        mobileReferenceNumber: data.mobileReferenceNumber,
                        uploading: false,
                        uploaded: false,
                        error: true,
                        uploadedDate: new Date(),
                        fileName: data.mobileReferenceNumber,
                    })
                );
            //  .then(this.setselectedAttachment);

            store &&
                store.dispatch(
                    inspectionAddLogs({
                        documentid: data.mobileReferenceNumber,
                        date: new Date(),
                        inspectionId: data.mobileReferenceNumber,
                        message: 'Error While Uploading',
                        success: false,
                    })
                );

            // RNFileUploader.getString('FailedUploadIds').then(failedUploadIds => {
            // if (failedUploadIds.indexOf(uploadId) > -1)
            // RNFileUploader.setString('FailedUploadIds', failedUploadIds.replace(uploadId, '').trim());
            // });
        } else if (data.cancelled) {
            // const pendingUploads = attachmentsHelper.getUploadingAttachement();
            // if (pendingUploads.length == 0) this.uploaderListener.remove();
            store &&
                store.dispatch(
                    uploadErrorImageAttachment({
                        mobileReferenceNumber: data.mobileReferenceNumber,
                        uploading: false,
                        uploaded: false,
                        error: data.cancelled,
                        uploadedDate: new Date(),
                        fileName: data.mobileReferenceNumber,
                    })
                );
            store &&
                store.dispatch(
                    inspectionAddLogs({
                        documentid: data.mobileReferenceNumber,
                        date: new Date(),
                        message: 'Upload Cancelled',
                        success: true,
                    })
                );
            // RNFileUploader.getString('CancelledUploadIds').then(cancelleduploadids => {
            //  if (cancelleduploadids.indexOf(uploadId) > -1)
            //  RNFileUploader.setString('CancelledUploadIds', cancelleduploadids.replace(uploadId, '').trim());
            // });
        }
    });

    //cancelAllBackgroundJobs();
});

class App extends React.Component {
    constructor(props) {
        super(props);
        this.handleBackPress = this.handleBackPress.bind(this);

        //Todo: remove it soon... how soon?
        YellowBox.ignoreWarnings([
            'Warning:',
            // 'Warning: componentWillMount is deprecated',
            // 'Warning: componentWillReceiveProps is deprecated',
            // 'Warning: componentWillUpdate is deprecated',
        ]);

        this.state = {
            isStoreHydrated: false,
            appStateInitialized: false,
        };

        this.storeHydrationTimer = setInterval(() => {
            if (_globalStore) {
                clearInterval(this.storeHydrationTimer);
                if (_state) {
                    _globalStore.dispatch(setLoaded({ result: undefined, options: undefined })); //Todo: set error - cancelled state
                    _globalStore.dispatch(hideInspectionDialog());
                }
                if (_state && _state.auth && _state.auth.loggingIn) {
                    _globalStore.dispatch(authCancel());
                }
                this.setState({ isStoreHydrated: true, store: _globalStore }, () => this.getRegistrationToken());
            } else {
            }
        }, 200);
    }

    handleAppStateChange = nextAppState => {
        this.setState({ appState: nextAppState });
        const { store } = this.state;
        if (store) {
            store.dispatch(appStateChange(nextAppState));
        }
    };

    componentDidUpdate() {
        if (!this.state.appStateInitialized && this.state.isStoreHydrated) {
            this.setState({ appStateInitialized: true }, () => {
                this.state.store.dispatch(appStateChange(AppState.currentState));

                this.getInitialNotification();
                if (Platform.OS === 'android') {
                    Linking.getInitialURL().then(deeplink => {
                        this.handleLinks({ url: deeplink });
                    });
                }

                // TEST deeplink command:  adb shell am start -W -a android.intent.action.VIEW -d "adm://mims/search" com.mims
                Linking.addEventListener('url', this.handleLinks);
                this.notificationsListner = firebase.addListener(this.handleNotifications);
                let lastValue = null;
                this.networkStatusUnsubscribe = NetInfo.addEventListener(state => {
                    if (lastValue === state.isInternetReachable) return;
                    lastValue = state.isInternetReachable;
                    store.dispatch(updateSettings({ isInternetReachable: state.isInternetReachable }));
                });
            });
        }
    }

    componentDidMount() {
        // BackgroundJob.cancelAll();

        AppState.addEventListener('change', this.handleAppStateChange);

        this.backHandler = BackHandler.addEventListener('hardwareBackPress', this.handleBackPress);
    }

    componentWillUnmount() {
        AppState.removeEventListener('change', this.handleAppStateChange);
        Linking.removeEventListener('url', this.handleLinks);
        if (this.splashTimer) {
            clearTimeout(this.splashTimer);
        }
        if (this.deeplinkTimer) {
            clearTimeout(this.deeplinkTimer);
        }
        if (this.notificationsListner) this.notificationsListner.remove();

        printHelper.removeListener();
        this.backHandler.remove();

        if (this.networkStatusUnsubscribe) this.networkStatusUnsubscribe();
    }

    getCurrentRoute = state => {
        const findCurrentRoute = navState => {
            if (navState.index !== undefined) {
                return findCurrentRoute(navState.routes[navState.index]);
            }
            return navState.routeName;
        };
        return findCurrentRoute(state.nav);
    };

    handleBackPress = () => {
        if (this.navigatorRef) {
            const routeName = this.getCurrentRoute(this.navigatorRef.state);
            if (routeName === 'serviceSelection') {
                return this.navigatorRef._navigation.navigate('dashboard');
            }
        }
        //return true;
    };

    deeplinkTimer;
    splashTimer;
    navigatorRef;
    notificationsListner;

    getRegistrationToken = () => {
        const { store } = this.state;
        if (store) {
            store.dispatch(fcmInitialize());
        }
        //firebase.subscribeToTopic('testTopic');
    };

    getInitialNotification = () => {
        const { store } = this.state;
        const storedState = store.getState();
        firebase.getInitialNotification((error, notification) => {
            const { notifications } = storedState;
            if (notification) {
                const messageId = notification['google.message_id'] || notification.message_id;
                if (messageId && typeof notifications[messageId] === 'undefined') {
                    store.dispatch(addNotification(notification));
                    this.refreshTasks(notification, store);
                }

                if (
                    notification.data &&
                    notification.data.deeplink &&
                    (typeof notifications[messageId] === 'undefined' || (notifications[messageId] && !notifications[messageId].readAt))
                ) {
                    this.handleLinks(notification);
                    store.dispatch(markNotificationAsRead(messageId));
                }

                notifications[messageId] && !notifications[messageId].readAt;
            }
        });
    };

    refreshTasks = (notification, store) => {
        try {
            const taskId = deeplinkHelper.getTaskId(notification);
            if (!taskId) return;
            const storedState = store.getState();
            const { selectedTab, tabs } = storedState.generic.tasksTabs;
            let selectedTabKey = 'later';
            Object.getOwnPropertyNames(tabs).map(t => {
                const tab = tabs[t];
                if (tab.items) {
                    const foundTask = _.find(tab.items, item => item.taskId == taskId);
                    if (foundTask) selectedTabKey = t;
                }
            });
            if (selectedTab == selectedTabKey) {
                const payload = {
                    tabKey: selectedTabKey,
                    startDate: tabs[selectedTabKey].startDate,
                    endDate: tabs[selectedTabKey].endDate,
                    reset: true,
                    isOrderByDesc: tabs[selectedTabKey].isOrderByDesc,
                };
                store.dispatch(tasksTabLoad(payload));
            } else {
                store.dispatch(tasksSetPendingRefresh({ tabKey: selectedTabKey, hasPendingRefresh: true }));
            }
        } catch (ex) {}
    };

    handleNotifications = notification => {
        const { store } = this.state;
        if (store) {
            switch (notification.type) {
                case 'NOTIFICATION':
                    store.dispatch(addNotification(notification.data));
                    this.refreshTasks(notification.data, store);
                    break;
                case 'FCM_NEW_TOKEN':
                    store.dispatch(updateFCMToken(notification.data));
                    break;
                default:
                    break;
            }
        }
    };

    handleLinks = event => {
        if (event.data && event.data.deeplink) {
            this.deeplinkTimer = setTimeout(() => {
                const { store } = this.state;
                const storedState = store.getState();
                const { auth } = storedState;
                const loggedIn = (auth && auth.loggedIn) || false;
                if (this.navigatorRef) {
                    store.dispatch(setDeeplink({ deeplink: event.data.deeplink }));
                    deeplinkHelper.handleLink({ deeplink: event.data.deeplink, loggedIn, dispatch: store.dispatch, navigation: this.navigatorRef });
                }
            }, 1000);
        }
    };

    render() {
        if (this.state.isStoreHydrated) {
            const { store } = this.state;
            const defaultLocale = 'en-US';
            const storedState = store.getState();
            if (!!storedState && !!storedState.settings && !!storedState.settings.locale) {
                setLocale(storedState.settings.locale);
            } else {
                setLocale(defaultLocale);
            }
            //first handle the language settings in the stored state, if any.
            //it may restart the app if current languange is different from the stored one.

            this.splashTimer = setTimeout(() => {
                SplashScreen.hide();
            }, 300);
            return (
                <Provider store={store}>
                    <PaperProvider theme={theme}>
                        <SwitchNavigator
                            ref={navigatorRef => {
                                if (navigatorRef) {
                                    this.navigatorRef = navigatorRef;
                                }
                            }}
                        />
                        <Loader />
                        <InspectionDialog />
                        <DropdownAlert
                            replaceEnabled={false}
                            closeInterval={6000}
                            defaultContainer={{ padding: 8, paddingTop: StatusBar.currentHeight, flexDirection: 'row' }}
                            ref={ref => alertsHelper.setAlertProvider(ref)}
                            showCancel={true}
                            onClose={() => alertsHelper.invokeOnClose()}
                        />
                    </PaperProvider>
                </Provider>
            );
        } else return null;
    }
}

export default App;

/*
    //without redux-persist use below code

    //export default () => <Provider store={store}><MainStackNavigator /></Provider>

    export default () => <Provider store={store}><SwitchNavigator /></Provider>

    // export default () => {
    //     return (
    //         <PaperProvider>
    //             <AuthNavigator />
    //         </PaperProvider>
    //     );
    // }

    //export default () => <AlertProvider><Navigator /></AlertProvider>
*/
