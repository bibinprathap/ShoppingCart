import update, { extend } from 'immutability-helper';
import {
    ATTACHMENTS_UNLOAD_ALL,
    ATTACHMENT_ADD_IMAGE,
    ATTACHMENT_REMOVE_IMAGE,
    ATTACHMENT_ADD_AUDIO,
    ATTACHMENT_ADD_VIDEO,
    ATTACHMENT_ADD_PDF,
    ATTACHMENT_STARTED_UPLOADING,
    ATTACHMENT_UPLOADED,
    ATTACHMENT_UPLOAD_ERROR,
} from 'app/actions/attachments';
import { INSPECTION_CLEARHISTORY } from 'app/actions/inspections';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';

import { _ } from 'lodash';

const initialState = {
    hasPendingUploads: false,
    hasPendingDownloads: false,
    uploading: false,
    downloading: false,
    envState: {},
    pendingUploadDocs: {},
};

const getDoc = (state, mobileReferenceNumber) => {
    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        return state.pendingUploadDocs[mobileReferenceNumber];
    }
    return {};
};

const addDoc = (state, payload) => {
    return {
        ...state,
        hasPendingUploads: true,
        pendingUploadDocs: { ...state.pendingUploadDocs, [payload.mobileReferenceNumber]: payload },
    };
};

const addOrUpdateDoc = (state, payload) => {
    if (!payload) return state;
    const { mobileReferenceNumber } = payload || {};
    if (!mobileReferenceNumber) throw 'To add an attachment, payload must have an Id';

    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        return { ...state, hasPendingUploads: true, pendingUploadDocs: { ...state.pendingUploadDocs, [mobileReferenceNumber]: payload } };
    }
    return addDoc(state, payload);
};

const updateDoc = (state, payload) => {
    if (!payload) return state;
    const { mobileReferenceNumber } = payload || {};
    if (!mobileReferenceNumber) throw 'To update an attachment, payload must have an Id';
    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        return update(state, {
            hasPendingUploads: { $set: true },
            pendingUploadDocs: {
                [mobileReferenceNumber]: {
                    fileName: { $set: payload.uploadId },
                    createdBy: { $set: payload.createdBy },
                    inspInstanceId: { $set: payload.inspInstanceId },
                    uploading: { $set: payload.uploading },
                    error: { $set: null },
                    uploadedDate: { $set: payload.uploadedDate },
                    uploaded: { $set: false },
                },
            },
        });
    }
    return state;
};

const uploadSuccess = (state, payload) => {
    if (!payload) return state;
    const { mobileReferenceNumber } = payload || {};
    if (!mobileReferenceNumber) throw 'To complete update an attachment, payload must have an Id';

    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        let { [mobileReferenceNumber]: uploadedDoc, ...pendingUploadDocs } = state.pendingUploadDocs;
        return update(removeDoc(state, payload), {
            hasPendingUploads: { $set: false },
            pendingUploadDocs: { $set: pendingUploadDocs },
        });
    }
    return state;
};

const updateErrorDoc = (state, payload) => {
    if (!payload) return state;
    const { mobileReferenceNumber } = payload || {};
    if (!mobileReferenceNumber) throw 'To complete update an attachment, payload must have an Id';

    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        return update(state, {
            hasPendingUploads: { $set: true },
            pendingUploadDocs: {
                [mobileReferenceNumber]: {
                    error: { $set: payload.error },
                    uploading: { $set: false },
                    uploaded: { $set: false },
                    uploadedDate: { $set: payload.uploadedDate },
                },
            },
        });
    }

    return state;
};

const removeDoc = (state, payload) => {
    if (!payload) return state;
    const { mobileReferenceNumber } = payload || {};
    if (!mobileReferenceNumber) throw 'To remove an attachment, payload must have an Id';

    if (state && state.pendingUploadDocs && state.pendingUploadDocs.hasOwnProperty(mobileReferenceNumber)) {
        if (Object.keys(state.pendingUploadDocs).length === 1) {
            return { ...state, hasPendingUploads: false, pendingUploadDocs: {} };
        }
        let { [mobileReferenceNumber]: removedDoc, ...pendingUploadDocs } = state.pendingUploadDocs;
        return { ...state, hasPendingUploads: false, pendingUploadDocs };
    }

    return state;
};

const reducer = (state = initialState, action) => {
    let newState = undefined;
    switch (action.type) {
        case INSPECTION_CLEARHISTORY:
            //Todo: keep the attachments that are not uploaded yet, for the inspections that are in history
            //for now just remove all
            return initialState;
        case ATTACHMENTS_UNLOAD_ALL:
            return initialState;
        case ATTACHMENT_ADD_IMAGE:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_REMOVE_IMAGE:
            newState = removeDoc(state, action.payload);
            return newState;
        case ATTACHMENT_STARTED_UPLOADING:
            newState = updateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_UPLOADED:
            newState = uploadSuccess(state, action.payload);
            return newState;
        case ATTACHMENT_UPLOAD_ERROR:
            newState = updateErrorDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_AUDIO:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_VIDEO:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case ATTACHMENT_ADD_PDF:
            newState = addOrUpdateDoc(state, action.payload);
            return newState;
        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = { ...state, envState: {} };
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: backupState };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        default:
            return state;
    }
};

export default reducer;
