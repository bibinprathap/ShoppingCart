import update, { extend } from 'immutability-helper';
import moment from 'moment';
import { _ } from 'lodash';
import { getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import {
    LOG_API_ERRORS,
    LOG_JS_ERRORS,
    LOG_CLEAR,
    LOG_LIMIT,
    LOG_LEVEL,
    DASHBOARD_CHART_LOADING,
    DASHBOARD_CHART_SUCCESS,
    DASHBOARD_CHART_FAILURE,
    DASHBOARD_CHART_CLEARALL,
    GET_LIST,
    GET_LIST_SUCCESS,
    GET_LIST_FAILURE,
    RESET_LISTS,
    SET_PREFERENCE,
    SET_STATUS,
    DASHBOARD_INSPECTIONS_TAB_CLEARALL,
    DASHBOARD_INSPECTIONS_TAB_CHANGED,
    DASHBOARD_INSPECTIONS_TAB_LOADING,
    DASHBOARD_INSPECTIONS_TAB_SUCCESS,
    DASHBOARD_INSPECTIONS_TAB_FAILURE,
    DASHBOARD_TASKS_TAB_CLEARALL,
    DASHBOARD_TASKS_TAB_CHANGED,
    DASHBOARD_TASKS_TAB_LOADING,
    DASHBOARD_TASKS_TAB_SUCCESS,
    DASHBOARD_TASKS_TAB_FAILURE,
    DASHBOARD_INSPECTIONS_CAL_SUCCESS,
    DASHBOARD_INSPECTIONS_CAL_FAILURE,
    DASHBOARD_INSPECTIONS_CAL_LOADING,
    DASHBOARD_INSPECTIONS_CAL_CLEARALL,
    DASHBOARD_TASK_CAL_SUCCESS,
    DASHBOARD_TASK_CAL_FAILURE,
    DASHBOARD_TASK_CAL_LOADING,
    DASHBOARD_TASK_CAL_CLEARALL,
    DASHBOARD_TASKS_SET_PENDING_REFRESH,
    defaultPageSize,
} from 'app/actions/generic';

const initialState = {
    dashboardChart: { data: [] },
    form: {},
    logs: { apiErrors: [], jsErrors: [], apiErrorsLimit: 25, jsErrorsLimit: 25, logLevel: 'error' },
    preference: { inspectionSideNavigation: false, mapInitialized: false },
    status: { isPrinting: false },
};

const getDateVariables = () => {
    return {
        smallestDate: moment('2000-01-01'),
        largestDate: moment('2999-12-31'),
        today: moment(),
        yesterday: moment().subtract(1, 'day'),
        older: moment().subtract(2, 'day'),
        tomorrow: moment().add(1, 'day'),
        later: moment().add(2, 'day'),
        minDate: moment().subtract(3, 'month'),
        maxDate: moment().add(3, 'month'),
    };
};

const initializeChart = () => {
    return {
        data: [],
    };
};

const initializeInspectionsTaskCalList = () => {
    const dateVariables = getDateVariables();
    return {
        lastRefreshed: undefined,
        startDate: dateVariables.today.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
        endDate: dateVariables.maxDate.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
    };
};

const initializeInspectionsCalList = () => {
    const dateVariables = getDateVariables();
    return {
        lastRefreshed: undefined,
        startDate: dateVariables.minDate.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
        endDate: dateVariables.today.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
    };
};

const initializeInspectionsTabbedList = () => {
    const dateVariables = getDateVariables();
    return {
        selectedTab: 'today',
        tabs: {
            today: {
                lastRefreshed: undefined,
                isOrderByDesc: true,
                startDate: dateVariables.today.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.today.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                order: 1,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
            yesterday: {
                lastRefreshed: undefined,
                isOrderByDesc: true,
                startDate: dateVariables.yesterday.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.yesterday.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                order: 2,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
            older: {
                lastRefreshed: undefined,
                isOrderByDesc: true,
                startDate: dateVariables.minDate.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.yesterday
                    .subtract(1, 'second')
                    .endOf('day')
                    .format('YYYY-MM-DD HH:mm:ss'),
                order: 3,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
        },
    };
};

const initializeTasksTabbedList = () => {
    const dateVariables = getDateVariables();
    return {
        selectedTab: 'today',
        tabs: {
            overdue: {
                hasPendingRefresh: false,
                lastRefreshed: undefined,
                isOrderByDesc: false,
                startDate: dateVariables.smallestDate.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.largestDate.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                fixedFilter: { isOverdue: true },
                order: 1,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
            today: {
                hasPendingRefresh: false,
                lastRefreshed: undefined,
                isOrderByDesc: false,
                startDate: dateVariables.today.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.today.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                order: 2,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
            tomorrow: {
                hasPendingRefresh: false,
                lastRefreshed: undefined,
                isOrderByDesc: false,
                startDate: dateVariables.tomorrow.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.tomorrow.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                order: 3,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
            later: {
                hasPendingRefresh: false,
                lastRefreshed: undefined,
                isOrderByDesc: false,
                startDate: dateVariables.later.startOf('day').format('YYYY-MM-DD HH:mm:ss'),
                endDate: dateVariables.maxDate.endOf('day').format('YYYY-MM-DD HH:mm:ss'),
                order: 4,
                pageSize: defaultPageSize,
                pageNumber: 0,
                totalCount: 0,
            },
        },
    };
};

const parseChartAction = (action, currentData = []) => {
    const newData = action.result;
    const loading = typeof newData === 'undefined';
    const isRootChart = typeof action.chartConst === 'undefined';
    let mergedData;
    if (isRootChart) mergedData = newData || [];
    else {
        mergedData = currentData;
        // if (newData) {
        //     mergedData.push(newData);
        // }
    }
    let rootChartLoading = isRootChart ? loading : false;
    let chartIndex = -1;
    if (!isRootChart) {
        chartIndex = _.findIndex(mergedData, { constant: action.chartConst });

        if (newData) {
            if (chartIndex == -1) {
                mergedData.push(newData);
                chartIndex = mergedData.length;
            } else {
                mergedData[chartIndex] = newData;
            }
        }
    }
    const formattedDate = moment().format('YYYY-MM-DD HH:mm:ss');
    if (!isRootChart && mergedData.length > 0) {
        mergedData[chartIndex].loading = loading;
        mergedData[chartIndex].lastRefreshed = formattedDate;
    }
    if (isRootChart && mergedData.length > 0) {
        for (var i = 0; i < mergedData.length; i++) {
            mergedData[i].lastRefreshed = formattedDate;
        }
    }
    return { data: mergedData, loading: rootChartLoading, lastRefreshed: formattedDate, chartRefreshing: loading };
};

const getDashboardTabState = ({ state, payload, loading }) => {
    const formattedDate = moment().format('YYYY-MM-DD HH:mm:ss');
    const { items, tabKey, error, reset = false, ...rest } = payload || {};
    let tabState = { ...state.tabs[tabKey], hasPendingRefresh: false };
    if (typeof loading !== 'undefined') tabState.loading = loading;
    if (typeof error !== 'undefined') {
        tabState.error = getErrorMessageWithDetail(error);
        tabState.lastRefreshed = formattedDate;
    } else {
        delete tabState.error;
    }
    if (typeof items !== 'undefined') {
        tabState = {
            ...tabState,
            items: reset ? items : [...(state.tabs[tabKey].items || []), ...items],
            lastRefreshed: formattedDate,
            hasPendingRefresh: false,
            ...rest,
        };
    }
    const newState = { ...state, tabs: { ...state.tabs, [tabKey]: tabState } };

    return newState;
};

const getInspectionsCalState = ({ state, payload, loading, clearDate }) => {
    const formattedDate = moment().format('YYYY-MM-DD HH:mm:ss');
    const { items, selectedDateData, dateSelected, error, reset = false, ...rest } = payload || {};
    let calState = {
        ...state,
        items: reset ? undefined : state.items,
        selectedDateData: state.selectedDateData,
        dateSelected: state.dateSelected,
    };
    if (typeof loading !== 'undefined') calState.loading = loading;
    if (typeof error !== 'undefined') {
        calState.error = getErrorMessageWithDetail(error);
    } else {
        delete calState.error;
    }
    if (typeof items !== 'undefined') {
        calState = { ...calState, items, lastRefreshed: formattedDate, ...rest };
    }
    if (typeof dateSelected !== 'undefined') {
        calState = { ...calState, selectedDateData, dateSelected };
    }
    const newState = { ...calState };

    return newState;
};

const reducer = (state = initialState, action) => {
    let chartState;
    let tabbedListViewState;
    switch (action.type) {
        case SET_PREFERENCE:
            return { ...state, preference: { ...state.preference, ...action.payload } };
        case SET_STATUS:
            return { ...state, status: { ...state.status, ...action.payload } };

        //-----------------
        case DASHBOARD_CHART_LOADING:
            //chartState = parseChartAction(action, state.dashboardChart.data);
            //return { ...state, dashboardChart: { ...chartState } };
            return { ...state, dashboardChart: { ...(state.dashboardChart || {}), chartRefreshing: true, loading: true } };
        case DASHBOARD_CHART_SUCCESS:
            // if (action.result !== undefined) {
            chartState = parseChartAction(action, state.dashboardChart.data);
            // }
            return { ...state, dashboardChart: { ...chartState } };

        case DASHBOARD_CHART_FAILURE:
            chartState = parseChartAction(action, state.dashboardChart.data);
            return { ...state, dashboardChart: { ...chartState, error: action.error } };

        case DASHBOARD_CHART_CLEARALL:
            return { ...state, dashboardChart: initializeChart() };

        //-----------------
        case GET_LIST:
        case GET_LIST_SUCCESS:
        case GET_LIST_FAILURE:
            const { formName, fieldName, data } = action.params;
            if (formName && fieldName) {
                const formObj = {};
                formObj[formName] = typeof state.form[formName] === 'undefined' ? {} : { ...state.form[formName] };

                if (typeof formObj[fieldName] === 'undefined') {
                    formObj[formName][fieldName] = {};
                }
                formObj[formName][fieldName].isLoading = action.type === 'GET_LIST' ? true : false;
                formObj[formName][fieldName].data = action.type === 'GET_LIST_SUCCESS' && data ? data : [];
                return { ...state, form: { ...state.form, ...formObj } };
            }
            return state;
        case RESET_LISTS:
            let { params } = action;
            if (params.formName && params.fieldNames && params.fieldNames.length > 0) {
                const formObjRest = {};
                formObjRest[params.formName] = typeof state.form[params.formName] === 'undefined' ? {} : { ...state.form[params.formName] };
                params.fieldNames.forEach(fieldName => {
                    if (typeof formObjRest[params.formName][fieldName] === 'undefined') {
                        formObjRest[params.formName][fieldName] = {};
                    }
                    formObjRest[params.formName][fieldName] = { isLoading: false, data: [] };
                });
                return { ...state, form: { ...state.form, ...formObjRest } };
            }
            return state;

        /*dashboard tabbed list - inspections start*/
        case DASHBOARD_INSPECTIONS_TAB_CLEARALL:
            return { ...state, inspectionsTabs: initializeInspectionsTabbedList() };
        case DASHBOARD_INSPECTIONS_TAB_CHANGED:
            return { ...state, inspectionsTabs: { ...state.inspectionsTabs, selectedTab: action.payload.tabKey } };
        case DASHBOARD_INSPECTIONS_TAB_LOADING:
            tabbedListViewState = getDashboardTabState({
                state: state.inspectionsTabs,
                loading: true,
                payload: action.payload,
            });
            return { ...state, inspectionsTabs: tabbedListViewState };
        case DASHBOARD_INSPECTIONS_TAB_SUCCESS:
            tabbedListViewState = getDashboardTabState({
                state: state.inspectionsTabs,
                loading: false,
                payload: action.payload,
            });
            return { ...state, inspectionsTabs: tabbedListViewState };
        case DASHBOARD_INSPECTIONS_TAB_FAILURE:
            tabbedListViewState = getDashboardTabState({
                state: state.inspectionsTabs,
                loading: false,
                payload: action.payload,
            });
            return { ...state, inspectionsTabs: tabbedListViewState };
        /*dashboard tabbed list - inspections end*/
        /*dashboard tabbed list - tasks start*/
        case DASHBOARD_TASKS_TAB_CLEARALL:
            return { ...state, tasksTabs: initializeTasksTabbedList() };
        case DASHBOARD_TASKS_TAB_CHANGED:
            return { ...state, tasksTabs: { ...state.tasksTabs, selectedTab: action.payload.tabKey } };
        case DASHBOARD_TASKS_SET_PENDING_REFRESH:
            return update(state, {
                tasksTabs: {
                    tabs: {
                        [action.payload.tabKey]: {
                            hasPendingRefresh: { $set: action.payload.hasPendingRefresh },
                        },
                    },
                },
            });
        case DASHBOARD_TASKS_TAB_LOADING:
            tabbedListViewState = getDashboardTabState({
                state: state.tasksTabs,
                loading: true,
                payload: action.payload,
            });
            return { ...state, tasksTabs: tabbedListViewState };
        case DASHBOARD_TASKS_TAB_SUCCESS:
            tabbedListViewState = getDashboardTabState({
                state: state.tasksTabs,
                loading: false,
                payload: action.payload,
            });
            return { ...state, tasksTabs: tabbedListViewState };
        case DASHBOARD_TASKS_TAB_FAILURE:
            tabbedListViewState = getDashboardTabState({
                state: state.tasksTabs,
                loading: false,
                payload: action.payload,
            });
            return { ...state, tasksTabs: tabbedListViewState };
        /*dashboard tabbed list tasks end*/

        case LOG_API_ERRORS:
            if (action.message || action.details) {
                let newLog = { message: action.message, loggedTime: moment().format('YYYY-MM-DD HH:mm:ss') };
                if (action.details) newLog.details = action.details;
                let apiErrors = [...state.logs.apiErrors].splice(0, state.logs.apiErrorsLimit || 25);
                return { ...state, logs: { ...state.logs, apiErrors: [{ ...newLog }, ...apiErrors] } };
            }
            return state;
        case LOG_JS_ERRORS:
            if (action.message) {
                let newLog = { message: action.message, loggedTime: moment().format('YYYY-MM-DD HH:mm:ss') };
                if (action.details) newLog.details = action.details;
                let jsErrors = [...state.logs.jsErrors].splice(0, state.logs.jsErrorsLimit || 25);
                return { ...state, logs: { ...state.logs, jsErrors: [{ ...newLog }, ...jsErrors] } };
            }
            return state;
        case LOG_CLEAR:
            if (action.logType) {
                if (action.logType === 'api') return { ...state, logs: { ...state.logs, apiErrors: [] } };
                return { ...state, logs: { ...state.logs, jsErrors: [] } };
            }
            return state;

        case LOG_LIMIT:
            if (action.logType && action.limit) {
                if (action.logType === 'api') return { ...state, logs: { ...state.logs, apiErrorsLimit: parseInt(action.limit) } };
                return { ...state, logs: { ...state.logs, jsErrorsLimit: parseInt(action.limit) } };
            }
            return state;
        case LOG_LEVEL:
            if (action.logLevel) {
                return { ...state, logs: { ...state.logs, logLevel: action.logLevel } };
            }
            return state;

        /*dashboard inspection calendar list start*/

        case DASHBOARD_INSPECTIONS_CAL_CLEARALL:
            return { ...state, inspectionsCalendar: initializeInspectionsCalList() };

        case DASHBOARD_INSPECTIONS_CAL_LOADING:
            calendarListViewState = getInspectionsCalState({
                state: state.inspectionsCalendar,
                loading: true,
                clearDate: true,
                payload: action.payload,
            });
            return { ...state, inspectionsCalendar: calendarListViewState };

        case DASHBOARD_INSPECTIONS_CAL_SUCCESS:
            calendarListViewState = getInspectionsCalState({
                state: state.inspectionsCalendar,
                loading: false,
                reset: true,
                clearDate: false,
                payload: action.payload,
            });
            return { ...state, inspectionsCalendar: calendarListViewState };

        case DASHBOARD_INSPECTIONS_CAL_FAILURE:
            calendarListViewState = getInspectionsCalState({
                state: state.inspectionsCalendar,
                loading: false,
                payload: action.payload,
            });
            return { ...state, inspectionsCalendar: calendarListViewState };

        /*dashboard inspection calendar list end*/

        /*dashboard inspectiontask calendar list start*/

        case DASHBOARD_TASK_CAL_CLEARALL:
            return { ...state, tasksCalendar: initializeInspectionsTaskCalList() };

        case DASHBOARD_TASK_CAL_LOADING:
            calendarListViewState = getInspectionsCalState({
                state: state.tasksCalendar,
                loading: true,
                clearDate: true,
                payload: action.payload,
            });
            return { ...state, tasksCalendar: calendarListViewState };

        case DASHBOARD_TASK_CAL_SUCCESS:
            calendarListViewState = getInspectionsCalState({
                state: state.tasksCalendar,
                loading: false,
                reset: true,
                clearDate: false,
                payload: action.payload,
            });
            return { ...state, tasksCalendar: calendarListViewState };

        case DASHBOARD_TASK_CAL_FAILURE:
            calendarListViewState = getInspectionsCalState({
                state: state.tasksCalendar,
                loading: false,
                payload: action.payload,
            });
            return { ...state, tasksCalendar: calendarListViewState };

        default:
            return state;
    }
};

export default reducer;
