import {
    INSPECTIONDIALOG_SHOW,
    INSPECTIONDIALOG_HIDE,
    INSPECTIONDIALOG_PENDINGTABRELOAD,
    INSPECTIONDIALOG_NOPENDINGTABRELOAD,
} from 'app/actions/inspectionDialog';

const initialState = { isShowing: false, pendingTabReload: false };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case INSPECTIONDIALOG_SHOW:
            return { ...state, isShowing: true, ...action.payload };
        case INSPECTIONDIALOG_PENDINGTABRELOAD:
            return { ...state, pendingTabReload: true };
        case INSPECTIONDIALOG_NOPENDINGTABRELOAD:
            return { ...state, pendingTabReload: false };
        case INSPECTIONDIALOG_HIDE:
            return { isShowing: false };
        default:
            return state;
    }
};

export default reducer;
