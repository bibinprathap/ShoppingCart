import update, { extend } from 'immutability-helper';
import { _ } from 'lodash';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';
import { _state } from 'app/config/store';

import {
    //INSPECTION_CREATENEW,
    INSPECTION_COORDSCHANGED,
    INSPECTION_ADDRESSCHANGED,
    INSPECTION_SELECTSERVICE,
    INSPECTION_CLEARHISTORY,
    INSPECTION_VALUECHANGED,
    INSPECTION_INFOCHANGED,
    INSPECTION_SELECT,
    //INSPECTION_SELECT_SUCCESS,
    INSPECTION_SAVENEW,
    INSPECTION_SAVE_SUCESS,
    INSPECTION_CANCEL_SUCESS,
    INSPECTION_LOCAL_SAVE_SUCCESS,
    INSPECTION_FOLLOWUP_LOCAL_SUCCESS,
    INSPECTION_SAVE_FAILURE,
    INSPECTION_CANCEL_FAILURE,
    INSPECTION_FOLLOWUP_FAILURE,
    INSPECTION_UPDATE,
    INSPECTION_INFOVIOLATORCHANGED,
    INSPECTION_ADDEDNEWVIOLATOR,
    INSPECTION_ADDNEWLOG,
    INSPECTION_ADD_VIOLATOR,
    INSPECTION_ADD_BUSINESSENTITYTOCHECKITEM,
    INSPECTION_REMOVE_BUSINESSENTITYFROMCHECKITEM,
    INSPECTION_UPDATEVIOLATIONS,
    INSPECTION_REMOVEVIOLATOR,
    INSPECTION_DUPCHK_START,
    INSPECTION_DUPCHK_SUCCESS,
    INSPECTION_DUPCHK_FAILURE,
    INSPECTION_DUPLICATE_DETAILS_SUCCESS,
    INSPECTION_DUPLICATE_DETAILS_FAILURE,
    INSPECTION_RECORDCREATE_START,
    INSPECTION_RECORDCREATE_SUCCESS,
    INSPECTION_RECORDCREATE_FAILURE,
    INSPECTION_SET_DUPLICATE,
    INSPECTION_CHECKLIST_SET_DUPLICATE,
    INSPECTION_ADD_VIOLATIOR_SIGNATURE,
    INSPECTION_REMOVE_VIOLATIOR_SIGNATURE,
    INSPECTION_ADD_NEXT_VISIT,
    ADD_VISIT_LOCATION,
    GET_VIOLATION_ACTION_TYPES,
    GET_VIOLATION_ACTION_TYPES_SUCCESS,
    GET_VIOLATION_ACTION_TYPES_STARTED,
    GET_VIOLATION_ACTION_TYPES_FAILED,
    UPDATE_VIOLATION,
    GET_ACTION_TYPES,
    GET_ACTION_TYPES_SUCCESS,
    GET_ACTION_TYPES_FAILED,
} from 'app/actions/inspections';

import { ATTACHMENT_ADD_IMAGE, ATTACHMENT_REMOVE_IMAGE, ATTACHMENT_STARTED_UPLOADING, ATTACHMENT_UPLOADED } from 'app/actions/attachments';

import { unloadAllAttachments } from 'app/actions/attachments';
import { inspectionsHelper } from 'app/api/helperServices';

const initialState = { currentInspectionRef: null, history: {}, envState: {} };

const getInspectionProperty = (state, refNumber, key) => {
    const inspectionContainer = state.history[refNumber];
    return { ...inspectionContainer.inspection[key] };
};

const setInspectionProperty = (state, refNumber, key, value) => {
    const inspectionContainer = state.history[refNumber];
    const valueChanged = inspectionContainer.inspection[key] !== value;
    return update(state, {
        currentInspectionVersion: {
            $apply: function (currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [refNumber]: {
                inspection: {
                    [key]: { $set: value },
                },
                saved: { $set: valueChanged ? false : inspectionContainer.saved },
            },
        },
    });
};

const saveVisit = (state, refNumber) => {
    if (!state.history[refNumber].inspection.visits) {
        return update(state, {
            history: {
                [refNumber]: {
                    inspection: {
                        visits: {
                            $set: [{ locallySaved: true, isLast: true }],
                        },
                    },
                },
            },
        });
    }
    const visitIndex = state.history[refNumber].inspection.visits.length - 1;
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [visitIndex]: {
                            locallySaved: { $set: true },
                        },
                    },
                },
            },
        },
    });
};
const isDistrotion = (state, refNumber) => {
    const inspection = state.history[refNumber].inspection;
    let currentVisitIndex = inspection && inspection.visits && inspection.visits.length - 1;

    const currentVisitData = currentVisitIndex != undefined ? inspection.visits[currentVisitIndex] : undefined;
    if (currentVisitData && currentVisitData.distortionForm) return true;
    else return false;
};
const setNexVisit = (state, refNumber, data) => {
    let nexinspection = {
        type: data.taskType,
        assignedToUserId: data.assignedToUserId,
        taskId: data.taskId,
        duedate: data.duedate,

        values: [],
        def: {
            type: 'form',
            def: [
                {
                    name: 'followupForm',
                    titleE: 'Details of the followup',
                    titleA: 'تفاصيل المتابعة',
                    workflowConst: 'MimsBuildingPenaltiesandGeneralAppearance',
                    showFormTitle: true,
                    collapsible: true,
                    showLabels: true,
                    formType: 'followup',
                    scope: 'visit',
                    fields: [
                        {
                            name: 'remarks',
                            type: 'text',
                            labelE: 'Remarks',
                            labelA: 'ملاحظات',
                            placeholderE: 'Remarks',
                            placeholderA: 'ملاحظات',
                            maxLength: 200,
                            multiline: true,
                            mode: 'flat',
                            debounce: 0,
                            validationRule: ['string', 'required'],
                        },
                        {
                            name: 'location',
                            type: 'currentLocation',
                            labelE: 'Current Location',
                            labelA: 'الموقع الحالي',
                        },
                        {
                            name: 'attachmentList',
                            type: 'attachmentList',
                            labelE: 'Attachments',
                            labelA: 'مرفقات',
                            validationRule: ['array', 'required', 'nullable'],
                        },
                        {
                            name: 'fieldGroup6',
                            type: 'fieldGroup',
                            fields: [
                                {
                                    type: 'picker',
                                    name: 'followupAction',
                                    defaultlyNotSelected: true,
                                    labelE: 'Action',
                                    labelA: 'عمل',
                                    validationRule: ['string', 'required'],
                                },
                                {
                                    type: 'periodPicker',
                                    name: 'duration',
                                    labelE: 'Duration',
                                    defaultValue: { selectedPeriod: 0, selectedPeriodType: 'day' },
                                    labelA: 'المدة الزمنية',
                                    showIf: ['followupAction=2'],
                                },
                                {
                                    name: 'amount',
                                    type: 'amount',
                                    labelE: 'Violation Amount',
                                    icon: 'remove-circle-outline',
                                    iconColor: '#FF0000',
                                    iconType: 'default',
                                    labelA: 'مبلغ الانتهاك',
                                    showIf: ['followupAction=3'],
                                },
                            ],
                        },
                    ],
                },
            ],
        },
    };
    if (isDistrotion(state, refNumber)) {
        nexinspection = {
            type: data.taskType,
            assignedToUserId: data.assignedToUserId,
            taskId: data.taskId,
            duedate: data.duedate,

            values: [],
            def: {
                type: 'form',
                def: [
                    {
                        name: 'followupForm',
                        titleE: 'Details of the followup',
                        titleA: 'تفاصيل المتابعة',
                        showFormTitle: true,
                        collapsible: true,
                        showLabels: true,
                        formType: 'followup',
                        workflowConst: 'MimsDistortion',
                        scope: 'visit',
                        fields: [
                            {
                                name: 'remarks',
                                type: 'text',
                                labelE: 'Remarks',
                                labelA: 'ملاحظات',
                                placeholderE: 'Remarks',
                                placeholderA: 'ملاحظات',
                                maxLength: 200,
                                multiline: true,
                                mode: 'flat',
                                debounce: 0,
                                validationRule: ['string', 'required'],
                            },
                            {
                                name: 'location',
                                type: 'currentLocation',
                                labelE: 'Current Location',
                                labelA: 'الموقع الحالي',
                            },
                            {
                                name: 'attachmentList',
                                type: 'attachmentList',
                                labelE: 'Attachments',
                                labelA: 'مرفقات',
                                validationRule: ['array', 'required', 'nullable'],
                            },
                            {
                                name: 'fieldGroup6',
                                type: 'fieldGroup',
                                fields: [
                                    {
                                        name: 'followupActionDistrotion',
                                        defaultValue: false,
                                        type: 'switch',
                                        labelE: 'Is it Resolved?',
                                        labelA: 'هل تم حلها؟',
                                        onIconType: 'default',
                                        onIcon: 'check',
                                        offIconType: 'default',
                                        offIcon: 'remove-circle',
                                        inlineValue: true,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        };
    }

    //return state;
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: { $push: [nexinspection] },
                },
            },
        },
    });
};

const setCreateInspectionRecordProperty = (state, refNumber, creatingInspectionID, inspectionId, creatingInspectionError) => {
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    saving: { $set: creatingInspectionID },
                    inspectionId: { $set: inspectionId },
                    savingError: { $set: creatingInspectionError },
                },
            },
        },
    });
};

const setCreateInspectionRecordPropertySuccess = (
    { history: { [refNumber]: temp, ...history }, ...state },
    applicationNumber,
    createdInspection,
    refNumber
) => {
    return {
        ...state,
        currentInspectionRef: applicationNumber,
        history: {
            ...history,
            [applicationNumber]: {
                ...temp,
                inspection: {
                    ...createdInspection, // ...temp.inspection,
                    saving: false,
                    //inspectionId: createdInspection.inspectionId,
                    savingError: '',
                },
            },
        },
    };
};

const setInitialDistrotionTypeProperty = (newState, refNumber, value) => {
    if (!newState.history[refNumber].inspection.info) newState.history[refNumber].inspection.info = { distortionForm: {} };
    else if (!newState.history[refNumber].inspection.info.distortionForm) newState.history[refNumber].inspection.info.distortionForm = {};
    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    info: {
                        distortionForm: {
                            distortionType: { $set: value },
                        },
                    },
                },
            },
        },
    });
};

const setInspectionLocation = (state, refNumber, key, value) => {
    const inspectionContainer = state.history[refNumber];

    const inspection = inspectionContainer && inspectionContainer.inspection;
    if (!inspection) return state;
    let valueChanged = false;
    if (inspection.location === undefined) {
        inspection.location = {};
        valueChanged = true;
    }
    const currentValue = inspection.location[key];
    if (currentValue !== value) valueChanged = true;

    return update(state, {
        currentInspectionVersion: {
            $apply: function (currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [refNumber]: {
                inspection: {
                    location: { $merge: { [key]: value } },
                    info: {
                        $apply: function (currentVersion) {
                            return currentVersion;
                        },
                    },
                },
                saved: { $set: valueChanged ? false : inspectionContainer.saved },
            },
        },
    });
};

const getMergedChecklistDef = (state, refNumber, checklistDef) => {
    const currentInspectionContainer = state.history[refNumber];
    let mergedChecklistDef = {
        ...(currentInspectionContainer.inspection.checklistDef || undefined),
        ...(checklistDef || undefined),
    };
    return mergedChecklistDef;
};

const clearHistory = (state) => {
    //Todo: keep the inspections which have unsaved data
    //for now just remove all history.
    return initialState;
};

// const getTrimmedServiceObject = serviceDefinition => {
//     if (!!serviceDefinition) {
//         return serviceDefinition.inspectionTypeId;
//         // return {
//         //     inspectionTypeId: serviceDefinition.inspectionTypeId,
//         //     titleE: serviceDefinition.titleE,
//         //     titleA: serviceDefinition.titleA,
//         // };
//     } else return undefined;
// };

const setInspectionValues = (state, refNumber, visitIndex, newValues) => {
    const newState = { ...state };
    newState.history[refNumber].inspection.visits[visitIndex].values = newValues;
    return newState;
};

const setInspectionInfo = (state, refNumber, key, value) => {
    const newState = { ...state };
    const newInfo = { ...newState.history[refNumber].inspection.info, [key]: value };
    newState.history[refNumber].inspection.info = newInfo;
    return newState;
};
const setApplicationNo = (state, refNumber, key, value) => {
    const newState = { ...state };
    const newinspection = { ...newState.history[refNumber].inspection, [key]: value };
    newState.history[refNumber].inspection = newinspection;
    return newState;
};

const setInspectionViolatorInfo = (state, refNumber, payload) => {
    let newState = { ...state };
    let { key, value } = payload;
    let violatorindex = -1;
    let baseInfo = key ? { ...payload.baseInfo, [key]: value } : { ...payload.baseInfo };
    // When there is no info object
    if (!state.history[refNumber].inspection.violators) {
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        violators: {
                            $set: [{ ...baseInfo }],
                        },
                    },
                },
            },
        });
    }

    violatorindex = state.history[refNumber].inspection.violators
        .map(function (e) {
            return e.violatorId || 0;
        })
        .indexOf(baseInfo.violatorId);
    if (violatorindex === -1) {
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        violators: { $push: [baseInfo] },
                    },
                },
            },
        });
    }

    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    violators: {
                        [violatorindex]: {
                            $merge: baseInfo,
                        },
                    },
                },
            },
        },
    });
};
const getNewDuplicates = (newState, refNumber) => {
    if (newState.history[refNumber].inspection.duplicates != undefined) {
        //already there is some  duplicate
        if (newState.history[refNumber].inspection.duplicates.length > 0) {
            let newDuplicate = [...newState.history[refNumber].inspection.duplicates];
            let newDuplicateArray = [];
            newDuplicate.map((d, i) => {
                let duplicateindex = newState.history[refNumber].inspection.duplicateInspection.duplicateCandidates
                    .map(function (e) {
                        return e.workflowInstanceId || 0;
                    })
                    .indexOf(d.workflowInstanceId || 0);
                if (duplicateindex > -1) {
                    newDuplicateArray.push(d);
                }
            });
            if (newDuplicateArray.length == 0) return undefined;
            else return newDuplicateArray;
        }
        // currently user deside  there is no duplicate
        else {
            return [];
        }
    }
    return undefined;
};
const addNewDuplicateInspection = (state, refNumber, newDuplicate) => {
    if (state.history[refNumber].inspection.duplicates != undefined) {
        return update(state, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicates: { $set: newDuplicate },
                    },
                },
            },
        });
    } else return state;
};

const addNewDuplicateInspectionDetails = (state, refNumber, payload) => {
    const { data, isChecklist } = payload;
    if (isChecklist) {
        const { currentVisitIndex, inspTypeCheckItemId } = payload;
        const { values } = state.history[refNumber].inspection.visits[currentVisitIndex];
        const checklistItemIndex = _.findIndex(values, (checkItem) => checkItem.inspTypeCheckItemId === inspTypeCheckItemId);
        const currentItem = values && values[checklistItemIndex];
        const duplicateCandidates = currentItem.duplicateInspection && currentItem.duplicateInspection.duplicateCandidates;
        if (!duplicateCandidates) return state;
        const cIndex = duplicateCandidates.map((d) => d.applicationNumber).indexOf(data.applicationNumber);
        if (cIndex > -1) {
            return update(state, {
                history: {
                    [refNumber]: {
                        inspection: {
                            visits: {
                                [currentVisitIndex]: {
                                    values: {
                                        [checklistItemIndex]: {
                                            duplicateInspection: {
                                                duplicateCandidates: {
                                                    [cIndex]: {
                                                        inspection: {
                                                            $set: data,
                                                        },
                                                    },
                                                },
                                            },
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            });
        } else {
            return state;
        }
    }

    if (state.history[refNumber].inspection.duplicateInspection.duplicateCandidates != undefined) {
        const dIndex = state.history[refNumber].inspection.duplicateInspection.duplicateCandidates
            .map((d) => d.applicationNumber)
            .indexOf(data.applicationNumber);
        if (dIndex > -1) {
            return update(state, {
                history: {
                    [refNumber]: {
                        inspection: {
                            duplicateInspection: {
                                duplicateCandidates: {
                                    [dIndex]: {
                                        inspection: {
                                            $set: data,
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            });
        } else return state;
    } else return state;
};

const setCheckListDuplicateInspection = (payload) => {
    const {
        state,
        currentInspectionRef,
        option,
        applicationNumber,
        currentVisitIndex,
        inspTypeCheckItemId,
        workflowInstanceId,
        workflowApplicationNumber,
    } = payload;
    let refNumber = currentInspectionRef;

    let newState = { ...state };

    const { values } = state.history[refNumber].inspection.visits[currentVisitIndex];
    const checklistItemIndex = _.findIndex(values, (checkItem) => checkItem.inspTypeCheckItemId === inspTypeCheckItemId);
    const currentItem = values && values[checklistItemIndex];
    const duplicateCandidates = currentItem.duplicateInspection && currentItem.duplicateInspection.duplicateCandidates;
    const duplicates = currentItem.duplicateInspection && currentItem.duplicates;

    if (!duplicateCandidates) return state;
    //const cIndex = duplicateCandidates.map(d => d.applicationNumber).indexOf(applicationNumber);

    let duplicateInspectionIndex = duplicates
        .map(function (e) {
            return e.applicationNumber;
        })
        .indexOf(applicationNumber);

    if (duplicateInspectionIndex > -1) {
        newState = update(state, {
            history: {
                [refNumber]: {
                    inspection: {
                        visits: {
                            [currentVisitIndex]: {
                                values: {
                                    [checklistItemIndex]: {
                                        duplicates: { $splice: [[duplicateInspectionIndex, 1]] },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
    }

    let newDuplicate = {};
    if (option == true) {
        let newDuplicatesList = [...newState.history[refNumber].inspection.visits[currentVisitIndex].values[checklistItemIndex].duplicates];
        newDuplicatesList = newDuplicatesList.map((d) => {
            d.isDuplicate = false;
            return d;
        });

        newDuplicate = { applicationNumber, workflowInstanceId, workflowApplicationNumber, isDuplicate: option, item: null };
        newDuplicatesList.push(newDuplicate);

        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        visits: {
                            [currentVisitIndex]: {
                                values: {
                                    [checklistItemIndex]: {
                                        didDuplicateCheck: { $set: true },
                                        duplicates: { $set: newDuplicatesList },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
    } else {
        newDuplicate = { workflowInstanceId, workflowApplicationNumber, applicationNumber, isDuplicate: false, item: null };

        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        visits: {
                            [currentVisitIndex]: {
                                values: {
                                    [checklistItemIndex]: {
                                        didDuplicateCheck: { $set: true },
                                        duplicates: { $push: [newDuplicate] },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
    }
};

const setDuplicateInspection = (
    state,
    refNumber,
    value,
    duplicateApplicationNumber,
    duplicateWorkflowInstanceId,
    duplicateworkflowApplicationNumber
) => {
    let newState = { ...state };
    if (newState.history[refNumber].inspection.duplicates == undefined) {
        newState.history[refNumber].inspection.duplicates = [];
    }
    let duplicateindex = newState.history[refNumber].inspection.duplicates
        .map(function (e) {
            return e.applicationNumber || 0;
        })
        .indexOf(duplicateApplicationNumber || 0);
    if (duplicateindex > -1) {
        newState = update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicates: { $splice: [[duplicateindex, 1]] },
                    },
                },
            },
        });
    }
    let newDuplicate = {};
    // is a violation
    if (value == true) {
        newDuplicate = {
            applicationNumber: duplicateApplicationNumber,
            workflowInstanceId: duplicateWorkflowInstanceId,
            workflowApplicationNumber: duplicateworkflowApplicationNumber,
            isDuplicate: true,
            item: null,
        };
        let newDuplicatesList = [...newState.history[refNumber].inspection.duplicates];
        newDuplicatesList = newDuplicatesList.map((d) => {
            d.isDuplicate = false;
            return d;
        });
        newDuplicatesList.push(newDuplicate);
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicates: { $set: newDuplicatesList },
                    },
                },
            },
        });
    } else {
        newDuplicate = {
            applicationNumber: duplicateApplicationNumber,
            workflowInstanceId: duplicateWorkflowInstanceId,
            workflowApplicationNumber: duplicateworkflowApplicationNumber,
            isDuplicate: false,
            item: null,
        };
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        duplicates: { $push: [newDuplicate] },
                    },
                },
            },
        });
    }
};

const setCheckItemValue = (state, refNumber, payload) => {
    const { currentVisitIndex, inspTypeCheckItemId, key, value } = payload;
    const checklistItemIndex = _.findIndex(
        state.history[refNumber].inspection.visits[currentVisitIndex].values,
        (checkItem) => checkItem.inspTypeCheckItemId === inspTypeCheckItemId
    );
    const newValues = key ? { [key]: value } : { ...value };
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [currentVisitIndex]: {
                            values: {
                                [checklistItemIndex]: { $merge: newValues },
                            },
                        },
                    },
                },
            },
        },
    });
};

const seActionTypes = (state, refNumber, payload) => {
    const { currentVisitIndex, formName, key, value, duplicateInspection, duplicates } = payload;
    const newValues = key ? { [key]: value } : { ...value };

    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [currentVisitIndex]: {
                            [formName]: { $merge: newValues },
                        },
                    },
                    duplicates: { $set: duplicates },
                    duplicateInspection: { $set: duplicateInspection },
                },
            },
        },
    });
};

const setViolatorId = (state, refNumber, payload) => {
    const { currentVisitIndex, inspTypeCheckItemId, violator } = payload;
    const violatorId = (violator && violator.violatorId) || null;

    const checklistItemIndex = _.findIndex(
        state.history[refNumber].inspection.visits[currentVisitIndex].values,
        (v) => v.inspTypeCheckItemId === inspTypeCheckItemId
    );

    let newValues = { violatorId };
    if (!violatorId) {
        newValues = {
            violatorId: null,
            selectedActionType: null,
            selectedActionTypeConst: null,
            selectedPeriodType: null,
            selectedPeriod: null,
            amount: null,
            reconciled: false,
        };
    }

    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [currentVisitIndex]: {
                            values: {
                                [checklistItemIndex]: { $merge: newValues },
                            },
                        },
                    },
                },
            },
        },
    });
};

const addViolatorToViolation = (state, refNumber, payload) => {
    //const { currentVisitIndex, violation, violator } = payload;
    return setViolatorId(state, refNumber, payload);
};
const addBusinessEntiryToCheckItem = (state, refNumber, payload) => {
    const { currentVisitIndex, violator } = payload;
    const violatorId = (violator && violator.violatorId) || null;
    const violatorType = (violator && violator.violatorType) || null;
    const oldValues = [...state.history[refNumber].inspection.visits[currentVisitIndex].values];
    const newValues = oldValues.map((v) => {
        v.violatorId = violatorId;
        v.violatorType = violatorType;
        return v;
    });
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [currentVisitIndex]: {
                            values: { $set: newValues },
                        },
                    },
                },
            },
        },
    });
};
const removeBusinessEntiryFromCheckItem = (state, refNumber, payload) => {
    const { currentVisitIndex } = payload;

    const oldValues = [...state.history[refNumber].inspection.visits[currentVisitIndex].values];
    const newValues = oldValues.map((v) => {
        v.violatorId = null;
        v.violatorType = null;
        return v;
    });
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    violators: { $set: [] },
                    visits: {
                        [currentVisitIndex]: {
                            values: { $set: newValues },
                        },
                    },
                },
            },
        },
    });
};

const removeViolator = (state, refNumber, payload) => {
    // const { currentVisitIndex, violation, violator } = payload;
    return setViolatorId(state, refNumber, { ...payload, violator: null });
};

const updateViolationsOfAViolator = (state, refNumber, violatorIndex, violations) => {
    return update(state, {
        history: {
            [refNumber]: {
                inspection: {
                    violators: {
                        [violatorIndex]: { violations: { $set: violations } },
                    },
                },
            },
        },
    });
};

const inspectionViolatorAdded = (newState, refNumber, payload) => {
    if (!newState.history[refNumber].inspection.violators) newState.history[refNumber].inspection.violators = [];
    else if (!newState.history[refNumber].inspection.violators) newState.history[refNumber].inspection.violators = [];
    if (!payload.violator) return newState;

    if (payload.reset) {
        return update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        violators: { $set: [payload.violator] },
                    },
                },
            },
        });
    }

    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    violators: { $push: [payload.violator] },
                },
            },
        },
    });
};

const addNewLog = (newState, refNumber, log) => {
    // currentInspectionVersion: {
    //     $apply: function(currentVersion) {
    //         return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
    //     },
    // },
    const refno = log.inspectionId || refNumber;
    if (refno && newState.history[refno])
        return update(newState, {
            history: {
                [log.inspectionId || refNumber]: {
                    logs: { $push: [log] },
                },
            },
        });
    else return newState;
};

const setInspectionVisitInfo = (state, refNumber, visitIndex, key, value) => {
    const newState = { ...state };
    if (newState.history[refNumber] && newState.history[refNumber].inspection) {
        const currentVisitData = newState.history[refNumber].inspection.visits[visitIndex];
        newState.history[refNumber].inspection.visits[visitIndex] = { ...currentVisitData, [key]: value };
    }
    return newState;
};

const updateViolation = (state, refNumber, payload) => {
    const { params, visitIndex, inspTypeCheckItemId, reset } = payload;
    let newState = { ...state };
    const checklistItemIndex = _.findIndex(
        state.history[refNumber].inspection.visits[visitIndex].values,
        (checkItem) => checkItem.inspTypeCheckItemId === inspTypeCheckItemId
    );

    const selectedActionType = (params && params.selectedActionType) || null;
    const selectedActionTypeConst = (selectedActionType && params.selectedActionTypeConst) || null;

    if (reset) {
        newState = update(newState, {
            history: {
                [refNumber]: {
                    inspection: {
                        visits: {
                            [visitIndex]: {
                                values: {
                                    [checklistItemIndex]: {
                                        selectedActionType: { $set: selectedActionType },
                                        selectedActionTypeConst: { $set: selectedActionTypeConst },
                                        selectedPeriodType: { $set: null },
                                        selectedPeriod: { $set: null },
                                        amount: { $set: null },
                                        reconciled: { $set: false },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        });
        if (!selectedActionType) {
            return newState;
        }
    }

    return update(newState, {
        history: {
            [refNumber]: {
                inspection: {
                    visits: {
                        [visitIndex]: {
                            values: {
                                [checklistItemIndex]: {
                                    $merge: params,
                                },
                            },
                        },
                    },
                },
            },
        },
    });
};

const setInspectionDefinition = (state, refNumber, visitIndex, def) => {
    const newState = { ...state };
    newState.history[refNumber].inspection.visits[visitIndex].def = def;
    return newState;
};

const updateVersion = (state) => {
    /*
    update the currently selected inspection version
    to signal the subscribing components that they should re-render.
    for performance reasons most component will use the outer container, and will not re-render when
    some embedded property of the selected inspection is changed.
    this version gives us control on when we want to trigger the re-render such components   
    */
    return update(state, {
        currentInspectionVersion: {
            $apply: function (currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
    });
    // const currentVersion = state.currentInspectionVersion;
    // return { ...state, currentInspectionVersion: isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1 };
};
// const createNewInspection = (state, newInspection) => {
//     return {
//         ...state,
//         currentInspectionRef: newInspection.refNumber,
//         currentInspectionVersion: '',
//         history: {
//             [newInspection.refNumber]: {
//                 status: 'draft',
//                 saved: false,
//                 locallySaved: false,
//                 inspection: newInspection,
//                 logs: [],
//             },
//             ...state.history,
//         },
//     };
// };

const addViolatorSignature = (state, payload) => {
    const violators = inspectionsHelper.getViolators(state.history[state.currentInspectionRef]);
    var violatorindex = _.findIndex(violators, { violatorId: payload.violatorId });
    debugger;
    return update(state, {
        currentInspectionVersion: {
            $apply: function (currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [state.currentInspectionRef]: {
                inspection: {
                    violators: {
                        [violatorindex]: {
                            signature: { $set: payload.attachment },
                        },
                    },
                },
            },
        },
    });
};

const removeViolatorSignature = (state, payload) => {
    const violators = inspectionsHelper.getViolators(state.history[state.currentInspectionRef]);
    var violatorindex = _.findIndex(violators, { violatorId: payload.violatorId });

    return update(state, {
        currentInspectionVersion: {
            $apply: function (currentVersion) {
                return isNaN(currentVersion) ? 1 : parseInt(currentVersion) + 1;
            },
        },
        history: {
            [state.currentInspectionRef]: {
                inspection: {
                    violators: {
                        [violatorindex]: {
                            signature: { $set: null },
                        },
                    },
                },
            },
        },
    });
};

const reducer = (state = initialState, action) => {
    let newState = undefined;
    let updatedDuplicateCheckProp = undefined;
    switch (action.type) {
        // case INSPECTION_CREATENEW:
        //     newState = createNewInspection(state, action.payload);
        //     return newState;
        case INSPECTION_UPDATE:
            return { ...state, [action.payload.prop]: action.payload.value };
        case INSPECTION_CANCEL_SUCESS:
            if (action.data && action.data.visits !== 'undefined') {
                let applicationNumber = inspectionsHelper.getInspectionKeyFromHistory(action.data, state.history);
                // let lastvisit = action.data.visits.find(k => k.isLast == true);
                // let applicationNumber = lastvisit.applicationNumber;
                //action.data.applicationNumber;
                let { [applicationNumber]: savedInspection, ...newHistory } = state.history;

                return updateVersion({
                    ...state,
                    history: {
                        ...newHistory,
                    },
                });
            }
        case INSPECTION_SAVE_SUCESS:
            if (action.data && action.data.visits !== 'undefined') {
                let applicationNumber = inspectionsHelper.getInspectionKeyFromHistory(action.data, state.history);

                // let lastvisit = action.data.visits.find(k => k.isLast == true);
                // let applicationNumber = lastvisit.applicationNumber;
                //action.data.applicationNumber;
                let { [applicationNumber]: savedInspection, ...newHistory } = state.history;

                return updateVersion({
                    ...state,
                    history: {
                        ...newHistory,
                    },
                });
            }
        /*
            if (action.data && action.data.visits !== undefined) {
                let lastvisit = action.data.visits.find(k => k.isLast == true);

                let visitsLength = state.history[action.data.inspectionId].inspection.visits.length - 1;
                if (lastvisit) {
                    newState = setInspectionVisitInfo(
                        state,
                        action.data.inspectionId,
                        visitsLength,
                        'applicationNumber',
                        lastvisit.applicationNumber
                    );
                    newState = setInspectionVisitInfo(
                        state,
                        action.data.inspectionId,
                        visitsLength,
                        'workflowInstanceId',
                        lastvisit.workflowInstanceId
                    );
                    if (!state.history[action.data.inspectionId].inspection.applicationNumber)
                        newState = setApplicationNo(newState, action.data.inspectionId, 'applicationNumber', lastvisit.applicationNumber);

                    newState = setInspectionProperty(newState, action.data.inspectionId, 'locallySaved', true);
                }
            }
            newState = saveVisit(newState, action.data.inspectionId);
            return updateVersion(newState);

      */

        // const currentInspectionId = action.data.visits[action.data.visits.length - 1].inspectionId;
        // if (action.data && action.data.visits !== undefined) {
        //     let visitsLength = state.history[currentInspectionId].inspection.visits.length - 1;
        //     newState = setApplicationNo(state, currentInspectionId, 'applicationNumber', action.data.visits[visitsLength].applicationNumber);
        //     newState = setInspectionVisitInfo(
        //         state,
        //         currentInspectionId,
        //         visitsLength,
        //         'applicationNumber',
        //         action.data.visits[visitsLength].applicationNumber
        //     );
        // }
        // newState = setInspectionProperty(newState, currentInspectionId, 'locallySaved', true);
        // newState = saveVisit(newState, currentInspectionId);
        // return updateVersion(newState);
        case INSPECTION_LOCAL_SAVE_SUCCESS:
            newState = setInspectionProperty(state, state.currentInspectionRef, 'locallySaved', true);
            newState = saveVisit(newState, state.currentInspectionRef);
            return updateVersion({
                ...newState,
                history: {
                    ...newState.history,
                    [state.currentInspectionRef]: {
                        ...newState.history[state.currentInspectionRef],
                        saved: false,
                        locallySaved: true,
                    },
                },
            });
        // case INSPECTION_FOLLOWUP_SUCESS:
        //     if (action.data && action.data.visits !== undefined) {
        //         let lastvisit = action.data.visits.find(k => k.isLast == true);

        //         let visitsLength = state.history[action.data.inspectionId].inspection.visits.length - 1;
        //         if (lastvisit)
        //             newState = setInspectionVisitInfo(
        //                 state,
        //                 action.data.inspectionId,
        //                 visitsLength,
        //                 'applicationNumber',
        //                 lastvisit.applicationNumber
        //             );
        //     }
        //     newState = saveVisit(newState, action.data.inspectionId);
        //     return updateVersion(newState);
        case INSPECTION_FOLLOWUP_LOCAL_SUCCESS:
            newState = saveVisit(state, state.currentInspectionRef);
            return updateVersion({
                ...newState,
                history: {
                    ...newState.history,
                    [state.currentInspectionRef]: {
                        ...newState.history[state.currentInspectionRef],
                        saved: false,
                        locallySaved: true,
                    },
                },
            });
        case INSPECTION_ADD_NEXT_VISIT:
            newState = setNexVisit(state, state.currentInspectionRef, action.data);
            return updateVersion(newState);
        case INSPECTION_COORDSCHANGED:
            const updatedStateWithNewCoords = setInspectionLocation(state, state.currentInspectionRef, 'coords', action.payload);
            //when coords are changed, remove the existing address
            return setInspectionLocation(updatedStateWithNewCoords, updatedStateWithNewCoords.currentInspectionRef, 'address', undefined);
        case INSPECTION_ADDRESSCHANGED:
            return setInspectionLocation(state, state.currentInspectionRef, 'address', action.payload);
        // case INSPECTION_SELECT:
        //     return { ...state, currentInspectionRef: action.payload, currentInspectionVersion: 0 };
        case INSPECTION_SELECT:
            const inspectionContainer = action.payload;
            if (inspectionContainer && inspectionContainer.inspection) {
                let inspectionKey = inspectionsHelper.getInspectionKey(inspectionContainer.inspection);
                // if (!applicationNumber) applicationNumber = inspectionContainer.inspection.refNumber; //in case of new inspection
                if (!inspectionKey) {
                    console.log('invalid payload, inspectionKey not found in inspectionContainer: ', inspectionContainer);
                    return state;
                }
                const inspectionObj = {};
                inspectionObj[inspectionKey] = inspectionContainer;
                return {
                    ...state,
                    history: { ...state.history, ...inspectionObj },
                    currentInspectionRef: inspectionKey,
                    currentInspectionVersion: 0,
                };
            } else {
                console.log('invalid payload, no inspection found');
                return state;
            }
        case INSPECTION_SELECTSERVICE:
            //const serviceObj = getTrimmedServiceObject(action.payload);
            const { inspectionTypeId } = action.payload;
            //const { inspectionTypeDetail = {} } = (state.history[state.currentInspectionRef] || {}).inspection;
            //const updatedInspectionType = { ...inspectionTypeDetail, inspectionTypeId: inspectionTypeId, workflowConst };
            newState = setInspectionProperty(state, state.currentInspectionRef, 'service', inspectionTypeId); //to be removed, should use inspectionTypeDetail.inspectionTypeId instead
            newState = setInspectionProperty(newState, state.currentInspectionRef, 'inspectionTypeId', inspectionTypeId); //to be removed, should use inspectionTypeDetail.inspectionTypeId instead
            newState = setInspectionProperty(newState, state.currentInspectionRef, 'inspectionTypeDetail', action.payload);
            return updateVersion(newState);
        case INSPECTION_ADDEDNEWVIOLATOR:
            newState = inspectionViolatorAdded(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_ADDNEWLOG:
            newState = addNewLog(state, state.currentInspectionRef, action.payload.log);
            return updateVersion(newState);
        case INSPECTION_UPDATEVIOLATIONS:
            newState = updateViolationsOfAViolator(state, state.currentInspectionRef, action.payload.violatorindex, action.payload.violations);
            return updateVersion(newState);
        case INSPECTION_ADD_BUSINESSENTITYTOCHECKITEM:
            newState = addBusinessEntiryToCheckItem(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_REMOVE_BUSINESSENTITYFROMCHECKITEM:
            newState = removeBusinessEntiryFromCheckItem(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_ADD_VIOLATOR:
            newState = addViolatorToViolation(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_REMOVEVIOLATOR:
            newState = removeViolator(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_VALUECHANGED:
            newState = setInspectionValues(state, state.currentInspectionRef, action.payload.visitIndex, action.payload.newValues);
            return updateVersion(newState);
        case INSPECTION_INFOVIOLATORCHANGED:
            newState = setInspectionViolatorInfo(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_INFOCHANGED:
            if (action.payload && action.payload.visit !== undefined) {
                newState = setInspectionVisitInfo(state, state.currentInspectionRef, action.payload.visit, action.payload.key, action.payload.value);
            } else {
                newState = setInspectionInfo(state, state.currentInspectionRef, action.payload.key, action.payload.value);
            }
            return updateVersion(newState);

        case UPDATE_VIOLATION:
            newState = updateViolation(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);

        case GET_VIOLATION_ACTION_TYPES:
            return state;

        case GET_VIOLATION_ACTION_TYPES_SUCCESS:
            newState = setCheckItemValue(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                inspTypeCheckItemId: action.payload.inspTypeCheckItemId,
                key: undefined,
                value: {
                    violationActionTypesLoading: false,
                    violationActionTypesSuccess: true,
                    violationActionTypesError: false,
                    isEngineerReviewRequired: action.data.isEngineerReviewRequired || false,
                    violationActionTypes: action.data.violationActionTypes || [],
                    duplicates: [],
                    duplicateInspection: { duplicateCandidates: action.data.duplicateInspections || [] },
                },
            });

            return updateVersion(newState);
        case GET_VIOLATION_ACTION_TYPES_STARTED:
            newState = setCheckItemValue(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                inspTypeCheckItemId: action.payload.inspTypeCheckItemId,
                key: undefined,
                value: {
                    violationActionTypesLoading: true,
                    violationActionTypesSuccess: undefined,
                    violationActionTypesError: false,
                    violationActionTypes: undefined,
                    isEngineerReviewRequired: undefined,
                    duplicates: [],
                    duplicateInspection: { duplicateCandidates: [] },
                },
            });
            return updateVersion(newState);
        case GET_VIOLATION_ACTION_TYPES_FAILED:
            newState = setCheckItemValue(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                inspTypeCheckItemId: action.payload.inspTypeCheckItemId,
                key: undefined,
                value: {
                    violationActionTypesLoading: false,
                    violationActionTypesSuccess: false,
                    violationActionTypesError: true,
                    violationActionTypes: undefined,
                    isEngineerReviewRequired: undefined,
                    duplicates: [],
                    duplicateInspection: { duplicateCandidates: [] },
                },
            });
            return updateVersion(newState);

        case GET_ACTION_TYPES:
            newState = seActionTypes(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                formName: action.payload.formName,
                duplicates: [],
                duplicateInspection: { duplicateCandidates: [] },
                value: {
                    violationActionTypesLoading: true,
                    violationActionTypesSuccess: undefined,
                    violationActionTypesError: false,
                    violationActionTypes: undefined,
                },
            });
            return updateVersion(newState);

        case GET_ACTION_TYPES_SUCCESS:
            newState = seActionTypes(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                formName: action.payload.formName,
                duplicates: [],
                duplicateInspection: { duplicateCandidates: action.data.duplicateInspections || [] },
                value: {
                    violationActionTypesLoading: false,
                    violationActionTypesSuccess: true,
                    violationActionTypesError: false,
                    violationActionTypes: action.data.violationActionTypes || [],
                },
            });

            return updateVersion(newState);
        case GET_ACTION_TYPES_FAILED:
            newState = seActionTypes(state, state.currentInspectionRef, {
                currentVisitIndex: action.payload.currentVisitIndex,
                formName: action.payload.formName,
                duplicates: [],
                duplicateInspection: { duplicateCandidates: [] },
                value: {
                    violationActionTypesLoading: false,
                    violationActionTypesSuccess: false,
                    violationActionTypesError: true,
                    violationActionTypes: undefined,
                },
            });
            return updateVersion(newState);

        case INSPECTION_CLEARHISTORY:
            return clearHistory();
        case INSPECTION_DUPCHK_START:
            updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateInspection'),
                checking: true,
                error: undefined,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateInspection', updatedDuplicateCheckProp);
            return updateVersion(newState);
        case INSPECTION_DUPCHK_SUCCESS:
            let updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateInspection'),
                checking: false,
                error: undefined,
                ...action.payload.data,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateInspection', updatedDuplicateCheckProp);
            let newDuplicates = getNewDuplicates(newState, action.payload.refNumber);
            let newStateWithDuplicates = addNewDuplicateInspection(newState, action.payload.refNumber, newDuplicates);
            return updateVersion(newStateWithDuplicates);
        case INSPECTION_DUPLICATE_DETAILS_SUCCESS:
            newState = addNewDuplicateInspectionDetails(state, state.currentInspectionRef, action.payload);
            return updateVersion(newState);
        case INSPECTION_DUPCHK_FAILURE:
            updatedDuplicateCheckProp = {
                ...getInspectionProperty(state, action.payload.refNumber, 'duplicateInspection'),
                checking: false,
                error: action.payload.error,
            };
            newState = setInspectionProperty(state, action.payload.refNumber, 'duplicateInspection', updatedDuplicateCheckProp);
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_START:
            newState = setCreateInspectionRecordProperty(state, state.currentInspectionRef, true);
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_SUCCESS:
            newState = setCreateInspectionRecordPropertySuccess(
                state,
                action.payload.applicationNumber,
                action.payload.createdInspection,
                action.payload.refNumber
            );
            return updateVersion(newState);
        case INSPECTION_RECORDCREATE_FAILURE:
            newState = setCreateInspectionRecordProperty(state, state.currentInspectionRef, false, undefined, action.payload.error);
            return updateVersion(newState);
        case INSPECTION_SET_DUPLICATE:
            newState = setDuplicateInspection(
                state,
                state.currentInspectionRef,
                action.payload.option,
                action.payload.inspection.applicationNumber,
                action.payload.inspection.workflowInstanceId,
                action.payload.inspection.workflowApplicationNumber
            );
            return updateVersion(newState);
        case INSPECTION_CHECKLIST_SET_DUPLICATE:
            newState = setCheckListDuplicateInspection({
                state: state,
                currentInspectionRef: state.currentInspectionRef,
                ...action.payload,
            });
            return updateVersion(newState);
        case INSPECTION_ADD_VIOLATIOR_SIGNATURE:
            return addViolatorSignature(state, action.payload);
        case INSPECTION_REMOVE_VIOLATIOR_SIGNATURE:
            return removeViolatorSignature(state, action.payload);

        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = { ...state, envState: {} };
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: backupState };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        case ADD_VISIT_LOCATION:
            if (action.payload.applicationNumber && action.payload.visitLocation && action.payload.visitIndex >= 0) {
                let visits = [...state.history[action.payload.applicationNumber].inspection.visits];
                //&& !visits[action.payload.visitIndex]['location']
                if (visits) {
                    visits[action.payload.visitIndex]['location'] = action.payload.visitLocation;
                    newState = setInspectionProperty(state, action.payload.applicationNumber, 'visits', visits);
                    return updateVersion(newState);
                }
            }
            return state;

        // case ATTACHMENT_ADD_IMAGE:
        //     newState = addOrUpdateDoc(state, action.payload, action.attachments);
        //     return newState;
        // case ATTACHMENT_REMOVE_IMAGE:
        //     newState = removeDoc(state, action.payload, action.attachments);
        //     return newState;
        // case ATTACHMENT_STARTED_UPLOADING:
        //     newState = updateDoc(state, action.payload, action.attachments);
        //     return newState;
        // case ATTACHMENT_UPLOADED:
        //     newState = uploadSuccess(state, action.payload, action.attachments);
        //     return newState;
        default:
            return state;
    }
};

export default reducer;
