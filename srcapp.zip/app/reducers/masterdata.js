//import { entities } from 'app/api/mockData';
import {
    MASTERDATA_LOADLATEST_STARTED,
    MASTERDATA_LOADLATEST_FAILURE,
    MASTERDATA_LOADLATEST_SUCCESS,
    MASTERDATA_CLEAR,
} from 'app/actions/masterdata';

const initialState = {
    loading: false,
    services: [],
    violationTypes: [],
    dataLookups: [],
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case MASTERDATA_LOADLATEST_STARTED:
            return { ...state, loading: true };
        case MASTERDATA_LOADLATEST_SUCCESS:
            return { loading: false, ...action.data };
        case MASTERDATA_CLEAR:
            return { ...initialState };
        default:
            return state;
    }
};

export default reducer;
