import update, { extend } from 'immutability-helper';
import { SET_ADDRESS, SET_SEARCH_KEY, SEARCH, SET_FILTER, SEARCH_SUCCESS, SEARCH_FAILURE, RESET_SEARCH, SET_SEARCHDATE } from 'app/actions/search';

const initialState = {
    isLoading: false,
    results: [],
    searchKey: null,
    filter: { type: 'referenceNumber' },
    searchFromDate: new Date(),
    searchToDate: new Date(),
    address: {},
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case SET_SEARCH_KEY:
            return { ...state, searchKey: action.searchKey };
        case SET_ADDRESS:
            return { ...state, address: action.zonesectorplot };
        case SET_FILTER:
            return { ...state, filter: action.filter };
        case SET_SEARCHDATE:
            return { ...state, fromDate: action.fromDate, toDate: action.toDate };
        case SEARCH:
            return { ...state, searchKey: action.searchKey, filter: action.filter, isLoading: true, results: [] };
        case SEARCH_SUCCESS:
            return { ...state, isLoading: false, results: action.results };
        case SEARCH_FAILURE:
            return { ...state, isLoading: false };
        case RESET_SEARCH:
            return { ...state, ...initialState, filter: state.filter };
        default:
            return state;
    }
};

export default reducer;
