import update, { extend } from 'immutability-helper';
import { TASK_DETAILS_DIALOG_SHOW, TASK_DETAILS_DIALOG_HIDE } from 'app/actions/tasks';
import { SETTINGS_CHANGE_ENVIRONMENT } from 'app/actions/settings';
const initialState = { currentTaskRef: null, envState: {}, vertionNumber: 1, showDetailsDialog: false, taskdetails: null, title: '' };

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case TASK_DETAILS_DIALOG_SHOW:
            return update(state, {
                showDetailsDialog: { $set: true },
                taskdetails: { $set: action.payload.taskDetails },
                title: { $set: action.payload.title },
            });
        case TASK_DETAILS_DIALOG_HIDE:
            return update(state, { showDetailsDialog: { $set: false }, taskdetails: { $set: null }, title: { $set: '' } });

        case SETTINGS_CHANGE_ENVIRONMENT:
            const backupState = {};
            backupState[action.environment] = { ...state, envState: {} };
            if (state.envState && typeof state.envState[action.newenvironment] !== 'undefined') {
                return { ...state.envState[action.newenvironment], envState: backupState };
            }
            return { ...initialState, envState: { ...(state.envState || {}), ...backupState } };

        default:
            return state;
    }
};

export default reducer;
