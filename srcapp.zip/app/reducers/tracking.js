import update from 'immutability-helper';
import { DEVICE_LOCATION_UPDATE, GEO_UPDATE, TRACKING_LOCATION_UPDATE, TRACKING_APPSTATE_CHANGE } from 'app/actions/tracking';

const maxBacklog = 1000;
const initialState = {
    //lastEvent: undefined,
    //backlog: [],
    // geoFencing: true,
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case TRACKING_LOCATION_UPDATE:
            return {
                ...state,
                lastEvent: { ...state.lastEvent, appState: action.event.appState, userId: action.event.userId, deviceInfo: action.event.deviceInfo },
            };
        case GEO_UPDATE:
            return update(state, {
                geoFencing: { $set: action.event },
            });
        case DEVICE_LOCATION_UPDATE:
            if (!state.lastEvent)
                return update(state, {
                    lastEvent: {
                        $set: {
                            location: action.event,
                        },
                    },
                });
            else
                return update(state, {
                    lastEvent: {
                        location: { $set: action.event },
                    },
                });

        case TRACKING_APPSTATE_CHANGE:
            return { ...state, appState: action.appState };
        default:
            return state;
    }
};

export default reducer;
