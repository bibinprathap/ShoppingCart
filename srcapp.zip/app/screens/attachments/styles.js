import { I18nManager } from 'react-native';
import EStyleSheet from 'react-native-extended-stylesheet';

export default EStyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    previewContainer: {
        flex: 1,
        marginBottom: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '$primaryLightBackground',
    },
    previewInnerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    previewNoImageSelectedText: {
        color: '$primaryMediumTextColor',
        textAlign: 'center',
        textAlignVertical: 'center',
        fontSize: '$primaryTextSM',
    },
    previewImage: {},
    addPictureButtonContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    addPictureButton: {
        padding: 10,
    },
    addPictureButtonIcon: {
        color: '$primaryWhite',
    },
    imageListContainer: {
        flex: 1,
        maxHeight: 100,
        paddingVertical: 0,
        paddingHorizontal: 5,
        backgroundColor: '$primaryDarkBackground',
        flexDirection: 'row',
    },
    doneButton: {
        backgroundColor: '$primaryLightButtonBackground',
        alignSelf: 'center',
        width: '98%',
        marginVertical: 5,
        paddingVertical: 5,
        fontFamily: '$primaryFontNormal',
        fontSize: '$primaryTextXS',
    },
    imageList: {},
    pdf: {
        flex: 1,
        width: 500,
        height: 500,
    },
    backgroundVideo: {
        position: 'absolute',
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
    },
});
