import React, { useState } from 'react';
import { View, Text, TouchableNativeFeedback } from 'react-native';
import { Icon, Modal, AttachmentList } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { Attachments } from 'app/screens';

export default function(props) {
    const [isDialogVisible, toggleDialog] = useState(false);
    const [selectedAttachment, selectAttachment] = useState(undefined);
    const { editable, attachments } = props;

    const handleCameraPressed = () => {
        toggleDialog(!isDialogVisible);
    };

    const handleOnClose = () => {
        const { onClose } = props;
        toggleDialog(false);
        if (typeof onClose === 'function') onClose();
    };

    const handleOnCancel = () => {
        const { onCancel } = props;
        toggleDialog(false);
        if (typeof onCancel === 'function') onCancel();
    };

    const handleThumbnailPressed = doc => {
        selectAttachment(doc);
        toggleDialog(true);
    };

    const renderAddPictureButton = () => {
        return (
            <View style={styles.buttonContainer}>
                <TouchableNativeFeedback onPress={handleCameraPressed}>
                    <Icon type="MaterialCommunityIcons" name="camera" size={44} style={styles.icon} />
                </TouchableNativeFeedback>
            </View>
        );
    };
    if (isDialogVisible) {
        return (
            <Modal animationType="slide" transparent={false} visible={isDialogVisible} onRequestClose={handleOnCancel}>
                <Attachments {...props} onClose={handleOnClose} selectedAttachment={selectedAttachment} />
            </Modal>
        );
    } else {
        if (!attachments || !attachments.length) {
            return (
                <View style={styles.outerContainerNoAttachment}>
                    {editable && <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>{renderAddPictureButton()}</View>}
                </View>
            );
        } else {
            return (
                <View style={styles.outerContainerNoAttachment}>
                    <View style={styles.outerContainerWithAttachment}>
                        <AttachmentList {...props} onPress={handleThumbnailPressed} />
                    </View>
                    <View style={styles.buttonWithAttachmentsContainer}>{editable && renderAddPictureButton()}</View>
                </View>
            );
        }
    }
}

const styles = EStyleSheet.create({
    outerContainerNoAttachment: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 10,
    },
    outerContainerWithAttachment: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonWithAttachmentsContainer: {
        flex: 1,
        maxWidth: 70,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    buttonContainer: {
        borderColor: '$primaryBorderColor',
        borderWidth: '$primaryBorderThin',
        padding: 5,
        borderRadius: 10,
    },
    emptyAttachmentListMessage: {
        fontSize: '$primaryTextSM',
        color: '$primaryDarkTextColor',
    },
});
