/* @flow */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { strings } from 'app/config/i18n/i18n';
import { connect } from 'react-redux';
import { View, StyleSheet, Platform } from 'react-native';
import { Drawer, DefaultTheme, withTheme, Switch, TouchableRipple, Text, Colors } from 'react-native-paper';
import { authLogout } from 'app/actions/auth';
import { mainStackDefinition } from 'app/config/routs/defs';
import { Icon } from 'app/components';

class DrawerMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedItemKey: mainStackDefinition.initialRoute,
        };
    }

    handleMenuPress = item => {
        nav = this.props.navigation;
        this.setState({ ...this.state, selectedItemKey: item.key });
        nav.closeDrawer();
        nav.navigate(item.key);
    };

    handleLogout = () => {
        this.props.dispatch(authLogout());
        this.props.navigation.navigate('auth'); //todo: handle this in some central location, perhaps on app root that is connected to redux
    };

    render() {
        const { colors } = DefaultTheme;
        const selectedItem = this.state.selectedItemKey;
        return (
            <View style={[styles.drawerContent, { backgroundColor: colors.surface }]}>
                <Drawer.Section>
                    {mainStackDefinition.routes.map(item => {
                        if (item.displayInDrawer === true)
                            return (
                                <View key={item.key} onPress={() => this.handleMenuPress(item)} style={styles.itemContainer}>
                                    <Text style={styles.itemText}>{item.subtitle || item.title}</Text>
                                    <Icon {...item.icon} size={24} />
                                </View>
                            );
                    })}
                </Drawer.Section>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    drawerContent: {
        flex: 1,
        paddingTop: Platform.OS === 'android' ? 25 : 22,
    },
    itemContainer: {
        flexDirection: 'row',
        margin: 10,
    },
    itemText: {
        fontSize: 18,
        marginEnd: 10,
    },

    settings: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        paddingHorizontal: 16,
    },
});

export default DrawerMenu;
