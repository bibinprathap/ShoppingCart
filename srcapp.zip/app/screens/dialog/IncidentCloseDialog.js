import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { HeaderGeneric, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { AttachmentListWithDialog } from 'app/screens';

export default class IncidentCloseDialog extends Component {
    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    handleOnAddAttachment = attachment => {
        console.log(attachment);
        //const newState = { attachmentList: [...this.state.attachmentList, attachment] };
        //this.updateState(newState);
    };
    handleOnRemoveAttachment = () => {};
    handleFieldChange = async (value, name) => {};

    render() {
        const { isVisible, taskdetails, title, remarks } = this.props;
        const attachmentList = [];

        if (!isVisible || !taskdetails) return null;
        const titleText = title || strings('requestClose');
        return (
            <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                <HeaderGeneric title={titleText} backAction={this.handleOnRequestClose} />
                <SafeAreaView style={{ flex: 1 }}>
                    <View style={styles.container}>
                        <View style={styles.formContainer}>
                            <Text style={styles.label}> {strings('attachments')}</Text>
                            <View style={styles.fieldContainer}>
                                <AttachmentListWithDialog
                                    editable={true}
                                    onAdd={this.handleOnAddAttachment}
                                    onRemove={this.handleOnRemoveAttachment}
                                    attachments={attachmentList}
                                />
                            </View>
                            <Text style={styles.label}> {strings('remarks')}</Text>
                            <View style={styles.fieldContainer}>
                                <TextInput
                                    style={styles.input}
                                    placeholder={strings('remarks')}
                                    value={remarks}
                                    editable={true}
                                    onChangeText={val => handleFieldChange(val, 'remarks')}
                                    autoCorrect={false}
                                    autoCapitalize="sentences"
                                    autoFocus={false}
                                    multiline={true}
                                    textAlignVertical={'top'}
                                />
                            </View>

                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
                                <TouchableOpacity style={styles.button}>
                                    <Text style={styles.buttonText}>{strings('save')}</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={[styles.button, styles.buttonCancel]}>
                                    <Text style={styles.buttonText}>{strings('cancel')}</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </SafeAreaView>
            </Modal>
        );
    }
}

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        marginBottom: 65,
    },
    formContainer: {
        padding: 10,
        backgroundColor: '$primaryLightBackground',
        marginTop: 5,
        borderRadius: 5,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
    },
    fieldContainer: {
        flexDirection: 'row',
        backgroundColor: '$primaryLightBackground',
        justifyContent: 'center',
        marginTop: 5,
        marginBottom: 15,
        borderRadius: 5,
        padding: 10,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryLightBorder',
    },
    input: {
        flex: 1,
        color: '$primaryDarkTextColor',
        backgroundColor: '$primaryWhite',
        alignItems: 'flex-start',
        borderRadius: 4,
        elevation: 1,
        borderWidth: '$primaryBorderThin',
        borderColor: '$primaryBorderColor',
        padding: 10,
        height: 100,
    },
    label: {
        fontSize: '$primaryTextXS',
        color: '$primaryDarkTextColor',
    },
    errorLabel: {
        fontSize: '$primaryTextXS',
        color: 'red',
        marginLeft: 10,
    },
    button: {
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 10,
        margin: 10,
        backgroundColor: '$primaryLightButtonBackground',
    },
    buttonCancel: {
        backgroundColor: '$primaryDarkIconbuttonBackground',
    },
    buttonText: {
        fontSize: '$primaryTextSM',
        fontFamily: '$primaryFontNormal',
        color: '$primaryWhite',
    },
});
