import React, { Component } from 'react';
import { connect } from 'react-redux';
import { View, ActivityIndicator, Text, TouchableOpacity } from 'react-native';
import { hideInspectionDialog, inspectionDialogNoPendingTabReload } from 'app/actions/inspectionDialog';
import { InspectionViewTopHeader, InspectionView, Modal, Icon } from 'app/components';
import { InspectionStepsDialog, ViolatorInfoDialog, ViolatorsListDialog } from 'app/screens';
import { strings } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { tasksTabLoad } from 'app/actions/generic';

class InspectionDialog extends Component {
    constructor(props) {
        super(props);
        this.state = { isShowing: props.isShowing, isShowingSteps: false, isShowingViolatorDetailsorViolatorsList: false };
    }

    handleOnRequestClose = () => {
        this.props.dispatch(hideInspectionDialog());
        const { dispatch, tabbedListViewData, selectedTab, inspectionDialogRefNumber, inspectionDialogPendingTabReload } = this.props;
        if (inspectionDialogRefNumber != null || inspectionDialogPendingTabReload) {
            const tabData = tabbedListViewData[selectedTab];
            const { startDate, endDate, fixedFilter } = tabData;
            const isOrderByDesc = tabData.isOrderByDesc;
            if (!tabData) {
            } else {
                const payload = { tabKey: selectedTab, startDate, endDate, fixedFilter, reset: true, isOrderByDesc };
                dispatch(tasksTabLoad(payload));
                dispatch(inspectionDialogNoPendingTabReload());
            }
        }
    };

    handleStepsModalAction = () => {
        this.setState({ isShowingSteps: !this.state.isShowingSteps });
    };
    handleViolatorModalAction = () => {
        this.setState({ isShowingViolatorDetailsorViolatorsList: !this.state.isShowingViolatorDetailsorViolatorsList });
    };

    renderCustomActions = () => {
        const { inspectionContainer } = this.props;
        const steps = inspectionContainer && inspectionContainer.inspection && inspectionContainer.inspection.steps;
        const violator =
            inspectionContainer &&
            inspectionContainer.inspection &&
            inspectionContainer.inspection.violators &&
            inspectionContainer.inspection.violators.length > 0 &&
            inspectionContainer.inspection.violators[0];

        return (
            <View style={{ flexDirection: 'row' }}>
                {(steps && (
                    <TouchableOpacity onPress={this.handleStepsModalAction}>
                        <Icon type="MaterialCommunityIcons" style={styles.iconWrapper} color="#FFFFFF" name={'timeline-text'} size={24} />
                    </TouchableOpacity>
                )) ||
                    null}
                {(violator && (
                    <Icon
                        type="MaterialCommunityIcons"
                        style={[styles.iconWrapper]}
                        onPress={this.handleViolatorModalAction}
                        color="#FFFFFF"
                        name={'account'}
                        size={24}
                    />
                )) ||
                    null}
            </View>
        );
    };
    render() {
        const { isShowing, inspectionContainer, title } = this.props;
        if (!isShowing) return null;
        if (!inspectionContainer) return null;
        const { isShowingSteps, isShowingViolatorDetailsorViolatorsList } = this.state;

        const steps = inspectionContainer && inspectionContainer.inspection && inspectionContainer.inspection.steps;
        // const steps = [
        //     {
        //         titleE: 'START',
        //         titleA: 'بداية',
        //         comments: 'STARTED REMARK STARTED REMARKSTARTED REMARKSTARTED REMARKSTARTED REMARK',
        //         createdDate: addDays(0),
        //     },
        //     {
        //         titleE: 'CONFIRM',
        //         titleA: 'بداية',
        //         comments: 'CONFIRMED  REMARK CONFIRMED  REMARKCONFIRMED  REMARKCONFIRMED  REMARKCONFIRMED  REMARK',
        //         createdDate: addDays(2),
        //     },
        //     { titleE: 'DUPLICATE REVIEW', titleA: 'مراجعة مزدوجة', comments: 'DUPLICATE REVIEW REMARK', createdDate: addDays(3) },
        //     { titleE: 'SUPERVISOR REVIEW', titleA: 'مراجعة المشرف', comments: 'SUPERVISOR REVIEW REMARK', createdDate: addDays(4) },
        // ];

        return (
            <View style={{ flex: 1 }}>
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <InspectionViewTopHeader
                        backAction={this.handleOnRequestClose}
                        renderCustomActions={this.renderCustomActions}
                        currentInspection={inspectionContainer.inspection}
                        hideSubTitle={true}
                        title={title}
                    />

                    {this.props.creatingFlag ? (
                        <View style={styles.wrapper}>
                            <ActivityIndicator size={'large'} />
                        </View>
                    ) : (
                        <InspectionView
                            showInspCommonFieldsAtTop={true}
                            inspection={inspectionContainer}
                            {...this.props}
                            requestClose={this.handleOnRequestClose}
                            activeProfileUserId={this.props.activeProfileUserId}
                        />
                    )}
                </Modal>
                {steps && (
                    <InspectionStepsDialog
                        isVisible={isShowingSteps}
                        steps={steps}
                        title={strings('inspectionStepsDetails')}
                        currentInspection={inspectionContainer.inspection}
                        onRequestClose={this.handleStepsModalAction}
                    />
                )}
                {inspectionContainer.inspection.violators && inspectionContainer.inspection.violators.length == 1 && (
                    <ViolatorInfoDialog
                        isVisible={isShowingViolatorDetailsorViolatorsList}
                        violator={inspectionContainer.inspection.violators[0]}
                        onRequestClose={this.handleViolatorModalAction}
                    />
                )}
                {inspectionContainer.inspection.violators && inspectionContainer.inspection.violators.length > 1 && (
                    <ViolatorsListDialog
                        isVisible={isShowingViolatorDetailsorViolatorsList}
                        violators={inspectionContainer.inspection.violators}
                        onRequestClose={this.handleViolatorModalAction}
                    />
                )}
            </View>
        );
    }
}

mapStateToProps = state => {
    const { isShowing, refNumber, inspection, title } = state.inspectionDialog;
    const inspectionToUse = inspection ? inspection : state.inspections.history[refNumber];
    const tasksTabsObj = state.generic.tasksTabs || {};

    return {
        tabbedListViewData: tasksTabsObj.tabs,
        selectedTab: tasksTabsObj.selectedTab,
        isShowing,
        inspectionContainer: inspectionToUse,
        title,
        activeProfileUserId: state.auth.activeProfileUserId,
        creatingFlag: state.inspections.creatingFlag,
        dataLookups: state.masterdata.dataLookups,
        inspectionDialogRefNumber: state.inspectionDialog.refNumber,
        inspectionDialogPendingTabReload: state.inspectionDialog.pendingTabReload,
        // tasksTabs: state.generic.tasksTabs,
    };
};
export default connect(mapStateToProps)(InspectionDialog);

const styles = EStyleSheet.create({
    wrapper: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    iconWrapper: {
        padding: 10,
    },
});
