import React, { Component } from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { InspectionViewTopHeader, Modal, StepsTimeLine } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
export default class InspectionStepsDialog extends Component {
    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    render() {
        const { isVisible, steps, title, currentInspection } = this.props;

        return (
            <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                <InspectionViewTopHeader
                    backAction={this.handleOnRequestClose}
                    renderCustomActions={this.renderCustomActions}
                    currentInspection={currentInspection}
                    title={title}
                />
                <SafeAreaView style={{ flex: 1 }}>
                    <View style={{ flex: 1, marginBottom: 65 }}>
                        <StepsTimeLine steps={steps} />
                    </View>
                </SafeAreaView>
            </Modal>
        );
    }
}

const styles = EStyleSheet.create({});
