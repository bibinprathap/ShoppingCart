import React, { Component } from 'react';
import { View, FlatList, TouchableOpacity, Text } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric } from 'app/components';
import { SimpleItemInfo, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
export default class ItemDetailDialog extends Component {
    handleOnRequestClose = (event, item) => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose(item);
    };

    render() {
        const { isVisible, item, title, displayFields } = this.props;
        if (!isVisible || !displayFields) return null;
        return (
            <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                <HeaderGeneric backAction={this.handleOnRequestClose} title={title || strings('back')} />
                <View style={styles.wrapper}>
                    <View style={styles.itemContainer}>
                        <SimpleItemInfo item={item} displayFields={displayFields} hideDetailsButton={true} />
                    </View>
                </View>
            </Modal>
        );
    }
}

const styles = EStyleSheet.create({
    wrapper: {
        margin: 10,
        flex: 1,
    },
    itemContainer: {
        marginVertical: 2,
        flex: 1,
    },
});
