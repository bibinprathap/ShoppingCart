import React, { Component } from 'react';
import { View, FlatList, TouchableOpacity } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric } from 'app/components';
import { SimpleItemInfo, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';

export default class ItemSelectorDialog extends Component {
    renderItem = ({ index, item }) => {
        const handleOnPress = () => {
            this.handleOnRequestClose(null, item);
        };

        return (
            <View style={styles.itemContainer} key={index}>
                <TouchableOpacity style={{ flex: 1 }} onPress={handleOnPress}>
                    <SimpleItemInfo item={item} displayFields={this.props.displayFields} detailedDisplayFields={this.props.detailedDisplayFields} />
                </TouchableOpacity>
            </View>
        );
    };

    handleOnRequestClose = (event, item) => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose(item);
    };

    //<ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps="always"></ScrollView>
    render() {
        const { isVisible, items, title, displayFields } = this.props;
        if (!isVisible || !displayFields) return null;
        else {
            return (
                <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric backAction={this.handleOnRequestClose} title={title || strings('select')} />
                    <View style={styles.wrapper}>
                        <FlatList
                            initialNumToRender={25}
                            data={items}
                            keyExtractor={(item, index) => index.toString()}
                            renderItem={this.renderItem}
                        />
                    </View>
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({
    wrapper: {
        margin: 10,
    },
    itemContainer: {
        marginVertical: 2,
    },
});
