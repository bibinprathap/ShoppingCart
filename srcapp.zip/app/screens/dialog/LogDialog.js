import React, { Component, useState } from 'react';
import moment from 'moment';
import { _ } from 'lodash';
import { View, ScrollView, TouchableOpacity, FlatList, Text, Alert, Clipboard, Picker, ToastAndroid } from 'react-native';
import { connect } from 'react-redux';
import { strings } from 'app/config/i18n/i18n';
import * as Animatable from 'react-native-animatable';
import EStyleSheet from 'react-native-extended-stylesheet';
import { HeaderGeneric, Loader, Icon, Modal } from 'app/components';
import { clearLogs, logSetLimit, setLogLevel } from 'app/actions/generic';

const copyToClipboard = details => {
    ToastAndroid.show('Copied to clipboard', ToastAndroid.SHORT);
    Clipboard.setString(JSON.stringify(details));
};

const LogDetailsRightMenu = ({ details }) => (
    <TouchableOpacity onPress={() => copyToClipboard(details)}>
        <Icon type="MaterialCommunityIcons" name="content-copy" style={styles.icon} />
    </TouchableOpacity>
);

const RenderItem = ({ item, isAPILog, isDoc }) => {
    const [modalVisible, setVisible] = useState(false);

    const { details, message } = item;
    let response = (details && details.response) || null;
    let code = null;
    let url = null;
    let jsonData = null;
    let loggedTime = null;
    let requestData = null;

    if (isDoc) {
        url = item.path;
        jsonData = item;
        loggedTime = moment(item.uploadedDate).format('YYYY-MM-DD HH:mm:ss');
    } else if (isAPILog && response) {
        let { config, data, status } = response;
        url = config.url;
        loggedTime = item.loggedTime;
        requestData = config.data || null;
        code = status;
        jsonData = data;
    } else {
        loggedTime = item.loggedTime;
        jsonData = details;
    }

    if (modalVisible) {
        if (jsonData && typeof jsonData === 'string') {
            jsonData = JSON.parse(jsonData);
        }

        if (jsonData) {
            jsonData = JSON.stringify(jsonData, null, 4);
        }

        if (requestData && typeof requestData === 'string') {
            requestData = JSON.parse(requestData);
        }

        if (requestData) {
            requestData = JSON.stringify(requestData, null, 4);
        }
    }

    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.item} onPress={() => setVisible(true)}>
                {isAPILog && <Text style={[styles.txt, styles.code]}>{code}</Text>}
                {isDoc && (
                    <View style={styles.code}>
                        <Loader size={14} loading={item.uploading} />
                        {!item.uploading && !item.uploaded && <Icon type="MaterialCommunityIcons" name="alert" size={18} color={'red'} />}
                    </View>
                )}
                <View style={styles.messageWrapper}>
                    {(message && <Text style={[styles.txt, styles.message]}>{message}</Text>) || null}
                    {url && <Text style={[styles.txt, styles.message]}>{url}</Text>}
                </View>
                <Text style={styles.time}>{loggedTime}</Text>
            </TouchableOpacity>
            <Modal
                animationType="slide"
                transparent={false}
                visible={modalVisible}
                onRequestClose={() => {
                    setVisible(false);
                }}
            >
                <HeaderGeneric
                    backAction={() => setVisible(false)}
                    title={'Error Details'}
                    renderRightComponent={() => <LogDetailsRightMenu details={details} />}
                />
                <ScrollView style={[styles.containerInner, { padding: 5 }]}>
                    {url && (
                        <View>
                            <View style={styles.titleWrapper}>
                                <Text style={styles.title}>URL</Text>
                            </View>
                            <View style={styles.content}>
                                <Text style={styles.txt}>{url}</Text>
                            </View>
                        </View>
                    )}
                    {requestData && (
                        <View>
                            <View style={styles.titleWrapper}>
                                <Text style={styles.title}>Request</Text>
                            </View>
                            <View style={styles.content}>
                                <Text style={styles.txt}>{requestData}</Text>
                            </View>
                        </View>
                    )}
                    <View style={{ marginBottom: 20 }}>
                        <View style={styles.titleWrapper}>
                            <Text style={styles.title}>{!requestData ? 'Details' : 'Response'}</Text>
                        </View>
                        <View style={styles.content}>
                            <Text style={styles.txt}>{jsonData}</Text>
                        </View>
                    </View>
                </ScrollView>
            </Modal>
        </View>
    );
};

const LogContent = ({ items, isAPILog, isDoc }) => (
    <View style={styles.container}>
        <View style={styles.item}>
            {isAPILog && <Text style={[styles.code, styles.headerText]}>Code</Text>}
            {isDoc && <Text style={[styles.code, styles.headerText]}>Status</Text>}
            <Text style={[styles.message, styles.headerText]}>{isDoc ? 'Path' : 'Message'}</Text>
            <Text style={[styles.time, styles.headerText]}>Time</Text>
        </View>
        <FlatList
            data={items}
            renderItem={({ item }) => <RenderItem item={item} isAPILog={isAPILog} isDoc={isDoc} />}
            keyExtractor={(item, idx) => idx.toString()}
        />
    </View>
);

const LogDialogRightMenu = ({ clearLogs, setLimit, limit, setErrorLogLevel, logLevel, activeTab }) => {
    let currentLimit = limit.toString();
    return (
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
            {activeTab === 'api' && (
                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' }}>
                    <Text style={styles.label}>Log level:</Text>
                    <Picker selectedValue={logLevel} style={[styles.picker, { width: 110 }]} onValueChange={setErrorLogLevel}>
                        <Picker.Item label="Error" value="error" />
                        <Picker.Item label="Debug" value="debug" />
                    </Picker>
                </View>
            )}
            <Text style={styles.label}>Limit:</Text>
            <Picker selectedValue={currentLimit} style={styles.picker} onValueChange={setLimit}>
                <Picker.Item label="25" value="25" />
                <Picker.Item label="50" value="50" />
                <Picker.Item label="100" value="100" />
            </Picker>
            <TouchableOpacity onPress={clearLogs}>
                <Icon type="MaterialCommunityIcons" name="delete" style={styles.icon} />
            </TouchableOpacity>
        </View>
    );
};

class LogDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeTab: 'api',
            routes: [
                { key: 'api', title: 'API logs' },
                { key: 'js', title: 'Javascript logs' },
                { key: 'attachment', title: 'Pending Uploads' },
            ],
        };
        this.logDialogRightMenuItems = this.logDialogRightMenuItems.bind(this);
    }
    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    clearLogs = () => {
        const { activeTab } = this.state;
        Alert.alert(
            strings('remove'),
            'Are you sure you want remove this list?',
            [
                { text: strings('no'), style: 'cancel', onPress: () => null },
                {
                    text: strings('yes'),
                    onPress: () => {
                        this.props.dispatch(clearLogs(activeTab));
                    },
                },
            ],
            { cancelable: true }
        );
    };
    setLimit = limit => {
        const { activeTab } = this.state;
        this.props.dispatch(logSetLimit(activeTab, limit));
    };

    setErrorLogLevel = logLevel => {
        this.props.dispatch(setLogLevel(logLevel));
    };

    logDialogRightMenuItems = () => {
        const { logs } = this.props;
        const { activeTab } = this.state;
        if (this.state.activeTab === 'attachment') return null;
        const limit = activeTab === 'api' ? logs.apiErrorsLimit : logs.jsErrorsLimit;
        const logLevel = logs.logLevel || 'error';

        return (
            <LogDialogRightMenu
                limit={limit || 25}
                clearLogs={this.clearLogs}
                setLimit={this.setLimit}
                logLevel={logLevel}
                activeTab={activeTab}
                setErrorLogLevel={this.setErrorLogLevel}
            />
        );
    };

    render() {
        const { isVisible, logs } = this.props;
        const { activeTab } = this.state;
        const pendingUploadDocs = Object.values(this.props.pendingUploadDocs);

        //if (!isVisible) return null;
        let tabConent = null;
        switch (activeTab) {
            case 'api':
                tabConent = <LogContent items={logs.apiErrors} isAPILog={true} />;
                break;
            case 'js':
                tabConent = <LogContent items={logs.jsErrors} />;
                break;
            case 'attachment':
                tabConent = <LogContent isDoc={true} items={pendingUploadDocs} />;
                break;
        }

        return (
            <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                <View style={{ flex: 1 }}>
                    <HeaderGeneric
                        title={'Error Details'}
                        backAction={this.handleOnRequestClose}
                        renderRightComponent={this.logDialogRightMenuItems}
                    />
                    <View style={styles.container}>
                        <View style={styles.tabWrapper}>
                            {this.state.routes.map((route, idx) => {
                                const tabStyle = route.key === activeTab ? [styles.tab, styles.selectedTab] : styles.tab;
                                return (
                                    <TouchableOpacity key={route.key} style={tabStyle} onPress={() => this.setState({ activeTab: route.key })}>
                                        <Text style={styles.tabText}>{route.title}</Text>
                                    </TouchableOpacity>
                                );
                            })}
                        </View>
                        <Animatable.View animation={'fadeIn'} style={styles.containerInner}>
                            {tabConent}
                        </Animatable.View>
                    </View>
                </View>
            </Modal>
        );
    }
}

mapStateToProps = (state, ownProps) => {
    return {
        logs: state.generic.logs,
        pendingUploadDocs: state.attachments.pendingUploadDocs,
    };
};

export default connect(mapStateToProps)(LogDialog);

const styles = EStyleSheet.create({
    container: {
        flex: 1,
        marginTop: 1,
        backgroundColor: '$primaryLightBackground',
    },
    containerInner: {
        flex: 1,
        backgroundColor: '$primaryLightBackground',
    },
    tabWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    icon: {
        color: '$primaryWhite',
        fontSize: 24,
        marginHorizontal: 10,
    },
    tab: {
        backgroundColor: '$primaryHeaderColor',
        flex: 1,
        justifyContent: 'center',
        paddingVertical: 10,
    },
    selectedTab: {
        borderBottomWidth: 2,
        borderBottomColor: '$primarySuccessColor',
    },
    tabText: {
        fontFamily: '$primaryFontNormal',
        alignSelf: 'center',
        color: '$primaryWhite',
    },
    item: {
        width: '100%',
        paddingVertical: 10,
        paddingHorizontal: 20,
        marginVertical: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: '$primaryWhite',
        borderBottomWidth: 1,
        borderColor: '$primaryBorderColor',
    },
    content: {
        padding: 10,
        backgroundColor: '$primaryWhite',
        margin: 5,
        borderWidth: 1,
        borderColor: '$primaryLightBorder',
    },
    txt: {
        fontSize: '$primaryTextXS',
    },
    code: {
        width: 50,
        justifyContent: 'center',
    },
    time: {
        width: 100,
        justifyContent: 'center',
    },
    message: {
        flex: 1,
    },
    messageWrapper: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        paddingHorizontal: 5,
    },
    headerText: {
        fontSize: '$primaryTextXS',
        fontWeight: 'bold',
    },
    titleWrapper: {
        padding: 10,
        backgroundColor: '$primaryLightBackground',
    },
    title: {
        fontSize: '$primaryTextXS',
        fontWeight: 'bold',
    },
    label: {
        color: '$primaryWhite',
        fontSize: '$primaryTextXS',
    },
    picker: {
        width: 95,
        height: 30,
        color: '$primaryWhite',
        alignItems: 'center',
        justifyContent: 'center',
    },
});
