import React, { Component, useState } from 'react';
import { View, Text, ScrollView, Image, TouchableNativeFeedback } from 'react-native';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import { HeaderGeneric, Modal, Signature } from 'app/components';
import { connect } from 'react-redux';
import { getLocation } from 'app/api/helperServices/geolocation';
import { attachmentsHelper, inspectionsHelper } from 'app/api/helperServices';
import { addImageAttachment } from 'app/actions/attachments';
import alertsHelper from 'app/api/helperServices/alerts';
class SignatureDialog extends Component {
    onRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    onChange = async (signature) => {
        const { dispatch, inspection, environment, authCode, userData, onAddSignature, violator } = this.props;
        const violatorId = (violator && violator.violatorId) || null;
        const violatorType = (violator && violator.violatorType) || null;
        if (signature && signature.pathName) {
            const path = `file://${signature.pathName}`;
            const coords = await getLocation();
            //const address = await api.getAddress(coords);
            const { currentVisit } = inspectionsHelper.getCurrentVisit(inspection);

            Image.getSize(
                path,
                (width, height) => {
                    const imageObj = {
                        path,
                        height,
                        width,
                    };
                    attachmentsHelper
                        .prepareNewImageForAttachment({
                            contents: imageObj,
                            quality: 1,
                            id: null,
                            inspInstanceId: currentVisit.inspectionId,
                            parentInspectionId: null,
                            refNumber: inspection.refNumber,
                            coords,
                            violatorId,
                        })
                        .then((newAttachment) => {
                            newAttachment.extension = 'png';
                            dispatch(addImageAttachment(newAttachment, true)).then(() => {
                                attachmentsHelper.startUpload(newAttachment, environment, authCode, userData.uuid, 'ConfirmViolatorSignature', {
                                    businessEntityConst: violatorType,
                                    businessEntityReferenceId: violatorId,
                                });
                            });
                            if (typeof onAddSignature === 'function') onAddSignature(newAttachment);
                        });
                },
                (error) => {
                    alertsHelper.show('error', 'Error', strings('unknown_error'));
                }
            );
        }
    };

    render() {
        const { visible = false, reconciliationAgreement, editable = true, value } = this.props;

        const config = {
            labelSaveE: strings('iAgree', { locale: 'en' }),
            labelSaveA: strings('iAgree', { locale: 'ar' }),
            labelResetE: strings('reset', { locale: 'en' }),
            labelResetA: strings('reset', { locale: 'ar' }),
        };

        const title = this.props.title ? this.props.title : strings('signature');
        if (visible) {
            return (
                <Modal animationType="slide" transparent={false} visible={visible} onRequestClose={this.onRequestClose}>
                    {/* <HeaderGeneric backAction={() => setModalVisible(false)} title={strings('reconciliation')} /> */}
                    <HeaderGeneric backAction={this.onRequestClose} title={title} />
                    <ScrollView style={styles.reconciliationWrapper}>
                        <View style={styles.agrementWrapper}>
                            <Text>{reconciliationAgreement}</Text>
                            <Text style={styles.signTitle}>{!editable ? strings('signature') : strings('signBelow')}</Text>
                        </View>
                        <Signature editable={editable} onChange={this.onChange} value={value} config={config} />
                        {/* <ReconcileInfoForm editable={!reconciled} values={{ signature }} formName="reconcileInfo" onFormChange={handleReconcileInfoChange} /> */}
                    </ScrollView>
                </Modal>
            );
        } else return null;
    }
}

mapStateToProps = (state) => {
    return {
        environment: state.settings.environment,
        authCode: state.auth.authCode,
        userData: state.auth.userData,
    };
};

export default connect(mapStateToProps)(SignatureDialog);

const styles = EStyleSheet.create({
    reconciliationWrapper: {
        flex: 1,
        margin: 5,
    },
    agrementWrapper: {
        margin: 5,
    },
    signTitle: {
        fontSize: 14,
        marginTop: 15,
        fontWeight: 'bold',
    },
});
