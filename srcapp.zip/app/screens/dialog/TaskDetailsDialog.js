import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withNavigation } from 'react-navigation';
import { Attachments } from 'app/screens';
import { TaskDetails } from 'app/components';
import { hideTaskDetailsDialog } from 'app/actions/tasks';
import alertsHelper from 'app/api/helperServices/alerts';
import { getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import { inspectionsHelper } from 'app/api/helperServices';
import { setLoading, setLoaded } from 'app/actions/loader';
import { HeaderGeneric, Modal } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import EStyleSheet from 'react-native-extended-stylesheet';
import AppApi from 'app/api/real';
import { inspectionsTabLoad, tasksTabLoad } from 'app/actions/generic';
import { createNewInspectionFromTask } from 'app/actions/inspections';

const api = new AppApi();

class TaskDetailsDialog extends Component {
    constructor(props) {
        super(props);
        this.state = { isShowing: props.isShowing, attachmentModalVisible: false, selectedAttachment: null };
        this.toggleAttachmentDialog = this.toggleAttachmentDialog.bind(this);
        this.handleThumbnailPressed = this.handleThumbnailPressed.bind(this);
        //this.handleSourceInspectionClick = this.handleSourceInspectionClick.bind(this);
        //this.showSourceInspection = this.showSourceInspection.bind(this);
        this.onStartClick = this.onStartClick.bind(this);
    }
    toggleAttachmentDialog = () => {
        this.setState({
            attachmentModalVisible: false,
        });
    };
    handleThumbnailPressed = (doc) => {
        this.setState({ attachmentModalVisible: true, selectedAttachment: doc });
    };

    handleShowInspection = (sourceEvent, showDialog = false) => {
        const { taskdetails, navigation } = this.props;
        const { inspectionTypeDetail = {}, createdInspectionTypeDetail = {} } = taskdetails;
        const inspectionParams = {
            workflowInstanceId: taskdetails.workflowInstanceId,
            applicationNumber: taskdetails.applicationNumber,
            createdApplicationNumber: taskdetails.createdApplicationNumber,
            workflowApplicationNumber: taskdetails.workflowApplicationNumber,
            inspectionTypeId: inspectionTypeDetail.inspectionTypeId,
            workflowConst: inspectionTypeDetail.workflowConst,
            createdInspectionTypeId: createdInspectionTypeDetail.inspectionTypeId,
            createdWorkflowConst: createdInspectionTypeDetail.workflowConst,
            createdWorkflowConst: createdInspectionTypeDetail.workflowConst,
            taskType: taskdetails.taskType,
            source: sourceEvent,
        };

        if (createdInspectionTypeDetail.inspectionTypeConst == 'MimsSiteVisit') inspectionParams.createdWorkflowConst = 'Inspection';

        if (sourceEvent == 'applicationNumber') {
            delete inspectionParams.workflowApplicationNumber; //don't pass workflowApplicationNumber in this case, get the root inspection
        }
        inspectionsHelper.showInspection({ navigation, inspectionParams, onSuccess: this.handleOnRequestClose(), showDialog });
    };

    onShowSiteVisit = async () => {
        const { taskdetails, dispatch, navigation } = this.props;
        try {
            const { taskId, location } = taskdetails;
            if (taskdetails.taskStatusConst.toLowerCase() === 'new') {
                dispatch(setLoading({ options: { message: 'Starting site visit...' } }));
                console.log('going to create new inspection model');
                const newInspection = inspectionsHelper.createNew({ taskId, location });
                //console.log('created inspectionModel: ', newInspection);
                console.log('going to call api.createInspectionRecord inspectionModel: ', newInspection);
                const createdInspection = await api.createInspectionRecord(newInspection);
                console.log('created inspection record: ', createdInspection);
                if (!createdInspection) throw 'Site visit creation failed';
                inspectionsHelper.showInspection({ createdInspection, navigation, showDialog: true, onSuccess: this.handleOnRequestClose() });

                //await dispatch(createNewInspectionFromTask(payload));
                //this.handleOnRequestClose();

                //show dialog here
            } else if (taskdetails.taskStatusConst.toLowerCase() === 'inprogress') {
                this.handleShowInspection('issueNumber', true);
            }
        } catch (error) {
            alertsHelper.show('error', strings('failedToCloseTask'), getErrorMessageWithDetail(error));
        } finally {
            dispatch(setLoaded());
        }
    };

    handleOnRequestClose = () => {
        this.props.dispatch(hideTaskDetailsDialog());
    };
    startNewInspection = async (inspectionTypeDetail, taskId, navigation) => {};

    onStartClick = async () => {
        const { taskdetails, tasksTabs, dispatch, navigation } = this.props;
        const { inspectionTypeDetail = {}, taskId, location } = taskdetails;

        if (taskdetails.taskType && taskdetails.taskType.toLowerCase() === 'incident') {
            if (
                taskdetails.taskStatusConst.toLowerCase() === 'new' ||
                (taskdetails.taskStatusConst.toLowerCase() === 'inprogress' &&
                    taskdetails.createdInspectionTypeDetail &&
                    taskdetails.createdInspectionTypeDetail.inspectionTypeId == 1112)
            ) {
                try {
                    dispatch(setLoading({ options: { message: 'Starting tasks...' } }));
                    const newInspection = inspectionsHelper.createNew({ taskId, location, inspectionTypeDetail });
                    inspectionsHelper.showInspection({
                        createdInspection: newInspection,
                        navigation,
                        onSuccess: this.handleOnRequestClose(),
                    });
                } catch (error) {
                    alertsHelper.show('error', strings('failedToStartTask'), getErrorMessageWithDetail(error));
                } finally {
                    dispatch(setLoaded());
                }
            } else {
                this.handleShowInspection('issueNumber');
            }
        } else if (taskdetails.taskStatusConst.toLowerCase() !== 'new') {
            this.handleShowInspection('issueNumber');
            return;
        } else {
            try {
                dispatch(setLoading({ options: { message: 'Starting tasks...' } }));

                const beginTaskPayload = {
                    taskId,
                    inspectionTypeId: inspectionTypeDetail.inspectionTypeId,
                    workflowConst: inspectionTypeDetail.workflowConst,
                };
                const data = await api.beginTask(beginTaskPayload);
                const inspection = data.inspection;
                //uncommentbellowline for test
                //inspection.visits[1].def.def[0].name = 'resUnitOccupancyWarrantApproved';
                //inspection.visits[1].def.def[0].name = 'foodTruckAndOutdoorSeatingFollowUp';

                inspection.saved = false;
                inspection.locallySaved = false;
                inspectionsHelper.showInspection({ navigation, createdInspection: inspection, onSuccess: this.handleOnRequestClose() });
                // const { selectedTab, tabs } = tasksTabs;
                // const payload = {
                //     tabKey: selectedTab,
                //     startDate: tabs[selectedTab].startDate,
                //     endDate: tabs[selectedTab].endDate,
                //     reset: true,
                //     isOrderByDesc: tabs[selectedTab].isOrderByDesc,
                // };
                // dispatch(tasksTabLoad(payload));
            } catch (error) {
                alertsHelper.show('error', strings('failedToStartTask'), getErrorMessageWithDetail(error));
            } finally {
                dispatch(setLoaded());
            }
        }
    };

    render() {
        const { isShowing, taskdetails } = this.props;
        if (!isShowing || !taskdetails) return null;
        const canPerformTask = taskdetails.taskStatusConst && taskdetails.taskStatusConst.toLowerCase() !== 'completed';
        const canRequestClose =
            taskdetails.taskType &&
            taskdetails.taskType.toLowerCase() === 'incident' &&
            taskdetails.taskStatusConst &&
            (taskdetails.taskStatusConst.toLowerCase() === 'new' ||
                (taskdetails.taskStatusConst.toLowerCase() === 'inprogress' &&
                    taskdetails.createdInspectionTypeDetail &&
                    taskdetails.createdInspectionTypeDetail.workflowConst == '')); /* check if created inspection is SiteVisit*/

        return (
            <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                <Modal
                    animationType="slide"
                    transparent={false}
                    visible={this.state.attachmentModalVisible}
                    onRequestClose={this.toggleAttachmentDialog}
                >
                    <Attachments
                        attachments={taskdetails.attachements}
                        selectedAttachment={this.state.selectedAttachment}
                        editable={false}
                        onClose={this.toggleAttachmentDialog}
                        attachmentModalVisible={this.state.attachmentModalVisible}
                    />
                </Modal>
                <HeaderGeneric
                    backAction={this.handleOnRequestClose}
                    title={`${strings('taskDetails')} - ${localeProperty(taskdetails, 'taskTypeName')} - ${taskdetails.taskId}`}
                />
                <TaskDetails
                    onShowInspection={this.handleShowInspection}
                    onShowSiteVisit={this.onShowSiteVisit}
                    onStartClick={this.onStartClick}
                    onCreatedInspectionClick={this.onCreatedInspectionClick}
                    //onSourceInspectionClick={this.handleSourceInspectionClick}
                    taskdetails={taskdetails}
                    handleThumbnailPressed={this.handleThumbnailPressed}
                    onBackClick={this.handleOnRequestClose}
                    dashboardNavExpanded={false}
                    canPerformTask={canPerformTask}
                    canRequestClose={canRequestClose}
                />
            </Modal>
        );
    }
}

mapStateToProps = (state) => {
    const { title, taskdetails, showDetailsDialog } = state.tasks;
    return {
        title,
        taskdetails,
        isShowing: showDetailsDialog,
        inspectionsHistory: state.inspections.history,
        inspectionsTabs: state.generic.inspectionsTabs,
        // tasksTabs: state.generic.tasksTabs,
    };
};
export default connect(mapStateToProps)(withNavigation(TaskDetailsDialog));

const styles = EStyleSheet.create({
    modalBackground: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#00000040',
    },
});
