import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import { HeaderGeneric, Modal, DetailViolatorInfo } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
export default class ViolatorInfoDialog extends Component {
    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };

    render() {
        const { isVisible, violator } = this.props;

        if (!isVisible) return null;
        else {
            if (!violator) return null;
            const title = `${strings('violatorDetails')} - ${localeProperty(violator, 'title')}`;
            return (
                <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric title={title} backAction={this.handleOnRequestClose} />
                    <SafeAreaView style={{ flex: 1 }}>
                        <View
                            style={{
                                flex: 1,
                                marginBottom: 65 /*dirty fix, bottom of the content was missing even after using SafeAreaView */,
                            }}
                        >
                            <DetailViolatorInfo violator={violator} />
                        </View>
                    </SafeAreaView>
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({});
