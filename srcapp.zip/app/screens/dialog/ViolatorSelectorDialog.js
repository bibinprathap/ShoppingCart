import React, { Component } from 'react';
import { View, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { strings } from 'app/config/i18n/i18n';
import { ViolatorSelectorDialogHeader } from 'app/components';
import { SimpleViolatorInfo, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
export default class ViolatorSelectorDialog extends Component {
    renderViolatorItem = ({ index, item }) => {
        const handleOnPress = () => {
            this.handleOnRequestClose(null, item);
        };

        return (
            <View style={styles.violatorItemContainer} key={index}>
                <TouchableOpacity style={{ flex: 1 }} onPress={handleOnPress}>
                    <SimpleViolatorInfo violator={item} />
                </TouchableOpacity>
            </View>
        );
    };

    handleOnRequestClose = (event, selectedViolator) => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose(selectedViolator);
    };

    render() {
        const { isShowing, availableViolators, title } = this.props;
        if (!isShowing) return null;
        else {
            return (
                <Modal transparent={false} animationType="slide" visible={isShowing} onRequestClose={this.handleOnRequestClose}>
                    <ViolatorSelectorDialogHeader title={title || strings('selectViolator')} backAction={this.handleOnRequestClose} />
                    <SafeAreaView>
                        <View
                            style={{
                                marginBottom: 65 /*dirty fix, bottom of the content was missing even after using SafeAreaView */,
                            }}
                        >
                            <View style={{ margin: 10 }}>
                                <FlatList
                                    initialNumToRender={25}
                                    data={availableViolators}
                                    keyExtractor={(item, index) => index.toString()}
                                    renderItem={this.renderViolatorItem}
                                />
                            </View>
                        </View>
                    </SafeAreaView>
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({
    violatorItemContainer: {
        flex: 1,
        marginBottom: 5,
    },
});
