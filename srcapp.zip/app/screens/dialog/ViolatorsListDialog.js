import React, { Component } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { strings } from 'app/config/i18n/i18n';
import { HeaderGeneric, Modal } from 'app/components';
import EStyleSheet from 'react-native-extended-stylesheet';
import { SimpleViolatorInfo } from 'app/components';
import { ViolatorInfoDialog } from 'app/screens';
export default class ViolatorsListDialog extends Component {
    constructor(props) {
        super(props);
        this.state = { selectedViolator: null };
    }

    handleOnRequestClose = () => {
        const { onRequestClose } = this.props;
        if (typeof onRequestClose === 'function') onRequestClose();
    };
    setSelectedViolator = violator => {
        this.setState({ selectedViolator: violator });
    };
    onSimpleViolatorInfoDialogClose = violator => {
        this.setState({ selectedViolator: null });
    };

    render() {
        const { isVisible, violators } = this.props;

        const violatorsList = !violators
            ? null
            : violators.map(violator => {
                  debugger;
                  const isSelected = this.state.selectedViolator && this.state.selectedViolator.idNumber == violator.idNumber;
                  return (
                      <View styles={{ flexWrap: 'wrap' }}>
                          <View style={{ margin: 10 }}>
                              <ViolatorInfoDialog isVisible={isSelected} violator={violator} onRequestClose={this.onSimpleViolatorInfoDialogClose} />
                              <TouchableOpacity onPress={this.setSelectedViolator.bind(this, violator)}>
                                  <SimpleViolatorInfo violator={violator} editable={false} />
                              </TouchableOpacity>
                          </View>
                      </View>
                  );
              });

        if (!isVisible) return null;
        else {
            if (!violators) return null;
            const title = strings('violatorsList');
            return (
                <Modal transparent={false} animationType="slide" visible={isVisible} onRequestClose={this.handleOnRequestClose}>
                    <HeaderGeneric title={title} backAction={this.handleOnRequestClose} />
                    <ScrollView styles={{ flex: 1, alignItems: 'center' }}>{violatorsList}</ScrollView>
                </Modal>
            );
        }
    }
}

const styles = EStyleSheet.create({});
