import React, { Component } from 'react';
import { View, ScrollView } from 'react-native';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import { InspectionContainer } from 'app/components/InspectionContainer';
import { screenWithSpinner } from 'app/components/WithSpinner';
import styles from './styles';
import { Text } from 'react-native-paper';
import { inspectionsHelper } from 'app/api/helperServices';
import BusinessEntityList from './BusinessEntityList';
import {
    addBusinessEntityTocheckItems,
    infoViolatorChanged,
    inspectionRemoveViolator,
    removeBusinessEntityFromcheckItems,
} from 'app/actions/inspections';

class BusinessEntityDetails extends Component {
    handleBusinessEntitySelected = async callProps => {
        const { selectedViolator, changed } = callProps;
        const { dispatch, inspection } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);

        if (changed) {

            await dispatch(infoViolatorChanged({ baseInfo: { ...selectedViolator } }));

        }
        await dispatch(
            addBusinessEntityTocheckItems({
                currentVisitIndex,
                violator: selectedViolator,
            })
        );
    };
    handleOnViolatorEdited = async callProps => {
        const { editedViolator, inspTypeCheckItemId, changed, violationTypeId } = callProps;
        const { dispatch, inspection, onViolatorSelected, onActionChange } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        //Promise((resolve, reject) => {})
        if (changed) {

            await dispatch(infoViolatorChanged({ baseInfo: { ...editedViolator, isPresent: editedViolator.isPresent } }));

        }
    };

    handleOnViolatorRemoved = async () => {
        const { dispatch, inspection } = this.props;
        const { currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        await dispatch(removeBusinessEntityFromcheckItems({ currentVisitIndex }));
    };

    render() {
        const { dispatch, inspection, editable } = this.props;
        const currentViolator = inspection.violators.find(v => {
            return inspection.visits.find(vs => vs.values.find(vsv => v.violatorId == vsv.violatorId));
        });
        const { currentVisit } = inspectionsHelper.getCurrentVisit(inspection);
        const existingViolators = inspectionsHelper.getAllViolators({ violators: inspection.violators || [], visit: currentVisit });
        return (
            <InspectionContainer {...this.props}>
                <View style={styles.container}>
                    <View style={{ flex: 1 }}>
                        <ScrollView>
                            <BusinessEntityList
                                dispatch={dispatch}
                                inspection={inspection}
                                violator={currentViolator}
                                editable={editable}
                                existingViolators={existingViolators}
                                onViolatorSelected={this.handleBusinessEntitySelected}
                                onViolatorEdited={this.handleOnViolatorEdited}
                                onViolatorRemoved={this.handleOnViolatorRemoved}
                            />
                        </ScrollView>
                    </View>
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;

    const inspection = currentInspectionContainer.inspection;
    const editable = inspectionsHelper.getIsEditable(currentInspectionContainer);
    return {
        inspection,

        editable,
        currentInspectionVersion: state.inspections.currentInspectionVersion,
    };
};
const connectedViolationDetails = connect(mapStateToProps)(BusinessEntityDetails);
export default screenWithSpinner(connectedViolationDetails, { theme: 'light' });
