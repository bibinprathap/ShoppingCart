import React, { Component } from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, Picker, Modal } from 'react-native';
import { Icon, Switch, SimpleViolatorInfo } from 'app/components';
import { strings, localeProperty } from 'app/config/i18n/i18n';
import ViolatorDialog from './../ViolationDetails/ViolatorDialog';
import AddViolatorButton from './../ViolationDetails/AddViolatorButton';
import AppApi from 'app/api/real';
import styles from './styles';
export default class BusinessEntityList extends Component {
    customActionsForViolatorInfo = () => {
        const { inspTypeCheckItemId, violationTypeId, violator, onViolatorRemoved, onViolatorEdited, reconciledViolators } = this.props;

        const handleOnViolatorRemoved = () => {
            if (typeof onViolatorRemoved === 'function') onViolatorRemoved(inspTypeCheckItemId, violator.violatorId);
        };
        const handleOnViolatorEditPressed = () => {
            this.violatorDialog.showEdit(violator);
        };
        const handleOnViolatorEdited = (violator, changed) => {
            if (typeof onViolatorEdited === 'function') onViolatorEdited({ editedViolator: violator, inspTypeCheckItemId, changed, violationTypeId });
        };
        const handleViolatorDialogRef = ref => {
            this.violatorDialog = ref;
        };
        return (
            <View
                style={{
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                }}
            >
                <ViolatorDialog ref={handleViolatorDialogRef} onViolatorEdited={handleOnViolatorEdited} reconciledViolators={reconciledViolators} />
                <TouchableOpacity onPress={handleOnViolatorRemoved} style={{ padding: 5 }}>
                    <Icon type="MaterialCommunityIcons" name="delete" size={20} style={styles.iconDark} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleOnViolatorEditPressed} style={{ padding: 5 }}>
                    <Icon type="MaterialCommunityIcons" name="pencil" size={20} style={styles.iconDark} />
                </TouchableOpacity>
            </View>
        );
    };

    handleOnViolatorSelected = (selectedViolator, changed) => {
        const { onViolatorSelected, violationTypeId } = this.props;
        if (typeof onViolatorSelected === 'function') onViolatorSelected({ selectedViolator, changed, violationTypeId });
    };

    handleOnViolatorEdited = (editedViolator, changed) => {
        const { onViolatorEdited, inspTypeCheckItemId, violationTypeId } = this.props;
        if (typeof onViolatorEdited === 'function') onViolatorEdited({ editedViolator, inspTypeCheckItemId, changed, violationTypeId });
    };

    render() {
        const { editable, inspTypeCheckItemId, violator, buttonTitle } = this.props;
        const possibleViolatorTypes = ['individual', 'vehicle', 'company'];
        return (
            <View key={inspTypeCheckItemId} style={[styles.rowContainer]}>
                <View style={[styles.row]}>
                    <View style={{ flex: 1 }}>
                        {violator && (
                            <SimpleViolatorInfo
                                key={violator.violatorId}
                                violator={violator}
                                editable={editable}
                                customActions={this.customActionsForViolatorInfo}
                            />
                        )}
                    </View>
                </View>

                <View style={styles.row}>
                    <View style={{ flex: 1 }}>
                        {!violator && (
                            <View style={{ marginTop: 5, justifyContent: 'flex-start', alignItems: 'flex-start' }}>
                                <AddViolatorButton
                                    {...this.props}
                                    showModalDefault={true}
                                    selectLabel={buttonTitle || strings('establishment')}
                                    possibleViolatorTypes={possibleViolatorTypes}
                                    onViolatorSelected={this.handleOnViolatorSelected}
                                    onViolatorEdited={this.handleOnViolatorEdited}
                                    onViolatorRemoved={this.handleOnViolatorRemoved}
                                />
                            </View>
                        )}
                    </View>
                </View>
            </View>
        );
    }
}
