import React, { Component } from 'react';
import { View } from 'react-native';
import { connect } from 'react-redux';
import styles from './styles';
import { InspectionContainer, VisitView, Icon } from 'app/components';
import { screenWithSpinner } from 'app/components/WithSpinner';
import { coordsChanged, createInspectionRecordSuccess, createInspectionRecordFailure } from 'app/actions/inspections';

import { strings } from 'app/config/i18n/i18n';
import { inspectionsHelper } from 'app/api/helperServices';
import { _state } from 'app/config/store';
import { withNavigation, NavigationActions } from 'react-navigation';
import { getLocation } from 'app/api/helperServices/geolocation';
import { runBlockingTask, getErrorMessageWithDetail } from 'app/api/helperServices/utils';
import AppApi from 'app/api/real';
import { inspectionsTabLoad } from 'app/actions/generic';
const api = new AppApi();

class Checklist extends Component {
    constructor(props) {
        super(props);
        const { inspection } = props;
        this.createInspection = this.createInspection.bind(this);
        this.state = { selectedViolator: undefined };
        //this.handleVisitInfoChange = this.handleVisitInfoChange.bind(this);
    }

    createInspection = async (inspection, currentVisit, currentVisitIndex) => {
        const blockingTaskOptions = {
            id: 'creatingInspectionRecord',
            message: strings('creatingInspectionRecord'),
            autoClose: false,
            autoRetry: false,
            allowCancel: true,
            maxTries: 0,
            runner: async (options, updateOptions) => {
                //updateOptions({ ...options, autoClose: true }); //always reset to true, in some cases we throw error and want user to see it and press close manually
                const { inspectionTypeDetail = {} } = inspection;
                const { workflowConst, inspectionTypeId } = inspectionTypeDetail;
                if (!inspectionTypeId) {
                    const newOptions = { ...options, maxTries: 1, autoClose: false }; //we cannot retry if no inspection type is selected
                    updateOptions(newOptions);
                    throw strings('noInspectionTypeSelected');
                }
                if (!workflowConst) {
                    const newOptions = { ...options, maxTries: 1, autoClose: false }; //we cannot retry if there is no workflowConst for the selected inspection type
                    updateOptions(newOptions);
                    throw strings('selectedInspectionTypeHasNoWorkflow');
                }
                let locationIsAvailable = false;
                const loc = inspection.location || {};
                let coords = loc.coords;
                if (coords && loc.address && loc.address != null) {
                    locationIsAvailable = true;
                }
                let visitLocation;
                try {
                    const visitCoords = await getLocation();

                    const visitAddress = await api.getAddress(visitCoords);
                    visitLocation = { coords: visitCoords, address: visitAddress };
                } catch (error) {
                    const newOptions = { ...options, maxTries: 1, autoClose: false };
                    updateOptions(newOptions);
                    throw `Failed to acquire visit location. ${getErrorMessageWithDetail(error)}`;
                }
                const finalResult = await new Promise(async (resolve, reject) => {
                    if (!locationIsAvailable) {
                        if (!coords) {
                            try {
                                coords = await getLocation();
                            } catch (error) {
                                reject(error);
                            }
                        }
                        this.props
                            .dispatch(coordsChanged(coords))
                            .then(updatedLocation => {
                                if (!updatedLocation || !updatedLocation.address || updatedLocation.address == null) {
                                    throw strings('cannotFindAddress');
                                }
                                //dirty way, although location is updated in store by now, but we are mutating a local copy of inspection object
                                //todo: change the action to return the complete inspection object from the store, instead of modifying the local copy
                                inspection.location = updatedLocation;
                                resolve();
                            })
                            .catch(error => {
                                reject(error);
                            });
                    } else {
                        resolve();
                    }
                })
                    .then(() => {
                        return api.createInspectionRecord(inspection);
                    })
                    .then(createdInspection => {
                        let payload = {
                            visitIndex: currentVisitIndex,
                            visitLocation: visitLocation,
                            refNumber: inspection.refNumber,
                            workflowConst: createdInspection.inspectionTypeDetail.workflowConst,
                        };
                        const tab = {
                            tabKey: 'today',
                            startDate: this.props.inspectionsTabs.tabs.today.startDate,
                            endDate: this.props.inspectionsTabs.tabs.today.endDate,
                            reset: true,
                            isOrderByDesc: this.props.inspectionsTabs.tabs.today.isOrderByDesc,
                        };
                        this.props.dispatch(inspectionsTabLoad(tab));
                        return new Promise((resolve, reject) => {
                            this.props
                                .dispatch(createInspectionRecordSuccess(createdInspection, payload))
                                .then(() => {
                                    resolve(createdInspection);
                                })
                                .catch(error => {
                                    const payload = { visitIndex: currentVisitIndex, refNumber: inspection.refNumber };
                                    payload.error = error;
                                    this.props.dispatch(createInspectionRecordFailure(payload));
                                    reject(error);
                                });
                        });
                    })
                    .then(createdInspectionWithVisitLocation => {
                        const newOptions = { ...options, maxTries: 1, autoClose: true };
                        updateOptions(newOptions);
                        return createdInspectionWithVisitLocation;
                    })
                    .catch(error => {
                        throw getErrorMessageWithDetail(error);
                    });
                return finalResult;
            },
        };
        try {
            const result = await runBlockingTask(blockingTaskOptions);
        } catch (error) {
            this.props.navigation.dispatch(NavigationActions.back());
        }
    };

    handleFocus = () => {
        const { inspection } = this.props;
        const { currentVisit, currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        if (!(currentVisit && currentVisit.inspectionId)) {
            this.createInspection(inspection, currentVisit, currentVisitIndex);
        }
    };

    componentDidMount() {
        this.focusListener = this.props.navigation.addListener('didFocus', this.handleFocus);
        this.handleFocus(); //call first time
    }

    componentWillUnmount() {
        // Remove the event listener

        this.focusListener.remove();
    }

    handleMEPSViolatorSelection = violator => {
        this.setState({ selectedViolator: violator });
    };

    handleELMSViolatorSelection = violator => {
        this.setState({ selectedViolator: violator });
    };

    handleHiddenViolatorSelection = violator => {
        this.setState({ selectedViolator: violator });
    };

    handleHiddenViolatorSelectionRef = ref => {
        this.handleHiddenViolatorSelector = ref;
    };

    handleHiddenViolatorSelectionTrigger = () => {
        this.handleHiddenViolatorSelector.selectSingle();
    };

    customActionsForViolatorInfo = props => {
        const customActionHandler = () => {
            //alert(`Deleting violator ${violator.titleE}`);
            this.setState({ selectedViolator: undefined });
        };

        return (
            <View>
                <Icon type="MaterialCommunityIcons" name="delete" size={24} onPress={customActionHandler} />
            </View>
        );
    };

    render() {
        const { inspection, dispatch, currentInspectionVersion, dataLookups, calibration } = this.props;
        if (!inspection) return null;
        const { currentVisit, currentVisitIndex } = inspectionsHelper.getCurrentVisit(inspection);
        if (!currentVisit || !currentVisit.inspectionId) return null;
        return (
            <InspectionContainer {...this.props}>
                <View style={styles.MainContainer}>
                    <View style={[styles.contentWithChecklist]}>
                        <VisitView
                            visit={currentVisit}
                            visitIndex={currentVisitIndex}
                            dispatch={dispatch}
                            refNumber={inspection.refNumber}
                            inspection={inspection}
                            dataLookups={dataLookups}
                            currentInspectionVersion={currentInspectionVersion}
                            calibration={calibration}
                        />
                    </View>
                </View>
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;

    return {
        inspection: currentInspectionContainer && currentInspectionContainer.inspection,
        inspectionsTabs: state.generic.inspectionsTabs,
        dataLookups: state.masterdata.dataLookups,
        //editable: inspectionsHelper.getIsEditable(currentInspection),
        currentInspectionVersion: state.inspections.currentInspectionVersion,
        calibration: state.settings.calibration,
    };
};

const connectedChecklist = connect(mapStateToProps)(withNavigation(Checklist));
export default screenWithSpinner(connectedChecklist, { theme: 'light' });
