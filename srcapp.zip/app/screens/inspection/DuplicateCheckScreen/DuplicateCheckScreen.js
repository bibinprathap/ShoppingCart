import React, { Component } from 'react';
import { connect } from 'react-redux';
import { _ } from 'lodash';
import { InspectionContainer, DuplicateInspection } from 'app/components';
import { _state } from 'app/config/store';
import { inspectionsHelper } from 'app/api/helperServices';
import { setDuplicate } from 'app/actions/inspections';

class DuplicateCheckScreen extends Component {
    constructor() {
        super();
        this.optionSelected = this.optionSelected.bind(this);
    }

    optionSelected = ({ option, inspection }) => {
        this.props.dispatch(setDuplicate({ option, inspection }));
    };

    render() {
        const { currentInspectionContainer, editable, dispatch } = this.props;
        const { inspection } = currentInspectionContainer;
        return (
            <InspectionContainer {...this.props}>
                <DuplicateInspection
                    optionSelected={this.optionSelected}
                    duplicateInspection={inspection.duplicateInspection}
                    duplicatesDecision={inspection.duplicates}
                    inspectionTypeId={inspection.inspectionTypeDetail.inspectionTypeId}
                    editable={editable}
                    dispatch={dispatch}
                    inspection={inspection}
                />
            </InspectionContainer>
        );
    }
}

mapStateToProps = state => {
    const currentInspectionContainer = !!state.inspections.currentInspectionRef
        ? state.inspections.history[state.inspections.currentInspectionRef]
        : undefined;
    return {
        currentInspectionContainer: currentInspectionContainer,
        editable: inspectionsHelper.getIsEditable(currentInspectionContainer),
    };
};

export default connect(mapStateToProps)(DuplicateCheckScreen);
