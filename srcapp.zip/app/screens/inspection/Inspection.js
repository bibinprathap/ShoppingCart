import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Text } from 'react-native-paper';
import { BaseContainer } from 'app/components';

class Inspection extends Component {
    render() {
        return (
            <BaseContainer {...this.props}>
                <Text>Build the inspection screen here with its own tab navigator</Text>
            </BaseContainer>
        );
    }
}

export default Inspection;
