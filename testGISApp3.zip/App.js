/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, { Fragment } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  requireNativeComponent,
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import ArcGISMapView from 'react-native-arcgis-mapview';

const App = () => {
  return (
    <Fragment>
      <StatusBar barStyle="dark-content" />
      <SafeAreaView>
        <ScrollView
          contentInsetAdjustmentBehavior="automatic"
          style={styles.scrollView}>
          {/* <View style={{ flex: 1, width: 400, height: 400 }}>
            {/* <ArcGISMapView
              ref={mapView => (this.mapView = mapView)}
              style={{ width: '100%', height: '100%' }}
              initialMapCenter={[{ latitude: -110.828140, longitude: 44.460458 }]}
              // currentMarkerCoords={coords}
              recenterIfGraphicTapped={true}
              pointGraphics={this.pointGraphics}
              basemapUrl="http://david-galindo.maps.arcgis.com/home/item.html?id=fc75f65db9504175b2fb0e87b66672e5"
              onSingleTap={this.onSingleTap}
            /> */}

          {/* </View> */} 
          <View style={{ flex: 1, marginHorizontal:50, width: 600, height: 1000 }}>
            <GISMap
              style={{ width: '100%', height: '100%' }}
              {...this.props}
              ref={ref => {
                this._scantext = ref;
              }}
            >
              <View />
            </GISMap>
          </View>
 
        </ScrollView>
      </SafeAreaView>
    </Fragment>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: Colors.lighter,
  },
  engine: {
    position: 'absolute',
    right: 0,
  },
  body: {
    backgroundColor: Colors.white,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: Colors.black,
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: Colors.dark,
  },
  highlight: {
    fontWeight: '700',
  },
  footer: {
    color: Colors.dark,
    fontSize: 12,
    fontWeight: '600',
    padding: 4,
    paddingRight: 12,
    textAlign: 'right',
  },
});
var GISMap = requireNativeComponent('GISMapView', App, {
  nativeOnly: { onChange: true },
});

export default App;







