package com.mims;

import com.facebook.react.ReactActivity;
import com.facebook.react.ReactActivityDelegate;
import com.facebook.react.ReactRootView;
import com.swmansion.gesturehandler.react.RNGestureHandlerEnabledRootView;
import org.devio.rn.splashscreen.SplashScreen;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;
import com.facebook.react.modules.i18nmanager.I18nUtil;
import java.util.concurrent.TimeUnit;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.mims.uploader.FitPlaceWorker;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;



public class MainActivity extends ReactActivity {

 public static final int PERMISSION_REQ_CODE = 1234;
 

    String[] perms = {  "android.permission.CAMERA"
    };
    private static final String W_TAG = "Periodic Worker";
    public static PlacesClient placesClient;
    //public static MainActivity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
       // SplashScreen.show(this);  // here
        super.onCreate(savedInstanceState);
         checkPerms();
        I18nUtil sharedI18nUtilInstance = I18nUtil.getInstance();
        sharedI18nUtilInstance.allowRTL(getApplicationContext(), true);
       //
        //
        //
        // =  this;
        Places.initialize(getApplicationContext(), "THIS_IS_MY_API_KEY");
        placesClient = Places.createClient(this);
        PeriodicWorkRequest fireUploadBuilder =
                new PeriodicWorkRequest.Builder(FitPlaceWorker.class, 1, TimeUnit.MINUTES).build();
        WorkManager.getInstance().enqueueUniquePeriodicWork(W_TAG, ExistingPeriodicWorkPolicy.KEEP, fireUploadBuilder);

    }

    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "mims";
    }

        public void checkPerms() {
        // Checking if device version > 22 and we need to use new permission model 
        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP_MR1) {
       
            for(String perm : perms){
                // Checking each persmission and if denied then requesting permissions
                if(checkSelfPermission(perm) == PackageManager.PERMISSION_DENIED){
                    requestPermissions(perms, PERMISSION_REQ_CODE);
                    break;
                }
            }
        }
        }

          // Window overlay permission intent result
 


    @Override
    protected ReactActivityDelegate createReactActivityDelegate() {
        return new ReactActivityDelegate(this, getMainComponentName()) {
            @Override
            protected ReactRootView createRootView() {
                return new RNGestureHandlerEnabledRootView(MainActivity.this);
            }
        };
    }
}
