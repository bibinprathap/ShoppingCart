package com.mims;

import android.app.Application;
import android.util.Log;

import com.facebook.react.PackageList;
import com.facebook.hermes.reactexecutor.HermesExecutorFactory;
import com.facebook.react.bridge.JavaScriptExecutorFactory;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.soloader.SoLoader;

import com.adm.mims.bluetooth.BluetoothPackage;
import com.adm.mims.zebra.ZebraPackage;
import com.mims.NumberPicker.NumberPickerReactPackage;
import com.mims.scantext.ScanTextPackage;
import com.mims.mapView.MapPackage;
import com.mims.uploader.UploaderReactPackage;

import java.util.List;

public class MainApplication extends Application implements ReactApplication {
//private  static  MainApplication m;
  private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
    @Override
    public boolean getUseDeveloperSupport() {
      return BuildConfig.DEBUG;
    }

    @Override
    protected List<ReactPackage> getPackages() {
      @SuppressWarnings("UnnecessaryLocalVariable")
      List<ReactPackage> packages = new PackageList(this).getPackages();
      // Packages that cannot be autolinked yet can be added manually here, for example:
      // packages.add(new MyReactNativePackage());
      packages.add(new BluetoothPackage());
      packages.add(new ZebraPackage());
      packages.add(new NumberPickerReactPackage());
      packages.add(new ScanTextPackage());
      packages.add(new MapPackage());
      packages.add(new UploaderReactPackage());
       
      return packages;
    }

    @Override
    protected String getJSMainModuleName() {
      return "index";
    }
  };

  @Override
  public ReactNativeHost getReactNativeHost() {
    return mReactNativeHost;
  }

  @Override
  public void onCreate() {
    super.onCreate();
   // m = this;
    SoLoader.init(this, /* native exopackage */ false);
  }
 // public static MainApplication getInstance() {

  //  return m;
 // }
}
