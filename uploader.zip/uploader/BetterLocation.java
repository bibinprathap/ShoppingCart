package com.mims.uploader;

import android.Manifest;
import android.app.Activity;
import android.location.Location;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.RequiresPermission;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.util.Log;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.OnSuccessListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.ACCESS_WIFI_STATE;
import static com.mims.MainActivity.mFusedLocationClient;

import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;


public class BetterLocation  {
    private static String TAG = "Location: ";
    public static Map<String, Object> places = new HashMap<>();
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_WIFI_STATE
    };

    public void findCurrentPlace(Context context ) {

        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {
            findCurrentPlaceWithPermissions(context);
        }
        else {
          //  ActivityCompat.requestPermissions(activity, PERMISSIONS, PERMISSION_ALL);
        }
    }

    @RequiresPermission(allOf = {ACCESS_FINE_LOCATION, ACCESS_WIFI_STATE})
    public void findCurrentPlaceWithPermissions(Context context) {
        if(ContextCompat.checkSelfPermission(context, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED) {

            Task<Location> currentPlaceTask =
                    mFusedLocationClient.getLastLocation();

            currentPlaceTask.addOnCompleteListener( task -> {
                if (task.isSuccessful()) {
                    places.clear();
                    Location response = task.getResult();
                    assert response != null;

                    Log.d(TAG, "findCurrentPlace: "
                            +response.getLatitude() + "\n"
                            + response.getLongitude() + "\n" );
                    WritableMap params = Arguments.createMap();
                    params.putString("currentLocation", "Locationevery15minit");
                    params.putString("Latitude", Double.toString(response.getLatitude()));
                    params.putString("Longitude", Double.toString(response.getLongitude()));
                    com.mims.uploader.UploaderModule.sendEvent3("progress", params);
                } else {
                    Exception exception = task.getException();
                    if (exception instanceof ApiException) {
                        ApiException apiException = (ApiException) exception;
                        Log.e(TAG, "findCurrentPlaceWithPermissions: " + apiException.getStatusCode() + apiException.getLocalizedMessage());
                    }
                }
            });



        }
    }

}