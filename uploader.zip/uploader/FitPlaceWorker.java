package com.mims.uploader;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import androidx.annotation.NonNull;
import android.util.Log;
import com.mims.MainActivity;
//import com.bettertime.packages.NativeUsageEvents;
//import com.bettertime.timePackage.NativeTime;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
//import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;
// import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
// import com.facebook.react.ReactApplication;
// import com.facebook.react.bridge.ReactContext;
// import com.facebook.react.ReactInstanceManager;

class LocThread implements Runnable {
    public static LocThread sInstance;
    private static final String UPLOAD_NOTIFICATION = "UPLOAD_NOTIFICATION";

    public static LocThread getInstance(Context context) {
        if (sInstance == null) {
            // Always pass in the Application Context
            sInstance = new LocThread(context.getApplicationContext());
        }

        return sInstance;
    }

    private Context mContext;

    public LocThread(Context context) {
        mContext = context;
    }

    private String TAG = "LocThread: ";

    @Override
    public void run() {
        try {
            Looper.prepare();
            Log.d(TAG, "running every 20 second");
            WritableMap params = Arguments.createMap();
            params.putString("pereodiccall", "every15minit");
            // ReactInstanceManager mReactInstanceManager =
            // com.mims.MainApplication.getInstance().getReactNativeHost().getReactInstanceManager();
            // ReactContext Rcontext = mReactInstanceManager.getCurrentReactContext();

            // Rcontext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(UPLOAD_NOTIFICATION,
            // params);
            com.mims.uploader.UploaderModule.sendEvent2("progress", params);

            Looper.loop();
        } catch (NullPointerException e) {
            Log.d(TAG, "run: " + e.getLocalizedMessage());
        }
    }
}

public class FitPlaceWorker extends ListenableWorker {

    private static final String TAG = "FitPlace Worker: ";
    private Thread locThread;

    public FitPlaceWorker(Context context, WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public ListenableFuture<Result> startWork() {
        SettableFuture<Result> result = SettableFuture.create();
        Log.d(TAG, "doWork - FitPlace fired");

        fitPlaceStamp();

        result.set(Result.success());
        return result;
    }

    private void fitPlaceStamp() {

        locThread = new Thread(new LocThread(getApplicationContext()));
        locThread.start();
        // log methods

    }

}